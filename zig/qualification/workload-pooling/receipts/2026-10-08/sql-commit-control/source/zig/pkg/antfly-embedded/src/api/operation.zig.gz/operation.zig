// Copyright 2026 Antfly, Inc.
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

//! Transport-neutral contracts shared by API-kernel operations.
//!
//! Nothing in this module depends on httpx or on the legacy HTTP request and
//! response types. HTTP, internal callers, and future compiled-boundary
//! adapters may all construct these values without manufacturing a wire
//! request.

const std = @import("std");
const platform_time = @import("antfly_platform").time;

pub const ApiError = error{
    Canceled,
    DeadlineExceeded,
    Unauthorized,
    Forbidden,
    NotFound,
    InvalidArgument,
    Conflict,
    Unsupported,
    CapacityExhausted,
    Unavailable,
    Internal,
};

/// Borrowed cancellation source. The owner must keep `ptr` alive for the
/// complete operation call. A callback keeps the kernel independent of the
/// transport's concrete cancellation representation.
pub const CancellationToken = @import("antfly_cancellation").CancellationToken;

/// Authenticated identity projected into an operation. Permissions stay in
/// the authorization policy layer; operations receive only the identity they
/// need for ownership, auditing, and row-policy semantics.
pub const Principal = struct {
    kind: Kind,
    subject: []const u8,

    pub const Kind = enum {
        user,
        service,
        internal,
    };
};

/// An admission permit remains owned by the ingress adapter. The request
/// context borrows it so downstream code can preserve the reservation across
/// nested operations without releasing it accidentally.
pub const AdmissionReservation = struct {
    ptr: *anyopaque,
    release_fn: *const fn (*anyopaque) void,
    released: bool = false,

    pub fn release(self: *AdmissionReservation) void {
        if (self.released) return;
        self.released = true;
        self.release_fn(self.ptr);
    }
};

/// Bounded, request-owned diagnostic context. Operations may populate this
/// while unwinding an error so ingress adapters can return actionable details
/// without thread-local state or heap allocation.
pub const GraphMetricRejectionDiagnostic = struct {
    graph_index_name: [256]u8 = undefined,
    graph_index_name_len: u16 = 0,
    metric_name: [128]u8 = undefined,
    metric_name_len: u8 = 0,
    materializer_fingerprint: u64 = 0,

    pub fn graphIndexName(self: *const GraphMetricRejectionDiagnostic) []const u8 {
        return self.graph_index_name[0..self.graph_index_name_len];
    }

    pub fn metricName(self: *const GraphMetricRejectionDiagnostic) []const u8 {
        return self.metric_name[0..self.metric_name_len];
    }
};

pub const RequestDiagnostics = struct {
    graph_metric_rejection: ?GraphMetricRejectionDiagnostic = null,

    pub fn recordGraphMetricRejection(
        self: *RequestDiagnostics,
        graph_index_name: []const u8,
        metric_name: []const u8,
        materializer_fingerprint: u64,
    ) void {
        var diagnostic = GraphMetricRejectionDiagnostic{
            .materializer_fingerprint = materializer_fingerprint,
        };
        const graph_len = @min(graph_index_name.len, diagnostic.graph_index_name.len);
        @memcpy(diagnostic.graph_index_name[0..graph_len], graph_index_name[0..graph_len]);
        diagnostic.graph_index_name_len = @intCast(graph_len);
        const metric_len = @min(metric_name.len, diagnostic.metric_name.len);
        @memcpy(diagnostic.metric_name[0..metric_len], metric_name[0..metric_len]);
        diagnostic.metric_name_len = @intCast(metric_len);
        self.graph_metric_rejection = diagnostic;
    }
};

pub const RequestContext = struct {
    /// Granted only after administrator authentication by a trusted native
    /// ingress. Metadata HTTP never reconstructs this from request JSON.
    setting_admin: bool = false,
    /// Exact authenticated SQL credential principal; distinct from username
    /// for API keys and derived only by trusted API/pgwire ingress.
    setting_read_principal: ?[]const u8 = null,
    /// Granted only by the authenticated internal metadata transport after
    /// verifying a body-bound policy-install read grant. Never infer it from
    /// a serialized catalog request or forwarded user identity.
    row_policy_install_authority: bool = false,
    /// Internal body-bound authorization for fenced FK schema publication.
    /// Never accepted from public SQL or a client-provided catalog payload.
    fk_generation_publication_authority: bool = false,
    /// Set only by the administrator-authorized relational recovery routes.
    relational_recovery: enum { none, repair, retry, retire } = .none,
    relational_retirement_target: ?[]const u8 = null,
    relational_retirement_drop: bool = false,
    cancellation: CancellationToken = .none,
    /// Absolute monotonic deadline. This deliberately does not use a wall
    /// clock or a transport timeout duration.
    deadline_ns: ?u64 = null,
    deadline_io: ?@import("antfly_runtime_abi").io_abi.Borrow = null,
    /// Execution capability for bounded request fanout. Independent of the
    /// deadline clock: native-monotonic HTTP budgets can still schedule Io.
    fanout_io: ?@import("antfly_runtime_abi").io_abi.Borrow = null,
    /// Trusted request-lifetime execution team. Local callbacks may borrow it
    /// only until their children join. Never reconstruct this from wire data.
    execution_team: ?*@import("antfly_runtime_abi").runnable_abi.Team = null,
    /// Borrowed request identity used for correlation. An empty value means
    /// the caller did not supply one; adapters may generate one in middleware.
    request_id: []const u8 = "",
    principal: ?Principal = null,
    /// Request-lifetime capability for writes discovered after initial route
    /// admission (for example FK cascades). Adapters retain the admitted
    /// credential scopes; a username alone cannot reconstruct API-key rights.
    table_write_authorization: ?TableWriteAuthorization = null,
    /// Borrowed authenticated ingress credential, never serialized or
    /// reconstructed from `principal`. Only ApiHttpServer may interpret this
    /// opaque capability when minting a table-scoped RLS write proof.
    row_policy_credential: ?*const anyopaque = null,
    admission: ?*AdmissionReservation = null,
    /// Borrowed for the duration of the operation. This is deliberately
    /// request-scoped: std.Io tasks may resume on a different worker thread.
    diagnostics: ?*RequestDiagnostics = null,
    /// Durable hash of an externally sourced table definition that was
    /// authorized before asynchronous restore admission.
    destination_authorization_fingerprint: []const u8 = "",
    /// Credential identity that authorized durable background destinations.
    /// Workers re-resolve this principal against the live user/key store.
    destination_authorization_principal: []const u8 = "",
    /// Borrowed, authenticated internal route capability. HTTP adapters keep
    /// the encoded form borrowed and transport-neutral operations decode it
    /// only when a group-local read is actually dispatched.
    catalog_route_fence_json: []const u8 = "",

    pub fn ensureActive(self: RequestContext) ApiError!void {
        if (self.cancellation.isCancelled()) return error.Canceled;
        if (self.deadline_ns) |deadline| {
            const now_ns = if (self.deadline_io) |borrow| blk: {
                var receiver = borrow.receive() catch return error.Internal;
                break :blk @as(u64, @intCast(@max(0, std.Io.Clock.now(.awake, receiver.io()).nanoseconds)));
            } else platform_time.monotonicNs();
            if (now_ns >= deadline) return error.DeadlineExceeded;
        }
    }

    /// Preserve remaining time when entering native owners or HTTP timeout
    /// APIs, whose absolute clock is platform monotonic rather than Io awake.
    pub fn platformDeadline(self: RequestContext) !RequestContext {
        try self.ensureActive();
        const deadline = self.deadline_ns orelse return self;
        const borrow = self.deadline_io orelse return self;
        const platform_now = platform_time.monotonicNs();
        var receiver = try borrow.receive();
        const source_now: u64 = @intCast(@max(0, std.Io.Clock.now(.awake, receiver.io()).nanoseconds));
        if (source_now >= deadline) return error.DeadlineExceeded;
        var normalized = self;
        normalized.deadline_ns = platform_now +| (deadline - source_now);
        normalized.deadline_io = null;
        return normalized;
    }
};

pub const TableWriteAuthorization = struct {
    ptr: *const anyopaque,
    allows: *const fn (*const anyopaque, []const u8) bool,
};

/// A synchronous sink applies backpressure by not returning from `writeAll`
/// until the bytes have been accepted or the operation has failed. The sink
/// is transport-owned and borrowed for the duration of `produce`.
pub const StreamSink = struct {
    ptr: *anyopaque,
    vtable: *const VTable,

    pub const VTable = struct {
        write_all: *const fn (*anyopaque, []const u8) anyerror!void,
        flush: *const fn (*anyopaque) anyerror!void,
        close: *const fn (*anyopaque) anyerror!void,
    };

    pub fn writeAll(self: StreamSink, bytes: []const u8) !void {
        try self.vtable.write_all(self.ptr, bytes);
    }

    pub fn flush(self: StreamSink) !void {
        try self.vtable.flush(self.ptr);
    }

    pub fn close(self: StreamSink) !void {
        try self.vtable.close(self.ptr);
    }
};

pub const StreamProducer = struct {
    ptr: *anyopaque,
    produce_fn: *const fn (*anyopaque, RequestContext, StreamSink) anyerror!void,

    pub fn produce(self: StreamProducer, request: RequestContext, sink: StreamSink) !void {
        try request.ensureActive();
        try self.produce_fn(self.ptr, request, sink);
    }
};

pub const JsonResult = struct {
    bytes: []const u8,
};

pub const BytesResult = struct {
    bytes: []const u8,
    content_type: []const u8 = "application/octet-stream",
};

pub const StatusResult = struct {
    status: u16 = 204,
};

pub const OperationResult = union(enum) {
    json: JsonResult,
    bytes: BytesResult,
    stream: StreamProducer,
    empty: StatusResult,
};

test "request context observes cancellation before deadline" {
    var signal = std.atomic.Value(bool).init(true);
    const request = RequestContext{
        .cancellation = CancellationToken.fromAtomic(&signal),
        .deadline_ns = 0,
    };
    try std.testing.expectError(error.Canceled, request.ensureActive());
}

test "admission reservation releases exactly once" {
    const Counter = struct {
        count: usize = 0,

        fn release(ptr: *anyopaque) void {
            const self: *@This() = @ptrCast(@alignCast(ptr));
            self.count += 1;
        }
    };
    var counter = Counter{};
    var reservation = AdmissionReservation{
        .ptr = &counter,
        .release_fn = Counter.release,
    };
    reservation.release();
    reservation.release();
    try std.testing.expectEqual(@as(usize, 1), counter.count);
}

test "serverless request diagnostics remain isolated across interleaved operations" {
    var first = RequestDiagnostics{};
    var second = RequestDiagnostics{};

    first.recordGraphMetricRejection("graph-a", "pagerank", 11);
    second.recordGraphMetricRejection("graph-b", "degree", 22);

    const first_rejection = first.graph_metric_rejection.?;
    const second_rejection = second.graph_metric_rejection.?;
    try std.testing.expectEqualStrings("graph-a", first_rejection.graphIndexName());
    try std.testing.expectEqualStrings("pagerank", first_rejection.metricName());
    try std.testing.expectEqual(@as(u64, 11), first_rejection.materializer_fingerprint);
    try std.testing.expectEqualStrings("graph-b", second_rejection.graphIndexName());
    try std.testing.expectEqualStrings("degree", second_rejection.metricName());
    try std.testing.expectEqual(@as(u64, 22), second_rejection.materializer_fingerprint);
}
