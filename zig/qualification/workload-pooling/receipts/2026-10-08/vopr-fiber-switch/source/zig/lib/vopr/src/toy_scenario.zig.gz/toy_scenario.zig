// Copyright 2026 Antfly, Inc.
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

const std = @import("std");
const event = @import("event.zig");
const ids = @import("id.zig");
const observation = @import("observation.zig");
const outcome = @import("outcome.zig");
const property = @import("property.zig");
const transition = @import("transition.zig");

pub const ToyScenario = struct {
    pub const name: []const u8 = "phase0-toy-counter";
    pub const version: u32 = 1;
    pub const bounded_id = ids.stable("property", "toy.counter_bounded");
    pub const positive_id = ids.stable("property", "toy.counter_positive_reached");
    pub const increment_id = ids.stable("transition", "toy.increment");
    pub const decrement_id = ids.stable("transition", "toy.decrement");
    pub const properties = &[_]property.Declaration{
        .{ .id = bounded_id, .name = "toy.counter_bounded", .kind = .always },
        .{ .id = positive_id, .name = "toy.counter_positive_reached", .kind = .reachable },
    };

    pub const World = struct { counter: i64 = 0, steps: u8 = 0 };

    pub fn init(_: std.mem.Allocator) !World {
        return .{};
    }

    pub fn deinit(_: *World, _: std.mem.Allocator) void {}

    pub fn enumerate(world: *World, list: *transition.List, allocator: std.mem.Allocator) !void {
        try list.append(allocator, .{ .id = increment_id, .name = "toy.increment", .kind = .workload, .parameter = 1 });
        if (world.counter > 0) try list.append(allocator, .{ .id = decrement_id, .name = "toy.decrement", .kind = .workload, .parameter = -1 });
    }

    pub fn execute(world: *World, selected: transition.Transition, events: *event.Sink, allocator: std.mem.Allocator) !outcome.TransitionOutcome {
        if (selected.id != increment_id and selected.id != decrement_id) return error.UnknownToyTransition;
        world.counter += selected.parameter;
        world.steps += 1;
        try events.emitNamed(allocator, .state_change, "toy.counter_changed", @bitCast(world.counter));
        return if (world.steps == 4)
            outcome.TransitionOutcome.targetReached("toy.transition_budget_reached", world.steps)
        else
            outcome.TransitionOutcome.applied();
    }

    pub fn observe(world: *World, builder: *observation.Builder, allocator: std.mem.Allocator) !void {
        // Add in reverse lexical order to prove canonicalization is owned by the engine.
        try builder.addNamed(allocator, "toy.steps", world.steps);
        try builder.addNamed(allocator, "toy.counter", world.counter);
    }

    pub fn evaluate(world: *World, sink: *property.Sink, allocator: std.mem.Allocator) !void {
        try sink.check(allocator, bounded_id, world.counter >= -4 and world.counter <= 4);
        try sink.check(allocator, positive_id, world.counter > 0);
    }

    pub fn done(world: *World) bool {
        return world.steps == 4;
    }

    pub fn snapshotAlloc(world: *const World, allocator: std.mem.Allocator) ![]u8 {
        const bytes = try allocator.alloc(u8, @sizeOf(i64) + @sizeOf(u8));
        std.mem.writeInt(i64, bytes[0..@sizeOf(i64)], world.counter, .little);
        bytes[@sizeOf(i64)] = world.steps;
        return bytes;
    }

    pub fn restoreSnapshot(world: *World, bytes: []const u8, _: std.mem.Allocator) !void {
        if (bytes.len != @sizeOf(i64) + @sizeOf(u8)) return error.InvalidToySnapshot;
        world.counter = std.mem.readInt(i64, bytes[0..@sizeOf(i64)], .little);
        world.steps = bytes[@sizeOf(i64)];
    }
};
