// Copyright 2026 Antfly, Inc.
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

const std = @import("std");
const choice = @import("choice.zig");
const collector = @import("collector.zig");
const event = @import("event.zig");
const event_stream = @import("event_stream.zig");
const flight_recorder = @import("flight_recorder.zig");
const health = @import("health.zig");
const ids = @import("id.zig");
const observation = @import("observation.zig");
const outcome = @import("outcome.zig");
const property = @import("property.zig");
const scenario_contract = @import("scenario.zig");
const scheduler = @import("scheduler.zig");
const snapshot = @import("snapshot.zig");
const trace = @import("trace.zig");
const transition = @import("transition.zig");

pub const Config = struct {
    system: []const u8 = "generic",
    seed: ?u64 = null,
    transition_budget: u64,
    resource_budget: u64 = std.math.maxInt(u64),
    fixture_hashes: []const u64 = &.{},
    feature_flags: []const ids.StableId = &.{},
    backend_ids: []const ids.StableId = &.{},
    scenario_parameters: []const trace.Parameter = &.{},
    source_revision: []const u8 = "unknown",
    target: []const u8 = "native",
    optimize: []const u8 = "unknown",
    /// Optional diagnostic-only scenario dependency (for example, a formal
    /// trace sink). It is intentionally absent from the replay artifact and
    /// must not change choices, observations, properties, or failures.
    scenario_context: ?*anyopaque = null,
    /// Optional diagnostic-only ring. Recorder contents and capacity never
    /// participate in choices, observations, fingerprints, or replay.
    flight_recorder: ?*flight_recorder.Recorder = null,
    /// Optional diagnostic-only live observer. The built-in buffered NDJSON
    /// observer never calls its sink on this path and isolates queue overflow
    /// from execution and replay. Custom observers must not block or panic.
    event_observer: ?event_stream.Observer = null,
};

const PropertyFailure = struct {
    declaration: property.Declaration,
    transition_index: u64,
};

const StepResult = enum { executed, stopped };

pub fn run(
    comptime Scenario: type,
    allocator: std.mem.Allocator,
    choice_source: choice.Source,
    config: Config,
) !trace.Trace {
    comptime scenario_contract.assertContract(Scenario);
    if (config.transition_budget == 0) return error.InvalidTransitionBudget;

    var world = try initWorld(Scenario, allocator, config.scenario_context);
    defer Scenario.deinit(&world, allocator);
    var tracker = try property.Tracker.init(allocator, Scenario.properties);
    defer tracker.deinit();
    var result = try initTrace(Scenario, allocator, config);
    errdefer result.deinit();

    const last_digest = try recordObservation(Scenario, allocator, &world, &result, 0);
    var health_recorder = health.Recorder{};
    recordHealth(Scenario, &world, 0, &health_recorder);
    return continueRun(Scenario, allocator, choice_source, config.transition_budget, &world, &tracker, &result, 0, last_digest, config.flight_recorder, config.event_observer, &health_recorder);
}

/// Replays and validates an exact prefix, then captures all logical execution
/// state needed to resume: scenario-owned bytes and accumulated property
/// statuses. It never snapshots pointers, allocators, or OS resources.
pub fn captureCheckpoint(
    comptime Scenario: type,
    allocator: std.mem.Allocator,
    artifact: *const trace.Trace,
    prefix_len: usize,
) !snapshot.Logical {
    comptime scenario_contract.assertContract(Scenario);
    comptime snapshot.assertContract(Scenario);
    try artifact.validate();
    try validateCompatibility(Scenario, artifact);
    if (prefix_len > artifact.choices.items.len) return error.InvalidSnapshotPrefix;

    const config = configFromTrace(artifact);
    var world = try initWorld(Scenario, allocator, config.scenario_context);
    defer Scenario.deinit(&world, allocator);
    var tracker = try property.Tracker.init(allocator, Scenario.properties);
    defer tracker.deinit();
    var actual = try initTrace(Scenario, allocator, config);
    defer actual.deinit();
    var last_digest = try recordObservation(Scenario, allocator, &world, &actual, 0);
    var health_recorder = health.Recorder{};
    recordHealth(Scenario, &world, 0, &health_recorder);
    var replay_source = choice.Replay{ .records = artifact.choices.items };
    var transition_index: u64 = 0;
    while (transition_index < prefix_len) {
        if (try executeStep(Scenario, allocator, replay_source.source(), config.transition_budget, &world, &tracker, &actual, &transition_index, &last_digest, null, null, &health_recorder) == .stopped)
            return error.SnapshotPrefixPastScenarioEnd;
    }
    actual.summary = .{
        .transitions = transition_index,
        .final_observation_digest = last_digest,
        .property_failures = 0,
    };
    var expected = try initTraceFromArtifact(allocator, artifact);
    defer expected.deinit();
    try copyPrefix(&expected, artifact, prefix_len);
    expected.summary = actual.summary;
    const actual_bytes = try actual.renderAlloc(allocator);
    defer allocator.free(actual_bytes);
    const expected_bytes = try expected.renderAlloc(allocator);
    defer allocator.free(expected_bytes);
    if (!std.mem.eql(u8, actual_bytes, expected_bytes)) return error.CheckpointPrefixArtifactDiverged;

    var checkpoint = try snapshot.captureExecution(
        Scenario,
        allocator,
        &world,
        tracker.statuses,
        transition_index,
        last_digest,
        try snapshot.prefixDigest(artifact, prefix_len),
    );
    checkpoint.health_recorder = health_recorder;
    return checkpoint;
}

/// Clean-replay to a choice prefix, prove the reconstructed prefix equals the
/// artifact, then let the scenario emit pointer-free logical diagnostics.
/// Scenarios opt in with `pub fn collect(*World, *collector.Sink) !void`.
pub fn collectAt(
    comptime Scenario: type,
    allocator: std.mem.Allocator,
    artifact: *const trace.Trace,
    prefix_len: usize,
    sink: *collector.Sink,
) !void {
    comptime scenario_contract.assertContract(Scenario);
    if (!@hasDecl(Scenario, "collect")) return error.ScenarioCollectorsUnsupported;
    try artifact.validate();
    try validateCompatibility(Scenario, artifact);
    if (prefix_len > artifact.choices.items.len or sink.choice_prefix != prefix_len)
        return error.InvalidCollectorPrefix;
    const config = configFromTrace(artifact);
    var world = try initWorld(Scenario, allocator, config.scenario_context);
    defer Scenario.deinit(&world, allocator);
    var tracker = try property.Tracker.init(allocator, Scenario.properties);
    defer tracker.deinit();
    var actual = try initTrace(Scenario, allocator, config);
    defer actual.deinit();
    var last_digest = try recordObservation(Scenario, allocator, &world, &actual, 0);
    var health_recorder = health.Recorder{};
    recordHealth(Scenario, &world, 0, &health_recorder);
    var replay_source = choice.Replay{ .records = artifact.choices.items };
    var transition_index: u64 = 0;
    while (transition_index < prefix_len) {
        if (try executeStep(Scenario, allocator, replay_source.source(), config.transition_budget, &world, &tracker, &actual, &transition_index, &last_digest, null, null, &health_recorder) == .stopped)
            return error.CollectorPrefixPastScenarioEnd;
    }
    actual.summary = .{
        .transitions = transition_index,
        .final_observation_digest = last_digest,
        .property_failures = 0,
    };
    var expected = try initTraceFromArtifact(allocator, artifact);
    defer expected.deinit();
    try copyPrefix(&expected, artifact, prefix_len);
    expected.summary = actual.summary;
    const actual_bytes = try actual.renderAlloc(allocator);
    defer allocator.free(actual_bytes);
    const expected_bytes = try expected.renderAlloc(allocator);
    defer allocator.free(expected_bytes);
    if (!std.mem.eql(u8, actual_bytes, expected_bytes)) return error.CollectorPrefixArtifactDiverged;
    try Scenario.collect(&world, sink);
    sink.canonicalize();
}

/// Restores a validated logical checkpoint and executes a suffix source. The
/// returned artifact includes the original canonical prefix. Callers must
/// exact-replay the complete artifact from a clean world before retention.
pub fn resumeFromCheckpoint(
    comptime Scenario: type,
    allocator: std.mem.Allocator,
    artifact: *const trace.Trace,
    checkpoint: snapshot.Logical,
    suffix_source: choice.Source,
) !trace.Trace {
    return resumeFromCheckpointWithRecorder(Scenario, allocator, artifact, checkpoint, suffix_source, null);
}

pub fn resumeFromCheckpointWithRecorder(
    comptime Scenario: type,
    allocator: std.mem.Allocator,
    artifact: *const trace.Trace,
    checkpoint: snapshot.Logical,
    suffix_source: choice.Source,
    recorder: ?*flight_recorder.Recorder,
) !trace.Trace {
    comptime scenario_contract.assertContract(Scenario);
    comptime snapshot.assertContract(Scenario);
    try artifact.validate();
    try validateCompatibility(Scenario, artifact);
    const prefix_len = std.math.cast(usize, checkpoint.transition_index) orelse return error.InvalidSnapshotPrefix;
    if (prefix_len > artifact.choices.items.len or checkpoint.prefix_digest != try snapshot.prefixDigest(artifact, prefix_len))
        return error.CheckpointPrefixIdentityDiverged;
    if (checkpoint.observation_digest != artifact.observations.items[prefix_len].digest)
        return error.CheckpointPrefixObservationDiverged;

    const config = configFromTrace(artifact);
    var world = try initWorld(Scenario, allocator, config.scenario_context);
    defer Scenario.deinit(&world, allocator);
    try snapshot.restore(Scenario, &world, checkpoint, allocator);
    var tracker = try property.Tracker.init(allocator, Scenario.properties);
    defer tracker.deinit();
    try snapshot.restorePropertyTracker(checkpoint, &tracker);
    var result = try initTraceFromArtifact(allocator, artifact);
    errdefer result.deinit();
    try copyPrefix(&result, artifact, prefix_len);
    var health_recorder = checkpoint.health_recorder orelse health.Recorder{};
    // Scenario-created checkpoints do not carry diagnostic prefix state.
    // Captured execution checkpoints already include this exact sample and
    // must not double-count it or reset their consecutive-stall state.
    if (checkpoint.health_recorder == null)
        recordHealth(Scenario, &world, checkpoint.transition_index, &health_recorder);
    return continueRun(
        Scenario,
        allocator,
        suffix_source,
        config.transition_budget,
        &world,
        &tracker,
        &result,
        checkpoint.transition_index,
        checkpoint.observation_digest,
        recorder,
        null,
        &health_recorder,
    );
}

fn continueRun(
    comptime Scenario: type,
    allocator: std.mem.Allocator,
    choice_source: choice.Source,
    transition_budget: u64,
    world: *Scenario.World,
    tracker: *property.Tracker,
    result: *trace.Trace,
    starting_transition_index: u64,
    starting_digest: u64,
    recorder: ?*flight_recorder.Recorder,
    observer: ?event_stream.Observer,
    health_recorder: *health.Recorder,
) !trace.Trace {
    var last_digest = starting_digest;
    var transition_index = starting_transition_index;
    while (!Scenario.done(world)) {
        if (try executeStep(Scenario, allocator, choice_source, transition_budget, world, tracker, result, &transition_index, &last_digest, recorder, observer, health_recorder) == .stopped)
            break;
    }
    try choice_source.finish();
    if (@hasDecl(Scenario, "budgetFailure")) {
        if (transition_index == transition_budget and !Scenario.done(world)) {
            const identity = Scenario.budgetFailure(world);
            try result.addFailure(.{
                .index = transition_index,
                .class = .liveness,
                .property_id = null,
                .identity = identity,
                .fingerprint = ids.stable("failure.liveness", identity),
                .observation_digest = last_digest,
            });
        }
    }
    // Final checks run after the canonical workload, even at its budget limit.
    // They must use distinct properties from per-transition evaluation.
    if (@hasDecl(Scenario, "finalize")) {
        var sink: property.Sink = .{};
        defer sink.deinit(allocator);
        try Scenario.finalize(world, &sink, allocator);
        try appendEvaluations(Scenario, &sink, result, tracker, transition_index);
        std.mem.sort(trace.PropertyRecord, result.properties.items, {}, struct {
            fn lessThan(_: void, lhs: trace.PropertyRecord, rhs: trace.PropertyRecord) bool {
                return lhs.index < rhs.index or (lhs.index == rhs.index and lhs.property_id < rhs.property_id);
            }
        }.lessThan);
    }
    tracker.finish(transition_index);
    var property_failures: std.ArrayListUnmanaged(PropertyFailure) = .empty;
    defer property_failures.deinit(allocator);
    for (Scenario.properties, tracker.statuses) |declaration, status| {
        if (!status.failed) continue;
        try property_failures.append(allocator, .{ .declaration = declaration, .transition_index = status.first_failure_transition.? });
    }
    std.mem.sort(PropertyFailure, property_failures.items, {}, struct {
        fn lessThan(_: void, lhs: PropertyFailure, rhs: PropertyFailure) bool {
            if (lhs.transition_index != rhs.transition_index) return lhs.transition_index < rhs.transition_index;
            return ids.stable("failure", lhs.declaration.name) < ids.stable("failure", rhs.declaration.name);
        }
    }.lessThan);
    for (property_failures.items) |failure| {
        try result.addFailure(.{
            .index = failure.transition_index,
            .class = .property,
            .property_id = failure.declaration.id,
            .identity = failure.declaration.name,
            .fingerprint = ids.stable("failure", failure.declaration.name),
            .observation_digest = null,
        });
    }
    std.mem.sort(trace.FailureRecord, result.failures.items, {}, struct {
        fn lessThan(_: void, lhs: trace.FailureRecord, rhs: trace.FailureRecord) bool {
            if (lhs.index != rhs.index) return lhs.index < rhs.index;
            return lhs.fingerprint < rhs.fingerprint;
        }
    }.lessThan);
    result.summary = .{
        .transitions = transition_index,
        .final_observation_digest = last_digest,
        .property_failures = @intCast(tracker.failureCount()),
    };
    if (health_recorder.evidence().samples != 0) result.health_evidence = health_recorder.evidence();
    try result.validate();
    _ = try choice.auditTrace(result);
    return result.*;
}

fn executeStep(
    comptime Scenario: type,
    allocator: std.mem.Allocator,
    choice_source: choice.Source,
    transition_budget: u64,
    world: *Scenario.World,
    tracker: *property.Tracker,
    result: *trace.Trace,
    transition_index: *u64,
    last_digest: *u64,
    recorder: ?*flight_recorder.Recorder,
    observer: ?event_stream.Observer,
    health_recorder: *health.Recorder,
) !StepResult {
    if (Scenario.done(world)) return error.SnapshotPrefixPastScenarioEnd;
    if (transition_index.* == transition_budget) return .stopped;

    var enabled = try scheduler.enumerateCanonical(Scenario, world, allocator);
    defer enabled.deinit(allocator);
    if (enabled.items.items.len == 0) {
        const classification: scenario_contract.NoTransition = if (@hasDecl(Scenario, "classifyNoTransition"))
            Scenario.classifyNoTransition(world)
        else
            .{ .harness_deadlock = "vopr.scenario_deadlock" };
        switch (classification) {
            .clean_quiescence, .expected_blocked => return .stopped,
            .liveness_failure => |identity| {
                if (identity.len == 0) return error.EmptyLivenessFailureIdentity;
                try result.addFailure(.{
                    .index = transition_index.*,
                    .class = .liveness,
                    .property_id = null,
                    .identity = identity,
                    .fingerprint = ids.derive("failure.liveness", ids.stable("failure", identity), Scenario.version),
                    .observation_digest = last_digest.*,
                });
                return .stopped;
            },
            .harness_deadlock => return error.ScenarioDeadlock,
        }
    }

    const occurrence = transition_index.*;
    const selected_id = try choice_source.choose(.{
        .site_id = ids.stable("choice", Scenario.name ++ ".transition"),
        .site_name = Scenario.name ++ ".transition",
        .occurrence = occurrence,
        .enabled = enabled.items.items,
    });
    const enabled_ids = try allocator.alloc(ids.StableId, enabled.items.items.len);
    defer allocator.free(enabled_ids);
    var selected: ?transition.Transition = null;
    for (enabled.items.items, 0..) |candidate, index| {
        enabled_ids[index] = candidate.id;
        if (candidate.id == selected_id) selected = candidate;
    }
    try result.addChoice(.{
        .site_id = ids.stable("choice", Scenario.name ++ ".transition"),
        .site_name = Scenario.name ++ ".transition",
        .occurrence = occurrence,
        .enabled_ids = enabled_ids,
        .selected_id = selected_id,
    });

    transition_index.* += 1;
    const selected_transition = selected orelse return error.ChoiceSourceSelectedDisabledAlternative;
    try scheduler.verifyStillEnabled(Scenario, world, allocator, enabled.items.items, selected_transition);
    var events = event.Sink{};
    defer events.deinit(allocator);
    var transition_outcome: outcome.TransitionOutcome = try Scenario.execute(world, selected_transition, &events, allocator);
    try transition_outcome.validate();
    try result.addTransition(.{
        .index = transition_index.*,
        .id = selected_transition.id,
        .name = selected_transition.name,
        .kind = selected_transition.kind,
        .actor_id = selected_transition.actor_id,
        .resource_id = selected_transition.resource_id,
        .parameter = selected_transition.parameter,
        .payload_digest = selected_transition.payloadDigest(),
    });
    var has_explicit_fault_lifecycle = false;
    for (events.events.items) |emitted| {
        const phase: ?trace.FaultPhase = switch (emitted.kind) {
            .fault_started => .start,
            .fault_stopped => .end,
            else => null,
        };
        if (phase) |fault_phase| {
            has_explicit_fault_lifecycle = true;
            try result.addFault(.{
                .index = transition_index.*,
                .id = emitted.resource_id orelse return error.FaultLifecycleEventMissingFaultId,
                .name = emitted.name,
                .phase = fault_phase,
            });
        }
    }
    if (selected_transition.kind == .fault and !has_explicit_fault_lifecycle) {
        try result.addFault(.{
            .index = transition_index.*,
            .id = selected_transition.id,
            .name = selected_transition.name,
            .phase = selected_transition.fault_phase orelse .pulse,
        });
    }
    for (events.events.items, 0..) |emitted, ordinal| {
        const record: trace.EventRecord = .{
            .index = transition_index.*,
            .ordinal = @intCast(ordinal),
            .id = emitted.id,
            .name = emitted.name,
            .kind = emitted.kind,
            .actor_id = emitted.actor_id,
            .resource_id = emitted.resource_id,
            .payload_digest = emitted.payload_digest,
        };
        try result.addEvent(record);
        if (observer) |live| live.publish(record);
        if (recorder) |flight| try flight.recordEvent(transition_index.*, @intCast(ordinal), emitted);
    }
    last_digest.* = try recordObservation(Scenario, allocator, world, result, transition_index.*);
    const prior_failure_count = tracker.failureCount();
    try evaluateProperties(Scenario, allocator, world, result, tracker, transition_index.*);
    if (@hasDecl(Scenario, "quiescent") and Scenario.quiescent(world)) tracker.beginQuiescence(transition_index.*);
    if (!@hasDecl(Scenario, "finalize") and Scenario.done(world)) tracker.finish(transition_index.*);
    recordHealth(Scenario, world, transition_index.*, health_recorder);
    if (tracker.failureCount() > prior_failure_count) {
        for (Scenario.properties, tracker.statuses) |declaration, status| {
            if (status.first_failure_transition == transition_index.*) {
                transition_outcome = outcome.TransitionOutcome.propertyViolation(
                    declaration.id,
                    declaration.name,
                    last_digest.*,
                );
                break;
            }
        }
    }
    const outcome_event = transition_outcome.asEvent();
    const outcome_record: trace.EventRecord = .{
        .index = transition_index.*,
        .ordinal = @intCast(events.events.items.len),
        .id = outcome_event.id,
        .name = outcome_event.name,
        .kind = outcome_event.kind,
        .actor_id = selected_transition.actor_id,
        .resource_id = selected_transition.resource_id,
        .payload_digest = outcome_event.payload_digest,
    };
    try result.addEvent(outcome_record);
    if (observer) |live| live.publish(outcome_record);
    if (recorder) |flight| {
        var detailed_outcome = outcome_event;
        detailed_outcome.details = transition_outcome.identity;
        try flight.recordEvent(transition_index.*, @intCast(events.events.items.len), detailed_outcome);
    }
    if (transition_outcome.failureClass()) |failure_class| {
        // Property failures are materialized from the property tracker at the
        // end so their first-failure identity remains the single authority.
        if (failure_class != .property) try result.addFailure(.{
            .index = transition_index.*,
            .class = failure_class,
            .property_id = transition_outcome.property_id,
            .identity = transition_outcome.identity,
            .fingerprint = transition_outcome.fingerprint(),
            .observation_digest = last_digest.*,
        });
    }
    return .executed;
}

fn recordHealth(comptime Scenario: type, world: *Scenario.World, transition_index: u64, recorder: *health.Recorder) void {
    const phase: health.Phase = if (comptime @hasDecl(Scenario, "validationPhase"))
        Scenario.validationPhase(world)
    else if (Scenario.done(world))
        .final
    else if (comptime @hasDecl(Scenario, "quiescent"))
        if (Scenario.quiescent(world)) .recovery else .continuous
    else
        .continuous;
    const snapshot_value: health.Snapshot = if (comptime @hasDecl(Scenario, "healthSnapshot"))
        Scenario.healthSnapshot(world)
    else
        .{
            .progress_expected = !Scenario.done(world),
            .progress_units = transition_index,
            .cleanup_complete = if (Scenario.done(world)) true else null,
        };
    recorder.record(phase, snapshot_value);
}

fn initTrace(comptime Scenario: type, allocator: std.mem.Allocator, config: Config) !trace.Trace {
    return trace.Trace.init(allocator, .{
        .system = config.system,
        .scenario = Scenario.name,
        .scenario_version = Scenario.version,
        .source_revision = config.source_revision,
        .target = config.target,
        .optimize = config.optimize,
    }, .{
        .seed = config.seed,
        .transition_budget = config.transition_budget,
        .resource_budget = config.resource_budget,
        .fixture_hashes = config.fixture_hashes,
        .feature_flags = config.feature_flags,
        .backend_ids = config.backend_ids,
        .scenario_parameters = config.scenario_parameters,
    });
}

fn initWorld(comptime Scenario: type, allocator: std.mem.Allocator, context: ?*anyopaque) !Scenario.World {
    if (comptime @hasDecl(Scenario, "initWithContext")) return Scenario.initWithContext(allocator, context);
    if (context != null) return error.ScenarioDoesNotAcceptContext;
    return Scenario.init(allocator);
}

fn initTraceFromArtifact(allocator: std.mem.Allocator, artifact: *const trace.Trace) !trace.Trace {
    return trace.Trace.init(allocator, artifact.header, artifact.config);
}

fn configFromTrace(artifact: *const trace.Trace) Config {
    return .{
        .system = artifact.header.system,
        .seed = artifact.config.seed,
        .transition_budget = artifact.config.transition_budget,
        .resource_budget = artifact.config.resource_budget,
        .fixture_hashes = artifact.config.fixture_hashes,
        .feature_flags = artifact.config.feature_flags,
        .backend_ids = artifact.config.backend_ids,
        .scenario_parameters = artifact.config.scenario_parameters,
        .source_revision = artifact.header.source_revision,
        .target = artifact.header.target,
        .optimize = artifact.header.optimize,
    };
}

fn validateCompatibility(comptime Scenario: type, artifact: *const trace.Trace) !void {
    if (!std.mem.eql(u8, artifact.header.scenario, Scenario.name)) return error.IncompatibleScenario;
    if (artifact.header.scenario_version != Scenario.version) return error.IncompatibleScenarioVersion;
}

fn copyPrefix(destination: *trace.Trace, source: *const trace.Trace, prefix_len: usize) !void {
    for (source.choices.items[0..prefix_len]) |record| try destination.addChoice(record);
    for (source.transitions.items[0..prefix_len]) |record| try destination.addTransition(record);
    for (source.faults.items) |record| {
        if (record.index > prefix_len) break;
        try destination.addFault(record);
    }
    for (source.events.items) |record| {
        if (record.index > prefix_len) break;
        try destination.addEvent(record);
    }
    for (source.observations.items[0 .. prefix_len + 1]) |record| try destination.addObservation(record);
    for (source.properties.items) |record| {
        if (record.index > prefix_len) break;
        try destination.addProperty(record);
    }
}

fn recordObservation(
    comptime Scenario: type,
    allocator: std.mem.Allocator,
    world: *Scenario.World,
    result: *trace.Trace,
    index: u64,
) !u64 {
    var builder = observation.Builder{};
    defer builder.deinit(allocator);
    try Scenario.observe(world, &builder, allocator);
    try builder.canonicalize();
    const digest = builder.digest();
    try result.addObservation(.{ .index = index, .digest = digest, .features = builder.features.items });
    return digest;
}

fn evaluateProperties(
    comptime Scenario: type,
    allocator: std.mem.Allocator,
    world: *Scenario.World,
    result: *trace.Trace,
    tracker: *property.Tracker,
    index: u64,
) !void {
    var sink = property.Sink{};
    defer sink.deinit(allocator);
    try Scenario.evaluate(world, &sink, allocator);
    try appendEvaluations(Scenario, &sink, result, tracker, index);
}

fn appendEvaluations(comptime Scenario: type, sink: *property.Sink, result: *trace.Trace, tracker: *property.Tracker, index: u64) !void {
    try sink.canonicalize();
    for (sink.evaluations.items) |evaluation| {
        const declaration = declarationFor(Scenario.properties, evaluation.property_id) orelse return error.UnknownPropertyId;
        try tracker.record(index, evaluation);
        try result.addProperty(.{
            .index = index,
            .property_id = evaluation.property_id,
            .name = declaration.name,
            .kind = declaration.kind,
            .condition = evaluation.condition,
            .details = evaluation.details,
        });
    }
}

fn declarationFor(declarations: []const property.Declaration, id: ids.StableId) ?property.Declaration {
    for (declarations) |declaration| if (declaration.id == id) return declaration;
    return null;
}

test "flight recording retains verbose details without changing replay truth" {
    const Scenario = struct {
        pub const name: []const u8 = "runner-flight-recorder";
        pub const version: u32 = 1;
        const step_id = ids.stable("transition", "runner-flight.step");
        pub const properties = &[_]property.Declaration{};
        pub const World = struct { done: bool = false };
        pub fn init(_: std.mem.Allocator) !World {
            return .{};
        }
        pub fn deinit(_: *World, _: std.mem.Allocator) void {}
        pub fn enumerate(world: *World, list: *transition.List, allocator_: std.mem.Allocator) !void {
            if (!world.done) try list.append(allocator_, .{ .id = step_id, .name = "runner-flight.step", .kind = .workload });
        }
        pub fn execute(world: *World, _: transition.Transition, events: *event.Sink, allocator_: std.mem.Allocator) !outcome.TransitionOutcome {
            world.done = true;
            try events.emitDetailed(allocator_, event.Event.named(.domain, "runner-flight.detail", 17), "verbose-only-secret");
            return .applied();
        }
        pub fn observe(world: *World, builder: *observation.Builder, allocator_: std.mem.Allocator) !void {
            try builder.addNamed(allocator_, "runner-flight.done", @intFromBool(world.done));
        }
        pub fn evaluate(_: *World, _: *property.Sink, _: std.mem.Allocator) !void {}
        pub fn done(world: *World) bool {
            return world.done;
        }
    };

    var recorder = try flight_recorder.Recorder.init(std.testing.allocator, 4);
    defer recorder.deinit();
    var recorded_source = choice.Seeded.init(9);
    var recorded = try run(Scenario, std.testing.allocator, recorded_source.source(), .{
        .seed = 9,
        .transition_budget = 1,
        .flight_recorder = &recorder,
    });
    defer recorded.deinit();
    var plain_source = choice.Seeded.init(9);
    var plain = try run(Scenario, std.testing.allocator, plain_source.source(), .{ .seed = 9, .transition_budget = 1 });
    defer plain.deinit();
    const recorded_bytes = try recorded.renderAlloc(std.testing.allocator);
    defer std.testing.allocator.free(recorded_bytes);
    const plain_bytes = try plain.renderAlloc(std.testing.allocator);
    defer std.testing.allocator.free(plain_bytes);
    try std.testing.expectEqualSlices(u8, plain_bytes, recorded_bytes);
    try std.testing.expect(std.mem.indexOf(u8, recorded_bytes, "verbose-only-secret") == null);

    var snapshot_value = try recorder.materialize(std.testing.allocator, .failure);
    defer snapshot_value.deinit();
    try std.testing.expectEqual(@as(usize, 2), snapshot_value.records.len);
    try std.testing.expectEqualStrings("verbose-only-secret", snapshot_value.records[0].details);
    var replayed = try @import("replay.zig").exact(Scenario, std.testing.allocator, &recorded);
    replayed.deinit();
}

test "runner publishes canonical events without changing replay truth" {
    const Scenario = struct {
        pub const name: []const u8 = "runner-live-events";
        pub const version: u32 = 1;
        const step_id = ids.stable("transition", name ++ ".step");
        pub const properties = &[_]property.Declaration{};
        pub const World = struct { done: bool = false };
        pub fn init(_: std.mem.Allocator) !World {
            return .{};
        }
        pub fn deinit(_: *World, _: std.mem.Allocator) void {}
        pub fn enumerate(world: *World, list: *transition.List, allocator_: std.mem.Allocator) !void {
            if (!world.done) try list.append(allocator_, .{ .id = step_id, .name = name ++ ".step", .kind = .workload });
        }
        pub fn execute(world: *World, _: transition.Transition, events: *event.Sink, allocator_: std.mem.Allocator) !outcome.TransitionOutcome {
            world.done = true;
            try events.emitNamed(allocator_, .domain, name ++ ".domain", 11);
            return .applied();
        }
        pub fn observe(world: *World, builder: *observation.Builder, allocator_: std.mem.Allocator) !void {
            try builder.addNamed(allocator_, name ++ ".done", @intFromBool(world.done));
        }
        pub fn evaluate(_: *World, _: *property.Sink, _: std.mem.Allocator) !void {}
        pub fn done(world: *World) bool {
            return world.done;
        }
    };
    const Capture = struct {
        const Record = struct { index: u64, ordinal: u64, id: u64, name_digest: u64 };
        records: [4]Record = undefined,
        count: usize = 0,
        fn publish(ptr: *anyopaque, record: trace.EventRecord) void {
            const self: *@This() = @ptrCast(@alignCast(ptr));
            self.records[self.count] = .{
                .index = record.index,
                .ordinal = record.ordinal,
                .id = record.id,
                .name_digest = ids.digest(record.name),
            };
            self.count += 1;
        }
    };
    var capture: Capture = .{};
    var source = choice.Seeded.init(10);
    var recorded = try run(Scenario, std.testing.allocator, source.source(), .{
        .seed = 10,
        .transition_budget = 1,
        .event_observer = .{ .ptr = &capture, .publish_fn = Capture.publish },
    });
    defer recorded.deinit();
    try std.testing.expectEqual(recorded.events.items.len, capture.count);
    for (recorded.events.items, capture.records[0..capture.count]) |expected, actual| {
        try std.testing.expectEqual(expected.index, actual.index);
        try std.testing.expectEqual(expected.ordinal, actual.ordinal);
        try std.testing.expectEqual(expected.id, actual.id);
        try std.testing.expectEqual(ids.digest(expected.name), actual.name_digest);
    }
}

test "bounded NDJSON stream backpressure is diagnostic-only at the runner boundary" {
    const Scenario = struct {
        pub const name: []const u8 = "runner-bounded-live-events";
        pub const version: u32 = 1;
        const step_id = ids.stable("transition", name ++ ".step");
        pub const properties = &[_]property.Declaration{};
        pub const World = struct { done: bool = false };
        pub fn init(_: std.mem.Allocator) !World {
            return .{};
        }
        pub fn deinit(_: *World, _: std.mem.Allocator) void {}
        pub fn enumerate(world: *World, list: *transition.List, allocator_: std.mem.Allocator) !void {
            if (!world.done) try list.append(allocator_, .{ .id = step_id, .name = name ++ ".step", .kind = .workload });
        }
        pub fn execute(world: *World, _: transition.Transition, events: *event.Sink, allocator_: std.mem.Allocator) !outcome.TransitionOutcome {
            world.done = true;
            try events.emitNamed(allocator_, .domain, name ++ ".domain", 11);
            return .applied();
        }
        pub fn observe(world: *World, builder: *observation.Builder, allocator_: std.mem.Allocator) !void {
            try builder.addNamed(allocator_, name ++ ".done", @intFromBool(world.done));
        }
        pub fn evaluate(_: *World, _: *property.Sink, _: std.mem.Allocator) !void {}
        pub fn done(world: *World) bool {
            return world.done;
        }
    };
    const Stream = event_stream.BufferedNdjson(512);
    var slots: [1]Stream.Slot = undefined;
    var stream = try Stream.init("runner-bounded-live-events-history", &slots);
    var streamed_source = choice.Seeded.init(11);
    var streamed = try run(Scenario, std.testing.allocator, streamed_source.source(), .{
        .seed = 11,
        .transition_budget = 1,
        .event_observer = stream.observer(),
    });
    defer streamed.deinit();
    var plain_source = choice.Seeded.init(11);
    var plain = try run(Scenario, std.testing.allocator, plain_source.source(), .{
        .seed = 11,
        .transition_budget = 1,
    });
    defer plain.deinit();

    const streamed_bytes = try streamed.renderAlloc(std.testing.allocator);
    defer std.testing.allocator.free(streamed_bytes);
    const plain_bytes = try plain.renderAlloc(std.testing.allocator);
    defer std.testing.allocator.free(plain_bytes);
    try std.testing.expectEqualSlices(u8, plain_bytes, streamed_bytes);
    const stream_stats = stream.stats();
    try std.testing.expectEqual(@as(u64, 1), stream_stats.enqueued);
    try std.testing.expectEqual(@as(u64, 1), stream_stats.dropped_full);
    try std.testing.expectEqual(@as(usize, 1), stream.pending());
}

test "runner automatically records phased health outside canonical replay bytes" {
    const Scenario = struct {
        pub const name: []const u8 = "runner-health-phases";
        pub const version: u32 = 1;
        const advance_id = ids.stable("transition", name ++ ".advance");
        pub const properties = &[_]property.Declaration{};
        pub const World = struct { step: u8 = 0 };
        pub fn init(_: std.mem.Allocator) !World {
            return .{};
        }
        pub fn deinit(_: *World, _: std.mem.Allocator) void {}
        pub fn enumerate(world: *World, list: *transition.List, allocator_: std.mem.Allocator) !void {
            if (world.step < 3) try list.append(allocator_, .{ .id = advance_id, .name = name ++ ".advance", .kind = .workload });
        }
        pub fn execute(world: *World, _: transition.Transition, _: *event.Sink, _: std.mem.Allocator) !outcome.TransitionOutcome {
            world.step += 1;
            return .applied();
        }
        pub fn observe(world: *World, builder: *observation.Builder, allocator_: std.mem.Allocator) !void {
            try builder.addNamed(allocator_, name ++ ".step", world.step);
        }
        pub fn evaluate(_: *World, _: *property.Sink, _: std.mem.Allocator) !void {}
        pub fn validationPhase(world: *World) health.Phase {
            return if (world.step == 3) .final else if (world.step >= 1) .recovery else .continuous;
        }
        pub fn healthSnapshot(world: *World) health.Snapshot {
            return .{
                .progress_expected = true,
                .progress_units = world.step,
                .active_tasks = 0,
                .open_descriptors = 0,
                .recovery_expected = world.step >= 1,
                .recovery_complete = world.step >= 2,
                .consistency_valid = world.step < 3 or world.step == 3,
                .cleanup_complete = world.step == 3,
            };
        }
        pub fn snapshotAlloc(world: *const World, allocator_: std.mem.Allocator) ![]u8 {
            const bytes = try allocator_.alloc(u8, 1);
            bytes[0] = world.step;
            return bytes;
        }
        pub fn restoreSnapshot(world: *World, bytes: []const u8, _: std.mem.Allocator) !void {
            if (bytes.len != 1) return error.InvalidHealthSnapshot;
            world.step = bytes[0];
        }
        pub fn done(world: *World) bool {
            return world.step == 3;
        }
    };

    var source = choice.Seeded.init(77);
    var artifact = try run(Scenario, std.testing.allocator, source.source(), .{ .transition_budget = 3 });
    defer artifact.deinit();
    const evidence = artifact.health_evidence.?;
    try std.testing.expectEqual(@as(u64, 4), evidence.samples);
    try std.testing.expectEqual(@as(u64, 1), evidence.continuous_samples);
    try std.testing.expectEqual(@as(u64, 2), evidence.recovery_samples);
    try std.testing.expectEqual(@as(u64, 1), evidence.final_samples);
    try std.testing.expect(evidence.recovery_complete);
    try std.testing.expect(evidence.final_snapshot.?.cleanup_complete.?);

    const encoded = try artifact.renderAlloc(std.testing.allocator);
    defer std.testing.allocator.free(encoded);
    var parsed = try trace.parseAlloc(std.testing.allocator, encoded);
    defer parsed.deinit();
    try std.testing.expect(parsed.health_evidence == null);

    var replayed = try @import("replay.zig").exact(Scenario, std.testing.allocator, &artifact);
    defer replayed.deinit();
    try std.testing.expectEqual(evidence.samples, replayed.health_evidence.?.samples);

    var checkpoint = try captureCheckpoint(Scenario, std.testing.allocator, &artifact, 2);
    defer checkpoint.deinit(std.testing.allocator);
    try std.testing.expectEqual(@as(u64, 3), checkpoint.health_recorder.?.evidence().samples);
    var suffix = choice.Replay{ .records = artifact.choices.items, .cursor = 2 };
    var resumed = try resumeFromCheckpoint(Scenario, std.testing.allocator, &artifact, checkpoint, suffix.source());
    defer resumed.deinit();
    try std.testing.expectEqualDeep(evidence, resumed.health_evidence.?);
}

test "budget cutoff retains liveness evidence and verifies cleanup before finishing properties" {
    const S = struct {
        pub const name: []const u8 = "finalization-test";
        pub const version: u32 = 1;
        pub const World = struct { owners: usize = 1 };
        pub const properties = &[_]property.Declaration{
            .{ .id = 1, .name = "cleanup", .kind = .always },
            .{ .id = 2, .name = "completed", .kind = .reachable },
        };
        pub fn init(_: std.mem.Allocator) !World {
            return .{};
        }
        pub fn deinit(world: *World, _: std.mem.Allocator) void {
            std.debug.assert(world.owners == 0);
        }
        pub fn enumerate(_: *World, list: *transition.List, alloc: std.mem.Allocator) !void {
            try list.append(alloc, .{ .id = 1, .name = "wait", .kind = .workload });
        }
        pub fn execute(_: *World, _: transition.Transition, _: *event.Sink, _: std.mem.Allocator) !outcome.TransitionOutcome {
            return outcome.TransitionOutcome.applied();
        }
        pub fn observe(world: *World, builder: *observation.Builder, alloc: std.mem.Allocator) !void {
            try builder.addNamed(alloc, "owners", @intCast(world.owners));
        }
        pub fn evaluate(_: *World, sink: *property.Sink, alloc: std.mem.Allocator) !void {
            try sink.check(alloc, 2, false);
        }
        pub fn done(_: *World) bool {
            return false;
        }
        pub fn budgetFailure(_: *World) []const u8 {
            return "transition-budget-exhausted";
        }
        pub fn finalize(world: *World, sink: *property.Sink, alloc: std.mem.Allocator) !void {
            world.owners = 0;
            try sink.check(alloc, 1, world.owners == 0);
        }
    };
    var choices = choice.Seeded.init(1);
    var artifact = try run(S, std.testing.allocator, choices.source(), .{ .transition_budget = 2 });
    defer artifact.deinit();
    try std.testing.expectEqual(@as(usize, 2), artifact.failures.items.len);
    var saw_liveness = false;
    for (artifact.failures.items) |failure| {
        saw_liveness = saw_liveness or failure.class == .liveness;
        try std.testing.expect(failure.property_id != 1);
    }
    try std.testing.expect(saw_liveness);
    var replay_choices = choice.Replay{ .records = artifact.choices.items };
    var replayed = try run(S, std.testing.allocator, replay_choices.source(), .{ .transition_budget = 2 });
    defer replayed.deinit();
    const original = try artifact.renderAlloc(std.testing.allocator);
    defer std.testing.allocator.free(original);
    const replay_bytes = try replayed.renderAlloc(std.testing.allocator);
    defer std.testing.allocator.free(replay_bytes);
    try std.testing.expectEqualStrings(original, replay_bytes);
}
