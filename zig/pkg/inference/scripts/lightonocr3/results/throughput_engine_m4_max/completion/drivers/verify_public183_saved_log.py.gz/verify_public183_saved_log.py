from pathlib import Path
import argparse,hashlib,importlib.util,json,re,sys
from unittest.mock import patch
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';w=o/'wolfspider_shared_frame';primary=json.loads((w/'paired184_4b_warmed_comparison_audit.json').read_text());dest=w/Path(primary['native']['report']).parent;report=json.loads((dest/'report.json').read_text());raw=(dest/report['results'][0]['log']).read_text();script=r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';sys.path.insert(0,str(script.parent));spec=importlib.util.spec_from_file_location('public183_saved_parser',script);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);settings=dict(report['settings']);settings.update(native_test=Path('/usr/bin/false'),images=[r/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png',script.parent/'corpus/receipt.png',script.parent/'corpus/shipping.png'],packed_shared_frame=True,require_packed_shared_frame=True,reference_report=w/'vllm_4b_content_oracle/report.json');args=argparse.Namespace(**settings);audit=o/'engine183_public_saved_log_parser_audit.json';assert not audit.exists();records=[]
for name,text,expected in [('valid',raw,'ok'),('wrong_frame_count',raw.replace('packed_shared_frame=1 packed_forward_submissions=1','packed_shared_frame=1 packed_forward_submissions=2',1),'missing_single_frame_packed_forwards'),('missing_frame_counters',re.sub(r'^LIGHTONOCR3 packed_shared_frame=[^\n]*\n','',raw,flags=re.M),'missing_single_frame_packed_forwards')]:
 out=v/('public183_parse_'+name);out.mkdir();calls=[]
 class SavedProcess:
  def __init__(self,command,**kwargs):
   calls.append(command);kwargs['stdout'].write(text);kwargs['stdout'].flush();self.returncode=0
  def wait(self,timeout=None):return 0
 with patch.object(module.subprocess,'Popen',SavedProcess):result=module.run(args,v/'ocr-models/lighton4b','lighton4b','batch',64,out)
 assert len(calls)==1 and result['status']==expected,(name,result['status'])
 if name=='valid':
  assert result['packed_shared_frame_steps_including_warmup']==763 and result['packed_shared_frame_topology_mismatches_including_warmup']==0
  assert [x['packed_shared_frame_steps']for x in result['policy_rounds']]==[254,254,255]
 records.append(dict(case=name,status=result['status'],shared_steps=result.get('packed_shared_frame_steps_including_warmup'),mismatches=result.get('packed_shared_frame_topology_mismatches_including_warmup')))
audit.write_text(json.dumps(dict(status='real_saved_log_and_corruption_rejection_pass',primary_throughput_eligible=False,scope='Public updated parser reads the completed actual184native log offline. Subprocess.Popen is replaced solely to supply saved output; no native binary or model runs. Original reports and speed data stay unchanged. Valid real763mixed forwards pass; a changed decoder-frame count and missing counters both fail closed.',parser_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),original_log_sha256=hashlib.sha256(raw.encode()).hexdigest(),driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=records),indent=2)+'\n');print('Public parser valid763frames and both corruption rejection cases passed offline')
