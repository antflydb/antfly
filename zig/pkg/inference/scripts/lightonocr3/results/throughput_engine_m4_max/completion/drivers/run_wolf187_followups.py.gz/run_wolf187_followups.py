from pathlib import Path
import datetime,json,os,psutil,subprocess,sys,time
r=Path('/Users/ajroetker/antfly/.worktrees/perf-lightonocr3-shared-frame-wolfspider');os.chdir(r);v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/wolfspider_shared_frame';a=o/'wolf187_followups_audit.json';assert not a.exists();candidates=[]
for p in psutil.process_iter(['cmdline']):
 try:
  if any(x.endswith('/run_wolf184_primary.py')for x in p.info['cmdline']or[])and Path(p.cwd())==r:candidates.append(p)
 except psutil.Error:pass
assert len(candidates)==1;parent=candidates[0];identity=dict(pid=parent.pid,create_time=parent.create_time(),cwd=parent.cwd(),cmdline=parent.cmdline());d=dict(status='waiting_for_completed184_primary',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),primary_parent=identity,runs=[])
def save():a.write_text(json.dumps(d,indent=2)+'\n')
save()
while True:
 try:x=json.loads((o/'paired184_4b_warmed_comparison_audit.json').read_text())
 except json.JSONDecodeError:time.sleep(.1);continue
 if x['status'] in ['repeated_native_win','native_behind','failed_or_excluded']:break
 assert parent.is_running()and parent.create_time()==identity['create_time'];time.sleep(15)
while parent.is_running()and parent.status()!=psutil.STATUS_ZOMBIE and parent.create_time()==identity['create_time']:time.sleep(.2)
if not x.get('promotable'):
 d.update(status='candidate_not_promoted_followups_held_for_selection',primary_status=x['status']);save();print('187 held: select final runtime before followup benchmarks',flush=True);sys.exit(0)
for name,script,report in [('185','run_wolf185_08_primary.py','paired185_08_warmed_comparison_audit.json'),('186','run_wolf186_florence_primary.py','paired186_florence_comparison_audit.json')]:
 d['status']='running_'+name;save();log=Path('/private/tmp')/('ocr-wolf'+name+'-primary-parent.txt');assert not log.exists();print('START187 followup',name,flush=True)
 with log.open('w')as out:p=subprocess.run([sys.executable,str(v/script)],cwd=r,stdout=out,stderr=subprocess.STDOUT)
 result=json.loads((o/report).read_text())if(o/report).exists()else{};d['runs'].append(dict(name=name,exit_code=p.returncode,report=report,status=result.get('status')));save()
 if p.returncode:d['status']='failed_followup_'+name;save();sys.exit(p.returncode)
d['status']='followups_complete';save();print('DONE187',[(x['name'],x['status'])for x in d['runs']],flush=True)
