from pathlib import Path
import datetime,gzip,hashlib,json,re
r=Path.cwd();o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';w=o/'wolfspider_shared_frame';old=o/'wolfspider';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();remote='/Users/ajroetker/antfly/.worktrees/'
def local_report(path):
 if not path.startswith('/'):return w/path
 for prefix,dest in [(remote+'perf-lightonocr3-shared-frame-wolfspider/zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/wolfspider_shared_frame/',w),(remote+'perf-lightonocr3-wolfspider/zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/wolfspider/',old)]:
  if path.startswith(prefix):return dest/path[len(prefix):]
 raise AssertionError(path)
def checked(entry):
 p=local_report(entry['report']);assert sha(p)==entry['report_sha256'];return p,json.loads(p.read_text())
selected={};cache_checks=[]
for tag,name in [('lighton4b','paired184_4b_warmed_comparison_audit.json'),('lighton08','paired188_08_warmed_comparison_audit.json')]:
 a=json.loads((w/name).read_text());assert a['status']=='repeated_native_win'and a['promotable'];np,nd=checked(a['native']);native=nd['results'][0];assert native['cross_runtime_full_fixture_string_identity']and native['serial_reference_parity'];assert all(x['completed']==256 and not x['admission_pressures']for x in native['policy_rounds']);assert all(x['decoder_frame_submissions_per_shared_forward']==[1]for x in a['actual_shared_frames'])
 refs=[]
 for key in ['opening_reference','closing_reference']:
  rp,report=checked(a[key]);assert report['status']=='ok'and report['automatic_cache_floor_admission']['admitted']and report['results'][0]['completed']==256 and len(report['saturation_warmups'][0]['outputs'])==256
  blocks=list(map(int,re.findall(r'Hybrid shared cache:\s*(\d+)\s*blocks',(rp.parent/'server.txt').read_text())));assert blocks and min(blocks)>=320;cache_checks.append(dict(report=str(rp.relative_to(o)),all_observed_auto_blocks=blocks));refs.append([x['text']for x in report['references']])
 assert refs[0]==refs[1]==[x['text']for x in native['references']];assert all(x['ratio']>1 for x in a['comparisons']);selected[tag]=dict(audit=str((w/name).relative_to(o)),audit_sha256=sha(w/name),comparisons=a['comparisons'],actual_shared_frames=a['actual_shared_frames'],native_report_sha256=sha(np))
f=w/'paired186_florence_comparison_audit.json';a=json.loads(f.read_text());assert a['status']in ['small_repeated_proxy_lead','clear_repeated_proxy_win'];assert all(c['native_to_proxy_ratio']>1 and c['cross_runtime_whitespace_normalized_content']and c['all_128_native_pages_equal_native_serial']for c in a['comparisons'])
for c in a['comparisons']:
 for path_key,sha_key in [('native_report','native_report_sha256'),('proxy_report','proxy_report_sha256')]:assert sha(w/c[path_key])==c[sha_key]
selected['florence']=dict(audit=str(f.relative_to(o)),audit_sha256=sha(f),comparisons=a['comparisons'],scope='MLX-VLM serial proxy only; publisher nativeQ4_K/F16encoder/no-repeat3 vs originalFP16/defaultgreedy. Fullnative strings exact; crossruntimecontent whitespace-normalized. InstalledvLLMMetal has noFlorenceadapter.')
archives=[]
for folder,mf in [(o/'drivers','drivers_manifest.json'),(o/'qualification','logs_manifest.json'),(w/'drivers','manifest.json'),(w/'qualification','manifest.json')]:
 index=json.loads((folder/mf).read_text())
 for name,entry in index.items():
  raw=gzip.decompress((folder/name).read_bytes());assert len(raw)==entry['raw_bytes']and hashlib.sha256(raw).hexdigest()==entry['raw_sha256'],name
 archives.append(dict(folder=str(folder.relative_to(o)),entries=len(index),manifest_sha256=sha(folder/mf)))
qual=json.loads((w/'wolf184c_qualification_audit.json').read_text());assert qual['status']=='full_gpu335_and_all64_exact_one_decoder_frame_pass';assert json.loads((w/'wolf184b_qualification_audit.json').read_text())['runs'][0]['exit_code']==0
p=o/'engine190_final_comparison_validation.json';assert not p.exists();p.write_text(json.dumps(dict(status='all_selected_profiles_repeated_win_and_archives_verified',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='BothLightOnsizes beat actualvLLM in both warmed orders on samewolfspiderM4Max32GPUcores36GiB; Florence beats onlytheexplicitMLXproxy. Allselected native/reference report hashes and completeLightOnfixturestrings checked. Complete serverlogs retain automaticcachecapacity>=320, notjust startup. Native256warm excluded+two256timed; API256warm+256timed each. Florence128warm+two128timed vs128warm+128timed eachproxy. Originalcaps/reserves preserved. FullGPU335/6 and all64C64model/frame proof pass; source180C/Metal/header inputs unchangedfromfresh158C24.3syntheticfixtures establish consistency, not broadaccuracy.',selected=selected,complete_log_cache_checks=cache_checks,archives=archives),indent=2)+'\n');print(json.dumps({k:v.get('comparisons')for k,v in selected.items()},indent=2));print('Allselected reports, complete cache logs and4archive manifests verified')
