from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess

r = Path('/Users/ajroetker/antfly/.worktrees/perf-lightonocr3-wolfspider')
os.chdir(r)
v = r / '.venv-lighton-vllm-metal'
o = r / 'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/wolfspider'
origin = v / 'wolf170_origin'
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024**2), b''):
            h.update(chunk)
    return h.hexdigest()
assert json.loads((o / 'wolf170b_replay_audit.json').read_text())['status'] == 'C24_and_333_native_tests_replayed_pass'
freeze = json.loads((v / 'engine158-freeze.json').read_text())
assert all(sha(r / name) == expected for name, expected in freeze.items())
models = json.loads((origin / 'model_inputs.json').read_text())
for model, files in models.items():
    print('WOLF171 verify', model, flush=True)
    for name, expected in files.items():
        path = v / 'ocr-models' / model / name
        assert path.stat().st_size == expected['bytes'] and sha(path) == expected['sha256'], path
identity = o / 'wolf170_model_identity_audit.json'
identity.write_text(json.dumps({'status': 'all_models_byte_identical', 'scope': 'Transferred original pinned BF16 LightOn0.8B/4B checkpoint files, including full safetensors hashes. No model conversion. Same32GPUcoreM4Max/36GiBhardware class; independent paired runs on wolfspider.', 'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'inputs': models}, indent=2) + '\n')
manifest = json.loads((origin / 'engine158_build_manifest.json').read_text())
manifest['origin_binary_path'] = manifest['binary_path']
manifest['origin_built_binary_path'] = manifest['built_binary_path']
manifest['binary_path'] = str(v / 'qualified-binaries/engine158-test')
manifest['binary_lifetime'] = 'Byte-identical qualified local executable copied to wolfspider; C24 and333native-tests replay passed on this GPU. No recompilation claimed.'
manifest['relocation'] = {'destination_host': 'wolfspider', 'source_files_verified': len(freeze), 'source_inputs_identical': True, 'replay_audit_sha256': sha(o / 'wolf170b_replay_audit.json')}
assert sha(manifest['binary_path']) == manifest['binary_sha256']
(o / 'engine158_build_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
old_oracle = origin / 'content_oracle/report.json'
old = json.loads(old_oracle.read_text())
oracle_dir = o / 'vllm_4b_content_oracle'
oracle_dir.mkdir(exist_ok=True)
(oracle_dir / 'report.json').write_text(json.dumps({'reference_kind': 'text_only', 'performance_evidence': False, 'source_report_sha256': sha(old_oracle), 'scope': 'Historical exact fixture strings only. No speed numbers retained or reused. Fresh actual vLLM is required for throughput comparisons.', 'images': old['images'], 'references': old['references']}, indent=2) + '\n')
s = (v / 'run_engine158_budget_policies.py').read_text()
assert "out=scripts/'results/throughput_engine_m4_max';" in s
s = s.replace("out=scripts/'results/throughput_engine_m4_max';", "out=scripts/'results/throughput_engine_m4_max/wolfspider';")
(v / 'run_wolf171_budget_policies.py').write_text(s)
s = (v / 'run_engine158_short161_screen.py').read_text()
s = s.replace("o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';", "o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/wolfspider';")
s = s.replace('short161', 'wolf171').replace('START161', 'START171').replace('DONE161', 'DONE171').replace('WAIT161', 'WAIT171')
s = s.replace("assert json.loads((o/'engine158_remaining_short160_audit.json').read_text())['status']=='screen_complete'", "assert json.loads((o/'wolf170b_replay_audit.json').read_text())['status']=='C24_and_333_native_tests_replayed_pass';assert json.loads((o/'wolf170_model_identity_audit.json').read_text())['status']=='all_models_byte_identical'")
s = s.replace('run_engine158_budget_policies.py', 'run_wolf171_budget_policies.py').replace("OCR_REFERENCE_LABEL='_primary_reference93_r0_c64_w256_r256_ctx1024'", "OCR_REFERENCE_LABEL='_content_oracle'")
s = s.replace('Independent source1584B configuration screen', 'Independent wolfspider source1584B configuration screen; all controls and candidates execute on wolfspider32GPUcoreM4Max36GiB, no local161rates reused')
s = s.replace('Fresh132API onlycontentoracle.', 'Historical132API strings only via explicitlytext-only oracle; no reference speed data reused.')
(v / 'run_wolf171_screen.py').write_text(s)
s = (v / 'run_engine158_primary162.py').read_text()
s = s.replace("o=s/'results/throughput_engine_m4_max';", "o=s/'results/throughput_engine_m4_max/wolfspider';")
s = s.replace('short161', 'wolf171').replace('primary162', 'primary172').replace('paired162', 'paired172').replace('reference162', 'reference172').replace('WAIT162', 'WAIT172').replace('START162', 'START172').replace('DONE162', 'DONE172').replace('PRIMARY162', 'PRIMARY172')
s = s.replace('run_engine158_budget_policies.py', 'run_wolf171_budget_policies.py')
s = s.replace("selected=max(candidates,key=lambda x:x['pages_per_second']);assert selected['pages_per_second']>max(controls),'No configuration beat both native controls; do not launch primary'", "best=max(candidates,key=lambda x:x['pages_per_second']);selected=best if best['pages_per_second']>max(controls)else next(x for x in screen['runs']if x['profile']['name']=='whole0')")
s = s.replace("assert sample['prepared_prefill_chunk_rows']==selected_chunk and sample['packed_prefill_pages']==sample['packed_prefill_starts']==256 and sample['packed_prefill_chunks']>256", "assert sample['prepared_prefill_chunk_rows']==selected_chunk and sample['packed_prefill_pages']==sample['packed_prefill_starts']==256\n  assert (sample['packed_prefill_chunks']>256)==(selected_chunk>0)")
s = s.replace("assert sample['short_prefill_core_dispatches']==sample['packed_prefill_chunks']*24 and sample['short_direct_attention_dispatches']>0", "if selected_chunk:assert sample['short_prefill_core_dispatches']==sample['packed_prefill_chunks']*24 and sample['short_direct_attention_dispatches']>0\n  else:assert sample['short_prefill_core_dispatches']==sample['short_direct_attention_dispatches']==0")
s = s.replace('Independent warmedscreen157 fixes source158 chunk configuration', 'Independent wolfspider warmedscreen171 fixes source158 configuration')
s = s.replace('Completed independent161screen fixed highest native timedrate that beat both native controls. No tuning during actualvLLM pairedcomparison.', 'Completed independentwolf171screen: choose a chunk setting only if it beat both controls; otherwise retain the existing whole-prefix configuration. Fresh actualvLLM comparison is independent of selection; no tuning during paired runs.')
(v / 'run_wolf172_primary.py').write_text(s)
for name in ['run_wolf171_budget_policies.py', 'run_wolf171_screen.py', 'run_wolf172_primary.py']:
    compile((v / name).read_text(), str(v / name), 'exec')
(o / 'wolf171_setup_audit.json').write_text(json.dumps({'status': 'ready_for_native_screen', 'scope': 'Separate wolfspider native screening and fresh actual vLLM paired comparison. All throughput data stay on one host; historical local report is text-only. Original limits/reserves/cache-floor retained. Source48files and model assets match; native/C binaries are byte-identical with replays passed.', 'driver_sha256': sha(Path(__file__)), 'private_drivers': {name: sha(v / name) for name in ['run_wolf171_budget_policies.py', 'run_wolf171_screen.py', 'run_wolf172_primary.py']}, 'model_identity_audit_sha256': sha(identity)}, indent=2) + '\n')
print('WOLF171 setup ready', flush=True)
