from pathlib import Path
import gzip,hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';base=o/'completion';base.mkdir(exist_ok=True)
def archive(folder,paths):
 dest=base/folder;dest.mkdir();index={}
 for p in sorted(set(paths)):
  if not p.exists():continue
  raw=p.read_bytes();name=p.name+'.gz';assert name not in index;index[name]=dict(raw_sha256=hashlib.sha256(raw).hexdigest(),raw_bytes=len(raw));(dest/name).write_bytes(gzip.compress(raw,mtime=0))
 (dest/'manifest.json').write_text(json.dumps(index,indent=2)+'\n');return len(index)
names=['wolf170_transfer.py','wolf170_replay.py','wolf171_setup.py','wolf173_chain.py','wolf180_setup.py','run_wolf184_qualification.py','run_wolf184b_qualification.py','run_wolf184c_qualification.py','run_wolf184_primary.py','run_wolf185_08_primary.py','run_wolf186_florence_primary.py','run_wolf187_followups.py','run_wolf188_08_modern_primary.py','run_wolf189_modern_followup.py','wolf190_archive.py','verify_public183_saved_log.py','validate_final190_evidence.py','validate_final191_evidence.py','florence186_native_content_oracle.json','engine188_08_modern_preregistration.json','engine188_08_modern_environment.json','archive_completion191.py']
paths=[v/name for name in names]+[r/'zig/pkg/inference/scripts/lightonocr3'/name for name in ['benchmark_concurrency.py','benchmark_vllm_metal.py','test_benchmark_vllm_metal.py']]
patterns=['ocr-wolf170-transfer-parent.txt','ocr-wolf170-replay-parent.txt','ocr-wolf170b-replay-parent.txt','ocr-wolf171-setup-parent.txt','ocr-wolf171-screen-parent.txt','ocr-wolf171-screen-parent-retry.txt','ocr-wolf173-chain-parent.txt','ocr-wolf180-setup-parent.txt','ocr-wolf184-qualification-parent.txt','ocr-wolf184b-qualification-parent.txt','ocr-wolf184c-qualification-parent.txt','ocr-wolf184-primary-parent.txt','ocr-wolf187-followups-parent.txt','ocr-wolf189-modern-followup-parent.txt','ocr-wolf190-archive-parent.txt']
print('Completion drivers',archive('drivers',paths),'logs',archive('qualification',[Path('/private/tmp')/name for name in patterns]))
