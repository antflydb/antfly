from pathlib import Path
import datetime,hashlib,json,os,psutil,signal,subprocess,sys,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';remote='/Users/ajroetker/antfly/.worktrees/perf-lightonocr3-wolfspider';a=o/'wolf170_transfer_audit.json';assert not a.exists()
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for chunk in iter(lambda:f.read(8*1024**2),b''):h.update(chunk)
 return h.hexdigest()
f=json.loads((v/'engine158-freeze.json').read_text());assert all(sha(p)==h for p,h in f.items());assert json.loads((o/'engine165_batched_prefix_audit.json').read_text())['own_waiter_resumed']
candidates=[]
for p in psutil.process_iter(['cmdline']):
 try:
  if any(x.endswith('/run_engine158_short161_screen.py')for x in p.info['cmdline']or[])and p.cwd()==str(r):candidates.append(p)
 except psutil.Error:pass
assert len(candidates)==1
p=candidates[0];owned=dict(pid=p.pid,create_time=p.create_time(),cmdline=p.cmdline(),cwd=p.cwd());d=dict(status='holding_only_own_local_waiter_for_transfer',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),remote_worktree=remote,own_waiter=owned,steps=[])
def save():a.write_text(json.dumps(d,indent=2)+'\n')
save();stopped=False
try:
 p.send_signal(signal.SIGSTOP);stopped=True
 for i in range(50):
  if p.status()==psutil.STATUS_STOPPED:break
  time.sleep(.01)
 assert p.status()==psutil.STATUS_STOPPED
 while True:
  children=[]
  for q in p.children(recursive=True):
   try:
    if q.status()!=psutil.STATUS_ZOMBIE:children.append(dict(pid=q.pid,create_time=q.create_time(),cmdline=q.cmdline()))
   except psutil.NoSuchProcess:pass
  if not children:break
  d.update(status='waiting_own_model_children_finish_without_signaling_them',children=children);save();print('TRANSFER170 waiting for our active model to finish',flush=True);time.sleep(15)
 d['status']='hashing_frozen_model_inputs';save();origin=v/'wolf170_origin';origin.mkdir();(origin/'engine158_build_manifest.json').write_bytes((o/'engine158_build_manifest.json').read_bytes());(origin/'engine158_runtime.patch.gz').write_bytes((o/'engine158_runtime.patch.gz').read_bytes());(origin/'engine158_c_build_manifest.json').write_bytes((o/'engine158_c_build_manifest.json').read_bytes());models={}
 for name in ['lighton08','lighton4b']:
  path=v/'ocr-models'/name;print('HASH170',name,flush=True);models[name]={str(p.relative_to(path)):dict(bytes=p.stat().st_size,sha256=sha(p))for p in sorted(path.rglob('*'))if p.is_file()}
 (origin/'model_inputs.json').write_text(json.dumps(models,indent=2)+'\n')
 oracle=origin/'content_oracle';oracle.mkdir();(oracle/'report.json').write_bytes((o/'vllm_4b_primary_reference93_r0_c64_w256_r256_ctx1024/report.json').read_bytes())
 files=['engine158-freeze.json','qualified-binaries/engine158-test','engine158_conformance','engine158_attention','engine5_gpu_tests.py','run_engine158_gpu_build.py','engine94_benchmark_vllm_warm.py','run_engine158_budget_policies.py','engine158_benchmark_concurrency.py','run_engine158_short161_screen.py','run_engine158_primary162.py','run_engine113_08_warmed135.py','run_engine113_florence_warmed136.py','engine136_benchmark_mlx_florence_warm.py','wolf170_origin']
 paths=[str((v/path).relative_to(r))for path in files];d.update(status='transferring_small_payload',payload_files=paths);save();print('COPY170 source/binaries/drivers',flush=True)
 with Path('/private/tmp/ocr-wolf170-transfer-small.txt').open('w')as log:
  tar=subprocess.Popen(['tar','-C',str(r),'-cf','-',*paths],stdout=subprocess.PIPE,stderr=log)
  ssh=subprocess.Popen(['/usr/local/bin/tailscale','ssh','wolfspider',f'tar -C {remote} -xf -'],stdin=tar.stdout,stdout=log,stderr=subprocess.STDOUT);tar.stdout.close();code=ssh.wait();tarcode=tar.wait();assert code==tarcode==0,(code,tarcode)
 d['steps'].append(dict(step='small_payload',exit_code=0));save()
 sources=[('sitepackages',v/'lib/python3.12/site-packages',remote+'/.venv-lighton-vllm-metal/lib/python3.12/site-packages'),('lighton08',v/'ocr-models/lighton08',remote+'/.venv-lighton-vllm-metal/ocr-models/lighton08'),('lighton4b',v/'ocr-models/lighton4b',remote+'/.venv-lighton-vllm-metal/ocr-models/lighton4b')]
 subprocess.run(['/usr/local/bin/tailscale','ssh','wolfspider',f'mkdir -p {remote}/.venv-lighton-vllm-metal/ocr-models/lighton08 {remote}/.venv-lighton-vllm-metal/ocr-models/lighton4b'],check=True)
 for name,source,dest in sources:
  d['status']='copying_'+name;save();print('COPY170',name,flush=True);log=Path(f'/private/tmp/ocr-wolf170-transfer-{name}.txt');assert not log.exists();cmd=['/usr/bin/rsync','-aL','--partial','--stats','--exclude=__pycache__','--exclude=*.pyc','--exclude=.DS_Store','-e','/usr/local/bin/tailscale ssh',str(source)+'/',f'wolfspider:{dest}/']
  with log.open('w')as out:result=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
  d['steps'].append(dict(step=name,exit_code=result.returncode,log_sha256=sha(log)));save();assert result.returncode==0,(name,result.returncode);print('DONE170',name,flush=True)
 d['status']='transferred_remote_hash_validation_pending';save()
except BaseException as e:d.update(status='failed_transfer',error=repr(e));save();raise
finally:
 if stopped:
  q=psutil.Process(owned['pid']);assert abs(q.create_time()-owned['create_time'])<.1 and q.cmdline()==owned['cmdline']and q.cwd()==owned['cwd'];q.send_signal(signal.SIGCONT);d['own_waiter_resumed']=True;save();print('TRANSFER170 own local waiter resumed',flush=True)
