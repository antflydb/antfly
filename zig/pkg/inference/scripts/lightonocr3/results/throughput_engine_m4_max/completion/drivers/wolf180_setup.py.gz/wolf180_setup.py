from pathlib import Path
import datetime,gzip,hashlib,json,os,shutil,subprocess
r=Path('/Users/ajroetker/antfly/.worktrees/perf-lightonocr3-shared-frame-wolfspider');os.chdir(r)
v=r/'.venv-lighton-vllm-metal';origin=v/'wolf180_origin';old=r.parent/'perf-lightonocr3-wolfspider';ov=old/'.venv-lighton-vllm-metal';prior=old/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/wolfspider';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/wolfspider_shared_frame';o.mkdir(parents=True,exist_ok=True);a=o/'wolf180_setup_audit.json';assert not a.exists()
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for block in iter(lambda:f.read(8*1024**2),b''):h.update(block)
 return h.hexdigest()
assert json.loads((prior/'paired172_4b_warmed_comparison_audit.json').read_text())['status']=='repeated_native_win'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='451ea2bdd0b8717ec0e302f90ff6bac1de6a5bb0'
patch=gzip.decompress((origin/'engine180_runtime.patch.gz').read_bytes());subprocess.run(['git','apply','--check','-'],input=patch,check=True);subprocess.run(['git','apply','-'],input=patch,check=True)
freeze=json.loads((origin/'engine180-freeze.json').read_text());assert all(sha(r/name)==expected for name,expected in freeze.items());shutil.copyfile(origin/'engine180-freeze.json',v/'engine180-freeze.json')
for name in ['lighton08','lighton4b']:(v/'ocr-models'/name).symlink_to(ov/'ocr-models'/name,target_is_directory=True)
models=json.loads((origin/'florence_model_inputs.json').read_text())
for model,files in models.items():
 for name,expected in files.items():
  path=v/'ocr-models'/model/name;assert path.stat().st_size==expected['bytes']and sha(path)==expected['sha256'],path
(o/'florence_model_identity_audit.json').write_text(json.dumps(dict(status='all_florence_inputs_byte_identical',scope='Pinned original MLX FP16 and publisher native Q4_K/F16-encoder checkpoints. Distinct representations remain explicit; no conversion or quantization change. New copies confined to own worktree.',models=models),indent=2)+'\n')
for name in ['run_engine180_budget_policies.py','engine180_benchmark_concurrency.py','run_engine180_gpu_build.py','engine5_gpu_tests.py','engine180_c64_smoke_environment.json']:shutil.copyfile(origin/name,v/name)
s=(v/'run_engine180_budget_policies.py').read_text();needle="out=scripts/'results/throughput_engine_m4_max';";assert needle in s;s=s.replace(needle,"out=scripts/'results/throughput_engine_m4_max/wolfspider_shared_frame';");(v/'run_wolf180_budget_policies.py').write_text(s);compile(s,'wolf180wrapper','exec')
shutil.copyfile(ov/'engine94_benchmark_vllm_warm.py',v/'engine94_benchmark_vllm_warm.py')
for model,source in [('4b',prior/'vllm_4b_primary_reference172_r1_c64_w256_r256_ctx1024/report.json'),('08',origin/'lighton08_content_oracle.json')]:
 d=json.loads(source.read_text());dest=o/('vllm_'+model+'_content_oracle');dest.mkdir();(dest/'report.json').write_text(json.dumps(dict(reference_kind='text_only',performance_evidence=False,source_report_sha256=sha(source),images=d['images'],references=d['references']),indent=2)+'\n')
shutil.copyfile(origin/'engine180_candidate_preregistration.json',o/'engine180_candidate_preregistration.json')
a.write_text(json.dumps(dict(status='source_models_and_drivers_ready_binary_qualification_pending',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),source_file_count=len(freeze),runtime_patch_sha256=sha(origin/'engine180_runtime.patch.gz'),scope='Separate worktree on same wolfspider host after paired172 closes. LightOn models reuse immutable hash-verified original copies through symlinks; Florence copies stream-hash verified. Local source180 noncheckpoint GPU build and full remote replay/model checks still pending. No performance result claimed.'),indent=2)+'\n');print('WOLF180 source and all model inputs ready; binary qualification pending',flush=True)
