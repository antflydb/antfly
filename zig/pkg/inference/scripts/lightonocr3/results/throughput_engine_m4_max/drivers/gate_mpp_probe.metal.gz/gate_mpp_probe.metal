#include <metal_stdlib>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;using namespace mpp::tensor_ops;
struct Params{uint rows,in_dim,out_dim,pad;};
kernel void gate_mpp_0(device float*x[[buffer(0)]],device bfloat*gw[[buffer(1)]],device bfloat*uw[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){
 tensor<device float,dextents<int,2>,tensor_inline>a(x,dextents<int,2>(p.in_dim,p.rows),array<int,2>{1,int(p.in_dim)});
 tensor<device bfloat,dextents<int,2>,tensor_inline>gmat(gw,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{1,int(p.in_dim)}),umat(uw,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{1,int(p.in_dim)});
 tensor<device float,dextents<int,2>,tensor_inline>c(y,dextents<int,2>(p.out_dim,p.rows),array<int,2>{1,int(p.out_dim)});
 auto left=a.slice(0,int(group.y)*16);auto rightg=gmat.slice(0,int(group.x)*8);auto rightu=umat.slice(0,int(group.x)*8);auto dest=c.slice(int(group.x)*8,int(group.y)*16);
 constexpr auto desc=matmul2d_descriptor(16,8,dynamic_length_v<int>,false,true,false);matmul2d<desc,execution_simdgroups<1>>op;
 auto g=op.get_destination_cooperative_tensor<decltype(left),decltype(rightg),float>();auto u=op.get_destination_cooperative_tensor<decltype(left),decltype(rightu),float>();op.run(left,rightg,g);op.run(left,rightu,u);
 for(ushort i=0;i<g.get_capacity();i++){auto coord=g.get_multidimensional_index(i);int col=int(group.x)*8+coord[0],row=int(group.y)*16+coord[1];if(coord[0]>=0&&coord[0]<8&&coord[1]>=0&&coord[1]<16&&col<int(p.out_dim)&&row<int(p.rows)){float gs=g[i]+gb[col],us=u[i]+ub[col];g[i]=(gs/(1.0f+exp(-gs)))*us;}}
 g.store(dest);
}
kernel void gate_mpp_1(device float*x[[buffer(0)]],device bfloat*gw[[buffer(1)]],device bfloat*uw[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){
 tensor<device float,dextents<int,2>,tensor_inline>a(x,dextents<int,2>(p.in_dim,p.rows),array<int,2>{1,int(p.in_dim)});
 tensor<device bfloat,dextents<int,2>,tensor_inline>gmat(gw,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{1,int(p.in_dim)}),umat(uw,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{1,int(p.in_dim)});
 tensor<device float,dextents<int,2>,tensor_inline>c(y,dextents<int,2>(p.out_dim,p.rows),array<int,2>{1,int(p.out_dim)});
 auto left=a.slice(0,int(group.y)*16);auto rightg=gmat.slice(0,int(group.x)*16);auto rightu=umat.slice(0,int(group.x)*16);auto dest=c.slice(int(group.x)*16,int(group.y)*16);
 constexpr auto desc=matmul2d_descriptor(16,16,dynamic_length_v<int>,false,true,false);matmul2d<desc,execution_simdgroups<1>>op;
 auto g=op.get_destination_cooperative_tensor<decltype(left),decltype(rightg),float>();auto u=op.get_destination_cooperative_tensor<decltype(left),decltype(rightu),float>();op.run(left,rightg,g);op.run(left,rightu,u);
 for(ushort i=0;i<g.get_capacity();i++){auto coord=g.get_multidimensional_index(i);int col=int(group.x)*16+coord[0],row=int(group.y)*16+coord[1];if(coord[0]>=0&&coord[0]<16&&coord[1]>=0&&coord[1]<16&&col<int(p.out_dim)&&row<int(p.rows)){float gs=g[i]+gb[col],us=u[i]+ub[col];g[i]=(gs/(1.0f+exp(-gs)))*us;}}
 g.store(dest);
}
kernel void gate_mpp_2(device float*x[[buffer(0)]],device bfloat*gw[[buffer(1)]],device bfloat*uw[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){
 tensor<device float,dextents<int,2>,tensor_inline>a(x,dextents<int,2>(p.in_dim,p.rows),array<int,2>{1,int(p.in_dim)});
 tensor<device bfloat,dextents<int,2>,tensor_inline>gmat(gw,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{1,int(p.in_dim)}),umat(uw,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{1,int(p.in_dim)});
 tensor<device float,dextents<int,2>,tensor_inline>c(y,dextents<int,2>(p.out_dim,p.rows),array<int,2>{1,int(p.out_dim)});
 auto left=a.slice(0,int(group.y)*16);auto rightg=gmat.slice(0,int(group.x)*32);auto rightu=umat.slice(0,int(group.x)*32);auto dest=c.slice(int(group.x)*32,int(group.y)*16);
 constexpr auto desc=matmul2d_descriptor(16,32,dynamic_length_v<int>,false,true,false);matmul2d<desc,execution_simdgroups<1>>op;
 auto g=op.get_destination_cooperative_tensor<decltype(left),decltype(rightg),float>();auto u=op.get_destination_cooperative_tensor<decltype(left),decltype(rightu),float>();op.run(left,rightg,g);op.run(left,rightu,u);
 for(ushort i=0;i<g.get_capacity();i++){auto coord=g.get_multidimensional_index(i);int col=int(group.x)*32+coord[0],row=int(group.y)*16+coord[1];if(coord[0]>=0&&coord[0]<32&&coord[1]>=0&&coord[1]<16&&col<int(p.out_dim)&&row<int(p.rows)){float gs=g[i]+gb[col],us=u[i]+ub[col];g[i]=(gs/(1.0f+exp(-gs)))*us;}}
 g.store(dest);
}
kernel void gate_mpp_3(device float*x[[buffer(0)]],device bfloat*gw[[buffer(1)]],device bfloat*uw[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){
 tensor<device float,dextents<int,2>,tensor_inline>a(x,dextents<int,2>(p.in_dim,p.rows),array<int,2>{1,int(p.in_dim)});
 tensor<device bfloat,dextents<int,2>,tensor_inline>gmat(gw,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{1,int(p.in_dim)}),umat(uw,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{1,int(p.in_dim)});
 tensor<device float,dextents<int,2>,tensor_inline>c(y,dextents<int,2>(p.out_dim,p.rows),array<int,2>{1,int(p.out_dim)});
 auto left=a.slice(0,int(group.y)*16);auto rightg=gmat.slice(0,int(group.x)*32);auto rightu=umat.slice(0,int(group.x)*32);auto dest=c.slice(int(group.x)*32,int(group.y)*16);
 constexpr auto desc=matmul2d_descriptor(16,32,dynamic_length_v<int>,false,true,false);matmul2d<desc,execution_simdgroups<2>>op;
 auto g=op.get_destination_cooperative_tensor<decltype(left),decltype(rightg),float>();auto u=op.get_destination_cooperative_tensor<decltype(left),decltype(rightu),float>();op.run(left,rightg,g);op.run(left,rightu,u);
 for(ushort i=0;i<g.get_capacity();i++){auto coord=g.get_multidimensional_index(i);int col=int(group.x)*32+coord[0],row=int(group.y)*16+coord[1];if(coord[0]>=0&&coord[0]<32&&coord[1]>=0&&coord[1]<16&&col<int(p.out_dim)&&row<int(p.rows)){float gs=g[i]+gb[col],us=u[i]+ub[col];g[i]=(gs/(1.0f+exp(-gs)))*us;}}
 g.store(dest);
}
kernel void gate_mpp_4(device float*x[[buffer(0)]],device bfloat*gw[[buffer(1)]],device bfloat*uw[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){
 tensor<device float,dextents<int,2>,tensor_inline>a(x,dextents<int,2>(p.in_dim,p.rows),array<int,2>{1,int(p.in_dim)});
 tensor<device bfloat,dextents<int,2>,tensor_inline>gmat(gw,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{1,int(p.in_dim)}),umat(uw,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{1,int(p.in_dim)});
 tensor<device float,dextents<int,2>,tensor_inline>c(y,dextents<int,2>(p.out_dim,p.rows),array<int,2>{1,int(p.out_dim)});
 auto left=a.slice(0,int(group.y)*16);auto rightg=gmat.slice(0,int(group.x)*64);auto rightu=umat.slice(0,int(group.x)*64);auto dest=c.slice(int(group.x)*64,int(group.y)*16);
 constexpr auto desc=matmul2d_descriptor(16,64,dynamic_length_v<int>,false,true,false);matmul2d<desc,execution_simdgroups<2>>op;
 auto g=op.get_destination_cooperative_tensor<decltype(left),decltype(rightg),float>();auto u=op.get_destination_cooperative_tensor<decltype(left),decltype(rightu),float>();op.run(left,rightg,g);op.run(left,rightu,u);
 for(ushort i=0;i<g.get_capacity();i++){auto coord=g.get_multidimensional_index(i);int col=int(group.x)*64+coord[0],row=int(group.y)*16+coord[1];if(coord[0]>=0&&coord[0]<64&&coord[1]>=0&&coord[1]<16&&col<int(p.out_dim)&&row<int(p.rows)){float gs=g[i]+gb[col],us=u[i]+ub[col];g[i]=(gs/(1.0f+exp(-gs)))*us;}}
 g.store(dest);
}
kernel void gate_mpp_5(device float*x[[buffer(0)]],device bfloat*gw[[buffer(1)]],device bfloat*uw[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){
 tensor<device float,dextents<int,2>,tensor_inline>a(x,dextents<int,2>(p.in_dim,p.rows),array<int,2>{1,int(p.in_dim)});
 tensor<device bfloat,dextents<int,2>,tensor_inline>gmat(gw,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{1,int(p.in_dim)}),umat(uw,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{1,int(p.in_dim)});
 tensor<device float,dextents<int,2>,tensor_inline>c(y,dextents<int,2>(p.out_dim,p.rows),array<int,2>{1,int(p.out_dim)});
 auto left=a.slice(0,int(group.y)*16);auto rightg=gmat.slice(0,int(group.x)*64);auto rightu=umat.slice(0,int(group.x)*64);auto dest=c.slice(int(group.x)*64,int(group.y)*16);
 constexpr auto desc=matmul2d_descriptor(16,64,dynamic_length_v<int>,false,true,false);matmul2d<desc,execution_simdgroups<4>>op;
 auto g=op.get_destination_cooperative_tensor<decltype(left),decltype(rightg),float>();auto u=op.get_destination_cooperative_tensor<decltype(left),decltype(rightu),float>();op.run(left,rightg,g);op.run(left,rightu,u);
 for(ushort i=0;i<g.get_capacity();i++){auto coord=g.get_multidimensional_index(i);int col=int(group.x)*64+coord[0],row=int(group.y)*16+coord[1];if(coord[0]>=0&&coord[0]<64&&coord[1]>=0&&coord[1]<16&&col<int(p.out_dim)&&row<int(p.rows)){float gs=g[i]+gb[col],us=u[i]+ub[col];g[i]=(gs/(1.0f+exp(-gs)))*us;}}
 g.store(dest);
}
