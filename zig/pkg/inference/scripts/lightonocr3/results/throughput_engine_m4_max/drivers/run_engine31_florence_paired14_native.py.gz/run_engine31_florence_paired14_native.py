from pathlib import Path
import json,subprocess,sys
root=Path.cwd();p=root/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_engine_m4_max';manifest=out/'engine31_build_manifest.json';binary=json.loads(manifest.read_text())['binary_path']
for i in [int(sys.argv[1])]:
 disabled=False
 rows=8
 command=[sys.executable,str(p/'benchmark_concurrency.py'),'--native-test',binary,'--model','florence=/Users/ajroetker/.antfly/inference/models/antflydb/florence-2-base','--images',str(root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(p/'corpus/receipt.png'),str(p/'corpus/shipping.png'),'--requests','64','--concurrency','8','--max-tokens','256','--modes','batch','--native-read-batch-size',str(rows),'--batch-wait-us','5000','--florence-batch-wait-us','5000','--memory-gib','24','--shared-memory-gib','28','--backend-memory-gib','16','--kv-memory-gib','4','--scratch-memory-gib','8','--timeout','600','--reference-report',str(out/f'mlx_florence_engine31_paired14_r{int(sys.argv[2])}_reference/report.json'),'--build-manifest',str(manifest),'--output-dir',str(out/f'engine31_florence_paired14_r{i}_native')]
 command+=['--require-florence-no-repeat-argmax','--require-florence-single-frame','--policy-rounds','current']
 if disabled:command+=['--disable-florence-single-frame']
 print('START',i,'disabled',disabled,flush=True)
 with open(f'/private/tmp/ocr-engine31-florence-paired14-round{i}.txt','w')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 print('DONE',i,rows,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
