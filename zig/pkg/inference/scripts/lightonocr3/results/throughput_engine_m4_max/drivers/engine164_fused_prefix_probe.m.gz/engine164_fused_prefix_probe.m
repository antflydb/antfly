#define main unused_engine164_main
#include "engine164_fused_prefix_checks.m"
#undef main
int main(int argc,const char**argv){@autoreleasepool{
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 NSError*error=nil;NSString*source=[NSString stringWithContentsOfFile:@".venv-lighton-vllm-metal/engine164_fused_prefix.metal" encoding:NSUTF8StringEncoding error:&error];
 MTLCompileOptions*options=[[MTLCompileOptions alloc]init];options.fastMathEnabled=NO;
 id<MTLLibrary>library=[r->device newLibraryWithSource:source options:options error:&error];if(!library){fprintf(stderr,"COMPILE164 %s\n",error.localizedDescription.UTF8String);return 2;}
 engine164_pipeline=termite_metal_make_pipeline(r->device,library,@"termite_lightonocr3_fused_prefill164");
 if(!engine164_pipeline||engine164_pipeline.threadExecutionWidth!=32||engine164_pipeline.maxTotalThreadsPerThreadgroup<512)return 3;
 const bool benchmark=argc==2&&strcmp(argv[1],"--benchmark")==0;
 const size_t qs[]={1,2,4,8,16,17,22,31,32,42,48,63,64,65,96,112,120,127,128,129,432,554,662,1024,2048};
 for(size_t h=16;h<=32;h+=16)for(size_t i=0;i<sizeof(qs)/sizeof(qs[0]);i++)for(size_t init=0;init<2;init++){
 if(benchmark&&qs[i]!=22&&qs[i]!=42&&qs[i]!=48&&qs[i]!=64&&qs[i]!=96&&qs[i]!=120&&qs[i]!=128&&qs[i]!=432&&qs[i]!=662)continue;
 int rc=prefill_core_check(r,qs[i],h,init,benchmark);if(rc){fprintf(stderr,"FAIL164 q=%zu h=%zu init=%zu rc=%d\n",qs[i],h,init,rc);return rc+20;}
 }
 fprintf(stderr,"FUSED164 FULL CORE STATE INTERMEDIATE CANARY CHECKS PASS benchmark=%d\n",benchmark);termite_metal_decode_runtime_destroy(r);return 0;
}}
