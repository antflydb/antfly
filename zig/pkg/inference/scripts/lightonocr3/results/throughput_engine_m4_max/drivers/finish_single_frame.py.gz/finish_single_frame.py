from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/src/ops/metal_compute.zig';s=p.read_text().replace('    lighton_wide_projection_tiles_start: u64 = 0,','    lighton_wide_projection_tiles_start: u64 = 0,\n    lighton_single_frame_stats: [2]u64 = @splat(0),',1).replace('        self.lighton_activation_pool_enabled = enabled;','        self.lighton_activation_pool_enabled = enabled;\n        self.lighton_single_frame_stats = @splat(0);',1);a='    pub fn argmaxOnFrameCount(cb: *const ops.ComputeBackend) u64 {';s=s.replace(a,'''    pub fn noteLightOnSingleFrame(cb: *const ops.ComputeBackend, submits: u64, argmaxes: u64) void {
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        self.lighton_single_frame_stats[if (submits == 1 and argmaxes == 1) 0 else 1] += 1;
    }

    pub fn lightOnSingleFrameStats(cb: *const ops.ComputeBackend) [2]u64 {
        if (cb.kind() != .metal) return @splat(0);
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return self.lighton_single_frame_stats;
    }

'''+a,1);p.write_text(s)
p=r/'zig/pkg/inference/src/pipelines/generation.zig';s=p.read_text();old='''                        if (platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3")) {
                            std.debug.print("LIGHTONOCR3 single_frame_step rows={d} submits={d} argmax_on_frame={d}\\n", .{ claimed.len, frames, on_frame });
                        }''';assert old in s;s=s.replace(old,'                        M.noteLightOnSingleFrame(&self.cb, frames, on_frame);',1);p.write_text(s)
p=r/'zig/pkg/inference/src/server/server.zig';s=p.read_text();a='                    std.debug.print("LIGHTONOCR3 wide_projection_tiles={d}\\n", .{wide_tiles});';assert a in s;s=s.replace(a,a+'''
                    const single_frame = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnSingleFrameStats(&cb) else @as([2]u64, @splat(0));
                    std.debug.print("LIGHTONOCR3 single_frame_steps={d} single_frame_topology_mismatches={d}\\n", .{ single_frame[0], single_frame[1] });''',1);p.write_text(s)
p=r/'.venv-lighton-vllm-metal/run_engine11_gpu_build.py';s=p.read_text().replace("env['ANTFLY_LIGHTONOCR3_EPOCH_AUX']='1'","env['ANTFLY_LIGHTONOCR3_EPOCH_AUX']='1'\nenv['ANTFLY_LIGHTONOCR3_SINGLE_FRAME']='1'");p.write_text(s)
