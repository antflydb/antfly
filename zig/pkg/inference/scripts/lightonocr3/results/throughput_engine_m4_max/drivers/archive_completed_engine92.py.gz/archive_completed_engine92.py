from pathlib import Path
import json,gzip,hashlib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
a=o/'engine92_prefill_geometry_audit.json';raw=a.read_bytes();assert json.loads(raw)['status']=='prototype_pass';gz=a.with_suffix('.json.gz');assert not gz.exists();gz.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(gz.read_bytes())==raw
m=o/'large_audits_manifest.json';d=json.loads(m.read_text())if m.exists()else{};assert a.name not in d;d[a.name]=dict(compressed_path=gz.name,raw_sha256=hashlib.sha256(raw).hexdigest(),raw_bytes=len(raw),compressed_sha256=hashlib.sha256(gz.read_bytes()).hexdigest());m.write_text(json.dumps(d,indent=2)+'\n')
p=o/'engine92_prefill_geometry_review.json';d=json.loads(p.read_text());assert d['audit_sha256']==hashlib.sha256(raw).hexdigest();d['audit_compressed_path']=gz.name;p.write_text(json.dumps(d,indent=2)+'\n');a.unlink()
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('qualification',sorted(Path('/private/tmp').glob('ocr-engine92-*.txt')),'logs_manifest.json')
ns['archive']('drivers',[p for p in v.glob('*engine92*')if p.is_file()and p.suffix in ['.py','.m','.metal','.inc','.json','.zig']],'drivers_manifest.json')
print('Archived92 complete probe losslessly; large timing audit compressed with hashes.')
