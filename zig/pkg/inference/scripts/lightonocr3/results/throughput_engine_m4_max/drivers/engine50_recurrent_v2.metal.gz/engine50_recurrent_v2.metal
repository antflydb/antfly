#define KSG 8
#include <metal_stdlib>
using namespace metal;
struct CoreParams {
    uint seq, key_heads, value_heads, dim, kernel_size, initialized;
};
struct CoreRow {
    device float *buffers[15];
    CoreParams params;
};
kernel void engine50_recurrent_v2(constant CoreRow *rows [[buffer(0)]],
                                                   uint2 group [[threadgroup_position_in_grid]],
                                                   uint d [[thread_index_in_threadgroup]],
                                                   ushort lane [[thread_index_in_simdgroup]],
                                                   ushort simd [[simdgroup_index_in_threadgroup]]) {
    constant CoreRow &r = rows[group.y];
    constant CoreParams &p = r.params;
    uint h = group.x;
    device const float *mixed = r.buffers[0];
    device const float *weight = r.buffers[1];
    device const float *beta = r.buffers[2];
    device const float *a = r.buffers[3];
    device const float *alog = r.buffers[4];
    device const float *dt = r.buffers[5];
    device const float *history = r.buffers[6];
    device float *next = r.buffers[7];
    device float *state = r.buffers[8];
    device float *conv = r.buffers[9];
    device float *gates = r.buffers[10];
    device float *core = r.buffers[11];
    device const float *z = r.buffers[12];
    device const float *norm = r.buffers[13];
    device float *output = r.buffers[14];

    threadgroup float q[128], k[128], values[128], reduction[64], scales[4];
    threadgroup float partials[KSG * 128];
    uint ratio = p.value_heads / p.key_heads, kh = h / ratio;
    if (d < 128) {
        uint indices[3] = {kh * 128 + d, (p.key_heads + kh) * 128 + d, 2 * p.key_heads * 128 + h * 128 + d};
        float v[3];
        for (uint j = 0; j < 3; j++) {
            uint c = indices[j];
            float sum = 0;
            for (uint t = 0; t < 4; t++) {
                float x = t == 3 ? mixed[c] : (p.initialized ? history[c * 4 + t + 1] : 0.0f);
                sum += x * weight[c * 4 + t];
                if (j == 2 || h % ratio == 0)
                    next[c * 4 + t] = x;
            }
            v[j] = sum / (1.0f + exp(-sum));
        }
        float qs = simd_sum(v[0] * v[0]), ks = simd_sum(v[1] * v[1]);
        if (lane == 0) {
            reduction[simd] = qs;
            reduction[4 + simd] = ks;
        }
        q[d] = v[0];
        k[d] = v[1];
        values[d] = v[2];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (d == 0) {
        float qs = 0, ks = 0;
        for (uint s = 0; s < 4; s++) {
            qs += reduction[s];
            ks += reduction[4 + s];
        }
        scales[0] = 1.0f / sqrt(qs + 1e-6f) / sqrt(128.0f);
        scales[1] = 1.0f / sqrt(ks + 1e-6f);
        float x = a[h] + dt[h], sp = x > 20.0f ? x : (x < -20.0f ? exp(x) : log(1.0f + exp(x)));
        scales[2] = exp(-exp(alog[h]) * sp);
        scales[3] = 1.0f / (1.0f + exp(-beta[h]));
        gates[h * 2] = scales[2];
        gates[h * 2 + 1] = scales[3];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (d < 128) {
        q[d] *= scales[0];
        k[d] *= scales[1];
        if (h % ratio == 0) {
            conv[kh * 128 + d] = q[d];
            conv[(p.key_heads + kh) * 128 + d] = k[d];
        }
        conv[2 * p.key_heads * 128 + h * 128 + d] = values[d];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    const uint col = uint(lane) * 4;
    float4 memory = 0;
    float4 previous[128/KSG];
    for (uint i=0;i<128/KSG;i++) {
        uint key=uint(simd)*(128/KSG)+i;
        float4 prior=p.initialized?*((device const float4*)(state+h*128*128+key*128+col)):float4(0);
        prior*=scales[2];
        previous[i]=prior;
        memory+=prior*k[key];
    }
    *((threadgroup float4*)(partials+uint(simd)*128+col))=memory;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    memory=0;
    for(uint sg=0;sg<KSG;sg++)memory+=*((threadgroup float4*)(partials+sg*128+col));
    float4 delta=(float4(values[col],values[col+1],values[col+2],values[col+3])-memory)*scales[3];
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float4 result=0;
    for(uint i=0;i<128/KSG;i++){
        uint key=uint(simd)*(128/KSG)+i;
        float4 prior=previous[i];
        float4 updated=prior+k[key]*delta;
        *((device float4*)(state+h*128*128+key*128+col))=updated;
        result+=updated*q[key];
    }
    *((threadgroup float4*)(partials+uint(simd)*128+col))=result;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if(simd==0){
        result=0;
        for(uint sg=0;sg<KSG;sg++)result+=*((threadgroup float4*)(partials+sg*128+col));
        *((device float4*)(core+h*128+col))=result;
        float sum=simd_sum(dot(result,result));
        float scale=1.0f/sqrt(sum/128.0f+1e-6f);
        float4 gate=*((device const float4*)(z+h*128+col)),n=*((device const float4*)(norm+col));
        *((device float4*)(output+h*128+col))=result*scale*n*(gate/(1.0f+exp(-gate)));
    }
}
