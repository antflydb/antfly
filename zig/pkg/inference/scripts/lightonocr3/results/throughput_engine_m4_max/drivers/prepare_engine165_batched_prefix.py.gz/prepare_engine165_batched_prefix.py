from pathlib import Path
import hashlib,json,re
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';path=r/'zig/pkg/inference/src/backends/metal_kernels.m';base=path.read_text();parts=[]
for line in base.splitlines():
 m=re.match(r'\s*(".*")\s*;?\s*$',line)
 if m:
  try:parts.append(json.loads(m[1]))
  except json.JSONDecodeError:pass
text=''.join(parts)
def function(token):
 start=text.index(token);a=text.index('{',start);level=1;b=a+1
 while level:
  level+=(text[b]=='{')-(text[b]=='}');b+=1
 return text[start:b]
shader='#include <metal_stdlib>\nusing namespace metal;\nstruct termite_qwen35_params{uint seq,key_heads,value_heads,dim,kernel_size,initialized;};\nstruct CoreRow{device float*buffers[15];termite_qwen35_params params;};\n'
shader+=function('template<uint C>inline void termite_qwen35_recurrent_columns_body(')+'\n'
locals='''constant CoreRow&r=rows[id.y];constant termite_qwen35_params&p=r.params;uint gid=id.x;
device const float*mixed=r.buffers[0],*weight=r.buffers[WEIGHT],*beta=r.buffers[2],*a=r.buffers[3],*alog=r.buffers[4],*dt=r.buffers[5],*history=r.buffers[6];
device float*next=r.buffers[7],*state=r.buffers[8],*conv=r.buffers[9],*gates=r.buffers[10],*core=r.buffers[11];device const float*z=r.buffers[12];device float*output=r.buffers[14];
'''
for name,original,weight in [('conv','termite_qwen35_prefill_conv_vec4',1),('history','termite_qwen35_history',1),('prepare','termite_lightonocr3_prefill_prepare_parallel',1),('norm','termite_lightonocr3_prefill_norm_parallel',13)]:
 f=function('kernel void '+original+'(');body=f[f.index('{')+1:-1];body=body.replace('constant CoreParams','constant termite_qwen35_params');shader+='kernel void batch165_'+name+'(constant CoreRow*rows[[buffer(0)]],uint2 id[[thread_position_in_grid]],ushort lane[[thread_index_in_simdgroup]]){\n'+locals.replace('WEIGHT',str(weight))+body+'\n}\n'
shader+='''kernel void batch165_recurrent(constant CoreRow*rows[[buffer(0)]],uint2 id[[thread_position_in_grid]],ushort lane[[thread_index_in_simdgroup]]){constant CoreRow&r=rows[id.y];termite_qwen35_recurrent_columns_body<4>(r.buffers[8],r.buffers[9],r.buffers[10],r.buffers[11],r.params,id.x,lane);}
''';(v/'engine165_batched_prefix.metal').write_text(shader);(v/'engine165_batched_prefix_kernels.m').write_text(base)
probe=r'''#include "engine165_batched_prefix_kernels.m"
static id<MTLComputePipelineState> psos165[5];
static int batch165(termite_metal_decode_runtime*r,void*const*handles,const size_t*offsets,const uint32_t*params,size_t pages){
 if(!r||!r->active_frame_cb||!pages||pages>8)return 1;
 termite_metal_lightonocr3_recurrent_row table[8];__unsafe_unretained id<MTLResource>resources[120],writes[48];size_t nw=0,maxseq=0,total=0;
 for(size_t page=0;page<pages;page++){
  const uint32_t*p=params+page*6;size_t seq=p[0],kh=p[1],vh=p[2],channels=(2*kh+vh)*128;
  if(seq<2||seq>2048||kh!=16||(vh!=16&&vh!=32)||p[3]!=128||p[4]!=4||vh!=params[2])return 2;
  maxseq=MAX(maxseq,seq);total+=seq;memcpy(table[page].params,p,24);
  const size_t counts[15]={seq*channels,channels*4,seq*vh,seq*vh,vh,vh,channels*4,channels*4,vh*128*128,seq*channels,seq*vh*2,seq*vh*128,seq*vh*128,128,seq*vh*128};
  for(size_t j=0;j<15;j++){
   const size_t index=page*15+j;id<MTLBuffer>b=(__bridge id<MTLBuffer>)handles[index];size_t bytes=counts[j]*4;
   if(!b||offsets[index]%16||offsets[index]>b.length||bytes>b.length-offsets[index]||!b.gpuAddress)return 3;
   table[page].buffers[j]=b.gpuAddress+offsets[index];resources[index]=b;
   if(j==7||j==8||j==9||j==10||j==11||j==14)writes[nw++]=b;
   if(termite_metal_decode_runtime_retain_frame_resource(r,b))return 4;
  }
 }
 if(total>4096)return 5;
 termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
 id<MTLComputeCommandEncoder>enc=termite_metal_tracked_compute_command_encoder_for(r->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_OTHER);if(!enc)return 6;
 [enc setBytes:table length:pages*sizeof(table[0])atIndex:0];[enc useResources:resources count:pages*15 usage:MTLResourceUsageRead];[enc useResources:writes count:nw usage:MTLResourceUsageWrite];
 size_t vh=params[2],channels=(32+vh)*128;size_t grids[5]={maxseq*channels/4,channels*4,maxseq*vh*32,vh*128*32/4,maxseq*vh*32};size_t widths[5]={256,256,32,32,32};
 for(size_t stage=0;stage<5;stage++){[enc setComputePipelineState:psos165[stage]];[enc dispatchThreads:MTLSizeMake(grids[stage],pages,1)threadsPerThreadgroup:MTLSizeMake(widths[stage],1,1)];if(stage<4)[enc memoryBarrierWithScope:MTLBarrierScopeBuffers];}
 [enc endEncoding];return 0;
}
static int check165(termite_metal_decode_runtime*r,size_t pages,size_t q,size_t vh,bool mixed,bool benchmark){
 size_t counts[8][15],seq[8],offsets[8][15];uint32_t params[8][6];
 id<MTLBuffer>buffers[2][8][15];void*handles[2][8][15];void*seed[8];
 size_t total=0;for(size_t page=0;page<pages;page++){seq[page]=mixed?MAX((size_t)2,q-MIN(q-2,(page%3)*17)):q;total+=seq[page];}if(total>4096)return 0;
 for(size_t page=0;page<pages;page++){
 size_t n=seq[page],channels=(32+vh)*128;size_t c[15]={n*channels,channels*4,n*vh,n*vh,vh,vh,channels*4,channels*4,vh*128*128,n*channels,n*vh*2,n*vh*128,n*vh*128,128,n*vh*128};memcpy(counts[page],c,sizeof(c));uint32_t p[6]={(uint32_t)n,16,(uint32_t)vh,128,4,(uint32_t)(page%2)};memcpy(params[page],p,24);
 for(size_t j=0;j<15;j++){offsets[page][j]=16;for(size_t mode=0;mode<2;mode++){
  buffers[mode][page][j]=[r->device newBufferWithLength:(c[j]+8)*4 options:MTLResourceStorageModeShared];if(!buffers[mode][page][j])return 10;handles[mode][page][j]=(__bridge void*)buffers[mode][page][j];uint32_t*raw=buffers[mode][page][j].contents;
  for(size_t i=0;i<4;i++)raw[i]=raw[c[j]+4+i]=0xdeadbeef;
  float*x=(float*)raw+4;for(size_t i=0;i<c[j];i++)x[i]=j==13?.5f+(i%7)*.1f:sinf(i*.013f+j+page*.31f)*.1f;
 }}
 seed[page]=malloc(c[8]*4);if(!seed[page])return 11;memcpy(seed[page],(char*)buffers[0][page][8].contents+16,c[8]*4);
 }
 float worst=0;size_t trials=benchmark?30:1;
 for(size_t trial=0;trial<trials;trial++)for(size_t order=0;order<2;order++){@autoreleasepool{
 size_t mode=benchmark?(order+trial%2)%2:order;
 for(size_t page=0;page<pages;page++)memcpy((char*)buffers[mode][page][8].contents+16,seed[page],counts[page][8]*4);
 if(termite_metal_decode_runtime_begin_frame(r))return 12;
 uint64_t start=clock_gettime_nsec_np(CLOCK_UPTIME_RAW);int rc=0;
 if(mode==0){for(size_t page=0;page<pages;page++){rc=termite_metal_decode_runtime_qwen35_core_device(r,handles[mode][page],offsets[page],seq[page],16,vh,128,4,page%2);if(rc)break;}}
 else rc=batch165(r,&handles[mode][0][0],&offsets[0][0],&params[0][0],pages);
 if(rc||termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r)){fprintf(stderr,"BATCH165 ENCODE rc=%d\n",rc);return 13;}
 uint64_t elapsed=clock_gettime_nsec_np(CLOCK_UPTIME_RAW)-start;
 if(benchmark)printf("{\"pages\":%zu,\"queries\":%zu,\"heads\":%zu,\"mixed\":%d,\"trial\":%zu,\"mode\":%zu,\"wall_us\":%.4f,\"gpu_us\":%.4f}\n",pages,q,vh,mixed,trial,mode,elapsed/1000.0,r->last_frame_gpu_nanos/1000.0);
 for(size_t page=0;page<pages;page++)for(size_t j=0;j<15;j++){
  uint32_t*raw=buffers[mode][page][j].contents;for(size_t i=0;i<4;i++)if(raw[i]!=0xdeadbeef||raw[counts[page][j]+4+i]!=0xdeadbeef)return 14;
  if(mode==1&&(j==7||j==8||j==9||j==10||j==11||j==14)){
   float*gold=(float*)buffers[0][page][j].contents+4,*got=(float*)raw+4;for(size_t i=0;i<counts[page][j];i++){if(!isfinite(gold[i])||!isfinite(got[i]))return 15;worst=fmaxf(worst,fabsf(gold[i]-got[i]));}
  }
 }
 }}
 for(size_t page=0;page<pages;page++)free(seed[page]);fprintf(stderr,"batch165_check pages=%zu queries=%zu heads=%zu mixed=%d max_abs=%g\n",pages,q,vh,mixed,worst);return worst>2e-4?16:0;
}
int main(int argc,const char**argv){@autoreleasepool{
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_CORE_NORM","1",1);unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_CORE_NORM");
 NSError*error=nil;NSString*source=[NSString stringWithContentsOfFile:@".venv-lighton-vllm-metal/engine165_batched_prefix.metal" encoding:NSUTF8StringEncoding error:&error];MTLCompileOptions*options=[[MTLCompileOptions alloc]init];options.fastMathEnabled=NO;id<MTLLibrary>library=[r->device newLibraryWithSource:source options:options error:&error];if(!library){fprintf(stderr,"COMPILE165 %s\n",error.localizedDescription.UTF8String);return 2;}
 NSString*names[5]={@"batch165_conv",@"batch165_history",@"batch165_prepare",@"batch165_recurrent",@"batch165_norm"};for(size_t i=0;i<5;i++){psos165[i]=termite_metal_make_pipeline(r->device,library,names[i]);if(!psos165[i]||psos165[i].threadExecutionWidth!=32||psos165[i].maxTotalThreadsPerThreadgroup<(i<2?256:32))return 3;}
 bool benchmark=argc==2&&strcmp(argv[1],"--benchmark")==0;size_t qs[]={2,17,22,42,64,96,120,128,432,662};
 for(size_t pages=1;pages<=8;pages*=2)for(size_t vh=16;vh<=32;vh+=16)for(size_t i=0;i<10;i++)for(size_t mixed=0;mixed<2;mixed++){@autoreleasepool{
  if(benchmark&&(qs[i]!=64&&qs[i]!=96&&qs[i]!=120&&qs[i]!=128||!mixed))continue;
  int rc=check165(r,pages,qs[i],vh,mixed,benchmark);if(rc){fprintf(stderr,"FAIL165 pages=%zu q=%zu h=%zu mixed=%zu rc=%d\n",pages,qs[i],vh,mixed,rc);return 20+rc;}
 }}
 fprintf(stderr,"BATCH165 FULL OUTPUT INDEPENDENT STATE CANARY CHECKS PASS benchmark=%d\n",benchmark);termite_metal_decode_runtime_destroy(r);return 0;
}}
'''.replace('\"engine165_batched_prefix_kernels.m\"','"engine165_batched_prefix_kernels.m"')
(v/'engine165_batched_prefix_probe.m').write_text(probe)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ps=[v/'engine165_batched_prefix.metal',v/'engine165_batched_prefix_kernels.m',v/'engine165_batched_prefix_probe.m',Path(__file__)];(v/'engine165_batched_prefix_preparation.json').write_text(json.dumps(dict(status='prepared_not_built_or_run',scope='Private five-stage prefix batch using existing convolution/history/prepare/columns4/normalization shader bodies with only page indexing. Independent state and output buffers, F32 unchanged, <=8pages/4096tokens. Serial stage prototype only; no canonical changes or production planned/alias qualification.',canonical_c_sha256=sha(path),source_sha256={str(p):sha(p)for p in ps}),indent=2)+'\n');print('165 private batched-prefix shader wrappers prepared; canonical unchanged')
