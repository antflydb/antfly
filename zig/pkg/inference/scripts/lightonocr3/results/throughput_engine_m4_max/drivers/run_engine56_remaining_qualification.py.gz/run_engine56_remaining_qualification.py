from pathlib import Path
import subprocess,sys,json,hashlib
v=Path('.venv-lighton-vllm-metal')
for name,script in [('stage-smoke','run_engine56_stage_smoke.py'),('workspace-profiles','run_engine56_profiles.py')]:
 print('START',name,flush=True)
 with Path('/private/tmp/ocr-engine56-'+name+'-driver.txt').open('w')as log:r=subprocess.run([sys.executable,str(v/script)],stdout=log,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True);assert r.returncode==0,(name,r.returncode)
for p,h in json.loads((v/'engine56-freeze.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
print('remaining qualification PASS',flush=True)
