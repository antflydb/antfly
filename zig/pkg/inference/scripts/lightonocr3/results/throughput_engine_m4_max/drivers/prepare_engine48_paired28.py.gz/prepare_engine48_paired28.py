from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine45_paired27_verify2.py').read_text().replace('engine45','engine48').replace('paired27','paired28').replace('reference27','reference28')
s=s.replace("models = sys.argv[1:] or ['4b', '08']","models = sys.argv[1:] or ['4b']")
s=s.replace("assert all(m in ['4b', '08'] for m in models)","assert models==['4b']")
s=s.replace('c, vf, prefix, wide64, prefill, gqa_off = profile[\'settings\']','c, vf, prefix, wide64, prefill, gqa_off, full64 = profile[\'settings\']')
s=s.replace("OCR_WIDE64_GATE_UP=str(int(wide64)),","OCR_WIDE64_GATE_UP=str(int(wide64)), OCR_FULL64_GATE_UP=str(int(full64)),")
s=s.replace("str(v / ('run_engine48_gqa_ffn_ablation_budget.py' if gqa_off else 'run_engine48_budget_policies.py'))","str(v / 'run_engine48_budget_policies_verify.py')")
s=s.replace("_wide64{int(wide64)}_p{prefill}","_wide64{int(wide64)}_full64{int(full64)}_p{prefill}")
needle="    if model=='4b':assert (sample['wide_gate_up_calls']>0)==record['selected_profiles'][model]['settings'][3]"
assert s.count(needle)==1
s=s.replace(needle,needle+"\n    assert (sample['full64_gate_up_calls']>0)==record['selected_profiles'][model]['settings'][6]")
a=s.index('for model in models:\n    source_audit =')
b=s.index('\nsave()\nfor model in models:',a)
s=s[:a]+"""for model in models:
    source_audit=out/'engine48_4b_full64_gate_up_primary_audit.json'
    d=json.loads(source_audit.read_text());assert d['status']=='pass'
    groups={on:[x for x in d['candidates'] if x['full64_gate_up']==on] for on in [False,True]}
    assert all(len(x)==2 for x in groups.values())
    scores={on:sum(x['pages_per_second']for x in rs)/len(rs) for on,rs in groups.items()}
    selected=max(scores,key=scores.get)
    best=groups[selected][-1]
    p=out/best['report'];assert sha(p)==best['report_sha256']
    settings=[64,2,0,selected,1,False,selected]
    record['selected_profiles'][model]=dict(settings=settings,selection='Highest mean of two native R128 runs per mode in ON/OFF/OFF/ON order; not maximum individual observation.',mean_native_control_rates={str(k):v for k,v in scores.items()},source_audit_sha256=sha(source_audit),source_reports=[dict(report=x['report'],sha256=x['report_sha256'])for x in groups[selected]],report=best['report'],report_sha256=sha(p))
""" + s[b:]
s=s.replace("4B engine48 kernel/prefill/ordinary-FFN ablations; 0.8B engine48 streaming sweep","4B engine48 native ON/OFF/OFF/ON full64 F32 matrix controls")
p=v/'run_engine48_paired28.py';assert not p.exists();p.write_text(s)
ns={};a=(v/'archive_engine10_evidence.py').read_text();exec(a[:a.index("archive('qualification'")],ns)
ns['archive']('drivers',[v/'prepare_engine48_paired28.py',p],'drivers_manifest.json')
