from pathlib import Path
import time,subprocess,sys,json,hashlib
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';o=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
while not (o/'engine71_precision_screen62_audit.json').exists() or json.loads((o/'engine71_precision_screen62_audit.json').read_text())['status']=='running':time.sleep(5)
assert json.loads((o/'engine71_precision_screen62_audit.json').read_text())['status']=='pass'
for p,h in json.loads((v/'engine73d-freeze.json').read_text()).items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
for label,cmd in [('build',[sys.executable,str(v/'build_engine73d_diagnostic.py')]),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine73d','/private/tmp/ocr-engine73d-gpu-build.txt']),('sample',[sys.executable,str(v/'run_engine73d_cpu_diagnostic63.py')])]:
 print('START DEBUG DIAGNOSTIC',label,flush=True)
 with Path('/private/tmp/ocr-engine73d-'+label+'-parent.txt').open('w')as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE DEBUG DIAGNOSTIC',label,flush=True)
print('ENGINE73D CPU DIAGNOSTIC DONE',flush=True)
