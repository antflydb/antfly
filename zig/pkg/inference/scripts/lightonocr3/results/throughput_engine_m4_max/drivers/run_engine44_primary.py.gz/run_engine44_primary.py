from pathlib import Path
import subprocess,sys
v=Path('.venv-lighton-vllm-metal')
for helper,args,label in [
 ('run_engine44_wide64_cases.py',['primary'],'wide64-primary'),
 ('run_engine44_prefill2_case.py',['primary','64','1'],'prefill2-wide64-on-primary'),
 ('run_engine44_prefill2_case.py',['primary','64','0'],'prefill2-wide64-off-primary'),
 ('run_engine44_florence_preprocess_cases_verify2.py',['primary'],'florence-preprocess-primary')]:
 print('START',helper,args,flush=True)
 with Path('/private/tmp/ocr-engine44-'+label+'-driver.txt').open('w')as log:
  r=subprocess.run([sys.executable,str(v/helper),*args],stdout=log,stderr=subprocess.STDOUT)
 print('DONE',helper,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
