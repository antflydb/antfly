from pathlib import Path
import datetime,hashlib,json,os,psutil,subprocess,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prep=json.loads((v/'engine82_real_ffn_preparation.json').read_text());assert all(sha(r/p)==h for p,h in prep['inputs'].items());assert sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')==prep['production_c_sha256']
waiters=[p for p in psutil.process_iter(['pid','cmdline'])if p.info['cmdline']and p.info['cmdline'][-1].endswith('/run_engine81_resident_primary70_verify2.py')];assert len(waiters)==1
waiter=waiters[0];waiter.suspend()
if waiter.children(recursive=True):waiter.resume();raise RuntimeError('Primary child started; do not run a probe during timings.')
audit=o/'engine82_real_ffn_probe_audit.json';assert not audit.exists();d=dict(status='preparing',primary_throughput_eligible=False,scope=prep['scope'],driver_sha256=sha(Path(__file__)),preparation_sha256=sha(v/'engine82_real_ffn_preparation.json'),inputs=prep['inputs'],paused_own_child_free_waiter_pid=waiter.pid,checks=[])
def save():audit.write_text(json.dumps(d,indent=2)+'\n')
save()
try:
 if psutil.virtual_memory().available<prep['working_estimate_bytes']+prep['os_reserve_bytes']:
  d.update(status='skipped_live_memory',available_bytes=psutil.virtual_memory().available);save()
 else:
  # Hash only selected real tensor payloads, not the whole checkpoint.
  weights=[];model=Path(prep['model_path']);before=model.stat()
  with model.open('rb')as f:
   for layer,offsets in zip(prep['layers'],prep['offsets']):
    for kind,offset in enumerate(offsets):
     f.seek(offset);remaining=2560*9216*2;h=hashlib.sha256()
     while remaining:
      chunk=f.read(min(1024**2,remaining));assert chunk;h.update(chunk);remaining-=len(chunk)
     weights.append(dict(layer=layer,kind=kind,offset=offset,bytes=2560*9216*2,sha256=h.hexdigest()))
  assert model.stat().st_mtime_ns==before.st_mtime_ns;d['real_weight_payloads']=weights;save()
  binary=v/'engine82_real_ffn_probe';assert not binary.exists();cmd=['clang','-O3','-fobjc-arc','-I','zig/pkg/inference/src/backends',str(v/'engine82_real_ffn_probe.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(binary)]
  build=Path('/private/tmp/ocr-engine82-real-ffn-build.txt');print('START REAL82 BUILD',flush=True)
  with build.open('w')as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
  d.update(build_exit_code=result.returncode,build_log_sha256=sha(build));save();assert result.returncode==0
  d['binary_sha256']=sha(binary);save()
  if psutil.virtual_memory().available<prep['working_estimate_bytes']+prep['os_reserve_bytes']:
   d.update(status='compiled_only_insufficient_memory',available_bytes=psutil.virtual_memory().available);save()
  else:
   so=Path('/private/tmp/ocr-engine82-real-ffn-stdout.txt');se=Path('/private/tmp/ocr-engine82-real-ffn-stderr.txt');assert not so.exists()and not se.exists()
   print('START REAL82 GPU',flush=True);d['status']='running';save()
   with so.open('w')as out, se.open('w')as err:result=subprocess.run([str(binary),str(v/'engine82_real_gate.metal')],stdout=out,stderr=err,env=dict(os.environ,ANTFLY_LIGHTONOCR3_THROUGHPUT='0'),timeout=900)
   records=[json.loads(line)for line in so.read_text().splitlines()if line.startswith('{"rows":')]
   d.update(exit_code=result.returncode,records=records,stdout_sha256=sha(so),stderr_sha256=sha(se));save()
   assert result.returncode==0 and len(records)==12
   assert all(x['output_bit_differences']==x['packed_differences']==x['norm_packed_differences']==0 and len(x['gpu_us'])==8 for x in records)
   assert 'REAL82 FULL REAL-WEIGHT PACKED/OUTPUT/CPU/CANARY CHECKS PASS'in se.read_text()
   d['status']='prototype_pass';save()
except BaseException as e:
 d.update(status='failed',error=repr(e));save();raise
finally:
 assert not waiter.children(recursive=True);waiter.resume();d['own_waiter_resumed']=True;save();print('REAL82 DONE',d['status'],'primary waiter resumed',flush=True)
