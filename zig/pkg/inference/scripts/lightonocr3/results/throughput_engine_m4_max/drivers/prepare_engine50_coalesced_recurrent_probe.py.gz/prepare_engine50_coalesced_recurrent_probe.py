from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
base=Path('zig/pkg/inference/src/backends/metal_kernels.m').read_text()
assert hashlib.sha256(base.encode()).hexdigest()==json.loads((v/'engine48-freeze.json').read_text())['zig/pkg/inference/src/backends/metal_kernels.m']
a=base.index('        "struct CoreParams {');b=base.index('        "kernel void termite_lightonocr3_prefill_prepare_parallel',a)
original=''.join(json.loads(x.strip())for x in base[a:b].splitlines())
body=r'''
    const uint col = uint(lane) * 4;
    float4 memory = 0;
PREVIOUS_DECL
    for (uint i=0;i<128/KSG;i++) {
        uint key=uint(simd)*(128/KSG)+i;
        float4 prior=p.initialized?*((device const float4*)(state+h*128*128+key*128+col)):float4(0);
        prior*=scales[2];
PREVIOUS_STORE
        memory+=prior*k[key];
    }
    *((threadgroup float4*)(partials+uint(simd)*128+col))=memory;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    memory=0;
    for(uint sg=0;sg<KSG;sg++)memory+=*((threadgroup float4*)(partials+sg*128+col));
    float4 delta=(float4(values[col],values[col+1],values[col+2],values[col+3])-memory)*scales[3];
    threadgroup_barrier(mem_flags::mem_threadgroup);
    float4 result=0;
    for(uint i=0;i<128/KSG;i++){
        uint key=uint(simd)*(128/KSG)+i;
PREVIOUS_LOAD
        float4 updated=prior+k[key]*delta;
        *((device float4*)(state+h*128*128+key*128+col))=updated;
        result+=updated*q[key];
    }
    *((threadgroup float4*)(partials+uint(simd)*128+col))=result;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if(simd==0){
        result=0;
        for(uint sg=0;sg<KSG;sg++)result+=*((threadgroup float4*)(partials+sg*128+col));
        *((device float4*)(core+h*128+col))=result;
        float sum=simd_sum(dot(result,result));
        float scale=1.0f/sqrt(sum/128.0f+1e-6f);
        float4 gate=*((device const float4*)(z+h*128+col)),n=*((device const float4*)(norm+col));
        *((device float4*)(output+h*128+col))=result*scale*n*(gate/(1.0f+exp(-gate)));
    }
}
'''
sources=[]
for mode,(sg,cached)in enumerate([(4,True),(8,True),(4,False)],1):
 s=original.replace('termite_lightonocr3_recurrent_parallel',f'engine50_recurrent_v{mode}')
 s=s.replace('    const uint TM = 8, SG = 128 / TM;','    threadgroup float partials[KSG * 128];')
 a=s.index('    uint col = simd * TM;')
 s=s[:a]+body
 s=s.replace('PREVIOUS_DECL','    float4 previous[128/KSG];'if cached else'')
 s=s.replace('PREVIOUS_STORE','        previous[i]=prior;'if cached else'')
 s=s.replace('PREVIOUS_LOAD','        float4 prior=previous[i];'if cached else'        float4 prior=(p.initialized?*((device const float4*)(state+h*128*128+key*128+col)):float4(0))*scales[2];')
 s=f'#define KSG {sg}\n#include <metal_stdlib>\nusing namespace metal;\n'+s
 p=v/f'engine50_recurrent_v{mode}.metal';assert not p.exists();p.write_text(s);sources.append(p)
private=base
a=private.index('static int termite_metal_lightonocr3_encode_recurrent_parallel(');b=private.index('int termite_metal_decode_runtime_qwen35_core_batch_end(',a)
part=private[a:b].replace('pipeline.maxTotalThreadsPerThreadgroup < 512','pipeline.maxTotalThreadsPerThreadgroup < engine50_threads').replace('MTLSizeMake(512, 1, 1)','MTLSizeMake(engine50_threads, 1, 1)')
private='static unsigned long engine50_threads=512;\n'+private[:a]+part+private[b:]
(v/'engine50_recurrent_runtime.m').write_text(private)
checker=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine50_recurrent_runtime.m"').replace('int main(int argc, const char **argv)','int engine50_original_main(int argc, const char **argv)')
(v/'engine50_recurrent_checks.m').write_text(checker)
literals=[ '@""\n'+''.join(' '+json.dumps(x+'\n')+'\n'for x in p.read_text().splitlines()) for p in sources ]
(v/'engine50_recurrent_sources.inc').write_text('static NSString *engine50_sources[]={\n'+',\n'.join(literals)+'\n};\n')
record=dict(status='prepared_not_built',base_c_sha256=hashlib.sha256(base.encode()).hexdigest(),scope='Private F32 recurrent memory lane mapping only, no cache layout/precision/buffer lifetime change. K-split4/8 cached register candidates and K-split4 reread candidate. Same persistent K-major/V-minor state; threads read adjacent value columns for coalesced addresses. Needs full staged reference checks and a 24-layer/64-page working-set ABBA probe before any runtime promotion.',variants=[dict(mode=1,threads=128,key_splits=4,retain_register_state=True),dict(mode=2,threads=256,key_splits=8,retain_register_state=True),dict(mode=3,threads=128,key_splits=4,retain_register_state=False)])
inputs=[*sources,v/'engine50_recurrent_runtime.m',v/'engine50_recurrent_checks.m',v/'engine50_recurrent_sources.inc']
record['inputs']={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in inputs}
(out/'engine50_recurrent_probe_preparation.json').write_text(json.dumps(record,indent=2)+'\n')
print('prepared coalesced memory mapping kernels; not compiled or run')
