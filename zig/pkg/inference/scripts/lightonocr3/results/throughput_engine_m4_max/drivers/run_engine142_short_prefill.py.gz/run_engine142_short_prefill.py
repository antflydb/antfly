from pathlib import Path
import json,hashlib,datetime,subprocess,os,psutil,time,statistics,re
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();a=o/'engine142_short_prefill_audit.json';assert not a.exists();prep=json.loads((v/'engine142_short_prefill_preparation.json').read_text());assert all(sha(Path(p))==h for p,h in prep['source_sha256'].items());assert sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')==prep['canonical_c_sha256'];assert json.loads((o/'engine139_chunk141_screen_audit.json').read_text())['status']=='screen_retired_four_profiles_completed_no_promotion'
for row in json.loads((v/'engine139_chunk141_continuing_children.json').read_text()):
 try:
  p=psutil.Process(row['pid']);assert abs(p.create_time()-row['create_time'])>.1 or p.status()==psutil.STATUS_ZOMBIE,'Owned model still active'
 except psutil.NoSuchProcess:pass
b=v/'engine142_short_prefill_probe';d=dict(status='preparing',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),preparation=prep,binary_sha256=sha(b),build_log_sha256=sha('/private/tmp/ocr-engine142-short-build.txt'),primary_throughput_eligible=False,scope='ExistingF32Q/P MPP attention eligible for2..127queries in privateCclone; no shader changes, q1decode routing unchanged.68full-output/canary/CPU/producer-consumer/fragmented-page/positive-offset/cancellation/nonfinite cases, then balanced old/new isolated stage timings. Realistic512-tokenpriorprefix, heads8/16. No own model/build/profile overlap. No whole-reader claim.')
def save():a.write_text(json.dumps(d,indent=2)+'\n')
save()
try:
 while psutil.virtual_memory().available<7*1024**3:d.update(status='waiting_reserve',available_bytes=psutil.virtual_memory().available);save();time.sleep(10)
 for phase,args in [('check',[]),('benchmark',['--benchmark'])]:
  so=Path(f'/private/tmp/ocr-engine142-short-{phase}-stdout.txt');se=Path(f'/private/tmp/ocr-engine142-short-{phase}-stderr.txt');assert not so.exists()and not se.exists();d['status']=phase+'_running';save();print('START142',phase,flush=True)
  with so.open('w')as out,se.open('w')as err:p=subprocess.run([str(b),*args],stdout=out,stderr=err,env=dict(os.environ,MTL_DEBUG_LAYER='0'),timeout=900)
  d[phase]=dict(exit_code=p.returncode,stdout_sha256=sha(so),stderr_sha256=sha(se));save();assert p.returncode==0,(phase,p.returncode)
  if phase=='check':assert 'SHORT142 FULL OUTPUT CPU FRAGMENTED OFFSET CANARY CANCEL NONFINITE CHECKS PASS'in se.read_text();assert se.read_text().count('prefill_check queries=')==68;d['numerical_case_count']=68
  else:
   assert 'SHORT142 BALANCED SHORT-PREFIX TIMINGS PASS'in se.read_text();records=[json.loads(l)for l in so.read_text().splitlines()if l.startswith('{')];assert len(records)==1080;d['timing_record_count']=len(records);d['stage_ratios']=[]
   for h,q in sorted({(x['heads'],x['queries'])for x in records}):
    xs=[x for x in records if x['heads']==h and x['queries']==q and x['trial']>=2];old=statistics.median(x['gpu_us']for x in xs if x['mode']==0);new=statistics.median(x['gpu_us']for x in xs if x['mode']==1);d['stage_ratios'].append(dict(heads=h,queries=q,old_median_gpu_us=old,new_median_gpu_us=new,old_over_new=old/new))
  save();print('DONE142',phase,flush=True)
 d['status']='numerical_and_isolated_stage_pass_no_model_promotion';save();print('SHORT142 DONE',d['stage_ratios'],flush=True)
except BaseException as e:d.update(status='failed',error=repr(e));save();raise
