from pathlib import Path
r=Path.cwd()
p=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=p.read_text().replace('    uint64_t lightonocr3_wide_projection_tile_calls;','    uint64_t lightonocr3_wide_projection_tile_calls;\n    uint64_t argmax_on_frame_calls;',1)
a='            if (encode_rc != 0) return encode_rc;\n        } else {';assert s.count(a)==1;s=s.replace(a,'            if (encode_rc != 0) return encode_rc;\n            runtime->argmax_on_frame_calls = termite_metal_u64_saturating_add(runtime->argmax_on_frame_calls, 1);\n        } else {',1)
s+='\nuint64_t termite_metal_decode_runtime_argmax_on_frame_calls(termite_metal_decode_runtime *runtime) {\n    return runtime != NULL ? runtime->argmax_on_frame_calls : 0;\n}\n';p.write_text(s)
p=r/'zig/pkg/inference/src/backends/metal_runtime.zig';s=p.read_text();s+='\npub extern fn termite_metal_decode_runtime_argmax_on_frame_calls(runtime: ?*RawMetalDecodeRuntime) u64;\n';p.write_text(s)
p=r/'zig/pkg/inference/src/ops/metal_compute.zig';s=p.read_text();a='    pub fn lightOnPreparedBlockCount(cb: *const ops.ComputeBackend) usize {';assert a in s;s=s.replace(a,'''    /// Reserve token readback before a forward can mutate recurrent/KV state.
    pub fn reserveLightOnFrameArgmax(cb: *const ops.ComputeBackend, rows: usize, vocab: usize) bool {
        if (cb.kind() != .metal) return false;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return self.lightonocr3_projections and metal_runtime_mod.qualifiedM4DeviceDefault() and
            metal_runtime_mod.reserveArgmaxRows(self.provider_impl, rows, vocab);
    }

    pub fn argmaxOnFrameCount(cb: *const ops.ComputeBackend) u64 {
        if (cb.kind() != .metal) return 0;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return metal_runtime_mod.termite_metal_decode_runtime_argmax_on_frame_calls(self.provider_impl.raw_decode_runtime);
    }

    /// Linear implementations may close their own encoder while retaining the
    /// caller's command buffer. Token selection must reopen it to consume that
    /// buffer, otherwise argmax would flush and submit a separate command buffer.
    pub fn ensureFrameArgmaxScope(cb: *const ops.ComputeBackend) !void {
        if (cb.kind() != .metal) return error.RuntimeUnavailable;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        const raw = self.provider_impl.raw_decode_runtime orelse return error.RuntimeUnavailable;
        metal_runtime_mod.beginPlannedComputeScope(raw, @backingInt(metal_runtime_mod.ComputeSource.quant_linear), .attention_project) catch |err| switch (err) {
            error.PlannedScopeActive => {},
            else => return err,
        };
    }

'''+a,1);p.write_text(s)
p=r/'zig/pkg/inference/src/pipelines/generation.zig';s=p.read_text().replace('    prepared_lighton_decode: bool = false,','    prepared_lighton_decode: bool = false,\n    single_frame_lighton_decode: bool = false,',1)
a='        if (all_greedy) {\n';assert s.count(a)==1;s=s.replace(a,a+'''            if (comptime build_options.enable_metal) {
                const M = @import("../ops/metal_compute.zig").MetalCompute;
                if (self.single_frame_lighton_decode and self.gpt_config.hasQwen35VisionArchitectureContract() and claimed.len <= 16 and
                    !self.cb.decoderRuntimeHasActiveFrame() and M.reserveLightOnFrameArgmax(&self.cb, claimed.len, self.gpt_config.vocab_size))
                {
                    const head = try self.graphWeight("lm_head.weight");
                    defer self.cb.free(head);
                    if (try self.cb.decoderRuntimeBeginFrame()) {
                        defer self.cb.decoderRuntimeCancelFrame() catch {};
                        try self.cb.decoderRuntimeSetActiveFrameRegime(.decode);
                        const before_frames = self.cb.debugTimingSnapshot().provider.decoder_runtime_frame_submits;
                        const before_argmax = M.argmaxOnFrameCount(&self.cb);
                        try self.cb.checkExecutionControl();
                        const hidden = try gpt_arch.forwardHiddenTensorWithCudaReplay(&self.cb, self.allocator, self.gpt_config, input_ids, claimed.len, 1, &owned_ctx.context, "gpt.metal_batch_decode");
                        defer self.cb.free(hidden);
                        const logits = try self.cb.linearNoBias(hidden, head, claimed.len, self.gpt_config.hidden_size, self.gpt_config.vocab_size);
                        defer self.cb.free(logits);
                        try M.ensureFrameArgmaxScope(&self.cb);
                        // Never replay a forward after it has updated recurrent/KV
                        // state. A failure must fail this claimed step instead.
                        const tokens = try self.cb.decoderRuntimeArgmaxRowsSuppress(logits, 0, claimed.len, self.gpt_config.vocab_size, self.gpt_config.suppressTokenIds(), self.allocator) orelse return error.ResidentImageOperationUnavailable;
                        errdefer self.allocator.free(tokens);
                        if (tokens.len != claimed.len) return error.InvalidBatchDecodeState;
                        const frames = self.cb.debugTimingSnapshot().provider.decoder_runtime_frame_submits -| before_frames;
                        const on_frame = M.argmaxOnFrameCount(&self.cb) -| before_argmax;
                        if (platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3")) {
                            std.debug.print("LIGHTONOCR3 single_frame_step rows={d} submits={d} argmax_on_frame={d}\\n", .{ claimed.len, frames, on_frame });
                        }
                        try self.cb.checkExecutionControl();
                        return .{ .logits = null, .greedy_tokens = tokens, .max_query_seq_len = 1 };
                    }
                }
            }

''',1);p.write_text(s)
p=r/'zig/pkg/inference/src/server/server.zig';s=p.read_text();s=s.replace('            epoch_auxiliary: bool = false,','            epoch_auxiliary: bool = false,\n            single_frame: bool = false,',1).replace('                    .epoch_auxiliary = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_EPOCH_AUX"),','                    .epoch_auxiliary = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_EPOCH_AUX"),\n                    .single_frame = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_SINGLE_FRAME"),',1).replace('                .prepared_lighton_decode = ctx.features.prepared,','                .prepared_lighton_decode = ctx.features.prepared,\n                .single_frame_lighton_decode = ctx.features.single_frame,',1).replace('            .prepared_lighton_decode = prepared_decode,','            .prepared_lighton_decode = prepared_decode,\n            .single_frame_lighton_decode = ctx.features.single_frame,',1);p.write_text(s)
