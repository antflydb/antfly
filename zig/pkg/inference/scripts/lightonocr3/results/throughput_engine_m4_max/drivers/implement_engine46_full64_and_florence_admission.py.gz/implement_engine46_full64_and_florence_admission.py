from pathlib import Path
import hashlib,json,subprocess
v=Path('.venv-lighton-vllm-metal');base=Path('zig/pkg/inference/src')
for p,h in json.loads((v/'engine45-freeze.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
subprocess.run(['git','apply','--check',str(v/'engine46_florence_incremental_admission_fallback_verified.patch')],check=True)
subprocess.run(['git','apply',str(v/'engine46_florence_incremental_admission_fallback_verified.patch')],check=True)
def replace(p,old,new):
 s=p.read_text();assert s.count(old)==1,(p,old,s.count(old));p.write_text(s.replace(old,new))
c=base/'backends/metal_kernels.m'
replace(c,'    uint64_t lightonocr3_wide_gate_up_calls;','    uint64_t lightonocr3_wide_gate_up_calls;\n    uint64_t lightonocr3_full64_gate_up_calls;')
replace(c,'''    // The fully occupied 4B cohort retains its vectorized generic kernel.
    // Use the smaller tile for intermediate tails and a 64-row tile for
    // partial wide cohorts. Keep this measured replacement explicit.
    if (rows >= 17 && rows < 64 && in_dim == 2560 && out_dim == 9216 &&''','''    // Preserve the vectorized generic default at exactly 64 rows. A separate
    // opt-in can assess the F32 matrix tile there without changing precision.
    // Intermediate tails retain their independently qualified smaller tile.
    if (rows >= 17 && rows <= 64 &&
        (rows < 64 || termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP"))) &&
        in_dim == 2560 && out_dim == 9216 &&''')
needle='''            runtime->lightonocr3_wide_gate_up_calls =
                termite_metal_u64_saturating_add(runtime->lightonocr3_wide_gate_up_calls, 1);
        }
        else if (small == runtime->lightonocr3_gate_up_wide32_pipeline'''
replace(c,needle,'''            runtime->lightonocr3_wide_gate_up_calls =
                termite_metal_u64_saturating_add(runtime->lightonocr3_wide_gate_up_calls, 1);
            if (rows == 64 && in_dim == 2560 && out_dim == 9216)
                runtime->lightonocr3_full64_gate_up_calls =
                    termite_metal_u64_saturating_add(runtime->lightonocr3_full64_gate_up_calls, 1);
        }
        else if (small == runtime->lightonocr3_gate_up_wide32_pipeline''')
needle='''uint64_t termite_metal_decode_runtime_lighton_wide_gate_up_calls(termite_metal_decode_runtime *runtime) {
    return runtime != NULL ? runtime->lightonocr3_wide_gate_up_calls : 0;
}'''
replace(c,needle,needle+'''\n\nuint64_t termite_metal_decode_runtime_lighton_full64_gate_up_calls(termite_metal_decode_runtime *runtime) {
    return runtime != NULL ? runtime->lightonocr3_full64_gate_up_calls : 0;
}''')
p=base/'backends/metal_runtime.zig';needle='pub extern fn termite_metal_decode_runtime_lighton_wide_gate_up_calls(runtime: ?*RawMetalDecodeRuntime) u64;'
replace(p,needle,needle+'\npub extern fn termite_metal_decode_runtime_lighton_full64_gate_up_calls(runtime: ?*RawMetalDecodeRuntime) u64;')
p=base/'ops/metal_compute.zig'
replace(p,'    lighton_wide_gate_up_start: u64 = 0,','    lighton_wide_gate_up_start: u64 = 0,\n    lighton_full64_gate_up_start: u64 = 0,')
needle='        self.lighton_wide_gate_up_start = metal_runtime_mod.termite_metal_decode_runtime_lighton_wide_gate_up_calls(raw);'
replace(p,needle,needle+'\n        self.lighton_full64_gate_up_start = metal_runtime_mod.termite_metal_decode_runtime_lighton_full64_gate_up_calls(raw);')
needle='''    pub fn lightOnWideGateUpCalls(cb: *const ops.ComputeBackend) u64 {
        if (cb.kind() != .metal) return 0;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return metal_runtime_mod.termite_metal_decode_runtime_lighton_wide_gate_up_calls(self.provider_impl.raw_decode_runtime) -| self.lighton_wide_gate_up_start;
    }'''
replace(p,needle,needle+'''\n\n    pub fn lightOnFull64GateUpCalls(cb: *const ops.ComputeBackend) u64 {
        if (cb.kind() != .metal) return 0;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return metal_runtime_mod.termite_metal_decode_runtime_lighton_full64_gate_up_calls(self.provider_impl.raw_decode_runtime) -| self.lighton_full64_gate_up_start;
    }''')
p=base/'server/server.zig';needle='                    std.debug.print("LIGHTONOCR3 wide_gate_up_calls={d}\\n", .{wide_gate_up});'
replace(p,needle,needle+'''
                    const full64_gate_up = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnFull64GateUpCalls(&cb) else 0;
                    std.debug.print("LIGHTONOCR3 full64_gate_up_calls={d}\\n", .{full64_gate_up});''')
p=base/'architectures/gpt.zig';needle='(isDecodeStep(decode_context) and total <= 64 and (hidden_size != 2560 or total < 64)))'
replace(p,needle,'''(isDecodeStep(decode_context) and total <= 64 and
                    (hidden_size != 2560 or total < 64 or platform.env.getenvBool("TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP")))))''')
# The C numerical suite independently qualifies both flags, missing-PSO
# rollback and actual selection counters at exactly 64 rows.
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m')
replace(p,'''            (rows >= 17 && rows < 64 && in == 2560 &&
                termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP")));''','''            (rows >= 17 && rows <= 64 && in == 2560 &&
                (rows < 64 || termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP"))) &&
                termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP")));''')
replace(p,'                const uint64_t before_wide = r->lightonocr3_wide_gate_up_calls;','                const uint64_t before_wide = r->lightonocr3_wide_gate_up_calls;\n                const uint64_t before_full64 = r->lightonocr3_full64_gate_up_calls;')
needle='                if (r->lightonocr3_wide_gate_up_calls - before_wide != (mode == 1 && qualified ? 1u : 0u)) return 75;'
replace(p,needle,needle+'''
                if (r->lightonocr3_full64_gate_up_calls - before_full64 !=
                    (mode == 1 && qualified && rows == 64 && in == 2560 ? 1u : 0u)) return 76;''')
needle='''        if (argc == 2 && (strcmp(argv[1], "--check-wide-gate-up") == 0 ||
                          strcmp(argv[1], "--check-wide-gate-up-large64") == 0)) {
            if (strcmp(argv[1], "--check-wide-gate-up-large64") == 0)'''
replace(p,needle,'''        if (argc == 2 && (strcmp(argv[1], "--check-wide-gate-up") == 0 ||
                          strcmp(argv[1], "--check-wide-gate-up-large64") == 0 ||
                          strcmp(argv[1], "--check-wide-gate-up-full64") == 0)) {
            const bool full64 = strcmp(argv[1], "--check-wide-gate-up-full64") == 0;
            setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP", full64 ? "1" : "0", 1);
            if (strcmp(argv[1], "--check-wide-gate-up-large64") == 0 || full64)''')
replace(p,'''                termite_metal_lightonocr3_batch_gate_up_pipeline(r, 64, 2560, 9216) != nil ||''','''                ((termite_metal_lightonocr3_batch_gate_up_pipeline(r, 64, 2560, 9216) != nil) != (hybrid && full64)) ||''')
# Benchmark controls explicitly reset both rollout knobs for every subprocess.
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py')
p.write_bytes((v/'engine46_benchmark_concurrency.proposal.py').read_bytes())
needle='''    env["TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP"] = (
        "1" if args.wide64_gate_up else "0"
    )'''
replace(p,needle,needle+'''
    env["TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP"] = (
        "1" if args.full64_gate_up else "0"
    )''')
replace(p,'    parser.add_argument("--wide64-gate-up", action="store_true")','    parser.add_argument("--wide64-gate-up", action="store_true")\n    parser.add_argument("--full64-gate-up", action="store_true")')
replace(p,'                        "wide_gate_up_calls",','                        "wide_gate_up_calls",\n                        "full64_gate_up_calls",')
print('Applied engine46: F32 full64 opt-in/counter plus incremental Florence admission and four boundary tests.')
