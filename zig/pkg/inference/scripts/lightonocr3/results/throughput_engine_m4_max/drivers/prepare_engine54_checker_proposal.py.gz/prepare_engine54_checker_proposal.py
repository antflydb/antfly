from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');p='zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m';dest=v/'engine54-product-proposal'
s=Path(p).read_text();needle='int main(int argc, const char **argv) {';assert s.count(needle)==1
s=s.replace(needle,(v/'engine54_batch_argmax_checks.inc').read_text()+needle)
needle='        if (argc == 2 && strcmp(argv[1], "--check-frame-metadata") == 0) {'
s=s.replace(needle,'''        if (argc == 2 && strcmp(argv[1], "--check-batch-argmax") == 0) {
            int rc = batch_argmax_check(r);
            termite_metal_decode_runtime_destroy(r);
            return rc;
        }
'''+needle)
target=dest/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(s)
# Private C-only compilation uses the proposal runtime without applying it.
(v/'engine54_product_checks.m').write_text(s.replace('#include "../../src/backends/metal_kernels.m"','#include "engine54-product-proposal/zig/pkg/inference/src/backends/metal_kernels.m"'))
m=json.loads((v/'engine54_product_proposal.json').read_text());m['files'][p]=hashlib.sha256(target.read_bytes()).hexdigest();(v/'engine54_product_proposal_with_checker.json').write_text(json.dumps(m,indent=2)+'\n')
