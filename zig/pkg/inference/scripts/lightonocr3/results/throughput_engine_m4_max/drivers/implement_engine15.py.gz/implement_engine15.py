from pathlib import Path
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text()
s=s.replace('typedef struct termite_metal_decode_runtime {','struct termite_metal_lighton_attention_batch;\nstatic void termite_metal_lighton_attention_batch_abort(struct termite_metal_decode_runtime *runtime);\n\ntypedef struct termite_metal_decode_runtime {',1)
s=s.replace('    uint64_t lightonocr3_gqa_split_calls;', '''    struct termite_metal_lighton_attention_batch *lighton_attention_batch;
    id<MTLBuffer> lighton_attention_batch_scratch[2];
    uint64_t lighton_attention_batch_calls;
    uint64_t lighton_attention_batch_rows;
    uint64_t lightonocr3_gqa_split_calls;''',1)
assert 'lighton_attention_batch_scratch[2]' in s
# Cleanup before runtime's other scratch buffers.
pos=s.index('void termite_metal_decode_runtime_destroy(');a=s[:pos];b=s[pos:];b=b.replace('    runtime->attention_decode_gqa_split_scratch_buffer_alt = nil;', '''    termite_metal_lighton_attention_batch_abort(runtime);
    runtime->lighton_attention_batch_scratch[0] = nil;
    runtime->lighton_attention_batch_scratch[1] = nil;
    runtime->attention_decode_gqa_split_scratch_buffer_alt = nil;''',1);s=a+b
# Records only live across one CPU batch call. Buffer references survive temporary views.
mark='static bool termite_metal_decode_gqa_split_schedule_for_variant('
idx=s.index(mark)
code='''// Bounded decode-only collector. Each page keeps its own parameters and
// physical KV pages; only command encoding and disjoint split scratch are shared.
#define TERMITE_METAL_LIGHTON_BATCH_ROWS 16u
#define TERMITE_METAL_LIGHTON_BATCH_SCRATCH (9u * 1024u * 1024u)
typedef struct termite_metal_lighton_attention_record {
    termite_metal_decode_runtime *owner;
    id<MTLBuffer> q, k, v, output;
    size_t q_offset, output_offset, scratch_offset;
    uint32_t blocks[256];
    termite_metal_paged_attention_params params;
    termite_metal_decode_gqa_split_launch launch;
} termite_metal_lighton_attention_record;
typedef struct termite_metal_lighton_attention_batch {
    size_t count, scratch_bytes;
    id<MTLBuffer> scratch;
    termite_metal_lighton_attention_record rows[TERMITE_METAL_LIGHTON_BATCH_ROWS];
} termite_metal_lighton_attention_batch;

static void termite_metal_lighton_attention_batch_abort(termite_metal_decode_runtime *runtime) {
    if (runtime == NULL || runtime->lighton_attention_batch == NULL) return;
    termite_metal_lighton_attention_batch *batch = runtime->lighton_attention_batch;
    runtime->lighton_attention_batch = NULL;
    for (size_t i = 0; i < batch->count; ++i) {
        batch->rows[i].q = nil;
        batch->rows[i].k = nil;
        batch->rows[i].v = nil;
        batch->rows[i].output = nil;
    }
    batch->scratch = nil;
    free(batch);
}

int termite_metal_decode_runtime_lighton_attention_batch_begin(termite_metal_decode_runtime *runtime) {
    if (runtime == NULL || runtime->active_frame_cb == nil ||
        runtime->lighton_attention_batch != NULL || !termite_metal_qualified_m4_device_default()) return -1;
    const size_t bank = runtime->active_frame_decode_gqa_split_scratch_slot & 1u;
    if (runtime->lighton_attention_batch_scratch[bank] == nil) {
        runtime->lighton_attention_batch_scratch[bank] = antfly_observe_metal_buffer(
            [runtime->device newBufferWithLength:TERMITE_METAL_LIGHTON_BATCH_SCRATCH options:MTLResourceStorageModePrivate],
            ANTFLY_BUFFER_UNINITIALIZED);
        if (runtime->lighton_attention_batch_scratch[bank] == nil) return -2;
    }
    termite_metal_lighton_attention_batch *batch = calloc(1, sizeof(*batch));
    if (batch == NULL) return -3;
    batch->scratch = runtime->lighton_attention_batch_scratch[bank];
    runtime->lighton_attention_batch = batch;
    return 0;
}

void termite_metal_decode_runtime_lighton_attention_batch_abort(termite_metal_decode_runtime *runtime) {
    termite_metal_lighton_attention_batch_abort(runtime);
}

int termite_metal_decode_runtime_lighton_attention_batch_end(termite_metal_decode_runtime *runtime) {
    if (runtime == NULL || runtime->active_frame_cb == nil || runtime->lighton_attention_batch == NULL) return -1;
    termite_metal_lighton_attention_batch *batch = runtime->lighton_attention_batch;
    if (batch->count == 0u) {
        termite_metal_lighton_attention_batch_abort(runtime);
        return 0;
    }
    // Finish all Q producers and KV seeds before concurrent read-only attention.
    termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(runtime);
    id<MTLComputeCommandEncoder> encoder = [runtime->active_frame_cb computeCommandEncoderWithDispatchType:MTLDispatchTypeConcurrent];
    if (encoder == nil) return -2;
    const float zero_sink = 0.0f;
    for (size_t i = 0; i < batch->count; ++i) {
        termite_metal_lighton_attention_record *r = &batch->rows[i];
        [encoder setComputePipelineState:r->owner->lightonocr3_gqa_split_stage_pipeline];
        [encoder setBuffer:r->q offset:r->q_offset atIndex:0];
        [encoder setBuffer:r->k offset:0 atIndex:1];
        [encoder setBuffer:r->v offset:0 atIndex:2];
        [encoder setBytes:r->blocks length:r->params.block_count * sizeof(uint32_t) atIndex:3];
        [encoder setBytes:&zero_sink length:sizeof(zero_sink) atIndex:4];
        [encoder setBuffer:batch->scratch offset:r->scratch_offset atIndex:5];
        [encoder setBytes:&r->params length:sizeof(r->params) atIndex:6];
        [encoder setBytes:&r->launch.params length:sizeof(r->launch.params) atIndex:7];
        [encoder setThreadgroupMemoryLength:TERMITE_METAL_DECODE_GQA_SPLIT_STAGE_MEMORY_BYTES(r->params.head_dim) atIndex:0];
        [encoder dispatchThreadgroups:MTLSizeMake(1, r->params.num_kv_heads, r->launch.params.split_count)
            threadsPerThreadgroup:MTLSizeMake(r->launch.schedule.stage_threads, 1, 1)];
    }
    [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
    for (size_t i = 0; i < batch->count; ++i) {
        termite_metal_lighton_attention_record *r = &batch->rows[i];
        [encoder setComputePipelineState:r->owner->lightonocr3_gqa_split_reduce_pipeline];
        [encoder setBuffer:batch->scratch offset:r->scratch_offset atIndex:0];
        [encoder setBuffer:r->output offset:r->output_offset atIndex:1];
        [encoder setBytes:&r->params length:sizeof(r->params) atIndex:2];
        [encoder setBytes:&r->launch.params length:sizeof(r->launch.params) atIndex:3];
        [encoder dispatchThreadgroups:MTLSizeMake(1, r->params.num_heads, 1)
            threadsPerThreadgroup:MTLSizeMake(r->launch.schedule.reduce_threads, 1, 1)];
        r->owner->lightonocr3_gqa_split_calls += 1;
    }
    [encoder endEncoding];
    runtime->lighton_attention_batch_calls += 1;
    runtime->lighton_attention_batch_rows += batch->count;
    termite_metal_lighton_attention_batch_abort(runtime);
    return 0;
}

void termite_metal_decode_runtime_lighton_attention_batch_stats(termite_metal_decode_runtime *runtime, uint64_t *out) {
    if (out == NULL) return;
    out[0] = runtime != NULL ? runtime->lighton_attention_batch_calls : 0;
    out[1] = runtime != NULL ? runtime->lighton_attention_batch_rows : 0;
}

'''
s=s[:idx]+code+s[idx:]
# Only ex implementation: validate output and collect AFTER canonical metadata/eligibility checks,
# BEFORE any attention encoded. Seed remains exactly once in the caller.
pos=s.index('static int termite_metal_decode_runtime_encode_paged_attention_slot_ex(');a=s[:pos];b=s[pos:]
old='''    if (!planned_encoder) {
        encoder = termite_metal_tracked_compute_command_encoder_for(command_buffer, TERMITE_METAL_COMPUTE_SOURCE_ATTENTION);
        if (encoder == nil) return -15;
    }
''';assert old in b;b=b.replace(old,'',1)
needle='    if (decode_gqa_split_strict_failure) return -15;'
insert='''
    if (frame_runtime->lighton_attention_batch != NULL && use_decode_gqa_split && split_launch.lightonocr3 &&
        q_len == 1u && needed_blocks <= 256u) {
        termite_metal_lighton_attention_batch *batch = frame_runtime->lighton_attention_batch;
        const size_t scratch_offset = (batch->scratch_bytes + 255u) & ~(size_t)255u;
        if (batch->count >= TERMITE_METAL_LIGHTON_BATCH_ROWS ||
            scratch_offset > batch->scratch.length || split_launch.scratch_bytes > batch->scratch.length - scratch_offset ||
            q_offset > q_buffer.length || q_bytes > q_buffer.length - q_offset ||
            output_offset > output_buffer.length || q_bytes > output_buffer.length - output_offset) return -15;
        termite_metal_lighton_attention_record *r = &batch->rows[batch->count++];
        r->owner = runtime;
        r->q = q_buffer;
        r->k = runtime->attention_span_encoded_key_buffers[slot];
        r->v = runtime->attention_span_v_buffers[slot];
        r->output = output_buffer;
        r->q_offset = q_offset;
        r->output_offset = output_offset;
        r->scratch_offset = scratch_offset;
        r->params = params;
        r->launch = split_launch;
        memcpy(r->blocks, block_table, needed_blocks * sizeof(uint32_t));
        batch->scratch_bytes = scratch_offset + split_launch.scratch_bytes;
        return 0;
    }
    if (!planned_encoder) {
        encoder = termite_metal_tracked_compute_command_encoder_for(command_buffer, TERMITE_METAL_COMPUTE_SOURCE_ATTENTION);
        if (encoder == nil) return -15;
    }
'''
assert needle in b;b=b.replace(needle,needle+insert,1);s=a+b;p.write_text(s)
