from pathlib import Path
import subprocess,sys,time
v=Path('.venv-lighton-vllm-metal');p=Path('/private/tmp/ocr-engine69-qualification-parent.txt')
while True:
 s=p.read_text()if p.exists()else''
 if 'ENGINE69 QUALIFICATION DONE' in s:break
 if 'Traceback' in s:raise RuntimeError('qualification failed; no performance run')
 time.sleep(5)
with Path('/private/tmp/ocr-engine69-prefill51-parent.txt').open('w')as log:
 subprocess.run([sys.executable,str(v/'run_engine69_prefill_screen51.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
print('ENGINE69 PREFILL SCREEN DONE',flush=True)
