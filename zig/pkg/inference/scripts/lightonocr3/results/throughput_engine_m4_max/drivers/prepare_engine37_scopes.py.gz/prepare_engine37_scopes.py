from pathlib import Path
import hashlib
import json
import sys

# This prepares the next revision only after engine36 primary jobs finish.
assert sys.argv[1:] == ["--apply"]
root = Path.cwd()
freeze = json.loads((root / ".venv-lighton-vllm-metal/engine36-freeze.json").read_text())
for name, expected in freeze.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
edits = {}


def replace(name, old, new):
    source = edits.get(name, (root / name).read_text())
    assert source.count(old) == 1, (name, old[:100], source.count(old))
    edits[name] = source.replace(old, new, 1)


def enter(name, function, body):
    source = edits.get(name, (root / name).read_text())
    start = source.index(function)
    at = source.index("{\n", start) + 2
    edits[name] = source[:at] + body + source[at:]


mc = "zig/pkg/inference/src/ops/metal_compute.zig"
replace(mc, "    lighton_token_encoder_scope_steps: u64 = 0,\n",
        "    lighton_token_encoder_scope_steps: u64 = 0,\n    ocr_encoder_scope_opens: [3]u64 = @splat(0),\n")
replace(mc, "        self.lighton_token_encoder_scope_steps = 0;\n",
        "        self.lighton_token_encoder_scope_steps = 0;\n        self.ocr_encoder_scope_opens = @splat(0);\n")
replace(mc, "    pub fn noteLightOnTokenEncoderScope(cb: *const ops.ComputeBackend) void {\n", r'''    pub const OcrEncoderStage = enum { vision, prefill, florence };

    /// An owned scope must end before returning from its block. Existing
    /// scopes are borrowed, and unsupported backends retain their normal path.
    pub fn beginOcrEncoderScope(cb: *const ops.ComputeBackend, stage: OcrEncoderStage) !bool {
        if (comptime !build_options.enable_metal) return false;
        if (cb.vtable.decoderRuntimeBeginPlannedComputeScope != &decoderRuntimeBeginPlannedComputeScopeOp or
            cb.kind() != .metal or !metal_runtime_mod.qualifiedM4DeviceDefault() or
            !getenvBool("ANTFLY_OCR_ENCODER_SCOPES")) return false;
        const owned = try cb.decoderRuntimeBeginPlannedComputeScope();
        if (owned) {
            const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
            self.ocr_encoder_scope_opens[@intFromEnum(stage)] +|= 1;
        }
        return owned;
    }

    pub fn ocrEncoderScopeOpens(cb: *const ops.ComputeBackend) [3]u64 {
        if (comptime !build_options.enable_metal) return @splat(0);
        if (cb.vtable.decoderRuntimeBeginPlannedComputeScope != &decoderRuntimeBeginPlannedComputeScopeOp or
            cb.kind() != .metal) return @splat(0);
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return self.ocr_encoder_scope_opens;
    }

    pub fn noteLightOnTokenEncoderScope(cb: *const ops.ComputeBackend) void {
''')
qwen = "zig/pkg/inference/src/architectures/qwen3vl_projector.zig"
enter(qwen, "fn encoderBlock(", r'''    const owns_encoder_scope = if (cfg.is_qwen35)
        try metal_compute_mod.MetalCompute.beginOcrEncoderScope(cb, .vision)
    else
        false;
    defer if (owns_encoder_scope) cb.decoderRuntimeEndPlannedComputeScope();
''')
gpt = "zig/pkg/inference/src/architectures/gpt.zig"
replace(gpt, "    const result = try decoderBlockImpl(\n", r'''    const owns_ocr_prefill_scope = if (config.hasQwen35VisionArchitectureContract() and
        decode_context != null and decode_context.?.attention_mode == .paged_prefill and
        decode_context.?.query_sequence_len > 1)
        try metal_compute_mod.MetalCompute.beginOcrEncoderScope(cb, .prefill)
    else
        false;
    defer if (owns_ocr_prefill_scope) cb.decoderRuntimeEndPlannedComputeScope();

    const result = try decoderBlockImpl(
''')
florence = "zig/pkg/inference/src/architectures/florence.zig"
replace(florence, 'const ops = @import("../ops/ops.zig");\n',
        'const ops = @import("../ops/ops.zig");\nconst metal_compute_mod = @import("../ops/metal_compute.zig");\n')
enter(florence, "fn daViTBlockFramed(", r'''    const owns_encoder_scope = try metal_compute_mod.MetalCompute.beginOcrEncoderScope(cb, .florence);
    defer if (owns_encoder_scope) cb.decoderRuntimeEndPlannedComputeScope();
''')
# The DaViT wrapper can itself own a frame. Open its scope after that frame,
# while retaining per-block balancing when a stage owns the surrounding frame.
source = edits[florence]
block_start = source.index("fn daViTBlockFramed(")
block_end = source.index("\nfn ", block_start + 4)
block = source[block_start:block_end]
scope = '''    const owns_encoder_scope = try metal_compute_mod.MetalCompute.beginOcrEncoderScope(cb, .florence);
    defer if (owns_encoder_scope) cb.decoderRuntimeEndPlannedComputeScope();
'''
assert block.count(scope) == 1
block = block.replace(scope, "", 1)
marker = "    errdefer if (frame_active) cb.decoderRuntimeCancelFrame() catch {};\n"
assert block.count(marker) == 1
block = block.replace(marker, marker + "\n" + scope, 1)
edits[florence] = source[:block_start] + block + source[block_end:]
enter(florence, "fn encoderBlock(", r'''    const owns_encoder_scope = try metal_compute_mod.MetalCompute.beginOcrEncoderScope(cb, .florence);
    defer if (owns_encoder_scope) cb.decoderRuntimeEndPlannedComputeScope();
''')
source = edits[florence]
start = source.index("pub fn encoderForwardTensor(")
at = source.index("    try control_cb.checkExecutionControl();", start)
source = source[:at] + r'''    const encoder_scope_before = metal_compute_mod.MetalCompute.ocrEncoderScopeOpens(cb)[2];
    defer if (platform.env.getenvBool("ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX")) {
        const opens = metal_compute_mod.MetalCompute.ocrEncoderScopeOpens(cb)[2] -| encoder_scope_before;
        std.debug.print("FLORENCE2 encoder_scope_opens={d}\n", .{opens});
    };
''' + source[at:]
edits[florence] = source
server = "zig/pkg/inference/src/server/server.zig"
replace(server, r'''                    std.debug.print("LIGHTONOCR3 token_encoder_scope_steps={d}\n", .{token_scopes});
''', r'''                    std.debug.print("LIGHTONOCR3 token_encoder_scope_steps={d}\n", .{token_scopes});
                    const encoder_scopes = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.ocrEncoderScopeOpens(&cb) else @as([3]u64, @splat(0));
                    std.debug.print("LIGHTONOCR3 vision_encoder_scope_opens={d} prefill_encoder_scope_opens={d}\n", .{ encoder_scopes[0], encoder_scopes[1] });
''')
bench = "zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py"
replace(bench, '            "ANTFLY_LIGHTONOCR3_SHARED_DECODER_SCRATCH",\n',
        '            "ANTFLY_LIGHTONOCR3_SHARED_DECODER_SCRATCH",\n            "ANTFLY_OCR_ENCODER_SCOPES",\n')
replace(bench, '    env["ANTFLY_LIGHTONOCR3_PHYSICAL32"] = "1" if args.physical32 else "0"\n',
        '    env["ANTFLY_OCR_ENCODER_SCOPES"] = "1" if args.ocr_encoder_scopes else "0"\n    env["ANTFLY_LIGHTONOCR3_PHYSICAL32"] = "1" if args.physical32 else "0"\n')
replace(bench, '    parser.add_argument("--share-decoder-scratch", action="store_true")\n',
        '    parser.add_argument("--share-decoder-scratch", action="store_true")\n    parser.add_argument("--ocr-encoder-scopes", action="store_true")\n')

edits[mc] += r'''

test "LightOnOCR3 encoder scope counters reject borrowed backend wrappers" {
    if (comptime !build_options.enable_metal) return error.SkipZigTest;
    const probe = try std.testing.allocator.create(MetalCompute);
    defer std.testing.allocator.destroy(probe);
    probe.* = undefined;
    probe.ocr_encoder_scope_opens = .{ 91, 92, 93 };
    const Borrowed = struct {
        fn begin(_: *anyopaque) anyerror!bool {
            return true;
        }
    };
    var table = MetalCompute.vtable_impl;
    table.decoderRuntimeBeginPlannedComputeScope = &Borrowed.begin;
    const cb = ops.ComputeBackend{ .ptr = probe, .vtable = &table };
    try std.testing.expect(!try MetalCompute.beginOcrEncoderScope(&cb, .vision));
    try std.testing.expectEqualDeep([3]u64{ 0, 0, 0 }, MetalCompute.ocrEncoderScopeOpens(&cb));
    try std.testing.expectEqualDeep([3]u64{ 91, 92, 93 }, probe.ocr_encoder_scope_opens);
}
'''

for name, source in edits.items():
    (root / name).write_text(source)
    print(name)
