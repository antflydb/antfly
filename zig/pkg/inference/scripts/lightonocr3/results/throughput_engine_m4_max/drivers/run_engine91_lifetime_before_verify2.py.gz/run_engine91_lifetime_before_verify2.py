from pathlib import Path
import hashlib,json,subprocess,os,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while True:
 p=Path('/private/tmp/ocr-engine90-qualification-parent.txt');s=p.read_text()if p.exists()else''
 if 'ENGINE90 QUALIFICATION DONE'in s:break
 if 'Traceback'in s or any('DONE ENGINE90 '+k+' 1'in s for k in ['image','gpu','cpu','finalize']):raise RuntimeError(s[-3000:])
 time.sleep(5)
assert sha(v/'engine91_before_kernels.m')==sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')
a=o/'engine91_frame_staging_before_audit.json';assert not a.exists();inputs={str(p.relative_to(r)):sha(p)for p in [v/'engine91_before_kernels.m',v/'engine91_frame_staging_before.m',v/'engine91_frame_staging_lifetime.inc',r/'zig/pkg/inference/src/backends/metal_buffer_observation.h',r/'zig/pkg/inference/src/backends/metal_mtp_head.h',r/'zig/pkg/inference/src/backends/metal_mtp_head_impl.h']}
b=v/'engine91_frame_staging_before';assert not b.exists();cmd=['clang','-O3','-fobjc-arc','-I','zig/pkg/inference/src/backends',str(v/'engine91_frame_staging_before.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(b)]
with Path('/private/tmp/ocr-engine91-lifetime-before-build.txt').open('w')as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
d=dict(status='compiled',primary_throughput_eligible=False,scope='Baseline weak-reference proof for ARC runtime host-staging buffer and pipeline teardown. Uses an exact immutable snapshot of source80/90 C. No model work or throughput claim.',input_sha256=inputs,build_exit_code=p.returncode,command=cmd);a.write_text(json.dumps(d,indent=2)+'\n');assert p.returncode==0
d['binary_sha256']=sha(b);log=Path('/private/tmp/ocr-engine91-lifetime-before.txt')
with log.open('w')as f:p=subprocess.run([str(b)],stdout=f,stderr=subprocess.STDOUT,timeout=120)
d.update(exit_code=p.returncode,log_sha256=sha(log),log=log.read_text(),status='leak_reproduced'if p.returncode==12 else'unexpected_result');a.write_text(json.dumps(d,indent=2)+'\n');print(log.read_text(),flush=True);assert p.returncode==12 and 'retained_buffers=2'in log.read_text()
print('ENGINE91 BASELINE LIFETIME LEAK REPRODUCED',flush=True)
