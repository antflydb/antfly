from pathlib import Path
import hashlib,json,re
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=list(json.loads((v/'engine48-freeze.json').read_text()))
(v/'engine52-freeze.json').write_text(json.dumps({p:sha(p)for p in files},indent=2)+'\n')
(v/'engine52_benchmark_concurrency.py').write_text(Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_text())
s=(v/'run_engine48_verify_gpu_build.py').read_text().replace('engine48','engine52')
s=s.replace("env['TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP']='0'","env['TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP']='0'\nenv['TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_RESOURCE_DEDUP']='1'")
(v/'run_engine52_verify_gpu_build.py').write_text(s)
s=(v/'build_engine46_conformance_retry.py').read_text().replace('engine46-freeze_retry','engine52-freeze').replace('engine46','engine52')
(v/'build_engine52_conformance.py').write_text(s)
s=(v/'run_engine46_c_qualification.py').read_text().replace('engine46','engine52')
s=s.replace("flags=['--check-wide-gate-up-full64'","flags=['--check-recurrent-resource-dedup','--check-wide-gate-up-full64'")
s=s.replace("TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP='0'","TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP='0',TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_RESOURCE_DEDUP='0'")
(v/'run_engine52_c_qualification.py').write_text(s)
s=(v/'run_engine46_c_and_bind.py').read_text().replace('engine46-freeze_retry','engine52-freeze').replace('build_engine46_conformance_retry','build_engine52_conformance').replace('engine46','engine52').replace("==13","==14").replace('ALL 13 C','ALL 14 C')
# Build log naming has no retry in engine52.
s=s.replace('ocr-engine52-verify-gpu-build-retry','ocr-engine52-verify-gpu-build')
(v/'run_engine52_c_and_bind.py').write_text(s)
s=(v/'run_engine48_budget_policies_verify.py').read_text().replace('engine48','engine52')
needle=" full64_gate_up=os.environ.get('OCR_FULL64_GATE_UP','0')=='1'"
assert needle in s
s=s.replace(needle," resource_dedup=os.environ.get('OCR_RESOURCE_DEDUP','0')=='1'\n if resource_dedup:cmd+=['--dedup-recurrent-resources']\n"+needle)
needle="report=json.loads((target/'report.json').read_text());"
assert needle in s
s=s.replace(needle,needle+"report['dedup_recurrent_resources']=resource_dedup;")
needle="    section=sections[sample['round']]";assert needle in s
s=s.replace(needle,needle+"""
    declarations=re.findall(r'recurrent_resource_calls=(\\d+) recurrent_resource_requested=(\\d+) recurrent_resource_emitted=(\\d+) recurrent_resource_skipped=(\\d+)',section)
    assert declarations,section[-2000:]
    sums=[sum(int(x[i])for x in declarations)for i in range(4)]
    sample['recurrent_resource_calls'],sample['recurrent_resource_requested'],sample['recurrent_resource_emitted'],sample['recurrent_resource_skipped']=sums
    assert sums[0]>0 and sums[1]>=sums[2] and sums[1]-sums[2]==sums[3]
    assert (sums[3]>0)==resource_dedup
""")
(v/'run_engine52_budget_policies.py').write_text(s)
for name in ['run_engine48_full64_cases.py','run_engine48_stream_cases.py','run_engine48_florence_case_verify.py','run_engine48_functional.py','engine48_verify_preset_only_test.py','engine48_verify_preset_physical32_test.py','engine48_verify_default_gpu_test.py']:
 p=v/name
 if not p.exists():continue
 s=p.read_text().replace('engine48','engine52').replace('run_engine52_budget_policies_verify.py','run_engine52_budget_policies.py')
 (v/name.replace('engine48','engine52')).write_text(s)
# Recover the exact canonical engine48 C source from the immutable private50
# copy by reversing only its documented host dispatch-size substitutions.
base=(v/'engine50_recurrent_runtime.m').read_text()
assert base.startswith('static unsigned long engine50_threads=512;\n')
base=base.split('\n',1)[1].replace('pipeline.maxTotalThreadsPerThreadgroup < engine50_threads','pipeline.maxTotalThreadsPerThreadgroup < 512').replace('MTLSizeMake(engine50_threads, 1, 1)','MTLSizeMake(512, 1, 1)')
expected=json.loads((v/'engine48-freeze.json').read_text())['zig/pkg/inference/src/backends/metal_kernels.m']
assert hashlib.sha256(base.encode()).hexdigest()==expected
(v/'engine48_c_canonical_from_probe50.m').write_text(base)
def shaders(s):
 result={}
 for match in re.finditer(r'^static NSString \*(\w+)\(void\) \{',s,re.M):
  a=match.start();b=s.index('\n}\n',a)+3
  result[match[1]]=hashlib.sha256(s[a:b].encode()).hexdigest()
 return result
old=shaders(base);new=shaders(Path('zig/pkg/inference/src/backends/metal_kernels.m').read_text())
assert old==new and len(old)>=4,(len(old),len(new))
(o/'engine52_unchanged_shader_source_audit.json').write_text(json.dumps(dict(status='pass',canonical_engine48_c_sha256=expected,shader_source_functions=old,scope='All static NSString shader-source functions remain byte-identical to engine48. New host-only per-dispatch declaration set merges exact-object duplicates and complete access usage.'),indent=2)+'\n')
for p in v.glob('*engine52*.py'):compile(p.read_text(),str(p),'exec')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
paths=list(v.glob('*engine52*.py'))+list(v.glob('engine52*.inc'))+[v/'engine52-freeze.json']
ns['archive']('drivers',paths,'drivers_manifest.json')
print('engine52 prepared; frozen',len(files),'files; unchanged shader functions',len(old))
