from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for kind in ['kernels','checks','probe']:
 s=(v/f'engine103_wide_core_{kind}.m').read_text().replace('engine103','engine104').replace('WALL103','WALL104').replace('WIDE103','WIDE104')
 if kind=='kernels':
  a=s.index('static int termite_metal_lightonocr3_encode_recurrent_parallel(');b=s.index('int termite_metal_decode_runtime_qwen35_core_batch_end(',a);part=s[a:b]
  part=part.replace('if (termite_metal_planned_range_make(buffer, offsets[index], bytes[index],','if (rows <= 16 && termite_metal_planned_range_make(buffer, offsets[index], bytes[index],')
  needle='    size_t access_count = rows * 15;';assert part.count(needle)==1
  part=part.replace(needle,needle+'''
    if (rows > 16) {
        // Packed projections, workspace and immutable weights are shared
        // buffers with disjoint views. Track a conservative bounding range
        // for each shared column rather than repeating it for every page.
        // Independent history/state allocations retain independent ranges.
        access_count = 0;
        for (size_t j = 0; j < 15; j++) {
            const bool write = j == 7 || j == 8 || j == 9 || j == 10 || j == 11 || j == 14;
            const termite_metal_planned_range_type type = write ? TERMITE_METAL_PLANNED_RANGE_WRITE : TERMITE_METAL_PLANNED_RANGE_READ;
            bool shared = true;
            size_t begin = offsets[j], end = offsets[j] + bytes[j];
            for (size_t row = 1; row < rows; row++) {
                const size_t index = row * 15 + j;
                shared = shared && handles[index] == handles[j];
                begin = MIN(begin, offsets[index]);
                end = MAX(end, offsets[index] + bytes[index]);
            }
            if (shared) {
                if (termite_metal_planned_range_make((__bridge id<MTLBuffer>)handles[j], begin, end - begin, type, &accesses[access_count++], -12)) return -12;
            } else for (size_t row = 0; row < rows; row++) {
                const size_t index = row * 15 + j;
                if (termite_metal_planned_range_make((__bridge id<MTLBuffer>)handles[index], offsets[index], bytes[index], type, &accesses[access_count++], -12)) return -12;
            }
        }
        // Preserve the global planner's bound. Unsupported layouts decline
        // before encoding so the ordinary per-page core can still execute.
        if (access_count + (rows * sizeof(table[0]) > 4096) > TERMITE_METAL_PLANNED_RANGE_CAPACITY) return 0;
    }''')
  s=s[:a]+part+s[b:]
 if kind=='checks':
  needle='    id<MTLBuffer> producers[64], consumers[64];';assert s.count(needle)==1
  s=s.replace(needle,'''    // Model projections use one row-packed buffer per output. Preserve
    // canaries around each row while exercising that real access topology.
    const size_t input_columns[4] = {0,2,3,12};
    id<MTLBuffer> packed_inputs[4];
    for (size_t k=0;k<4;k++) {
        size_t j=input_columns[k];
        packed_inputs[k]=[r->device newBufferWithLength:pages*(counts[j]+8)*4 options:MTLResourceStorageModeShared];
        if(!packed_inputs[k])return 66;
        for(size_t i=0;i<packed_inputs[k].length/4;i++)((uint32_t*)packed_inputs[k].contents)[i]=0xdeadbeef;
        for(size_t page=0;page<pages;page++) {
            size_t offset=16+page*(counts[j]+8)*4;
            memcpy((char*)packed_inputs[k].contents+offset,(char*)buffers[1][page][j].contents+offsets[1][page][j],counts[j]*4);
            buffers[1][page][j]=packed_inputs[k];handles[1][page][j]=(__bridge void*)packed_inputs[k];offsets[1][page][j]=offset;
        }
    }
'''+needle)
  # Poison and CPU initialization must address the packed mixed row, too.
  s=s.replace('((float *)buffers[1][page][0].contents)[i + 4] = -.9f;','((float *)((char*)buffers[1][page][0].contents+offsets[1][page][0]))[i] = -.9f;')
 if kind=='probe':
  s=s.replace('if(argc!=3)return 1;','if(argc<3||argc>5)return 1;').replace(' int rc=fused_batch_core_check(r,16,32,pages,true);',' size_t heads=argc>3?strtoul(argv[3],NULL,10):32;bool bench=argc>4?strtoul(argv[4],NULL,10)!=0:true;\n int rc=fused_batch_core_check(r,16,heads,pages,bench);')
 p=v/f'engine104_wide_core_{kind}.m';assert not p.exists();p.write_text(s)
d=json.loads((v/'engine103_wide_core_preparation.json').read_text());d['scope']+=' Source103 initialstepbitsexactbutcoalescedstepfailedplanner256limit;source104compactsharedcolumnranges,globalplannerboundunchanged,packedprojectedinputsmatchactualmodel. Unsupportedlayoutsdeclinebeforeencoding. Allprivate.';d['files_sha256']={str((v/f'engine104_wide_core_{k}.m').relative_to(r)):sha(v/f'engine104_wide_core_{k}.m')for k in ['kernels','checks','probe']};(v/'engine104_wide_core_preparation.json').write_text(json.dumps(d,indent=2)+'\n')
