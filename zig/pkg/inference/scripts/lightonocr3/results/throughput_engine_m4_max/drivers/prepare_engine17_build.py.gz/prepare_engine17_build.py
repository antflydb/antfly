from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';p=root/'zig/pkg/inference/src/backends/metal_kernels.m';s=p.read_text();a=s.index('// Bounded decode-only collector.');b=s.index('static bool termite_metal_decode_gqa_split_schedule_for_variant(',a)
part=s[a:b];formatted=subprocess.check_output(['/opt/homebrew/opt/llvm/bin/clang-format','--assume-filename='+str(p)],input=part,text=True);s=s[:a]+formatted+'\n'+s[b:];p.write_text(s)
p=root/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m';s=p.read_text();a=s.index('// Compare one concurrent encoder');b=s.index('int main(',a);part=s[a:b];formatted=subprocess.check_output(['/opt/homebrew/opt/llvm/bin/clang-format','--assume-filename='+str(p)],input=part,text=True);s=s[:a]+formatted+'\n'+s[b:];p.write_text(s)
s=(v/'run_engine16_gpu_build.py').read_text().replace('engine16','engine17');(v/'run_engine17_gpu_build.py').write_text(s)
s=(v/'run_engine16_policies.py').read_text().replace('engine16','engine17')
s=s.replace("str(out/('vllm_'+model+('_primary_reference4_16x128' if c=='16' and requests=='128' else '_primary_reference3_16x32' if c=='16' else '_primary_reference1_32'))/'report.json')", "str(out/('vllm_'+model+os.environ.get('OCR_REFERENCE_LABEL', '_primary_reference5_32x128' if c=='32' else '_primary_reference4_16x128' if requests=='128' else '_primary_reference3_16x32'))/'report.json')")
s=s.replace("    p=sample['policy'];assert", "    assert sample['attention_batch_calls']<=sum(int(x) for x,_ in cohorts)*(6 if model=='08' else 8),sample\n    assert sample['attention_batch_rows']<=sum(int(x) for _,x in cohorts)*(6 if model=='08' else 8),sample\n    p=sample['policy'];assert",1)
(v/'run_engine17_policies.py').write_text(s);(v/'engine17_benchmark_concurrency.py').write_bytes((v/'engine16_benchmark_concurrency.py').read_bytes());(v/'engine17_default_gpu_test.py').write_text((v/'engine16_default_gpu_test.py').read_text().replace('engine16','engine17'))
files=json.loads((v/'engine16-freeze.json').read_text());(v/'engine17-freeze.json').write_text(json.dumps({f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files},indent=2)+'\n')
print('source frozen17; do not build until primary16 finishes')
