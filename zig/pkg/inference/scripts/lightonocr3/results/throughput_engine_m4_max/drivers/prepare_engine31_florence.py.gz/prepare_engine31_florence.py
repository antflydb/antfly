from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal')
for f,h in json.loads((v/'engine30-freeze.json').read_text()).items():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h,f
p=Path('zig/pkg/inference/src/pipelines/reading.zig');s=p.read_text();a=s.index('    fn decodeNativeFlorenceBatchIncrementalFromEncoder(');b=s.index('    fn decodeNativeFlorenceBatchFromEncoder(',a);m=s[a:b]
anchor='''        var no_repeat_device_accepts: usize = 0;''';assert anchor in m
m=m.replace(anchor,'''        // This invocation already admits full-prefix logits and decoder/KV
        // storage. Keep each incremental decoder, head and reduction in one
        // frame; token publication and row compaction follow its completion.
        const single_frame = if (comptime build_options.enable_metal)
            checked_no_repeat_argmax and self.config.no_repeat_ngram_size > 0 and
                @import("../backends/metal_runtime.zig").qualifiedM4DeviceDefault() and
                platform.env.getenvBoolDefault("ANTFLY_FLORENCE2_SINGLE_FRAME", true) and
                !platform.env.getenvBool("TERMITE_FLORENCE2_METAL_DISABLE_FRAMES") and
                !platform.env.getenvBool("TERMITE_METAL_ENABLE_CONCURRENT_PLANNED_DISPATCH") and
                !readProfileEnabled() and !florenceDebugStats()
        else false;
        var owns_step_frame = false;
        defer if (owns_step_frame) cb.decoderRuntimeCancelFrame() catch {};
        var step_frame_start: u64 = 0;
        var frame_topology_mismatches: usize = 0;
        var single_frame_steps: usize = 0;
        var frame_api_fallbacks: usize = 0;
        defer if (self.config.no_repeat_ngram_size > 0 and platform.env.getenvBool("ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX")) {
            std.debug.print("FLORENCE2 single_frame_enabled={d} single_frame_steps={d} frame_api_fallbacks={d} frame_topology_mismatches={d}\\n", .{ @intFromBool(single_frame), single_frame_steps, frame_api_fallbacks, frame_topology_mismatches });
        };
'''+anchor,1)
anchor='''            const prefix_step_start = nowNs();
            const hidden = try florence_arch.decoderForwardIncrementalBatchStepFinalHiddenTensor(''';assert anchor in m
m=m.replace(anchor,'''            const prefix_step_start = nowNs();
            // Warm the first decoder step normally. A final forced prefix
            // token can then share a frame with its first generated token.
            if (idx > 0 and idx + 1 == dec_len) {
                owns_step_frame = try beginFlorenceStepFrame(cb, single_frame);
                if (owns_step_frame) step_frame_start = cb.debugTimingSnapshot().provider.decoder_runtime_frame_submits;
            }
            const hidden = try florence_arch.decoderForwardIncrementalBatchStepFinalHiddenTensor(''',1)
old='''                        if (try cb.argmaxRows(
                            logits_tensor,
                            0,
                            active_count,
                            florence_cfg.vocab_size,
                            allocator,
                        )) |selected_tokens| {''';assert old in m
m=m.replace(old,'''                        const prior_frame_steps = single_frame_steps;
                        const selected = try florenceStepArgmaxRows(
                            cb, logits_tensor, active_count, florence_cfg.vocab_size, allocator,
                            &owns_step_frame, &single_frame_steps, &frame_api_fallbacks,
                        );
                        if (single_frame_steps > prior_frame_steps and
                            cb.debugTimingSnapshot().provider.decoder_runtime_frame_submits -| step_frame_start != 1)
                            frame_topology_mismatches += 1;
                        if (selected) |selected_tokens| {''',1)
anchor='''                const decoder_run_start = nowNs();
                hidden_opt = try florence_arch.decoderForwardIncrementalBatchStepFinalHiddenTensor(''';assert anchor in m
m=m.replace(anchor,'''                const decoder_run_start = nowNs();
                owns_step_frame = try beginFlorenceStepFrame(cb, single_frame);
                if (owns_step_frame) step_frame_start = cb.debugTimingSnapshot().provider.decoder_runtime_frame_submits;
                hidden_opt = try florence_arch.decoderForwardIncrementalBatchStepFinalHiddenTensor(''',1)
s=s[:a]+m+s[b:]
a=s.index('/// Validate each device winner against its original page history. Active')
helper='''/// The caller cancels an owned frame on every exit before its page/cache
/// storage retires. Existing outer frames retain their original ownership.
fn beginFlorenceStepFrame(cb: *const ComputeBackend, enabled: bool) !bool {
    if (!enabled or cb.kind() != .metal or cb.decoderRuntimeHasActiveFrame()) return false;
    if (!try cb.decoderRuntimeBeginFrame()) return false;
    errdefer cb.decoderRuntimeCancelFrame() catch {};
    try cb.decoderRuntimeSetActiveFrameRegime(.decode);
    if (!try cb.decoderRuntimeBeginPlannedComputeScope()) {
        try cb.decoderRuntimeCancelFrame();
        return false;
    }
    return true;
}

fn florenceStepArgmaxRows(
    cb: *const ComputeBackend, logits: CT, rows: usize, vocab: usize,
    allocator: std.mem.Allocator, owns_frame: *bool, steps: *usize, fallbacks: *usize,
) !?[]u32 {
    if (owns_frame.*) {
        // A dense implementation may close its encoder while retaining the
        // frame. Reopen the scope so argmax consumes this same command buffer.
        _ = try cb.decoderRuntimeBeginPlannedComputeScope();
        if (try cb.decoderRuntimeArgmaxRowsSuppress(logits, 0, rows, vocab, &.{}, allocator)) |selected| {
            // This API completes the frame before returning CPU token ids.
            if (cb.decoderRuntimeHasActiveFrame()) {
                allocator.free(selected);
                return error.FlorenceArgmaxFrameNotConsumed;
            }
            owns_frame.* = false;
            steps.* += 1;
            return selected;
        }
        // Missing/unsupported consuming APIs keep the regular selection path.
        // Drain the producer before that path can inspect or download logits.
        if (!cb.decoderRuntimeHasActiveFrame()) {
            owns_frame.* = false;
            return error.FlorenceArgmaxFrameFailed;
        }
        try cb.decoderRuntimeSubmitAndWaitFrame();
        owns_frame.* = false;
        fallbacks.* += 1;
    }
    return cb.argmaxRows(logits, 0, rows, vocab, allocator);
}

'''
s=s[:a]+helper+s[a:]
# Extend the actual Metal no-repeat regression to an unsubmitted GPU producer,
# including early producer retirement and the existing masked CPU fallback.
a=s.index('test "Florence checked no-repeat argmax keeps logits on Metal and preserves fallback"');b=s.index('\nfn selectGreedyToken(',a);m=s[a:b]
m=m.replace('''                for (0..5) |scenario| {''','''                for ([_]bool{ false, true }) |frame_mode| {
                for (0..5) |scenario| {''',1)
m=m.replace('''                }
            }
        }
    };''','''                }
                }
            }
        }
    };''',1)
old='''                    const transfers = @import("../ops/media_residency_test.zig").Transfers.snapshot(cb);
                    const selected = (try cb.argmaxRows(device, 0, 2, vocab, allocator)) orelse return error.DeviceArgmaxUnavailable;''';assert old in m
new='''                    const zeros = try allocator.alloc(f32, vocab * 2);
                    defer allocator.free(zeros);
                    @memset(zeros, 0);
                    const zero_host = try cb.fromFloat32Shape(zeros, &.{ 2, @as(i32, @intCast(vocab)) });
                    defer cb.free(zero_host);
                    const zero_device = (try cb.ensureDeviceResident(zero_host)) orelse return error.DeviceLogitsUnavailable;
                    defer cb.free(zero_device);
                    var owns_frame = try beginFlorenceStepFrame(&cb, frame_mode);
                    defer if (owns_frame) cb.decoderRuntimeCancelFrame() catch {};
                    try std.testing.expectEqual(frame_mode, owns_frame);
                    const produced = if (frame_mode) blk: {
                        const intermediate = try cb.add(device, zero_device);
                        defer cb.free(intermediate);
                        break :blk try cb.add(intermediate, zero_device);
                    } else device;
                    defer if (frame_mode) cb.free(produced);
                    const transfers = @import("../ops/media_residency_test.zig").Transfers.snapshot(cb);
                    var frame_steps: usize = 0;
                    var frame_fallbacks: usize = 0;
                    const selected = (try florenceStepArgmaxRows(&cb, produced, 2, vocab, allocator, &owns_frame, &frame_steps, &frame_fallbacks)) orelse return error.DeviceArgmaxUnavailable;
                    try std.testing.expect(!owns_frame and !cb.decoderRuntimeHasActiveFrame());
                    try std.testing.expectEqual(@as(usize, @intFromBool(frame_mode)), frame_steps);
                    try std.testing.expectEqual(@as(usize, 0), frame_fallbacks);'''
m=m.replace(old,new,1).replace('const downloaded = try cb.toFloat32(device, allocator);','const downloaded = try cb.toFloat32(produced, allocator);',1)
s=s[:a]+m+s[b:]
# Separate real-backend regression: consuming API absent and allocation failure.
a=s.index('\nfn selectGreedyToken(')
test='''
test "Florence step frame drains unsupported consumers and cancels failed token allocation" {
    const Check = struct {
        fn run(cb: ComputeBackend, _: ComputeBackend) !void {
            const allocator = std.testing.allocator;
            const values = [_]f32{ 1, 4, 2, 0, 8, 2, 1, 0 };
            const host = try cb.fromFloat32Shape(&values, &.{ 2, 4 });
            defer cb.free(host);
            const device = (try cb.ensureDeviceResident(host)) orelse return error.DeviceLogitsUnavailable;
            defer cb.free(device);
            const LostResult = struct {
                base: ComputeBackend,
                fn consume(raw: *anyopaque, _: CT, _: usize, _: usize, _: usize, _: []const i32, _: std.mem.Allocator) anyerror!?[]u32 {
                    const self: *@This() = @ptrCast(@alignCast(raw));
                    try self.base.decoderRuntimeSubmitAndWaitFrame();
                    return null;
                }
                fn scope(raw: *anyopaque) anyerror!bool {
                    const self: *@This() = @ptrCast(@alignCast(raw));
                    return self.base.decoderRuntimeBeginPlannedComputeScope();
                }
                fn active(raw: *anyopaque) bool {
                    const self: *@This() = @ptrCast(@alignCast(raw));
                    return self.base.decoderRuntimeHasActiveFrame();
                }
            };
            var fallback_table = cb.vtable.*;
            fallback_table.decoderRuntimeArgmaxRowsSuppress = null;
            var fallback_cb = cb;
            fallback_cb.vtable = &fallback_table;
            var owns = try beginFlorenceStepFrame(&fallback_cb, true);
            defer if (owns) cb.decoderRuntimeCancelFrame() catch {};
            const produced = try cb.add(device, device);
            defer cb.free(produced);
            var steps: usize = 0;
            var fallbacks: usize = 0;
            const selected = (try florenceStepArgmaxRows(&fallback_cb, produced, 2, 4, allocator, &owns, &steps, &fallbacks)).?;
            defer allocator.free(selected);
            try std.testing.expectEqualSlices(u32, &.{ 1, 0 }, selected);
            try std.testing.expect(!owns and !cb.decoderRuntimeHasActiveFrame());
            try std.testing.expectEqual(@as(usize, 0), steps);
            try std.testing.expectEqual(@as(usize, 1), fallbacks);
            {
                var failed_frame = try beginFlorenceStepFrame(&cb, true);
                defer if (failed_frame) cb.decoderRuntimeCancelFrame() catch {};
                const pending = try cb.add(device, device);
                defer cb.free(pending);
                try std.testing.expectError(error.OutOfMemory, florenceStepArgmaxRows(&cb, pending, 2, 4, std.testing.failing_allocator, &failed_frame, &steps, &fallbacks));
                try std.testing.expect(failed_frame and cb.decoderRuntimeHasActiveFrame());
            }
            try std.testing.expect(!cb.decoderRuntimeHasActiveFrame());
            var lost_context = LostResult{ .base = cb };
            var lost_table = cb.vtable.*;
            lost_table.decoderRuntimeArgmaxRowsSuppress = LostResult.consume;
            lost_table.decoderRuntimeHasActiveFrame = LostResult.active;
            lost_table.decoderRuntimeBeginPlannedComputeScope = LostResult.scope;
            const lost_cb = ComputeBackend{ .ptr = &lost_context, .vtable = &lost_table };
            var lost_frame = try beginFlorenceStepFrame(&cb, true);
            defer if (lost_frame) cb.decoderRuntimeCancelFrame() catch {};
            const lost_logits = try cb.add(device, device);
            defer cb.free(lost_logits);
            try std.testing.expectError(error.FlorenceArgmaxFrameFailed, florenceStepArgmaxRows(&lost_cb, lost_logits, 2, 4, allocator, &lost_frame, &steps, &fallbacks));
            try std.testing.expect(!lost_frame and !cb.decoderRuntimeHasActiveFrame());
        }
    };
    const fixture = @import("../ops/media_residency_test.zig");
    try fixture.onMetal(fixture.noWeights, Check.run);
}
'''
s=s[:a]+test+s[a:];p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text()
s=s.replace('''            "ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX",''','''            "ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX",
            "ANTFLY_FLORENCE2_SINGLE_FRAME",''',1)
anchor='''    if args.disable_florence_no_repeat_argmax:''';assert anchor in s;s=s.replace(anchor,'''    env["ANTFLY_FLORENCE2_SINGLE_FRAME"] = "0" if args.disable_florence_single_frame else "1"
    if args.require_florence_single_frame:
        env["ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX"] = "1"
'''+anchor,1)
anchor='''        if args.require_weight_handles:''';assert anchor in s
s=s.replace(anchor,'''        if args.require_florence_single_frame:
            timed = "".join(re.split(r"OCR_POLICY round=\\d+ name=[a-z0-9]+\\n", text)[1:])
            traces = re.findall(r"FLORENCE2 single_frame_enabled=(\\d+) single_frame_steps=(\\d+) frame_api_fallbacks=(\\d+) frame_topology_mismatches=(\\d+)", timed)
            stats = {"enabled": sorted({int(x[0]) for x in traces}), "steps": sum(int(x[1]) for x in traces), "api_fallbacks": sum(int(x[2]) for x in traces), "topology_mismatches": sum(int(x[3]) for x in traces)}
            result["florence_single_frame"] = stats
            enabled = not args.disable_florence_single_frame
            if stats["enabled"] != [int(enabled)] or (enabled and not stats["steps"]) or stats["api_fallbacks"] or stats["topology_mismatches"] or (not enabled and stats["steps"]):
                result["status"] = "florence_single_frame_control_mismatch"
'''+anchor,1)
anchor='''    parser.add_argument("--disable-prefill-pack-reuse", action="store_true")''';assert anchor in s;s=s.replace(anchor,'''    parser.add_argument("--disable-florence-single-frame", action="store_true")
    parser.add_argument("--require-florence-single-frame", action="store_true")
'''+anchor,1);p.write_text(s)
print('31 Florence complete-step frame, fallback and allocation-failure checks prepared')
