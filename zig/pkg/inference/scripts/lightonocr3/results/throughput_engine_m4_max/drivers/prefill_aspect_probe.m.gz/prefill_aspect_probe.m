// Copyright 2026 Antfly, Inc.
// SPDX-License-Identifier: Apache-2.0
#define main production_checks_main
#include "../zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m"
#undef main
static int aspect(termite_metal_decode_runtime*r,size_t rows,size_t in,size_t out,int bf16){
 size_t nx=rows*in,ny=rows*out;
 id<MTLBuffer>src=[r->device newBufferWithLength:nx*4 options:MTLResourceStorageModeShared],zero=[r->device newBufferWithLength:nx*4 options:MTLResourceStorageModeShared],x=[r->device newBufferWithLength:nx*4 options:MTLResourceStorageModePrivate],pack=[r->device newBufferWithLength:nx*2 options:MTLResourceStorageModePrivate];
 id<MTLBuffer>ys[2];for(int i=0;i<2;i++)ys[i]=[r->device newBufferWithLength:(ny+8)*4 options:MTLResourceStorageModeShared];
 uint16_t*w=malloc(in*out*2);float*b=malloc(out*4);if(!src||!zero||!x||!pack||!ys[0]||!ys[1]||!w||!b)return 1;
 float*xs=src.contents;memset(zero.contents,0,nx*4);uint32_t rng=17;
 for(size_t i=0;i<nx;i++)xs[i]=sinf((i%1997)*.017f)*.7f;
 for(size_t i=0;i<in*out;i++){rng=rng*1664525u+1013904223u;w[i]=round_bf16(((int)(rng>>16)-32768)*.000001f);}
 for(size_t i=0;i<out;i++)b[i]=cosf(i*.019f)*.1f;
 if(termite_metal_decode_runtime_prepare_linear_bf16(r,0,(uint8_t*)w,in*out*2,b,in,out))return 2;
 double gpu[2]={0},wall[2]={0};float worst=0;double cpu=0;
 for(int trial=0;trial<14;trial++)for(int mi=0;mi<2;mi++){@autoreleasepool{
  int mode=(trial&1)?1-mi:mi;uint32_t*raw=ys[mode].contents;for(size_t j=0;j<ny+8;j++)raw[j]=0xdeadbeef;
  uint64_t begin=termite_metal_clock_monotonic_nanos();
  if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_PREFILL)||termite_metal_decode_runtime_apply_add_device(r,(__bridge void*)src,0,(__bridge void*)zero,0,nx,(__bridge void*)x,0))return 3;
  termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
  id<MTLCommandBuffer>cb=r->active_frame_cb;id<MTLComputeCommandEncoder>e=[cb computeCommandEncoder];if(!e)return 4;
  if(bf16){uint32_t count=nx;[e setComputePipelineState:r->lightonocr3_pack_bf16_pipeline];[e setBuffer:x offset:0 atIndex:0];[e setBuffer:pack offset:0 atIndex:1];[e setBytes:&count length:4 atIndex:2];[e dispatchThreads:MTLSizeMake(nx,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];[e memoryBarrierWithScope:MTLBarrierScopeBuffers];}
  id<MTLComputePipelineState>p=bf16?(mode?r->lightonocr3_mpp_bf16_n32_pipeline:r->lightonocr3_mpp_bf16_pipeline):(mode?r->lightonocr3_mpp_f32_n32_pipeline:r->lightonocr3_mpp_f32_pipeline);
  if(!p||p.maxTotalThreadsPerThreadgroup<128)return 5;
  termite_metal_linear_params params={(uint32_t)rows,(uint32_t)in,(uint32_t)out,0};[e setComputePipelineState:p];[e setBuffer:bf16?pack:x offset:0 atIndex:0];[e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:2];[e setBuffer:ys[mode] offset:16 atIndex:3];[e setBytes:&params length:sizeof(params) atIndex:4];
  size_t tm=mode?64:32,tn=mode?32:64;[e dispatchThreadgroups:MTLSizeMake((out+tn-1)/tn,(rows+tm-1)/tm,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];[e endEncoding];
  if(termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r)||cb.status!=MTLCommandBufferStatusCompleted)return 6;
  if(trial>=2){gpu[mode]+=(cb.GPUEndTime-cb.GPUStartTime)*1e6;wall[mode]+=(termite_metal_clock_monotonic_nanos()-begin)*1e-3;}
  for(size_t j=0;j<4;j++)if(raw[j]!=0xdeadbeef||raw[ny+4+j]!=0xdeadbeef)return 7;
  float*got=(float*)raw+4;for(size_t j=0;j<ny;j++)if(!isfinite(got[j]))return 8;
  for(size_t corner=0;corner<4;corner++){size_t row=(corner&1)?rows-1:0,col=(corner&2)?out-1:0;double expected=b[col];for(size_t k=0;k<in;k++)expected+=(double)(bf16?expand_bf16(round_bf16(xs[row*in+k])):xs[row*in+k])*expand_bf16(w[col*in+k]);cpu=fmax(cpu,fabs(expected-got[row*out+col]));}
  if(mi==1){float*a=(float*)ys[0].contents+4,*z=(float*)ys[1].contents+4;for(size_t j=0;j<ny;j++)worst=fmaxf(worst,fabsf(a[j]-z[j]));}
 }}
 fprintf(stderr,"ASPECT rows=%zu in=%zu out=%zu bf16=%d m32_gpu_us=%.3f m64_gpu_us=%.3f m32_wall_us=%.3f m64_wall_us=%.3f max_abs=%g cpu_max_abs=%g\n",rows,in,out,bf16,gpu[0]/12,gpu[1]/12,wall[0]/12,wall[1]/12,worst,cpu);
 free(w);free(b);return worst>2e-4||cpu>2e-4?9:0;
}
int main(void){@autoreleasepool{termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;termite_metal_decode_runtime_set_lightonocr3_projections(r,1);size_t shapes[][2]={{1024,6144},{1024,2048},{1024,4096},{1024,3584},{2048,1024},{3584,1024},{2560,8192},{2560,4096},{2560,9216},{2560,1024},{4096,2560},{9216,2560}};size_t rows[]={128,432,864};for(size_t s=0;s<12;s++)for(size_t j=0;j<3;j++)for(int b=0;b<2;b++){@autoreleasepool{int rc=aspect(r,rows[j],shapes[s][0],shapes[s][1],b);if(rc){fprintf(stderr,"ASPECT_FAIL rc=%d\n",rc);return rc;}}}termite_metal_decode_runtime_destroy(r);return 0;}}
