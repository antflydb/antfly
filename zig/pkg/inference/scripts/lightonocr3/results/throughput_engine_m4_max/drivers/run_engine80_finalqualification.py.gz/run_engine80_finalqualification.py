from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while True:
 text=Path('/private/tmp/ocr-engine80-qualification-parent.txt').read_text()
 if 'Traceback' in text or any('DONE ENGINE80 '+x+' 'in text and 'DONE ENGINE80 '+x+' 0'not in text for x in ['c-build','c-qualification','gpu','finalize','cpu']):raise RuntimeError(text)
 if 'ENGINE80 QUALIFICATION DONE'in text:break
 time.sleep(5)
f=json.loads((v/'engine80-freeze.json').read_text());assert all(sha(r/p)==h for p,h in f.items())
manifest=json.loads((o/'engine70_c_build_manifest.json').read_text());inputs={p:sha(r/p)for p in manifest['input_sha256']}
(o/'engine80_c_build_manifest.json').write_text(json.dumps(dict(binary=str((v/'engine79_conformance').relative_to(r)),binary_sha256=sha(v/'engine79_conformance'),input_sha256=inputs,compiler_driver_sha256=sha(v/'build_engine79_conformance.py'),qualification_driver_sha256=sha(v/'run_engine79_c_qualification.py')),indent=2)+'\n')
binary=v/'engine80_c_prefill_ffn_check_verify2';assert not binary.exists()
source=v/'engine80_c_prefill_ffn_check_verify2.m';build=Path('/private/tmp/ocr-engine80-focused-c-verify2-build.txt')
cmd=['clang','-O3','-fobjc-arc','-I','zig/pkg/inference/src/backends',str(source),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(binary)]
print('START ENGINE80 focusedC verify2 build',flush=True)
with build.open('w')as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
assert result.returncode==0
stdout=Path('/private/tmp/ocr-engine80-focused-c-verify2-stdout.txt');stderr=Path('/private/tmp/ocr-engine80-focused-c-verify2-stderr.txt');assert not stdout.exists()and not stderr.exists()
print('START ENGINE80 focusedC verify2 GPU',flush=True)
with stdout.open('w')as so,stderr.open('w')as se:result=subprocess.run([str(binary)],stdout=so,stderr=se,env=dict(os.environ,ANTFLY_LIGHTONOCR3_THROUGHPUT='0',TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY='1'),timeout=900)
records=[json.loads(line)for line in stdout.read_text().splitlines()if line.startswith('{"variant":')]
d=dict(status='pass'if result.returncode==0 else'failed',primary_throughput_eligible=False,scope='Production-C FFN exact packed/output and CPU/canary coverage at six lengths, including independent MPP/prefill-projection/pack-reuse/planned-MPP rollback flags. Fresh source after focused attempt1.',exit_code=result.returncode,records=records,binary_sha256=sha(binary),production_c_sha256=sha(r/'zig/pkg/inference/src/backends/metal_kernels.m'),checker_sha256=sha(source),stdout_sha256=sha(stdout),stderr_sha256=sha(stderr),driver_sha256=sha(Path(__file__)))
(o/'engine80_focused_c_prefill_ffn_verify2_audit.json').write_text(json.dumps(d,indent=2)+'\n')
assert result.returncode==0 and len(records)==24
assert all(x['max_abs']==x['packed_differences']==x['norm_packed_differences']==0 for x in records)
assert 'PROBE78 FULL PACKED/OUTPUT/CORNER/CANARY CHECKS PASS'in stderr.read_text()
assert all(sha(r/p)==h for p,h in f.items())
manifest=json.loads((o/'engine80_build_manifest.json').read_text());preserved=v/'qualified-binaries/engine80-test';os.link(Path(manifest['binary_path']),preserved);assert sha(preserved)==manifest['binary_sha256']
print('ENGINE80 FINAL QUALIFICATION DONE',flush=True)
