from pathlib import Path
import difflib,json,hashlib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';names=['zig/pkg/inference/src/server/server.zig','zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py'];old={p:(r/p).read_text()for p in names};new=dict(old)
s=new[names[0]]
s=s.replace('            "TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN",\n','            "TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN",\n            "TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS",\n',1)
needle='        for (policy_names, 0..) |policy, round| {';assert s.count(needle)==1
s=s.replace(needle,'''        var parsed_bf16_rounds: ?std.json.Parsed([]const bool) = null;
        defer if (parsed_bf16_rounds) |*value| value.deinit();
        if (platform.env.getenv("ANTFLY_TEST_OCR_BF16_PROJECTION_ROUNDS")) |raw| {
            parsed_bf16_rounds = try std.json.parseFromSlice([]const bool, allocator, raw, .{});
            if (parsed_bf16_rounds.?.value.len != policy_names.len) return error.InvalidBenchmarkPolicy;
        }
'''+needle)
needle='            const latencies = try allocator.alloc(u64, requests);';assert s.count(needle)==1
s=s.replace(needle,'''            if (parsed_bf16_rounds) |rounds| {
                const enabled = rounds.value[round];
                if (Env.setenv("TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS", if (enabled) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;
                std.debug.print("OCR_BF16_POLICY round={d} enabled={d}\\n", .{ round, @intFromBool(enabled) });
            }
'''+needle)
needle='            const cpu_begin = benchmarkOcrProcessCpuNs();';assert s.count(needle)==1;s=s.replace(needle,'            benchmarkOcrMemorySnapshot(round, "before");\n'+needle)
needle='            var completed: usize = 0;';assert s.count(needle)==1;s=s.replace(needle,'            benchmarkOcrMemorySnapshot(round, "after");\n'+needle)
needle='    fn benchmarkOcrProcessCpuNs() ?u64 {';assert s.count(needle)==1
s=s.replace(needle,'''    // Lifetime gauges, not physical residency. Capture outside timed work.
    fn benchmarkOcrMemorySnapshot(round: usize, phase: []const u8) void {
        if (comptime build_options.enable_metal) {
            const tensors = @import("../backends/metal_tensor.zig").memoryStatsSnapshot();
            const observed = @import("../backends/metal_telemetry.zig").memorySnapshot(true);
            std.debug.print("OCR_MEMORY round={d} phase={s} tensor_live_bytes={d} owned_buffer_live_bytes={d} alias_buffer_live_bytes={d}\\n", .{ round, phase, tensors.device_owned_live_bytes, observed[0], observed[6] });
        }
    }

'''+needle);new[names[0]]=s
s=new[names[1]]
needle='    if args.bf16_prefill_inputs:';assert s.count(needle)==1
s=s.replace(needle,'''    env.pop("ANTFLY_TEST_OCR_BF16_PROJECTION_ROUNDS", None)
    if args.bf16_projection_rounds:
        env["ANTFLY_TEST_OCR_BF16_PROJECTION_ROUNDS"] = json.dumps(
            [value == "on" for value in args.bf16_projection_rounds]
        )
'''+needle)
needle='        if args.require_prefill_fused_ffn:';assert s.count(needle)==1
s=s.replace(needle,'''        if args.bf16_projection_rounds:
            observed = [(int(index), bool(int(enabled))) for index, enabled in re.findall(
                r"OCR_BF16_POLICY round=(\\d+) enabled=([01])", text
            )]
            expected = [(index, value == "on") for index, value in enumerate(args.bf16_projection_rounds)]
            samples = result.get("policy_rounds", [])
            if observed != expected or len(samples) != len(expected):
                result["status"] = "missing_bf16_projection_rounds"
            for sample, (index, enabled) in zip(samples, expected):
                sample["bf16_projection_enabled"] = enabled
                if sample.get("round") != index or ((sample.get("decode_pack_calls", 0) > 0) != enabled):
                    result["status"] = "missing_timed_bf16_projection_policy"
        memory_samples = {}
        for index, phase, tensor_live, owned_live, alias_live in re.findall(
            r"OCR_MEMORY round=(\\d+) phase=(before|after) tensor_live_bytes=(\\d+) owned_buffer_live_bytes=(\\d+) alias_buffer_live_bytes=(\\d+)", text
        ):
            memory_samples.setdefault(int(index), {})[phase] = dict(
                tensor_live_bytes=int(tensor_live), owned_buffer_live_bytes=int(owned_live), alias_buffer_live_bytes=int(alias_live)
            )
        for sample in result.get("policy_rounds", []):
            sample["buffer_lifetime_gauges"] = memory_samples.get(sample["round"], {})
        if args.require_memory_rounds and (not result.get("policy_rounds") or any(
            set(sample.get("buffer_lifetime_gauges", {})) != {"before", "after"} for sample in result["policy_rounds"]
        )):
            result["status"] = "missing_round_buffer_lifetime_gauges"
'''+needle)
needle='    parser.add_argument("--bf16-projection-inputs", action="store_true")';assert s.count(needle)==1
s=s.replace(needle,needle+'''
    parser.add_argument("--bf16-projection-rounds", nargs="+", choices=("off", "on"),
                        help="Override decode projection input precision per resident policy round; requires BF16 prefill")
    parser.add_argument("--require-memory-rounds", action="store_true",
                        help="Require before/after buffer lifetime gauges outside timed policy rounds")''')
needle='    prefill_ffn_enabled = args.prefill_fused_ffn or "on" in (';assert s.count(needle)==1
s=s.replace(needle,'''    if args.bf16_projection_rounds and (not args.policy_rounds or len(args.bf16_projection_rounds) != len(args.policy_rounds)):
        parser.error("--bf16-projection-rounds must match --policy-rounds length")
    if args.bf16_projection_rounds and "on" in args.bf16_projection_rounds and not args.bf16_prefill_inputs:
        parser.error("decode precision rounds require --bf16-prefill-inputs to hold prefill precision fixed")
    if args.require_memory_rounds and not args.policy_rounds:
        parser.error("--require-memory-rounds requires --policy-rounds")
'''+needle)
s=s.replace('                    sample["retained_weight_handles_observed"] = (','                    sample["decode_pack_calls"] = sum(int(value) for value in re.findall(r"LIGHTONOCR3 decode_pack_calls=(\\d+)", section))\n                    sample["retained_weight_handles_observed"] = (',1)
new[names[1]]=s
for p,s in new.items():(v/('engine90_proposed_'+Path(p).name)).write_text(s)
(v/'engine90_proposal.json').write_text(json.dumps(dict(original_sha256={p:hashlib.sha256(old[p].encode()).hexdigest()for p in names},proposed_sha256={p:hashlib.sha256(new[p].encode()).hexdigest()for p in names}),indent=2)+'\n')
(v/'engine90_proposed.patch').write_text(''.join(''.join(difflib.unified_diff(old[p].splitlines(True),new[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p))for p in names))
print('Prepared only private proposal; production/frozen sources unchanged.')
