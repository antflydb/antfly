from pathlib import Path
import ast
v=Path('.venv-lighton-vllm-metal');c=Path('zig/pkg/inference/src/backends/metal_kernels.m').read_text()
a=c.index('        "template<uint N, uint M=8, uint SG=1> inline void termite_lightonocr3_gate_up_small_body(');b=c.index('        "kernel void termite_lightonocr3_gate_up_small16(',a)
body=''.join(ast.literal_eval(x.strip())for x in c[a:b].splitlines())
body=body.replace('template<uint N, uint M=8, uint SG=1>','template<uint M, uint N, uint SG>').replace('termite_lightonocr3_gate_up_small_body','candidate_gate').replace('device float*x','device bfloat*x').replace('tensor<device float,dextents<int,2>,tensor_inline>a(x,','tensor<device bfloat,dextents<int,2>,tensor_inline>a(x,')
header='#include <metal_stdlib>\n#include <metal_tensor>\n#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\nusing namespace metal;using namespace mpp::tensor_ops;\nstruct Params {uint rows,in_dim,out_dim,pad;};\n'
for i,(m,n,sg)in enumerate([(32,32,4),(32,64,4),(64,32,4)]):
 body+=f'kernel void candidate{i}(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){{candidate_gate<{m},{n},{sg}>(x,g,u,gb,ub,y,p,group);}}\n'
(v/'prefill_gate_up_probe64a.metal').write_text(header+body)
