from pathlib import Path
import psutil,signal,subprocess,datetime,json,hashlib,os
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
found=[]
for p in psutil.process_iter(['pid','cmdline']):
 try:
  if (p.info['cmdline']or[])[1:]==['-u','.venv-lighton-vllm-metal/run_engine113_cache94.py']:found.append(p)
 except(psutil.NoSuchProcess,psutil.AccessDenied):pass
assert len(found)==1;parent=found[0];assert parent.cwd()==str(r)and not parent.children(recursive=True)
audit=o/'engine114_retention_gap_probe_audit.json';assert not audit.exists();before=json.loads((o/'engine113_remaining_cache94_audit.json').read_text());assert len(before['runs'])==2 and all(x['status']=='passed'for x in before['runs']);parent.send_signal(signal.SIGSTOP)
d=dict(status='owned_childfree_waiter_paused',started=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=parent.pid,scope='CPU-only approximate retention-topology microprobe between native cohorts. Pause only verified owned child-free admission waiter before next model launch. No compiled runtime source changes; no GPU or model execution. Resume in finally.',source_sha256=sha(v/'retained_resources114_probe.m'));audit.write_text(json.dumps(d,indent=2)+'\n')
try:
 assert not parent.children(recursive=True)
 with Path('/private/tmp/ocr-engine114-retention-build.txt').open('w')as log:subprocess.run(['clang','-O3','-fobjc-arc',str(v/'retained_resources114_probe.m'),'-framework','Foundation','-o',str(v/'retained_resources114_probe')],env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')),stdout=log,stderr=subprocess.STDOUT,check=True)
 with Path('/private/tmp/ocr-engine114-retention-probe.txt').open('w')as log:subprocess.run([str(v/'retained_resources114_probe')],stdout=log,stderr=subprocess.STDOUT,check=True,timeout=45)
 d['status']='cpu_probe_complete';d['log_sha256']=sha('/private/tmp/ocr-engine114-retention-probe.txt')
finally:
 if parent.is_running():parent.send_signal(signal.SIGCONT);d['waiter_resumed']=True
 d['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();audit.write_text(json.dumps(d,indent=2)+'\n')
print(Path('/private/tmp/ocr-engine114-retention-probe.txt').read_text())
