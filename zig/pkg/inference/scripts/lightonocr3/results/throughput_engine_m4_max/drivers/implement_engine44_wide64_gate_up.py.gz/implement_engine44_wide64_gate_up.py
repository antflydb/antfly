from pathlib import Path
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text()
def replace(old,new):
 global s
 assert s.count(old)==1,(old[:100],s.count(old));s=s.replace(old,new)
replace('    id<MTLComputePipelineState> lightonocr3_gate_up_wide32_pipeline;','    id<MTLComputePipelineState> lightonocr3_gate_up_wide32_pipeline;\n    id<MTLComputePipelineState> lightonocr3_gate_up_wide64_pipeline;')
line=next(x for x in s.splitlines(True) if '"kernel void termite_lightonocr3_gate_up_wide32(' in x)
replace(line,line+line.replace('gate_up_wide32','gate_up_wide64').replace('small_body<16,32,2>','small_body<32,64,4>'))
line=next(x for x in s.splitlines(True) if 'runtime->lightonocr3_gate_up_wide32_pipeline = termite_metal_make_pipeline' in x)
replace(line,line+line.replace('wide32','wide64'))
line='    runtime->lightonocr3_gate_up_wide32_pipeline = nil;\n'
replace(line,line+line.replace('wide32','wide64'))
needle='    // The small model retains its measured wide MPP tile. The 4B geometry\n    // keeps generic BF16 fusion after its full-model MPP candidate regressed.\n    // Preserve the established narrow tiles and generic fallback independently.'
replace(needle,'''    // Keep the measured small-model tile. The larger replacement remains
    // explicit until a full-model run qualifies it; preserve generic fusion.
    if (rows >= 32 && in_dim == 2560 && out_dim == 9216 &&
        termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP")) &&
        !termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP"))) {
        id<MTLComputePipelineState> wide = runtime->lightonocr3_gate_up_wide64_pipeline;
        if (wide != nil && wide.threadExecutionWidth == 32 &&
            wide.maxTotalThreadsPerThreadgroup >= 128 &&
            wide.staticThreadgroupMemoryLength <= runtime->device.maxThreadgroupMemoryLength)
            return wide;
    }''')
needle='        else if (small == runtime->lightonocr3_gate_up_wide32_pipeline && small != nil) {'
replace(needle,'''        else if (small == runtime->lightonocr3_gate_up_wide64_pipeline && small != nil) {
            [encoder dispatchThreadgroups:MTLSizeMake(out_dim / 32, (rows + 63u) / 64u, 1)
                    threadsPerThreadgroup:MTLSizeMake(128, 1, 1)];
            runtime->lightonocr3_wide_gate_up_calls =
                termite_metal_u64_saturating_add(runtime->lightonocr3_wide_gate_up_calls, 1);
        }
'''+needle)
replace('small != nil && small == runtime->lightonocr3_gate_up_wide32_pipeline ? "lightonocr3_wide_gate_up_mpp"', 'small != nil && small == runtime->lightonocr3_gate_up_wide64_pipeline ? "lightonocr3_wide64_gate_up_mpp" : small != nil && small == runtime->lightonocr3_gate_up_wide32_pipeline ? "lightonocr3_wide_gate_up_mpp"')
p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text()
a=s.index('static int wide_gate_up_check(');b=s.index('\nstatic ',a+10);chunk=s[a:b]
chunk=chunk.replace('bool qualified = rows >= 32 && rows <= 64 && in == 1024;','bool qualified = rows >= 32 && rows <= 64 && (in == 1024 ||\n            (in == 2560 && termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP"))));')
needle='        id<MTLComputePipelineState> wide32 = r->lightonocr3_gate_up_wide32_pipeline;'
assert needle in chunk
chunk=chunk.replace(needle,needle+'\n        id<MTLComputePipelineState> wide64 = r->lightonocr3_gate_up_wide64_pipeline;\n        r->lightonocr3_gate_up_wide64_pipeline = nil;')
chunk=chunk.replace('        r->lightonocr3_gate_up_wide32_pipeline = wide32;','        r->lightonocr3_gate_up_wide32_pipeline = wide32;\n        r->lightonocr3_gate_up_wide64_pipeline = wide64;')
s=s[:a]+chunk+s[b:]
needle='        if (argc == 2 && strcmp(argv[1], "--check-wide-gate-up") == 0) {'
assert s.count(needle)==1
s=s.replace(needle,'''        if (argc == 2 && (strcmp(argv[1], "--check-wide-gate-up") == 0 ||
                          strcmp(argv[1], "--check-wide-gate-up-large64") == 0)) {
            if (strcmp(argv[1], "--check-wide-gate-up-large64") == 0)
                setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP", "1", 1);
            else
                unsetenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP");''')
p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text()
needle='    env["ANTFLY_LIGHTONOCR3_GPU_GREEDY_STREAM"] = "1" if args.gpu_greedy_stream else "0"'
assert s.count(needle)==1;s=s.replace(needle,needle+'''
    env["TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP"] = (
        "1" if args.wide64_gate_up else "0"
    )''')
needle='    parser.add_argument("--disable-wide-gate-up", action="store_true")'
assert s.count(needle)==1;s=s.replace(needle,needle+'\n    parser.add_argument("--wide64-gate-up", action="store_true")')
p.write_text(s)
