from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
s=(v/'engine50_recurrent_probe_verify2.m').read_text()
s=s.replace('if(termite_metal_decode_runtime_qwen35_core_batch_begin(r,rows)!=1)','if(rows>1&&termite_metal_decode_runtime_qwen35_core_batch_begin(r,rows)!=1)').replace('if(termite_metal_decode_runtime_qwen35_core_batch_end(r))','if(rows>1&&termite_metal_decode_runtime_qwen35_core_batch_end(r))')
assert 'const size_t pages[]={64,48,33};'in s
s=s.replace('const size_t pages[]={64,48,33};','const size_t pages[]={33};').replace('for(int i=0;i<3;i++){int rc=working50','for(int i=0;i<1;i++){int rc=working50')
(v/'engine50_recurrent_probe_verify3.m').write_text(s)
s=(v/'build_engine50_recurrent_probe_verify2.py').read_text().replace('engine50_recurrent_probe_verify2','engine50_recurrent_probe_verify3').replace('build_verify2_manifest','build_verify3_manifest').replace('build-verify2.txt','build-verify3.txt')
(v/'build_engine50_recurrent_probe_verify3.py').write_text(s)
record=dict(status='singleton_fixture_correction_only',original_failed_audit_sha256=hashlib.sha256((o/'engine50_recurrent_probe_audit.json').read_bytes()).hexdigest(),completed_cases_preserved='24 valid ABBA records at 64 and 48 pages, no numerical/canary failures',failure='33 pages end with a singleton; existing batch_begin API declines one-item batches. New fixture routes singleton through existing direct core call, as production does.',rerun_scope='33 pages only; same three shader sources and runtime copy. Reruns staged conformance on the unchanged kernels before the missing 33-page cases.')
(o/'engine50_recurrent_probe_singleton_fixture_recovery.json').write_text(json.dumps(record,indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('drivers',[v/n for n in ['prepare_engine50_recurrent_probe_verify3.py','engine50_recurrent_probe_verify3.m','build_engine50_recurrent_probe_verify3.py']],'drivers_manifest.json')
