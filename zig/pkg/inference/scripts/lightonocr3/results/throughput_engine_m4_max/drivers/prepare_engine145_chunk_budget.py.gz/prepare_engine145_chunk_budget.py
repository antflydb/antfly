from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/src/server/server.zig';s=p.read_text()
a='.packed_mixed = features.packed_mixed };'
assert s.count(a)==1;s=s.replace(a,'.packed_mixed = features.packed_mixed, .prefill_query_chunk_rows = features.prepared_prefill_chunk_rows };')
a='        packed_mixed: bool = false,\n        decoder_backend_peak: usize = 0,'
assert s.count(a)==1;s=s.replace(a,'        packed_mixed: bool = false,\n        prefill_query_chunk_rows: usize = 0,\n        decoder_backend_peak: usize = 0,')
a='            var retained_decoder = decoder;\n            if (self.share_decoder_scratch) {'
b='''            if (self.prefill_query_chunk_rows != 0 and
                (!self.share_decoder_scratch or !self.packed_mixed or
                    self.prefill_query_chunk_rows < 64 or self.prefill_query_chunk_rows > 1024)) return error.ResourceLimitExceeded;
            const working_rows = if (self.prefill_query_chunk_rows != 0)
                @min(prompt_tokens, self.prefill_query_chunk_rows)
            else
                prompt_tokens;
            // Only transient, gate-owned activations use the bounded query
            // shape. Full page KV, projected inputs, recurrent histories and
            // escaping outputs retain their original admission below. The
            // scratch estimate is independent of KV dtype; its KV result is
            // deliberately discarded, rather than replacing the page estimate.
            const working_scratch = if (self.prefill_query_chunk_rows != 0)
                (try runtime.tier.memory.estimateGptGeneration(.metal, .f16, cfg, prompt_tokens, output_tokens, working_rows)).scratch_bytes
            else
                decoder.backend_scratch_bytes;
            var retained_decoder = decoder;
            if (self.share_decoder_scratch) {'''
assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('product(&.{ decoder.backend_scratch_bytes, 2, self.max_prefill_batch_items })','product(&.{ working_scratch, 2, self.max_prefill_batch_items })')
s=s.replace('if (prompt_tokens == 0) return error.ResourceLimitExceeded;\n                    // Dense','if (working_rows == 0) return error.ResourceLimitExceeded;\n                    // Dense')
s=s.replace('std.math.add(usize, prompt_tokens, self.decoder_rows - 1)','std.math.add(usize, working_rows, self.decoder_rows - 1)')
s=s.replace('product(&.{ two_sets, rows }), prompt_tokens)','product(&.{ two_sets, rows }), working_rows)')
p.write_text(s)
p=r/'zig/pkg/inference/src/pipelines/generation.zig';s=p.read_text();a='''        if (prepared.plan.tokenCount() != seq_len or !decode_state.isPaged()) return error.InvalidPreparedPrompt;
        try decode_state.ensureQwen35LinearCache(self.gpt_config);''';b='''        if (prepared.plan.tokenCount() != seq_len or !decode_state.isPaged()) return error.InvalidPreparedPrompt;
        // A chunk-sized epoch workspace cannot admit the direct full-prefix
        // fallback. Reject unsupported routing before cache or GPU mutation.
        if (self.prepared_qwen_prefill_chunk_rows != 0 and
            (self.qwen_prefill_batch == null or prepared.deepstack_layer_count != 0)) return error.InvalidPreparedPrompt;
        try decode_state.ensureQwen35LinearCache(self.gpt_config);''';assert s.count(a)==1;s=s.replace(a,b);p.write_text(s)
print('source145 bounded transient admission prepared')
