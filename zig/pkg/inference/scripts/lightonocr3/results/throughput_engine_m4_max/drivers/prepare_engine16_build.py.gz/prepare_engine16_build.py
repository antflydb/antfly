from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine15_gpu_build.py').read_text().replace('engine15','engine16');s=s.replace("print('exit',r.returncode);sys.exit(r.returncode)",'''print('exit',r.returncode)
if r.returncode==0:
 import re
 log=Path('/private/tmp/ocr-engine16-gpu-build.txt').read_text()
 matches=re.findall(r'attention_batch_calls=(\\d+) attention_batch_rows=(\\d+)',log)
 kernels=re.findall(r'attention_batch_kernel_calls=(\\d+)',log)
 assert matches and any(int(x)>0 and int(y)>=2*int(x) for x,y in matches),matches
 assert kernels and any(int(x)>0 for x in kernels),kernels
 print('qualified production batch attention counters',matches,kernels)
sys.exit(r.returncode)''');(v/'run_engine16_gpu_build.py').write_text(s)
files=json.loads((v/'engine15-freeze.json').read_text());(v/'engine16-freeze.json').write_text(json.dumps({f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in files},indent=2)+'\n')
s=(v/'run_engine15_policies.py').read_text().replace('engine15','engine16');s=s.replace("    stream_stats=re.findall(","    kernel_stats=re.findall(r'attention_batch_kernel_calls=(\\d+)',section);sample['attention_batch_kernel_calls']=sum(int(x)for x in kernel_stats);assert kernel_stats and (sample['attention_batch_kernel_calls']>0)==batched,sample\n    stream_stats=re.findall(",1).replace("'attention_batch_rows','stream_forward_splits'", "'attention_batch_rows','attention_batch_kernel_calls','stream_forward_splits'");(v/'run_engine16_policies.py').write_text(s)
(v/'engine16_benchmark_concurrency.py').write_bytes((v/'engine15_benchmark_concurrency.py').read_bytes())
(v/'engine16_default_gpu_test.py').write_text((v/'engine15_default_gpu_test.py').read_text().replace('engine15','engine16'))
