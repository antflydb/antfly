from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=p.read_text();needle='    uint64_t lightonocr3_prefill_norm_dispatches;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    uint64_t lightonocr3_short_prefill_norm_dispatches;\n    uint64_t lightonocr3_short_direct_attention_dispatches;');needle='void termite_metal_decode_runtime_lighton_wide_recurrent_stats(';assert s.count(needle)==1;s=s.replace(needle,'''void termite_metal_decode_runtime_lighton_short_prefill_stats(termite_metal_decode_runtime *runtime, uint64_t *out) {
    if (out == NULL) return;
    out[0] = runtime == NULL ? 0 : runtime->lightonocr3_short_prefill_norm_dispatches;
    out[1] = runtime == NULL ? 0 : runtime->lightonocr3_short_direct_attention_dispatches;
}
'''+needle)
needle='    if ((runtime->lightonocr3_prefill_attention_mpp_dispatches++ == 0 || p->q_len < 128) &&';assert s.count(needle)==1;s=s.replace(needle,'''    if (p->q_len < 128 && direct) runtime->lightonocr3_short_direct_attention_dispatches++;
    if (runtime->lightonocr3_prefill_attention_mpp_dispatches++ == 0 &&''')
needle='''            if (prefill_norm && runtime->lightonocr3_prefill_norm_dispatches++ == 0 &&''';assert s.count(needle)==1;s=s.replace(needle,'''            if (prefill_norm && seq < 128) runtime->lightonocr3_short_prefill_norm_dispatches++;
'''+needle);p.write_text(s)
p=r/'zig/pkg/inference/src/backends/metal_runtime.zig';s=p.read_text();needle='pub extern fn termite_metal_decode_runtime_lighton_wide_recurrent_stats(';assert s.count(needle)==1;s=s.replace(needle,'pub extern fn termite_metal_decode_runtime_lighton_short_prefill_stats(runtime: ?*RawMetalDecodeRuntime, out: *[2]u64) void;\n'+needle);p.write_text(s)
p=r/'zig/pkg/inference/src/ops/metal_compute.zig';s=p.read_text();needle='    lighton_wide_recurrent_start: [3]u64 = @splat(0),';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    lighton_short_prefill_start: [2]u64 = @splat(0),');needle='        metal_runtime_mod.termite_metal_decode_runtime_lighton_wide_recurrent_stats(raw, &self.lighton_wide_recurrent_start);';assert s.count(needle)==1;s=s.replace(needle,needle+'\n        metal_runtime_mod.termite_metal_decode_runtime_lighton_short_prefill_stats(raw, &self.lighton_short_prefill_start);');needle='    pub fn lightOnWideRecurrentStats(cb: *const ops.ComputeBackend) [3]u64 {';assert s.count(needle)==1;s=s.replace(needle,'''    pub fn lightOnShortPrefillStats(cb: *const ops.ComputeBackend) [2]u64 {
        if (cb.kind() != .metal or cb.vtable.decoderRuntimeArgmaxRowsSuppress != &decoderRuntimeArgmaxRowsSuppressOp) return @splat(0);
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        var stats: [2]u64 = @splat(0);
        metal_runtime_mod.termite_metal_decode_runtime_lighton_short_prefill_stats(self.provider_impl.raw_decode_runtime, &stats);
        for (&stats, self.lighton_short_prefill_start) |*value, start| value.* -|= start;
        return stats;
    }

'''+needle);needle='    pub fn lightOnWideRecurrentStats(_: *const ops.ComputeBackend) [3]u64 {';assert s.count(needle)==1;s=s.replace(needle,'''    pub fn lightOnShortPrefillStats(_: *const ops.ComputeBackend) [2]u64 {
        return @splat(0);
    }

'''+needle);p.write_text(s)
p=r/'zig/pkg/inference/src/server/server.zig';s=p.read_text();needle='                    const wide_recurrent = if (comptime build_options.enable_metal)';assert s.count(needle)==1;s=s.replace(needle,'''                    const short_prefill = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnShortPrefillStats(&cb) else @as([2]u64, @splat(0));
                    std.debug.print("LIGHTONOCR3 short_prefill_core_dispatches={d} short_direct_attention_dispatches={d}\\n", .{ short_prefill[0], short_prefill[1] });
'''+needle);p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';s=p.read_text();needle='                    sample["packed_prefill_chunks"] = sum(';assert s.count(needle)==1;s=s.replace(needle,'''                    short_prefill = re.findall(
                        r"LIGHTONOCR3 short_prefill_core_dispatches=(\\d+) short_direct_attention_dispatches=(\\d+)",
                        section,
                    )
                    sample["short_prefill_core_dispatches"] = sum(int(core) for core, _ in short_prefill)
                    sample["short_direct_attention_dispatches"] = sum(int(attention) for _, attention in short_prefill)
'''+needle);p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m';s=p.read_text();a=s.index('static int prefill_core_check(');b=s.index('static int compute_copy_check(',a);part=s[a:b];needle='            uint64_t before = r->lightonocr3_prefill_norm_dispatches;';assert part.count(needle)==1;part=part.replace(needle,needle+'\n            uint64_t short_before[2], short_after[2];\n            termite_metal_decode_runtime_lighton_short_prefill_stats(r, short_before);');needle='''            if (benchmark)
                printf(''';assert part.count(needle)==1;part=part.replace(needle,'''            termite_metal_decode_runtime_lighton_short_prefill_stats(r, short_after);
            if (short_after[0] - short_before[0] != (variant == 1 && seq >= 2 && seq < 128 ? 1 : 0) ||
                short_after[1] != short_before[1]) return 9;
'''+needle);s=s[:a]+part+s[b:];p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/check_metal_prefill_attention.m';s=p.read_text();needle='            const uint64_t before = r->lightonocr3_prefill_attention_mpp_dispatches;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n            uint64_t short_before[2], short_after[2];\n            termite_metal_decode_runtime_lighton_short_prefill_stats(r, short_before);');needle='''            if (benchmark)
                printf(''';assert s.count(needle)==1;s=s.replace(needle,'''            termite_metal_decode_runtime_lighton_short_prefill_stats(r, short_after);
            if (short_after[0] != short_before[0] ||
                short_after[1] - short_before[1] != (expected_direct && n < 128 ? 1 : 0)) return 16;
'''+needle);p.write_text(s)
print('source158 scoped short counters; shader arithmetic and routing unchanged from155')
