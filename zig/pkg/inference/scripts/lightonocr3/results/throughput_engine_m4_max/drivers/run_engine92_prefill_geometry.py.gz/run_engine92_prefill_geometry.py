from pathlib import Path
import hashlib,json,os,subprocess,psutil,time,datetime
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((o/'engine91_precision_memory_screen74_audit.json').read_text())['status']=='hold_no_clear_bf16_screen_win'
prep=json.loads((v/'engine92_geometry_preparation.json').read_text());assert all(sha(r/f)==h for f,h in prep['input_sha256'].items());assert sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')==prep['production_c_sha256']
a=o/'engine92_prefill_geometry_audit.json';assert not a.exists();d=dict(status='building',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),primary_throughput_eligible=False,scope=prep['scope'],preparation_sha256=sha(v/'engine92_geometry_preparation.json'),driver_sha256=sha(Path(__file__)),checks=[])
def save():a.write_text(json.dumps(d,indent=2)+'\n')
save();binary=v/'engine92_geometry_probe';assert not binary.exists();cmd=['clang','-O3','-fobjc-arc','-I','zig/pkg/inference/src/backends',str(v/'engine92_geometry_probe.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(binary)]
with Path('/private/tmp/ocr-engine92-geometry-build.txt').open('w')as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
d['build_exit_code']=p.returncode;save();assert p.returncode==0;d['binary_sha256']=sha(binary);save()
try:
 for kind in [1,2,3]:
  for width in [64,128,256,512]:
   while psutil.virtual_memory().available<8*1024**3:print('WAIT GEOMETRY92 original reserve',flush=True);time.sleep(15)
   row=dict(kind=kind,width=width,available_bytes=psutil.virtual_memory().available,working_estimate_bytes=2*1024**3,os_reserve_bytes=6*1024**3);d['checks'].append(row);d['status']='running';save()
   so=Path(f'/private/tmp/ocr-engine92-geometry-k{kind}-w{width}-stdout.txt');se=Path(f'/private/tmp/ocr-engine92-geometry-k{kind}-w{width}-stderr.txt');assert not so.exists()and not se.exists();print('START GEOMETRY92',kind,width,flush=True)
   with so.open('w')as f,se.open('w')as e:p=subprocess.run([str(binary),str(kind),str(width)],stdout=f,stderr=e,env=dict(os.environ,ANTFLY_LIGHTONOCR3_THROUGHPUT='0'),timeout=900)
   records=[json.loads(l)for l in so.read_text().splitlines()if l.startswith('{"width":')];row.update(exit_code=p.returncode,stdout_sha256=sha(so),stderr_sha256=sha(se),records=records)
   if p.returncode==77:assert not records;row['status']='unsupported_width_skipped';save();continue
   save();assert p.returncode==0 and len(records)==1200,(kind,width,p.returncode,len(records));assert 'GEOMETRY92 EXACT FULL OUTPUT/STATE/CANARY PASS'in se.read_text();row['status']='exact_prototype_pass';save();print('DONE GEOMETRY92',kind,width,flush=True)
 d['status']='prototype_pass';save();print('GEOMETRY92 PROBE DONE',flush=True)
except BaseException as e:d.update(status='failed',error=repr(e));save();raise
