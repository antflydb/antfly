from pathlib import Path
import hashlib,json,subprocess,statistics
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((out/'engine50_recurrent_probe_build_verify2_manifest.json').read_text())
assert m['exit_code']==0 and sha(m['binary'])==m['binary_sha256']
for p,h in m['inputs'].items():assert sha(p)==h,p
raw=Path('/private/tmp/ocr-engine50-recurrent-probe-gpu-verify2.jsonl')
err=Path('/private/tmp/ocr-engine50-recurrent-probe-gpu-verify2-stderr.txt')
assert not raw.exists()and not err.exists()
with raw.open('w')as stdout,err.open('w')as stderr:r=subprocess.run([m['binary']],stdout=stdout,stderr=stderr)
audit=out/'engine50_recurrent_probe_audit.json'
record=dict(status='failed'if r.returncode else'running',exit_code=r.returncode,build_manifest_sha256=sha(out/'engine50_recurrent_probe_build_verify2_manifest.json'),raw_stdout_sha256=sha(raw),raw_stderr_sha256=sha(err),scope='Private diagnostic only. 24 distinct recurrent layers, 64/48/33 independent page states. Same F32 state/layout/precision, actual runtime indirect resource path; candidates change lane memory mapping. ABBA two warm/eight timed frames per leg. Every output and full persistent state compared after each leg; unchanged single/batch staged conformance covers cold/continuation/offset/private producer/fallback/cancel. Not a full-model or vLLM win.',cases=[])
audit.write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==0,r.returncode
rows=[json.loads(x)for x in raw.read_text().splitlines()]
assert len(rows)==36 and len({(x['pages'],x['candidate'],x['leg'])for x in rows})==36
stderr=err.read_text()
for candidate in [1,2,3]:assert f'CONFORMANCE PASS mode={candidate}'in stderr
for pages in [64,48,33]:
 for candidate in [1,2,3]:
  group=[x for x in rows if x['pages']==pages and x['candidate']==candidate]
  assert [x['mode']for x in group]==[0,candidate,candidate,0]
  assert all(x['checked_elements']>0 and x['full_output_state_max_abs']<=2e-4 and len(x['gpu_us'])==8 for x in group)
  b=[t for x in group if x['mode']==0 for t in x['gpu_us']]
  c=[t for x in group if x['mode']==candidate for t in x['gpu_us']]
  record['cases'].append(dict(pages=pages,candidate=candidate,baseline_median_gpu_us=statistics.median(b),candidate_median_gpu_us=statistics.median(c),candidate_to_baseline=statistics.median(c)/statistics.median(b),legs=group))
record['status']='pass';audit.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps([(x['pages'],x['candidate'],x['candidate_to_baseline'])for x in record['cases']]),flush=True)
