from pathlib import Path
import json,hashlib,subprocess,sys
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';out=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ref=json.loads((out/'vllm_4b_primary_reference13_r0_auto_c32_r128/report.json').read_text());reference={x['image_index']:x['text']for x in ref['references']}
records=[];excluded=[]
for c,vf,vision_batch in [(48,4,False),(64,2,False),(64,4,False),(64,3,False),(48,1,True)]:
 prefix='shared_decoder_visionbatch4_wait20ms'if vision_batch else'shared_decoder'
 rp=out/f'engine36_4b_{prefix}_c{c}_vf{vf}_physical32_device17_scratch10_sf1_f32_r128_0/report.json'
 d=json.loads(rp.read_text());r=d['results'][0]
 if r['status']!='ok':
  raw=(rp.parent/r['log']).read_text()
  assert r['exit_code']==1 and 'FAIL (ResourceTemporarilyUnavailable)'in raw and 'admission_pressure=domain_backend'in raw
  excluded.append(dict(report=str(rp.relative_to(out)),report_sha256=sha(rp),concurrency=c,vision_frame_blocks=vf,reason='Backend cap admission timeout; incomplete run has no throughput.',primary_throughput_eligible=False))
  continue
 s=r['policy_rounds'][0]
 assert r['status']=='ok' and r['serial_reference_parity']and r['cross_runtime_content_parity']and s['completed']==128
 assert{x['image_index']:x['text']for x in r['references']}==reference
 assert d['shared_decoder_scratch']and s['shared_decoder_peak_bytes']>0 and s['host_recurrent_bytes_total']==0 and s['single_frame_topology_mismatches']==0
 records.append(dict(report=str(rp.relative_to(out)),report_sha256=sha(rp),concurrency=c,vision_frame_blocks=vf,vision_batch=vision_batch,full_fixture_string_identity=True,**{k:s.get(k)for k in ['completed','pages_per_second','process_cpu_ms','shared_decoder_peak_bytes','recurrent_cache_pages','host_recurrent_bytes_total','average_decode_rows','executor_steps','single_frame_steps','single_frame_topology_mismatches','admission_pressures','framed_runtime_totals']}))
audit=dict(scope='Complete successive shared-machine candidate profiles, not a fresh vLLM comparison or isolated causal attribution. Backend17/scratch10/KV4/combined28 GiB and six-GiB live reserve unchanged.',records=records,excluded=excluded,build_manifest_sha256=sha(out/'engine36_build_manifest.json'))
(out/'engine36_4b_comparison_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
source=(v/'archive_engine10_evidence.py').read_text();exec(source[:source.index("archive('qualification'")])
archive('qualification',list(Path('/private/tmp').glob('ocr-engine36-4b-shared*.txt'))+list(Path('/private/tmp').glob('ocr-engine36-4b-vision-batch*.txt'))+list(Path('/private/tmp').glob('ocr-engine36-vision-batch*.txt')),'logs_manifest.json')
archive('drivers',[v/'audit_engine36_large_profiles.py'],'drivers_manifest.json')
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine36_4b_shared_decoder*'],check=True)
best=max(records,key=lambda x:x['pages_per_second']);(v/'engine36_best_large.json').write_text(json.dumps(best,indent=2)+'\n');print('BEST',best,flush=True)
