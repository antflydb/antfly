from pathlib import Path
import hashlib,json,subprocess,sys,time,os
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
subprocess.run([sys.executable,str(v/'verify_engine81_resident_saved_results2.py')],check=True)
print('START ENGINE81 CPU checks',flush=True)
with Path('/private/tmp/ocr-engine81-cpu-parent.txt').open('w')as log:result=subprocess.run([sys.executable,str(v/'run_engine81_metal_disabled.py')],stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0,result.returncode
f=json.loads((v/'engine81-freeze.json').read_text());assert all(sha(r/p)==h for p,h in f.items())
old=json.loads((v/'engine80-freeze.json').read_text());changed=[p for p in f if f[p]!=old[p]];assert sorted(changed)==sorted(['zig/pkg/inference/src/server/server.zig','zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py'])
(o/'engine81_c_runtime_reuse_audit.json').write_text(json.dumps(dict(status='pass',scope='Only resident benchmark test harness and Python driver change. All C/Metal/runtime/ops/model source inputs remain byte-identical to source80. Retain original nineteen C suites and extended FFN/pending-prefix qualification.',unchanged_inputs={p:h for p,h in f.items()if p not in changed},changed_inputs=changed,driver_sha256=sha(Path(__file__))),indent=2)+'\n')
m=json.loads((o/'engine81_build_manifest.json').read_text());binary=v/'qualified-binaries/engine81-test'
if not binary.exists():os.link(Path(m['binary_path']),binary)
assert sha(binary)==m['binary_sha256']
print('ENGINE81 FINAL QUALIFICATION DONE',flush=True)
