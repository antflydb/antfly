from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');dest=v/'engine56-proposal'
def put(p,s):
 t=dest/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_text(s)
p='zig/pkg/inference/src/backends/metal_runtime.zig';s=Path(p).read_text()+'''
pub extern fn termite_metal_decode_runtime_set_lighton_vision_workspace_cache(runtime: ?*RawMetalDecodeRuntime, enabled: c_int) c_int;
pub extern fn termite_metal_decode_runtime_lighton_vision_workspace_stats(runtime: ?*RawMetalDecodeRuntime, out: *[3]u64) void;
pub extern fn termite_metal_decode_runtime_lighton_large_vision_pack_stats(runtime: ?*RawMetalDecodeRuntime, out: *[2]u64) void;
''';put(p,s)
p='zig/pkg/inference/src/ops/metal_compute.zig';s=Path(p).read_text();needle='    lighton_batch_argmax_start: [2]u64 = @splat(0),';assert needle in s
s=s.replace(needle,needle+'\n    lighton_vision_workspace_start: [3]u64 = @splat(0),\n    lighton_large_vision_pack_start: [2]u64 = @splat(0),')
needle='        metal_runtime_mod.termite_metal_decode_runtime_lighton_batch_argmax_stats(raw, &self.lighton_batch_argmax_start);';assert needle in s
s=s.replace(needle,needle+'\n        metal_runtime_mod.termite_metal_decode_runtime_lighton_vision_workspace_stats(raw, &self.lighton_vision_workspace_start);\n        metal_runtime_mod.termite_metal_decode_runtime_lighton_large_vision_pack_stats(raw, &self.lighton_large_vision_pack_start);')
needle='    pub fn lightOnBatchedArgmaxStats('
extra='''    /// Only an epoch whose shared vision peak survives backend teardown may
    /// retain these two packing banks across frames. clearVisionWorkspace in
    /// deinit releases them before the caller retires that admission lease.
    pub fn setLightOnVisionWorkspaceCache(cb: *const ops.ComputeBackend, enabled: bool) !void {
        if (cb.kind() != .metal or cb.vtable.decoderRuntimeArgmaxRowsSuppress != &decoderRuntimeArgmaxRowsSuppressOp) {
            if (enabled) return error.UnsupportedVisionWorkspaceCache;
            return;
        }
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        if (enabled and (!self.lightonocr3_projections or !metal_runtime_mod.qualifiedM4DeviceDefault())) return error.UnsupportedVisionWorkspaceCache;
        if (metal_runtime_mod.termite_metal_decode_runtime_set_lighton_vision_workspace_cache(self.provider_impl.raw_decode_runtime, @intFromBool(enabled)) != 0) return error.VisionWorkspaceBusy;
    }

    pub fn lightOnVisionWorkspaceStats(cb: *const ops.ComputeBackend) [3]u64 {
        if (cb.kind() != .metal or cb.vtable.decoderRuntimeArgmaxRowsSuppress != &decoderRuntimeArgmaxRowsSuppressOp) return @splat(0);
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        var stats: [3]u64 = @splat(0);
        metal_runtime_mod.termite_metal_decode_runtime_lighton_vision_workspace_stats(self.provider_impl.raw_decode_runtime, &stats);
        for (stats[0..2], self.lighton_vision_workspace_start[0..2]) |*value, baseline| value.* -|= baseline;
        return stats;
    }

    pub fn lightOnLargeVisionPackStats(cb: *const ops.ComputeBackend) [2]u64 {
        if (cb.kind() != .metal or cb.vtable.decoderRuntimeArgmaxRowsSuppress != &decoderRuntimeArgmaxRowsSuppressOp) return @splat(0);
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        var stats: [2]u64 = @splat(0);
        metal_runtime_mod.termite_metal_decode_runtime_lighton_large_vision_pack_stats(self.provider_impl.raw_decode_runtime, &stats);
        for (&stats, self.lighton_large_vision_pack_start) |*value, baseline| value.* -|= baseline;
        return stats;
    }

'''
assert needle in s;s=s.replace(needle,extra+needle);put(p,s)
p='zig/pkg/inference/src/server/server.zig';s=Path(p).read_text();needle='            stream_chunks: bool = false,';s=s.replace(needle,needle+'\n            vision_workspace_cache: bool = false,')
needle='                features.stream_chunks = features.gpu_greedy_stream and platform.env.getenvBool("ANTFLY_LIGHTONOCR3_STREAM_CHUNKS");'
s=s.replace(needle,needle+'''
                features.vision_workspace_cache = features.epoch_auxiliary and metal_runtime.qualifiedM4DeviceDefault() and cfg.hasQwen35VisionArchitectureContract() and
                    !platform.env.getenvBool("ANTFLY_LIGHTONOCR3_DISABLE_SHARED_VISION_PEAK") and platform.env.getenvBool("ANTFLY_LIGHTONOCR3_KEEP_VISION_WORKSPACE");''')
needle='                    try M.setLightOnStreamChunks(&cb, ctx.features.stream_chunks);';assert needle in s
s=s.replace(needle,needle+'''
                    // admitPage has already acquired the shared vision peak.
                    // It outlives cb.deinit and its explicit workspace clear.
                    try M.setLightOnVisionWorkspaceCache(&cb, ctx.features.vision_workspace_cache);''')
needle='                    const batch_argmax = ';a=s.index(needle);b=s.index('\n',s.index('std.debug.print("LIGHTONOCR3 batch_argmax_calls=',a))+1
s=s[:b]+'''                    const vision_workspace = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnVisionWorkspaceStats(&cb) else @as([3]u64, @splat(0));
                    const large_vision_pack = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnLargeVisionPackStats(&cb) else @as([2]u64, @splat(0));
                    std.debug.print("LIGHTONOCR3 vision_workspace_cache={d}\\nLIGHTONOCR3 vision_workspace_allocations={d}\\nLIGHTONOCR3 vision_workspace_reuses={d}\\nLIGHTONOCR3 vision_workspace_bytes={d}\\n", .{ @intFromBool(ctx.features.vision_workspace_cache), vision_workspace[0], vision_workspace[1], vision_workspace[2] });
                    std.debug.print("LIGHTONOCR3 large_vision_pack_calls={d}\\nLIGHTONOCR3 large_vision_pack_reuse_hits={d}\\n", .{ large_vision_pack[0], large_vision_pack[1] });
'''+s[b:]
needle='        "ANTFLY_LIGHTONOCR3_GPU_GREEDY_STREAM",';a=s.index(needle);s=s[:a]+'''        "ANTFLY_LIGHTONOCR3_KEEP_VISION_WORKSPACE",
'''+s[a:];put(p,s)
p='zig/pkg/inference/src/server/executor_microbatch.zig';s=Path(p).read_text();needle='            var live = false;';assert s.count(needle)==1
s=s.replace(needle,needle+'\n            var live_deadline: ?std.Io.Clock.Timestamp = null;')
needle='                live = live or (!expired and !ticket.cancel_requested.load(.acquire) and !isCanceled(ticket.cancellation));';assert needle in s
s=s.replace(needle,'''                const ticket_live = !expired and !ticket.cancel_requested.load(.acquire) and !isCanceled(ticket.cancellation);
                live = live or ticket_live;
                if (ticket_live) if (ticket.deadline) |deadline| {
                    if (live_deadline == null or deadline.raw.nanoseconds < live_deadline.?.raw.nanoseconds) live_deadline = deadline;
                };''')
s=s.replace('            const epoch = self.execution_epoch.load(.acquire);','            const wake_deadline = boundedLeaderWaitDeadline(now, 100_000, live_deadline);\n            const epoch = self.execution_epoch.load(.acquire);')
s=s.replace('io.futexWaitTimeout(u32, &self.execution_epoch.raw, epoch, .{ .duration = .{ .raw = .fromMilliseconds(10), .clock = .awake } })','io.futexWaitTimeout(u32, &self.execution_epoch.raw, epoch, .{ .deadline = wake_deadline })')
put(p,s)
p='zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';s=Path(p).read_text();needle='    env["ANTFLY_LIGHTONOCR3_STREAM_CHUNKS"]';a=s.index(needle);s=s[:a]+'''    env["ANTFLY_LIGHTONOCR3_KEEP_VISION_WORKSPACE"] = "1" if args.cache_vision_workspace else "0"
    env["TERMITE_METAL_ENABLE_LIGHTONOCR3_LARGE_VISION_PACK_REUSE"] = "1" if args.large_vision_pack_reuse else "0"
'''+s[a:]
needle='                        "batch_argmax_calls",';s=s.replace(needle,'''                        "vision_workspace_allocations",
                        "vision_workspace_reuses",
                        "vision_workspace_bytes",
                        "large_vision_pack_calls",
                        "large_vision_pack_reuse_hits",
'''+needle)
needle='    args = parser.parse_args()';s=s.replace(needle,'''    parser.add_argument("--cache-vision-workspace", action="store_true", help="Reuse vision SDPA packing banks under the existing shared epoch lease")
    parser.add_argument("--large-vision-pack-reuse", action="store_true", help="Reuse frame-local BF16 projection inputs for 4097..16384 vision rows")
'''+needle)
s=s.replace('        "batch_argmax": args.batch_argmax,','        "batch_argmax": args.batch_argmax,\n        "cache_vision_workspace": args.cache_vision_workspace,\n        "large_vision_pack_reuse": args.large_vision_pack_reuse,')
put(p,s)
print('prepared Zig/benchmark proposal; admission caps and reservation sizes unchanged')
