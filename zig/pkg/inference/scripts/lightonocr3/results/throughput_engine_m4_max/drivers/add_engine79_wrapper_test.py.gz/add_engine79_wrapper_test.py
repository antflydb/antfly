from pathlib import Path
p=Path('zig/pkg/inference/src/backends/metal_runtime.zig');s=p.read_text();needle='test "LightOnOCR3 batched gate up wrapper reaches qualified device kernel" {';assert s.count(needle)==1
new='''test "LightOnOCR3 prefill fused FFN wrapper retains private scratch through submit and cancellation" {
    if (!build_options.enable_metal or !metalDeviceAvailable()) return error.SkipZigTest;
    const allocator = std.testing.allocator;
    const flags = [_][:0]const u8{
        "TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN",
        "TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS",
        "TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY",
        "TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_FFN",
        "TERMITE_METAL_DISABLE_LIGHTONOCR3_MPP",
        "TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PROJECTIONS",
        "TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PACK_REUSE",
        "TERMITE_METAL_DISABLE_LIGHTONOCR3_PLANNED_MPP",
    };
    var original: [flags.len]?[:0]u8 = @splat(null);
    defer for (flags, original) |name, value| {
        if (value) |saved| {
            _ = setenv(name, saved.ptr, 1);
            allocator.free(saved);
        } else _ = unsetenv(name);
    };
    for (flags, 0..) |name, i| {
        if (std.c.getenv(name)) |value| original[i] = try allocator.dupeSentinel(u8, std.mem.span(value), 0);
    }
    for (flags, 0..) |name, i| {
        if (i < 3) {
            try std.testing.expectEqual(@as(c_int, 0), setenv(name, "1", 1));
        } else try std.testing.expectEqual(@as(c_int, 0), unsetenv(name));
    }
    const metal_native_provider = @import("metal_native_provider.zig");
    var provider = try metal_native_provider.MetalNativeProvider.create();
    defer provider.deinitOwned();
    const runtime = provider.raw_decode_runtime orelse return error.SkipZigTest;
    termite_metal_decode_runtime_set_lightonocr3_projections(runtime, 1);
    termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(runtime, 1);
    const rows = 128;
    const hidden = 2560;
    const intermediate = 9216;
    const weights = try allocator.alloc(u16, hidden * intermediate);
    defer allocator.free(weights);
    const bias = try allocator.alloc(f32, intermediate);
    defer allocator.free(bias);
    @memset(weights, 0);
    @memset(bias, 1);
    for (0..2) |slot| try std.testing.expectEqual(@as(c_int, 0), termite_metal_decode_runtime_prepare_linear_bf16(runtime, slot, std.mem.sliceAsBytes(weights).ptr, weights.len * 2, bias.ptr, hidden, intermediate));
    @memset(bias, 0);
    for (0..hidden) |col| weights[col * intermediate + col] = 0x3f80;
    try std.testing.expectEqual(@as(c_int, 0), termite_metal_decode_runtime_prepare_linear_bf16(runtime, 2, std.mem.sliceAsBytes(weights).ptr, weights.len * 2, bias.ptr, intermediate, hidden));
    const data = try allocator.alloc(f32, rows * hidden);
    defer allocator.free(data);
    @memset(data, 0);
    var input = try testDeviceTensorFromSlice(runtime, data, &.{rows, hidden});
    defer input.deinit();
    const request = .{
        .input = input, .gate_slot = @as(usize, 0), .up_slot = @as(usize, 1), .down_slot = @as(usize, 2),
        .hidden_size = @as(usize, hidden), .intermediate_size = @as(usize, intermediate),
        .activation = ops.DecoderRuntimeActivationKind.silu,
    };
    try std.testing.expect((try decoderRuntimeTryApplyLightOnPrefillFfn(&provider, request)) == null);
    for (0..3) |iteration| {
        try std.testing.expectEqual(@as(c_int, 0), termite_metal_decode_runtime_begin_frame(runtime));
        var frame = true;
        defer if (frame) { _ = termite_metal_decode_runtime_cancel_frame(runtime); };
        try setActiveFrameRegime(runtime, .prefill);
        var output = (try decoderRuntimeTryApplyLightOnPrefillFfn(&provider, request)) orelse return error.UnexpectedNull;
        defer output.deinit();
        // Scratch owners have already been released by the helper at this point.
        if (iteration == 1) {
            try std.testing.expectEqual(@as(c_int, 0), termite_metal_decode_runtime_cancel_frame(runtime));
        } else {
            try std.testing.expectEqual(@as(c_int, 0), termite_metal_decode_runtime_submit_frame(runtime));
            try std.testing.expectEqual(@as(c_int, 0), termite_metal_decode_runtime_wait_frame(runtime));
            const actual = try tensorHostSlice(&output);
            for (actual) |value| try std.testing.expectEqual(@as(f32, 0.73046875), value);
        }
        frame = false;
    }
}

'''
p.write_text(s.replace(needle,new+needle))
