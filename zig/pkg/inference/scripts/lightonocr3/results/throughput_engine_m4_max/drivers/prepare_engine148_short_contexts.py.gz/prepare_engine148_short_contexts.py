from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Existing isolated143 route is copied unchanged. This expands shapes only.
(v/'engine148_short_prefill_kernels.m').write_bytes((v/'engine143_short_prefill_kernels.m').read_bytes())
s=(v/'engine143_short_prefill_checks.m').read_text().replace('engine143_','engine148_')
a='"4f,\\\"gpu_us\\\":%.4f}\\n",\n                       heads, n, kv, trial, mode, elapsed / 1000.0, r->last_frame_gpu_nanos / 1000.0);'
b='"4f,\\\"gpu_us\\\":%.4f,\\\"page_size\\\":%zu}\\n",\n                       heads, n, kv, trial, mode, elapsed / 1000.0, r->last_frame_gpu_nanos / 1000.0, page);'
assert a in s;s=s.replace(a,b);(v/'engine148_short_prefill_checks.m').write_text(s)
s='''#define main unused_prefill148_main
#include "engine148_short_prefill_checks.m"
#undef main
int main(int argc,const char**argv){@autoreleasepool{
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_ATTENTION_MPP","1",1);
 bool benchmark=argc==2&&strcmp(argv[1],"--benchmark")==0;
 const size_t qs[]={31,32,33,42,63,64,65,96,127}, prefixes[]={256,1024}, pages[]={16,128};
 for(size_t h=8;h<=16;h+=8)for(size_t i=0;i<sizeof(qs)/sizeof(qs[0]);i++)for(size_t k=0;k<2;k++)for(size_t p=0;p<2;p++){
  int rc=check(r,qs[i],prefixes[k],h,pages[p],i%2,0,benchmark);if(rc){fprintf(stderr,"SHORT148 FAIL h=%zu q=%zu prefix=%zu page=%zu rc=%d\\n",h,qs[i],prefixes[k],pages[p],rc);return rc+10;}
 }
 fprintf(stderr,"SHORT148 CONTEXT PAGE OFFSET NUMERIC CHECKS PASS benchmark=%d\\n",benchmark);
 termite_metal_decode_runtime_destroy(r);return 0;
}}
''';(v/'engine148_short_prefill_probe.m').write_text(s)
ps=[v/f'engine148_short_prefill_{x}.m'for x in ['kernels','checks','probe']]+[Path(__file__)]
(v/'engine148_short_prefill_preparation.json').write_text(json.dumps(dict(status='prepared_not_built_or_run',scope='Same private direct-KV143 implementation, expanded cutoff/shortcontext/pagegeometry qualification. No canonical edits.',source_sha256={str(p):sha(p)for p in ps}),indent=2)+'\n');print('Prepared148 CPU source snapshots only; no build/GPU work')
