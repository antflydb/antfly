from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');freeze=json.loads((v/'engine25-freeze.json').read_text())
for f,h in freeze.items():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h,f
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text();old='        request.ctx.coordinator.notePrefillProgress(lease, 0, seq);\n';assert old in s;s=s.replace(old,'        // Collection stays waiting until the broker seals its group.\n',1)
anchor='''        for (items, 0..) |item, index| batch[index] = item.payloadAs(LightOnPrefillPayload).item;
        // Fairness can select any member'''
new='''        for (items, 0..) |item, index| batch[index] = item.payloadAs(LightOnPrefillPayload).item;
        control.check() catch |err| {
            for (items) |item| item.slot.fail(err);
            return;
        };
        // Publishing before broker collection finishes lets fairness select
        // an unavailable manual turn and parks ready decode work. Only a
        // sealed group may enter the coordinator's runnable prefill set.
        for (batch[0..items.len]) |item| {
            const lease = item.pipeline.scheduler_lease orelse {
                for (items) |value| value.slot.fail(error.InvalidBatchDecodeState);
                return;
            };
            ctx.coordinator.notePrefillProgress(lease, 0, item.seq_len);
        }
        // Fairness can select any member'''
assert anchor in s;s=s.replace(anchor,new);p.write_text(s)
p=Path('zig/pkg/inference/src/runtime/scheduler/native_generate.zig');s=p.read_text();anchor='    pub fn notePrefillProgress(self: *NativeGenerateCoordinator,';assert anchor in s;s=s.replace(anchor,'    /// Publish a runnable manual prefill turn. A broker still collecting its\n    /// group must leave its leases waiting until that group has been sealed.\n'+anchor,1)
s+='''

test "LightOnOCR3 collecting prefill groups leave ready decode runnable until sealing" {
    var coordinator = NativeGenerateCoordinator.init(std.testing.allocator);
    defer coordinator.deinit();
    const collecting = try coordinator.acquire(.{ .requested_units = 1, .prompt_bytes = 1, .prompt_tokens = 4, .max_tokens = 1 });
    defer coordinator.release(collecting);
    var sealed = try coordinator.acquire(.{ .requested_units = 1, .prompt_bytes = 1, .prompt_tokens = 4, .max_tokens = 1 });
    defer coordinator.release(sealed);
    var decode = try coordinator.acquire(.{ .requested_units = 1, .prompt_bytes = 1, .max_tokens = 4 });
    defer coordinator.release(decode);
    coordinator.beginDecode(&decode, 4);
    // Even the strictest prefill priority must ignore unsealed groups.
    coordinator.max_decode_streak_before_prefill = 0;
    var work: u8 = 0;
    var storage: [32]StepItem = undefined;
    var step = std.ArrayListUnmanaged(StepItem).empty;
    const budget = coordinator.defaultStepBudget();
    for (0..2) |index| {
        try coordinator.enqueueDecodeWork(decode, &work, 5 + index, 4 + index, 0, .{});
        var claimed = coordinator.claimNextStep(budget, &storage, &step).?;
        try std.testing.expectEqual(decode.request_id, claimed.request_id);
        coordinator.completeStep(&claimed, step.items);
    }
    try coordinator.enqueueDecodeWork(decode, &work, 7, 6, 0, .{});
    // The second group seals first. The older collecting lease must not
    // block it, while the ready group keeps the established fairness rule.
    coordinator.notePrefillProgress(&sealed, 0, 4);
    try std.testing.expect(coordinator.claimNextStep(budget, &storage, &step) == null);
    var waiting = collecting;
    try std.testing.expect(!coordinator.tryAcquireTurn(&waiting, .prefill));
    try std.testing.expect(coordinator.tryAcquireTurn(&sealed, .prefill));
    coordinator.finishTurn(&sealed, .prefill);
    coordinator.beginDecode(&sealed, 4);
    var resumed = coordinator.claimNextStep(budget, &storage, &step).?;
    try std.testing.expectEqual(decode.request_id, resumed.request_id);
    coordinator.completeStep(&resumed, step.items);
}
''';p.write_text(s)
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text();old='const bool reuse_packed = bf16 && !owned && rows >= 32u && rows <= 2048u &&';assert old in s;s=s.replace(old,'const bool reuse_packed = bf16 && !owned && rows >= 32u && rows <= 4096u &&');p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text();s=s.replace('size_t rows, size_t in, bool benchmark) {\n  const size_t out = 4096, steps = 6, count = rows * in, outputs = rows * out,','size_t rows, size_t in, size_t out, bool benchmark) {\n  const size_t steps = 6, count = rows * in, outputs = rows * out,')
s=s.replace('if ((mode == 1 || mode == 2) ? call_delta != steps : call_delta != 0)', 'if (((mode == 1 || mode == 2) && rows <= 4096) ? call_delta != steps : call_delta != 0)')
s=s.replace('if (mode == 1 ? hit_delta < steps - 1 : hit_delta != 0)', 'if ((mode == 1 && rows <= 4096) ? hit_delta < steps - 1 : hit_delta != 0)')
s=s.replace('prefill_pack_reuse_check(r,sizes[i],in,strstr', 'prefill_pack_reuse_check(r,sizes[i],in,4096,strstr')
anchor='''        if (argc == 2 && (strcmp(argv[1], "--check-batch-attention")'''
new='''        if (argc == 2 && (strcmp(argv[1], "--check-prefill-pack-reuse-large") == 0 || strcmp(argv[1], "--benchmark-prefill-pack-reuse-large") == 0)) {
            const bool benchmark = strstr(argv[1], "benchmark") != NULL;
            const size_t shapes[][3] = {{2648,2560,4096},{2648,9216,2560},{2047,1024,4096},{2048,1024,4096},{2049,1024,4096},{4096,1024,4096},{4097,1024,4096},{2049,2560,4096},{4096,2560,4096}};
            const size_t count = benchmark ? 2 : sizeof(shapes)/sizeof(shapes[0]);
            for (size_t i=0;i<count;i++) { @autoreleasepool {
                int rc = prefill_pack_reuse_check(r,shapes[i][0],shapes[i][1],shapes[i][2],benchmark);
                if(rc){fprintf(stderr,"PREFILL_PACK_REUSE_LARGE_FAIL rows=%zu in=%zu out=%zu rc=%d\\n",shapes[i][0],shapes[i][1],shapes[i][2],rc);return 132;}
            }}
            termite_metal_decode_runtime_destroy(r);return 0;
        }
'''+anchor
assert anchor in s;s=s.replace(anchor,new);p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text();old='not 0 <= args.prefill_wait_us <= 100000';assert old in s;s=s.replace(old,'not 0 <= args.prefill_wait_us <= 1000000').replace('vision/prefill collection waits must be 0..100000 microseconds','vision waits must be 0..100000 and prefill waits 0..1000000 microseconds');p.write_text(s)
print('engine26 readiness and large-prefill packing source prepared')
