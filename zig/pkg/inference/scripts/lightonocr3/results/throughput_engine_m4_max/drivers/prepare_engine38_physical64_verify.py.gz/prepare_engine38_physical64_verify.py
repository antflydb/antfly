from pathlib import Path
import hashlib
import json

root = Path.cwd()
for name, digest in json.loads((root / ".venv-lighton-vllm-metal/engine37-freeze.json").read_text()).items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
edits = {}


def replace(name, old, new, count=1):
    source = edits.get(name, (root / name).read_text())
    assert source.count(old) == count, (name, old[:100], source.count(old))
    edits[name] = source.replace(old, new)


server = "zig/pkg/inference/src/server/server.zig"
replace(server, "            prepared_rows: u8 = 16,\n",
        "            prepared_rows: u8 = 16,\n            scheduling_rows: u8 = 0,\n")
replace(server, '                const prefill_batch = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_PREFILL_BATCH");\n',
        '                const prefill_batch = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_PREFILL_BATCH");\n                const physical_rows = effectiveLightOnReadRows();\n')
replace(server, "                    .prepared_rows = if (effectiveLightOnReadRows() > 16) 32 else 16,\n",
        "                    .prepared_rows = if (physical_rows > 32) 64 else if (physical_rows > 16) 32 else 16,\n                    .scheduling_rows = @intCast(physical_rows),\n")
replace(server, "(if (features.prepared_rows > 16) @as(usize, 12) else 8)",
        "(if (features.prepared_rows > 32) @as(usize, 24) else if (features.prepared_rows > 16) @as(usize, 12) else 8)", 2)
replace(server, "            var storage: [32]runtime.scheduler.native_generate.StepItem = undefined;\n",
        "            var storage: [64]runtime.scheduler.native_generate.StepItem = undefined;\n")
replace(server, "self.decoder_rows > 32", "self.decoder_rows > 64")
replace(server, ".decoder_rows = 33", ".decoder_rows = 65")
replace(server, '    return if (metal_runtime.qualifiedM4DeviceDefault() and platform.env.getenvBool("ANTFLY_LIGHTONOCR3_PHYSICAL32")) 32 else 16;\n',
        '''    if (metal_runtime.qualifiedM4DeviceDefault()) {
        if (platform.env.getenvBool("ANTFLY_LIGHTONOCR3_PHYSICAL64")) return 64;
        if (platform.env.getenvBool("ANTFLY_LIGHTONOCR3_PHYSICAL32")) return 32;
    }
    return 16;
''')
replace(server, "(if (ceiling == 32) @as(usize, 32)", "(if (ceiling >= 32) ceiling")
replace(server, 'else if (lightOnPhysicalRowCeiling() == 32 and platform.env.getenvBool("ANTFLY_LIGHTONOCR3_LOGICAL64")) reader_execution_pool.Pool.max_capacity',
        'else if (lightOnPhysicalRowCeiling() == 64 or (lightOnPhysicalRowCeiling() == 32 and platform.env.getenvBool("ANTFLY_LIGHTONOCR3_LOGICAL64"))) reader_execution_pool.Pool.max_capacity')
old_names = 'const names = [_][:0]const u8{ "ANTFLY_LIGHTONOCR3_WIDE_DECODE", "ANTFLY_LIGHTONOCR3_PHYSICAL32", "ANTFLY_LIGHTONOCR3_LOGICAL64", "ANTFLY_LIGHTONOCR3_BATCH_ROWS", "ANTFLY_LIGHTONOCR3_BATCH_WINDOW" };'
replace(server, old_names, old_names.replace(' };', ', "ANTFLY_LIGHTONOCR3_PHYSICAL64" };'))
source = edits[server]
at = source.index(old_names.split(" };")[0])
start = source.rfind('\ntest "', 0, at)
end = source.index('\ntest "', at)
block = source[start:end]
marker = '    for (names[0..3]) |name|'
assert block.count(marker) == 1
block = block.replace(marker, '    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[5], "0", 1));\n' + marker)
tail = block.rfind("\n}")
block = block[:tail] + '''
    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[5], "1", 1));
    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[2], "0", 1));
    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[3], "64", 1));
    const physical64_rows: usize = if (eligible) 64 else 16;
    try std.testing.expectEqual(physical64_rows, effectiveLightOnReadRows());
    try std.testing.expectEqual(@as(usize, if (eligible) 64 else 32), effectiveLightOnReadWindow());
    try std.testing.expectEqual(physical64_rows, node.lightOnOcrPolicy(64).max_step_items);
    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[3], "48", 1));
    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[4], "56", 1));
    const partial = Node.LightOnStreamContext.ExecutionFeatures.fromEnvironmentForModel(.{});
    try std.testing.expectEqual(@as(u8, if (eligible) 64 else 16), partial.prepared_rows);
    try std.testing.expectEqual(@as(u8, if (eligible) 48 else 16), partial.scheduling_rows);
    try std.testing.expectEqual(@as(usize, if (eligible) 56 else 32), effectiveLightOnReadWindow());
''' + block[tail:]
edits[server] = source[:start] + block + source[end:]
replace(server, '        "ANTFLY_LIGHTONOCR3_PREFILL_BATCH",\n    };\n',
        '        "ANTFLY_LIGHTONOCR3_PREFILL_BATCH", "ANTFLY_LIGHTONOCR3_PHYSICAL64",\n    };\n')

gpt = "zig/pkg/inference/src/architectures/gpt.zig"
replace(gpt, "return decode and owns_frame and batch >= 2 and batch <= 32",
        "return decode and owns_frame and batch >= 2 and batch <= 64")
replace(gpt, "query_seq_len == 1 and batch >= 1 and batch <= 32",
        "query_seq_len == 1 and batch >= 1 and batch <= 64")
replace(gpt, "var states: [32]*metal_compute_mod.Qwen35LinearState",
        "var states: [64]*metal_compute_mod.Qwen35LinearState")
replace(gpt, "        try std.testing.expect(!lightOnForwardSplitEligible(config, 33, true, true, 4));",
        "        try std.testing.expect(lightOnForwardSplitEligible(config, 33, true, true, 4));\n        try std.testing.expect(lightOnForwardSplitEligible(config, 64, true, true, 4));\n        try std.testing.expect(!lightOnForwardSplitEligible(config, 65, true, true, 4));")

generation = "zig/pkg/inference/src/pipelines/generation.zig"
replace(generation, "claimed.len <= 32", "claimed.len <= 64", 2)
replace(generation, "var item_slots: [32]MixedBatchDecodeItem", "var item_slots: [64]MixedBatchDecodeItem")
replace(generation, "var input_slots: [32]i64", "var input_slots: [64]i64")
replace(generation, "var reservation_slots: [32]usize", "var reservation_slots: [64]usize")
replace(generation, "const metadata_bytes = 32 * (@sizeOf(gpt_arch.DecodeContext.KvBatchView)",
        "const metadata_bytes = 64 * (@sizeOf(gpt_arch.DecodeContext.KvBatchView)")

mc = "zig/pkg/inference/src/ops/metal_compute.zig"
replace(mc, "rows < 2 or rows > 32 or !lightOnPreparedConfigEligible(config)",
        "rows < 2 or rows > 64 or !lightOnPreparedConfigEligible(config)")
replace(mc, "if (rows != 16 and rows != 32) return error.InvalidBatchDecodeState;",
        "if (rows != 16 and rows != 32 and rows != 64) return error.InvalidBatchDecodeState;")
replace(mc, "states.len == 0 or states.len > 32 or layer >= 32",
        "states.len == 0 or states.len > 64 or layer >= 32")
replace(mc, "var state_handles: [32 * 7]?*anyopaque", "var state_handles: [64 * 7]?*anyopaque")
replace(mc, "var state_offsets: [32 * 7]usize", "var state_offsets: [64 * 7]usize")
replace(mc, "self.lighton_batch_attention and batch >= 2 and batch <= 32",
        "self.lighton_batch_attention and batch >= 2 and batch <= 64")

c = "zig/pkg/inference/src/backends/metal_kernels.m"
replace(c, "    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_PLANNED_MPP,\n",
        "    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_PLANNED_MPP,\n    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_64_ROW_TILE,\n")
replace(c, '    "TERMITE_METAL_DISABLE_LIGHTONOCR3_PLANNED_MPP",\n',
        '    "TERMITE_METAL_DISABLE_LIGHTONOCR3_PLANNED_MPP",\n    "TERMITE_METAL_DISABLE_LIGHTONOCR3_64_ROW_TILE",\n')
replace(c, "const bool wide_rows = rows >= 17 && rows <= 32 &&",
        "const bool wide_rows = rows >= 17 && rows <= 64 &&")
replace(c, "    // A wider decode uses the existing 32-row matrix tiles. Precision remains\n    // controlled by the explicit flags; sixteen-row specializations stay intact.\n",
        "    // Decoder cohorts retain their explicit precision policy. Wider\n    // cohorts share weight reads while histories remain in sixteen-row chunks.\n")
replace(c, "    const bool n32 = in_dim == 4096 && out_dim == 4096;\n",
        '''    const bool n32 = (in_dim == 4096 && out_dim == 4096) ||
        (rows > 32 && (wide_decode || wide_head) &&
         !termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_64_ROW_TILE));
''')
replace(c, "input_handle == NULL || buffers == NULL || offsets == NULL || rows == 0 || rows > 32 ||",
        "input_handle == NULL || buffers == NULL || offsets == NULL || rows == 0 || rows > 64 ||")
source = edits[c]
start = source.index("static int termite_metal_try_lightonocr3_prefill_gate(")
end = source.index("// Return zero to decline", start)
block = source[start:end]
old = '''    termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
    id<MTLComputeCommandEncoder> enc =
        termite_metal_tracked_compute_command_encoder_for(cb, TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);
    if (enc == nil)
        return -11;
'''
assert block.count(old) == 1
block = block.replace(old, '''    const bool coalesced = r->active_planned_compute_encoder != nil &&
        !termite_metal_frame_env_enabled(r, TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_PLANNED_MPP);
    BOOL encoder_owned = YES;
    id<MTLComputeCommandEncoder> enc;
    if (coalesced) {
        termite_metal_planned_encoder_range accesses[4];
        if (termite_metal_planned_range_make(input, input_offset, rows * in * 4,
                TERMITE_METAL_PLANNED_RANGE_READ, &accesses[0], -11) ||
            termite_metal_planned_range_make(weight, 0, in * out * 2,
                TERMITE_METAL_PLANNED_RANGE_READ, &accesses[1], -11) ||
            termite_metal_planned_range_make(bias, 0, out * 4,
                TERMITE_METAL_PLANNED_RANGE_READ, &accesses[2], -11) ||
            termite_metal_planned_range_make(output, output_offset, rows * out * 4,
                TERMITE_METAL_PLANNED_RANGE_WRITE, &accesses[3], -11)) return -11;
        enc = termite_metal_scoped_compute_encoder_for(r, cb, TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR,
            &encoder_owned);
        if (enc == nil) return -11;
        if (termite_metal_decode_runtime_prepare_planned_compute_accesses(r, accesses, 4, -11)) {
            termite_metal_end_scoped_compute_encoder(enc, encoder_owned);
            return -11;
        }
    } else {
        termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
        enc = termite_metal_tracked_compute_command_encoder_for(cb, TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);
        if (enc == nil) return -11;
    }
''')
assert block.count("    [enc endEncoding];\n") == 1
block = block.replace("    [enc endEncoding];\n",
                      "    if (!encoder_owned) [enc setThreadgroupMemoryLength:0 atIndex:0];\n    termite_metal_end_scoped_compute_encoder(enc, encoder_owned);\n")
block = block.replace('"lightonocr3_prefill_gate_tg", !owned, false, false,',
                      '"lightonocr3_prefill_gate_tg", !owned, !encoder_owned, false,')
edits[c] = source[:start] + block + source[end:]

bench = "zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py"
replace(bench, '    env["ANTFLY_LIGHTONOCR3_PHYSICAL32"] = "1" if args.physical32 else "0"\n',
        '    env["ANTFLY_LIGHTONOCR3_PHYSICAL32"] = "1" if args.physical32 else "0"\n    env["ANTFLY_LIGHTONOCR3_PHYSICAL64"] = "1" if args.physical64 else "0"\n')
replace(bench, "    if args.physical32:\n", "    if args.physical32 or args.physical64:\n")
replace(bench, "    if args.disable_planned_mpp:\n",
        '    if args.disable_64_row_tile:\n        env["TERMITE_METAL_DISABLE_LIGHTONOCR3_64_ROW_TILE"] = "1"\n    if args.disable_planned_mpp:\n')
replace(bench, '    parser.add_argument("--physical32", action="store_true")\n',
        '    parser.add_argument("--physical32", action="store_true")\n    parser.add_argument("--physical64", action="store_true")\n')
replace(bench, '    parser.add_argument("--disable-planned-mpp", action="store_true")\n',
        '    parser.add_argument("--disable-planned-mpp", action="store_true")\n    parser.add_argument("--disable-64-row-tile", action="store_true")\n')
old = '''    if not 1 <= args.pages_per_request <= 64 or not 1 <= args.batch_rows <= 32:
        parser.error("pages per request must be 1..64; batch rows must be 1..32")
    if args.batch_rows > 16 and not args.physical32:
        parser.error("more than sixteen physical rows requires --physical32")
    if args.physical32 and not args.continuous:
        parser.error("--physical32 requires --continuous")
'''
new = '''    if args.physical32 and args.physical64:
        parser.error("choose only one physical row ceiling")
    if not 1 <= args.pages_per_request <= 64 or not 1 <= args.batch_rows <= 64:
        parser.error("pages per request and batch rows must be 1..64")
    if args.batch_rows > 32 and not args.physical64:
        parser.error("more than thirty-two physical rows requires --physical64")
    if args.batch_rows > 16 and not (args.physical32 or args.physical64):
        parser.error("more than sixteen physical rows requires --physical32 or --physical64")
    if (args.physical32 or args.physical64) and not args.continuous:
        parser.error("physical row overrides require --continuous")
'''
replace(bench, old, new)
replace(bench, '''    if args.logical64 and not args.physical32:
        parser.error("--logical64 requires --physical32")
    if not 1 <= args.batch_window <= (64 if args.logical64 else 32):
        parser.error("batch window must be 1..32, or 1..64 with --logical64")
''', '''    if args.logical64 and not (args.physical32 or args.physical64):
        parser.error("--logical64 requires --physical32 or --physical64")
    if not 1 <= args.batch_window <= (64 if args.logical64 or args.physical64 else 32):
        parser.error("batch window must be 1..32, or 1..64 with --logical64 or --physical64")
''')

for name, source in edits.items():
    (root / name).write_text(source)
    print(name)
