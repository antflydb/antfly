from pathlib import Path
import hashlib,json,subprocess,statistics
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((o/'engine50_recurrent_probe_build_verify3_manifest.json').read_text())
assert m['exit_code']==0 and sha(m['binary'])==m['binary_sha256']
for p,h in m['inputs'].items():assert sha(p)==h,p
raw=Path('/private/tmp/ocr-engine50-recurrent-probe-gpu-verify3.jsonl');err=Path('/private/tmp/ocr-engine50-recurrent-probe-gpu-verify3-stderr.txt')
assert not raw.exists()and not err.exists()
with raw.open('w')as a,err.open('w')as b:r=subprocess.run([m['binary']],stdout=a,stderr=b)
Path('/private/tmp/ocr-engine50-recurrent-probe-verify3-complete.json').write_text(json.dumps(dict(exit_code=r.returncode))+'\n')
assert r.returncode==0,r.returncode
old=Path('/private/tmp/ocr-engine50-recurrent-probe-gpu-verify2.jsonl')
oldrows=[json.loads(x)for x in old.read_text().splitlines()];newrows=[json.loads(x)for x in raw.read_text().splitlines()]
assert len(oldrows)==24 and len(newrows)==12
rows=oldrows+newrows;assert len({(x['pages'],x['candidate'],x['leg'])for x in rows})==36
record=dict(status='pass',scope='Private recurrent lane-mapping experiment, all three candidates regress. Same F32 cache/layout/precision. Full 24-layer state/output checks and ABBA working sets at 64/48/33 pages. Initial failed build and singleton fixture failure remain preserved; only missing 33-page cases rerun after using existing direct singleton API. No runtime promotion.',raw_stdout_sha256={str(p):sha(p)for p in [old,raw]},raw_stderr_sha256={str(p):sha(p)for p in [Path('/private/tmp/ocr-engine50-recurrent-probe-gpu-verify2-stderr.txt'),err]},build_manifests={str(p):sha(p)for p in [o/'engine50_recurrent_probe_build_verify2_manifest.json',o/'engine50_recurrent_probe_build_verify3_manifest.json']},cases=[])
for p in [Path('/private/tmp/ocr-engine50-recurrent-probe-gpu-verify2-stderr.txt'),err]:
 s=p.read_text()
 for mode in [1,2,3]:assert f'CONFORMANCE PASS mode={mode}'in s
for pages in [64,48,33]:
 for candidate in [1,2,3]:
  group=[x for x in rows if x['pages']==pages and x['candidate']==candidate]
  assert [x['mode']for x in group]==[0,candidate,candidate,0]
  assert all(x['checked_elements']>0 and x['full_output_state_max_abs']<=2e-4 and len(x['gpu_us'])==8 for x in group)
  a=[t for x in group if x['mode']==0 for t in x['gpu_us']]
  b=[t for x in group if x['mode']==candidate for t in x['gpu_us']]
  record['cases'].append(dict(pages=pages,candidate=candidate,baseline_median_gpu_us=statistics.median(a),candidate_median_gpu_us=statistics.median(b),candidate_to_baseline=statistics.median(b)/statistics.median(a),legs=group))
(o/'engine50_recurrent_probe_verified_audit.json').write_text(json.dumps(record,indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('qualification',[raw,err,Path('/private/tmp/ocr-engine50-recurrent-probe-build-verify3.txt'),Path('/private/tmp/ocr-engine50-recurrent-build-verify3-driver.txt')],'logs_manifest.json')
print(json.dumps([(x['pages'],x['candidate'],x['candidate_to_baseline'])for x in record['cases']]),flush=True)
