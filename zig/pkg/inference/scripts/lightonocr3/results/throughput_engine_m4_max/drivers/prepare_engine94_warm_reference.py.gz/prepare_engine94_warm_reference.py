from pathlib import Path
import hashlib
v=Path('.venv-lighton-vllm-metal');p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_vllm_metal.py');s=p.read_text();s=s.replace('    parser.add_argument("--requests", type=int, default=16)','    parser.add_argument("--requests", type=int, default=16)\n    parser.add_argument("--warmup-requests", type=int, default=128)\n    parser.add_argument("--minimum-auto-cache-blocks", type=int, default=0)',1)
s=s.replace('    args.output_dir.mkdir(parents=True, exist_ok=True)','    if args.warmup_requests < 1 or args.minimum_auto_cache_blocks < 0:\n        parser.error("warmup-requests must be positive and cache floor nonnegative")\n    args.output_dir.mkdir(parents=True, exist_ok=True)',1)
needle='''            references = [request(i) for i in range(len(payloads))]''';assert s.count(needle)==1
s=s.replace(needle,'''            import re
            blocks = [int(value) for value in re.findall(r"Hybrid shared cache:\\s*(\\d+)\\s*blocks", (args.output_dir / "server.txt").read_text())]
            report["automatic_cache_floor_admission"] = {"requested_floor": args.minimum_auto_cache_blocks, "observed_blocks": blocks, "admitted": bool(blocks) and min(blocks) >= args.minimum_auto_cache_blocks}
            report["excluded_saturation_warmup_requests"] = args.warmup_requests
            report["upstream_script_sha256"] = "'''+hashlib.sha256(p.read_bytes()).hexdigest()+'''"
            save()
            if not report["automatic_cache_floor_admission"]["admitted"]:
                raise RuntimeError("Automatic cache floor not met before warmup or timing")
'''+needle,1)
needle='''            for concurrency in args.concurrency:
                start = time.perf_counter()''';assert s.count(needle)==1
s=s.replace(needle,'''            report["saturation_warmups"] = []
            for concurrency in args.concurrency:
                with ThreadPoolExecutor(max_workers=concurrency) as executor:
                    warm_outputs = list(executor.map(request, range(args.warmup_requests)))
                if not all(output["text"] == references[output["image_index"]]["text"] for output in warm_outputs):
                    raise RuntimeError("Saturation warmup changed full OCR output")
                report["saturation_warmups"].append({"concurrency": concurrency, "excluded_from_throughput": True, "outputs": warm_outputs})
                save()
                start = time.perf_counter()''',1)
q=v/'engine94_benchmark_vllm_warm.py';assert not q.exists();q.write_text(s);print(q)
