from pathlib import Path
import ast,datetime,hashlib,json,os,statistics,subprocess,sys,time
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while True:
 p=Path('/private/tmp/ocr-engine74-qualification-verify2-parent.txt');s=p.read_text()if p.exists()else''
 if 'Traceback'in s:raise RuntimeError(s[-3000:])
 if 'ENGINE74 QUALIFICATION DONE'in s:break
 time.sleep(5)
for p,h in json.loads((v/'engine74-freeze.json').read_text()).items():assert sha(root/p)==h,p
precision=json.loads((out/'engine71_precision_screen62_audit.json').read_text());assert precision['status']=='pass'
rates={mode:statistics.mean(x['pages_per_second']for x in precision['cases']if x['bf16_decode_inputs']==mode)for mode in [False,True]}
bf16=rates[True]>rates[False]
primary=json.loads((out/'paired59_4b_comparison_audit.json').read_text());profiles=primary['profiles'];oracle=Path(primary['comparisons'][-1]['reference_report']).parent.name.removeprefix('vllm_4b')
audit=out/'engine74_burst_screen64_audit.json';assert not audit.exists()
record=dict(status='running',scope='Isolate four/eight-step greedy publication bursts in ABBA order on the same qualified source74 binary. Original caps, R128 and full serial/cross-runtime string checks. Precision selected independently from completed source71 precision62 ABBA. This is a policy screen, not evidence of a vLLM win.',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),precision_audit_sha256=sha(out/'engine71_precision_screen62_audit.json'),bf16_decode_inputs=bf16,precision_mean_rates={str(k):val for k,val in rates.items()},cases=[])
def save():audit.write_text(json.dumps(record,indent=2)+'\n')
save();source=(v/'run_engine71_api_paired59.py').read_text();node=next(x for x in ast.parse(source).body if isinstance(x,ast.FunctionDef)and x.name=='native');base=ast.get_source_segment(source,node)
for leg,width in enumerate([4,8,8,4]):
 fn=base.replace('paired59',f'burst_screen64_w{width}').replace('engine71','engine74').replace("OCR_BF16='0'",f"OCR_BF16='{int(bf16)}'").replace("['OCR_GPU_TOKEN_BURST_WIDTH']='4'",f"['OCR_GPU_TOKEN_BURST_WIDTH']='{width}'").replace("s['gpu_token_burst_max_width']==4",f"s['gpu_token_burst_max_width']=={width}")
 exec(compile(fn,'extracted_native_burst64_'+str(leg),'exec'),globals())
 print('START BURST SCREEN',leg,width,bf16,flush=True)
 try:
  d,p=native('wide',leg,oracle);s=d['results'][0]['policy_rounds'][0]
  record['cases'].append(dict(leg=leg,width=width,status='pass',pages_per_second=s['pages_per_second'],report=str(p.relative_to(out)),report_sha256=sha(p)))
 except Exception as e:
  record['status']='failed';record['failure']=repr(e);save();raise
 save();print('DONE BURST SCREEN',record['cases'][-1],flush=True)
means={width:statistics.mean(x['pages_per_second']for x in record['cases']if x['width']==width)for width in [4,8]}
record.update(status='pass',mean_rates=means,selected_width=max(means,key=means.get));save();print('ENGINE74 BURST64 DONE',record['selected_width'],flush=True)
