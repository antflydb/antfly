from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';p=root/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_engine_m4_max'
mode=sys.argv[1];b,c,enabled=map(int,sys.argv[2:5]);assert mode in ['qualification','primary'] and b in [8,10,12,14,16,32,64] and 1<=c<=64 and c>=b and enabled in [0,1]
n=max(32,b) if mode=='qualification' else 128
manifest=out/'engine64_build_manifest.json';binary=json.loads(manifest.read_text())['binary_path']
oracle=out/'mlx_florence_engine37_paired19_r1_reference/report.json'
old=json.loads((out/'engine37_florence_encoder_qualification_enabled0/report.json').read_text())
old_texts={x['image_index']:x['text']for x in old['results'][0]['references']}
proxy_texts={i:x['text']for i,x in enumerate(json.loads(oracle.read_text())['references'])}
label=f'florence_profile37_batch{b}_c{c}_cpu{enabled}_r{n}_{mode}';dest=out/f'engine64_{label}';assert not(dest/'report.json').exists()
env=os.environ.copy();env['PYTHONPATH']=str(p)
cmd=[sys.executable,str(v/'engine64_benchmark_concurrency.py'),'--native-test',binary,
 '--model','florence=/Users/ajroetker/.antfly/inference/models/antflydb/florence-2-base',
 '--images',str(root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(p/'corpus/receipt.png'),str(p/'corpus/shipping.png'),
 '--requests',str(n),'--concurrency',str(c),'--max-tokens','256','--modes','batch','--native-read-batch-size',str(b),
 '--batch-wait-us','5000','--florence-batch-wait-us','20000' if b>8 else '5000',
 '--memory-gib','24','--shared-memory-gib','28','--backend-memory-gib','16','--kv-memory-gib','4','--scratch-memory-gib','8','--admission-units','512',
 '--timeout','900','--reference-report',str(oracle),'--build-manifest',str(manifest),'--output-dir',str(dest),
 '--require-florence-no-repeat-argmax','--require-florence-single-frame','--policy-rounds','current']
if enabled:cmd+=['--florence-cpu-preprocess']
print('START',label,flush=True)
with Path('/private/tmp/ocr-engine64-'+label+'-driver.txt').open('w')as log:
 r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
print('DONE',label,r.returncode,flush=True);assert r.returncode==0,(label,r.returncode)
rp=dest/'report.json';d=json.loads(rp.read_text());r=d['results'][0];sample=r['policy_rounds'][0]
assert r['status']=='ok' and r['serial_reference_parity'] and r['cross_runtime_content_parity'] and sample['completed']==n
assert sample['native_items']==n,sample
texts={x['image_index']:x['text']for x in r['references']};assert texts==old_texts
assert {k:''.join(t.split())for k,t in texts.items()}=={k:''.join(t.split())for k,t in proxy_texts.items()}
f=r['florence_single_frame'];assert f['steps']>0 and f['api_fallbacks']==f['topology_mismatches']==0
raw=(dest/r['log']).read_text();assert 'admission_pressure='not in raw
timed=raw.split('OCR_POLICY round=0',1)[1];sizes=list(map(int,re.findall(r'FLORENCE2 batch_items=(\d+)',timed)))
assert sizes and max(sizes)==b and all(2<=s<=b for s in sizes) and sum(sizes)<=n,(b,n,sizes)
d['cpu_preprocess_overlap']=bool(enabled);d['actual_florence_profile37_batch_items']=sizes;d['driver_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
rp.write_text(json.dumps(d,indent=2)+'\n')
record=dict(status='pass',cpu_preprocess_overlap=bool(enabled),concurrency=c,model_batch_size=b,completed=n,
 actual_florence_profile37_batch_items=sizes,actual_batch_items_traced=sum(sizes),native_items=sample['native_items'],
 pages_per_second=sample['pages_per_second'],process_cpu_ms=sample['process_cpu_ms'],native_full_fixture_string_identity=True,
 all_native_pages_equal_native_serial=True,cross_runtime_full_fixture_string_identity=texts==proxy_texts,
 cross_runtime_whitespace_normalized_content=True,single_frame=f,primary_throughput_eligible=mode=='primary',
 own_cpu_compile_or_sampling_overlap=False,report=str(rp.relative_to(out)),report_sha256=hashlib.sha256(rp.read_bytes()).hexdigest(),
 scope='Configured native Florence batch, actual size verified. Q4_K plus F16 encoder/no-repeat policy; available MLX serial proxy differs in precision/policy; no actual vLLM Florence adapter.')
(out/f'engine64_{label}_audit.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
