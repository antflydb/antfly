from pathlib import Path
import hashlib,json,subprocess,sys,time,psutil
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while 'ENGINE75 LAYOUT RETRY DONE' not in Path('/private/tmp/ocr-engine75-layout-retry-parent.txt').read_text():time.sleep(5)
# The binary is intentionally the historical integrated source71 build. Bind
# every source byte to its immutable commit rather than claiming source74.
m=json.loads((o/'engine73d_build_manifest.json').read_text());assert sha(m['binary_path'])==m['binary_sha256']
for p,h in m['runtime_files_sha256'].items():assert hashlib.sha256(subprocess.check_output(['git','show',m['runtime_commit']+':'+p])).hexdigest()==h,p
assert m['runtime_source_diff_sha256']==hashlib.sha256(b'').hexdigest()
while psutil.virtual_memory().available < 11348275670+6*1024**3+512*1024**2:time.sleep(5)
print('START HISTORICAL SOURCE71 SYMBOL CPU RETRY',flush=True)
with Path('/private/tmp/ocr-engine73d-cpu-retry65-parent.txt').open('w')as log:subprocess.run([sys.executable,str(v/'run_engine73d_cpu_diagnostic65.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
a=o/'engine73d_cpu_diagnostic65_audit.json';d=json.loads(a.read_text());assert d['status'] in ['pass','sampling_unavailable']
d.update(historical_source_build_manifest_sha256=sha(o/'engine73d_build_manifest.json'),historical_runtime_commit=m['runtime_commit'],historical_source_bytes_verified_against_commit=True,primary_throughput_eligible=False,scope='Historical integrated source71, ReleaseFast with symbols; CPU diagnosis only after isolated probes. Every historical source byte verified against its immutable commit, binary hash verified. Current source74 is a separate candidate. This sampled R64 rate is never primary throughput evidence.');a.write_text(json.dumps(d,indent=2)+'\n');print('ENGINE73D CPU RETRY65 DONE',flush=True)
