from pathlib import Path
import re,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';s=(r/'zig/pkg/inference/src/backends/metal_kernels.m').read_text();a=s.index('           "template<uint B,uint SN,uint TM,bool GATE>');b=s.index('           "#undef T',a)
msl=''.join(json.loads(line.strip())for line in s[a:b].splitlines());msl=msl[:msl.index('#define T')]+msl[msl.index('#define V'):]
msl=msl.replace('a[b]=*((device const float4*)(x+b*p.in_dim+k))','a[b]=b<p.rows?*((device const float4*)(x+b*p.in_dim+k)):float4(0)').replace('if(lane%SN==0){g+=gb[col+t];','if(lane%SN==0 && b<p.rows){g+=gb[col+t];')
msl=msl[:msl.index('T(2,16,2)')]
msl='#include <metal_stdlib>\nusing namespace metal;\nstruct termite_lightonocr3_local_params{uint rows,in_dim,out_dim,pad;};\n'+msl+'\nV(16,16,1) V(16,16,2) V(16,16,4) V(16,32,1) V(16,32,2) V(16,32,4)\n';(v/'wide_register_probe.metal').write_text(msl)
