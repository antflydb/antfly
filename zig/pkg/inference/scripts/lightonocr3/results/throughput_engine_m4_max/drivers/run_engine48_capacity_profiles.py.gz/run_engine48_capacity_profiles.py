from pathlib import Path
import hashlib,json,os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
audit=out/'engine48_4b_capacity_profiles_audit.json';assert not audit.exists()
record=dict(status='running',scope='Capacity profiles within unchanged 17 GiB backend / 10 GiB scratch / 4 GiB KV / 28 GiB combined budget and 6 GiB live reserve. Pressure disqualifies performance. No vLLM speed claim from this sweep.',cases=[])
for c,vf in [(63,2),(60,4)]:
 n=128;label=f'capacity_c{c}_vf{vf}_p2_wide641_full641_r128'
 env=os.environ.copy()
 env.update(OCR_REFERENCE_LABEL='_primary_reference20_r0_auto_c64_r128',OCR_PHYSICAL32='0',OCR_PHYSICAL64='1',
 OCR_CONCURRENCY=str(c),OCR_REQUESTS=str(n),OCR_WIDE='1',OCR_SCRATCH_GIB='10',OCR_BACKEND_GIB='17',OCR_KV_GIB='4',
 OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1',
 OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_VISION_BATCH='0',OCR_VISION_BATCH_ITEMS='1',OCR_PREFILL_BATCH='1',
 OCR_PREFILL_BATCH_ITEMS='2',OCR_PREFILL_WAIT_US='1000000',OCR_VISION_FRAME_BLOCKS=str(vf),
 OCR_SINGLE_FRAME='1',OCR_STREAM_FIRST='0',OCR_GPU_GREEDY_STREAM='0',OCR_LOGICAL64='1',
 OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',
 OCR_ADMISSION_UNITS='512',OCR_DISABLE_64_ROW_TILE='0',OCR_DISABLE_WIDE_GATE_UP='0',
 OCR_WIDE64_GATE_UP='1',OCR_FULL64_GATE_UP='1',ANTFLY_FLORENCE_CPU_PREPROCESS='0')
 print('START',label,flush=True)
 dest=out/f'engine48_4b_{label}';assert not(dest/'report.json').exists()
 with Path(f'/private/tmp/ocr-engine48-4b-{label}-driver.txt').open('w')as log:
  r=subprocess.run([sys.executable,str(v/'run_engine48_budget_policies_verify.py'),'4b:'+label],env=env,stdout=log,stderr=subprocess.STDOUT)
 item=dict(concurrency=c,vision_frame_blocks=vf,exit_code=r.returncode,prefill_batch_items=2,primary_throughput_eligible=False)
 rp=dest/'report.json'
 if rp.exists():
  d=json.loads(rp.read_text());rs=d['results'][0]
  sample=(rs.get('policy_rounds')or[{}])[0]
  item.update(status=rs['status'],pages_per_second=sample.get('pages_per_second'),completed=sample.get('completed'),admission_pressures=sample.get('admission_pressures'),report=str(rp.relative_to(out)),report_sha256=hashlib.sha256(rp.read_bytes()).hexdigest())
  if rs['status']=='ok':
   assert rs['serial_reference_parity'] and rs['cross_runtime_content_parity'] and sample['completed']==n
   assert sample['host_recurrent_bytes_total']==0 and sample['single_frame_topology_mismatches']==0
   assert any(b['items']==2 for b in sample['prefill_batches'])
   item['primary_throughput_eligible']=not sample['admission_pressures']
 record['cases'].append(item);audit.write_text(json.dumps(record,indent=2)+'\n');print('DONE',item,flush=True)
record['status']='complete';audit.write_text(json.dumps(record,indent=2)+'\n')
