from pathlib import Path
import json,os,subprocess,sys,time
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';out=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';binary=json.loads((out/'engine17_build_manifest.json').read_text())['binary_path'];label='cpu_sample_c32_r32_0';target=out/('engine17_08_'+label)
env=os.environ.copy();env.update(OCR_CONCURRENCY='32',OCR_REQUESTS='32',OCR_WIDE='1',OCR_SCRATCH_GIB='8',OCR_STREAM_FIRST='0',OCR_SINGLE_FRAME='0',OCR_SHARED_CORE='0',OCR_BF16_PREFILL='0',OCR_POLICIES='engineepoch')
with open('/private/tmp/ocr-engine17-cpu-sample-driver.txt','w')as log:
 process=subprocess.Popen([sys.executable,str(v/'run_engine17_policies.py'),'08:'+label],env=env,stdout=log,stderr=subprocess.STDOUT)
 sampled=False;start=time.monotonic()
 while process.poll()is None:
  raw=target/'lighton08-batch-c32.txt'
  if not sampled and raw.exists()and 'OCR_POLICY round=0' in raw.read_text():
   entries={}
   for line in subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines():
    fields=line.strip().split(None,2)
    if len(fields)==3:entries[int(fields[0])]=(int(fields[1]),fields[2])
   candidates=[]
   for pid,(parent,command)in entries.items():
    if not command.startswith(binary+' '):continue
    ancestors=set();current=pid
    while current in entries and current not in ancestors:
     ancestors.add(current);current=entries[current][0]
    if process.pid in ancestors:candidates.append(pid)
   if len(candidates)==1:
    pid=candidates[0];print('sample own OCR descendant',pid,flush=True)
    subprocess.run(['sample',str(pid),'1','1','-file','/private/tmp/ocr-engine17-cpu-prefill-sample.txt'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT)
    time.sleep(5)
    if process.poll()is None:subprocess.run(['sample',str(pid),'1','1','-file','/private/tmp/ocr-engine17-cpu-decode-sample.txt'],check=False,stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT)
    sampled=True
  if time.monotonic()-start>180:raise RuntimeError('diagnostic exceeded expected time')
  time.sleep(.2)
 rc=process.wait();print('exit',rc,'sampled',sampled,flush=True)
 if(target/'report.json').exists():
  p=target/'report.json';j=json.loads(p.read_text());j.update(primary_throughput=False,instrumented_cpu_sample=True,own_cpu_compile_overlap=False);p.write_text(json.dumps(j,indent=2)+'\n')
 sys.exit(rc)
