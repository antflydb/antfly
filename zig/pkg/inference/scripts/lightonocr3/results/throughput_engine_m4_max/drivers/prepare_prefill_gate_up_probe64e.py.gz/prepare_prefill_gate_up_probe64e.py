from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=(v/'prefill_gate_up_probe64d.metal').read_text();a=s.index('kernel void candidate0(');s=s[:a]
s=s.replace('template<uint M,uint N,uint SG,uint K>','template<bool REUSE,uint M,uint N,uint SG,uint K>')
s=s.replace('matmul2d_descriptor(M,N,K,false,true,true)','matmul2d_descriptor(M,N,K,false,true,false,matmul2d_descriptor::mode::multiply_accumulate)')
a=' auto g=op.template get_destination_cooperative_tensor';assert s.count(a)==1;s=s.replace(a,' auto cached_left=op.template get_left_input_cooperative_tensor<bfloat,bfloat,float>();\n'+a)
a='  op.run(left,rightG,g);op.run(left,rightU,u);';assert s.count(a)==1;s=s.replace(a,'  if constexpr(REUSE){cached_left.load(left);op.run(cached_left,rightG,g);op.run(cached_left,rightU,u);}else{op.run(left,rightG,g);op.run(left,rightU,u);}')
for i,(reuse,m,n,k)in enumerate([(reuse,m,n,k)for reuse in [False,True]for m,n in [(32,64),(64,32)]for k in [64,128,256,512]]):
 s+=f'kernel void candidate{i}(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){{candidate_gate<{str(reuse).lower()},{m},{n},4,{k}>(x,g,u,gb,ub,y,p,group);}}\n'
(v/'prefill_gate_up_probe64e.metal').write_text(s)
s=(v/'prefill_gate_up_probe64d.m').read_text().replace('size_t m=variant<4?32:64,n=variant<4?64:32;','size_t tile=variant%8,m=tile<4?32:64,n=tile<4?64:32;').replace('variant<8','variant<16').replace('psos[8];for(size_t i=0;i<8;i++)','psos[16];for(size_t i=0;i<16;i++)');(v/'prefill_gate_up_probe64e.m').write_text(s)
s=(v/'run_prefill_gate_up_probe64b.py').read_text().replace('probe64b','probe64e').replace('gup64b','gup64e').replace('probe64a.metal','probe64e.metal');(v/'run_prefill_gate_up_probe64e.py').write_text(s)
