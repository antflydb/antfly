#include <metal_stdlib>
using namespace metal;
struct termite_metal_argmax_suppress_params { uint out_dim; uint suppress_count; uint reserved0; uint reserved1; };
inline bool termite_argmax_suppressed_token(uint token_id, device const int *suppress_ids, uint suppress_count) {
    for (uint i = 0u; i < suppress_count; ++i) {
        int raw = suppress_ids[i];
        if (raw >= 0 && uint(raw) == token_id) return true;
    }
    return false;
}
kernel void engine54_partials(device const float *logits [[buffer(0)]], device const int *suppress_ids [[buffer(1)]], device float *partial_values [[buffer(2)]], device uint *partial_ids [[buffer(3)]], constant termite_metal_argmax_suppress_params &p [[buffer(4)]], threadgroup float *sh_vals [[threadgroup(0)]], threadgroup uint *sh_ids [[threadgroup(1)]], ushort tid [[thread_index_in_threadgroup]], ushort3 tg_shape [[threads_per_threadgroup]], uint3 group [[threadgroup_position_in_grid]]) {
    const ushort tg_size = tg_shape.x;
    const uint block = group.x;
    logits += size_t(group.y) * p.out_dim;
    partial_values += size_t(group.y) * ((p.out_dim + 1023u) / 1024u);
    partial_ids += size_t(group.y) * ((p.out_dim + 1023u) / 1024u);
    const uint block_size = 1024u;
    uint start = block * block_size;
    uint end = min(start + block_size, p.out_dim);
    float best = -INFINITY;
    uint best_idx = 0xffffffffu;
    for (uint i = start + uint(tid); i < end; i += uint(tg_size)) {
        if (termite_argmax_suppressed_token(i, suppress_ids, p.suppress_count)) continue;
        float value = logits[i];
        if (value > best || (value == best && i < best_idx)) { best = value; best_idx = i; }
    }
    if (best_idx == 0xffffffffu) best_idx = 0u;
    sh_vals[tid] = best;
    sh_ids[tid] = best_idx;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    for (uint stride = uint(tg_size) >> 1u; stride > 0u; stride >>= 1u) {
        if (uint(tid) < stride) {
            float other = sh_vals[uint(tid) + stride];
            uint other_idx = sh_ids[uint(tid) + stride];
            if (other > sh_vals[tid] || (other == sh_vals[tid] && other_idx < sh_ids[tid])) { sh_vals[tid] = other; sh_ids[tid] = other_idx; }
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }
    if (tid == 0u) { partial_values[block] = sh_vals[0]; partial_ids[block] = sh_ids[0]; }
}
kernel void engine54_reduce(device const float *partial_values [[buffer(0)]], device const uint *partial_ids [[buffer(1)]], device uint *output [[buffer(2)]], constant uint &partial_count [[buffer(3)]], uint gid [[thread_position_in_grid]]) {
    output += gid;
    partial_values += size_t(gid) * partial_count;
    partial_ids += size_t(gid) * partial_count;
    if (partial_count == 0u) { output[0] = 0u; return; }
    float best = partial_values[0];
    uint best_idx = partial_ids[0];
    for (uint i = 1u; i < partial_count; ++i) {
        float value = partial_values[i];
        uint idx = partial_ids[i];
        if (value > best || (value == best && idx < best_idx)) { best = value; best_idx = idx; }
    }
    output[0] = best_idx;
}
