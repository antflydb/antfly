from pathlib import Path
import subprocess,sys,json,hashlib,re,gzip
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';out=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,*args):
 print('START',name,flush=True)
 with open('/private/tmp/ocr-engine36-'+name+'-driver.txt','w')as stream:
  result=subprocess.run([sys.executable,str(v/('run_engine36_'+name+'.py')),*args],stdout=stream,stderr=subprocess.STDOUT)
 print('DONE',name,result.returncode,flush=True)
 assert result.returncode==0,(name,result.returncode)
run('functional')
run('logical64_units512_qualification')
run('shared_workspace_rollback')
report=out/'engine36_08_shared_decoder_rollback_c16_r32/report.json';d=json.loads(report.read_text());r=d['results'][0];s=r['policy_rounds'][0]
oracle=json.loads((out/'vllm_08_primary_reference11_r0_auto_c32_r128/report.json').read_text())
assert r['serial_reference_parity']and r['cross_runtime_content_parity']and s['completed']==32
assert{x['image_index']:x['text']for x in r['references']}=={x['image_index']:x['text']for x in oracle['references']}
assert not d['shared_decoder_scratch']and s['shared_decoder_peak_bytes']==0 and s['host_recurrent_bytes_total']==0
build=Path('/private/tmp/ocr-engine36-verify-gpu-build.txt').read_text()
assert '217 selected; 216 passed; 1 skipped.' in build,build[-2000:]
audit=dict(selected=217,passed=216,skipped=1,leaked=0,reader_checks=['preset16','physical32','feature_off'],c_qualification_reuse='engine36_c_qualification_reuse.json',logical64_checks='engine36_logical64_units512_qualification_audit.json',shared_decoder_working_set=True,backend_first_peak_release=True,host_recurrent_bytes_total=0,rollback=dict(report=str(report.relative_to(out)),report_sha256=sha(report),completed=32,full_fixture_string_identity=True,shared_decoder_scratch=False,shared_decoder_peak_bytes=0),rejected_builds=['qualification/ocr-engine36-invalid-credit-test-build.txt.gz','qualification/ocr-engine36-live-credit-assertion-build.txt.gz'],build_manifest_sha256=sha(out/'engine36_build_manifest.json'),freeze_sha256=sha(v/'engine36-freeze.json'))
(out/'engine36_qualification_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
source=(v/'archive_engine10_evidence.py').read_text();exec(source[:source.index("archive('qualification'")])
archive('qualification',list(Path('/private/tmp').glob('ocr-engine36*qualification*.txt'))+list(Path('/private/tmp').glob('ocr-engine36*functional*.txt'))+list(Path('/private/tmp').glob('ocr-engine36*rollback*.txt'))+[Path('/private/tmp/ocr-engine36-verify-gpu-build.txt'),Path('/private/tmp/ocr-engine36-invalid-credit-test-build.txt'),Path('/private/tmp/ocr-engine36-live-credit-assertion-build.txt')],'logs_manifest.json')
paths=list(v.glob('*engine36*.py'))+[v/'archive_completed_engine_reports.py']
archive('drivers',paths,'drivers_manifest.json')
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine36_08_*qualification*','engine36_08_shared_decoder_rollback*'],check=True)
print('FINAL FULL QUALIFICATION PASS; primary profiles may run',flush=True)
