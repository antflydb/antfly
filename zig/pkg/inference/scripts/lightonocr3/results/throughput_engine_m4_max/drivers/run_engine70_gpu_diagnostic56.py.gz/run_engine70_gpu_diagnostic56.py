from pathlib import Path
import ast,datetime,hashlib,json,os,subprocess,sys
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
primary=json.loads((out/'paired55_4b_comparison_audit.json').read_text());assert primary['status']in['early_stop_forward_loss','native_behind']
for p,h in json.loads((v/'engine70-freeze.json').read_text()).items():assert sha(root/p)==h,p
profiles=primary['profiles'];assert list(profiles)==['wide']
audit=out/'engine70_gpu_diagnostic56_audit.json';assert not audit.exists()
record=dict(status='running',primary_throughput_eligible=False,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),scope='Separate R64 Metal timestamp/encoder diagnostic after primary55 loss. Original caps and full output checks. Instrumented timing is not eligible for a throughput claim.')
audit.write_text(json.dumps(record,indent=2)+'\n')
source=(v/'run_engine70_api_paired55.py').read_text();node=next(x for x in ast.parse(source).body if isinstance(x,ast.FunctionDef)and x.name=='native');fn=ast.get_source_segment(source,node).replace('paired55','gpu_diagnostic56').replace("OCR_REQUESTS='128'","OCR_REQUESTS='64'").replace('_r128','_r64').replace('==128','==64').replace('== 128','== 64')
exec(compile(fn,'extracted_native_gpu_diagnostic56','exec'),globals())
os.environ.update(TERMITE_METAL_STAGE_TIMING='1',TERMITE_METAL_STAGE_TIMING_LOG_FRAMES='1',TERMITE_METAL_STAGE_TIMING_PREFILL_MAX='8',TERMITE_METAL_STAGE_TIMING_DECODE_START='0',TERMITE_METAL_STAGE_TIMING_DECODE_STRIDE='8',TERMITE_METAL_STAGE_TIMING_DECODE_MAX='16',TERMITE_METAL_TRACE_ENCODER_TIMING='1')
oracle=Path(primary['comparisons'][-1]['reference_report']).parent.name.removeprefix('vllm_4b')
d,p=native('wide',0,oracle)
d.update(own_profiling_overlap=True,primary_throughput_eligible=False,diagnostic_driver_sha256=sha(Path(__file__)),diagnostic_scope=record['scope'],extracted_native_source_sha256=hashlib.sha256(fn.encode()).hexdigest());p.write_text(json.dumps(d,indent=2)+'\n')
raw=(p.parent/'lighton4b-batch-c64.txt').read_text();section=raw.split('OCR_POLICY round=0',1)[1]
record.update(status='pass',report=str(p.relative_to(out)),report_sha256=sha(p),metal_timestamp_supported='metal-stage-timing: timestamp dispatch/stage-boundary counters unsupported'not in section,encoder_timing_present='metal_encoder_timing_kernel:'in section)
audit.write_text(json.dumps(record,indent=2)+'\n');print('GPU DIAGNOSTIC DONE',record,flush=True)
