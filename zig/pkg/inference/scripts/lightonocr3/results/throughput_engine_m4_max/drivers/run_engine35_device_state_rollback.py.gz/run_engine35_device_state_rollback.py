from pathlib import Path
import os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');env=os.environ.copy();env.update(OCR_REFERENCE_LABEL='_primary_reference11_r0_auto_c32_r128',OCR_PHYSICAL32='0',OCR_CONCURRENCY='16',OCR_REQUESTS='32',OCR_WIDE='1',OCR_SCRATCH_GIB='8',OCR_BACKEND_GIB='16',OCR_KV_GIB='4',OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='0',OCR_BF16_PREFILL='0',OCR_BF16='0',OCR_VISION_BATCH='0',OCR_VISION_FRAME_BLOCKS='4',OCR_SINGLE_FRAME='1',OCR_STREAM_FIRST='0',OCR_LOGICAL64='0',OCR_DEVICE_RECURRENT_STATE='0',OCR_ADMISSION_UNITS='512')
label='device_state_rollback_c16_r32';r=subprocess.run([sys.executable,str(v/'run_engine35_budget_no_prefill_policies.py'),'08:'+label],env=env);sys.exit(r.returncode)
