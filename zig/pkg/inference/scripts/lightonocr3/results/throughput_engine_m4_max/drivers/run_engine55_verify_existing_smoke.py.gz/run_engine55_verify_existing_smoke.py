from pathlib import Path
import os,subprocess,sys,json
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');label='stage_queue_argmax_smoke_c8_r16'
env=os.environ.copy();env.update(OCR_REFERENCE_LABEL='_primary_reference20_r0_auto_c64_r128',OCR_PHYSICAL32='0',OCR_PHYSICAL64='1',OCR_CONCURRENCY='8',OCR_REQUESTS='16',OCR_WIDE='1',OCR_SCRATCH_GIB='8',OCR_BACKEND_GIB='16',OCR_KV_GIB='4',OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='0',OCR_BF16_PREFILL='0',OCR_BF16='0',OCR_VISION_BATCH='1',OCR_VISION_BATCH_ITEMS='2',OCR_PREFILL_BATCH='1',OCR_PREFILL_BATCH_ITEMS='2',OCR_VISION_FRAME_BLOCKS='1',OCR_SINGLE_FRAME='1',OCR_STREAM_FIRST='0',OCR_STREAM_CHUNK_LAYERS='0',OCR_GPU_GREEDY_STREAM='0',OCR_LOGICAL64='1',OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',OCR_ADMISSION_UNITS='512',OCR_DISABLE_64_ROW_TILE='1',OCR_DISABLE_WIDE_GATE_UP='0',OCR_WIDE64_GATE_UP='0',OCR_FULL64_GATE_UP='0',OCR_BATCH_ARGMAX='1',OCR_DEFER_VISION_SEAL='1',OCR_DEFER_PREFILL_SEAL='1',OCR_TIMEOUT='120',ANTFLY_FLORENCE_CPU_PREPROCESS='0')
p=o/f'engine55_08_{label}';assert p.exists()
env['OCR_VERIFY_SAVED_RUN']='1';env['OCR_ORIGINAL_EXECUTION_DRIVER_SHA']='79a223b6637a3fae9657ee8845487803d2538982ad5f3742eeea335c2f037d1d'
with Path('/private/tmp/ocr-engine55-stage-smoke-verify2.txt').open('w')as log:r=subprocess.run([sys.executable,str(v/'run_engine55_budget_policies_verify2.py'),'08:'+label],env=env,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0,r.returncode
d=json.loads((p/'report.json').read_text());rs=d['results'][0];s=rs['policy_rounds'][0]
assert rs['status']=='ok'and rs['serial_reference_parity']and rs['cross_runtime_content_parity']and s['completed']==16 and not s['admission_pressures']
print('stage queue/argmax smoke PASS',s['pages_per_second'],flush=True)
