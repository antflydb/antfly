from pathlib import Path
import hashlib,json,re
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=o/'engine81_08_resident_ffn_qualification69_r0_physical64_c4_vf4_prefix16_wide640_p1_r4/report.json';d=json.loads(p.read_text());result=d['results'][0];raw=p.parent/result['log'];text=raw.read_text();rounds=result['policy_rounds']
assert result['exit_code']==0 and result['status']=='ok' and result['serial_reference_parity'] and result['cross_runtime_content_parity']
assert len(rounds)==4 and [s['round']for s in rounds]==[0,1,2,3] and [s['prefill_fused_ffn_enabled']for s in rounds]==[False,True,True,False]
assert re.findall(r'OCR_PREFILL_FFN_POLICY round=(\d+) enabled=([01])',text)==[('0','0'),('1','1'),('2','1'),('3','0')]
assert len(re.findall(r'OCR_CONCURRENCY .*parity=true',text))==4
for s in rounds:
 assert s['completed']==s['requests']==s['native_items']==4 and s['concurrency']==4
 assert s['prefill_fused_ffn_calls']==s['wide_mpp_heads']==s['wide_mpp_projections']==0
 assert s['frame_policy_snapshots']>0 and s['prepared_blocks']>0 and s['executor_steps']>0
 assert s['batch_argmax_calls']>0 and s['activation_pool_peak_bytes']<=8*1024**2
 assert s['gpu_greedy_stream_topology_mismatches']==0
assert 'admission_pressure='not in text and len(d['results'][0]['references'])==3
manifest=o/'engine81_build_manifest.json';m=json.loads(manifest.read_text());assert sha(m['binary_path'])==m['binary_sha256']
(o/'engine81_resident_ffn_rounds_initial_wrapper_failure.json').write_text(json.dumps(dict(scope='Private C64-oriented post-verifier incorrectly required a wide MPP vocabulary head for a C4 harness validation. Native execution and canonical verification passed all four rounds. No runtime change; primary C64 verifier remains unchanged.',original_driver_sha256=sha(v/'run_engine81_budget_policies.py'),original_qualification_driver_sha256=sha(v/'qualify_engine81_resident_ffn_rounds.py'),original_failure_log_sha256=sha('/private/tmp/ocr-engine81-resident-rounds-parent.txt'),report_sha256=sha(p),native_log_sha256=sha(raw)),indent=2)+'\n')
(o/'engine81_resident_ffn_rounds_qualification_audit.json').write_text(json.dumps(dict(status='pass',primary_throughput_eligible=False,scope='Four same-resident 0.8B R4 rounds prove per-round FFN flag overrides, frame snapshots and serial/full cross-runtime consistency. The 4B-only shape is ineligible; FFN and wide vocabulary-MPP counts must remain zero at C4. Saved native execution verified without rerun or changes to primary C64 expectations.',verification_driver_sha256=sha(Path(__file__)),report=str(p.relative_to(o)),report_sha256=sha(p),native_log_sha256=sha(raw),build_manifest_sha256=sha(manifest)),indent=2)+'\n')
print('ENGINE81 RESIDENT FFN ROUNDS QUALIFICATION DONE',flush=True)
