from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=(v/'run_engine12_policies.py').read_text();s=s.replace("'--policy-rounds',*policies","'--bf16-prefill-inputs','--policy-rounds',*policies").replace("report['single_frame']=single;","report['bf16_prefill_inputs']=True;report['single_frame']=single;");(v/'run_engine12_prefill_policies.py').write_text(s)
