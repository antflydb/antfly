from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';p=root/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_engine_m4_max'
for path, digest in json.loads((v/'engine69-freeze.json').read_text()).items():
 assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
manifest=out/'engine69_build_manifest.json';binary=json.loads(manifest.read_text())['binary_path']
images=[root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png',p/'corpus/receipt.png',p/'corpus/shipping.png']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
profiles=[json.loads(x.read_text())for x in out.glob('engine64_florence_profile37_batch10_c20_cpu1_r128_primary_audit.json')]
assert profiles and all(x['status']=='pass' for x in profiles)
profile=max(profiles,key=lambda x:x['pages_per_second'])
assert sha(out/profile['report'])==profile['report_sha256']
old=json.loads((out/'engine37_florence_encoder_qualification_enabled0/report.json').read_text())
old_texts={x['image_index']:x['text']for x in old['results'][0]['references']}
path=out/'paired54_florence_comparison_audit.json';assert not path.exists()
audit=dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Fresh MLX-VLM serial proxy only; installed vLLM Metal has no Florence adapter. Native publisher Q4_K plus F16 encoder mirrors/no-repeat trigrams vs MLX original FP16/default greedy. Prior MLX batch2 failed content parity, so batch1 is the valid proxy. Full native strings must remain identical; cross-runtime content is whitespace normalized. Shared machine uncontrolled; no own CPU compilation/sampling during timings.',selected_profile=profile,comparisons=[],status='running')
def save():path.write_text(json.dumps(audit,indent=2)+'\n')
def reference(round):
 dest=out/f'mlx_florence_engine69_paired54_r{round}_reference';assert not(dest/'report.json').exists()
 cmd=[sys.executable,str(p/'benchmark_mlx_florence.py'),'--model-dir',str(v/'ocr-models/florence-fp16'),'--images',*map(str,images),'--batch-sizes','1','--requests','128','--max-tokens','256','--output-dir',str(dest)]
 print('START MLX PROXY',round,flush=True)
 with Path(f'/private/tmp/ocr-engine69-florence-paired54-reference{round}.txt').open('w')as log:
  subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 rp=dest/'report.json';d=json.loads(rp.read_text());assert d['status']=='ok' and d['results'][0]['serial_reference_parity'] and len(d['references'])==3
 print('DONE MLX PROXY',round,d['results'][0]['pages_per_second'],flush=True);return rp,d
def native(round,oracle):
 dest=out/f'engine69_florence_paired54_r{round}_native';assert not(dest/'report.json').exists()
 env=os.environ.copy();env['PYTHONPATH']=str(p);env['ANTFLY_FLORENCE_CPU_PREPROCESS']=str(int(profile['cpu_preprocess_overlap']))
 cmd=[sys.executable,str(v/'engine69_benchmark_concurrency.py'),'--native-test',binary,'--model','florence=/Users/ajroetker/.antfly/inference/models/antflydb/florence-2-base','--images',*map(str,images),
  '--requests','128','--concurrency',str(profile['concurrency']),'--max-tokens','256','--modes','batch','--native-read-batch-size',str(profile['model_batch_size']),
  '--batch-wait-us','5000','--florence-batch-wait-us','20000' if profile['model_batch_size']>8 else '5000','--memory-gib','24','--shared-memory-gib','28','--backend-memory-gib','16','--kv-memory-gib','4','--scratch-memory-gib','8','--timeout','900',
  '--reference-report',str(oracle),'--build-manifest',str(manifest),'--output-dir',str(dest),'--require-florence-no-repeat-argmax','--require-florence-single-frame','--policy-rounds','current']
 if profile['cpu_preprocess_overlap']:cmd+=['--florence-cpu-preprocess']
 print('START NATIVE',round,profile['concurrency'],profile['cpu_preprocess_overlap'],flush=True)
 with Path(f'/private/tmp/ocr-engine69-florence-paired54-native{round}.txt').open('w')as log:
  subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 rp=dest/'report.json';d=json.loads(rp.read_text());d['cpu_preprocess_overlap']=profile['cpu_preprocess_overlap'];rp.write_text(json.dumps(d,indent=2)+'\n')
 r=d['results'][0];sample=r['policy_rounds'][0];f=r['florence_single_frame']
 assert r['status']=='ok' and r['serial_reference_parity'] and r['cross_runtime_content_parity'] and sample['completed']==128
 assert f['steps']>0 and f['api_fallbacks']==f['topology_mismatches']==0
 assert {x['image_index']:x['text']for x in r['references']}==old_texts
 assert 'admission_pressure=' not in (dest/r['log']).read_text()
 raw=(dest/r['log']).read_text().split('OCR_POLICY round=0',1)[1]
 sizes=list(map(int,__import__('re').findall(r'FLORENCE2 batch_items=(\d+)',raw)))
 assert sizes and max(sizes)==profile['model_batch_size'] and sample['native_items']==128,sizes
 print('DONE NATIVE',round,sample['pages_per_second'],flush=True);return rp,d
def compare(round,n,ref,order):
 np,nd=n;rp,rd=ref;r=nd['results'][0];sample=r['policy_rounds'][0]
 texts={x['image_index']:x['text']for x in r['references']};reference={i:x['text']for i,x in enumerate(rd['references'])}
 assert {k:''.join(t.split())for k,t in texts.items()}=={k:''.join(t.split())for k,t in reference.items()}
 a,b=sample['pages_per_second'],rd['results'][0]['pages_per_second']
 item=dict(round=round,order=order,native_report=str(np.relative_to(out)),native_report_sha256=sha(np),proxy_report=str(rp.relative_to(out)),proxy_report_sha256=sha(rp),
  native_pages_per_second=a,proxy_pages_per_second=b,native_to_proxy_ratio=a/b,all_128_native_pages_equal_native_serial=True,native_full_fixture_string_identity=True,
  cross_runtime_full_fixture_string_identity=texts==reference,cross_runtime_whitespace_normalized_content=True,primary_throughput_eligible=True)
 audit['comparisons'].append(item);save();print('COMPARISON',json.dumps(item),flush=True)
save();ref0=reference(0);compare(0,native(0,ref0[0]),ref0,'MLX proxy then native')
n1=native(1,ref0[0]);ref1=reference(1);compare(1,n1,ref1,'native then fresh MLX proxy')
ratios=[x['native_to_proxy_ratio']for x in audit['comparisons']]
audit['status']='native_behind_proxy'if any(x<=1 for x in ratios)else'clear_repeated_proxy_win'if all(x>=1.05 for x in ratios)else'small_repeated_proxy_lead'
save();print('FINAL',audit['status'],flush=True)
