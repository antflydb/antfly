from pathlib import Path
import hashlib,json,os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
mode=sys.argv[1];assert mode in ['qualification','primary']
requests=64 if mode=='qualification' else 128
records=[]
# The CLI disables the ordinary decoder FFN selector (attention layers).
# Prepared recurrent-layer FFNs call C directly and retain their existing route.
for enabled in [False,True]:
 label=f'gqa_ffn_disabled_wide64_gate_up_enabled{int(enabled)}_physical64_c64_vf2_r{requests}_{mode}'
 dest=out/f'engine45_4b_{label}';assert not (dest/'report.json').exists()
 env=os.environ.copy()
 env.update(OCR_REFERENCE_LABEL='_primary_reference20_r0_auto_c64_r128',OCR_PHYSICAL32='0',OCR_PHYSICAL64='1',
  OCR_CONCURRENCY='64',OCR_REQUESTS=str(requests),OCR_WIDE='1',OCR_SCRATCH_GIB='10',
  OCR_BACKEND_GIB='17',OCR_KV_GIB='4',OCR_CPU_PREPROCESS='1',
  OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1',
  OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_VISION_BATCH='0',OCR_VISION_BATCH_ITEMS='1',
  OCR_PREFILL_BATCH='0',OCR_PREFILL_BATCH_ITEMS='1',OCR_VISION_FRAME_BLOCKS='2',
  OCR_SINGLE_FRAME='1',OCR_STREAM_FIRST='0',OCR_GPU_GREEDY_STREAM='0',
  OCR_LOGICAL64='1',OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',
  OCR_ADMISSION_UNITS='512',OCR_DISABLE_64_ROW_TILE='0',OCR_DISABLE_WIDE_GATE_UP='0',OCR_WIDE64_GATE_UP=str(int(enabled)),
  ANTFLY_FLORENCE_CPU_PREPROCESS='0')
 print('START',label,flush=True)
 with Path(f'/private/tmp/ocr-engine45-4b-{label}-driver.txt').open('w') as log:
  r=subprocess.run([sys.executable,str(v/'run_engine45_gqa_ffn_ablation_budget.py'),'4b:'+label],env=env,stdout=log,stderr=subprocess.STDOUT)
 print('DONE',label,r.returncode,flush=True);assert r.returncode==0,(label,r.returncode)
 p=dest/'report.json';d=json.loads(p.read_text());result=d['results'][0];sample=result['policy_rounds'][0]
 assert result['status']=='ok' and result['serial_reference_parity'] and result['cross_runtime_content_parity']
 assert sample['completed']==requests and not sample['admission_pressures']
 assert sample['host_recurrent_bytes_total']==0 and sample['single_frame_topology_mismatches']==0
 assert sample['single_frame_steps']==sample['executor_steps']
 assert sample['gpu_greedy_stream_steps']==sample['stream_forward_splits']==0
 assert (sample['wide_gate_up_calls']>0)==enabled
 oracle=json.loads((out/'vllm_4b_primary_reference20_r0_auto_c64_r128/report.json').read_text())
 assert {t['image_index']:t['text'] for t in result['references']}=={t['image_index']:t['text'] for t in oracle['references']}
 records.append(dict(wide64_gate_up=enabled,wide_gate_up_calls=sample['wide_gate_up_calls'],concurrency=64,vision_frame_blocks=2,
  pages_per_second=sample['pages_per_second'],process_cpu_ms=sample['process_cpu_ms'],
  framed_runtime_totals=sample['framed_runtime_totals'],average_decode_rows=sample['average_decode_rows'],
  completed=requests,full_fixture_string_identity=True,all_native_pages_equal_serial_reference=True,
  primary_throughput_eligible=mode=='primary',own_cpu_compile_or_sampling_overlap=False,
  report=str(p.relative_to(out)),report_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 audit=out/f'engine45_4b_gqa_ffn_disabled_{mode}_audit.json'
 audit.write_text(json.dumps(dict(status='running',candidates=records),indent=2)+'\n')
audit.write_text(json.dumps(dict(status='pass',candidates=records),indent=2)+'\n')
