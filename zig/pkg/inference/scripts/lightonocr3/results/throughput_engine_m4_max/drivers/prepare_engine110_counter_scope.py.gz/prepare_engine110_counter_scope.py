from pathlib import Path
import hashlib,json,gzip,subprocess
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();f=json.loads((v/'engine109-freeze.json').read_text());assert all(sha(p)==h for p,h in f.items());(o/'engine109_unqualified_gpu_runtime.patch.gz').write_bytes(gzip.compress(subprocess.check_output(['git','diff','--',*f]),mtime=0))
p=r/'zig/pkg/inference/src/ops/metal_compute.zig';s=p.read_text();needle='    lighton_batch_argmax_start: [2]u64 = @splat(0),';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    lighton_wide_recurrent_start: [3]u64 = @splat(0),')
needle='        metal_runtime_mod.termite_metal_decode_runtime_lighton_batch_argmax_stats(raw, &self.lighton_batch_argmax_start);';assert s.count(needle)==1;s=s.replace(needle,needle+'\n        metal_runtime_mod.termite_metal_decode_runtime_lighton_wide_recurrent_stats(raw, &self.lighton_wide_recurrent_start);')
a=s.index('    pub fn lightOnWideRecurrentStats(');b=s.index('\n    pub fn ',a+10);part=s[a:b];needle='        return stats;';assert part.count(needle)==1;part=part.replace(needle,'''        stats[0] -|= self.lighton_wide_recurrent_start[0];
        stats[2] -|= self.lighton_wide_recurrent_start[2];
        // The maximum is a lifetime high-water mark. Counts and staged bytes
        // are scoped to this reader, so warmup activity cannot qualify a run.
        if (stats[0] == 0) stats[1] = 0;
'''+needle);s=s[:a]+part+s[b:];p.write_text(s)
for name in ['zig/pkg/inference/src/server/server.zig','zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py']:
 p=r/name;s=p.read_text();assert 'wide_recurrent_max_rows' in s;s=s.replace('wide_recurrent_max_rows','wide_recurrent_lifetime_max_rows');p.write_text(s)
for old,new in [('run_engine109_gpu_build.py','run_engine110_gpu_build.py'),('run_engine109_budget_policies.py','run_engine110_budget_policies.py'),('run_engine109_mixed_screen89.py','run_engine110_mixed_screen89.py'),('save_engine109_manifest.py','save_engine110_manifest.py')]:
 s=(v/old).read_text().replace('engine109','engine110').replace('wide_recurrent_max_rows','wide_recurrent_lifetime_max_rows');(v/new).write_text(s)
