from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
for name in ['run_engine45_verify_gpu_build.py','run_engine45_budget_policies.py','run_engine45_functional.py','run_engine45_florence_case_verify.py','run_engine45_florence_raster_qualification_verify.py']:
 p=v/name.replace('engine45','engine46')
 assert not p.exists()
 text=(v/name).read_text().replace('engine45','engine46')
 if 'florence_case_verify' in name:
  text=text.replace('b in [8,10,12,16,32,64]','b in [8,10,12,16,24,32,48,64]')
  text=text.replace("timed=raw.split('OCR_POLICY round=0',1)[1];sizes=", """stats=re.findall(r'FLORENCE2 incremental_admission=(\\d+) logits_rows=(\\d+) fallback_supplement_attempts=(\\d+) fallback_supplements_acquired=(\\d+)',raw)
assert stats and all(tuple(map(int,s))==(1,1,0,0) for s in stats),stats
timed=raw.split('OCR_POLICY round=0',1)[1];sizes=""")
 p.write_text(text)
