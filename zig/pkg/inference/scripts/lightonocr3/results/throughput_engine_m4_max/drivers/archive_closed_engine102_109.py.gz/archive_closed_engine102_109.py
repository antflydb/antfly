from pathlib import Path
import hashlib,json,subprocess,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
assert json.loads((o/'paired86_4b_warmed_comparison_audit.json').read_text())['status']=='native_behind'
assert json.loads((o/'engine108_wide_core_suppressed_audit.json').read_text())['status']=='private_screen_complete'
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine102_4b_paired86*','vllm_4b_primary_reference86*'],check=True)
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns);logs=[];drivers=[]
for tag in range(102,110):
 logs+=list(Path('/private/tmp').glob(f'ocr-engine{tag}-*.txt'))
 drivers+=[p for p in v.glob(f'*engine{tag}*')if p.is_file()and p.suffix in ['.py','.json','.m','.metal','.inc','.patch','.zig']]
ns['archive']('qualification',sorted(set(logs)),'logs_manifest.json')
index=json.loads((o/'drivers/drivers_manifest.json').read_text());renamed=[]
for p in sorted(set(drivers)):
 h=hashlib.sha256(p.read_bytes()).hexdigest();entry=index.get(p.name+'.gz')
 if entry and entry['raw_sha256']!=h:
  q=v/(p.stem+'_closed109_'+h[:10]+p.suffix);assert not q.exists()or q.read_bytes()==p.read_bytes();q.write_bytes(p.read_bytes());renamed.append(q)
 else:renamed.append(p)
ns['archive']('drivers',renamed,'drivers_manifest.json');print('Closed102-109archived; active110untouched')
