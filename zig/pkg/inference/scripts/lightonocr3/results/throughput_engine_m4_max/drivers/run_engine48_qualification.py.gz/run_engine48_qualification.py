from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';out=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def freeze():
 d=json.loads((v/'engine48-freeze.json').read_text())
 assert all(sha(root/p)==s for p,s in d.items())
 m=json.loads((out/'engine48_build_manifest.json').read_text())
 assert sha(Path(m['binary_path']))==m['binary_sha256']
def archive(paths):
 ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
 ns['archive']('qualification',paths,'logs_manifest.json')
def run(name,cmd):
 print('START',name,flush=True)
 log=Path('/private/tmp/ocr-'+name+'.txt');assert not log.exists()
 with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 archive([log]);print('DONE',name,r.returncode,flush=True)
 assert r.returncode==0,(name,r.returncode)
def compress(patterns):
 subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),*patterns],check=True)

freeze()
run('engine48-functional-driver',[sys.executable,str(v/'run_engine48_functional.py')])
run('engine48-full64-qualification-driver',[sys.executable,str(v/'run_engine48_full64_cases.py'),'qualification'])
run('engine48-stream-qualification-driver',[sys.executable,str(v/'run_engine48_stream_cases.py'),'qualification'])
run('engine48-florence-b12-qualification-driver',[sys.executable,str(v/'run_engine48_florence_case_verify.py'),'qualification','12','24','1'])
freeze()
compress(['engine48_*qualification*'])
archive(list(Path('/private/tmp').glob('ocr-engine48-functional-*.txt')))
archive(list(Path('/private/tmp').glob('ocr-engine48-verify-*.txt')))
archive(list(Path('/private/tmp').glob('ocr-engine48-4b-*qualification*.txt')))
archive(list(Path('/private/tmp').glob('ocr-engine48-08-*qualification*.txt')))
archive(list(Path('/private/tmp').glob('ocr-engine48-florence*qualification*.txt')))
checks=[out/'engine48_4b_full64_gate_up_qualification_audit.json',out/'engine48_08_gpu_greedy_stream_qualification_audit.json',out/'engine48_florence_batch12_c24_cpu1_r32_qualification_audit.json',out/'engine48_c_qualification_reuse_audit.json']
assert all(json.loads(p.read_text())['status']=='pass'for p in checks)
(out/'engine48_full_qualification_audit.json').write_text(json.dumps(dict(status='pass',checks=[dict(path=str(p.relative_to(out)),sha256=sha(p)) for p in checks],runtime_files_sha256=json.loads((v/'engine48-freeze.json').read_text())),indent=2)+'\n')
print('ALL ENGINE48 QUALIFICATION PASS',flush=True)
