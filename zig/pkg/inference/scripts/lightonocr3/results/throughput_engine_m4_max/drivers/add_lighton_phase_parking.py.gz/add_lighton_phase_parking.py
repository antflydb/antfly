from pathlib import Path
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text();needle='''        execution_gate_wait_ns: u64 = 0,
        step_mutex:''';assert s.count(needle)==1;s=s.replace(needle,'''        execution_gate_wait_ns: u64 = 0,
        phase_wait_ns: u64 = 0,
        published_vision_peak: std.atomic.Value(usize) = .init(0),
        step_mutex:''',1)
needle='''            // New prefill must progress, while already decoding pages retain''';assert s.count(needle)==1;s=s.replace(needle,'''            ctx.phase_wait_ns = if (platform.env.getenvBool("ANTFLY_LIGHTONOCR3_PHASE_PARK")) ctx.execution_gate_wait_ns else 0;
'''+needle,1)
needle='''        fn admitPage(ctx: *LightOnStreamContext, factory: *Factory, peak: ?usize, amounts: runtime.tier.memory.AdmissionAmounts) !model_manager_mod.GenerationAdmissionLease {
            if (peak) |bytes| {
                try factory.control.lock(&ctx.step_mutex);
                defer ctx.step_mutex.unlock();
                try ctx.vision_peak.grow(bytes, factory, acquireVisionPeak);
            }''';assert s.count(needle)==1;s=s.replace(needle,'''        fn lockStep(ctx: *LightOnStreamContext, control: InferenceExecutionControl) !void {
            try control.lockWithPoll(&ctx.step_mutex, ctx.phase_wait_ns);
        }
        fn lockStepForCleanup(ctx: *LightOnStreamContext) void {
            if (ctx.phase_wait_ns == 0) return platform.sync.lockYielding(&ctx.step_mutex);
            // Cleanup must retain stack-backed state until its owner releases
            // the backend. An empty control cannot cancel this acquisition.
            (InferenceExecutionControl{}).lockWithPoll(&ctx.step_mutex, ctx.phase_wait_ns) catch unreachable;
        }
        fn admitPage(ctx: *LightOnStreamContext, factory: *Factory, peak: ?usize, amounts: runtime.tier.memory.AdmissionAmounts) !model_manager_mod.GenerationAdmissionLease {
            if (peak) |bytes| {
                if (ctx.phase_wait_ns == 0 or bytes > ctx.published_vision_peak.load(.acquire)) {
                    try ctx.lockStep(factory.control);
                    defer ctx.step_mutex.unlock();
                    try ctx.vision_peak.grow(bytes, factory, acquireVisionPeak);
                    // Publish only after the larger peak's resource lease is
                    // held. Smaller pages can then avoid the GPU execution gate.
                    if (ctx.phase_wait_ns != 0) ctx.published_vision_peak.store(ctx.vision_peak.bytes, .release);
                }
            }''',1)
s=s.replace('try request.control.lock(&ctx.step_mutex);','try ctx.lockStep(request.control);',1)
assert s.count('control.lock(&ctx.step_mutex) catch |err| {')==2;s=s.replace('control.lock(&ctx.step_mutex) catch |err| {','ctx.lockStep(control) catch |err| {')
assert s.count('try control.lock(&ctx.step_mutex);')==1;s=s.replace('try control.lock(&ctx.step_mutex);','try ctx.lockStep(control);',1)
# The newly added helper contains the same old lock as its disabled fallback.
needle='''            platform.sync.lockYielding(&ctx.step_mutex);''';assert s.count(needle)==2;s=s.replace(needle,'''            ctx.lockStepForCleanup();''')
needle='''        var logged_wait = false;
        var admission = while''';assert s.count(needle)==1;s=s.replace(needle,'''        var logged_wait = false;
        var retry_delay_ns: u64 = std.time.ns_per_ms;
        var admission = while''',1)
needle='''                platform.time.sleepNs(std.time.ns_per_ms);
                continue;''';assert s.count(needle)==1;s=s.replace(needle,'''                platform.time.sleepNs(retry_delay_ns);
                if (ctx.phase_wait_ns != 0) retry_delay_ns = @min(retry_delay_ns * 2, 10 * std.time.ns_per_ms);
                continue;''',1)
needle='''                std.debug.print("LIGHTONOCR3 executor_steps={d}\\n", .{ctx.worker_steps});''';assert s.count(needle)==1;s=s.replace(needle,needle+'''
                std.debug.print("LIGHTONOCR3 phase_gate_wait_ns={d}\\n", .{ctx.phase_wait_ns});''',1)
needle='''            "ANTFLY_LIGHTONOCR3_ACTIVATION_POOL",
        };''';assert s.count(needle)==1;s=s.replace(needle,'''            "ANTFLY_LIGHTONOCR3_ACTIVATION_POOL",
            "ANTFLY_LIGHTONOCR3_PHASE_PARK",
        };''',1)
needle='''const engine = std.mem.eql(u8, policy, "enginepool")''';assert s.count(needle)==1;s=s.replace(needle,'''const engine = std.mem.eql(u8, policy, "enginephase") or std.mem.eql(u8, policy, "enginepoolphase") or std.mem.eql(u8, policy, "enginefull") or std.mem.eql(u8, policy, "enginepool")''',1)
s=s.replace('''or std.mem.eql(u8, policy, "enginecached")) "1" else "0"''','''or std.mem.eql(u8, policy, "enginecached") or std.mem.eql(u8, policy, "enginefull")) "1" else "0"''',2)
needle='''if (std.mem.eql(u8, policy, "enginepool") or std.mem.eql(u8, policy, "enginecached")) "1" else "0"''';assert s.count(needle)==1;s=s.replace(needle,'''if (std.mem.eql(u8, policy, "enginepool") or std.mem.eql(u8, policy, "enginecached") or std.mem.eql(u8, policy, "enginepoolphase") or std.mem.eql(u8, policy, "enginefull")) "1" else "0"''',1)
needle='''            std.debug.print("OCR_POLICY round={d} name={s}\\n", .{ round, policy });''';assert s.count(needle)==1;s=s.replace(needle,'''            if (std.mem.startsWith(u8, policy, "engine")) {
                if (Env.setenv("ANTFLY_LIGHTONOCR3_PHASE_PARK", if (std.mem.eql(u8, policy, "enginephase") or std.mem.eql(u8, policy, "enginepoolphase") or std.mem.eql(u8, policy, "enginefull")) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;
            }
'''+needle,1);p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text().replace('''            "enginecached",
''','''            "enginecached",
            "enginephase",
            "enginepoolphase",
            "enginefull",
''',1).replace('''                        "activation_pool_duplicate_retirements",
''','''                        "activation_pool_duplicate_retirements",
                        "phase_gate_wait_ns",
''',1);p.write_text(s)

p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text().replace('if counter.endswith("_peak_bytes")','if counter.endswith("_peak_bytes") or counter == "phase_gate_wait_ns"');p.write_text(s)
