from pathlib import Path
import json,os,re,subprocess,sys,hashlib
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';p=root/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_engine_m4_max'
binary=json.loads((out/'engine45_build_manifest.json').read_text())['binary_path'];records=[]
for enabled in [False,True]:
 for index,image in enumerate([root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png',p/'corpus/receipt.png',p/'corpus/shipping.png']):
  env=os.environ.copy();env.update(ANTFLY_TEST_LIGHTONOCR3_MODEL_DIR='/Users/ajroetker/.antfly/inference/models/antflydb/florence-2-base',
   ANTFLY_TEST_LIGHTONOCR3_IMAGE_PATH=str(image),ANTFLY_TEST_LIGHTONOCR3_MAX_TOKENS='256',
   ANTFLY_TEST_LIGHTONOCR3_WARM_RUNS='0',ANTFLY_BENCH_LIGHTONOCR3='1',ANTFLY_TEST_LIGHTONOCR3_REQUESTS='0',
   ANTFLY_TEST_OCR_RASTER_PARITY='1',ANTFLY_TEST_LIGHTONOCR3_HTTP_BATCH='0',ANTFLY_TEST_LIGHTONOCR3_VISION_BATCH_CHECK='0',
   ANTFLY_FLORENCE_CPU_PREPROCESS=str(int(enabled)),ANTFLY_INFERENCE_READ_BATCH_SIZE='16',ANTFLY_OCR_ENCODER_SCOPES='0',
   ANTFLY_INFERENCE_PREFERRED_BACKEND='metal',ANTFLY_INFERENCE_REQUIRED_BACKEND='metal',
   ANTFLY_TEST_LIGHTONOCR3_MEMORY_LIMIT_GIB='24',ANTFLY_TEST_LIGHTONOCR3_SHARED_LIMIT_GIB='28',
   ANTFLY_TEST_LIGHTONOCR3_BACKEND_LIMIT_GIB='16',ANTFLY_TEST_LIGHTONOCR3_KV_LIMIT_GIB='4',ANTFLY_TEST_LIGHTONOCR3_SCRATCH_LIMIT_GIB='8',
   ANTFLY_TEST_LIGHTONOCR3_ADMISSION_UNITS='512',ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX='1')
  env.pop('ANTFLY_TEST_LIGHTONOCR3_CONCURRENCY',None)
  log=Path(f'/private/tmp/ocr-engine45-florence-raster-cpu{int(enabled)}-image{index}.txt');assert not log.exists()
  print('START',enabled,index,flush=True)
  with log.open('w')as stream:r=subprocess.run([binary,'--test-filter','LightOnOCR3 real checkpoint'],env=env,stdout=stream,stderr=subprocess.STDOUT,cwd=root/'zig/pkg/inference')
  print('DONE',enabled,index,r.returncode,flush=True);assert r.returncode==0,(enabled,index,r.returncode)
  raw=log.read_text();assert 'LIGHTONOCR3 backend=metal' in raw
  assert re.findall(r'OCR raster_pages=(\d+) padded_stride=true full_text_identity=true',raw)==['1','2']
  assert 'admission_pressure='not in raw
  records.append(dict(cpu_preprocess_overlap=enabled,image_index=index,padded_raster_pages=[1,2],full_encoded_raster_text_identity=True,identity_and_padding_preserved=True,
   log=str(log),raw_sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
  (out/'engine45_florence_raster_qualification_audit.json').write_text(json.dumps(dict(status='running',records=records),indent=2)+'\n')
(out/'engine45_florence_raster_qualification_audit.json').write_text(json.dumps(dict(status='pass',records=records),indent=2)+'\n')
