from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
for name in ['prepare_engine45_streamed_prefill_tiles.py','build_engine45_streamed_prefill_tiles.py','prepare_engine45_prefill_columns_probe.py','build_engine45_prefill_columns_probe.py']:
    dest=v/name.replace('engine45','engine46')
    assert not dest.exists()
    dest.write_text((v/name).read_text().replace('engine45','engine46'))
