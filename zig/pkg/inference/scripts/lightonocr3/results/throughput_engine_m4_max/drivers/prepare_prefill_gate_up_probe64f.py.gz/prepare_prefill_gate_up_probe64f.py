from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=(v/'prefill_gate_up_probe64d.metal').read_text();a=s.index('kernel void candidate0(');s=s[:a]
s=s.replace('template<uint M,uint N,uint SG,uint K>','template<bool TG,uint M,uint N,uint SG,uint K>')
s=s.replace('constant Params&p,uint2 group){','constant Params&p,uint2 group,threadgroup bfloat*tile,uint tid){')
s=s.replace('matmul2d_descriptor(M,N,K,false,true,true)','matmul2d_descriptor(M,N,K,false,true,false,matmul2d_descriptor::mode::multiply_accumulate)')
a='  op.run(left,rightG,g);op.run(left,rightU,u);';assert s.count(a)==1
b='''  if constexpr(TG){
   for(uint i=tid;i<M*K;i+=128){uint row=group.y*M+i/K;tile[i]=row<p.rows?x[row*p.in_dim+k+i%K]:bfloat(0);}
   threadgroup_barrier(mem_flags::mem_threadgroup);
   tensor<threadgroup bfloat,dextents<int,2>,tensor_inline>at(tile,dextents<int,2>(K,M),array<int,2>{1,int(K)});auto cached=at.slice(0,0);
   op.run(cached,rightG,g);op.run(cached,rightU,u);
   threadgroup_barrier(mem_flags::mem_threadgroup);
  }else{op.run(left,rightG,g);op.run(left,rightU,u);}'''
s=s.replace(a,b)
cases=[(False,32,64,k)for k in [64,128,256]]+[(True,32,64,k)for k in [64,128,256]]+[(True,64,32,k)for k in [64,128]]
for i,(tg,m,n,k)in enumerate(cases):
 s+=f'kernel void candidate{i}(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]],uint tid[[thread_index_in_threadgroup]]){{threadgroup bfloat tile[{m*k}];candidate_gate<{str(tg).lower()},{m},{n},4,{k}>(x,g,u,gb,ub,y,p,group,tile,tid);}}\n'
(v/'prefill_gate_up_probe64f.metal').write_text(s)
s=(v/'prefill_gate_up_probe64d.m').read_text().replace('size_t m=variant<4?32:64,n=variant<4?64:32;','size_t m=variant<6?32:64,n=variant<6?64:32;');(v/'prefill_gate_up_probe64f.m').write_text(s)
s=(v/'run_prefill_gate_up_probe64b.py').read_text().replace('probe64b','probe64f').replace('gup64b','gup64f').replace('probe64a.metal','probe64f.metal');(v/'run_prefill_gate_up_probe64f.py').write_text(s)
