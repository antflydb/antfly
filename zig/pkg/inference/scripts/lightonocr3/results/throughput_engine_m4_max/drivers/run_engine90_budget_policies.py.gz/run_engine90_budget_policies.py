from pathlib import Path
import hashlib,json,os,subprocess,sys,re
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max';manifest=out/'engine90_build_manifest.json';binary=Path(json.loads(manifest.read_text())['binary_path'])
for key in sys.argv[1:]:
 model,label=key.split(':');env=os.environ.copy();cpu_preprocess=os.environ.get('OCR_CPU_PREPROCESS','1')=='1';vision_batch=os.environ.get('OCR_VISION_BATCH','0')=='1';env['ANTFLY_LIGHTONOCR3_PREFILL_DECODE_STREAK']=os.environ.get('OCR_PREFILL_DECODE_STREAK','4');env['ANTFLY_LIGHTONOCR3_VISION_FRAME_BLOCKS']=os.environ.get('OCR_VISION_FRAME_BLOCKS','1');env['ANTFLY_LIGHTONOCR3_CPU_PREPROCESS']='1'if cpu_preprocess else'0';env['ANTFLY_LIGHTONOCR3_GATE_EVENTS']=os.environ.get('OCR_GATE_EVENTS','1');env['PYTHONPATH']=str(scripts);wide=os.environ.get('OCR_WIDE','0')=='1';physical32=os.environ.get('OCR_PHYSICAL32','0')=='1';physical64=os.environ.get('OCR_PHYSICAL64','0')=='1';physical_rows=64 if physical64 else 32 if physical32 else 16 if wide else 8;compact=os.environ.get('OCR_COMPACT','1')=='1';extended=os.environ.get('OCR_EXTENDED_EPOCH','1')=='1';env['ANTFLY_LIGHTONOCR3_EXTENDED_EPOCH']='1'if extended else'0';pack_disabled=os.environ.get('OCR_DISABLE_PACK_REUSE','0')=='1';contention=os.environ.get('OCR_CONTENTION_US','1000');batched=os.environ.get('OCR_BATCH_ATTENTION','1')=='1';env['ANTFLY_LIGHTONOCR3_BATCH_ATTENTION']='1'if batched else'0';chunks=int(os.environ.get('OCR_STREAM_CHUNK_LAYERS','0'));stream=chunks or int(os.environ.get('OCR_STREAM_FIRST','0'));env['ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS']=str(stream);shared=os.environ.get('OCR_SHARED_CORE','1')=='1';disable_mpp=os.environ.get('OCR_DISABLE_WIDE_MPP','0')=='1';prefill_bf16=os.environ.get('OCR_BF16_PREFILL','0')=='1';env['ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS']='1'if shared else'0';single=os.environ.get('OCR_SINGLE_FRAME','0')=='1';bf16=os.environ.get('OCR_BF16','0')=='1';env['ANTFLY_LIGHTONOCR3_SINGLE_FRAME']='1'if single else'0';env['ANTFLY_LIGHTONOCR3_COMPACT_KV']='1'if compact else'0';env['ANTFLY_LIGHTONOCR3_EXECUTOR_TAIL']='0';env['ANTFLY_LIGHTONOCR3_PHASE_FAIR']='0';env['ANTFLY_LIGHTONOCR3_EPOCH_AUX']='0';env.update(ANTFLY_LIGHTONOCR3_WIDE_DECODE='1'if wide else'0',ANTFLY_LIGHTONOCR3_PREPARED_DECODE='0',ANTFLY_LIGHTONOCR3_EXECUTOR='0',ANTFLY_LIGHTONOCR3_STEP_EVENTS='0',ANTFLY_LIGHTONOCR3_DECODE_WORKSPACE='0',ANTFLY_LIGHTONOCR3_ACTIVATION_POOL='0')
 pipeline_vision=os.environ.get('OCR_PIPELINE_VISION','0')=='1'
 burst=os.environ.get('OCR_GPU_TOKEN_BURST','0')=='1'
 burst_width=int(os.environ.get('OCR_GPU_TOKEN_BURST_WIDTH','4')) if burst else 2
 assert burst_width in range(2,9)
 c=os.environ.get('OCR_CONCURRENCY','8');requests=os.environ.get('OCR_REQUESTS','16');policies=os.environ.get('OCR_POLICIES','engineepoch,enginetailepoch').split(',');target=out/f'engine90_{model}_{label}'
 env['TERMITE_METAL_DISABLE_LIGHTONOCR3_DECODE_PACK_REUSE']=os.environ.get('OCR_DISABLE_DECODE_PACK_REUSE','0');env['TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_PACK_REUSE']=os.environ.get('OCR_DISABLE_VISION_PACK_REUSE','0')
 planned_disabled=os.environ.get('OCR_DISABLE_PLANNED_MPP','0')=='1';hook=os.environ.get('OCR_PREFILL_BATCH','0')=='1';vision_items=int(os.environ.get('OCR_VISION_BATCH_ITEMS','4'))if vision_batch else 1;prefill_items=int(os.environ.get('OCR_PREFILL_BATCH_ITEMS','4'))if hook else 1
 cmd=[sys.executable,str(v/'engine90_benchmark_concurrency.py'),'--native-test',str(binary),'--model',f'lighton{model}={v/"ocr-models"/("lighton"+model)}','--images',str(root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(scripts/'corpus/receipt.png'),str(scripts/'corpus/shipping.png'),'--concurrency',c,'--requests',requests,'--max-tokens','256','--modes','batch','--batch-rows',str(physical_rows),'--batch-window',c,'--batch-wait-us','20000','--memory-gib','24','--shared-memory-gib','28','--backend-memory-gib',os.environ.get('OCR_BACKEND_GIB','16'),'--kv-memory-gib',os.environ.get('OCR_KV_GIB','4'),'--scratch-memory-gib',os.environ.get('OCR_SCRATCH_GIB','4'),'--timeout',os.environ.get('OCR_TIMEOUT','900'),'--contention-wait-us',contention,'--reference-report',str(out/('vllm_'+model+os.environ.get('OCR_REFERENCE_LABEL', '_primary_reference5_32x128' if c=='32' else '_primary_reference6_16x128' if requests=='128' else '_primary_reference3_16x32'))/'report.json'),'--output-dir',str(target),'--build-manifest',str(manifest),'--weight-residency','--continuous','--frame-policy','--require-frame-policy','--weight-handles','--require-weight-handles','--trace-packed-core','--require-packed-core','--recurrent-parallel','--require-recurrent-parallel','--prefill-attention-mpp','--require-prefill-attention-mpp','--prefill-core-norm','--require-prefill-core-norm',*(['--bf16-projection-inputs']if bf16 else[]),*(['--bf16-prefill-inputs']if prefill_bf16 else[]),*(['--disable-wide-mpp']if disable_mpp else[]),*(['--disable-prefill-pack-reuse']if pack_disabled else[]),*(['--disable-decode-pack-reuse']if env['TERMITE_METAL_DISABLE_LIGHTONOCR3_DECODE_PACK_REUSE']=='1'else[]),*(['--disable-vision-pack-reuse']if env['TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_PACK_REUSE']=='1'else[]),*(['--physical64'] if physical64 else ['--physical32'] if physical32 else []),*(['--vision-batch','--vision-wait-us',os.environ.get('OCR_VISION_WAIT_US','2000')] if vision_batch else []),'--policy-rounds',*policies]
 prefill_stream=int(os.environ.get('OCR_PREFILL_STREAM_LAYERS','0'))
 if os.environ.get('OCR_PREFILL_FUSED_FFN','0')=='1':cmd+=['--prefill-fused-ffn','--require-prefill-fused-ffn']
 if os.environ.get('OCR_BF16_ROUNDS'):
  cmd+=['--bf16-projection-rounds',*os.environ['OCR_BF16_ROUNDS'].split(',')]
 if os.environ.get('OCR_REQUIRE_MEMORY_ROUNDS','0')=='1':cmd+=['--require-memory-rounds']
 if os.environ.get('OCR_PREFILL_FFN_ROUNDS'):
  cmd+=['--prefill-ffn-rounds',*os.environ['OCR_PREFILL_FFN_ROUNDS'].split(',')]
  if os.environ.get('OCR_REQUIRE_PREFILL_FFN','1')=='1':cmd+=['--require-prefill-fused-ffn']
 if prefill_stream:cmd+=['--prefill-stream-layers',str(prefill_stream)]
 if pipeline_vision:cmd+=['--pipeline-vision']
 if burst:cmd+=['--gpu-token-burst','--gpu-token-burst-width',str(burst_width)]
 logical64=os.environ.get('OCR_LOGICAL64','0')=='1'
 if logical64:cmd+=['--logical64']
 device_state=os.environ.get('OCR_DEVICE_RECURRENT_STATE','1')=='1'
 if device_state:cmd+=['--device-recurrent-state']
 share_decoder=os.environ.get('OCR_SHARED_DECODER_SCRATCH','0')=='1'
 if share_decoder:cmd+=['--share-decoder-scratch']
 encoder_scopes=os.environ.get('OCR_ENCODER_SCOPES','1')=='1'
 if encoder_scopes:cmd+=['--ocr-encoder-scopes']
 admission_units=os.environ.get('OCR_ADMISSION_UNITS','512');cmd+=['--admission-units',admission_units]
 token_scope_disabled=os.environ.get('OCR_DISABLE_TOKEN_ENCODER','0')=='1'
 if token_scope_disabled:cmd+=['--disable-lighton-token-encoder']
 if planned_disabled:cmd+=['--disable-planned-mpp']
 cmd+=['--vision-batch-items',str(vision_items),'--prefill-batch-items',str(prefill_items)]
 if hook:cmd+=['--prefill-batch','--prefill-wait-us',os.environ.get('OCR_PREFILL_WAIT_US','100000')]
 if os.environ.get('OCR_DISABLE_64_ROW_TILE','0')=='1':cmd+=['--disable-64-row-tile']
 cache_vision=os.environ.get('OCR_CACHE_VISION_WORKSPACE','0')=='1'
 large_vision_pack=os.environ.get('OCR_LARGE_VISION_PACK_REUSE','0')=='1'
 if cache_vision:cmd+=['--cache-vision-workspace']
 if large_vision_pack:cmd+=['--large-vision-pack-reuse']
 resident_vision=os.environ.get('OCR_RESIDENT_VISION_BUDGET','0')=='1'
 if resident_vision:cmd+=['--resident-vision-budget']
 batch_argmax=os.environ.get('OCR_BATCH_ARGMAX','0')=='1'
 defer_vision=os.environ.get('OCR_DEFER_VISION_SEAL','0')=='1'
 defer_prefill=os.environ.get('OCR_DEFER_PREFILL_SEAL','0')=='1'
 if batch_argmax:cmd+=['--batch-argmax']
 if defer_vision:cmd+=['--defer-vision-seal']
 if defer_prefill:cmd+=['--defer-prefill-seal']
 full64_gate_up=os.environ.get('OCR_FULL64_GATE_UP','0')=='1'
 if full64_gate_up:cmd+=['--full64-gate-up']
 wide64_gate_up=os.environ.get('OCR_WIDE64_GATE_UP','0')=='1'
 if wide64_gate_up:cmd+=['--wide64-gate-up']
 greedy_stream=chunks>0 or os.environ.get('OCR_GPU_GREEDY_STREAM','0')=='1'
 if greedy_stream:cmd+=['--gpu-greedy-stream']
 if chunks:cmd+=['--stream-chunk-layers',str(chunks)]
 wide_gate_disabled=os.environ.get('OCR_DISABLE_WIDE_GATE_UP','0')=='1'
 if wide_gate_disabled:cmd+=['--disable-wide-gate-up']
 print('START',key,flush=True)
 if os.environ.get('OCR_VERIFY_SAVED_RUN','0')=='1':
  from types import SimpleNamespace
  assert (target/'report.json').exists()
  res=SimpleNamespace(returncode=0)
 else:
  with open('/private/tmp/ocr-engine90-'+model+'-'+label+'.txt','w')as log:res=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 if(target/'report.json').exists():
  report=json.loads((target/'report.json').read_text());report['cache_vision_workspace']=cache_vision;report['large_vision_pack_reuse']=large_vision_pack;report['batch_argmax']=batch_argmax;report['defer_vision_seal']=defer_vision;report['defer_prefill_seal']=defer_prefill;report['stream_chunk_layers']=chunks;report['full64_gate_up']=full64_gate_up;report['wide64_gate_up']=wide64_gate_up;report['gpu_greedy_stream']=greedy_stream;report['wide_gate_up_model_qualified']=model=='08';report['disable_wide_gate_up']=wide_gate_disabled;report['ocr_encoder_scopes']=encoder_scopes;report['shared_decoder_scratch']=share_decoder;report['logical64']=logical64;report['device_recurrent_state']=device_state;report['request_admission_units']=int(admission_units);report['kv_memory_gib']=int(os.environ.get('OCR_KV_GIB','4'));report['prefill_batch']=hook;report['vision_batch_items']=vision_items;report['prefill_batch_items']=prefill_items;report['prefill_wait_us']=int(os.environ.get('OCR_PREFILL_WAIT_US','100000'));report['cpu_preprocess']=cpu_preprocess;report['vision_batch']=vision_batch;report['gate_events']=env['ANTFLY_LIGHTONOCR3_GATE_EVENTS']=='1';report['driver_sha256']=os.environ.get('OCR_ORIGINAL_EXECUTION_DRIVER_SHA',hashlib.sha256(Path(__file__).read_bytes()).hexdigest());report['verification_driver_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();report['verified_existing_run']=os.environ.get('OCR_VERIFY_SAVED_RUN','0')=='1';report['own_cpu_compile_overlap']=os.environ.get('OCR_DIAGNOSTIC','0')=='1';report['extended_epoch']=extended;report['disable_prefill_pack_reuse']=pack_disabled;report['contention_wait_us']=int(contention);report['batch_attention']=batched;report['planned_barriers_disabled']=env.get('TERMITE_METAL_DISABLE_PLANNED_COMPUTE_BARRIERS','0');report['stream_first_layers']=stream;report['shared_core_weights']=shared;report['disable_wide_mpp']=disable_mpp;report['bf16_prefill_inputs']=prefill_bf16;report['single_frame']=single;report['bf16_projection_inputs']=bf16;report['compact_qwen35_kv']=compact;report['physical_rows']=physical_rows
  for result in report['results']:
   raw=(target/result['log']).read_text()
   heads=list(re.finditer(r'OCR_POLICY round=(\d+) name=(\w+)',raw))
   sections={int(m[1]):raw[m.end():heads[i+1].start()if i+1<len(heads)else len(raw)]for i,m in enumerate(heads)}
   for sample in (result.get('policy_rounds') or []):
    round_bf16=sample.get('bf16_projection_enabled',bf16)
    section=sections[sample['round']]
    prefstats=re.findall(r'prefill_stream_layers=(\d+) prefill_stream_splits=(\d+)',section);sample['prefill_stream_splits']=sum(int(n)for k,n in prefstats);report['prefill_stream_layers']=prefill_stream
    assert prefstats and all(int(k)==prefill_stream for k,n in prefstats),(prefstats,prefill_stream)
    if prefill_stream:assert sample['prefill_stream_splits']>0,prefstats
    else:assert sample['prefill_stream_splits']==0,prefstats
    vf=int(os.environ.get('OCR_VISION_FRAME_BLOCKS','1'));report['vision_frame_blocks']=vf;groups=re.findall(r'vision_frame_blocks=(\d+) vision_frame_submits=(\d+) vision_frame_images=(\d+)',section);sample['vision_frame_groups']=[list(map(int,x))for x in groups]
    if vf>1 or pipeline_vision:assert sum(int(n)for _,_,n in groups)==int(requests) and all(int(b)==vf and int(s)==(12 if model=='08' else 24)//vf for b,s,n in groups),(sample,groups)
    prefill_batches=re.findall(r'prefill_batch_items=(\d+) query_tokens=(\d+)',section);sample['prefill_batches']=[{'items':int(n),'tokens_per_item':int(t)} for n,t in prefill_batches];assert (bool(prefill_batches)==hook) and all(1<=int(n)<=prefill_items for n,t in prefill_batches) and (not hook or sum(int(n)for n,t in prefill_batches)==int(requests)),(sample,prefill_batches)
    streak=int(os.environ.get('OCR_PREFILL_DECODE_STREAK','4'));report['prefill_decode_streak']=streak;waits=re.findall(r'prefill_await_groups=(\d+) prefill_await_events=(\d+) prefill_decode_streak=(\d+)',section);sample['prefill_await_groups']=sum(int(g)for g,e,s in waits);sample['prefill_await_events']=bool(waits)and all(int(e)==1 for g,e,s in waits);assert waits and sample['prefill_await_groups']==len(prefill_batches) and sample['prefill_await_events']==hook and all(int(s)==streak for g,e,s in waits),(sample,waits)
    hostpeak=re.findall(r'shared_vision_host_peak_bytes=(\d+) peak_segments=(\d+)',section);sample['shared_vision_host_peaks']=[int(x)for x,n in hostpeak];assert hostpeak and all((int(x)>0)==(vf>1 or pipeline_vision)for x,n in hostpeak),(sample,hostpeak)
    heads=re.findall(r'standalone_wide_heads=(\d+)',section);assert heads,section[-1000:];sample['standalone_wide_heads']=sum(int(x)for x in heads)
    if physical32 and not single and not greedy_stream:assert sample['standalone_wide_heads']>0,sample
    if single or greedy_stream:assert sample['standalone_wide_heads']==0,sample
    cpu=re.findall(r'cpu_preprocess=(\d+) cpu_preprocess_items=(\d+) cpu_preprocess_ns=(\d+) vision_batch_limit=(\d+)',section)
    sample['cpu_preprocess_items']=sum(int(n) for _,n,_,_ in cpu);sample['cpu_preprocess_ns']=sum(int(ns) for _,_,ns,_ in cpu)
    assert cpu and all((int(enabled)==1)==cpu_preprocess and int(limit)==vision_items for enabled,_,_,limit in cpu),(sample,cpu)
    assert sample['cpu_preprocess_items']==(int(requests) if cpu_preprocess else 0),(sample,cpu)
    batches=re.findall(r'(?:prepared_)?vision_batch_items=(\d+)',section);sample['vision_batch_sizes']=[int(x) for x in batches]
    if vision_batch and vision_items>1:assert batches and max(sample['vision_batch_sizes'])>1 and max(sample['vision_batch_sizes'])<=vision_items,(sample,batches)
    event_gates=re.findall(r'gate_events=(\d+) gate_event_acquisitions=(\d+) gate_event_waits=(\d+)',section)
    sample['gate_event_acquisitions']=sum(int(a) for _,a,_ in event_gates);sample['gate_event_waits']=sum(int(w) for _,_,w in event_gates)
    expected_gate=report['gate_events'] and sample['policy'] in ['engineepoch','enginetailepoch','enginefull','enginecached','engineall','engineworker','engineplan','enginepool','enginephase','enginepoolphase','enginetail','enginetailfair','enginefullfair']
    assert event_gates and all((int(e)==1)==expected_gate for e,_,_ in event_gates),(sample,event_gates)
    if expected_gate:assert sample['gate_event_acquisitions']>0,sample
    auxiliary=re.findall(r'epoch_auxiliary=(\d+) auxiliary_acquisitions=(\d+) auxiliary_host_scratch=(\d+) auxiliary_backend_scratch=(\d+)',section)
    expected_aux=sample['policy']in ['engineepoch','enginetailepoch'];sample['epoch_auxiliary']=expected_aux;sample['auxiliary_acquisitions']=[int(x[1])for x in auxiliary];sample['admission_pressures']=re.findall(r'admission_pressure=(\w+)',section)
    assert auxiliary and all((int(x[0])==1)==expected_aux and int(x[1])==(1 if expected_aux else 0)for x in auxiliary),auxiliary
    assert section.count('auxiliary_release_after_backend=1')==(len(auxiliary)if expected_aux else 0),section
    sample['epoch_page_joins']=[int(x)for x in re.findall(r'cohort_items=(\d+)',section)];assert sum(sample['epoch_page_joins'])==int(requests),sample
    if extended and int(requests)>64:assert max(sample['epoch_page_joins'])>64,sample
    # A physical64 cohort need not visit the older 9..16-row projection tile.
    if round_bf16:assert sample['wide_projection_tiles']==0,sample
    if result['status']=='ok'and not round_bf16:assert (sample['wide_mpp_heads']>0)==(not disable_mpp) and (sample['wide_mpp_projections']>0)==(wide and not disable_mpp and int(c)>8),sample
    core=re.findall(r'shared_core_weight_hits=(\d+) shared_core_weight_misses=(\d+) shared_core_weight_bytes=(\d+)',section);sample['shared_core_weight_hits']=sum(int(x)for x,_,_ in core);sample['shared_core_weight_misses']=sum(int(x)for _,x,_ in core);sample['shared_core_weight_bytes']=sum(int(x)for _,_,x in core);assert core and (sample['shared_core_weight_hits']>0)==shared and all(int(m)<=128 and int(b)<=8*1024*1024 for _,m,b in core),sample
    for scope,enabled in [('decode',round_bf16 and (physical32 or physical64)),('vision',round_bf16 or prefill_bf16)]:
     stats=re.findall(scope+r'_pack_calls=(\d+) '+scope+r'_pack_reuse_hits=(\d+)',section)
     assert stats,(scope,section[-2000:]);sample[scope+'_pack_calls']=sum(int(x)for x,y in stats);sample[scope+'_pack_reuse_hits']=sum(int(y)for x,y in stats)
     off=env['TERMITE_METAL_DISABLE_LIGHTONOCR3_'+scope.upper()+'_PACK_REUSE']=='1'
     if not enabled or off:assert sample[scope+'_pack_calls']==0 and sample[scope+'_pack_reuse_hits']==0,(scope,sample)
     else:assert sample[scope+'_pack_calls']>0 and sample[scope+'_pack_reuse_hits']>0,(scope,sample)
     report['disable_'+scope+'_pack_reuse']=off
    mpp=re.findall(r'mpp_planned_calls=(\d+) mpp_dedicated_calls=(\d+)',section);assert mpp,section[-2000:];sample['mpp_planned_calls']=sum(int(x)for x,y in mpp);sample['mpp_dedicated_calls']=sum(int(y)for x,y in mpp);report['disable_planned_mpp']=planned_disabled
    if planned_disabled:assert sample['mpp_planned_calls']==0,sample
    else:assert sample['mpp_planned_calls']>0,sample
    pack_stats=re.findall(r'prefill_pack_calls=(\d+) prefill_pack_reuse_hits=(\d+)',section);sample['prefill_pack_calls']=sum(int(x)for x,_ in pack_stats);sample['prefill_pack_reuse_hits']=sum(int(x)for _,x in pack_stats);assert pack_stats and sample['prefill_pack_reuse_hits']<=sample['prefill_pack_calls'],sample
    if not (prefill_bf16 or round_bf16) or pack_disabled:assert sample['prefill_pack_calls']==0 and sample['prefill_pack_reuse_hits']==0,sample
    attn_stats=re.findall(r'attention_batch_calls=(\d+) attention_batch_rows=(\d+)',section);sample['attention_batch_calls']=sum(int(x)for x,_ in attn_stats);sample['attention_batch_rows']=sum(int(x)for _,x in attn_stats);assert attn_stats and (sample['attention_batch_calls']>0)==batched,sample
    kernel_stats=re.findall(r'attention_batch_kernel_calls=(\d+)',section);sample['attention_batch_kernel_calls']=sum(int(x)for x in kernel_stats);assert kernel_stats and (sample['attention_batch_kernel_calls']>0)==batched,sample
    stream_stats=re.findall(r'stream_forward_splits=(\d+) stream_first_layers=(\d+)',section);sample['stream_forward_splits']=sum(int(x)for x,_ in stream_stats);assert stream_stats and (sample['stream_forward_splits']>0)==(stream>0),sample
    bursts=re.findall(r'gpu_token_burst_enabled=(\d+) gpu_token_burst_steps=(\d+) gpu_token_burst_topology_mismatches=(\d+)',section)
    assert bursts and all((int(e)==1)==(burst and expected_aux)and int(m)==0 for e,n,m in bursts),bursts
    sample['gpu_token_burst_steps']=sum(int(n)for e,n,m in bursts)
    sample['gpu_token_burst_topology_mismatches']=sum(int(m)for e,n,m in bursts)
    assert (sample['gpu_token_burst_steps']>0)==(burst and expected_aux),bursts
    report['gpu_token_burst']=burst
    extras=re.findall(r'gpu_token_burst_extra_steps=(\d+) gpu_token_burst_extra_rows=(\d+) gpu_token_burst_max_width=(\d+)',section)
    assert extras,section[-2000:]
    sample['gpu_token_burst_extra_steps']=sum(int(n)for n,r,w in extras)
    sample['gpu_token_burst_extra_rows']=sum(int(r)for n,r,w in extras)
    sample['gpu_token_burst_max_width']=max(int(w)for n,r,w in extras)
    assert sample['gpu_token_burst_extra_steps']>=sample['gpu_token_burst_steps']
    assert sample['gpu_token_burst_extra_steps']<=(burst_width-1)*sample['gpu_token_burst_steps']
    if burst and expected_aux:assert sample['gpu_token_burst_max_width']==burst_width,sample
    else:assert sample['gpu_token_burst_extra_steps']==sample['gpu_token_burst_extra_rows']==sample['gpu_token_burst_max_width']==0,sample
    report['gpu_token_burst_width']=burst_width
    frame_stats=re.findall(r'single_frame_steps=(\d+) single_frame_topology_mismatches=(\d+)',section);sample['single_frame_steps']=sum(int(x)for x,_ in frame_stats);sample['single_frame_topology_mismatches']=sum(int(x)for _,x in frame_stats);assert frame_stats and (sample['single_frame_steps']>0)==single and sample['single_frame_topology_mismatches']==0,sample
    recurrent=re.findall(r'device_recurrent_state=(\d+) recurrent_cache_pages=(\d+) host_recurrent_bytes_total=(\d+)',section);assert recurrent,(sample,section[-2000:]);sample['recurrent_cache_pages']=sum(int(b)for a,b,c in recurrent);sample['host_recurrent_bytes_total']=sum(int(c)for a,b,c in recurrent)
    assert all((int(a)==1)==device_state for a,b,c in recurrent) and sample['recurrent_cache_pages']==int(requests),(sample,recurrent)
    assert (sample['host_recurrent_bytes_total']==0)==device_state,(sample,recurrent)
    shared_stats=re.findall(r'shared_decoder_scratch=(\d+) shared_decoder_peak_bytes=(\d+) peak_segments=(\d+)',section);assert shared_stats,section[-2000:]
    enabled=share_decoder and device_state and expected_aux
    assert all((int(a)==1)==enabled and (int(b)>0)==enabled and (int(c)>0)==enabled for a,b,c in shared_stats),shared_stats
    assert section.count('decoder_scratch_release_after_backend=1')==(len(shared_stats)if enabled else 0),shared_stats
    sample['shared_decoder_peak_bytes']=max(int(b)for a,b,c in shared_stats)
    host_permits=re.findall(r'prefill_host_scratch_acquisitions=(\d+) prefill_host_scratch_releases=(\d+) prefill_host_scratch_peak_bytes=(\d+)',section)
    assert host_permits and all(int(a)==int(b) for a,b,c in host_permits),host_permits
    sample['prefill_host_scratch_acquisitions']=sum(int(a)for a,b,c in host_permits)
    sample['prefill_host_scratch_releases']=sum(int(b)for a,b,c in host_permits)
    sample['prefill_host_scratch_peak_bytes']=max(int(c)for a,b,c in host_permits)
    assert sample['prefill_host_scratch_acquisitions']==len(prefill_batches) and (sample['prefill_host_scratch_peak_bytes']>0)==hook,host_permits
    encoder_stats=re.findall(r'vision_encoder_scope_opens=(\d+) prefill_encoder_scope_opens=(\d+)',section);assert encoder_stats,section[-2000:]
    sample['vision_encoder_scope_opens']=sum(int(a)for a,b in encoder_stats);sample['prefill_encoder_scope_opens']=sum(int(b)for a,b in encoder_stats)
    assert all((int(a)>0)==encoder_scopes and (int(b)>0)==encoder_scopes for a,b in encoder_stats),encoder_stats
    scopes=re.findall(r'token_encoder_scope_steps=(\d+)',section);assert scopes,section[-2000:];sample['token_encoder_scope_steps']=sum(map(int,scopes));report['disable_token_encoder']=token_scope_disabled
    assert sample['token_encoder_scope_steps']==(sample['executor_steps']+sample['gpu_token_burst_extra_steps']if (single or greedy_stream) and not token_scope_disabled else 0),sample
    if single:assert sample['single_frame_steps']+sample['gpu_token_burst_steps']==sample['executor_steps'],sample
    assert sample['gpu_greedy_stream_topology_mismatches']==0,sample
    assert sample['gpu_greedy_stream_steps']==(sample['executor_steps'] if greedy_stream else 0),sample
    for name in ['multi_frame_steps','frame_submits']:
     counters=re.findall(r'gpu_greedy_stream_'+name+r'=(\d+)',section)
     assert counters,(name,section[-2000:])
     sample['gpu_greedy_stream_'+name]=sum(map(int,counters))
    if greedy_stream:
     assert not single,sample
     assert sample['gpu_greedy_stream_frame_submits']==sample['gpu_greedy_stream_steps']+sample['stream_forward_splits'],sample
     if chunks:
      splits_per_step=((24 if model=='08'else 32)-1)//chunks
      assert sample['gpu_greedy_stream_multi_frame_steps']>0,sample
      assert sample['stream_forward_splits']==splits_per_step*sample['gpu_greedy_stream_multi_frame_steps'],sample
      assert sample['gpu_greedy_stream_two_frame_steps']==0,sample
     else:
      assert sample['gpu_greedy_stream_two_frame_steps']==sample['stream_forward_splits'] and sample['stream_forward_splits']>0,sample
    else:assert sample['gpu_greedy_stream_frame_submits']==0,sample
    if stream>0:
     assert sample['prepared_blocks']==(18 if model=='08'else 24)*sample['executor_steps'],sample
     assert sample['stream_forward_splits']<=sample['executor_steps']*(((24 if model=='08'else 32)-1)//chunks if chunks else 1),sample
    gates=re.findall(r'phase_priority_yields=(\d+) phase_fair=(\d+)',section);layers=re.findall(r'kv_storage_layers=(\d+) model_layers=(\d+)',section);cohorts=re.findall(r'cohort_items=\d+ decode_steps=(\d+).*?decode_items=(\d+)',section)
    sample['phase_priority_yields']=sum(int(x)for x,_ in gates);sample['phase_fair']=all(int(x)==1 for _,x in gates)if gates else False;sample['kv_storage_layers']=[int(x)for x,_ in layers];sample['average_decode_rows']=sum(int(x)for _,x in cohorts)/max(1,sum(int(x)for x,_ in cohorts))
    assert gates and sample['phase_fair']==(sample['policy']in ['enginetailfair','enginefullfair','engineepoch','enginetailepoch']),(sample,gates)
    assert layers and all(int(x)==int(y)//(4 if compact else 1)for x,y in layers),layers
    assert sample['attention_batch_calls']<=(sum(int(x) for x,_ in cohorts)+sample['gpu_token_burst_extra_steps'])*(6 if model=='08' else 8)*((physical_rows+15)//16),sample
    assert sample['attention_batch_rows']<=(sum(int(x) for _,x in cohorts)+sample['gpu_token_burst_extra_rows'])*(6 if model=='08' else 8),sample
    sample['average_gpu_decode_rows']=(sum(int(x)for _,x in cohorts)+sample['gpu_token_burst_extra_rows'])/max(1,sum(int(x)for x,_ in cohorts)+sample['gpu_token_burst_extra_steps'])
    windows=re.findall(r'registered_window_peak=(\d+) physical_rows_limit=(\d+)',section);assert windows and all(int(y)==physical_rows for _,y in windows),windows
    if c=='32':assert max(int(x)for x,_ in windows)>16,windows
    if int(c)>32 and logical64:assert max(int(x)for x,_ in windows)>32,windows
    if physical64 and int(c)>32:assert max(sample['packed_core_rows_observed'])>32,sample
    for name,enabled in [('vision_late_seal',defer_vision),('prefill_late_seal',defer_prefill)]:
     values=re.findall(r'LIGHTONOCR3 '+name+r'=(\d+)',section)
     assert values and all((int(x)==1)==(enabled and expected_aux)for x in values),(name,values,enabled,expected_aux)
    queued_priority=os.environ.get('ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY','0')=='1';report['queued_phase_priority']=queued_priority
    values=re.findall(r'LIGHTONOCR3 queued_phase_priority=(\d+)',section);assert values and all((int(x)==1)==(queued_priority and expected_aux)for x in values),(values,queued_priority,expected_aux)
    values=re.findall(r'LIGHTONOCR3 resident_vision_budget=(\d+)',section);assert values and all((int(x)==1)==resident_vision for x in values),(values,resident_vision)
    report['resident_vision_budget']=resident_vision
    pipeline=re.findall(r'vision_pipeline_enabled=1 vision_pipeline_submits=(\d+) vision_pipeline_waits=(\d+) vision_pipeline_overlaps=(\d+)',section)
    report['pipeline_vision']=pipeline_vision
    sample['vision_pipeline_images']=len(pipeline)
    sample['vision_pipeline_submits']=sum(int(s)for s,w,o in pipeline)
    sample['vision_pipeline_waits']=sum(int(w)for s,w,o in pipeline)
    sample['vision_pipeline_overlaps']=sum(int(o)for s,w,o in pipeline)
    if pipeline_vision:
     assert len(pipeline)==int(requests),pipeline
     assert all(int(s)==int(w)==(12 if model=='08' else 24)//vf and int(o)==int(s)-1 for s,w,o in pipeline),pipeline
    else:assert not pipeline,pipeline
    workspace_mode=re.findall(r'LIGHTONOCR3 vision_workspace_cache=(\d+)',section)
    assert workspace_mode and all((int(x)==1)==(cache_vision and expected_aux)for x in workspace_mode),(workspace_mode,cache_vision,expected_aux)
    assert sample['vision_workspace_allocations']>0,sample
    if cache_vision and expected_aux:assert sample['vision_workspace_reuses']>0 and sample['vision_workspace_bytes']>0,sample
    else:assert sample['vision_workspace_bytes']==0,sample
    assert 0<=sample['large_vision_pack_reuse_hits']<=sample['large_vision_pack_calls'],sample
    if not large_vision_pack:assert sample['large_vision_pack_calls']==sample['large_vision_pack_reuse_hits']==0,sample
    elif vision_items>=3 and max(sample['vision_batch_sizes'],default=0)>2:assert sample['large_vision_pack_calls']>0 and sample['large_vision_pack_reuse_hits']>0,sample
    assert 'batch_argmax_calls'in sample and 'batch_argmax_rows'in sample,sample
    if batch_argmax and int(c)>1:assert sample['batch_argmax_calls']>0 and 2*sample['batch_argmax_calls']<=sample['batch_argmax_rows']<=64*sample['batch_argmax_calls'],sample
    else:assert sample['batch_argmax_calls']==sample['batch_argmax_rows']==0,sample
    assert 'wide_gate_up_calls' in sample,sample
    assert (sample['full64_gate_up_calls']>0)==(model=='4b' and not round_bf16 and full64_gate_up and max(sample['packed_core_rows_observed'],default=0)==64),sample
    if (model=='4b' and not wide64_gate_up) or wide_gate_disabled or round_bf16:assert sample['wide_gate_up_calls']==0,sample
    elif physical64 and int(c)>32 and wide and not disable_mpp:assert sample['wide_gate_up_calls']>0,sample
    if physical32:assert max(sample['packed_core_rows_observed'])>16,sample
    p=sample['policy'];assert(sample['executor_tail_steps']>0)==(burst or p in ['enginetail','enginetailfair','enginetailepoch']),(p,sample);assert(sample['prepared_blocks']>0)==(p in ['engineplan','engineall','enginecached','enginefull','enginetail','enginetailfair','enginefullfair','engineepoch','enginetailepoch']),(p,sample);assert(sample['executor_steps']>0)==(p in ['engineworker','engineall','enginecached','enginefull','enginetail','enginetailfair','enginefullfair','engineepoch','enginetailepoch']),(p,sample);assert(sample['activation_pool_hits']>0)==(p in ['enginepool','enginecached','enginepoolphase','enginefull','enginetail','enginetailfair','enginefullfair','engineepoch','enginetailepoch']),(p,sample);assert (sample['phase_gate_wait_ns']>0)==(p in ['enginephase','enginepoolphase','enginefull','enginetail','enginetailfair','enginefullfair','engineepoch','enginetailepoch']),(p,sample);assert sample['activation_pool_peak_bytes']<=8*1024*1024,(p,sample)
  (target/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps([{'status':x['status'],'rounds':[{k:s.get(k)for k in ['policy','pages_per_second','process_cpu_ms','prepared_blocks','executor_steps','executor_tail_steps','prefill_pack_calls','prefill_pack_reuse_hits','decode_pack_calls','decode_pack_reuse_hits','vision_pack_calls','vision_pack_reuse_hits','attention_batch_calls','attention_batch_rows','attention_batch_kernel_calls','stream_forward_splits','shared_core_weight_hits','shared_core_weight_misses','shared_core_weight_bytes','wide_projection_tiles','wide_mpp_projections','wide_mpp_heads','standalone_wide_heads','full64_gate_up_calls','single_frame_steps','single_frame_topology_mismatches','epoch_auxiliary','auxiliary_acquisitions','epoch_page_joins','admission_pressures','phase_priority_yields','phase_fair','average_decode_rows','activation_pool_hits','activation_pool_peak_bytes','activation_pool_duplicate_retirements','framed_runtime_totals']}for s in (x.get('policy_rounds') or [])]}for x in report['results']]),flush=True)
 print('DONE',key,res.returncode,flush=True)
 if res.returncode:sys.exit(res.returncode)
