#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
int main(void){@autoreleasepool{id<MTLDevice>d=MTLCreateSystemDefaultDevice();fprintf(stderr,"COUNTERS dispatch=%d stage=%d blit=%d\n",[d supportsCounterSampling:MTLCounterSamplingPointAtDispatchBoundary],[d supportsCounterSampling:MTLCounterSamplingPointAtStageBoundary],[d supportsCounterSampling:MTLCounterSamplingPointAtBlitBoundary]);}return 0;}
