from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
for name in ['preset_only_test','preset_physical32_test','default_gpu_test']:
 s=(v/('engine45_verify_'+name+'.py')).read_text().replace('engine45','engine48')
 s=s.replace("env['TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP']='0'","env['TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP']='0'\nenv['TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP']='0'")
 p=v/('engine48_verify_'+name+'.py');assert not p.exists();p.write_text(s)
for name in ['run_engine45_stream_cases.py','run_engine45_florence_case_verify.py']:
 s=(v/name).read_text().replace('engine45','engine48')
 s=s.replace("v/'run_engine48_budget_policies.py'","v/'run_engine48_budget_policies_verify.py'")
 p=v/name.replace('engine45','engine48');assert not p.exists();p.write_text(s)
s=(v/'run_engine45_remaining_then46_probes.py').read_text();s=s[:s.index('while True:')].replace('engine45','engine48')
s+="""
freeze()
run('engine48-functional-driver',[sys.executable,str(v/'run_engine48_functional.py')])
run('engine48-full64-qualification-driver',[sys.executable,str(v/'run_engine48_full64_cases.py'),'qualification'])
run('engine48-stream-qualification-driver',[sys.executable,str(v/'run_engine48_stream_cases.py'),'qualification'])
run('engine48-florence-b12-qualification-driver',[sys.executable,str(v/'run_engine48_florence_case_verify.py'),'qualification','12','24','1'])
freeze()
compress(['engine48_*qualification*'])
archive(list(Path('/private/tmp').glob('ocr-engine48-functional-*.txt')))
archive(list(Path('/private/tmp').glob('ocr-engine48-verify-*.txt')))
archive(list(Path('/private/tmp').glob('ocr-engine48-4b-*qualification*.txt')))
archive(list(Path('/private/tmp').glob('ocr-engine48-08-*qualification*.txt')))
archive(list(Path('/private/tmp').glob('ocr-engine48-florence*qualification*.txt')))
checks=[out/'engine48_4b_full64_gate_up_qualification_audit.json',out/'engine48_08_gpu_greedy_stream_qualification_audit.json',out/'engine48_florence_batch12_c24_cpu1_r32_qualification_audit.json',out/'engine48_c_qualification_reuse_audit.json']
assert all(json.loads(p.read_text())['status']=='pass'for p in checks)
(out/'engine48_full_qualification_audit.json').write_text(json.dumps(dict(status='pass',checks=[dict(path=str(p.relative_to(out)),sha256=sha(p)) for p in checks],runtime_files_sha256=json.loads((v/'engine48-freeze.json').read_text())),indent=2)+'\\n')
print('ALL ENGINE48 QUALIFICATION PASS',flush=True)
"""
p=v/'run_engine48_qualification.py';assert not p.exists();p.write_text(s)
ns={};a=(v/'archive_engine10_evidence.py').read_text();exec(a[:a.index("archive('qualification'")],ns)
names=['prepare_engine48_qualification.py','run_engine48_qualification.py','run_engine48_stream_cases.py','run_engine48_florence_case_verify.py']+['engine48_verify_'+n+'.py' for n in ['preset_only_test','preset_physical32_test','default_gpu_test']]
ns['archive']('drivers',[v/n for n in names],'drivers_manifest.json')
ns['archive']('qualification',[Path('/private/tmp/ocr-engine48-verify-gpu-build.txt'),Path('/private/tmp/ocr-engine48-verify-gpu-build-driver.txt')],'logs_manifest.json')
