from pathlib import Path
import subprocess,sys,json,hashlib,re
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';out=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(name):
 print('START',name,flush=True)
 with open('/private/tmp/ocr-engine37-'+name+'-driver.txt','w')as stream:result=subprocess.run([sys.executable,str(v/('run_engine37_'+name+'.py'))],stdout=stream,stderr=subprocess.STDOUT)
 print('DONE',name,result.returncode,flush=True);assert result.returncode==0,(name,result.returncode)
for name in ['functional','logical64_units512_qualification','encoder_scopes_rollback','florence_encoder_qualification']:run(name)
rp=out/'engine37_08_encoder_scopes_rollback_c16_r32/report.json';d=json.loads(rp.read_text());r=d['results'][0];sample=r['policy_rounds'][0]
assert r['status']=='ok'and r['serial_reference_parity']and r['cross_runtime_content_parity']and sample['completed']==32
oracle=json.loads((out/'vllm_08_primary_reference11_r0_auto_c32_r128/report.json').read_text())
assert{x['image_index']:x['text']for x in r['references']}=={x['image_index']:x['text']for x in oracle['references']}
assert d['shared_decoder_scratch']and not d['ocr_encoder_scopes']and sample['shared_decoder_peak_bytes']>0 and sample['host_recurrent_bytes_total']==0
assert sample['vision_encoder_scope_opens']==0 and sample['prefill_encoder_scope_opens']==0
build=Path('/private/tmp/ocr-engine37-verify-gpu-build.txt').read_text();assert '218 selected; 217 passed; 1 skipped.'in build
counts=[list(map(int,x))for x in re.findall(r'vision_encoder_scope_opens=(\d+) prefill_encoder_scope_opens=(\d+)',build)];assert counts and all(a>0 and b>0 for a,b in counts)
freeze=json.loads((v/'engine37-freeze.json').read_text())
for f,h in freeze.items():assert sha(root/f)==h,f
audit=dict(selected=218,passed=217,skipped=1,leaked=0,reader_checks=['preset16','physical32','feature_off'],c_qualification_reuse='engine37_c_qualification_reuse.json',vision_prefill_scope_opens=counts,logical64_checks='engine37_logical64_units512_qualification_audit.json',florence_on_off='engine37_florence_encoder_qualification_audit.json',rollback=dict(report=str(rp.relative_to(out)),report_sha256=sha(rp),completed=32,full_fixture_string_identity=True,ocr_encoder_scopes=False,shared_decoder_scratch=True),build_manifest_sha256=sha(out/'engine37_build_manifest.json'),freeze_sha256=sha(v/'engine37-freeze.json'))
(out/'engine37_qualification_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
source=(v/'archive_engine10_evidence.py').read_text();exec(source[:source.index("archive('qualification'")])
archive('qualification',list(Path('/private/tmp').glob('ocr-engine37*.txt')),'logs_manifest.json')
archive('drivers',list(v.glob('*engine37*.py'))+[v/'engine37-freeze.json'],'drivers_manifest.json')
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine37_08_*qualification*','engine37_08_encoder_scopes_rollback*','engine37_florence_encoder_qualification*'],check=True)
print('FINAL FULL QUALIFICATION PASS',flush=True)
