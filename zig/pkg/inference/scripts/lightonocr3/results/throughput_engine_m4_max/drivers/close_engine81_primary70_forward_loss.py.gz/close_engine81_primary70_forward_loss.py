from pathlib import Path
import psutil,json,hashlib,datetime
r=Path.cwd();o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
ps=[p for p in psutil.process_iter(['pid','cmdline'])if p.info['cmdline']and p.info['cmdline'][-1].endswith('/run_engine81_resident_primary70_verify2.py')];assert len(ps)==1;p=ps[0];p.suspend()
try:
 assert not p.children(recursive=True),'Closing reference active: finish original protocol.'
 a=o/'paired70_4b_comparison_audit.json';d=json.loads(a.read_text());assert d['status']=='running'and not d['comparisons']and len(d['reference_candidates'])==3
 control=d['native_control'];s=control['rounds'][1];ref=max(d['reference_candidates'],key=lambda x:x['pages_per_second']);assert s['pages_per_second']<ref['pages_per_second']
 (o/'paired70_4b_before_early_stop_audit.json').write_text(a.read_text())
 nd=json.loads((o/control['report']).read_text());result=nd['results'][0];assert result['status']=='ok'and result['serial_reference_parity']and result['cross_runtime_content_parity']
 d['comparisons'].append(dict(round=0,native_policy_round=1,native_pages_per_second=s['pages_per_second'],reference_pages_per_second=ref['pages_per_second'],native_to_vllm_ratio=s['pages_per_second']/ref['pages_per_second'],reference_concurrency=ref['concurrency'],native_report=control['report'],native_report_sha256=control['report_sha256'],reference_report=ref['report'],reference_report_sha256=ref['report_sha256'],all_128_native_pages_equal_serial=True,full_cross_runtime_fixture_string_identity=True,primary_throughput_eligible=True))
 d.update(status='early_stop_forward_loss',reason='Both fused rounds trail the strongest fresh opening API control, and the complete independent same-model FFN ABBA screen regresses. Retire only own child-free closing-model admission waiter, before any closing server/timing. No repeated win or closing reference result exists.',early_stop_driver_sha256=sha(Path(__file__)),retired_own_child_free_waiter_pid=p.pid,closed_at=datetime.datetime.now(datetime.timezone.utc).isoformat());a.write_text(json.dumps(d,indent=2)+'\n')
 p.terminate()
finally:p.resume()
print('SOURCE81 PRIMARY70 CLOSED FOR FORWARD LOSS',flush=True)
