from pathlib import Path
import subprocess
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text()
s=s.replace('    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_DECODE_PACK_REUSE,','    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_DECODE_PACK_REUSE,\n    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_VISION_PACK_REUSE,',1)
s=s.replace('    "TERMITE_METAL_DISABLE_LIGHTONOCR3_DECODE_PACK_REUSE",','    "TERMITE_METAL_DISABLE_LIGHTONOCR3_DECODE_PACK_REUSE",\n    "TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_PACK_REUSE",',1)
s=s.replace('    uint64_t lighton_decode_pack_reuse_hits;','    uint64_t lighton_decode_pack_reuse_hits;\n    uint64_t lighton_vision_pack_calls;\n    uint64_t lighton_vision_pack_reuse_hits;',1)
anchor='''    const bool reuse_packed = bf16 && !owned && (prefill_pack_scope || decode_pack_scope) &&''';assert anchor in s;s=s.replace(anchor,'''    const bool vision_pack_scope = rows >= 32u && rows <= 4096u &&
        runtime->active_frame_regime == TERMITE_METAL_FRAME_REGIME_NONE &&
        !termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_VISION_PACK_REUSE);
    const bool reuse_packed = bf16 && !owned && (prefill_pack_scope || decode_pack_scope || vision_pack_scope) &&''',1)
anchor='''                runtime->lighton_activation_hits > activation_before;
        }
    }
    if (!owned''';assert anchor in s;s=s.replace(anchor,'''                runtime->lighton_activation_hits > activation_before;
        } else if (reuse_packed && vision_pack_scope) {
            runtime->lighton_vision_pack_calls += 1;
            runtime->lighton_vision_pack_reuse_hits += runtime->reuse_hit_count > reuse_before;
        }
    }
    if (!owned''',1)
s+='''

void termite_metal_decode_runtime_lighton_vision_pack_stats(termite_metal_decode_runtime *runtime, uint64_t *out) {
    if (out == NULL) return;
    out[0] = runtime != NULL ? runtime->lighton_vision_pack_calls : 0;
    out[1] = runtime != NULL ? runtime->lighton_vision_pack_reuse_hits : 0;
}
''';p.write_text(s)
p=Path('zig/pkg/inference/src/backends/metal_runtime.zig');s=p.read_text();anchor='pub extern fn termite_metal_decode_runtime_lighton_decode_pack_stats(runtime: ?*RawMetalDecodeRuntime, out: *[2]u64) void;';assert anchor in s;s=s.replace(anchor,anchor+'\npub extern fn termite_metal_decode_runtime_lighton_vision_pack_stats(runtime: ?*RawMetalDecodeRuntime, out: *[2]u64) void;',1);p.write_text(s)
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text();s=s.replace('    lighton_decode_pack_baseline: [2]u64 = @splat(0),','    lighton_decode_pack_baseline: [2]u64 = @splat(0),\n    lighton_vision_pack_baseline: [2]u64 = @splat(0),',1)
anchor='        metal_runtime_mod.termite_metal_decode_runtime_lighton_decode_pack_stats(raw, &self.lighton_decode_pack_baseline);';assert anchor in s;s=s.replace(anchor,anchor+'\n        metal_runtime_mod.termite_metal_decode_runtime_lighton_vision_pack_stats(raw, &self.lighton_vision_pack_baseline);',1)
a=s.index('    pub fn lightOnDecodePackStats(');b=s.index('    pub fn lightOnBatchAttentionStats(',a);method=s[a:b].replace('lightOnDecodePackStats','lightOnVisionPackStats').replace('lighton_decode_pack','lighton_vision_pack');s=s[:b]+method+s[b:];p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text();anchor='                    std.debug.print("LIGHTONOCR3 decode_pack_calls={d} decode_pack_reuse_hits={d}\\n", .{ decode_pack[0], decode_pack[1] });';assert anchor in s;s=s.replace(anchor,anchor+'''
                    const vision_pack = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnVisionPackStats(&cb) else @as([2]u64, @splat(0));
                    std.debug.print("LIGHTONOCR3 vision_pack_calls={d} vision_pack_reuse_hits={d}\\n", .{ vision_pack[0], vision_pack[1] });''',1);p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text();a=s.index('static int prefill_pack_reuse_check(');b=s.index('static int decode_pack_reuse_check(',a);method=s[a:b]
method=method.replace('prefill_pack_reuse_check','vision_pack_reuse_check').replace('TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PACK_REUSE','TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_PACK_REUSE').replace('TERMITE_METAL_FRAME_REGIME_PREFILL','TERMITE_METAL_FRAME_REGIME_NONE').replace('lighton_prefill_pack','lighton_vision_pack').replace('prefill_pack_reuse rows=', 'vision_pack_reuse rows=')
method=method.replace('modes = benchmark ? 2 : 5','modes = benchmark ? 2 : 6').replace('results[5][6]','results[6][6]')
method=method.replace('      const int old_reuse = r->buffer_reuse_enabled;', '      const bool old_concurrent = r->concurrent_planned_dispatch_enabled;\n      if (mode == 5) r->concurrent_planned_dispatch_enabled = true;\n      const int old_reuse = r->buffer_reuse_enabled;',1)
method=method.replace('      r->buffer_reuse_enabled = old_reuse;', '      r->concurrent_planned_dispatch_enabled = old_concurrent;\n      r->buffer_reuse_enabled = old_reuse;',1)
method=method.replace('  const size_t steps = 6,','  const uint64_t prefill_before = r->lighton_prefill_pack_calls, decode_before = r->lighton_decode_pack_calls;\n  const size_t steps = 6,',1)
method=method.replace('  free(weights);','  if (r->lighton_prefill_pack_calls != prefill_before || r->lighton_decode_pack_calls != decode_before) return 16;\n  free(weights);',1)
method=method.replace('"vision_pack_reuse rows=%zu in=%zu steps=%zu cpu_max_abs=%g "', '"vision_pack_reuse rows=%zu in=%zu out=%zu steps=%zu cpu_max_abs=%g "').replace('      rows, in, steps, cpu_worst,','      rows, in, out, steps, cpu_worst,',1)
method=subprocess.check_output(['/opt/homebrew/opt/llvm/bin/clang-format','--assume-filename=check.m'],input=method,text=True)
b=s.index('\nint main(');s=s[:b]+'\n'+method+s[b:]
anchor='''        if (argc == 2 && (strcmp(argv[1], "--check-prefill-pack-reuse")''';assert anchor in s
block='''if (argc == 2 && (strcmp(argv[1], "--check-vision-pack-reuse") == 0 || strcmp(argv[1], "--benchmark-vision-pack-reuse") == 0)) {
    const bool benchmark = strstr(argv[1], "benchmark") != NULL;
    const size_t shapes[][3] = {{2304,1024,4096},{2304,4096,1024},{128,768,768},{432,768,3072},{2304,768,2304},{2648,1024,4096},{4096,1024,1024},{4097,1024,1024}};
    const size_t count = benchmark ? 2 : sizeof(shapes)/sizeof(shapes[0]);
    for(size_t i=0;i<count;i++) { @autoreleasepool {
        int rc=vision_pack_reuse_check(r,shapes[i][0],shapes[i][1],shapes[i][2],benchmark);
        if(rc){fprintf(stderr,"VISION_PACK_REUSE_FAIL rows=%zu in=%zu out=%zu rc=%d\\n",shapes[i][0],shapes[i][1],shapes[i][2],rc);return 134;}
    }}
    termite_metal_decode_runtime_destroy(r);return 0;
}
'''
block=subprocess.check_output(['/opt/homebrew/opt/llvm/bin/clang-format','--assume-filename=check.m'],input=block,text=True);block=''.join('        '+line if line.strip()else line for line in block.splitlines(keepends=True));s=s.replace(anchor,block+anchor,1);p.write_text(s)
print('29 vision activation-pack reuse prepared; owned/submitted/concurrent/explicit-off controls retained')
