from pathlib import Path
import json,hashlib,re
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';base=v/'lib/python3.12/site-packages/mlx/include';seen={};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def flatten(name):
 if name in seen:return ''
 p=base/name;seen[name]=sha(p)
 text=p.read_text().replace('#pragma once','')
 return re.sub(r'^#include "([^"]+)"',lambda m:flatten(m[1]),text,flags=re.M)
source='#include <metal_stdlib>\nusing namespace metal;\n#define METAL_FUNC inline\n'
source+=flatten('mlx/backend/metal/kernels/complex.h')
source+=flatten('mlx/backend/metal/kernels/steel/gemm/gemm.h')
assert source.count('const constant GEMMParams* params')==1
source=source.replace('const constant GEMMParams* params','const thread GEMMParams* params')
source+='''
struct Engine86Params {uint rows,in_dim,out_dim,pad;};
kernel void engine86_steel(device const bfloat*x[[buffer(0)]],device const bfloat*w[[buffer(1)]],device const float*bias[[buffer(2)]],device float*y[[buffer(3)]],constant Engine86Params&p[[buffer(4)]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]],uint3 tid[[threadgroup_position_in_grid]],uint3 lid[[thread_position_in_threadgroup]]) {
 using K=mlx::steel::GEMMKernel<bfloat,float,32,64,32,2,2,false,true,false,true>;
 threadgroup bfloat As[K::tgp_mem_size_a];threadgroup bfloat Bs[K::tgp_mem_size_b];
 thread mlx::steel::GEMMParams gp={int(p.rows),int(p.out_dim),int(p.in_dim),int(p.in_dim),int(p.in_dim),int(p.out_dim),int((p.out_dim+63)/64),int((p.rows+31)/32),0,0,0,0,int(p.in_dim/32),0};
 K::run(x,w,y,&gp,As,Bs,lane,sg,tid,lid);
}
'''
q=v/'engine86_steel.metal';assert not q.exists();q.write_text(source)
(v/'engine86_MLX_LICENSE').write_bytes((v/'lib/python3.12/site-packages/mlx-0.32.2.dist-info/licenses/LICENSE').read_bytes())
s=(v/'engine83_real_ffn_probe.m').read_text()
s=s.replace('r->lighton_prefill_ffn_pipelines[variant]','r->lightonocr3_mpp_bf16_pipeline')
s=s.replace('r->lightonocr3_mpp_bf16_pipeline=original;\n        tile_', 'r->lightonocr3_mpp_bf16_pipeline=fused?candidate:original;\n        tile_')
s=s.replace('rows,0,fused,&gpu','rows,0,false,&gpu').replace('(fused?b->y1:b->y0).contents','b->y0.contents')
s=s.replace('if(fused)normDiff+=pn[i]!=round_bf16(input[i]+0.f);','if(fabsf(got[i]-gold[layer][i])>2e-4f+2e-5f*fabsf(gold[layer][i]))return 33;')
s=s.replace('if(fused)for(size_t i=0;i<rows*f;i++)packedDiff+=pg[i]!=packed[layer][i];','for(size_t i=0;i<rows*f;i++)packedDiff+=round_bf16(((float*)b->activated.contents+4)[i])!=packed[layer][i];')
s=s.replace('if(diffs||packedDiff||normDiff)return 32;','if(!fused&&(diffs||packedDiff||normDiff))return 32;')
s=s.replace('@"engine82_gate2"','@"engine86_steel"').replace('maxTotalThreadsPerThreadgroup<256','maxTotalThreadsPerThreadgroup<128')
s=s.replace('REAL83','REAL86').replace('PACKED/OUTPUT/CPU/CANARY CHECKS PASS','OUTPUT/CPU/CANARY CHECKS PASS; STEEL FLOAT REDUCTION ORDER CAN DIFFER')
q=v/'engine86_real_ffn_probe.m';assert not q.exists();q.write_text(s)
inputs={str(p.relative_to(r)):sha(p)for p in [v/'engine86_steel.metal',v/'engine86_MLX_LICENSE',v/'engine86_real_ffn_probe.m',v/'engine82_real_ffn_prefix.inc',v/'engine82_probe_checks.m',v/'engine82_probe_kernels.m',v/'engine82_weight_offsets.inc']}
(v/'engine86_steel_probe_preparation.json').write_text(json.dumps(dict(scope='Private MLX Steel BF16/F32 GEMM primitive comparison only. Native operand/accumulator precision preserved; float reduction order may differ. Zero biases validated by all slots. No production changes or full-model performance claim.',mlx_headers_sha256=seen,input_sha256=inputs,production_c_sha256=sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')),indent=2)+'\n')
print('PREPARED',len(source),len(seen),'headers')
