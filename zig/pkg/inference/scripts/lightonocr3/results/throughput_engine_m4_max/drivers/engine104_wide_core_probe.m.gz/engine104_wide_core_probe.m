#define main engine104_unused_main
#include "engine104_wide_core_checks.m"
#undef main
int main(int argc,char **argv){@autoreleasepool{
 if(argc<3||argc>5)return 1;engine104_cap=strtoul(argv[1],NULL,10);size_t pages=strtoul(argv[2],NULL,10);
 if(engine104_cap<16||engine104_cap>64||pages<2||pages>64)return 2;
 setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL","1",1);
 setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY","1",1);
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 3;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 size_t heads=argc>3?strtoul(argv[3],NULL,10):32;bool bench=argc>4?strtoul(argv[4],NULL,10)!=0:true;
 int rc=fused_batch_core_check(r,16,heads,pages,bench);if(!rc)fprintf(stderr,"WIDE104 FULL STATE/OUTPUT BITS/CANARIES PASS pages=%zu cap=%zu\n",pages,engine104_cap);
 termite_metal_decode_runtime_destroy(r);return rc;
}}
