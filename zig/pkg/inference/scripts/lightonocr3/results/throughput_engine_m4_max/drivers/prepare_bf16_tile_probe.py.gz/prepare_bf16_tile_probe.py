from pathlib import Path
v=Path('.venv-lighton-vllm-metal');msl=(v/'wide_mpp_probe.metal').read_text().replace('device float*x[[buffer(0)]]','device bfloat*x[[buffer(0)]]').replace('tensor<device float,dextents<int,2>,tensor_inline>a(x','tensor<device bfloat,dextents<int,2>,tensor_inline>a(x');(v/'bf16_tile_probe.metal').write_text(msl)
s=(v/'wide_mpp_probe.m').read_text().replace('wide_mpp_probe.metal','bf16_tile_probe.metal').replace('WIDE_MPP','BF16_TILE').replace('float*v=(float*)x.contents+4','float*v=(float*)x.contents+4')
s=s.replace('static int dispatch_probe(', 'static id<MTLBuffer> packed_input;\nstatic int dispatch_probe(',1)
a=' [e setComputePipelineState:p];[e setBuffer:x offset:16 atIndex:0];';assert a in s;s=s.replace(a,''' uint32_t count=(uint32_t)(rows*in);[e setComputePipelineState:r->lightonocr3_pack_bf16_pipeline];[e setBuffer:x offset:16 atIndex:0];[e setBuffer:packed_input offset:0 atIndex:1];[e setBytes:&count length:4 atIndex:2];[e dispatchThreads:MTLSizeMake(count,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];[e memoryBarrierWithScope:MTLBarrierScopeBuffers];
 [e setComputePipelineState:p];[e setBuffer:packed_input offset:0 atIndex:0];''',1)
s=s.replace('v[i]=sinf(i*.013f)*.7f','v[i]=expand_bf16(round_bf16(sinf(i*.013f)*.7f))')
s=s.replace('termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);','termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);packed_input=[r->device newBufferWithLength:16*9216*2 options:MTLResourceStorageModePrivate];if(!packed_input)return 9;',1)
s=s.replace('for(size_t rows=9;rows<=16;rows+=rows==9?3:4)','for(size_t rows=8;rows<=16;rows+=8)')
(v/'bf16_tile_probe.m').write_text(s)
