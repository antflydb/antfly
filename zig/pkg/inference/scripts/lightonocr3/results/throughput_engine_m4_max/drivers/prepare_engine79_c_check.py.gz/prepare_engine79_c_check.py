from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=(v/'engine78_packed_ffn_probe.m').read_text()
a=s.index(' }else{\n  id<MTLComputeCommandEncoder>e=');b=s.index('\n if(termite_metal_decode_runtime_end_planned_compute_scope',a)
s=s[:a]+''' }else{
  uint64_t before=r->lighton_prefill_ffn_calls;
  if(!antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,h,f)||
     antfly_metal_lighton_prefill_ffn_apply(r,0,1,2,rows,h,f,(__bridge void*)b->x,16,
        (__bridge void*)b->pnorm,16,(__bridge void*)b->pgated,16,(__bridge void*)b->y1,16))return 3;
  if(r->lighton_prefill_ffn_calls!=before+1)return 3;
 }
'''+s[b:]
preflight='''static int preflight79(termite_metal_decode_runtime*r,Buffers78*b,size_t rows){
 if(antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 70;
 if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_PREFILL))return 71;
 if(!antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 72;
 uint64_t calls=r->lighton_prefill_ffn_calls;
 if(antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,127,2560,9216)||
    antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,1025,2560,9216)||
    antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2561,9216)||
    antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,TERMITE_METAL_LINEAR_SLOT_CAPACITY,rows,2560,9216))return 73;
 size_t variant=rows<=512?1:0;id<MTLComputePipelineState>saved=r->lighton_prefill_ffn_pipelines[variant];r->lighton_prefill_ffn_pipelines[variant]=nil;
 if(antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 74;r->lighton_prefill_ffn_pipelines[variant]=saved;
 if(antfly_metal_lighton_prefill_ffn_apply(r,0,1,2,rows,2560,9216,(__bridge void*)b->x,16,(__bridge void*)b->pnorm,16,(__bridge void*)b->pgated,16,(__bridge void*)b->x,16)!=-3)return 75;
 if(antfly_metal_lighton_prefill_ffn_apply(r,0,1,2,rows,2560,9216,(__bridge void*)b->x,16,(__bridge void*)b->pgated,16,(__bridge void*)b->pgated,16,(__bridge void*)b->y1,16)!=-3)return 76;
 if(antfly_metal_lighton_prefill_ffn_apply(r,0,1,2,rows,2560,9216,(__bridge void*)b->x,16,(__bridge void*)b->pnorm,16,(__bridge void*)b->pgated,16,(__bridge void*)b->pnorm,16)!=-2)return 77;
 if(antfly_metal_lighton_prefill_ffn_apply(r,0,1,2,rows,2560,9216,(__bridge void*)b->x,16,(__bridge void*)b->pnorm,16,(__bridge void*)b->pgated,16,(__bridge void*)b->y1,SIZE_MAX-3)!=-2)return 78;
 if(r->lighton_prefill_ffn_calls!=calls)return 79;
 // Rollback is stable within the snapshot, and takes effect next frame.
 setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_FFN","1",1);
 if(!antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 80;
 if(termite_metal_decode_runtime_cancel_frame(r)||termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_PREFILL))return 81;
 if(antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 82;
 if(termite_metal_decode_runtime_cancel_frame(r))return 83;unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_FFN");
 setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN","0",1);
 if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_PREFILL))return 84;
 if(antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 85;
 if(termite_metal_decode_runtime_cancel_frame(r))return 86;setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN","1",1);
 if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_DECODE))return 87;
 if(antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 88;
 if(termite_metal_decode_runtime_cancel_frame(r))return 89;
 return 0;
}
'''
needle='static int probe78(';assert s.count(needle)==1;s=s.replace(needle,preflight+needle)
needle=' double us,encode;if(frame78(';assert s.count(needle)==1;s=s.replace(needle,' int preflight=preflight79(r,b,rows);if(preflight)return preflight;\n double us,encode;if(frame78(')
a=s.index(' MTLCompileOptions*opt=[MTLCompileOptions new];',s.index('int main(void)'));b=s.index(' const size_t rows[]=',a)
s=s[:a]+s[b:]
s=s.replace('const size_t rows[]={432,554,662};for(size_t variant=0;variant<2;variant++)','const size_t rows[]={128,129,432,554,662,1024};for(size_t variant=0;variant<1;variant++)')
needle='  id<MTLComputePipelineState>pso=termite_metal_make_pipeline';a=s.index(needle,s.index('int main(void)'));b=s.index('\n',a);s=s[:a]+'  id<MTLComputePipelineState>pso=nil;'+s[b:]
s=s.replace('for(size_t i=0;i<3;i++){int rc=probe78','for(size_t i=0;i<6;i++){int rc=probe78')
s=s.replace(' setenv("TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS","1",1);',' setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY","1",1);setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN","1",1);\n setenv("TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS","1",1);')
s=s.replace('PROBE78 FULL PACKED/OUTPUT/CORNER/CANARY CHECKS PASS','ENGINE79 C PREFILL FFN CHECK PASS')
(v/'engine79_c_prefill_ffn_check.m').write_text(s);print('prepared production-C helper conformance, flags/rollback/PSO/bounds/alias + full packed/output tests')
