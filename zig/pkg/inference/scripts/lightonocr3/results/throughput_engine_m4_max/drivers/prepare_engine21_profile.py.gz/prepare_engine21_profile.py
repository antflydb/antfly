from pathlib import Path
p=Path('zig/pkg/inference/src/backends/metal_runtime.zig');s=p.read_text();needle='pub fn qualifiedM4FeatureEnabled(';i=s.index(needle);s=s[:i]+'''/// One opt-in serving preset; individual explicit overrides remain authoritative.
/// Precision and admission limits are not changed by this profile.
pub fn lightOnThroughputProfileEnabled() bool {
    return @import("antfly_platform").env.getenvBool("ANTFLY_LIGHTONOCR3_THROUGHPUT") and qualifiedM4DeviceDefault();
}

pub fn lightOnThroughputFeatureEnabled(comptime name: [*:0]const u8) bool {
    return @import("antfly_platform").env.getenvBoolDefault(name, lightOnThroughputProfileEnabled());
}

'''+s[i:];p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text();flags=['EPOCH_AUX','PREPARED_DECODE','ACTIVATION_POOL','EXECUTOR','BATCH_ATTENTION','READY_COHORTS','STEP_EVENTS','PHASE_PARK','PHASE_FAIR','COMPACT_KV','WIDE_DECODE','EXTENDED_EPOCH']
for flag in flags:s=s.replace('platform.env.getenvBool("ANTFLY_LIGHTONOCR3_'+flag+'")','metal_runtime.lightOnThroughputFeatureEnabled("ANTFLY_LIGHTONOCR3_'+flag+'")')
s=s.replace('platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_CONTENTION_WAIT_US") orelse 100,','platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_CONTENTION_WAIT_US") orelse (if (metal_runtime.lightOnThroughputProfileEnabled()) @as(usize, 1000) else 100),',1)
needle='''            fn auxiliaryAmounts(features: @This())''';replacement='''            fn fromEnvironmentForModel(cfg: gpt_model_mod.Config) @This() {
                var features = fromEnvironment();
                features.shared_core_weights = features.epoch_auxiliary and platform.env.getenvBoolDefault("ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS", metal_runtime.lightOnThroughputProfileEnabled() and cfg.hidden_size == 2560);
                return features;
            }
            fn auxiliaryAmounts(features: @This())''';assert needle in s;s=s.replace(needle,replacement,1)
s=s.replace('const features = LightOnStreamContext.ExecutionFeatures.fromEnvironment();','const features = LightOnStreamContext.ExecutionFeatures.fromEnvironmentForModel(cfg);',1)
s=s.replace('orelse (if (metal_runtime.qualifiedM4DeviceDefault()) @as(usize, 8) else 4), 1), ceiling);','orelse (if (metal_runtime.lightOnThroughputProfileEnabled()) @as(usize, 16) else if (metal_runtime.qualifiedM4DeviceDefault()) @as(usize, 8) else 4), 1), ceiling);',1)
s=s.replace('platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_BATCH_WINDOW") orelse 8,','platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_BATCH_WINDOW") orelse (if (metal_runtime.lightOnThroughputProfileEnabled()) @as(usize, 16) else 8),',1)
p.write_text(s)
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text().replace('platform.env.getenvBool("TERMITE_METAL_ENABLE_LIGHTONOCR3_WEIGHT_HANDLES");','metal_runtime_mod.lightOnThroughputFeatureEnabled("TERMITE_METAL_ENABLE_LIGHTONOCR3_WEIGHT_HANDLES");',1);p.write_text(s)
p=Path('zig/pkg/inference/src/pipelines/generation.zig');s=p.read_text().replace('platform.env.getenvBool("ANTFLY_LIGHTONOCR3_DECODE_WORKSPACE") and blk:', 'platform.env.getenvBoolDefault("ANTFLY_LIGHTONOCR3_DECODE_WORKSPACE", self.prepared_lighton_decode) and blk:',1);p.write_text(s)
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text();needle='static BOOL termite_metal_generated_quant_disabled(void) {';i=s.index(needle);s=s[:i]+'''// The serving preset changes execution policy only. Explicit per-feature
// values (including false) always win, and other hardware keeps its defaults.
static BOOL termite_metal_lightonocr3_profile_feature_enabled(const char *name) {
    const char *value = getenv(name);
    if (value != NULL) return termite_metal_env_flag_enabled(value);
    return termite_metal_env_flag_enabled(getenv("ANTFLY_LIGHTONOCR3_THROUGHPUT")) &&
        termite_metal_qualified_m4_device_default() != 0;
}

'''+s[i:]
for name in ['TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY','TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_COALESCING','TERMITE_METAL_ENABLE_LIGHTONOCR3_WEIGHT_RESIDENCY']:
 s=s.replace('termite_metal_env_flag_enabled(getenv("'+name+'"))', 'termite_metal_lightonocr3_profile_feature_enabled("'+name+'")')
p.write_text(s)
