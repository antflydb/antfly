from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

v = Path('.venv-lighton-vllm-metal')
out = Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
records = []
for model in ['08', '4b']:
    for kind, c, requests, hook, shared in [('baseline', 64, 64, False, True), ('batch2_shared', 56, 64, True, True), ('batch2_sharing_off', 16, 32, True, False)]:
        blocks = 1 if hook else 2 if model == '4b' else 4
        label = f'{kind}_physical64_c{c}_r{requests}_qualification'
        dest = out / f'engine40_{model}_{label}'
        assert not (dest / 'report.json').exists()
        env = os.environ.copy()
        env.update(OCR_REFERENCE_LABEL='_primary_reference20_r0_auto_c64_r128', OCR_PHYSICAL32='0',
                   OCR_PHYSICAL64='1', OCR_CONCURRENCY=str(c), OCR_REQUESTS=str(requests), OCR_WIDE='1',
                   OCR_SCRATCH_GIB='10' if model == '4b' else '8', OCR_BACKEND_GIB='17' if model == '4b' else '16',
                   OCR_KV_GIB='4', OCR_CPU_PREPROCESS='1', OCR_PREFILL_DECODE_STREAK='0',
                   OCR_POLICIES='engineepoch', OCR_SHARED_CORE='1' if model == '4b' else '0',
                   OCR_BF16_PREFILL='1' if model == '4b' else '0', OCR_BF16='0',
                   OCR_VISION_BATCH=str(int(hook)), OCR_VISION_BATCH_ITEMS='2', OCR_VISION_WAIT_US='20000',
                   OCR_PREFILL_BATCH=str(int(hook)), OCR_PREFILL_BATCH_ITEMS='2', OCR_PREFILL_WAIT_US='100000',
                   OCR_VISION_FRAME_BLOCKS=str(blocks), OCR_SINGLE_FRAME='1', OCR_STREAM_FIRST='0',
                   OCR_LOGICAL64='1', OCR_SHARED_DECODER_SCRATCH=str(int(shared)), OCR_DEVICE_RECURRENT_STATE='1',
                   OCR_ENCODER_SCOPES='1', OCR_ADMISSION_UNITS='512',
                   OCR_DISABLE_64_ROW_TILE='0' if model == '4b' else '1')
        print('START', model, kind, flush=True)
        with Path(f'/private/tmp/ocr-engine40-{model}-{kind}-qualification-driver.txt').open('w') as log:
            result = subprocess.run([sys.executable, str(v / 'run_engine40_budget_policies.py'), model + ':' + label], env=env, stdout=log, stderr=subprocess.STDOUT)
        assert result.returncode == 0, (model, kind, result.returncode)
        p = dest / 'report.json'
        d = json.loads(p.read_text())
        r = d['results'][0]
        x = r['policy_rounds'][0]
        assert r['status'] == 'ok' and r['serial_reference_parity'] and r['cross_runtime_content_parity']
        assert x['completed'] == requests and not x['admission_pressures']
        assert x['host_recurrent_bytes_total'] == 0 and x['single_frame_topology_mismatches'] == 0
        if c > 32:
            assert max(x['packed_core_rows_observed']) > 32
        if hook:
            assert max(t['items'] for t in x['prefill_batches']) == 2
            assert max(x['vision_batch_sizes']) == 2
            assert x['prefill_host_scratch_acquisitions'] == x['prefill_host_scratch_releases'] > 0
        oracle = json.loads((out / f'vllm_{model}_primary_reference20_r0_auto_c64_r128/report.json').read_text())
        assert {t['image_index']: t['text'] for t in r['references']} == {t['image_index']: t['text'] for t in oracle['references']}
        records.append(dict(model=model, kind=kind, completed=requests, full_fixture_string_identity=True,
                            all_native_pages_equal_serial_reference=True, shared_decoder_scratch=shared,
                            shared_decoder_peak_bytes=x['shared_decoder_peak_bytes'], prefill_batches=x['prefill_batches'],
                            vision_batch_sizes=x['vision_batch_sizes'],
                            prefill_host_scratch_acquisitions=x['prefill_host_scratch_acquisitions'],
                            prefill_host_scratch_releases=x['prefill_host_scratch_releases'],
                            report=str(p.relative_to(out)), report_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
        (out / 'engine40_batch_qualification_audit.json').write_text(json.dumps(dict(status='running', checks=records), indent=2) + '\n')
        print('DONE', model, kind, flush=True)
(out / 'engine40_batch_qualification_audit.json').write_text(json.dumps(dict(status='pass', checks=records), indent=2) + '\n')
