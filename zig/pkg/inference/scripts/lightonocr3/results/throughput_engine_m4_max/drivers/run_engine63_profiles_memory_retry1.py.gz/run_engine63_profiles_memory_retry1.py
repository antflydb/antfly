from pathlib import Path
import subprocess,sys,os,json,collections,hashlib,time,ctypes
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');audit=o/'engine63_profiles_audit.json';assert not audit.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
lib=ctypes.CDLL(None);level_fn=lib.memorystatus_get_level;level_fn.argtypes=[ctypes.POINTER(ctypes.c_int)];level_fn.restype=ctypes.c_int
old=o/'engine63_4b_rolling_chunks0_trial0_c64_p4_vf1_r64_queued_priority_v4_sv1_sp0_q0/report.json'
records=[];attempts=[dict(report=str(old.relative_to(o)),report_sha256=sha(old),eligible=False,reason='live_load_admission_before_inference')]
def save(status='running'):
 audit.write_text(json.dumps(dict(status=status,candidates=records,attempts=attempts,scope='Same runtime and original caps; wait for >=47% macOS availability before load retries. Original load failure preserved; no OS reserve or cap changed.'),indent=2)+'\n')
def run(cfg):
 c,p,vis,vf,sv,sp,q=cfg;attempt=0
 while True:
  level=ctypes.c_int();assert level_fn(ctypes.byref(level))==0
  if level.value<47:
   print('WAIT LIVE CAPACITY',level.value,flush=True);time.sleep(10);continue
  attempt+=1;tag=f'resident_retry1_v{vis}_sv{sv}_sp{sp}_q{q}_a{attempt}'
  env=os.environ.copy();env.update(OCR_CASE_CONCURRENCY=str(c),OCR_CASE_PREFILL_ITEMS=str(p),OCR_CASE_VISION_FRAME_BLOCKS=str(vf),OCR_CASE_VISION_BATCH_ITEMS=str(vis),OCR_CASE_TAG=tag,OCR_BATCH_ARGMAX='1',OCR_CACHE_VISION_WORKSPACE='1',OCR_LARGE_VISION_PACK_REUSE='1',OCR_DEFER_VISION_SEAL=str(sv),OCR_DEFER_PREFILL_SEAL=str(sp),ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY=str(q),OCR_TIMEOUT='240',OCR_RESIDENT_VISION_BUDGET='1',OCR_PREFILL_WAIT_US='100000')
  print('START',cfg,'availability',level.value,'attempt',attempt,flush=True)
  r=subprocess.run([sys.executable,str(v/'run_engine63_prefill8_profile.py'),'4b','0'],env=env)
  print('DONE',cfg,r.returncode,flush=True)
  label=f'engine63_4b_rolling_chunks0_trial0_c{c}_p{p}_vf{vf}_r64_{tag}';report=o/label/'report.json';assert report.exists(),label
  d=json.loads(report.read_text());rs=d['results'][0];text=(report.parent/f'lighton4b-batch-c{c}.txt').read_text()
  if r.returncode:
   if 'live-memory admission denied'in text and 'OCR_POLICY round=0'not in text:
    attempts.append(dict(settings=cfg,report=str(report.relative_to(o)),report_sha256=sha(report),eligible=False,reason='live_load_admission_before_inference',availability_percent=level.value));save();time.sleep(10);continue
   if 'admission_pressure='in text:
    records.append(dict(settings=cfg,eligible=False,reason='admission_pressure',report=str(report.relative_to(o)),report_sha256=sha(report)));save();return False
   raise RuntimeError((label,'unexpected runtime/check failure'))
  s=rs['policy_rounds'][0]
  assert rs['status']=='ok'and rs['serial_reference_parity']and rs['cross_runtime_content_parity']and s['completed']==64 and not s['admission_pressures']and d['resident_vision_budget']
  assert all(x['items']*x['tokens_per_item']<=4096 for x in s['prefill_batches'])
  records.append(dict(settings=cfg,prefill_wait_us=100000,eligible=True,resident_vision_budget=True,pages_per_second=s['pages_per_second'],process_cpu_ms=s['process_cpu_ms'],average_decode_rows=s['average_decode_rows'],prefill_sizes=dict(collections.Counter(x['items']for x in s['prefill_batches'])),vision_sizes=dict(collections.Counter(s['vision_batch_sizes'])),report=str(report.relative_to(o)),report_sha256=sha(report)));save();return True
save()
wide=64 if run([64,4,4,1,1,0,0]) else 60
if wide==60:run([60,4,4,1,1,0,0])
run([56,4,4,2,1,0,0])
run([wide,4,4,1,1,1,1])
save('pass');print('ALL RESIDENT PROFILES COMPLETE',flush=True)
