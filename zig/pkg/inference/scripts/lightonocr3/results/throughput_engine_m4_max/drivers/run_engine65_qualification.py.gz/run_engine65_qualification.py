from pathlib import Path
import subprocess,sys,json,hashlib,re
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(name,script,*args):
 p=Path('/private/tmp/ocr-engine65-'+name+'-driver.txt');assert not p.exists(),p
 print('START',name,flush=True)
 with p.open('w')as log:r=subprocess.run([sys.executable,str(v/script),*args],stdout=log,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True);assert r.returncode==0,(name,r.returncode)
def shaders(s):
 lines=s.splitlines(keepends=True);result={}
 for i,line in enumerate(lines):
  if line.startswith('static NSString *')and line.rstrip().endswith('(void) {'):
   name=line.split('*',1)[1].split('(',1)[0]
   j=next(j for j in range(i+1,len(lines))if lines[j].strip()=='}')
   result[name]=hashlib.sha256(''.join(lines[i:j+1]).encode()).hexdigest()
 return result
old=v/'engine56_final_metal_kernels.m';assert old.exists()
a=shaders(old.read_text());b=shaders(Path('zig/pkg/inference/src/backends/metal_kernels.m').read_text());assert a and a==b
(o/'engine65_unchanged_shader_source_audit.json').write_text(json.dumps(dict(status='pass',source_functions=a),indent=2)+'\n')
run('c-build','build_engine65_conformance.py')
inputs=[Path('zig/pkg/inference/src/backends')/x for x in ['metal_kernels.m','metal_buffer_observation.h','metal_mtp_head.h','metal_mtp_head_impl.h']]+[Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m')]
binary=v/'engine65_conformance';m=dict(binary=str(binary),binary_sha256=sha(binary),input_sha256={str(p):sha(p)for p in inputs},compiler_driver_sha256=sha(v/'build_engine65_conformance.py'),qualification_driver_sha256=sha(v/'run_engine65_c_qualification.py'));(o/'engine65_c_build_manifest.json').write_text(json.dumps(m,indent=2)+'\n')
run('c-qualification','run_engine65_c_qualification.py')
d=json.loads((o/'engine65_c_qualification_audit.json').read_text());assert d['status']=='pass'and len(d['checks'])==19
d.update(build_manifest_sha256=sha(o/'engine65_c_build_manifest.json'),binary_sha256=m['binary_sha256'],input_sha256=m['input_sha256']);(o/'engine65_c_qualification_audit.json').write_text(json.dumps(d,indent=2)+'\n')
run('verify-gpu-build','run_engine65_verify2_gpu_build.py')
run('finalize','finalize_engine_build.py','engine65','/private/tmp/ocr-engine65-verify2-gpu-build.txt')
run('metal-disabled','run_engine65_metal_disabled.py')
print('ENGINE65 QUALIFICATION DONE',flush=True)
