#define main engine103_unused_main
#include "engine103_wide_core_checks.m"
#undef main
int main(int argc,char **argv){@autoreleasepool{
 if(argc!=3)return 1;engine103_cap=strtoul(argv[1],NULL,10);size_t pages=strtoul(argv[2],NULL,10);
 if(engine103_cap<16||engine103_cap>64||pages<2||pages>64)return 2;
 setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL","1",1);
 setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY","1",1);
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 3;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 int rc=fused_batch_core_check(r,16,32,pages,true);if(!rc)fprintf(stderr,"WIDE103 FULL STATE/OUTPUT BITS/CANARIES PASS pages=%zu cap=%zu\n",pages,engine103_cap);
 termite_metal_decode_runtime_destroy(r);return rc;
}}
