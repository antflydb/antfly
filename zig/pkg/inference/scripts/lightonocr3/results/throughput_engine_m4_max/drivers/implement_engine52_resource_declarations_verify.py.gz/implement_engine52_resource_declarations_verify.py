from pathlib import Path
import hashlib,json
edits={}
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
for p,h in json.loads((v/'engine48-freeze.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text()
needle='typedef struct termite_metal_decode_runtime {';assert needle in s
s=s.replace(needle,'typedef struct { uintptr_t key; uint8_t usage; } termite_metal_lighton_resource_entry;\n\n'+needle,1)
needle='    uint64_t lightonocr3_recurrent_parallel_dispatches;';assert s.count(needle)==1
s=s.replace(needle,needle+'''
    // Fixed 8 KiB host metadata; no GPU allocations or new resource ownership.
    termite_metal_lighton_resource_entry lighton_resource_cache[512];
    const void *lighton_resource_cache_encoder;
    uint64_t lighton_resource_cache_frame;
    uint64_t lighton_resource_cache_generation;
    size_t lighton_resource_cache_count;
    uint64_t lighton_resource_declaration_stats[4];
''',1)
needle='// 0 declines before encoding, 1 encoded, negative values report a frame error.\nstatic int termite_metal_lightonocr3_encode_recurrent_parallel'
assert s.count(needle)==1
s=s.replace(needle,(v/'engine52_recurrent_resource_helper.inc').read_text()+'\n'+needle)
needle='''    [encoder useResources:resources count:rows * 15 usage:MTLResourceUsageRead];
    [encoder useResources:writes count:write_count usage:MTLResourceUsageWrite];'''
assert s.count(needle)==1
s=s.replace(needle,'''    const size_t requested_declarations = rows * 15 + write_count;
    size_t emitted_declarations = requested_declarations;
    if (termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_RESOURCE_DEDUP"))) {
        emitted_declarations = termite_metal_lighton_declare_recurrent_resources(
            runtime, cb, encoder, resources, rows * 15, writes, write_count);
    } else {
        [encoder useResources:resources count:rows * 15 usage:MTLResourceUsageRead];
        [encoder useResources:writes count:write_count usage:MTLResourceUsageWrite];
    }
    runtime->lighton_resource_declaration_stats[0] += 1u;
    runtime->lighton_resource_declaration_stats[1] += requested_declarations;
    runtime->lighton_resource_declaration_stats[2] += emitted_declarations;
    runtime->lighton_resource_declaration_stats[3] += requested_declarations - emitted_declarations;''',1)
needle='void termite_metal_decode_runtime_set_lightonocr3_projections('
index=s.index(needle)
s=s[:index]+'''void termite_metal_decode_runtime_lighton_resource_declaration_stats(
    termite_metal_decode_runtime *runtime, uint64_t out[4]) {
    if (out == NULL) return;
    if (runtime == NULL) { memset(out, 0, 4 * sizeof(*out)); return; }
    memcpy(out, runtime->lighton_resource_declaration_stats, 4 * sizeof(*out));
}

'''+s[index:]
edits[p]=s
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text()
idx=s.index('int main(int argc, const char **argv)')
s=s[:idx]+(v/'engine52_recurrent_resource_checks.inc').read_text()+'\n'+s[idx:]
needle='''        const bool wide_benchmark = argc == 2 && strcmp(argv[1], "--benchmark-wide-gate-up") == 0;'''
assert needle in s
s=s.replace(needle,'''        if (argc == 2 && strcmp(argv[1], "--check-recurrent-resource-dedup") == 0) {
            if (recurrent_resource_cache_check()) return 180;
            setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_RESOURCE_DEDUP", "1", 1);
            const size_t counts[] = {1, 2, 7, 16};
            for (size_t h = 16; h <= 32; h += 16)
                for (size_t i = 0; i < 4; ++i)
                    if (fused_batch_core_check(r, 16, h, counts[i], false)) return 181;
            if (!r->lighton_resource_declaration_stats[0] ||
                !r->lighton_resource_declaration_stats[3] ||
                r->lighton_resource_declaration_stats[1] - r->lighton_resource_declaration_stats[2] !=
                    r->lighton_resource_declaration_stats[3]) return 182;
            fprintf(stderr, "recurrent_resource_dedup calls=%llu requested=%llu emitted=%llu skipped=%llu\\n",
                r->lighton_resource_declaration_stats[0], r->lighton_resource_declaration_stats[1],
                r->lighton_resource_declaration_stats[2], r->lighton_resource_declaration_stats[3]);
            termite_metal_decode_runtime_destroy(r);
            return 0;
        }
'''+needle)
# Preserve literal newline escape in the C format string.
s=s.replace('skipped=%llu\\n",','skipped=%llu\\\\n",')if False else s
edits[p]=s
p=Path('zig/pkg/inference/src/backends/metal_runtime.zig');s=p.read_text();needle='pub extern fn termite_metal_decode_runtime_lighton_full64_gate_up_calls';idx=s.index(needle)
s=s[:idx]+'pub extern fn termite_metal_decode_runtime_lighton_resource_declaration_stats(runtime: ?*RawMetalDecodeRuntime, out: *[4]u64) void;\n'+s[idx:];edits[p]=s
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text()
needle='    lighton_full64_gate_up_start: u64 = 0,';assert s.count(needle)==1
s=s.replace(needle,needle+'\n    lighton_resource_declaration_start: [4]u64 = @splat(0),')
needle='        self.lighton_full64_gate_up_start = metal_runtime_mod.termite_metal_decode_runtime_lighton_full64_gate_up_calls(raw);'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n        metal_runtime_mod.termite_metal_decode_runtime_lighton_resource_declaration_stats(raw, &self.lighton_resource_declaration_start);')
needle='    pub fn lightOnFull64GateUpCalls';idx=s.index(needle)
s=s[:idx]+'''    pub fn lightOnResourceDeclarationStats(cb: *const ops.ComputeBackend) [4]u64 {
        var values: [4]u64 = @splat(0);
        if (cb.kind() != .metal) return values;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        metal_runtime_mod.termite_metal_decode_runtime_lighton_resource_declaration_stats(self.provider_impl.raw_decode_runtime, &values);
        for (&values, self.lighton_resource_declaration_start) |*value, start| value.* -|= start;
        return values;
    }

'''+s[idx:];edits[p]=s
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text()
needle='''                    std.debug.print("LIGHTONOCR3 full64_gate_up_calls={d}\\n", .{full64_gate_up});'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''
                    const declarations = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnResourceDeclarationStats(&cb) else [_]u64{0} ** 4;
                    std.debug.print("LIGHTONOCR3 recurrent_resource_calls={d} recurrent_resource_requested={d} recurrent_resource_emitted={d} recurrent_resource_skipped={d}\\n", .{ declarations[0], declarations[1], declarations[2], declarations[3] });''')
edits[p]=s
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text()
needle='    parser.add_argument("--full64-gate-up", action="store_true")';assert needle in s
s=s.replace(needle,needle+'\n    parser.add_argument("--dedup-recurrent-resources", action="store_true")')
needle='    env["TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP"] = ('
assert needle in s
s=s.replace(needle, '    env["TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_RESOURCE_DEDUP"] = "1" if args.dedup_recurrent_resources else "0"\n'+needle)
edits[p]=s
for p,s in edits.items():p.write_text(s)
print('Applied source52 proposal; format and validate before freeze/build.')
