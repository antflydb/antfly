from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,psutil
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while 'ENGINE74 BURST64 DONE' not in Path('/private/tmp/ocr-engine74-burst64-parent.txt').read_text():time.sleep(5)
p=json.loads((v/'engine76_preparation.json').read_text());assert sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')==p['production_c_sha256'] and all(sha(r/f)==h for f,h in p['inputs'].items())
binary=v/'engine76_fma_probe';assert not binary.exists();audit=o/'engine76_fma_probe_audit.json';assert not audit.exists()
d=dict(status='running',primary_throughput_eligible=False,scope=p['scope'],preparation_sha256=sha(v/'engine76_preparation.json'),driver_sha256=sha(Path(__file__)),checks=[])
def save():audit.write_text(json.dumps(d,indent=2)+'\n')
save();cmd=['clang','-O3','-fobjc-arc','-I','zig/pkg/inference/src/backends',str(v/'engine76_fma_probe.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(binary)]
with Path('/private/tmp/ocr-engine76-build.txt').open('w')as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
d.update(build_exit_code=result.returncode,build_command=cmd,build_log_sha256=sha('/private/tmp/ocr-engine76-build.txt'));save();assert result.returncode==0
d['binary_sha256']=sha(binary);save()
for candidate in [1,2]:
 available=psutil.virtual_memory().available;need=512*1024**2;reserve=6*1024**3
 assert available>=need+reserve,(available,need,reserve)
 log=Path(f'/private/tmp/ocr-engine76-fma{candidate}.txt');print('START FMA',candidate,flush=True)
 with log.open('w')as f:result=subprocess.run([str(binary),str(candidate)],stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,ANTFLY_LIGHTONOCR3_THROUGHPUT='0'),timeout=900)
 text=log.read_text();records=[json.loads(x)for x in text.splitlines()if x.startswith('{"candidate":')]
 d['checks'].append(dict(candidate=candidate,exit_code=result.returncode,records=records,log=str(log),log_sha256=sha(log),available_bytes=available,working_estimate_bytes=need,os_reserve_bytes=reserve));save();assert result.returncode==0 and len(records)==1200 and f'FMA PROBE PASS candidate={candidate}' in text
 print('DONE FMA',candidate,len(records),flush=True)
d['status']='pass';save();print('ENGINE76 FMA PROBE DONE',flush=True)
