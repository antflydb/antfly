from pathlib import Path
import subprocess,sys
s=Path('.venv-lighton-vllm-metal/engine5_gpu_tests.py').read_text();exec(s[:s.index('cmd=[str(')])
env['ANTFLY_TEST_LIGHTONOCR3_MODEL_DIR']='/Users/ajroetker/go/src/github.com/antflydb/antfly/.worktrees/lightonocr3-08b/.venv-lighton-vllm-metal/ocr-models/lighton08'
env['ANTFLY_LIGHTONOCR3_PACKED_SHARED_FRAME']='1'
env['TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN']='1'
env['ANTFLY_LIGHTONOCR3_PACKED_MIXED']='0'
env['ANTFLY_LIGHTONOCR3_PREFILL_QUERY_CHUNK_ROWS']='0'
env['ANTFLY_LIGHTONOCR3_PREFILL_ACTIVATION_POOL']='1'
env['TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE_RECURRENT']='0'
env['ANTFLY_LIGHTONOCR3_RESIDENT_VISION_BUDGET']='1'
env.pop('TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP',None)
env['ANTFLY_LIGHTONOCR3_GPU_GREEDY_STREAM']='0'
env['ANTFLY_LIGHTONOCR3_GPU_TOKEN_BURST']='1'
env['ANTFLY_LIGHTONOCR3_GPU_TOKEN_BURST_WIDTH']='8'
env['TERMITE_METAL_ENABLE_PIPELINED_DECODE_FRAME']='1'
env['TERMITE_METAL_ENABLE_LIGHTONOCR3_BATCH_ARGMAX']='1'
env['ANTFLY_LIGHTONOCR3_KEEP_VISION_WORKSPACE']='1'
env['TERMITE_METAL_ENABLE_LIGHTONOCR3_LARGE_VISION_PACK_REUSE']='1'
env['ANTFLY_LIGHTONOCR3_VISION_LATE_SEAL']='1'
env['ANTFLY_LIGHTONOCR3_PREFILL_LATE_SEAL']='1'
env['ANTFLY_LIGHTONOCR3_STREAM_CHUNKS']='1'
env['TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP']='0'
env['ANTFLY_FLORENCE_CPU_PREPROCESS']='0'
env['ANTFLY_TEST_OCR_RASTER_PARITY']='0'
env['TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP']='0'
env['ANTFLY_INFERENCE_READ_BATCH_SIZE']='16'
root=Path.cwd();env['ANTFLY_LIGHTONOCR3_PHYSICAL32']='0';env['ANTFLY_LIGHTONOCR3_PHYSICAL64']='1';env['ANTFLY_LIGHTONOCR3_WIDE_DECODE']='1';env['ANTFLY_LIGHTONOCR3_BATCH_ROWS']='64';env['ANTFLY_LIGHTONOCR3_BATCH_WINDOW']='64'
env['ANTFLY_LIGHTONOCR3_LOGICAL64']='1'
env['ANTFLY_OCR_ENCODER_SCOPES']='1'
env['ANTFLY_LIGHTONOCR3_DEVICE_RECURRENT_STATE']='1'
env['ANTFLY_LIGHTONOCR3_SHARED_DECODER_SCRATCH']='1'
env['ANTFLY_LIGHTONOCR3_PREFILL_BATCH']='0';env['ANTFLY_LIGHTONOCR3_PREFILL_BATCH_ITEMS']='1';env['ANTFLY_LIGHTONOCR3_VISION_BATCH_ITEMS']='1';env['ANTFLY_LIGHTONOCR3_CPU_PREPROCESS']='1'
env['ANTFLY_LIGHTONOCR3_EPOCH_AUX']='1'
env['ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS']='1'
env['ANTFLY_LIGHTONOCR3_BATCH_ATTENTION']='1'
env['ANTFLY_LIGHTONOCR3_EXTENDED_EPOCH']='1'
env['ANTFLY_LIGHTONOCR3_CONTENTION_WAIT_US']='1000'
env['TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS']='1'
env['ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS']='0'
env['ANTFLY_LIGHTONOCR3_SINGLE_FRAME']='1'
env.pop('TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS',None)
env['ANTFLY_LIGHTONOCR3_PREFILL_DECODE_STREAK']='0'
env['ANTFLY_LIGHTONOCR3_PREFILL_WAIT_US']='1000000'
env['ANTFLY_LIGHTONOCR3_VISION_FRAME_BLOCKS']='1'
env['ANTFLY_LIGHTONOCR3_PIPELINE_VISION']='1'
env['ANTFLY_LIGHTONOCR3_PREFILL_STREAM_LAYERS']='8'
env['ANTFLY_LIGHTONOCR3_PHASE_FAIR']='1'
env['ANTFLY_LIGHTONOCR3_PHASE_PARK']='1'
env['ANTFLY_LIGHTONOCR3_EXECUTOR_TAIL']='1'
env['ANTFLY_LIGHTONOCR3_COMPACT_KV']='1'
env['ZIG_GLOBAL_CACHE_DIR']=str(root/'zig/.zig-cache/global')
filters=['claimStep','mixed','dispatchStepLogits','runtime snapshots', 'runtime identifiers', 'runtime snapshot', 'exact Whisper', 'instance identifiers', 'runtime unload', 'runtime model instances', 'composite decoder selection', 'startup split Whisper']+['microbatch broker','LightOnOCR3','Qwen3-VL','batch decode context','execution lane','execution gate','projector residency','executor batch','coalesc','Florence','shared native provider','dynamic linear slot','decode GQA split','argmax','video buffer survives producer destruction','video Metal gather fences','native reader batching']
env.pop('ANTFLY_TEST_LIGHTONOCR3_MODEL_DIR',None) # Full checkpoint replay deferred to Wolfspider; no loader reserve relaxation.
command=['/Users/ajroetker/bin/zig-0.17.0/zig','build','inference-test','-Doptimize=ReleaseFast','-Dstrip=true','--summary','all',*[f'-Dtest-filter={x}'for x in filters]]
with open('/private/tmp/ocr-engine181-noncheckpoint-gpu-build.txt','w')as out:r=subprocess.run(command,cwd=root/'zig',env=env,stdout=out,stderr=subprocess.STDOUT)
print('exit',r.returncode)
sys.exit(r.returncode)
