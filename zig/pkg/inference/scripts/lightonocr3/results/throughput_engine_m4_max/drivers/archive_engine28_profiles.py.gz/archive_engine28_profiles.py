from pathlib import Path
import json,hashlib,gzip,collections
s=Path('.venv-lighton-vllm-metal/archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")]);folders=sorted(p.parent for p in out.glob('engine28_4b_*/report.json'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
archive('qualification',[Path('/private/tmp/ocr-engine28-profiles-driver.txt')]+[Path('/private/tmp')/('ocr-'+folder.name.replace('_4b_','-4b-',1).replace('engine28_','engine28-',1)+'.txt')for folder in []],'logs_manifest.json')
# Explicit completed per-profile driver logs; exclude the ongoing load check.
archive('qualification',[Path('/private/tmp/ocr-engine28-4b-'+folder.name.split('engine28_4b_',1)[1]+'.txt')for folder in folders],'logs_manifest.json')
records=[];index=out/'raw_logs_manifest.json';mapping=json.loads(index.read_text())
for folder in folders:
 p=folder/'report.json';d=json.loads(p.read_text());r=d['results'][0];assert r['status']=='ok'and r['serial_reference_parity']and r['cross_runtime_content_parity']and not d['own_cpu_compile_overlap'];s=r['policy_rounds'][0];assert s['completed']==128;records.append(dict(report=str(p.relative_to(out)),sha256=sha(p),pages_per_second=s['pages_per_second'],completed=128,admission_pressures=s['admission_pressures'],exact_native_and_cross_runtime_text=True,physical_rows=d['physical_rows'],vision_frame_blocks=d['vision_frame_blocks'],prefill_wait_us=d['prefill_wait_us'],prefill_group_sizes=dict(collections.Counter(x['items']for x in s['prefill_batches'])),framed_runtime_totals=s['framed_runtime_totals']))
 for p in folder.glob('*.txt'):
  raw=p.read_bytes();dest=p.with_name(p.name+'.gz');packed=gzip.compress(raw,mtime=0);dest.write_bytes(packed);assert gzip.decompress(packed)==raw;mapping[str(p.relative_to(out))]={'compressed_path':str(dest.relative_to(out)),'raw_sha256':hashlib.sha256(raw).hexdigest(),'raw_bytes':len(raw),'compressed_sha256':sha(dest)};p.unlink()
index.write_text(json.dumps(mapping,indent=2)+'\n');(out/'engine28_comparison_audit.json').write_text(json.dumps(dict(scope='Seven completed qualified runtime profiles; no fresh repeated vLLM win. Budget profiles explicitly use device17/scratch10 with unchanged combined28 cap. Successful admission backpressure retained.',reports=records),indent=2)+'\n')
archive('qualification',[Path('/private/tmp/ocr-engine28-budget-profiles-driver.txt')],'logs_manifest.json')
archive('drivers',[v/n for n in ['archive_engine28_profiles.py','run_engine28_profiles.py','run_engine28_budget_profiles.py','run_engine28_budget_policies.py']],'drivers_manifest.json');print('archived',len(records),'complete native profiles; ongoing load-check files excluded')
