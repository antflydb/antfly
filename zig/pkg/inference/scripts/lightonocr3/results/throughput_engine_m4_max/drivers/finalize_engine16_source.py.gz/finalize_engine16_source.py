from pathlib import Path
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text().replace('''                attention.mode == .paged_decode and metal_runtime.hasActiveFrame(self.provider_impl.raw_decode_runtime);''','''                metal_runtime.hasActiveFrame(self.provider_impl.raw_decode_runtime);''',1)
s=s.replace('pub fn lightOnBatchAttentionStats(cb: *const ops.ComputeBackend) [2]u64 {','pub fn lightOnBatchAttentionStats(cb: *const ops.ComputeBackend) [3]u64 {',1)
idx=s.index('pub fn lightOnBatchAttentionStats(');a=s[:idx];b=s[idx:];b=b.replace('var result: [2]u64', 'var result: [3]u64',1);s=a+b;p.write_text(s)
p=Path('zig/pkg/inference/src/backends/metal_runtime.zig');s=p.read_text().replace('lighton_attention_batch_stats(runtime: ?*RawMetalDecodeRuntime, out: *[2]u64)', 'lighton_attention_batch_stats(runtime: ?*RawMetalDecodeRuntime, out: *[3]u64)');p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text();s=s.replace('MetalCompute.lightOnBatchAttentionStats(&cb) else @as([2]u64', 'MetalCompute.lightOnBatchAttentionStats(&cb) else @as([3]u64',1);s=s.replace('''                    const stream_splits = if''','''                    std.debug.print("LIGHTONOCR3 attention_batch_kernel_calls={d}\\n", .{attention_batch[2]});
                    const stream_splits = if''',1);p.write_text(s)
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text().replace('    uint64_t lighton_attention_batch_calls;', '    uint64_t lighton_attention_batch_kernel_calls;\n    uint64_t lighton_attention_batch_calls;',1)
s=s.replace('''    const uint32_t heads=batch->rows[0].params.num_heads''','''    if (runtime->lightonocr3_gqa_batch_stage_pipeline.maxTotalThreadsPerThreadgroup < 256u ||
        runtime->lightonocr3_gqa_batch_reduce_pipeline.maxTotalThreadsPerThreadgroup < 256u ||
        runtime->lightonocr3_gqa_batch_stage_pipeline.threadExecutionWidth != 32u ||
        runtime->lightonocr3_gqa_batch_reduce_pipeline.threadExecutionWidth != 32u) return 0;
    const uint32_t heads=batch->rows[0].params.num_heads''',1)
s=s.replace('''    // Ending the producer encoder orders all KV seeds''','''    if (termite_metal_decode_runtime_retain_frame_resource(runtime, table) != 0) return -1;
    // Ending the producer encoder orders all KV seeds''',1)
s=s.replace('''    if (batch_kernel > 0) {
        runtime->lighton_attention_batch_calls''','''    if (batch_kernel > 0) {
        runtime->lighton_attention_batch_kernel_calls += 1;
        runtime->lighton_attention_batch_calls''',1)
s=s.replace('''    out[1] = runtime != NULL ? runtime->lighton_attention_batch_rows : 0;
}''','''    out[1] = runtime != NULL ? runtime->lighton_attention_batch_rows : 0;
    out[2] = runtime != NULL ? runtime->lighton_attention_batch_kernel_calls : 0;
}''',1);p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text();a=s.index('static int ocr_attention_batch_check(');b=s.index('\nint main(',a);part=s[a:b]
part=part.replace('benchmark?2u:4u','benchmark?2u:5u').replace('''        const size_t mode=variant?1:0;''','''        const size_t mode=variant?1:0;
        const uint64_t batch_kernel_before=r->lighton_attention_batch_kernel_calls;
        if(variant==4)setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_BATCHED_GQA_KERNEL","1",1);''')
part=part.replace('variant>=2?0:rows','(variant==2||variant==3)?0:rows')
part=part.replace('''        r->lightonocr3_gqa_split_stage_pipeline=saved_stage;''','''        if(variant==1 && r->lighton_attention_batch_kernel_calls!=batch_kernel_before+1)return 10;
        if(variant!=1 && r->lighton_attention_batch_kernel_calls!=batch_kernel_before)return 11;
        if(variant==4)unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_BATCHED_GQA_KERNEL");
        r->lightonocr3_gqa_split_stage_pipeline=saved_stage;''')
s=s[:a]+part+s[b:];p.write_text(s)
