from pathlib import Path
v=Path('.venv-lighton-vllm-metal');root=v/'engine54-product-proposal';p=root/'zig/pkg/inference/src/server/executor_microbatch.zig';s=p.read_text()
needle='    execution_mutex: ?*std.Io.Mutex = null,';s=s.replace(needle,needle+'\n    execution_ready: std.Io.Event = .unset,\n    execution_waiters: std.atomic.Value(usize) = .init(0),')
needle='    fn executeGroup(self: *Broker, io: std.Io, shard: *BrokerShard, group: *Group) void {'
s=s.replace(needle,(v/'engine54_execution_lane_wait.inc').read_text()+needle)
a=s.index('        // Lock before detaching the group.');b=s.index('        shard.mutex.lockUncancelable(io);',a)
s=s[:a]+'''        var protection: ?std.Io.CancelProtection = null;
        defer if (protection) |previous| _ = io.swapCancelProtection(previous);
        const owns_lane = if (self.execution_mutex) |mutex| self.waitForExecutionLane(io, shard, group, mutex, &protection) else false;
        const abandoned = self.execution_mutex != null and !owns_lane;
        defer if (owns_lane) {
            self.execution_mutex.?.unlock(io);
            self.execution_ready.set(io);
        };
'''+s[b:]
a=s.index(needle);b=s.index('    fn finishGroupLocked',a);region=s[a:b].replace('if (canceled or expired) {','if (canceled or expired or abandoned) {');s=s[:a]+region+s[b:]
s=s.replace('while (execution_mutex.state.load(.acquire) != .contended)', 'while (broker.execution_waiters.load(.acquire) == 0)').replace('This observes\n        // mutex contention rather than assuming a scheduler timing interval.','This observes\n        // a registered waiter rather than assuming a scheduler timing interval.')
p.write_text(s)
print('cancellation-aware execution-lane wait prepared')
