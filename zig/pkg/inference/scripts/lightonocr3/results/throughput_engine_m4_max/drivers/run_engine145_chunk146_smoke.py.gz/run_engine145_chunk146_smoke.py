from pathlib import Path
import datetime,hashlib,json,os,psutil,subprocess,sys,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();a=o/'engine145_remaining_chunk146_audit.json';assert not a.exists();f=json.loads((v/'engine145-freeze.json').read_text());assert all(sha(p)==h for p,h in f.items());d=dict(status='preparing',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),scope='Source139 first full4B groupedP4 chunk128 correctness smoke C16R16, wide-recurrentOFF/legacy16 math; original caps and fresh132 API strings as content oracle only. All chunks, independent histories, final starts/finishes and full OCR strings required. No primary speed claim.',runs=[])
def save():a.write_text(json.dumps(d,indent=2)+'\n')
d['primary_throughput_eligible']=False
assert (o/'engine145_build_manifest.json').exists()
save()
profiles=[dict(name='4b_profile',model='4b',c=16,requests=16,stream=0,pool=0,vf=3)]
try:
 for profile in profiles:
  while psutil.virtual_memory().available<(11348275670 if profile['model']=='4b'else 3000000000)+6*1024**3+512*1024**2:d['status']='waiting_original_reserve';d['available_bytes']=psutil.virtual_memory().available;save();print('WAIT146',d['available_bytes'],flush=True);time.sleep(15)
  label=f"chunk146_{profile['name']}_c{profile['c']}_r{profile['requests']}";dest=o/f"engine145_{profile['model']}_{label}";assert not dest.exists();env=dict(os.environ)
  env.update(OCR_PREFILL_ACTIVATION_POOL=str(profile['pool']),OCR_PREFILL_QUERY_CHUNK_ROWS='128',OCR_WIDE_RECURRENT='0',OCR_PACKED_MIXED='1',OCR_PACKED_PREFILL_ITEMS='4',OCR_REFERENCE_LABEL='_primary_reference93_r0_c64_w256_r256_ctx1024'if profile['model']=='4b'else'_primary_reference72_r0_auto_c64_r128',OCR_PHYSICAL32='0',OCR_PHYSICAL64='1',OCR_CONCURRENCY=str(profile['c']),OCR_REQUESTS=str(profile['requests']),OCR_WIDE='1',OCR_KV_GIB='4',OCR_BACKEND_GIB='17'if profile['model']=='4b'else'16',OCR_SCRATCH_GIB='10'if profile['model']=='4b'else'8',OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1',OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_DISABLE_64_ROW_TILE='0',OCR_DISABLE_WIDE_GATE_UP='0',OCR_WIDE64_GATE_UP='1',OCR_FULL64_GATE_UP=str(int(profile['model']=='4b')),OCR_GPU_GREEDY_STREAM='0',OCR_STREAM_CHUNK_LAYERS='0',OCR_VISION_BATCH='0',OCR_VISION_BATCH_ITEMS='1',OCR_VISION_WAIT_US='20000',OCR_PREFILL_BATCH='0',OCR_PREFILL_BATCH_ITEMS='1',OCR_VISION_FRAME_BLOCKS=str(profile['vf']),OCR_SINGLE_FRAME='1',OCR_STREAM_FIRST='0',OCR_LOGICAL64='1',OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',OCR_ADMISSION_UNITS='512',OCR_BATCH_ARGMAX='1',OCR_DEFER_VISION_SEAL='0',OCR_DEFER_PREFILL_SEAL='0',OCR_CACHE_VISION_WORKSPACE='1',OCR_LARGE_VISION_PACK_REUSE='0',ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY='0',OCR_TIMEOUT='1800',OCR_PREFILL_FUSED_FFN='0',OCR_RESIDENT_VISION_BUDGET='1',OCR_GPU_TOKEN_BURST='1',OCR_GPU_TOKEN_BURST_WIDTH='4',OCR_PIPELINE_VISION='0',OCR_PREFILL_STREAM_LAYERS=str(profile['stream']),OCR_REQUIRE_MEMORY_ROUNDS='1')
  for key in ['OCR_BF16_ROUNDS','OCR_PREFILL_FFN_ROUNDS','OCR_VERIFY_SAVED_RUN']:env.pop(key,None)
  d['diagnostic_environment']={};save()
  record=dict(profile=profile,status='running');d['runs'].append(record);d['status']='running';save();print('START146',profile,flush=True);log=Path('/private/tmp')/f"ocr-engine145-chunk146-{profile['name']}-driver.txt";assert not log.exists()
  with log.open('w')as out:
   p=subprocess.Popen([sys.executable,str(v/'run_engine145_budget_policies.py'),profile['model']+':'+label],env=env,stdout=out,stderr=subprocess.STDOUT)
   sampled=False
   p.wait(timeout=1800)
  d['cpu_sampling_attempted']=sampled;save()
  record.update(exit_code=p.returncode,driver_log_sha256=sha(log));rp=dest/'report.json'
  if rp.exists():
   report=json.loads(rp.read_text());result=report['results'][0];sample=(result.get('policy_rounds')or[{}])[0];record.update(report=str(rp.relative_to(o)),report_sha256=sha(rp),sample=sample)
   passed=p.returncode==0 and result['status']=='ok'and result['serial_reference_parity']and result['cross_runtime_content_parity']and sample.get('completed')==profile['requests'] and not sample.get('admission_pressures')
  else:passed=False
  
  if passed:
   assert sample.get('prefill_activation_pool')==profile['pool']
   assert sample['packed_prefill_chunks']>profile['requests'] and sample['packed_prefill_pages']==sample['packed_prefill_starts']==profile['requests'] and sample['prepared_prefill_chunk_rows']==128
   if profile['pool']:assert sample['prefill_activation_pool_hits']>0 and sample['prefill_activation_pool_hit_bytes']>0 and 8*1024**2<sample['activation_pool_peak_bytes']<=64*1024**2
  if passed:assert 2<=sample['packed_prefill_max_items']<=4,sample
  record['primary_throughput_eligible']=False
  record['status']='passed'if passed else'excluded';save();print('DONE146',profile['name'],record['status'],record.get('sample',{}).get('pages_per_second'),flush=True)
  assert passed,record
 d['status']='screen_complete';save()
except BaseException as e:d.update(status='failed_screen',error=repr(e));save();raise
