from pathlib import Path
import json,hashlib,re
v=Path('.venv-lighton-vllm-metal');dest=v/'engine56-proposal';p='zig/pkg/inference/src/backends/metal_kernels.m';s=Path(p).read_text();base=s
needle='    uint64_t lighton_vision_pack_reuse_hits;';assert s.count(needle)==1
s=s.replace(needle,needle+'''
    uint64_t lighton_large_vision_pack_calls;
    uint64_t lighton_large_vision_pack_reuse_hits;
    BOOL lighton_vision_workspace_keep;
    uint64_t lighton_vision_workspace_allocations;
    uint64_t lighton_vision_workspace_reuses;''')
needle='    const bool vision_pack_scope = rows >= 32u && rows <= 4096u &&';assert s.count(needle)==1
s=s.replace(needle,'''    const bool large_vision_pack = rows > 4096u && rows <= 16384u &&
        termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_LARGE_VISION_PACK_REUSE);
    const bool vision_pack_scope = rows >= 32u && (rows <= 4096u || large_vision_pack) &&''')
# Frame policy flags are snapshotted once, so the new explicit switch must use
# the same frame-local policy rather than getenv in the projection loop.
needle='TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_VISION_PACK_REUSE'
# Inspect the enum/map before completing this proposal; this script deliberately
# stops before applying or writing an unbound policy entry.
a=s.index('static id<MTLBuffer> termite_metal_lightonocr3_vision_workspace(');b=s.index('int termite_metal_decode_runtime_sdpa',a) if 'int termite_metal_decode_runtime_sdpa'in s[a:]else s.index('int termite_metal_sdpa',a)
region=s[a:b]
old='''                ANTFLY_BUFFER_OWNED);
        }
        id<MTLBuffer> packed = r->lightonocr3_vision_pack_buffers[i];'''
assert old in region
region=region.replace(old,'''                ANTFLY_BUFFER_OWNED);
            if (r->lightonocr3_vision_pack_buffers[i] != nil)
                r->lighton_vision_workspace_allocations = termite_metal_u64_saturating_add(r->lighton_vision_workspace_allocations, 1);
        } else {
            r->lighton_vision_workspace_reuses = termite_metal_u64_saturating_add(r->lighton_vision_workspace_reuses, 1);
        }
        id<MTLBuffer> packed = r->lightonocr3_vision_pack_buffers[i];''')
region=region.replace('''            r->lightonocr3_vision_pack_buffers[i] = nil;
            r->lightonocr3_vision_pack_owners[i] = nil;''','''            if (!r->lighton_vision_workspace_keep) r->lightonocr3_vision_pack_buffers[i] = nil;
            r->lightonocr3_vision_pack_owners[i] = nil;''')
# clear() always releases both banks and resets the opt-in mode before its
# request/epoch admission lease can retire.
needle='''    for (size_t i = 0; i < 2; ++i) {
        r->lightonocr3_vision_pack_buffers[i] = nil;
        r->lightonocr3_vision_pack_owners[i] = nil;
    }
    return 0;'''
assert needle in region
region=region.replace(needle,needle.replace('    return 0;','    r->lighton_vision_workspace_keep = NO;\n    return 0;'))
s=s[:a]+region+s[b:]
needle='''            runtime->lighton_vision_pack_reuse_hits += runtime->reuse_hit_count > reuse_before;
        }'''
assert s.count(needle)==1
s=s.replace(needle,'''            runtime->lighton_vision_pack_reuse_hits += runtime->reuse_hit_count > reuse_before;
            if (large_vision_pack) {
                runtime->lighton_large_vision_pack_calls += 1;
                runtime->lighton_large_vision_pack_reuse_hits += runtime->reuse_hit_count > reuse_before;
            }
        }''')
s+='''
int termite_metal_decode_runtime_set_lighton_vision_workspace_cache(termite_metal_decode_runtime *runtime, int enabled) {
    int rc = termite_metal_decode_runtime_clear_lightonocr3_vision_workspace(runtime);
    if (rc != 0) return rc;
    runtime->lighton_vision_workspace_keep = enabled != 0 ? YES : NO;
    return 0;
}
void termite_metal_decode_runtime_lighton_vision_workspace_stats(termite_metal_decode_runtime *runtime, uint64_t *out) {
    if (out == NULL) return;
    out[0] = runtime != NULL ? runtime->lighton_vision_workspace_allocations : 0;
    out[1] = runtime != NULL ? runtime->lighton_vision_workspace_reuses : 0;
    out[2] = runtime != NULL ? runtime->lightonocr3_vision_pack_buffers[0].length + runtime->lightonocr3_vision_pack_buffers[1].length : 0;
}
void termite_metal_decode_runtime_lighton_large_vision_pack_stats(termite_metal_decode_runtime *runtime, uint64_t *out) {
    if (out == NULL) return;
    out[0] = runtime != NULL ? runtime->lighton_large_vision_pack_calls : 0;
    out[1] = runtime != NULL ? runtime->lighton_large_vision_pack_reuse_hits : 0;
}
'''
s=s.replace('    TERMITE_METAL_FRAME_ENV_COUNT\n', '    TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_LARGE_VISION_PACK_REUSE,\n    TERMITE_METAL_FRAME_ENV_COUNT\n')
s=s.replace('    \"TERMITE_METAL_DISABLE_LIGHTONOCR3_64_ROW_TILE\",\n};', '    \"TERMITE_METAL_DISABLE_LIGHTONOCR3_64_ROW_TILE\",\n    \"TERMITE_METAL_ENABLE_LIGHTONOCR3_LARGE_VISION_PACK_REUSE\",\n};')
assert s.count('TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_LARGE_VISION_PACK_REUSE')==2
target=dest/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(s)
(v/'engine56-c-proposal-pending-policy.json').write_text(json.dumps(dict(status='proposal_only_requires_policy_binding',source=p,base_sha256=hashlib.sha256(base.encode()).hexdigest(),proposal_sha256=hashlib.sha256(s.encode()).hexdigest()),indent=2)+'\n')
print('C host proposal prepared, not applied; needs explicit frame policy binding')
