import subprocess,sys
from pathlib import Path
r=Path.cwd();s=r/'zig/pkg/inference/scripts/lightonocr3';v=r/'.venv-lighton-vllm-metal'
for model in sys.argv[1:]:
 cmd=[sys.executable,str(s/'benchmark_vllm_metal.py'),'--python',sys.executable,'--model-dir',str(v/'ocr-models'/('lighton'+model)),'--images',str(r/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(s/'corpus/receipt.png'),str(s/'corpus/shipping.png'),'--concurrency','16','--requests','32','--max-tokens','256','--kv-cache-blocks','128','--startup-timeout','600','--output-dir',str(s/'results/throughput_engine_m4_max'/('vllm_'+model+'_primary_reference3_16x32'))]
 print('START',model,flush=True)
 with open('/private/tmp/ocr-engine-vllm-'+model+'-primary3-16x32.txt','w')as log:res=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 print('DONE',model,res.returncode,flush=True)
 if res.returncode:sys.exit(res.returncode)
