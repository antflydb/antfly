from pathlib import Path
import hashlib,json,os,subprocess,sys,re
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max';manifest=out/'engine39_build_manifest.json';binary=Path(json.loads(manifest.read_text())['binary_path'])
for key in sys.argv[1:]:
 model,label=key.split(':');env=os.environ.copy();cpu_preprocess=os.environ.get('OCR_CPU_PREPROCESS','1')=='1';vision_batch=os.environ.get('OCR_VISION_BATCH','0')=='1';env['ANTFLY_LIGHTONOCR3_PREFILL_DECODE_STREAK']=os.environ.get('OCR_PREFILL_DECODE_STREAK','4');env['ANTFLY_LIGHTONOCR3_VISION_FRAME_BLOCKS']=os.environ.get('OCR_VISION_FRAME_BLOCKS','1');env['ANTFLY_LIGHTONOCR3_CPU_PREPROCESS']='1'if cpu_preprocess else'0';env['ANTFLY_LIGHTONOCR3_GATE_EVENTS']=os.environ.get('OCR_GATE_EVENTS','1');env['PYTHONPATH']=str(scripts);wide=os.environ.get('OCR_WIDE','0')=='1';physical32=os.environ.get('OCR_PHYSICAL32','0')=='1';physical64=os.environ.get('OCR_PHYSICAL64','0')=='1';physical_rows=64 if physical64 else 32 if physical32 else 16 if wide else 8;compact=os.environ.get('OCR_COMPACT','1')=='1';extended=os.environ.get('OCR_EXTENDED_EPOCH','1')=='1';env['ANTFLY_LIGHTONOCR3_EXTENDED_EPOCH']='1'if extended else'0';pack_disabled=os.environ.get('OCR_DISABLE_PACK_REUSE','0')=='1';contention=os.environ.get('OCR_CONTENTION_US','1000');batched=os.environ.get('OCR_BATCH_ATTENTION','1')=='1';env['ANTFLY_LIGHTONOCR3_BATCH_ATTENTION']='1'if batched else'0';stream=int(os.environ.get('OCR_STREAM_FIRST','0'));env['ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS']=str(stream);shared=os.environ.get('OCR_SHARED_CORE','1')=='1';disable_mpp=os.environ.get('OCR_DISABLE_WIDE_MPP','0')=='1';prefill_bf16=os.environ.get('OCR_BF16_PREFILL','0')=='1';env['ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS']='1'if shared else'0';single=os.environ.get('OCR_SINGLE_FRAME','0')=='1';bf16=os.environ.get('OCR_BF16','0')=='1';env['ANTFLY_LIGHTONOCR3_SINGLE_FRAME']='1'if single else'0';env['ANTFLY_LIGHTONOCR3_COMPACT_KV']='1'if compact else'0';env['ANTFLY_LIGHTONOCR3_EXECUTOR_TAIL']='0';env['ANTFLY_LIGHTONOCR3_PHASE_FAIR']='0';env['ANTFLY_LIGHTONOCR3_EPOCH_AUX']='0';env.update(ANTFLY_LIGHTONOCR3_WIDE_DECODE='1'if wide else'0',ANTFLY_LIGHTONOCR3_PREPARED_DECODE='0',ANTFLY_LIGHTONOCR3_EXECUTOR='0',ANTFLY_LIGHTONOCR3_STEP_EVENTS='0',ANTFLY_LIGHTONOCR3_DECODE_WORKSPACE='0',ANTFLY_LIGHTONOCR3_ACTIVATION_POOL='0')
 c=os.environ.get('OCR_CONCURRENCY','8');requests=os.environ.get('OCR_REQUESTS','16');policies=os.environ.get('OCR_POLICIES','engineepoch,enginetailepoch').split(',');target=out/f'engine39_{model}_{label}'
 env['TERMITE_METAL_DISABLE_LIGHTONOCR3_DECODE_PACK_REUSE']=os.environ.get('OCR_DISABLE_DECODE_PACK_REUSE','0');env['TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_PACK_REUSE']=os.environ.get('OCR_DISABLE_VISION_PACK_REUSE','0')
 planned_disabled=os.environ.get('OCR_DISABLE_PLANNED_MPP','0')=='1';vision_stream=os.environ.get('OCR_VISION_STREAM','0')=='1'
 cmd=[sys.executable,str(v/'engine39_benchmark_concurrency.py'),'--native-test',str(binary),'--model',f'lighton{model}={v/"ocr-models"/("lighton"+model)}','--images',str(root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(scripts/'corpus/receipt.png'),str(scripts/'corpus/shipping.png'),'--concurrency',c,'--requests',requests,'--max-tokens','256','--modes','batch','--batch-rows',str(physical_rows),'--batch-window',c,'--batch-wait-us','20000','--memory-gib','24','--shared-memory-gib','28','--backend-memory-gib',os.environ.get('OCR_BACKEND_GIB','16'),'--kv-memory-gib',os.environ.get('OCR_KV_GIB','4'),'--scratch-memory-gib',os.environ.get('OCR_SCRATCH_GIB','4'),'--timeout','900','--contention-wait-us',contention,'--reference-report',str(out/('vllm_'+model+os.environ.get('OCR_REFERENCE_LABEL', '_primary_reference5_32x128' if c=='32' else '_primary_reference6_16x128' if requests=='128' else '_primary_reference3_16x32'))/'report.json'),'--output-dir',str(target),'--build-manifest',str(manifest),'--weight-residency','--continuous','--frame-policy','--require-frame-policy','--weight-handles','--require-weight-handles','--trace-packed-core','--require-packed-core','--recurrent-parallel','--require-recurrent-parallel','--prefill-attention-mpp','--require-prefill-attention-mpp','--prefill-core-norm','--require-prefill-core-norm',*(['--bf16-projection-inputs']if bf16 else[]),*(['--bf16-prefill-inputs']if prefill_bf16 else[]),*(['--disable-wide-mpp']if disable_mpp else[]),*(['--disable-prefill-pack-reuse']if pack_disabled else[]),*(['--disable-decode-pack-reuse']if env['TERMITE_METAL_DISABLE_LIGHTONOCR3_DECODE_PACK_REUSE']=='1'else[]),*(['--disable-vision-pack-reuse']if env['TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_PACK_REUSE']=='1'else[]),*(['--physical64'] if physical64 else ['--physical32'] if physical32 else []),*(['--vision-batch','--vision-wait-us',os.environ.get('OCR_VISION_WAIT_US','2000')] if vision_batch else []),'--policy-rounds',*policies]
 logical64=os.environ.get('OCR_LOGICAL64','0')=='1'
 if logical64:cmd+=['--logical64']
 device_state=os.environ.get('OCR_DEVICE_RECURRENT_STATE','1')=='1'
 if device_state:cmd+=['--device-recurrent-state']
 share_decoder=os.environ.get('OCR_SHARED_DECODER_SCRATCH','0')=='1'
 if share_decoder:cmd+=['--share-decoder-scratch']
 encoder_scopes=os.environ.get('OCR_ENCODER_SCOPES','1')=='1'
 if encoder_scopes:cmd+=['--ocr-encoder-scopes']
 admission_units=os.environ.get('OCR_ADMISSION_UNITS','512');cmd+=['--admission-units',admission_units]
 token_scope_disabled=os.environ.get('OCR_DISABLE_TOKEN_ENCODER','0')=='1'
 if token_scope_disabled:cmd+=['--disable-lighton-token-encoder']
 if planned_disabled:cmd+=['--disable-planned-mpp']
 if vision_stream:cmd+=['--vision-stream']
 if os.environ.get('OCR_DISABLE_64_ROW_TILE','0')=='1':cmd+=['--disable-64-row-tile']
 print('START',key,flush=True)
 reuse=os.environ.get('OCR_REUSE_COMPLETED_NATIVE_REPORT','0')=='1'
 if reuse:
  assert (target/'report.json').exists()
  res=subprocess.CompletedProcess(cmd,0)
 else:
  with open('/private/tmp/ocr-engine39-'+model+'-'+label+'.txt','w')as log:res=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 if(target/'report.json').exists():
  report=json.loads((target/'report.json').read_text());report['vision_stream']=vision_stream;report['ocr_encoder_scopes']=encoder_scopes;report['shared_decoder_scratch']=share_decoder;report['logical64']=logical64;report['device_recurrent_state']=device_state;report['request_admission_units']=int(admission_units);report['kv_memory_gib']=int(os.environ.get('OCR_KV_GIB','4'));report['prefill_batch']=False;report['prefill_wait_us']=int(os.environ.get('OCR_PREFILL_WAIT_US','100000'));report['cpu_preprocess']=cpu_preprocess;report['vision_batch']=vision_batch;report['gate_events']=env['ANTFLY_LIGHTONOCR3_GATE_EVENTS']=='1';report['driver_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();report['own_cpu_compile_overlap']=os.environ.get('OCR_DIAGNOSTIC','0')=='1';report['extended_epoch']=extended;report['disable_prefill_pack_reuse']=pack_disabled;report['contention_wait_us']=int(contention);report['batch_attention']=batched;report['planned_barriers_disabled']=env.get('TERMITE_METAL_DISABLE_PLANNED_COMPUTE_BARRIERS','0');report['stream_first_layers']=stream;report['shared_core_weights']=shared;report['disable_wide_mpp']=disable_mpp;report['bf16_prefill_inputs']=prefill_bf16;report['single_frame']=single;report['bf16_projection_inputs']=bf16;report['compact_qwen35_kv']=compact;report['physical_rows']=physical_rows
  for result in report['results']:
   raw=(target/result['log']).read_text()
   heads=list(re.finditer(r'OCR_POLICY round=(\d+) name=(\w+)',raw))
   sections={int(m[1]):raw[m.end():heads[i+1].start()if i+1<len(heads)else len(raw)]for i,m in enumerate(heads)}
   for sample in (result.get('policy_rounds') or []):
    section=sections[sample['round']]
    vf=int(os.environ.get('OCR_VISION_FRAME_BLOCKS','1'));report['vision_frame_blocks']=vf;groups=re.findall(r'vision_frame_blocks=(\d+) vision_frame_submits=(\d+) vision_frame_images=(\d+)',section);sample['vision_frame_groups']=[list(map(int,x))for x in groups]
    if vf>1 or vision_stream:assert sum(int(n)for _,_,n in groups)==int(requests) and all(int(b)==vf and int(s)==(12 if model=='08' else 24)//vf for b,s,n in groups),(sample,groups)
    vision_stream_stats=re.findall(r'vision_stream=1 vision_stream_pending_blocks_peak=(\d+) vision_stream_retained_blocks=(\d+) vision_stream_images=(\d+)',section)
    sample['vision_stream_stats']=[list(map(int,x))for x in vision_stream_stats]
    if vision_stream:assert vision_stream_stats and all(int(a)==vf and int(b)==2*vf for a,b,n in vision_stream_stats) and sum(int(n)for a,b,n in vision_stream_stats)==int(requests),vision_stream_stats
    else:assert not vision_stream_stats,vision_stream_stats
    prefill_batches=re.findall(r'prefill_batch_items=(\d+) query_tokens=(\d+)',section);sample['prefill_batches']=[{'items':int(n),'tokens_per_item':int(t)} for n,t in prefill_batches];assert not prefill_batches,(sample,prefill_batches)
    streak=int(os.environ.get('OCR_PREFILL_DECODE_STREAK','4'));report['prefill_decode_streak']=streak;waits=re.findall(r'prefill_await_groups=(\d+) prefill_await_events=(\d+) prefill_decode_streak=(\d+)',section);sample['prefill_await_groups']=sum(int(g)for g,e,s in waits);sample['prefill_await_events']=bool(waits)and all(int(e)==1 for g,e,s in waits);assert waits and sample['prefill_await_groups']==len(prefill_batches) and not sample['prefill_await_events'] and all(int(s)==streak for g,e,s in waits),(sample,waits)
    hostpeak=re.findall(r'shared_vision_host_peak_bytes=(\d+) peak_segments=(\d+)',section);sample['shared_vision_host_peaks']=[int(x)for x,n in hostpeak];assert hostpeak and all((int(x)>0)==(vf>1 or vision_stream)for x,n in hostpeak),(sample,hostpeak)
    heads=re.findall(r'standalone_wide_heads=(\d+)',section);assert heads,section[-1000:];sample['standalone_wide_heads']=sum(int(x)for x in heads)
    if physical32 and not single:assert sample['standalone_wide_heads']>0,sample
    if single:assert sample['standalone_wide_heads']==0,sample
    cpu=re.findall(r'cpu_preprocess=(\d+) cpu_preprocess_items=(\d+) cpu_preprocess_ns=(\d+) vision_batch_limit=(\d+)',section)
    sample['cpu_preprocess_items']=sum(int(n) for _,n,_,_ in cpu);sample['cpu_preprocess_ns']=sum(int(ns) for _,_,ns,_ in cpu)
    assert cpu and all((int(enabled)==1)==cpu_preprocess and int(limit)==(4 if vision_batch else 1) for enabled,_,_,limit in cpu),(sample,cpu)
    assert sample['cpu_preprocess_items']==(int(requests) if cpu_preprocess else 0),(sample,cpu)
    batches=re.findall(r'(?:prepared_)?vision_batch_items=(\d+)',section);sample['vision_batch_sizes']=[int(x) for x in batches]
    if vision_batch:assert batches and max(sample['vision_batch_sizes'])>1 and max(sample['vision_batch_sizes'])<=4,(sample,batches)
    event_gates=re.findall(r'gate_events=(\d+) gate_event_acquisitions=(\d+) gate_event_waits=(\d+)',section)
    sample['gate_event_acquisitions']=sum(int(a) for _,a,_ in event_gates);sample['gate_event_waits']=sum(int(w) for _,_,w in event_gates)
    expected_gate=report['gate_events'] and sample['policy'] in ['engineepoch','enginetailepoch','enginefull','enginecached','engineall','engineworker','engineplan','enginepool','enginephase','enginepoolphase','enginetail','enginetailfair','enginefullfair']
    assert event_gates and all((int(e)==1)==expected_gate for e,_,_ in event_gates),(sample,event_gates)
    if expected_gate:assert sample['gate_event_acquisitions']>0,sample
    auxiliary=re.findall(r'epoch_auxiliary=(\d+) auxiliary_acquisitions=(\d+) auxiliary_host_scratch=(\d+) auxiliary_backend_scratch=(\d+)',section)
    expected_aux=sample['policy']in ['engineepoch','enginetailepoch'];sample['epoch_auxiliary']=expected_aux;sample['auxiliary_acquisitions']=[int(x[1])for x in auxiliary];sample['admission_pressures']=re.findall(r'admission_pressure=(\w+)',section)
    assert auxiliary and all((int(x[0])==1)==expected_aux and int(x[1])==(1 if expected_aux else 0)for x in auxiliary),auxiliary
    assert section.count('auxiliary_release_after_backend=1')==(len(auxiliary)if expected_aux else 0),section
    sample['epoch_page_joins']=[int(x)for x in re.findall(r'cohort_items=(\d+)',section)];assert sum(sample['epoch_page_joins'])==int(requests),sample
    if extended and int(requests)>64:assert max(sample['epoch_page_joins'])>64,sample
    # Physical64 cohorts can entirely skip the older narrow projection tile.
    if bf16:assert sample['wide_projection_tiles']==0,sample
    if result['status']=='ok'and not bf16:assert (sample['wide_mpp_heads']>0)==(not disable_mpp) and (sample['wide_mpp_projections']>0)==(wide and not disable_mpp),sample
    core=re.findall(r'shared_core_weight_hits=(\d+) shared_core_weight_misses=(\d+) shared_core_weight_bytes=(\d+)',section);sample['shared_core_weight_hits']=sum(int(x)for x,_,_ in core);sample['shared_core_weight_misses']=sum(int(x)for _,x,_ in core);sample['shared_core_weight_bytes']=sum(int(x)for _,_,x in core);assert core and (sample['shared_core_weight_hits']>0)==shared and all(int(m)<=128 and int(b)<=8*1024*1024 for _,m,b in core),sample
    for scope,enabled in [('decode',bf16 and (physical32 or physical64)),('vision',bf16 or prefill_bf16)]:
     stats=re.findall(scope+r'_pack_calls=(\d+) '+scope+r'_pack_reuse_hits=(\d+)',section)
     assert stats,(scope,section[-2000:]);sample[scope+'_pack_calls']=sum(int(x)for x,y in stats);sample[scope+'_pack_reuse_hits']=sum(int(y)for x,y in stats)
     off=env['TERMITE_METAL_DISABLE_LIGHTONOCR3_'+scope.upper()+'_PACK_REUSE']=='1'
     if not enabled or off:assert sample[scope+'_pack_calls']==0 and sample[scope+'_pack_reuse_hits']==0,(scope,sample)
     else:assert sample[scope+'_pack_calls']>0 and sample[scope+'_pack_reuse_hits']>0,(scope,sample)
     report['disable_'+scope+'_pack_reuse']=off
    mpp=re.findall(r'mpp_planned_calls=(\d+) mpp_dedicated_calls=(\d+)',section);assert mpp,section[-2000:];sample['mpp_planned_calls']=sum(int(x)for x,y in mpp);sample['mpp_dedicated_calls']=sum(int(y)for x,y in mpp);report['disable_planned_mpp']=planned_disabled
    if planned_disabled:assert sample['mpp_planned_calls']==0,sample
    else:assert sample['mpp_planned_calls']>0,sample
    pack_stats=re.findall(r'prefill_pack_calls=(\d+) prefill_pack_reuse_hits=(\d+)',section);sample['prefill_pack_calls']=sum(int(x)for x,_ in pack_stats);sample['prefill_pack_reuse_hits']=sum(int(x)for _,x in pack_stats);assert pack_stats and sample['prefill_pack_reuse_hits']<=sample['prefill_pack_calls'],sample
    if not (prefill_bf16 or bf16) or pack_disabled:assert sample['prefill_pack_calls']==0 and sample['prefill_pack_reuse_hits']==0,sample
    attn_stats=re.findall(r'attention_batch_calls=(\d+) attention_batch_rows=(\d+)',section);sample['attention_batch_calls']=sum(int(x)for x,_ in attn_stats);sample['attention_batch_rows']=sum(int(x)for _,x in attn_stats);assert attn_stats and (sample['attention_batch_calls']>0)==batched,sample
    kernel_stats=re.findall(r'attention_batch_kernel_calls=(\d+)',section);sample['attention_batch_kernel_calls']=sum(int(x)for x in kernel_stats);assert kernel_stats and (sample['attention_batch_kernel_calls']>0)==batched,sample
    stream_stats=re.findall(r'stream_forward_splits=(\d+) stream_first_layers=(\d+)',section);sample['stream_forward_splits']=sum(int(x)for x,_ in stream_stats);assert stream_stats and (sample['stream_forward_splits']>0)==(stream>0),sample
    frame_stats=re.findall(r'single_frame_steps=(\d+) single_frame_topology_mismatches=(\d+)',section);sample['single_frame_steps']=sum(int(x)for x,_ in frame_stats);sample['single_frame_topology_mismatches']=sum(int(x)for _,x in frame_stats);assert frame_stats and (sample['single_frame_steps']>0)==single and sample['single_frame_topology_mismatches']==0,sample
    recurrent=re.findall(r'device_recurrent_state=(\d+) recurrent_cache_pages=(\d+) host_recurrent_bytes_total=(\d+)',section);assert recurrent,(sample,section[-2000:]);sample['recurrent_cache_pages']=sum(int(b)for a,b,c in recurrent);sample['host_recurrent_bytes_total']=sum(int(c)for a,b,c in recurrent)
    assert all((int(a)==1)==device_state for a,b,c in recurrent) and sample['recurrent_cache_pages']==int(requests),(sample,recurrent)
    assert (sample['host_recurrent_bytes_total']==0)==device_state,(sample,recurrent)
    shared_stats=re.findall(r'shared_decoder_scratch=(\d+) shared_decoder_peak_bytes=(\d+) peak_segments=(\d+)',section);assert shared_stats,section[-2000:]
    enabled=share_decoder and not report['prefill_batch']
    assert all((int(a)==1)==enabled and (int(b)>0)==enabled and (int(c)>0)==enabled for a,b,c in shared_stats),shared_stats
    assert section.count('decoder_scratch_release_after_backend=1')==(len(shared_stats)if enabled else 0),shared_stats
    sample['shared_decoder_peak_bytes']=max(int(b)for a,b,c in shared_stats)
    encoder_stats=re.findall(r'vision_encoder_scope_opens=(\d+) prefill_encoder_scope_opens=(\d+)',section);assert encoder_stats,section[-2000:]
    sample['vision_encoder_scope_opens']=sum(int(a)for a,b in encoder_stats);sample['prefill_encoder_scope_opens']=sum(int(b)for a,b in encoder_stats)
    assert all((int(a)>0)==encoder_scopes and (int(b)>0)==encoder_scopes for a,b in encoder_stats),encoder_stats
    scopes=re.findall(r'token_encoder_scope_steps=(\d+)',section);assert scopes,section[-2000:];sample['token_encoder_scope_steps']=sum(map(int,scopes));report['disable_token_encoder']=token_scope_disabled
    assert sample['token_encoder_scope_steps']==(sample['executor_steps']if single and not token_scope_disabled else 0),sample
    if single:assert sample['single_frame_steps']==sample['executor_steps'],sample
    if stream>0:
     assert sample['prepared_blocks']==(18 if model=='08'else 24)*sample['executor_steps'],sample
     assert sample['stream_forward_splits']<=sample['executor_steps'],sample
    gates=re.findall(r'phase_priority_yields=(\d+) phase_fair=(\d+)',section);layers=re.findall(r'kv_storage_layers=(\d+) model_layers=(\d+)',section);cohorts=re.findall(r'cohort_items=\d+ decode_steps=(\d+).*?decode_items=(\d+)',section)
    sample['phase_priority_yields']=sum(int(x)for x,_ in gates);sample['phase_fair']=all(int(x)==1 for _,x in gates)if gates else False;sample['kv_storage_layers']=[int(x)for x,_ in layers];sample['average_decode_rows']=sum(int(x)for _,x in cohorts)/max(1,sum(int(x)for x,_ in cohorts))
    assert gates and sample['phase_fair']==(sample['policy']in ['enginetailfair','enginefullfair','engineepoch','enginetailepoch']),(sample,gates)
    assert layers and all(int(x)==int(y)//(4 if compact else 1)for x,y in layers),layers
    assert sample['attention_batch_calls']<=sum(int(x) for x,_ in cohorts)*(6 if model=='08' else 8)*((physical_rows+15)//16),sample
    assert sample['attention_batch_rows']<=sum(int(x) for _,x in cohorts)*(6 if model=='08' else 8),sample
    windows=re.findall(r'registered_window_peak=(\d+) physical_rows_limit=(\d+)',section);assert windows and all(int(y)==physical_rows for _,y in windows),windows
    if c=='32':assert max(int(x)for x,_ in windows)>16,windows
    if int(c)>32 and logical64:assert max(int(x)for x,_ in windows)>32,windows
    if physical64:assert max(sample['packed_core_rows_observed'])>32,sample
    if physical32:assert max(sample['packed_core_rows_observed'])>16,sample
    p=sample['policy'];assert(sample['executor_tail_steps']>0)==(p in ['enginetail','enginetailfair','enginetailepoch']),(p,sample);assert(sample['prepared_blocks']>0)==(p in ['engineplan','engineall','enginecached','enginefull','enginetail','enginetailfair','enginefullfair','engineepoch','enginetailepoch']),(p,sample);assert(sample['executor_steps']>0)==(p in ['engineworker','engineall','enginecached','enginefull','enginetail','enginetailfair','enginefullfair','engineepoch','enginetailepoch']),(p,sample);assert(sample['activation_pool_hits']>0)==(p in ['enginepool','enginecached','enginepoolphase','enginefull','enginetail','enginetailfair','enginefullfair','engineepoch','enginetailepoch']),(p,sample);assert (sample['phase_gate_wait_ns']>0)==(p in ['enginephase','enginepoolphase','enginefull','enginetail','enginetailfair','enginefullfair','engineepoch','enginetailepoch']),(p,sample);assert sample['activation_pool_peak_bytes']<=8*1024*1024,(p,sample)
  (target/('verified_report.json'if reuse else'report.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps([{'status':x['status'],'rounds':[{k:s.get(k)for k in ['policy','pages_per_second','process_cpu_ms','prepared_blocks','executor_steps','executor_tail_steps','prefill_pack_calls','prefill_pack_reuse_hits','decode_pack_calls','decode_pack_reuse_hits','vision_pack_calls','vision_pack_reuse_hits','attention_batch_calls','attention_batch_rows','attention_batch_kernel_calls','stream_forward_splits','shared_core_weight_hits','shared_core_weight_misses','shared_core_weight_bytes','wide_projection_tiles','wide_mpp_projections','wide_mpp_heads','standalone_wide_heads','single_frame_steps','single_frame_topology_mismatches','epoch_auxiliary','auxiliary_acquisitions','epoch_page_joins','admission_pressures','phase_priority_yields','phase_fair','average_decode_rows','activation_pool_hits','activation_pool_peak_bytes','activation_pool_duplicate_retirements','framed_runtime_totals']}for s in (x.get('policy_rounds') or [])]}for x in report['results']]),flush=True)
 print('DONE',key,res.returncode,flush=True)
 if res.returncode:sys.exit(res.returncode)
