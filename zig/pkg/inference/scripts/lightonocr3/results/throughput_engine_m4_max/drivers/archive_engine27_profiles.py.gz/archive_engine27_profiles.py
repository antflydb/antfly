from pathlib import Path
import json,hashlib,gzip,collections
s=Path('.venv-lighton-vllm-metal/archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")]);folders=sorted(out.glob('engine27_4b_ready_*'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
archive('qualification',[Path('/private/tmp/ocr-engine27-profiles-driver.txt')]+[Path('/private/tmp')/('ocr-'+folder.name.replace('_4b_','-4b-',1).replace('engine27_','engine27-',1)+'.txt')for folder in []],'logs_manifest.json')
# Explicit completed per-profile driver logs; exclude the ongoing load check.
archive('qualification',[Path('/private/tmp/ocr-engine27-4b-'+folder.name.split('engine27_4b_',1)[1]+'.txt')for folder in folders],'logs_manifest.json')
records=[];index=out/'raw_logs_manifest.json';mapping=json.loads(index.read_text())
for folder in folders:
 p=folder/'report.json';d=json.loads(p.read_text());r=d['results'][0];assert r['status']=='ok'and r['serial_reference_parity']and r['cross_runtime_content_parity']and not d['own_cpu_compile_overlap'];s=r['policy_rounds'][0];assert s['completed']==128and not s['admission_pressures'];records.append(dict(report=str(p.relative_to(out)),sha256=sha(p),pages_per_second=s['pages_per_second'],completed=128,exact_native_and_cross_runtime_text=True,physical_rows=d['physical_rows'],vision_frame_blocks=d['vision_frame_blocks'],prefill_wait_us=d['prefill_wait_us'],prefill_group_sizes=dict(collections.Counter(x['items']for x in s['prefill_batches'])),framed_runtime_totals=s['framed_runtime_totals']))
 for p in folder.glob('*.txt'):
  raw=p.read_bytes();dest=p.with_name(p.name+'.gz');packed=gzip.compress(raw,mtime=0);dest.write_bytes(packed);assert gzip.decompress(packed)==raw;mapping[str(p.relative_to(out))]={'compressed_path':str(dest.relative_to(out)),'raw_sha256':hashlib.sha256(raw).hexdigest(),'raw_bytes':len(raw),'compressed_sha256':sha(dest)};p.unlink()
index.write_text(json.dumps(mapping,indent=2)+'\n');(out/'engine27_comparison_audit.json').write_text(json.dumps(dict(scope='Qualified runtime, no fresh repeated vLLM win. Readiness correctness fix and large pack reuse do not establish end-to-end speedup. Load-check controls run separately.',reports=records),indent=2)+'\n')
archive('drivers',[v/'archive_engine27_profiles.py'],'drivers_manifest.json');print('archived',len(records),'complete native profiles; ongoing load-check files excluded')
