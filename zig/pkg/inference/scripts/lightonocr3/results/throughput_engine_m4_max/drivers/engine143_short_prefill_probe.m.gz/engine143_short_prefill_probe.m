#define main unused_prefill143_main
#include "engine143_short_prefill_checks.m"
#undef main
int main(int argc,const char**argv){@autoreleasepool{
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_ATTENTION_MPP","1",1);
 bool benchmark=argc==2&&strcmp(argv[1],"--benchmark")==0;
 const size_t shortq[]={1,2,3,4,7,8,15,16,17,22,31,42,48,63,64,65,95,127};
 if(!benchmark){
  for(size_t h=8;h<=16;h+=8)for(size_t i=0;i<sizeof(shortq)/sizeof(shortq[0]);i++){
   int rc=check(r,shortq[i],512,h,128,i%2,0,false);if(rc){fprintf(stderr,"SHORT143_FAIL heads=%zu q=%zu rc=%d\n",h,shortq[i],rc);return rc+10;}
  }
  const size_t poisonq[]={2,17,42,127};for(size_t h=8;h<=16;h+=8)for(size_t i=0;i<4;i++)for(int poison=1;poison<=4;poison++){
   int rc=check(r,poisonq[i],63,h,i%2?8:16,true,poison,false);if(rc){fprintf(stderr,"SHORT143_POISON_FAIL heads=%zu q=%zu poison=%d rc=%d\n",h,poisonq[i],poison,rc);return rc+40;}
  }
  fprintf(stderr,"SHORT143 FULL OUTPUT CPU FRAGMENTED OFFSET CANARY CANCEL NONFINITE CHECKS PASS\n");
 }else{
  const size_t qs[]={2,8,16,22,42,48,64,96,127};for(size_t h=8;h<=16;h+=8)for(size_t i=0;i<sizeof(qs)/sizeof(qs[0]);i++){
   int rc=check(r,qs[i],512,h,128,false,0,true);if(rc)return rc+80;
  }
  fprintf(stderr,"SHORT143 BALANCED SHORT-PREFIX TIMINGS PASS\n");
 }
 termite_metal_decode_runtime_destroy(r);return 0;
}}
