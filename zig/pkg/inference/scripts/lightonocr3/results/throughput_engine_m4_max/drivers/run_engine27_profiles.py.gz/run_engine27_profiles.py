from pathlib import Path
import os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');base=os.environ.copy();base.update(OCR_REFERENCE_LABEL='_primary_reference8_r0_auto_c32_r128',OCR_PHYSICAL32='1',OCR_REQUESTS='128',OCR_WIDE='1',OCR_SCRATCH_GIB='8',OCR_STREAM_FIRST='0',OCR_SINGLE_FRAME='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1',OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_VISION_BATCH='0')
for label,c,vf,wait in [('ready_prefill1s_vision1',32,1,1000000),('ready_prefill100ms_vision1',32,1,100000),('ready_prefill1s_vision2',24,2,1000000)]:
 env=base.copy();env.update(OCR_CONCURRENCY=str(c),OCR_VISION_FRAME_BLOCKS=str(vf),OCR_PREFILL_WAIT_US=str(wait))
 print('START',label,c,flush=True)
 r=subprocess.run([sys.executable,str(v/'run_engine27_policies.py'),'4b:'+label+f'_f32_c{c}_r128_0'],env=env)
 print('DONE',label,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
