from pathlib import Path
p=Path('zig/pkg/inference/src/backends/metal_runtime.zig');s=p.read_text();s+='''
// Scoped by MetalCompute's decode batch. Every error path aborts collection;
// the owning forward retains responsibility for draining its frame.
pub extern fn termite_metal_decode_runtime_lighton_attention_batch_begin(runtime: ?*RawMetalDecodeRuntime) c_int;
pub extern fn termite_metal_decode_runtime_lighton_attention_batch_end(runtime: ?*RawMetalDecodeRuntime) c_int;
pub extern fn termite_metal_decode_runtime_lighton_attention_batch_abort(runtime: ?*RawMetalDecodeRuntime) void;
pub extern fn termite_metal_decode_runtime_lighton_attention_batch_stats(runtime: ?*RawMetalDecodeRuntime, out: *[2]u64) void;
''';p.write_text(s)
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text().replace('    lighton_stream_first_layers: u8 = 0,','    lighton_stream_first_layers: u8 = 0,\n    lighton_batch_attention: bool = false,',1)
idx=s.index('    pub fn setLightOnStreamFirstLayers(')
s=s[:idx]+'''    pub fn setLightOnBatchAttention(cb: *const ops.ComputeBackend, enabled: bool) !void {
        if (cb.kind() != .metal) return error.RuntimeUnavailable;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        self.lighton_batch_attention = enabled and self.lightonocr3_projections and metal_runtime_mod.qualifiedM4DeviceDefault();
    }

    pub fn lightOnBatchAttentionStats(cb: *const ops.ComputeBackend) [2]u64 {
        if (cb.kind() != .metal) return @splat(0);
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        var result: [2]u64 = @splat(0);
        metal_runtime_mod.termite_metal_decode_runtime_lighton_attention_batch_stats(self.provider_impl.raw_decode_runtime, &result);
        return result;
    }

'''+s[idx:]
# Keep the production vtable signature unchanged; a private destination view
# lets the collector write directly into the batch tensor.
idx=s.index('    fn gqaPagedAttentionOp(');a=s[:idx];b=s[idx:]
sig=b[:b.index('        const self: *MetalCompute')]
wrapper=sig+'''        return gqaPagedAttentionIntoOp(ctx, Q, K, V, attn_bias, attention, batch, num_heads, num_kv_heads, head_dim, null);
    }

'''
newsig=sig.replace('fn gqaPagedAttentionOp(', 'fn gqaPagedAttentionIntoOp(').replace('        head_dim: usize,\n', '        head_dim: usize,\n        destination: ?MetalTensor,\n')
b=wrapper+newsig+b[len(sig):]
# Before per-page loop establish bounded collector. Its abort is unconditional
# and idempotent, covering recursive failures and successful completion.
needle='''            for (0..batch) |b| {
                const view = kv_batch[b];'''
repl='''            const collect_attention = self.lighton_batch_attention and batch >= 2 and batch <= 16 and
                max_q_rows == 1 and !is_mixed and resident_output != null and !has_attention_sink and
                attention.mode == .paged_decode and metal_runtime.hasActiveFrame(self.provider_impl.raw_decode_runtime);
            if (collect_attention and metal_runtime.termite_metal_decode_runtime_lighton_attention_batch_begin(self.provider_impl.raw_decode_runtime) != 0)
                return error.MetalAttentionBatchFailed;
            defer if (collect_attention) metal_runtime.termite_metal_decode_runtime_lighton_attention_batch_abort(self.provider_impl.raw_decode_runtime);

            for (0..batch) |b| {
                const view = kv_batch[b];'''
assert needle in b;b=b.replace(needle,repl,1)
needle='''                const item_ct = try gqaPagedAttentionOp(ctx, q_slice, k_slice, v_slice, null, item_attention, 1, num_heads, num_kv_heads, head_dim);'''
repl='''                var target: ?MetalTensor = null;
                defer if (target) |*tensor| tensor.deinit();
                if (collect_attention) {
                    const parent = toBuf(resident_output.?).metal_tensor.?;
                    const shape = [_]i32{ 1, @intCast(h_q) };
                    target = try parent.retainedView(b * q_span * @sizeOf(f32), q_span * @sizeOf(f32), &shape);
                }
                const item_ct = try gqaPagedAttentionIntoOp(ctx, q_slice, k_slice, v_slice, null, item_attention, 1, num_heads, num_kv_heads, head_dim, target);'''
assert needle in b;b=b.replace(needle,repl,1)
b=b.replace('''                if (resident_output) |tensor| {
                    if (!try copyRows2DOp''','''                if (resident_output) |tensor| {
                    if (collect_attention) {
                        // Every collected page must use the supplied destination.
                        // A canonical fallback may have produced a separate tensor;
                        // encoding its copy now could race deferred attention.
                        const actual = toBuf(item_ct).metal_tensor orelse return error.MetalAttentionBatchFailed;
                        if (actual.deviceHandle() != target.?.deviceHandle() or actual.deviceByteOffset() != target.?.deviceByteOffset()) return error.MetalAttentionBatchFailed;
                        continue;
                    }
                    if (!try copyRows2DOp''',1)
b=b.replace('''            if (resident_output) |tensor| return tensor;''','''            if (collect_attention and metal_runtime.termite_metal_decode_runtime_lighton_attention_batch_end(self.provider_impl.raw_decode_runtime) != 0)
                return error.MetalAttentionBatchFailed;
            if (resident_output) |tensor| return tensor;''',1)
# Both normal same-runtime and donated slot routes may receive the destination.
start=b.index('        if (batch != 1)');before=b[:start];rest=b[start:];end=rest.index('    fn ',10) if '    fn ' in rest[10:] else len(rest)
# Add to the two active-frame request types only. Locate normal slot_request and cross frame branches.
rest=rest.replace('''                            const slot_request = .{
                                .q = q_mt,''','''                            const slot_request = .{
                                .destination = destination,
                                .q = q_mt,''',1)
rest=rest.replace('''                                            .{
                                                .q = q_mt,''','''                                            .{
                                                .destination = destination,
                                                .q = q_mt,''',1)
b=before+rest;s=a+b;p.write_text(s)
# Both bridge helpers validate exact destination geometry and retain a view.
p=Path('zig/pkg/inference/src/backends/metal_runtime.zig');s=p.read_text()
for func,runtime in [('fn decoderRuntimeApplyPagedKvAttentionSlotOnRuntimeWithFlush(', 'runtime'),('pub fn decoderRuntimeApplyPagedKvAttentionSlotOnFrame(', 'frame_runtime')]:
    idx=s.index(func);end=s.index('\n}',idx)+2;a=s[:idx];part=s[idx:end];z=s[end:]
    old=f'''    var output = try MetalTensor.deviceAllocate(
        @ptrCast({runtime}),
        q_rows * attention_input_size * @sizeOf(f32),
        .private,
        &attention_shape,
    );'''
    new=f'''    const destination: ?MetalTensor = if (@hasField(@TypeOf(request), "destination")) request.destination else null;
    const output_bytes = q_rows * attention_input_size * @sizeOf(f32);
    var output = if (destination) |target| blk: {{
        if (!target.isDevice() or target.elemCount() != q_rows * attention_input_size or target.deviceByteLen() != output_bytes) return error.InvalidAttentionShape;
        break :blk try target.retainedView(0, output_bytes, &attention_shape);
    }} else try MetalTensor.deviceAllocate(@ptrCast({runtime}), output_bytes, .private, &attention_shape);'''
    assert old in part,func;part=part.replace(old,new,1);s=a+part+z
p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text().replace('            stream_first_layers: u8 = 0,','            stream_first_layers: u8 = 0,\n            batch_attention: bool = false,',1)
s=s.replace('                    .shared_core_weights = epoch_auxiliary', '                    .batch_attention = epoch_auxiliary and platform.env.getenvBool("ANTFLY_LIGHTONOCR3_BATCH_ATTENTION"),\n                    .shared_core_weights = epoch_auxiliary',1)
s=s.replace('                if (features.stream_first_layers != 0) {','''                if (features.batch_attention) {
                    // Two 9 MiB banks permit one submitted prefix plus one
                    // active suffix without reusing in-flight attention scratch.
                    amounts.backend_scratch_bytes += 18 * 1024 * 1024;
                    amounts.host_scratch_bytes += 1024 * 1024;
                }
                if (features.stream_first_layers != 0) {''',1)
s=s.replace('or features.stream_first_layers != 0);','or features.stream_first_layers != 0 or features.batch_attention);',1)
s=s.replace('                    try M.setLightOnStreamFirstLayers(&cb, ctx.features.stream_first_layers);','                    try M.setLightOnStreamFirstLayers(&cb, ctx.features.stream_first_layers);\n                    try M.setLightOnBatchAttention(&cb, ctx.features.batch_attention);',1)
needle='                    const stream_splits = if (comptime build_options.enable_metal)'
idx=s.index(needle);s=s[:idx]+'''                    const attention_batch = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnBatchAttentionStats(&cb) else @as([2]u64, @splat(0));
                    std.debug.print("LIGHTONOCR3 attention_batch_calls={d} attention_batch_rows={d}\\n", .{ attention_batch[0], attention_batch[1] });
'''+s[idx:]
s+='''
test "LightOnOCR3 batched attention reserves two disjoint frame scratch banks" {
    const features = Node.LightOnStreamContext.ExecutionFeatures{ .epoch_auxiliary = true, .batch_attention = true };
    try std.testing.expect(features.needsAuxiliary());
    const amounts = features.auxiliaryAmounts();
    try std.testing.expectEqual(@as(usize, 18 * 1024 * 1024), amounts.backend_scratch_bytes);
    try std.testing.expectEqual(@as(usize, 1024 * 1024), amounts.host_scratch_bytes);
}
''';p.write_text(s)
