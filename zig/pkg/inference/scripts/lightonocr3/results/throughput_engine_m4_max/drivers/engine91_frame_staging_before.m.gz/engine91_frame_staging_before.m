#include "engine91_before_kernels.m"
#include "engine91_frame_staging_lifetime.inc"
int main(void) { @autoreleasepool { fprintf(stderr,"RUNTIME_BYTES=%zu\n",sizeof(termite_metal_decode_runtime)); return engine91_frame_staging_lifetime_check(); } }
