from pathlib import Path
import hashlib,json,re
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
f=json.loads((v/'engine48-freeze.json').read_text())
for name,h in f.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h,name
base=Path('zig/pkg/inference/src/backends/metal_kernels.m').read_text()
private=base.replace('#include "metal_', '#include "../zig/pkg/inference/src/backends/metal_')
# Private dispatch geometry follows actual selected pipeline, not the old 16-row default.
old='runtime->lightonocr3_prefill_attention_mpp32_pipeline ? 32 : 16;'
assert private.count(old)==1
private=private.replace(old,'runtime->lightonocr3_prefill_attention_mpp32_pipeline || [runtime->lightonocr3_prefill_attention_direct_pipeline.label hasSuffix:@"_q32"] ? 32 : 16;')
(v/'engine49_attention_runtime.m').write_text(private)
a=base.index('        "kernel void termite_lightonocr3_prefill_attention_direct16_64(')
b=base.index('        "struct Params { uint rows;',a)
kernel=''.join(json.loads(x.strip()) for x in base[a:b].splitlines())
prefix=(v/'prefill_direct64_16.metal').read_text().split('kernel void')[0]
prefix=prefix[prefix.index('#include'):].replace('struct Params','struct LightOnPrefillParams')
specs=[(16,64,False),(16,64,True),(32,64,True),(16,128,True),(32,128,True)]
sources=[]
for i,(qt,kt,alias)in enumerate(specs):
 s=kernel.replace('termite_lightonocr3_prefill_attention_direct16_64',f'engine49_v{i}_q{qt}')
 s=s.replace('group.x * 16','group.x * QT').replace('scores[16 * 64], prob[16 * 64], maxima[16], denom[16], correction[16]','scores[QT * KT], '+(''if alias else'prob[QT * KT], ')+'maxima[QT], denom[QT], correction[QT]')
 if alias:s=s.replace('    threadgroup atomic_uint nonfinite_v;','    threadgroup float *prob = scores;\n    threadgroup atomic_uint nonfinite_v;')
 s=s.replace('tid < 16','tid < QT').replace('dextents<int, 2>(16, 16)','dextents<int, 2>(16, QT)').replace('array<int, 2>{1, 64}','array<int, 2>{1, KT}')
 s=s.replace('matmul2d_descriptor(16, 16, 256','matmul2d_descriptor(QT, 16, 256').replace('matmul2d_descriptor(16, 64, 16','matmul2d_descriptor(QT, 64, 16')
 s=s.replace('q0 + 16','q0 + QT').replace('start += 64','start += KT')
 begin=s.index('        uint key = start + sg * 16,')
 end=s.index('        threadgroup_barrier(mem_flags::mem_threadgroup);',begin)
 block=s[begin:end]
 block=block.replace('start + sg * 16','start + sg * 16 + key_pass * 64').replace('dots.store(S);','tensor<threadgroup float, dextents<int, 2>, tensor_inline> Sstep(scores + sg * 16 + key_pass * 64, dextents<int, 2>(16, QT), array<int, 2>{1, KT});\n            dots.store(Sstep);').replace('i < 16 * 16','i < QT * 16').replace('(i / 16) * 64 + sg * 16','(i / 16) * KT + sg * 16 + key_pass * 64')
 s=s[:begin]+'        for (uint key_pass = 0; key_pass < KT / 64; key_pass++) {\n'+block+'        }\n'+s[end:]
 s=s.replace('pass < 16 / 4','pass < QT / 4').replace('float x[2]','float x[KT / 32]').replace('j < 2','j < KT / 32')
 s=s.replace('row * 64','row * KT').replace('i < 64 * 256','i < KT * 256').replace('part < 64 / 16','part < KT / 16').replace('dextents<int, 2>(count, 16)','dextents<int, 2>(count, QT)').replace('t < 64 &&','t < KT &&')
 s=f'#define QT {qt}\n#define KT {kt}\n'+prefix+s
 p=v/f'engine49_attention_v{i}.metal';assert not p.exists();p.write_text(s);sources.append(p)
wrapper=r'''
#include "engine49_attention_runtime.m"
static NSString *sources[] = {
SOURCES
};
typedef struct { termite_metal_decode_runtime *r; id<MTLComputePipelineState> psos[5]; id<MTLBuffer> q[8], k[8], v[8], y[8]; uint32_t *blocks; size_t n,heads,kh,nb; } Probe49;
void *probe49_create(size_t n,size_t heads,const float*q,const uint16_t*k,const uint16_t*v) {
 @autoreleasepool {
 Probe49*b=calloc(1,sizeof(*b));if(!b)return NULL;
 b->r=termite_metal_decode_runtime_create();if(!b->r)return NULL;
 termite_metal_decode_runtime_set_lightonocr3_projections(b->r,1);
 termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(b->r,1);
 b->psos[0]=b->r->lightonocr3_prefill_attention_direct_pipeline;
 for(int mode=1;mode<5;mode++){
  MTLCompileOptions *opt=[MTLCompileOptions new];opt.languageVersion=MTLLanguageVersion4_0;opt.mathMode=MTLMathModeSafe;
  NSError*err=nil;id<MTLLibrary>lib=[b->r->device newLibraryWithSource:sources[mode] options:opt error:&err];
  if(!lib){fprintf(stderr,"%s\n",err.localizedDescription.UTF8String);return NULL;}
  NSString*name=[NSString stringWithFormat:@"engine49_v%d_q%d",mode,(mode==2||mode==4)?32:16];
  b->psos[mode]=termite_metal_make_pipeline(b->r->device,lib,name);if(!b->psos[mode])return NULL;
  b->psos[mode].label=name;
  fprintf(stderr,"PIPELINE mode=%d shared_bytes=%lu\n",mode,(unsigned long)b->psos[mode].staticThreadgroupMemoryLength);
 }
 b->n=n;b->heads=heads;b->kh=heads/4;b->nb=(n+127)/128;b->blocks=calloc(b->nb,4);
 for(size_t p=0;p<b->nb;p++)b->blocks[p]=(b->nb-1-p)*128;
 size_t qs=n*heads*256,ks=n*b->kh*256;
 for(int z=0;z<8;z++){
 b->q[z]=[b->r->device newBufferWithLength:(qs+32)*4 options:MTLResourceStorageModeShared];
 b->k[z]=[b->r->device newBufferWithLength:b->nb*128*b->kh*256*2 options:MTLResourceStorageModeShared];
 b->v[z]=[b->r->device newBufferWithLength:b->k[z].length options:MTLResourceStorageModeShared];
 b->y[z]=[b->r->device newBufferWithLength:(qs+32)*4 options:MTLResourceStorageModeShared];
 if(!b->q[z]||!b->k[z]||!b->v[z]||!b->y[z])return NULL;
 memcpy((float*)b->q[z].contents+16,q+z*qs,qs*4);
 for(size_t t=0;t<n;t++){
 size_t physical=b->blocks[t/128]+t%128;
 memcpy((uint16_t*)b->k[z].contents+physical*b->kh*256,k+z*ks+t*b->kh*256,b->kh*256*2);
 memcpy((uint16_t*)b->v[z].contents+physical*b->kh*256,v+z*ks+t*b->kh*256,b->kh*256*2);
 }
 for(size_t j=0;j<qs+32;j++)((float*)b->y[z].contents)[j]=-12345.0f;
 }
 return b;
 }
}
int probe49_run(void*raw,int mode,double*us){
 @autoreleasepool{
 Probe49*b=raw;if(mode<0||mode>=5)return -9;
 b->r->lightonocr3_prefill_attention_direct_pipeline=b->psos[mode];
 uint64_t calls=b->r->lightonocr3_prefill_attention_direct_dispatches;
 if(termite_metal_decode_runtime_begin_frame(b->r))return -1;
 for(int z=0;z<8;z++){
 b->r->attention_span_encoded_key_buffers[7]=b->k[z];b->r->attention_span_v_buffers[7]=b->v[z];
 b->r->attention_span_slot_key_row_bytes[7]=b->kh*256*2;b->r->attention_span_slot_v_row_stride[7]=b->kh*256;
 if(termite_metal_decode_runtime_attention_paged_slot_device(b->r,7,3,(__bridge void*)b->q[z],64,b->blocks,b->nb,128,b->n,b->n,b->heads,b->kh,256,b->kh*256*2,b->kh*256*2,0,0,0,0,NULL,0,(__bridge void*)b->y[z],64))return -2;
 }
 if(termite_metal_decode_runtime_submit_frame(b->r)||termite_metal_decode_runtime_wait_frame(b->r))return -3;
 if(b->r->lightonocr3_prefill_attention_direct_dispatches!=calls+8)return -4;
 *us=b->r->last_frame_gpu_nanos/1000.0;
 size_t qs=b->n*b->heads*256;
 for(int z=0;z<8;z++)for(int j=0;j<16;j++)if(((float*)b->y[z].contents)[j]!=-12345.0f||((float*)b->y[z].contents)[16+qs+j]!=-12345.0f)return -5;
 return 0;
 }
}
const float*probe49_output(void*raw,int z){Probe49*b=raw;return (float*)b->y[z].contents+16;}
void probe49_destroy(void*raw){
 if(!raw)return;Probe49*b=raw;termite_metal_decode_runtime_destroy(b->r);
 for(int z=0;z<8;z++){b->q[z]=nil;b->k[z]=nil;b->v[z]=nil;b->y[z]=nil;}
 for(int i=0;i<5;i++)b->psos[i]=nil;free(b->blocks);free(b);
}
'''
literals=[ '@""\n'+''.join(' '+json.dumps(x+'\n')+'\n'for x in p.read_text().splitlines()) for p in sources ]
wrapper=wrapper.replace('SOURCES',',\n'.join(literals))
(v/'engine49_attention_probe.m').write_text(wrapper)
inputs=[v/'engine49_attention_runtime.m',v/'engine49_attention_probe.m',*sources]
record=dict(status='prepared_not_built',runtime_base_sha256=f['zig/pkg/inference/src/backends/metal_kernels.m'],specs=specs,inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in inputs},scope='Private F32 attention score/probability alias and Q/K tile experiment. Eight distinct layer buffers in each frame, production F32 Q/probability/accumulation/output and F16 KV unchanged. Baseline is current actual runtime PSO. No primary comparison or speed claim.')
(out/'engine49_attention_probe_preparation.json').write_text(json.dumps(record,indent=2)+'\n')
print('prepared',len(inputs),'inputs')
