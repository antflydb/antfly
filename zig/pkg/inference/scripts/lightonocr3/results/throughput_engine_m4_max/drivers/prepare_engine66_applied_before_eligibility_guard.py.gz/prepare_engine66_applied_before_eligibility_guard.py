from pathlib import Path
import hashlib,json
root=Path.cwd();v=root/'.venv-lighton-vllm-metal'
for p,h in json.loads((v/'engine65-freeze.json').read_text()).items():
    assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p

def edit(name,fn):
    p=root/name;old=p.read_text();(v/('engine65-before66-'+p.name)).write_bytes(p.read_bytes());new=fn(old);assert old!=new,name;p.write_text(new)

def projector(s):
    a=s.index('const VisionFrameGroup = struct {');b=s.index('\nfn qwen3VlProfileEnabled()',a)
    s=s[:a]+'''const VisionFrameGroup = struct {
    cb: *const ComputeBackend,
    blocks: usize,
    streamed: bool = false,
    owns_frame: bool = false,
    held: [4]?CT = @splat(null),
    count: usize = 0,
    pending: [4]?CT = @splat(null),
    pending_count: usize = 0,
    submitted: bool = false,
    submits: usize = 0,
    waits: usize = 0,
    overlaps: usize = 0,

    fn begin(self: *@This(), enabled: bool) !void {
        if (self.owns_frame) return;
        if (self.streamed and !self.submitted and self.cb.decoderRuntimeHasSubmittedFrame()) return error.PreparedVisionUnavailable;
        if (!enabled or self.cb.decoderRuntimeHasActiveFrame()) {
            if (self.streamed) return error.PreparedVisionUnavailable;
            return;
        }
        self.owns_frame = try self.cb.decoderRuntimeBeginFrame();
        if (self.streamed and !self.owns_frame) return error.PreparedVisionUnavailable;
        if (self.owns_frame and self.submitted) self.overlaps += 1;
    }

    fn release(self: *@This()) void {
        for (self.held[0..self.count]) |tensor| self.cb.free(tensor.?);
        self.count = 0;
    }

    fn releasePending(self: *@This()) void {
        for (self.pending[0..self.pending_count]) |tensor| self.cb.free(tensor.?);
        self.pending_count = 0;
    }

    fn wait(self: *@This()) !void {
        if (!self.submitted) return;
        try self.cb.decoderRuntimeWaitSubmittedFrame();
        self.submitted = false;
        self.waits += 1;
        self.releasePending();
    }

    fn finishBlock(self: *@This(), previous: CT, last: bool) !void {
        if (!self.owns_frame) {
            self.cb.free(previous);
            return;
        }
        self.held[self.count] = previous;
        self.count += 1;
        if (self.count == self.blocks or last) {
            if (self.streamed) {
                // The active group's commands are encoded while its producer
                // executes. Drain that producer before rotating either bank.
                try self.wait();
                try self.cb.decoderRuntimeSubmitFrame();
                self.owns_frame = false;
                self.submitted = true;
                @memcpy(self.pending[0..self.count], self.held[0..self.count]);
                self.pending_count = self.count;
                self.count = 0;
                self.submits += 1;
                if (last) try self.wait();
            } else {
                try self.cb.decoderRuntimeSubmitAndWaitFrame();
                self.owns_frame = false;
                self.submits += 1;
                self.release();
            }
        }
    }

    fn deinit(self: *@This()) void {
        if (self.owns_frame) self.cb.decoderRuntimeCancelFrame() catch {};
        self.owns_frame = false;
        // The active group's input can be an output of the submitted group.
        // Neither set may retire before that producer completes, even on error.
        if (self.submitted) self.cb.decoderRuntimeWaitSubmittedFrame() catch {};
        self.submitted = false;
        self.releasePending();
        self.release();
    }
};
''' +s[b:]
    s=s.replace('    metal_frame_blocks: u8 = 1,','''    metal_frame_blocks: u8 = 1,
    /// One submitted plus one active group. Charge both complete envelopes.
    /// Restricted to one/two blocks per group; total retained blocks <= four.
    metal_frame_pipeline: bool = false,

    pub fn retainedFrameBlocks(self: Limits) usize {
        return @as(usize, self.metal_frame_blocks) * (if (self.metal_frame_pipeline) @as(usize, 2) else 1);
    }
''')
    s=s.replace('self.metal_frame_blocks == 0 or self.metal_frame_blocks > 4)', 'self.metal_frame_blocks == 0 or self.metal_frame_blocks > 4 or\n            (self.metal_frame_pipeline and self.metal_frame_blocks > 2))')
    s=s.replace('admissionMul(host_scratch, limits.metal_frame_blocks)', 'admissionMul(host_scratch, limits.retainedFrameBlocks())').replace('admissionMul(backend_scratch, limits.metal_frame_blocks)', 'admissionMul(backend_scratch, limits.retainedFrameBlocks())')
    s=s.replace('VisionFrameGroup{ .cb = cb, .blocks = limits.metal_frame_blocks }', 'VisionFrameGroup{ .cb = cb, .blocks = limits.metal_frame_blocks, .streamed = limits.metal_frame_pipeline }')
    s=s.replace('if (limits.metal_frame_blocks > 1 and platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3"))', 'if ((limits.metal_frame_blocks > 1 or limits.metal_frame_pipeline) and platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3"))')
    # Both entry points drain the last group before final normalization/merge.
    for needle in ['.{ limits.metal_frame_blocks, frame_group.submits, prepared_images.len });', '.{ limits.metal_frame_blocks, frame_group.submits });']:
        assert needle in s,needle
        s=s.replace(needle,needle+'''\n    if (limits.metal_frame_pipeline and platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3"))
        std.debug.print("LIGHTONOCR3 vision_pipeline_enabled=1 vision_pipeline_submits={d} vision_pipeline_waits={d} vision_pipeline_overlaps={d}\\n", .{ frame_group.submits, frame_group.waits, frame_group.overlaps });''')
    # Direct diagnostic calls must not read a not-yet-submitted trace tensor.
    needle='    var frame_group = VisionFrameGroup{ .cb = cb, .blocks = limits.metal_frame_blocks, .streamed = limits.metal_frame_pipeline };'
    # Profiling/qualification trace requests keep the original synchronous path.
    # The doubled envelope remains conservative when streaming is declined.
    s=s.replace(needle, '    const stream_frames = limits.metal_frame_pipeline and !qwen3VlProfileEnabled() and platform.env.getenv("ANTFLY_QWEN3VL_QUALIFICATION_TRACE_LAYER") == null;\n'+needle.replace('.streamed = limits.metal_frame_pipeline','.streamed = stream_frames'))
    s=s.replace('    var deepstack_ns: u64 = 0;\n    const stream_frames = limits.metal_frame_pipeline', '    var deepstack_ns: u64 = 0;\n    const stream_frames = !collect_preprocess_evidence and limits.metal_frame_pipeline')
    s=s.replace('if (limits.metal_frame_pipeline and platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3"))', 'if (stream_frames and platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3"))')
    # Extend the existing dimension-sweep admission test with two complete banks.
    needle='            grouped_limits.metal_frame_blocks = 0;'
    assert needle in s
    s=s.replace(needle,'''            grouped_limits.metal_frame_blocks = 1;
            grouped_limits.metal_frame_pipeline = true;
            const streamed_one = try estimateAdmissionForImageDimensions(&.{image_dimensions}, config, grouped_limits);
            try std.testing.expectEqual(estimate.host_scratch_bytes * 2, streamed_one.host_scratch_bytes);
            try std.testing.expectEqual(estimate.backend_scratch_bytes * 2, streamed_one.backend_scratch_bytes);
            grouped_limits.metal_frame_blocks = 2;
            const streamed_two = try estimateAdmissionForImageDimensions(&.{image_dimensions}, config, grouped_limits);
            try std.testing.expectEqual(grouped.host_scratch_bytes, streamed_two.host_scratch_bytes);
            try std.testing.expectEqual(grouped.backend_scratch_bytes, streamed_two.backend_scratch_bytes);
            grouped_limits.metal_frame_blocks = 3;
            try std.testing.expectError(error.InvalidVisionLimits, grouped_limits.validate());
            grouped_limits.metal_frame_pipeline = false;
''' +needle)
    s+='''

test "Qwen3-VL vision pipeline drains both tensor banks on completion cancellation and failures" {
    const native_compute = @import("../ops/native_compute.zig");
    const Fake = struct {
        mode: usize,
        active: bool = false,
        submitted: bool = false,
        active_mask: u16 = 0,
        submitted_mask: u16 = 0,
        freed_mask: u16 = 0,
        submit_calls: usize = 0,
        wait_calls: usize = 0,
        failed_wait: bool = false,
        fn get(raw: *anyopaque) *@This() { return @ptrCast(@alignCast(raw)); }
        fn begin(raw: *anyopaque) !bool {
            const f = get(raw);
            if (f.mode == 4) return false;
            std.debug.assert(!f.active);
            f.active = true;
            return true;
        }
        fn hasActive(raw: *anyopaque) bool { return get(raw).active; }
        fn hasSubmitted(raw: *anyopaque) bool { return get(raw).submitted; }
        fn submit(raw: *anyopaque) !void {
            const f = get(raw);
            f.submit_calls += 1;
            if (f.mode == 2 and f.submit_calls == 2) return error.InjectedSubmitFailure;
            std.debug.assert(f.active and !f.submitted);
            f.submitted = true;
            f.active = false;
            f.submitted_mask = f.active_mask;
            f.active_mask = 0;
        }
        fn wait(raw: *anyopaque) !void {
            const f = get(raw);
            if (!f.submitted) return;
            f.wait_calls += 1;
            if (f.mode == 3 and !f.failed_wait) {
                f.failed_wait = true;
                return error.InjectedWaitFailure;
            }
            f.submitted = false;
            f.submitted_mask = 0;
        }
        fn submitWait(raw: *anyopaque) !void { try submit(raw); try wait(raw); }
        fn cancel(raw: *anyopaque) !void {
            const f = get(raw);
            f.active = false;
            f.active_mask = 0;
        }
        fn free(raw: *anyopaque, tensor: CT) void {
            const f = get(raw);
            const bit = @as(u16, 1) << @as(u4, @intCast(@intFromPtr(tensor)));
            // The previous group's output is also the active group's input.
            // Cancel alone cannot make that tensor safe to free.
            std.debug.assert((f.active_mask | f.submitted_mask | f.freed_mask) & bit == 0);
            f.freed_mask |= bit;
        }
    };
    for (0..6) |mode| {
        var fake = Fake{ .mode = mode };
        var table = native_compute.vtable_impl;
        table.freeTensor = Fake.free;
        table.decoderRuntimeBeginFrame = Fake.begin;
        table.decoderRuntimeHasActiveFrame = Fake.hasActive;
        table.decoderRuntimeHasSubmittedFrame = Fake.hasSubmitted;
        table.decoderRuntimeSubmitFrame = Fake.submit;
        table.decoderRuntimeWaitSubmittedFrame = Fake.wait;
        table.decoderRuntimeSubmitAndWaitFrame = Fake.submitWait;
        table.decoderRuntimeCancelFrame = Fake.cancel;
        const cb = ComputeBackend{ .ptr = &fake, .vtable = &table };
        var group = VisionFrameGroup{ .cb = &cb, .blocks = 2, .streamed = mode != 5 };
        var encoded: usize = 0;
        var failure: ?anyerror = null;
        for (0..6) |index| {
            group.begin(true) catch |err| { failure = err; break; };
            // Track the producer output as well as the input; the next group
            // borrows that output while the first producer is still in flight.
            fake.active_mask |= (@as(u16, 1) << @as(u4, @intCast(index + 1))) |
                (@as(u16, 1) << @as(u4, @intCast(index + 2)));
            encoded += 1;
            group.finishBlock(@ptrFromInt(index + 1), index == 5) catch |err| { failure = err; break; };
            if (mode == 1 and encoded == 3) break;
        }
        group.deinit();
        try std.testing.expect(!fake.active and !fake.submitted);
        try std.testing.expectEqual(@as(u16, 0), fake.active_mask | fake.submitted_mask);
        const expected = (@as(u16, 1) << @as(u4, @intCast(encoded + 1))) - 2;
        try std.testing.expectEqual(expected, fake.freed_mask);
        // The final/current output remains the caller's property.
        Fake.free(&fake, @ptrFromInt(encoded + 1));
        switch (mode) {
            0 => {
                try std.testing.expect(failure == null);
                try std.testing.expectEqual(@as(usize, 3), group.submits);
                try std.testing.expectEqual(group.submits, group.waits);
                try std.testing.expectEqual(@as(usize, 2), group.overlaps);
            },
            1 => try std.testing.expect(failure == null),
            2 => try std.testing.expectEqual(error.InjectedSubmitFailure, failure.?),
            3 => try std.testing.expectEqual(error.InjectedWaitFailure, failure.?),
            4 => try std.testing.expectEqual(error.PreparedVisionUnavailable, failure.?),
            5 => {
                try std.testing.expect(failure == null);
                try std.testing.expectEqual(@as(usize, 3), group.submits);
                try std.testing.expectEqual(@as(usize, 0), group.overlaps);
            },
            else => unreachable,
        }
    }
}
'''
    return s

def server(s):
    s=s.replace('            vision_frame_blocks: u8 = 1,','            vision_frame_blocks: u8 = 1,\n            pipeline_vision: bool = false,')
    needle='                features.stream_chunks = features.gpu_greedy_stream'
    assert needle in s
    s=s.replace(needle,'''                features.pipeline_vision = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_PIPELINE_VISION") and
                    metal_runtime.qualifiedM4DeviceDefault() and cfg.hasQwen35VisionArchitectureContract() and
                    features.resident_vision_budget and features.cpu_preprocess and features.epoch_auxiliary and
                    features.vision_batch_items == 1 and features.vision_frame_blocks <= 2 and
                    !platform.env.getenvBool("TERMITE_METAL_DISABLE_PIPELINED_DECODE_FRAME") and
                    !platform.env.getenvBool("TERMITE_METAL_DISABLE_QWEN35_VISION_FRAME") and
                    !platform.env.getenvBool("TERMITE_QWEN3VL_PROFILE") and
                    platform.env.getenv("ANTFLY_QWEN3VL_QUALIFICATION_TRACE_LAYER") == null;
''' +needle)
    needle='            fn auxiliaryAmounts(features: @This())'
    assert needle in s
    s=s.replace(needle,'''            fn visionRetainedBlocks(features: @This()) usize {
                return @as(usize, features.vision_frame_blocks) * (if (features.pipeline_vision) @as(usize, 2) else 1);
            }
''' +needle)
    s=s.replace('            limits.metal_frame_blocks = ctx.features.vision_frame_blocks;', '            limits.metal_frame_blocks = ctx.features.vision_frame_blocks;\n            limits.metal_frame_pipeline = ctx.features.pipeline_vision;')
    s=s.replace('vision_amounts.backend_scratch_bytes, features.vision_frame_blocks)', 'vision_amounts.backend_scratch_bytes, features.visionRetainedBlocks())')
    s=s.replace('memory.visionFrameHostPeak(features.vision_frame_blocks,', 'memory.visionFrameHostPeak(features.visionRetainedBlocks(),')
    return s

def benchmark(s):
    needle='    env["ANTFLY_LIGHTONOCR3_GPU_TOKEN_BURST"]'
    a=s.index(needle)
    s=s[:a]+'''    env["ANTFLY_LIGHTONOCR3_PIPELINE_VISION"] = "1" if args.pipeline_vision else "0"
    if args.pipeline_vision:
        env["ANTFLY_LIGHTONOCR3_CPU_PREPROCESS"] = "1"
        env["TERMITE_METAL_ENABLE_PIPELINED_DECODE_FRAME"] = "1"
''' +s[a:]
    needle='    args = parser.parse_args()'
    a=s.index(needle)
    s=s[:a]+'''    parser.add_argument("--pipeline-vision", action="store_true", help="Overlap two fully admitted resident vision frame groups")
''' +s[a:]
    s=s.replace(needle,needle+'''\n    if args.pipeline_vision and (not args.continuous or not args.resident_vision_budget or args.vision_batch):
        parser.error("--pipeline-vision requires continuous resident vision with single-image groups")''')
    s=s.replace('        "resident_vision_budget": args.resident_vision_budget,','        "resident_vision_budget": args.resident_vision_budget,\n        "pipeline_vision": args.pipeline_vision,')
    return s

edit('zig/pkg/inference/src/architectures/qwen3vl_projector.zig',projector)
edit('zig/pkg/inference/src/server/server.zig',server)
edit('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py',benchmark)
print('Engine66 vision pipeline proposal applied; unqualified')
