from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name in ['run_engine85_verify3_gpu_build.py','run_engine85_metal_disabled.py']:
 p=v/name.replace('85','90');assert not p.exists();p.write_text((v/name).read_text().replace('engine85','engine90').replace('ENGINE85','ENGINE90'))
s=(v/'run_engine85_qualification_verify3.py').read_text().replace('engine85','engine90').replace('ENGINE85','ENGINE90');s=s.replace('Only exact integer CPU horizontal resizing and the Zig private BF16 scratch capacity change.','Only Zig test harness precision rounds and untimed lifetime gauges change after source85. Its exact integer CPU horizontal resizing and two-byte private BF16 scratch are retained.')
p=v/'run_engine90_qualification.py';assert not p.exists();p.write_text(s)
f=json.loads((v/'engine85-freeze.json').read_text());p=v/'engine90-freeze.json';assert not p.exists();p.write_text(json.dumps({f:sha(r/f)for f in f},indent=2)+'\n')
p=v/'engine90_benchmark_concurrency.py';assert not p.exists();p.write_bytes((r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
s=(v/'run_engine85_budget_policies.py').read_text().replace('engine85','engine90')
needle=" if os.environ.get('OCR_PREFILL_FFN_ROUNDS'):";assert s.count(needle)==1
s=s.replace(needle," if os.environ.get('OCR_BF16_ROUNDS'):\n  cmd+=['--bf16-projection-rounds',*os.environ['OCR_BF16_ROUNDS'].split(',')]\n if os.environ.get('OCR_REQUIRE_MEMORY_ROUNDS','0')=='1':cmd+=['--require-memory-rounds']\n"+needle)
a=s.index('   for sample,section in zip(');b=s.index("  (target/'report.json').write_text",a)
part=s[a:b];needle='    assert';idx=part.index(needle);part=part[:idx]+"    round_bf16=sample.get('bf16_projection_enabled',bf16)\n"+part[idx:];part=part.replace('if bf16:','if round_bf16:').replace('not bf16','not round_bf16').replace('bf16 and','round_bf16 and').replace('bf16 or','round_bf16 or').replace(' or bf16)', ' or round_bf16)').replace(' or bf16:',' or round_bf16:')
# A precision ablation may reach fewer than64 active rows; require the full64 kernel only when observed.
part=part.replace("and not round_bf16),sample","and not round_bf16 and max(sample['packed_core_rows_observed'],default=0)==64),sample")
s=s[:a]+part+s[b:];p=v/'run_engine90_budget_policies.py';assert not p.exists();p.write_text(s)
print('Prepared90 frozen qualification and precision-aware private validator.')
