from pathlib import Path
import datetime,hashlib,json,subprocess,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';out=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';binary=v/'engine18_final_conformance';digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary_sha256':digest(binary),'kernel_sha256':digest(r/'zig/pkg/inference/src/backends/metal_kernels.m'),'checker_sha256':digest(r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m'),'own_cpu_compile_overlap':False,'commands':[]}
for flag in ['--check-batch-attention','--check-prefill-pack-reuse','--benchmark-prefill-pack-reuse']:
 name=flag.removeprefix('--');log=Path('/private/tmp')/('ocr-engine18-final-c-'+name+'.txt')
 with log.open('w')as f:res=subprocess.run([str(binary),flag],stdout=f,stderr=subprocess.STDOUT)
 record['commands'].append({'flag':flag,'exit_code':res.returncode,'log':str(log),'log_sha256':digest(log)})
 print(flag,res.returncode,flush=True)
 if res.returncode:break
(out/'engine18_c_qualification_manifest.json').write_text(json.dumps(record,indent=2)+'\n')
sys.exit(res.returncode)
