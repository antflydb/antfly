from pathlib import Path
import subprocess,sys
v=Path('.venv-lighton-vllm-metal')
for name in ['run_engine29_budget_profiles.py','run_engine29_nohook_profile.py']:
 print('START DRIVER',name,flush=True)
 r=subprocess.run([sys.executable,str(v/name)])
 print('DONE DRIVER',name,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
