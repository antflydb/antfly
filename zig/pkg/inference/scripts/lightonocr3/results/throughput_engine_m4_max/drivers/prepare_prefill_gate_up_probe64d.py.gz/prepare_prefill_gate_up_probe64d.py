from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=(v/'prefill_gate_up_probe64a.metal').read_text();a=s.index('template<uint M,');header=s[:a]
body='''template<uint M,uint N,uint SG,uint K> inline void candidate_gate(device bfloat*x,device bfloat*gw,device bfloat*uw,device float*gb,device float*ub,device float*y,constant Params&p,uint2 group){
 tensor<device bfloat,dextents<int,2>,tensor_inline>a0(x,dextents<int,2>(K,p.rows),array<int,2>{1,int(p.in_dim)});
 tensor<device bfloat,dextents<int,2>,tensor_inline>g0(gw,dextents<int,2>(K,p.out_dim),array<int,2>{1,int(p.in_dim)});
 tensor<device float,dextents<int,2>,tensor_inline>dest(y,dextents<int,2>(p.out_dim,p.rows),array<int,2>{1,int(p.out_dim)});
 auto left0=a0.slice(0,int(group.y)*M);auto right0=g0.slice(0,int(group.x)*N);auto out=dest.slice(int(group.x)*N,int(group.y)*M);
 constexpr auto desc=matmul2d_descriptor(M,N,K,false,true,true);matmul2d<desc,execution_simdgroups<SG>>op;
 auto g=op.template get_destination_cooperative_tensor<decltype(left0),decltype(right0),float>();auto u=op.template get_destination_cooperative_tensor<decltype(left0),decltype(right0),float>();
 for(ushort i=0;i<g.get_capacity();i++){g[i]=0;u[i]=0;}
 for(uint k=0;k<p.in_dim;k+=K){
  tensor<device bfloat,dextents<int,2>,tensor_inline>a(x+k,dextents<int,2>(K,p.rows),array<int,2>{1,int(p.in_dim)});
  tensor<device bfloat,dextents<int,2>,tensor_inline>gm(gw+k,dextents<int,2>(K,p.out_dim),array<int,2>{1,int(p.in_dim)}),um(uw+k,dextents<int,2>(K,p.out_dim),array<int,2>{1,int(p.in_dim)});
  auto left=a.slice(0,int(group.y)*M);auto rightG=gm.slice(0,int(group.x)*N);auto rightU=um.slice(0,int(group.x)*N);
  op.run(left,rightG,g);op.run(left,rightU,u);
 }
 for(ushort i=0;i<g.get_capacity();i++){auto c=g.get_multidimensional_index(i);int col=int(group.x)*N+c[0],row=int(group.y)*M+c[1];if(c[0]>=0&&c[0]<N&&c[1]>=0&&c[1]<M&&col<int(p.out_dim)&&row<int(p.rows)){float gs=g[i]+gb[col],us=u[i]+ub[col];g[i]=(gs/(1.0f+exp(-gs)))*us;}}
 g.store(out);
}
'''
for i,(m,n,k)in enumerate([(32,64,k)for k in [64,128,256,512]]+[(64,32,k)for k in [64,128,256,512]]):
 body+=f'kernel void candidate{i}(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){{candidate_gate<{m},{n},4,{k}>(x,g,u,gb,ub,y,p,group);}}\n'
(v/'prefill_gate_up_probe64d.metal').write_text(header+body)
s=(v/'prefill_gate_up_probe64b.m').read_text().replace(' size_t m=variant==2?64:32,n=variant==1?64:32;',' size_t m=variant<4?32:64,n=variant<4?64:32;').replace('variant<3','variant<8').replace('psos[3];for(size_t i=0;i<3;i++)','psos[8];for(size_t i=0;i<8;i++)');(v/'prefill_gate_up_probe64d.m').write_text(s)
s=(v/'run_prefill_gate_up_probe64b.py').read_text().replace('probe64b','probe64d').replace('gup64b','gup64d').replace('probe64a.metal','probe64d.metal');(v/'run_prefill_gate_up_probe64d.py').write_text(s)
