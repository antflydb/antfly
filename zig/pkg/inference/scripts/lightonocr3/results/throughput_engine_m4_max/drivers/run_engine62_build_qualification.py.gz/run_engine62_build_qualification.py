from pathlib import Path
import subprocess,sys,json,hashlib,os
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
def run(name,cmd,env=None):
 p=Path('/private/tmp/ocr-engine62-'+name+'-driver.txt');assert not p.exists(),p
 print('START',name,flush=True)
 with p.open('w')as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True);assert r.returncode==0,(name,r.returncode)
env=os.environ.copy();env['ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY']='1'
run('verify-gpu-build',[sys.executable,str(v/'run_engine62_verify_gpu_build.py')],env)
run('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine62','/private/tmp/ocr-engine62-verify-gpu-build.txt'])
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((o/'engine56_c_build_manifest.json').read_text());assert all(sha(p)==h for p,h in m['input_sha256'].items())
(o/'engine62_c_qualification_reuse_audit.json').write_text(json.dumps(dict(status='pass',c_suites=16,source='engine56',input_sha256=m['input_sha256'],reason='All C, header and checker inputs byte-identical; engine62 only changes uniform prefill bounds and optionally queued scheduler phase priority.'),indent=2)+'\n')
p=v/'run_engine62_metal_disabled.py'
run('metal-disabled',[sys.executable,str(p)])
print('ENGINE62 BUILD QUALIFICATION DONE',flush=True)
