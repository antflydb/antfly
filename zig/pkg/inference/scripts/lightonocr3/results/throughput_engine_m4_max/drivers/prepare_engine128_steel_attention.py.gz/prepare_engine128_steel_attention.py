from pathlib import Path
import re,json
v=Path('.venv-lighton-vllm-metal');root=v/'lib/python3.12/site-packages/mlx/include';path=root/'mlx/backend/metal/kernels/steel/attn/kernels/steel_attention.h';s=path.read_text();start=s.index('  // Pacifying compiler');body=s[start:s.rindex('}')]
# Eliminate inactive optional paths while preserving all ordinary vision work.
for condition in ['has_mask','has_sinks','do_causal','do_causal && kb >= kb_min_causal']:
 marker='  if ('+condition+') {'
 while marker in body:
  a=body.index(marker);p=a+len(marker);depth=1
  while depth:depth+=(body[p]=='{')-(body[p]=='}');p+=1
  body=body[:a]+body[p:]
body=body.replace('store_safe<T, 1, 1>','store_safe<float, 1, 1>').replace('store<T, 1, 1>','store<float, 1, 1>')
head=s[:s.index('// clang-format off')];head=head[head.index('#include'):];head=re.sub(r'constant bool .*?\[\[function_constant\(\d+\)\]\];','',head)
seen=set();sources={}
def inline(text):
 def inc(m):
  rel=m[1];p=root/rel
  if not p.exists():return m[0]
  if rel in seen:return ''
  seen.add(rel);z=p.read_text();sources[str(p)]=__import__('hashlib').sha256(p.read_bytes()).hexdigest();return inline(z.replace('#pragma once',''))
 return re.sub(r'#include "([^"]+)"',inc,text)
head=inline('#include "mlx/backend/metal/kernels/utils.h"\n'+head);head='// Private adaptation of installed MLX Steel attention; original license retained separately.\n'+head
plans=[]
for qb,kb,sg in [(32,32,4),(32,64,4),(32,128,4),(64,64,8),(16,64,2)]:
 ident=f'q{qb}k{kb}s{sg}';prefix=f'''using namespace metal;
struct VisionParams{{uint batch,seq_len,num_heads,head_dim,bias_mode,has_mask,layout,reserved1;}};
kernel void vision128(device half*q[[buffer(0)]],device half*k[[buffer(1)]],device half*v[[buffer(2)]],device const float*bias[[buffer(3)]],device const float*mask_arg[[buffer(4)]],device float*output[[buffer(5)]],constant VisionParams&p[[buffer(6)]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]],uint group[[threadgroup_position_in_grid]]){{
using T=half;using AccumType=float;using MaskType=float;constexpr int BQ={qb},BK={kb},BD=64,WM={sg},WN=1;constexpr bool align_Q=false,align_K=false;
uint nq=(p.seq_len+BQ-1)/BQ;uint3 tid=uint3(group%nq,(group/nq)%p.num_heads,group/(nq*p.num_heads)),lid=uint3(lane,sg,0);uint simd_lane_id=lane,simd_group_id=sg;
mlx::steel::AttnParams value={{}};value.B=p.batch;value.H=p.num_heads;value.D=64;value.qL=p.seq_len;value.kL=p.seq_len;value.gqa_factor=1;value.scale=1;
value.NQ=nq;value.NK=(p.seq_len+BK-1)/BK;value.NQ_aligned=p.seq_len/BQ;value.NK_aligned=p.seq_len/BK;value.qL_rem=p.seq_len%BQ;value.kL_rem=p.seq_len%BK;
value.Q_strides[0]=value.K_strides[0]=value.V_strides[0]=(long)p.num_heads*p.reserved1*64;value.Q_strides[1]=value.K_strides[1]=value.V_strides[1]=(long)p.reserved1*64;value.Q_strides[2]=value.K_strides[2]=value.V_strides[2]=64;
value.O_strides[0]=(long)p.seq_len*p.num_heads*64;value.O_strides[1]=64;value.O_strides[2]=(long)p.num_heads*64;
thread const mlx::steel::AttnParams*params=&value;device const half*Q=q;device const half*K=k;device const half*V=v;device float*O=output;
'''
 (v/f'engine128_{ident}.metal').write_text(head+prefix+body+'\n}\n');plans.append(dict(id=ident,q=qb,k=kb,sg=sg,m=0))
(v/'engine128_plans.json').write_text(json.dumps(plans,indent=2)+'\n');(v/'engine128_upstream_sources.json').write_text(json.dumps(sources,indent=2)+'\n');(v/'engine128_MLX_LICENSE').write_bytes((v/'engine86_MLX_LICENSE').read_bytes())
for name in ['vision_kernels.m','vision_checks.m','vision_probe.m']:
 z=(v/('engine120_'+name)).read_text().replace('engine120_','engine128_').replace('vision120','vision128').replace('select120','select128').replace('VISION120','VISION128');(v/('engine128_'+name)).write_text(z)
