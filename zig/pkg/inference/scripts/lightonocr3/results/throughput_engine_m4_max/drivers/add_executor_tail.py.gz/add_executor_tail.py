from pathlib import Path
p=Path('zig/pkg/inference/src/pipelines/generation.zig');s=p.read_text()
a='    prepared_lighton_decode: bool = false,';assert s.count(a)==1;s=s.replace(a,a+'\n    executor_sequence_control: ?InferenceExecutionControl = null,\n    executor_tail_steps: usize = 0,',1)
a='''        greedy_token: ?u32 = null,
        failure: ?anyerror = null,''';assert s.count(a)==1;s=s.replace(a,'''        greedy_token: ?u32 = null,
        sequence: ?*PendingGreedySequence = null,
        failure: ?anyerror = null,''',1)
a='    fn runScheduledDecodeBatch(';assert s.count(a)==1;s=s.replace(a,Path('.venv-lighton-vllm-metal/executor_tail_methods.zig.inc').read_text()+'\n'+a,1)
a='''        while (tokens_generated < max_tokens) {
            if (self.execution_control) |control| try control.update(.executing, @intCast(tokens_generated), @intCast(max_tokens));''';assert s.count(a)>=1;start=s.index('    fn standardDecode(');i=s.index(a,start);s=s[:i]+s[i:].replace(a,a+'''
            if (tokens_generated > 0 and self.executor_sequence_control != null and
                self.gpt_config.hasQwen35VisionArchitectureContract() and self.cb.kind() == .metal and
                self.execution_lock != null and self.io != null and self.scheduler_lease != null and
                self.scheduler != null and self.scheduler.?.hasExecutor() and self.scheduler.?.usesStepEvents() and
                isPureGreedyConfig(config) and !penalty_state.enabled and
                token_table == null and json_grammar.* == null and gbnf_grammar == null and
                on_token_fn == null and on_token_ctx == null and
                self.executor_sequence_control.?.progress == null and
                (self.execution_control == null or self.execution_control.?.progress == null))
            {
                return self.runExecutorGreedyTail(token_ids, seq_len, decode_state, config, tokens_generated, max_tokens);
            }''',1)
a='''                    work.greedy_token = token;
                    work.ready.store(true, .release);''';assert s.count(a)==1;s=s.replace(a,'''                    publishGreedyToken(work, token);''',1)
a='''        self.cb.drainPrefetchBudget(prefetch_drain_budget_per_step);

        const result = self.forwardScheduledStep(claimed)''';assert s.count(a)==1;s=s.replace(a,'''        self.cb.drainPrefetchBudget(prefetch_drain_budget_per_step);
        for (claimed) |item| if (item.phase == .decode) {
            const work: *PendingDecodeBatchWork = @ptrCast(@alignCast(item.work_ptr));
            if (work.sequence != null) self.executor_tail_steps += 1;
        };

        const result = self.forwardScheduledStep(claimed)''',1)
# Mixed prefill/decode steps can return logits even for greedy sequence work.
a='''                    if (work.allocator.dupe(f32, slice)) |buf| {
                        work.logits = buf;''';assert s.count(a)==1;s=s.replace(a,'''                    if (work.sequence) |sequence| {
                        // Keep the same suppression and first-index tie policy
                        // as the ordinary scheduled greedy fallback.
                        var best: usize = 0;
                        var best_value: f32 = -std.math.inf(f32);
                        for (slice, 0..) |value, token| {
                            var suppressed = false;
                            for (sequence.model_config.suppressTokenIds()) |id| {
                                if (token == id) { suppressed = true; break; }
                            }
                            if (!suppressed and value > best_value) { best = token; best_value = value; }
                        }
                        publishGreedyToken(work, @intCast(best));
                        continue;
                    }
                    if (work.allocator.dupe(f32, slice)) |buf| {
                        work.logits = buf;''',1)
p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text();a='''        worker_steps: usize = 0,''';assert s.count(a)==1;s=s.replace(a,a+'\n        worker_tail_steps: usize = 0,',1)
a='''                std.debug.print("LIGHTONOCR3 executor_steps={d}\\n", .{ctx.worker_steps});''';assert s.count(a)==1;s=s.replace(a,a+'''\n                std.debug.print("LIGHTONOCR3 executor_tail_steps={d}\\n", .{ctx.worker_tail_steps});''',1)
a='''        fn prepare(ctx: *LightOnStreamContext, kv_dtype: runtime.kv.pool.KvDType) !void {''';i=s.index(a);prev=s.rfind('''            }
        }
''',0,i);assert prev!=-1;s=s[:prev]+s[prev:].replace('''            }
        }
''','''            }
            ctx.worker_tail_steps = pipeline.executor_tail_steps;
        }
''',1)
a='''            .prepared_lighton_decode = prepared_decode,
            .execution_control''';assert s.count(a)==1;s=s.replace(a,'''            .prepared_lighton_decode = prepared_decode,
            .executor_sequence_control = if (platform.env.getenvBool("ANTFLY_LIGHTONOCR3_EXECUTOR_TAIL")) control else null,
            .execution_control''',1)
a='''            "ANTFLY_LIGHTONOCR3_PHASE_PARK",
        };''';assert s.count(a)==1;s=s.replace(a,'''            "ANTFLY_LIGHTONOCR3_PHASE_PARK",
            "ANTFLY_LIGHTONOCR3_EXECUTOR_TAIL",
        };''',1)
a='''const engine = std.mem.eql(u8, policy, "enginephase")''';assert s.count(a)==1;s=s.replace(a,'''const engine = std.mem.eql(u8, policy, "enginetail") or std.mem.eql(u8, policy, "enginephase")''',1)
# Tail policy changes only the per-token ownership on top of enginefull.
s=s.replace('''or std.mem.eql(u8, policy, "enginefull")) "1" else "0"''','''or std.mem.eql(u8, policy, "enginefull") or std.mem.eql(u8, policy, "enginetail")) "1" else "0"''')
a='''            std.debug.print("OCR_POLICY round={d} name={s}\\n", .{ round, policy });''';assert s.count(a)==1;s=s.replace(a,'''            if (std.mem.startsWith(u8, policy, "engine")) {
                if (Env.setenv("ANTFLY_LIGHTONOCR3_EXECUTOR_TAIL", if (std.mem.eql(u8, policy, "enginetail")) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;
            }
'''+a,1);p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text().replace('''            "enginefull",
''','''            "enginefull",
            "enginetail",
''',1).replace('''                        "executor_steps",
''','''                        "executor_steps",
                        "executor_tail_steps",
''',1);p.write_text(s)
