from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');freeze=json.loads((v/'engine24-freeze.json').read_text())
for f,h in freeze.items():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h,f
p=Path('zig/pkg/inference/src/architectures/qwen3vl_projector.zig');s=p.read_text()
s=s.replace('    hard_max_merged_tokens: usize = 1024,','    hard_max_merged_tokens: usize = 1024,\n    /// Consecutive vision blocks retained by one Metal submission. Admission\n    /// charges this many complete block envelopes before execution.\n    metal_frame_blocks: u8 = 1,')
s=s.replace('self.max_images > 64 or self.hard_max_merged_tokens > 4096)', 'self.max_images > 64 or self.hard_max_merged_tokens > 4096 or\n            self.metal_frame_blocks == 0 or self.metal_frame_blocks > 4)')
s=s.replace('.host_scratch_bytes = host_scratch,\n        .backend_scratch_bytes = backend_scratch,','.host_scratch_bytes = try admissionMul(host_scratch, limits.metal_frame_blocks),\n        .backend_scratch_bytes = try admissionMul(backend_scratch, limits.metal_frame_blocks),')
anchor='const CT = ops.CT;\n'
helper='''

/// Own the frame before releasing tensors retained across vision blocks.
/// The caller keeps the current output; this group owns only predecessors.
const VisionFrameGroup = struct {
    cb: *const ComputeBackend,
    blocks: usize,
    owns_frame: bool = false,
    held: [4]?CT = @splat(null),
    count: usize = 0,
    submits: usize = 0,

    fn begin(self: *@This(), enabled: bool) !void {
        if (!self.owns_frame and enabled and !self.cb.decoderRuntimeHasActiveFrame())
            self.owns_frame = try self.cb.decoderRuntimeBeginFrame();
    }

    fn release(self: *@This()) void {
        for (self.held[0..self.count]) |tensor| self.cb.free(tensor.?);
        self.count = 0;
    }

    fn finishBlock(self: *@This(), previous: CT, last: bool) !void {
        if (!self.owns_frame) {
            self.cb.free(previous);
            return;
        }
        self.held[self.count] = previous;
        self.count += 1;
        if (self.count == self.blocks or last) {
            try self.cb.decoderRuntimeSubmitAndWaitFrame();
            self.owns_frame = false;
            self.submits += 1;
            self.release();
        }
    }

    fn deinit(self: *@This()) void {
        if (self.owns_frame) self.cb.decoderRuntimeCancelFrame() catch {};
        self.release();
    }
};
'''
s=s.replace(anchor,anchor+helper)
old='''    for (0..cfg.block_count) |layer| {
        try cb.checkExecutionControl();
        var owns_frame = !cb.decoderRuntimeHasActiveFrame() and try cb.decoderRuntimeBeginFrame();
        defer if (owns_frame) cb.decoderRuntimeCancelFrame() catch {};
        const next = try encoderBlock(cb, allocator, &weights, cfg, hidden.?, positions, rows, layer, prepared_images.len);
        errdefer cb.free(next);
        if (owns_frame) {
            try cb.decoderRuntimeSubmitAndWaitFrame();
            owns_frame = false;
        }
        cb.free(hidden.?);
        hidden = next;
    }
'''
new='''    var frame_group = VisionFrameGroup{ .cb = cb, .blocks = limits.metal_frame_blocks };
    defer frame_group.deinit();
    for (0..cfg.block_count) |layer| {
        try cb.checkExecutionControl();
        try frame_group.begin(true);
        const previous = hidden.?;
        hidden = try encoderBlock(cb, allocator, &weights, cfg, previous, positions, rows, layer, prepared_images.len);
        try frame_group.finishBlock(previous, layer + 1 == cfg.block_count);
    }
    if (limits.metal_frame_blocks > 1 and platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3"))
        std.debug.print("LIGHTONOCR3 vision_frame_blocks={d} vision_frame_submits={d} vision_frame_images={d}\\n", .{ limits.metal_frame_blocks, frame_group.submits, prepared_images.len });
'''
assert old in s;s=s.replace(old,new)
s=s.replace('    var deepstack_ns: u64 = 0;\n    for (0..cfg.block_count)', '    var deepstack_ns: u64 = 0;\n    var frame_group = VisionFrameGroup{ .cb = cb, .blocks = limits.metal_frame_blocks };\n    defer frame_group.deinit();\n    for (0..cfg.block_count)')
old='''        // One frame per vision block batches GPU operations while keeping
        // retained scratch bounded to the admitted single-block envelope.
        var owns_frame = cfg.is_qwen35 and cb.kind() == .metal and
            !platform.env.getenvBool("TERMITE_METAL_DISABLE_QWEN35_VISION_FRAME") and
            !cb.decoderRuntimeHasActiveFrame() and try cb.decoderRuntimeBeginFrame();
        defer if (owns_frame) cb.decoderRuntimeCancelFrame() catch {};
'''
new='''        // Bound retained blocks by the larger admitted frame envelope.
        try frame_group.begin(cfg.is_qwen35 and cb.kind() == .metal and
            !platform.env.getenvBool("TERMITE_METAL_DISABLE_QWEN35_VISION_FRAME"));
'''
assert old in s;s=s.replace(old,new)
old='''        if (owns_frame) {
            cb.decoderRuntimeSubmitAndWaitFrame() catch |err| {
                cb.free(next);
                return err;
            };
            owns_frame = false;
        }
        if (profile) blocks_ns +|= monotonicNowNs() -| block_started_at;
        cb.free(hidden);
        hidden = next;
'''
new='''        const previous = hidden;
        hidden = next;
        try frame_group.finishBlock(previous, layer + 1 == cfg.block_count);
        if (profile) blocks_ns +|= monotonicNowNs() -| block_started_at;
'''
assert old in s;s=s.replace(old,new)
# Log after all vision blocks, before post-normalization.
anchor='    const post_norm = (layerNormNamed(cb, allocator, weights, hidden, "v.post_ln", cfg.vision_hidden, cfg.layer_norm_eps)'
assert anchor in s
s=s.replace(anchor,'''    if (limits.metal_frame_blocks > 1 and platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3"))
        std.debug.print("LIGHTONOCR3 vision_frame_blocks={d} vision_frame_submits={d} vision_frame_images=1\\n", .{ limits.metal_frame_blocks, frame_group.submits });
'''+anchor)
# Extend the existing real geometry/admission test with larger frames.
anchor='            try std.testing.expectEqual(7 * hidden + @max(scores, ffn) + merge + packed_pair, estimate.backend_scratch_bytes);'
assert anchor in s
s=s.replace(anchor,anchor+'''
            var grouped_limits = limits;
            grouped_limits.metal_frame_blocks = 4;
            const grouped = try estimateAdmissionForImageDimensions(&.{image_dimensions}, config, grouped_limits);
            try std.testing.expectEqual(estimate.visual_tokens, grouped.visual_tokens);
            try std.testing.expectEqual(estimate.host_scratch_bytes * 4, grouped.host_scratch_bytes);
            try std.testing.expectEqual(estimate.backend_scratch_bytes * 4, grouped.backend_scratch_bytes);
            grouped_limits.metal_frame_blocks = 0;
            try std.testing.expectError(error.InvalidVisionLimits, grouped_limits.validate());
            grouped_limits.metal_frame_blocks = 5;
            try std.testing.expectError(error.InvalidVisionLimits, grouped_limits.validate());''')
p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text()
s=s.replace('            vision_batch_items: u8 = 1,','            vision_batch_items: u8 = 1,\n            vision_frame_blocks: u8 = 1,')
anchor='                    .vision_batch_items = if (platform.env.getenvBool("ANTFLY_LIGHTONOCR3_VISION_BATCH")) 4 else 1,'
assert anchor in s;s=s.replace(anchor,anchor+'\n                    .vision_frame_blocks = if (metal_runtime.qualifiedM4DeviceDefault() and metal_runtime.lightOnThroughputFeatureEnabled("ANTFLY_LIGHTONOCR3_CPU_PREPROCESS")) @intCast(@min(@max(platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_VISION_FRAME_BLOCKS") orelse 1, 1), 4)) else 1,')
s=s.replace('fn encodeCpuPrepared(raw: *anyopaque, allocator: std.mem.Allocator, images: []const []const u8, limits: qwen3vl_projector.Limits)', 'fn encodeCpuPrepared(raw: *anyopaque, allocator: std.mem.Allocator, images: []const []const u8, original_limits: qwen3vl_projector.Limits)')
anchor='''            const ctx = request.ctx;
            if (images.len != 1) {'''
assert anchor in s;s=s.replace(anchor,'''            const ctx = request.ctx;
            var limits = original_limits;
            limits.metal_frame_blocks = ctx.features.vision_frame_blocks;
            if (images.len != 1) {''',1)
old='        try memory.add(cfg, estimate.token_count, @intCast(max_tokens), runtime.tier.memory.AdmissionAmounts.fromEstimate(resource), try model_manager_mod.projectorRunAdmissionAmounts(model.manifest, .metal, estimate.media_admission));'
assert old in s
s=s.replace(old,'''        var vision_amounts = try model_manager_mod.projectorRunAdmissionAmounts(model.manifest, .metal, estimate.media_admission);
        // The prompt probe used single-block projector limits. Charge the
        // complete larger host/device envelope before enabling grouped frames.
        vision_amounts.host_scratch_bytes = try std.math.mul(usize, vision_amounts.host_scratch_bytes, features.vision_frame_blocks);
        vision_amounts.backend_scratch_bytes = try std.math.mul(usize, vision_amounts.backend_scratch_bytes, features.vision_frame_blocks);
        try memory.add(cfg, estimate.token_count, @intCast(max_tokens), runtime.tier.memory.AdmissionAmounts.fromEstimate(resource), vision_amounts);''')
# New tuning remains opt-in. Keep existing 100-ms default and allow a bounded
# one-second collection window to qualify steady-state prefill batching.
s=s.replace('.max_wait_us = @min(platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_PREFILL_WAIT_US") orelse 5000, 100000)', '.max_wait_us = @min(platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_PREFILL_WAIT_US") orelse 5000, 1000000)')
p.write_text(s)
p=Path('zig/pkg/inference/src/pipelines/generation.zig');s=p.read_text();old='self.gpt_config.hasQwen35VisionArchitectureContract() and claimed.len <= 16 and';assert old in s;s=s.replace(old,'self.gpt_config.hasQwen35VisionArchitectureContract() and claimed.len <= 32 and');p.write_text(s)
print('engine25 source prepared')
