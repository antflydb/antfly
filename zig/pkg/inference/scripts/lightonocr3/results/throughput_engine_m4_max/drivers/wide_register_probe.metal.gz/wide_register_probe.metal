#include <metal_stdlib>
using namespace metal;
struct termite_lightonocr3_local_params{uint rows,in_dim,out_dim,pad;};
template<uint B,uint SN,uint TM,bool GATE> inline void termite_lightonocr3_local_tile_body(device const float*x,device const ushort*gw,device const ushort*uw,device const float*gb,device const float*ub,device float*y,constant termite_lightonocr3_local_params&p,uint group,uint sg,uint lane){
 uint col=((group*4+sg)*(32/SN)+lane/SN)*TM;
 float gs[B][TM],us[B][TM];
 #pragma unroll
 for(uint b=0;b<B;b++){
  #pragma unroll
  for(uint t=0;t<TM;t++){gs[b][t]=0;us[b][t]=0;}
 }
 for(uint k=(lane%SN)*4;k<p.in_dim;k+=SN*4){
  float4 a[B];
  #pragma unroll
  for(uint b=0;b<B;b++)a[b]=b<p.rows?*((device const float4*)(x+b*p.in_dim+k)):float4(0);
  #pragma unroll
  for(uint t=0;t<TM;t++){
   float4 wg=as_type<float4>(uint4(*((device const ushort4*)(gw+(col+t)*p.in_dim+k)))<<16);
   float4 wu=GATE?as_type<float4>(uint4(*((device const ushort4*)(uw+(col+t)*p.in_dim+k)))<<16):float4(0);
   #pragma unroll
   for(uint b=0;b<B;b++){gs[b][t]+=dot(a[b],wg);if(GATE)us[b][t]+=dot(a[b],wu);}
  }
 }
 #pragma unroll
 for(uint b=0;b<B;b++){
  #pragma unroll
  for(uint t=0;t<TM;t++){
   float g=gs[b][t],u=us[b][t];
   #pragma unroll
   for(uint step=SN/2;step>0;step/=2){g+=simd_shuffle_xor(g,step);if(GATE)u+=simd_shuffle_xor(u,step);}
   if(lane%SN==0 && b<p.rows){g+=gb[col+t];if(GATE){u+=ub[col+t];g=(g/(1.0f+exp(-g)))*u;}y[b*p.out_dim+col+t]=g;}
  }
 }
}
#define V(B,SN,TM) kernel void termite_lightonocr3_local_proj_vec##B##_##SN##_##TM(device const float*x[[buffer(0)]],device const ushort*g[[buffer(1)]],device const float*gb[[buffer(2)]],device float*y[[buffer(3)]],constant termite_lightonocr3_local_params&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){termite_lightonocr3_local_tile_body<B,SN,TM,false>(x,g,g,gb,gb,y,p,group,sg,lane);}

V(16,16,1) V(16,16,2) V(16,16,4) V(16,32,1) V(16,32,2) V(16,32,4)
