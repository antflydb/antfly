#define main production_checks_main
#include "engine77_probe_checks.m"
#undef main
#include "engine77_sources.inc"
static uint32_t engine77_candidate;

static int timed_linear(termite_metal_decode_runtime *r,bool on,size_t rows,size_t in,size_t out,
 id<MTLBuffer>source,id<MTLBuffer>zero,id<MTLBuffer>x,id<MTLBuffer>y,double *us){
 r->engine77_variant=on?engine77_candidate:0;
 uint64_t before=r->frame_gpu_nanos,calls=r->engine77_calls;
 if(termite_metal_decode_runtime_begin_frame(r)||
    termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_PREFILL)||
    termite_metal_decode_runtime_apply_add_device(r,(__bridge void*)source,16,(__bridge void*)zero,0,rows*in,(__bridge void*)x,16)||
    termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_FFN,TERMITE_METAL_COMPUTE_REGION_FFN)||
    termite_metal_decode_runtime_apply_linear_multi_row_device(r,0,(__bridge void*)x,16,rows,in,out,(__bridge void*)y,16)||
    termite_metal_decode_runtime_end_planned_compute_scope(r)||
    termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r))return 1;
 if(r->engine77_calls-calls!=(on?1u:0u))return 2;
 *us=(r->frame_gpu_nanos-before)/1000.0;return 0;
}
static int probe_linear(termite_metal_decode_runtime*r,size_t rows,size_t in,size_t out){
 @autoreleasepool{
 id<MTLBuffer>source=[r->device newBufferWithLength:(rows*in+8)*4 options:MTLResourceStorageModeShared],
 zero=[r->device newBufferWithLength:rows*in*4 options:MTLResourceStorageModeShared],
 x=[r->device newBufferWithLength:(rows*in+8)*4 options:MTLResourceStorageModePrivate],
 y=[r->device newBufferWithLength:(rows*out+12)*4 options:MTLResourceStorageModeShared];
 uint16_t*w=malloc(in*out*2);float*b=malloc(out*4),*gold=malloc(rows*out*4);
 if(!source||!zero||!x||!y||!w||!b||!gold)return 3;
 memset(zero.contents,0,zero.length);
 float*input=(float*)source.contents+4,*got=(float*)y.contents+4;
 for(size_t i=0;i<rows*in;i++)input[i]=sinf(i*.013f)*.7f;
 uint32_t rng=123;for(size_t i=0;i<in*out;i++){rng=rng*1664525u+1013904223u;w[i]=round_bf16(((int)(rng>>16)-32768)*.000001f);}
 for(size_t i=0;i<out;i++)b[i]=cosf(i*.019f)*.2f;
 double cpu[4];
 for(size_t corner=0;corner<4;corner++){
  size_t row=corner/2?rows-1:0,col=corner%2?out-1:0;
  double sum=b[col];for(size_t k=0;k<in;k++)sum+=(double)expand_bf16(round_bf16(input[row*in+k]))*expand_bf16(w[col*in+k]);
  cpu[corner]=sum;
 }
 if(termite_metal_decode_runtime_prepare_linear_bf16(r,0,(uint8_t*)w,in*out*2,b,in,out))return 4;
 free(w);free(b);
 double us;if(timed_linear(r,false,rows,in,out,source,zero,x,y,&us))return 5;
 memcpy(gold,got,rows*out*4);
 for(size_t corner=0;corner<4;corner++){
  size_t row=corner/2?rows-1:0,col=corner%2?out-1:0;
  if(fabs(cpu[corner]-gold[row*out+col])>2e-4)return 6;
 }
 for(size_t leg=0;leg<4;leg++){
  const bool on=leg==1||leg==2;double times[8];float worst=0;double corner_error=0;
  for(size_t trial=0;trial<10;trial++){
   for(size_t i=0;i<4;i++)((uint32_t*)y.contents)[i]=0xdeadbeef;
   for(size_t i=rows*out+4;i<rows*out+12;i++)((uint32_t*)y.contents)[i]=0xcafebabe;
   if(timed_linear(r,on,rows,in,out,source,zero,x,y,&us))return 7;if(trial>=2)times[trial-2]=us;
   for(size_t i=0;i<rows*out;i++){if(!isfinite(got[i]))return 8;worst=fmaxf(worst,fabsf(got[i]-gold[i]));}
   for(size_t c=0;c<4;c++){size_t row=c/2?rows-1:0,col=c%2?out-1:0;corner_error=fmax(corner_error,fabs(cpu[c]-got[row*out+col]));}
   for(size_t i=0;i<4;i++)if(((uint32_t*)y.contents)[i]!=0xdeadbeef)return 9;
   for(size_t i=rows*out+4;i<rows*out+12;i++)if(((uint32_t*)y.contents)[i]!=0xcafebabe)return 10;
  }
  if(worst>2e-4||corner_error>2e-4)return 11;
  printf("{\"candidate\":%u,\"rows\":%zu,\"in\":%zu,\"out\":%zu,\"mode\":%d,\"leg\":%zu,\"max_abs\":%.9g,\"cpu_error\":%.9g,\"gpu_us\":[",engine77_candidate,rows,in,out,on,leg,worst,corner_error);
  for(int t=0;t<8;t++)printf("%s%.6f",t?",":"",times[t]);printf("]}\n");fflush(stdout);
 }
 free(gold);return 0;
 }
}
int main(void){@autoreleasepool{
 setenv("TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS","1",1);unsetenv("TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS");
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 if(termite_metal_decode_runtime_set_lighton_activation_pool(r,8*1024*1024))return 2;
 size_t ready=0;
 for(size_t i=0;i<3;i++){
  MTLCompileOptions*opt=[MTLCompileOptions new];opt.languageVersion=MTLLanguageVersion4_0;opt.fastMathEnabled=NO;opt.mathMode=MTLMathModeSafe;NSError*err=nil;
  id<MTLLibrary>lib=[r->device newLibraryWithSource:engine77_sources[i] options:opt error:&err];
  if(!lib){fprintf(stderr,"UNSUPPORTED77 candidate=%zu error=%s\n",i+1,err.localizedDescription.UTF8String);continue;}
  r->engine77_psos[i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"engine77_prefill_%zu",i+1]);
  id<MTLComputePipelineState>p=r->engine77_psos[i];if(!p||p.maxTotalThreadsPerThreadgroup<256||p.staticThreadgroupMemoryLength>r->device.maxThreadgroupMemoryLength){fprintf(stderr,"UNSUPPORTED77 candidate=%zu PSO\n",i+1);continue;}
  ready++;fprintf(stderr,"CANDIDATE77 READY candidate=%zu\n",i+1);engine77_candidate=(uint32_t)i+1;
  const size_t rows[]={432,554,662},shapes[][2]={{2560,8192},{2560,4096},{4096,2560},{2560,1024},{2560,9216},{9216,2560}};
  for(size_t a=0;a<3;a++)for(size_t b=0;b<6;b++){
   int rc=probe_linear(r,rows[a],shapes[b][0],shapes[b][1]);
   if(rc){fprintf(stderr,"PROBE77 FAIL candidate=%zu rows=%zu in=%zu out=%zu rc=%d\n",i+1,rows[a],shapes[b][0],shapes[b][1],rc);return 10+rc;}
  }
 }
 for(size_t i=0;i<3;i++)r->engine77_psos[i]=nil;
 termite_metal_decode_runtime_destroy(r);fprintf(stderr,"PROBE77 SCREEN COMPLETE ready=%zu\n",ready);return 0;
}}
