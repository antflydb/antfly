#define main production_checks_main
#include "engine42_ffn_probe_checks.m"
#undef main
static int run_gate(termite_metal_decode_runtime*r,id<MTLComputePipelineState>p,size_t n,size_t m,size_t sg,size_t rows,size_t in,size_t out,id<MTLBuffer>x,id<MTLBuffer>y,double*us){
 id<MTLBuffer>zero=[r->device newBufferWithLength:rows*in*4 options:MTLResourceStorageModeShared];
 id<MTLBuffer>device_input=[r->device newBufferWithLength:(rows*in+4)*4 options:MTLResourceStorageModePrivate];
 if(!zero||!device_input)return 10;memset(zero.contents,0,rows*in*4);
 if(p&&(p.threadExecutionWidth!=32||p.maxTotalThreadsPerThreadgroup<sg*32||p.staticThreadgroupMemoryLength>r->device.maxThreadgroupMemoryLength))return 11;
 uint64_t before=r->frame_gpu_nanos;
 if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_DECODE))return 12;
 if(termite_metal_decode_runtime_apply_add_device(r,(__bridge void*)x,16,(__bridge void*)zero,0,rows*in,(__bridge void*)device_input,16))return 13;
 if(termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_FFN,TERMITE_METAL_COMPUTE_REGION_FFN))return 14;
 if(!p){
  if(termite_metal_decode_runtime_apply_bf16_gate_up_device(r,0,1,(__bridge void*)device_input,16,rows,in,out,(__bridge void*)y,16))return 15;
 }else{
  id<MTLComputeCommandEncoder>e=r->active_planned_compute_encoder;if(!e)return 16;
  termite_metal_linear_params params={(uint32_t)rows,(uint32_t)in,(uint32_t)out,0};
  [e setComputePipelineState:p];[e setBuffer:device_input offset:16 atIndex:0];
  [e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_weight_buffers[1] offset:0 atIndex:2];
  [e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:3];[e setBuffer:r->linear_bias_buffers[1] offset:0 atIndex:4];
  [e setBuffer:y offset:16 atIndex:5];[e setBytes:&params length:sizeof(params) atIndex:6];
  [e dispatchThreadgroups:MTLSizeMake((out+n-1)/n,(rows+m-1)/m,1) threadsPerThreadgroup:MTLSizeMake(sg*32,1,1)];
 }
 if(termite_metal_decode_runtime_end_planned_compute_scope(r)||termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r))return 17;
 *us=(r->frame_gpu_nanos-before)/1000.0;return 0;
}
static int probe_gate(termite_metal_decode_runtime*r,id<MTLComputePipelineState> __strong p[6],size_t rows,size_t in,size_t out){
 id<MTLBuffer>x=[r->device newBufferWithLength:(rows*in+4)*4 options:MTLResourceStorageModeShared],y=[r->device newBufferWithLength:(rows*out+12)*4 options:MTLResourceStorageModeShared];uint16_t*w=malloc(in*out*2);float*b=malloc(out*4),*gold=malloc(rows*out*4);if(!x||!y||!w||!b||!gold)return 1;float*v=(float*)x.contents+4,*got=(float*)y.contents+4;for(size_t i=0;i<rows*in;i++)v[i]=sinf(i*.013f)*.7f;
 double cpu[2][4]={0};uint32_t state=123;
 for(size_t slot=0;slot<2;slot++){
  for(size_t i=0;i<in*out;i++){state=state*1664525u+1013904223u;w[i]=round_bf16(((int)(state>>16)-32768)*.000001f);}for(size_t i=0;i<out;i++)b[i]=cosf(i*.019f+slot)*.2f;
  for(size_t corner=0;corner<4;corner++){size_t row=corner/2?rows-1:0,col=corner%2?out-1:0;double ref=b[col];for(size_t k=0;k<in;k++)ref+=(double)v[row*in+k]*expand_bf16(w[col*in+k]);cpu[slot][corner]=ref;}
  if(termite_metal_decode_runtime_prepare_linear_bf16(r,slot,(uint8_t*)w,in*out*2,b,in,out))return 2;
 }
 double us;if(run_gate(r,nil,0,0,0,rows,in,out,x,y,&us))return 3;memcpy(gold,got,rows*out*4);
 for(size_t corner=0;corner<4;corner++){size_t row=corner/2?rows-1:0,col=corner%2?out-1:0;double g=cpu[0][corner],u=cpu[1][corner];if(fabs(g/(1+exp(-g))*u-gold[row*out+col])>2e-4)return 4;}
 const size_t ms[6]={32,32,32,64,64,64},ns[6]={16,32,32,16,32,64},sgs[6]={2,2,4,4,4,8};
 for(size_t pick=0;pick<2;pick++)for(size_t round=0;round<4;round++){
  const size_t variant=pick?0:2;
  bool on=round==1||round==2;double total=0;float worst=0;
  for(size_t trial=0;trial<40;trial++){
   for(size_t i=0;i<4;i++)((uint32_t*)y.contents)[i]=0xdeadbeef;for(size_t i=rows*out+4;i<rows*out+12;i++)((uint32_t*)y.contents)[i]=0xcafebabe;
   if(run_gate(r,on?p[variant]:nil,ns[variant],ms[variant],sgs[variant],rows,in,out,x,y,&us))return 5;total+=us;
   for(size_t i=0;i<rows*out;i++){if(!isfinite(got[i]))return 6;worst=fmaxf(worst,fabsf(got[i]-gold[i]));}
   for(size_t i=0;i<4;i++)if(((uint32_t*)y.contents)[i]!=0xdeadbeef)return 7;for(size_t i=rows*out+4;i<rows*out+12;i++)if(((uint32_t*)y.contents)[i]!=0xcafebabe)return 8;
  }
  if(worst>2e-4)return 9;fprintf(stderr,"WIDE_FFN_REPEAT rows=%zu in=%zu out=%zu variant=%zu on=%d round=%zu gpu_us=%.3f max_abs=%g\n",rows,in,out,variant,on,round,total/40,worst);
 }
 free(w);free(b);free(gold);return 0;
}
int main(void){@autoreleasepool{
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 NSError*err=nil;NSString*source=[NSString stringWithContentsOfFile:@".venv-lighton-vllm-metal/engine42_wide_ffn_probe_repeat.metal" encoding:NSUTF8StringEncoding error:&err];MTLCompileOptions*opts=[MTLCompileOptions new];opts.fastMathEnabled=NO;opts.mathMode=MTLMathModeSafe;opts.languageVersion=MTLLanguageVersion4_0;id<MTLLibrary>lib=[r->device newLibraryWithSource:source options:opts error:&err];if(!lib){fprintf(stderr,"MSL_ERROR %s\n",err.description.UTF8String);return 2;}id<MTLComputePipelineState>p[6];for(size_t i=0;i<6;i++){p[i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"gate_mpp_%zu",i]);if(!p[i])return 3;}
 const size_t rows[]={64,48,33,63,32,56};for(size_t i=0;i<6;i++)for(size_t model=0;model<2;model++){int rc=probe_gate(r,p,rows[i],model?2560:1024,model?9216:3584);if(rc){fprintf(stderr,"WIDE_FFN_PROBE_FAIL rows=%zu model=%zu rc=%d\n",rows[i],model,rc);return 10+rc;}}
 termite_metal_decode_runtime_destroy(r);
}return 0;}
