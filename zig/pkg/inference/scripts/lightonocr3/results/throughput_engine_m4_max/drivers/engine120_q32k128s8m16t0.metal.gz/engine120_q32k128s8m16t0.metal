#include <metal_stdlib>
#include <metal_tensor>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;using namespace mpp::tensor_ops;
struct VisionParams{uint batch,seq_len,num_heads,head_dim,bias_mode,has_mask,layout,reserved1;};
kernel void vision120(device half*q[[buffer(0)]],device half*k[[buffer(1)]],device half*v[[buffer(2)]],device const float*bias[[buffer(3)]],device const float*mask[[buffer(4)]],device float*output[[buffer(5)]],constant VisionParams&p[[buffer(6)]],uint tid[[thread_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]],uint group[[threadgroup_position_in_grid]]){
 constexpr uint QB=32,KB=128,SG=8,M=16,QKT=8,NPV=1;
 const uint tiles=(p.seq_len+QB-1)/QB,qtile=group%tiles,h=(group/tiles)%p.num_heads,b=group/(tiles*p.num_heads),q0=qtile*QB,base=(b*p.num_heads+h)*p.reserved1*64;
 threadgroup float scores[QB*KB],rowmax[QB],rowsum[QB],correction[QB];threadgroup half probs[QB*KB];
 if(tid<QB){rowmax[tid]=-INFINITY;rowsum[tid]=0;}threadgroup_barrier(mem_flags::mem_threadgroup);
 tensor<threadgroup half,dextents<int,2>,tensor_inline> P0(probs,dextents<int,2>(KB,M),array<int,2>{1,KB});
 tensor<device half,dextents<int,2>,tensor_inline> V0(v+base,dextents<int,2>(16,KB),array<int,2>{1,64});
 constexpr auto qkd=matmul2d_descriptor(M,32,64,false,true,false);matmul2d<qkd,execution_simdgroups<1>> qkop;
 constexpr auto pvd=matmul2d_descriptor(M,16,KB,false,false,false,matmul2d_descriptor::mode::multiply_accumulate);matmul2d<pvd,execution_simdgroups<1>> pvop;
 auto out0=pvop.get_destination_cooperative_tensor<decltype(P0),decltype(V0),float>();
 for(ushort z=0;z<out0.get_capacity();z++)out0[z]=0;
 
 for(uint start=0;start<p.seq_len;start+=KB){
  
  if(sg<QKT){uint qr=(sg/(KB/32))*M,kc=(sg%(KB/32))*32;
   tensor<device half,dextents<int,2>,tensor_inline> Q(q+base+(q0+qr)*64,dextents<int,2>(64,M),array<int,2>{1,64});
   tensor<device half,dextents<int,2>,tensor_inline> K(k+base+(start+kc)*64,dextents<int,2>(64,32),array<int,2>{1,64});
   tensor<threadgroup float,dextents<int,2>,tensor_inline> S(scores+qr*KB+kc,dextents<int,2>(32,M),array<int,2>{1,KB});
   auto dot=qkop.get_destination_cooperative_tensor<decltype(Q),decltype(K),float>();qkop.run(Q,K,dot);dot.store(S);
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint row=sg;row<QB;row+=SG){float xs[KB/32],es[KB/32],mx=-INFINITY;
   for(uint j=0;j<KB/32;j++){xs[j]=(q0+row<p.seq_len&&start+lane+j*32<p.seq_len)?scores[row*KB+lane+j*32]:-INFINITY;if(!isfinite(xs[j]))xs[j]=-INFINITY;mx=max(mx,xs[j]);}
   mx=simd_max(mx);float nm=max(rowmax[row],mx),c=isfinite(nm)&&isfinite(rowmax[row])?exp(rowmax[row]-nm):0,sum=0;
   for(uint j=0;j<KB/32;j++){es[j]=isfinite(xs[j])?exp(xs[j]-nm):0;probs[row*KB+lane+j*32]=half(es[j]);sum+=es[j];}
   sum=simd_sum(sum);if(lane==0){rowmax[row]=nm;rowsum[row]=rowsum[row]*c+sum;correction[row]=c;}
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);
  {const uint a=0;uint tile=sg+a*SG,qr=(tile/4)*M,dc=(tile%4)*16;
   for(ushort z=0;z<out0.get_capacity();z++){auto c=out0.get_multidimensional_index(z);out0[z]*=correction[qr+c[1]];}
   tensor<threadgroup half,dextents<int,2>,tensor_inline> P(probs+qr*KB,dextents<int,2>(KB,M),array<int,2>{1,KB});
   tensor<device half,dextents<int,2>,tensor_inline> V(v+base+start*64+dc,dextents<int,2>(16,KB),array<int,2>{1,64});
   pvop.run(P,V,out0);
  }
  
 }
 {const uint a=0;uint tile=sg+a*SG,qr=(tile/4)*M,dc=(tile%4)*16;
  for(ushort z=0;z<out0.get_capacity();z++){auto c=out0.get_multidimensional_index(z);uint row=qr+c[1],d=dc+c[0];if(q0+row<p.seq_len)output[((b*p.seq_len+q0+row)*p.num_heads+h)*64+d]=rowsum[row]>0?out0[z]/rowsum[row]:0;}
 }
}
