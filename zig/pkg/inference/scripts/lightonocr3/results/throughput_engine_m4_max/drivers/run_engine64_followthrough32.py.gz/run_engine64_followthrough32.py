from pathlib import Path
import json,subprocess,sys,time
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');source=out/'engine64_profile32_4b_r128_audit.json'
while not source.exists()or json.loads(source.read_text())['status']=='running':
 parent=Path('/private/tmp/ocr-engine64-profile32-parent.txt')
 if parent.exists()and'Traceback'in parent.read_text():raise RuntimeError('profile32 qualification failed')
 time.sleep(5)
assert json.loads(source.read_text())['status']=='pass'
for name,script in [('profile33-b2','run_engine64_profile33_b2.py'),('paired32','run_engine64_paired32.py')]:
 if name=='paired32':
  sources=[source,out/'engine64_profile33_b2_r128_audit.json'];records=[]
  for p in sources:records+=json.loads(p.read_text())['candidates']
  assert any(x['eligible']for x in records)
  p=out/'engine64_selected32_profiles_audit.json';assert not p.exists();p.write_text(json.dumps(dict(status='pass',candidates=records),indent=2)+'\n')
 print('START',name,flush=True)
 with Path(f'/private/tmp/ocr-engine64-{name}-parent.txt').open('w')as f:r=subprocess.run([sys.executable,str(v/script)],stdout=f,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True);assert r.returncode==0,(name,r.returncode)
print('ENGINE64 FOLLOWTHROUGH32 COMPLETE',flush=True)
