from pathlib import Path
import os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');base=os.environ.copy();base.update(OCR_REFERENCE_LABEL='_primary_reference11_r0_auto_c32_r128',OCR_PHYSICAL32='1',OCR_CONCURRENCY='32',OCR_REQUESTS='64',OCR_WIDE='1',OCR_SCRATCH_GIB='8',OCR_BACKEND_GIB='16',OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='0',OCR_BF16_PREFILL='0',OCR_BF16='0',OCR_VISION_BATCH='0',OCR_VISION_FRAME_BLOCKS='4',OCR_SINGLE_FRAME='1',OCR_STREAM_FIRST='0')
for disabled in [0,1]:
 env=base.copy();env['OCR_DISABLE_TOKEN_ENCODER']=str(disabled);label=f'token_encoder_qualification_c32_r64_disabled{disabled}';print('START',label,flush=True);r=subprocess.run([sys.executable,str(v/'run_engine32_budget_no_prefill_policies.py'),'08:'+label],env=env);print('DONE',label,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
