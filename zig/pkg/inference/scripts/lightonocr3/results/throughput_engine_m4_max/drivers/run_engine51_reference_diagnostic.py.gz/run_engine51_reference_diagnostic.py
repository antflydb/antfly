from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,statistics
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p,h in json.loads((v/'engine48-freeze.json').read_text()).items():assert sha(p)==h,p
hook=v/'engine51-reference-hook';rawdir=v/'engine51-reference-profile';assert not rawdir.exists();rawdir.mkdir()
dest=out/'vllm_4b_engine51_synchronized_stage_diagnostic_c64_r128';assert not(dest/'report.json').exists()
env=os.environ.copy();env.update(PYTHONPATH=str(hook),ANTFLY_OCR_REFERENCE_PROFILE_DIR=str(rawdir),ANTFLY_OCR_REFERENCE_PROFILE_SYNC='1')
images=[root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png',scripts/'corpus/receipt.png',scripts/'corpus/shipping.png']
cmd=[sys.executable,str(scripts/'benchmark_vllm_metal.py'),'--python',sys.executable,'--model-dir',str(v/'ocr-models/lighton4b'),'--images',*map(str,images),'--concurrency','64','--requests','128','--max-tokens','256','--startup-timeout','600','--output-dir',str(dest)]
plan=dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='running',primary_throughput_eligible=False,scope='Reference synchronized stage-wall diagnostic only. Extra eval/synchronization changes vLLM pipeline overlap; do not compare its throughput to native primary. Original installed source unchanged, unique media UUID/cache-off benchmark unchanged. Scheduler shape counts are observed under this instrumented execution.',hook_sha256=sha(hook/'sitecustomize.py'),driver_sha256=sha(__file__),benchmark_sha256=sha(scripts/'benchmark_vllm_metal.py'),command=cmd,hook_env={k:env[k]for k in ['PYTHONPATH','ANTFLY_OCR_REFERENCE_PROFILE_DIR','ANTFLY_OCR_REFERENCE_PROFILE_SYNC']})
audit=out/'engine51_reference_stage_diagnostic_audit.json';assert not audit.exists();audit.write_text(json.dumps(plan,indent=2)+'\n')
with Path('/private/tmp/ocr-engine51-reference-diagnostic.txt').open('w')as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
plan['exit_code']=r.returncode
report=dest/'report.json'
if report.exists():
 d=json.loads(report.read_text());d.update(primary_throughput_eligible=False,instrumented_reference_stage_diagnostic=True)
 report.write_text(json.dumps(d,indent=2)+'\n');plan['report_sha256']=sha(report)
audit.write_text(json.dumps(plan,indent=2)+'\n');assert r.returncode==0,r.returncode
assert d['status']=='ok'and d['results'][0]['serial_reference_parity']
paths=sorted(rawdir.glob('worker-*.jsonl'));rows=[]
for p in paths:rows.extend(json.loads(x)for x in p.read_text().splitlines())
installed=[x for x in rows if x['kind']=='installed'];assert installed
for x in installed:assert sha(x['module'])==x['module_sha256'],x['module']
fw=[x for x in rows if x['kind']=='forward'];vision=[x for x in rows if x['kind']=='vision'];assert fw and vision
plan.update(status='pass',raw_logs=[dict(path=str(p),sha256=sha(p))for p in paths],installed=installed,forward_steps=len(fw),mixed_steps=sum(bool(x['prefill_items']and x['decode_items'])for x in fw),decode_only_steps=sum(bool(x['decode_items']and not x['prefill_items'])for x in fw),prefill_query_lengths_observed=sorted(set(n for x in fw for n in x['prefill_query_lengths'])),max_prefill_items=max(x['prefill_items']for x in fw),max_vision_items=max(x['items']for x in vision),stage_wall_seconds={'vision':sum(x['elapsed_wall_ns']for x in vision)/1e9,'forward':sum(x['elapsed_wall_ns']for x in fw)/1e9})
plan['decode_only_wall_ms_by_rows']={str(n):dict(samples=len(g),median_wall_ms=statistics.median(x['elapsed_wall_ns']for x in g)/1e6)for n in sorted(set(x['decode_items']for x in fw if not x['prefill_items']))if(g:=[x for x in fw if not x['prefill_items']and x['decode_items']==n])}
audit.write_text(json.dumps(plan,indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('qualification',paths+[Path('/private/tmp/ocr-engine51-reference-diagnostic.txt')],'logs_manifest.json')
print(json.dumps({k:plan[k]for k in ['status','forward_steps','mixed_steps','max_prefill_items','max_vision_items','stage_wall_seconds','decode_only_wall_ms_by_rows']}),flush=True)
