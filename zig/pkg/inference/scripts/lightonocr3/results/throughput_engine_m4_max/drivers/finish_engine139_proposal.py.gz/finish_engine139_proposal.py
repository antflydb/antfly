from pathlib import Path
import difflib,json,hashlib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';p=v/'engine139_generation.zig';s=p.read_text();s=s.replace('''        while (processed < seq) {
            const query = @min(chunk_rows, seq - processed);''','''        while (processed < seq) {
            try self.checkPreparedQwenContinuation();
            const query = @min(chunk_rows, seq - processed);''',1)
needle='    /// Validate every chunk against its original immutable visual prompt before';assert s.count(needle)==1;s=s.replace(needle,'''    fn checkPreparedQwenContinuation(self: *const NativeGenerationPipeline) !void {
        if (self.execution_control) |control| try control.check();
        if (self.continue_fn) |should_continue| {
            const context = self.continue_ctx orelse return error.InvalidCallbackContext;
            if (!should_continue(context)) return error.Cancelled;
        }
    }

'''+needle)
s=s.replace('prompt.deepstack_layer_count != 0 or prompt.input_embeddings == null)','prompt.deepstack_layer_count != 0 or prompt.input_embeddings == null or\n            work.wants_last_logits != (work.seq_len == full))',1)
needle='''                for (0..3) |axis| @memcpy(positions[axis * total + offsets[index] ..][0..lengths[index]], work.prepared_prompt.?.plan.mrope_positions[axis * work.prepared_prompt.?.plan.tokenCount() + prefill_starts[index] ..][0..lengths[index]]);''';assert s.count(needle)==1;s=s.replace(needle,'                copyPreparedQwenChunkPositions(work, prefill_starts[index], positions, total, offsets[index]);')
needle='    fn forwardPackedScheduledQwenStep(self:';assert s.count(needle)==1;s=s.replace(needle,'''    fn copyPreparedQwenChunkPositions(work: *const PendingPrefillBatchWork, start: usize, output: []u32, total: usize, offset: usize) void {
        const prompt = work.prepared_prompt.?;
        const full = prompt.plan.tokenCount();
        const query = work.query_seq_len;
        std.debug.assert(output.len == 3 * total and offset <= total and query <= total - offset);
        std.debug.assert(start <= full and query <= full - start);
        for (0..3) |axis| @memcpy(output[axis * total + offset ..][0..query], prompt.plan.mrope_positions[axis * full + start ..][0..query]);
    }

'''+needle)
s+='''

test "LightOnOCR3 prepared chunks preserve visual axes independent KV histories and reject replay" {
    const P = NativeGenerationPipeline;
    const a = std.testing.allocator;
    var manager = runtime.kv.manager.KvManager.init(a);
    defer manager.deinit();
    const pool = try manager.addPool(.{ .backend = .native, .dtype = .f16, .page_size_tokens = 4, .num_kv_heads = 1, .head_dim = 2 });
    var state = NativeDecodeState.initPaged(a, &manager, pool, null);
    defer state.deinit();
    var peer = NativeDecodeState.initPaged(a, &manager, pool, null);
    defer peer.deinit();
    try peer.notePrefill(5);
    var marker: u8 = 0;
    var ids: [7]i64 = @splat(1);
    var causal: [7]u32 = undefined;
    var axes: [21]u32 = undefined;
    var visual: [7]bool = @splat(true);
    for (&causal, 0..) |*value, i| value.* = @intCast(i);
    for (0..3) |axis| for (0..7) |i| { axes[axis * 7 + i] = @intCast(axis * 1000 + i); };
    // Metadata validation never dereferences this opaque embedding handle.
    var prompt = qwen3vl_projector.PreparedPrompt{ .allocator = a, .token_ids = &ids, .input_embeddings = @ptrCast(&marker), .plan = .{ .allocator = a, .mrope_positions = &axes, .causal_positions = &causal, .visual_token_mask = &visual, .visual_spans = &.{}, .mrope_position_delta = 0 }, .deepstack_embeddings = &.{}, .deepstack_layer_count = 0 };
    var previous: usize = 0;
    for ([_]usize{ 3, 6, 7 }) |end| {
        const query = end - previous;
        var work = P.PendingPrefillBatchWork{ .allocator = a, .decode_state = &state, .token_ids = &.{}, .seq_len = end, .query_seq_len = query, .wants_last_logits = end == 7, .prepared_prompt = &prompt };
        var item = runtime.scheduler.native_generate.StepItem{ .work_ptr = &work, .phase = .prefill, .query_sequence_len = query, .total_sequence_len = end, .kv_sequence_len = previous, .kv_position_offset = 0 };
        const start = try P.preparedQwenPrefillStart(&work, item);
        try std.testing.expectEqual(previous, start);
        // Both a preceding and a following peer occupy the packed destination.
        const total = query + 2;
        var output: [15]u32 = @splat(0xfeedbeef);
        P.copyPreparedQwenChunkPositions(&work, start, output[0 .. 3 * total], total, 1);
        for (0..3) |axis| {
            try std.testing.expectEqual(@as(u32, 0xfeedbeef), output[axis * total]);
            try std.testing.expectEqual(@as(u32, 0xfeedbeef), output[axis * total + query + 1]);
            try std.testing.expectEqualSlices(u32, axes[axis * 7 + previous ..][0..query], output[axis * total + 1 ..][0..query]);
        }
        item.total_sequence_len += 1;
        try std.testing.expectError(error.InvalidPreparedPrompt, P.preparedQwenPrefillStart(&work, item));
        item.total_sequence_len -= 1;
        var mixed = P.MixedBatchDecodeItem{ .state = &state, .total_sequence_len = end, .query_sequence_len = query, .kv_sequence_len = previous, .attention_mode = .paged_prefill };
        const reserved = try P.reserveAndRefreshScheduledPrefill(&mixed, end);
        try std.testing.expectEqual(query, reserved);
        try std.testing.expectEqual(end, state.total_tokens);
        try std.testing.expectEqual(end, mixed.kv_sequence_len);
        try std.testing.expectEqual(@as(usize, 5), peer.total_tokens);
        try std.testing.expectError(error.InvalidPreparedPrompt, P.preparedQwenPrefillStart(&work, item));
        if (end == 6) {
            // A failed continuation releases only its new suffix reservation.
            P.rollbackPrefillReservations(&.{item}, &.{reserved}, 1);
            try std.testing.expectEqual(previous, state.total_tokens);
            try std.testing.expectEqual(previous, state.kvView().?.token_count);
            try std.testing.expectEqual(@as(usize, 5), peer.kvView().?.token_count);
            _ = try P.preparedQwenPrefillStart(&work, item);
            _ = try P.reserveAndRefreshScheduledPrefill(&mixed, end);
        }
        previous = end;
    }
}

test "LightOnOCR3 prepared chunk cancellation stops before another prefix reservation" {
    const Stop = struct {
        calls: usize = 0,
        fn check(raw: *anyopaque) bool {
            const self: *@This() = @ptrCast(@alignCast(raw));
            self.calls += 1;
            return self.calls < 2;
        }
    };
    var stop = Stop{};
    var pipeline = NativeGenerationPipeline{ .allocator = std.testing.allocator, .cb = undefined, .gpt_config = .{}, .tokenizer = undefined, .continue_ctx = &stop, .continue_fn = Stop.check };
    try pipeline.checkPreparedQwenContinuation();
    try std.testing.expectError(error.Cancelled, pipeline.checkPreparedQwenContinuation());
    try std.testing.expectEqual(@as(usize, 2), stop.calls);
}
'''
p.write_text(s)
paths=['zig/pkg/inference/src/pipelines/generation.zig','zig/pkg/inference/src/server/server.zig','zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py'];patch=''
for name in paths:
 old=(r/name).read_text();new=(v/('engine139_'+Path(name).name)).read_text();patch+=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(v/'engine139_chunked_prefill_proposal.patch').write_text(patch);p=v/'engine139_preparation.json';d=json.loads(p.read_text());d['proposed_sha256']={name:hashlib.sha256((v/('engine139_'+Path(name).name)).read_bytes()).hexdigest()for name in paths};d['validation']='Private proposal only; tests added but not compiled or run; canonical source unchanged.';p.write_text(json.dumps(d,indent=2)+'\n');print('Private proposal includes chunk-range/axis/KV rollback/replay/cancellation checks; not applied or compiled')
