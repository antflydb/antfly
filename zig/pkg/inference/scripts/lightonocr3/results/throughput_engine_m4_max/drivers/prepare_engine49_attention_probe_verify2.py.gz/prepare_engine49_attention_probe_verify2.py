from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
p=v/'engine49_attention_runtime.m';s=p.read_text()
old='runtime->lightonocr3_prefill_attention_mpp32_pipeline || [runtime->lightonocr3_prefill_attention_direct_pipeline.label hasSuffix:@"_q32"] ? 32 : 16;'
assert s.count(old)==1
s=s.replace(old,'runtime->lightonocr3_prefill_attention_mpp32_pipeline ? 32 : engine49_query_tile;')
s='static unsigned long engine49_query_tile = 16;\n'+s;p.write_text(s)
p=v/'engine49_attention_probe.m';s=p.read_text()
assert s.count('  b->psos[mode].label=name;')==1
s=s.replace('  b->psos[mode].label=name;','')
needle=' b->r->lightonocr3_prefill_attention_direct_pipeline=b->psos[mode];'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n engine49_query_tile=(mode==2||mode==4)?32:16;')
checker=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_prefill_attention.m').read_text()
checker=checker.replace('#include "../../src/backends/metal_kernels.m"','').replace('int main(int argc, const char **argv)','int engine49_original_conformance_main(int argc, const char **argv)')
s+='\n'+checker+r'''
int probe49_conformance(void*raw,int mode) {
 @autoreleasepool{
 Probe49*b=raw;b->r->lightonocr3_prefill_attention_direct_pipeline=b->psos[mode];engine49_query_tile=(mode==2||mode==4)?32:16;
 const size_t lengths[]={128,129,432,554,662,1024,2048};
 for(size_t h=8;h<=16;h+=8){
  for(size_t i=0;i<sizeof(lengths)/sizeof(lengths[0]);i++){int rc=check(b->r,lengths[i],0,h,128,false,0,false);if(rc)return rc;}
  if(check(b->r,129,63,h,16,true,0,false)||check(b->r,432,129,h,128,true,0,false))return 30;
  for(int poison=1;poison<=4;poison++)if(check(b->r,129,0,h,128,false,poison,false)||check(b->r,432,0,h,16,true,poison,false))return 31;
  if(check(b->r,129,63,h,8,false,0,false))return 32;
 }
 return 0;
 }
}
'''
p.write_text(s)
record=json.loads((out/'engine49_attention_probe_preparation.json').read_text())
inputs=[*record['inputs'], 'zig/pkg/inference/scripts/lightonocr3/check_metal_prefill_attention.m']
record['inputs']={str(p):hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in inputs}
record['scope']+=' Private dispatch tile override follows explicit mode; no writable pipeline-label assumption. Adds original standalone full-output/CPU/private producer/canary/cancel/nonfinite/padded stride/page prefix checks.'
record['status']='prepared_not_built'
(out/'engine49_attention_probe_preparation_verify2.json').write_text(json.dumps(record,indent=2)+'\n')
