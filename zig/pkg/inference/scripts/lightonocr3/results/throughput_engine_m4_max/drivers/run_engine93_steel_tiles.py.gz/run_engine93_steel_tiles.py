from pathlib import Path
import hashlib,json,os,psutil,subprocess,datetime,time,statistics
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=json.loads((v/'engine93_steel_preparation.json').read_text());assert all(sha(r/f)==h for f,h in p['input_sha256'].items());assert sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')==p['production_c_sha256']
a=o/'engine93_steel_tiles_audit.json';assert not a.exists();d=dict(status='preparing',primary_throughput_eligible=False,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),preparation=p,driver_sha256=sha(Path(__file__)),candidates=[])
def save():a.write_text(json.dumps(d,indent=2)+'\n')
save()
try:
 b=v/'engine93_real_ffn_probe';assert not b.exists();cmd=['clang','-O3','-fobjc-arc','-I','zig/pkg/inference/src/backends',str(v/'engine93_real_ffn_probe.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(b)]
 with Path('/private/tmp/ocr-engine93-steel-build.txt').open('w')as f:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
 d['build_exit_code']=result.returncode;save();assert result.returncode==0
 d['binary_sha256']=sha(b)
 original=json.loads((o/'engine83_real_ffn_probe_retry_audit.json').read_text());d['real_weight_payloads']=original['real_weight_payloads'];save()
 model=Path(json.loads((v/'engine82_real_ffn_preparation.json').read_text())['model_path']);before=model.stat()
 with model.open('rb')as f:
  for w in d['real_weight_payloads']:
   f.seek(w['offset']);assert hashlib.sha256(f.read(w['bytes'])).hexdigest()==w['sha256']
 assert before.st_mtime_ns==model.stat().st_mtime_ns
 for m,n,k,wm,wn in p['shapes']:
  while psutil.virtual_memory().available<8*1024**3:
   d.update(status='waiting_original_reserve',available_bytes=psutil.virtual_memory().available);save();print('WAIT93',d['available_bytes'],flush=True);time.sleep(15)
  name=f'm{m}n{n}k{k}w{wm}x{wn}';so=Path(f'/private/tmp/ocr-engine93-{name}-stdout.txt');se=Path(f'/private/tmp/ocr-engine93-{name}-stderr.txt');assert not so.exists()and not se.exists()
  c=dict(name=name,shape=[m,n,k,wm,wn],available_before=psutil.virtual_memory().available);d['candidates'].append(c);d['status']='running';save()
  with so.open('w')as f,se.open('w')as e:result=subprocess.run([str(b),str(v/f'engine93_steel_{name}.metal')],stdout=f,stderr=e,env=dict(os.environ,ANTFLY_LIGHTONOCR3_THROUGHPUT='0',ENGINE93_M=str(m),ENGINE93_N=str(n),ENGINE93_THREADS=str(wm*wn*32)),timeout=900)
  records=[json.loads(l)for l in so.read_text().splitlines()if l.startswith('{"rows":')];c.update(exit_code=result.returncode,records=records,stdout_sha256=sha(so),stderr_sha256=sha(se),status='failed_or_unsupported');save()
  if result.returncode==0:
   assert len(records)==12 and all(len(x['gpu_us'])==8 for x in records)
   assert 'REAL93 FULL REAL-WEIGHT OUTPUT/CPU/CANARY CHECKS PASS'in se.read_text()
   c['status']='prototype_pass';c['ratios']={str(rows):statistics.mean(statistics.median(x['gpu_us'])for x in records if x['rows']==rows and x['candidate_enabled'])/statistics.mean(statistics.median(x['gpu_us'])for x in records if x['rows']==rows and not x['candidate_enabled'])for rows in [432,554,662]}
  save();print(name,c['status'],c.get('ratios'),flush=True)
 d['status']='complete_private_screen';save()
except BaseException as e:d.update(status='failed',error=repr(e));save();raise
