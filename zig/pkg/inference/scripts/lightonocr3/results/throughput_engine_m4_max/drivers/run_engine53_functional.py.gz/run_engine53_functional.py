from pathlib import Path
import subprocess,sys
v=Path('.venv-lighton-vllm-metal')
for name in ['preset_only_test','preset_physical32_test','default_gpu_test']:
 print('START',name,flush=True)
 with open('/private/tmp/ocr-engine53-functional-'+name+'-driver.txt','w')as out:r=subprocess.run([sys.executable,str(v/('engine53_verify_'+name+'.py'))],stdout=out,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
