from pathlib import Path
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text();a=s.index('static int wide_projection_tiles_check(');b=s.index('\nint main(',a);body=s[a:b];new=body.replace('wide_projection_tiles_check','wide_mpp_check').replace('TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_PROJECTION_TILES','TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_MPP').replace('r->lightonocr3_wide_projection_tile_calls','(*counter)').replace('WIDE_PROJECTION_TILES','WIDE_MPP_CHECK')
new=new.replace('  id<MTLBuffer> x=', '  uint64_t *counter=out==248320?&r->lightonocr3_wide_mpp_head_calls:&r->lightonocr3_wide_mpp_projection_calls;\n  id<MTLBuffer> x=',1)
# The old path is independently checked, rather than using the new dispatch
# as its own oracle. Include scalar CPU samples before comparisons.
anchor='  memcpy(gold,got,rows*out*4);';new=new.replace(anchor,anchor+'''
  for(size_t row=0;row<rows;row+=rows>1?rows-1:1)for(size_t col=0;col<out;col+=out>1?out-1:1){
    double want=b[col];for(size_t k=0;k<in;k++)want+=(double)v[row*in+k]*expand_bf16(w[col*in+k]);
    if(fabs(want-gold[row*out+col])>2e-4)return 12;
  }''',1)
new=new.replace('  // A GPU producer feeds the full wide input through the same planned\n  // encoder. The consumer spans both tiles and their shared scratch hazards.','  // A GPU producer feeds the matrix head/projection through the same\n  // planned encoder. The input must remain on device across the dependency.')
new=new.replace('  free(w);free(b);free(gold);return 0;','''  // Missing optional pipelines must decline before encoding anything.
  id<MTLComputePipelineState> saved[3];
  for(size_t i=0;i<3;i++){saved[i]=r->lightonocr3_wide_mpp_pipelines[i];r->lightonocr3_wide_mpp_pipelines[i]=nil;}
  if(termite_metal_try_lightonocr3_wide_mpp(r,0,x,16,rows,in,out,y,16)!=0)return 13;
  for(size_t i=0;i<3;i++)r->lightonocr3_wide_mpp_pipelines[i]=saved[i];
  free(w);free(b);free(gold);return 0;''',1)
body=body.replace('  id<MTLBuffer> x=','  setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_MPP","1",1);\n  id<MTLBuffer> x=',1).replace('  free(w);free(b);free(gold);return 0;','  unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_MPP");\n  free(w);free(b);free(gold);return 0;',1)
s=s[:a]+body+'\n'+new+s[b:]
a='        const bool wide_tiles_benchmark =';i=s.index(a);s=s[:i]+'''        if (argc == 2 && strcmp(argv[1], "--check-wide-mpp") == 0) {
            const size_t cases[][3]={{9,1024,6144},{12,1024,4096},{13,1024,2048},{16,2048,1024},
                {9,2560,4096},{12,2560,8192},{9,1024,3584},{9,2560,9216},{13,4096,2560},
                {9,1024,248320},{12,1024,248320},{16,1024,248320},
                {9,2560,248320},{12,2560,248320},{16,2560,248320}};
            for(size_t i=0;i<sizeof(cases)/sizeof(cases[0]);i++){
                int rc=wide_mpp_check(r,cases[i][0],cases[i][1],cases[i][2],false);
                if(rc){fprintf(stderr,"WIDE_MPP_FAIL case=%zu rc=%d\\n",i,rc);return 124;}
            }
            termite_metal_decode_runtime_destroy(r);return 0;
        }
'''+s[i:];p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text().replace('                        "wide_projection_tiles",','                        "wide_projection_tiles",\n                        "wide_mpp_projections",\n                        "wide_mpp_heads",',1);s=s.replace('            "TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_PROJECTION_TILES",','            "TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_PROJECTION_TILES",\n            "TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_MPP",',1);p.write_text(s)
