from pathlib import Path
import json,hashlib,subprocess
v=Path('.venv-lighton-vllm-metal')
for p,h in json.loads((v/'engine63-freeze.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
changes=json.loads((v/'engine64_prepared_changes.json').read_text())
r='zig/pkg/inference/src/backends/metal_runtime.zig'
changes[r]=changes[r].replace('runtime: ?*anyopaque, slot: usize, rows: usize, dim: usize, output:', 'runtime: ?*RawMetalDecodeRuntime, slot: usize, rows: usize, dim: usize, output:').replace('runtime: ?*anyopaque, output: [*]u32, rows:', 'runtime: ?*RawMetalDecodeRuntime, output: [*]u32, rows:')
m='zig/pkg/inference/src/ops/metal_compute.zig'
a='        if (b.native_dense_dtype != .bf16 or b.native_dense_bytes == null or b.mutable_state) return null;'
b='''        const storage = b.quantized_storage orelse b.runtime_quantized_storage;
        const bf16 = if (storage) |s| switch (s.tensor_type) { .known => |kind| kind == .BF16, else => false } else b.native_dense_dtype == .bf16 and b.native_dense_bytes != null;
        if (!bf16 or b.mutable_state) return null;'''
assert changes[m].count(a)==1;changes[m]=changes[m].replace(a,b)
for p,s in changes.items():Path(p).write_text(s)
subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt',*[p for p in changes if p.endswith('.zig')]],check=True)
print('APPLIED64',len(changes))
