const std = @import("std");
fn lightOnReportedRowBit(rows: usize) u64 {
    if (rows == 0 or rows > 64) return 0;
    return @as(u64, 1) << @as(u6, @intCast(rows - 1));
}

test "LightOnOCR3 row reporting covers sixty-four cohorts without shift overflow" {
    var seen: u64 = 0;
    for (1..65) |rows| {
        const bit = lightOnReportedRowBit(rows);
        try std.testing.expect(bit != 0);
        try std.testing.expectEqual(@as(u64, 0), seen & bit);
        seen |= bit;
    }
    try std.testing.expectEqual(std.math.maxInt(u64), seen);
    try std.testing.expectEqual(@as(u64, 1), lightOnReportedRowBit(1));
    try std.testing.expectEqual(@as(u64, 1) << 63, lightOnReportedRowBit(64));
    try std.testing.expectEqual(@as(u64, 0), lightOnReportedRowBit(0));
    try std.testing.expectEqual(@as(u64, 0), lightOnReportedRowBit(65));
    try std.testing.expectEqual(@as(u64, 0), lightOnReportedRowBit(std.math.maxInt(usize)));
}
