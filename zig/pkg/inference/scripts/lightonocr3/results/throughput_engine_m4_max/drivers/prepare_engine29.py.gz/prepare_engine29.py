from pathlib import Path
import json,hashlib,subprocess
v=Path('.venv-lighton-vllm-metal');freeze=json.loads((v/'engine28-freeze.json').read_text())
for f,h in freeze.items():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h,f
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text()
s=s.replace('    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_PREFILL_PACK_REUSE,','    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_PREFILL_PACK_REUSE,\n    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_DECODE_PACK_REUSE,',1)
s=s.replace('    "TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PACK_REUSE",','    "TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PACK_REUSE",\n    "TERMITE_METAL_DISABLE_LIGHTONOCR3_DECODE_PACK_REUSE",',1)
s=s.replace('    uint64_t lighton_prefill_pack_reuse_hits;','    uint64_t lighton_prefill_pack_reuse_hits;\n    uint64_t lighton_decode_pack_calls;\n    uint64_t lighton_decode_pack_reuse_hits;',1)
a=s.index('    // Packing does not create a live tensor:');b=s.index('    id<MTLBuffer> packed = nil;',a)
s=s[:a]+'''    // The packed input has exactly one consumer. Recycle only after that
    // projection, in a serial frame with no submitted prefix. Explicit BF16
    // decode uses the same lifetime; F32 decoder inputs remain unchanged.
    const bool prefill_pack_scope = rows >= 32u && rows <= 4096u &&
        runtime->active_frame_regime == TERMITE_METAL_FRAME_REGIME_PREFILL &&
        !termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_PREFILL_PACK_REUSE);
    const bool decode_pack_scope = wide_rows &&
        runtime->active_frame_regime == TERMITE_METAL_FRAME_REGIME_DECODE &&
        !termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_DECODE_PACK_REUSE);
    const bool reuse_packed = bf16 && !owned && (prefill_pack_scope || decode_pack_scope) &&
        runtime->active_frame_cb == cb && runtime->submitted_frame_cb == nil &&
        !termite_metal_concurrent_planned_dispatch_enabled(runtime);
'''+s[b:]
s=s.replace('''        const uint64_t reuse_before = runtime->reuse_hit_count;
        packed = reuse_packed''','''        const uint64_t reuse_before = runtime->reuse_hit_count;
        const uint64_t activation_before = runtime->lighton_activation_hits;
        packed = reuse_packed''',1)
old='''        if (reuse_packed) {
            runtime->lighton_prefill_pack_calls += 1;
            runtime->lighton_prefill_pack_reuse_hits += runtime->reuse_hit_count > reuse_before;
        }'''
new='''        if (reuse_packed && prefill_pack_scope) {
            runtime->lighton_prefill_pack_calls += 1;
            runtime->lighton_prefill_pack_reuse_hits += runtime->reuse_hit_count > reuse_before;
        } else if (reuse_packed && decode_pack_scope) {
            runtime->lighton_decode_pack_calls += 1;
            runtime->lighton_decode_pack_reuse_hits += runtime->reuse_hit_count > reuse_before ||
                runtime->lighton_activation_hits > activation_before;
        }'''
assert old in s;s=s.replace(old,new,1)
s+='''

void termite_metal_decode_runtime_lighton_decode_pack_stats(termite_metal_decode_runtime *runtime, uint64_t *out) {
    if (out == NULL) return;
    out[0] = runtime != NULL ? runtime->lighton_decode_pack_calls : 0;
    out[1] = runtime != NULL ? runtime->lighton_decode_pack_reuse_hits : 0;
}
''';p.write_text(s)
p=Path('zig/pkg/inference/src/backends/metal_runtime.zig');s=p.read_text();anchor='pub extern fn termite_metal_decode_runtime_lighton_prefill_pack_stats(runtime: ?*RawMetalDecodeRuntime, out: *[2]u64) void;';assert anchor in s;s=s.replace(anchor,anchor+'\npub extern fn termite_metal_decode_runtime_lighton_decode_pack_stats(runtime: ?*RawMetalDecodeRuntime, out: *[2]u64) void;',1);p.write_text(s)
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text();s=s.replace('    lighton_prefill_pack_baseline: [2]u64 = @splat(0),','    lighton_prefill_pack_baseline: [2]u64 = @splat(0),\n    lighton_decode_pack_baseline: [2]u64 = @splat(0),',1)
anchor='        metal_runtime_mod.termite_metal_decode_runtime_lighton_prefill_pack_stats(raw, &self.lighton_prefill_pack_baseline);';assert anchor in s;s=s.replace(anchor,anchor+'\n        metal_runtime_mod.termite_metal_decode_runtime_lighton_decode_pack_stats(raw, &self.lighton_decode_pack_baseline);',1)
a=s.index('    pub fn lightOnPrefillPackStats(');b=s.index('    pub fn lightOnBatchAttentionStats(',a);method=s[a:b].replace('lightOnPrefillPackStats','lightOnDecodePackStats').replace('lighton_prefill_pack','lighton_decode_pack');s=s[:b]+method+s[b:];p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text();anchor='                    std.debug.print("LIGHTONOCR3 prefill_pack_calls={d} prefill_pack_reuse_hits={d}\\n", .{ prefill_pack[0], prefill_pack[1] });';assert anchor in s;s=s.replace(anchor,anchor+'''
                    const decode_pack = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnDecodePackStats(&cb) else @as([2]u64, @splat(0));
                    std.debug.print("LIGHTONOCR3 decode_pack_calls={d} decode_pack_reuse_hits={d}\\n", .{ decode_pack[0], decode_pack[1] });''',1);p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text();a=s.index('static int prefill_pack_reuse_check(');b=s.index('\nint main(',a);method=s[a:b]
method=method.replace('prefill_pack_reuse_check','decode_pack_reuse_check').replace('size_t out, bool benchmark)', 'size_t out, bool benchmark, bool activation_pool)')
# clang-format may have wrapped the function signature differently.
if 'bool activation_pool' not in method:
 method=method.replace('bool benchmark) {','bool benchmark, bool activation_pool) {',1)
assert 'bool activation_pool' in method
method=method.replace('const size_t steps = 6,', 'const size_t steps = out == 248320 ? 2 : 6,',1)
method=method.replace('modes = benchmark ? 2 : 5', 'modes = benchmark ? 2 : 6').replace('results[5][6]', 'results[6][6]')
method=method.replace('TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PACK_REUSE','TERMITE_METAL_DISABLE_LIGHTONOCR3_DECODE_PACK_REUSE').replace('TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS','TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS').replace('TERMITE_METAL_FRAME_REGIME_PREFILL','TERMITE_METAL_FRAME_REGIME_DECODE').replace('lighton_prefill_pack','lighton_decode_pack').replace('rows <= 4096','rows <= 32').replace('prefill_pack_reuse rows=', 'decode_pack_reuse rows=')
method=method.replace('  const size_t steps = out == 248320 ? 2 : 6,', '''  if (termite_metal_decode_runtime_set_lighton_activation_pool(r, activation_pool ? 8*1024*1024 : 0)) return 16;
  const uint64_t prefill_before = r->lighton_prefill_pack_calls;
  const size_t steps = out == 248320 ? 2 : 6,''',1)
method=method.replace('''      if (mode == 0)
''','''      // Standalone skinny non-head projections have a different legacy
      // precision fallback. Owned-frame rollback is tested at32 and the head.
      if (mode == 3 && rows < 32 && out != 248320) continue;
      if (mode == 0)
''',1)
method=method.replace('      const int old_reuse = r->buffer_reuse_enabled;', '      const bool old_concurrent = r->concurrent_planned_dispatch_enabled;\n      if (mode == 5) r->concurrent_planned_dispatch_enabled = true;\n      const int old_reuse = r->buffer_reuse_enabled;',1)
method=method.replace('      r->buffer_reuse_enabled = old_reuse;', '      r->concurrent_planned_dispatch_enabled = old_concurrent;\n      r->buffer_reuse_enabled = old_reuse;',1)
method=method.replace('''      if (mode == 2)
        r->buffer_reuse_enabled = 0;''','''      if (mode == 2) {
        r->buffer_reuse_enabled = 0;
        if (activation_pool && termite_metal_decode_runtime_set_lighton_activation_pool(r, 0)) return 17;
      }''',1)
method=method.replace('''      r->buffer_reuse_enabled = old_reuse;''','''      r->buffer_reuse_enabled = old_reuse;
      if (mode == 2 && activation_pool && termite_metal_decode_runtime_set_lighton_activation_pool(r, 8*1024*1024)) return 18;''',1)
method=method.replace('''  free(weights);
  free(bias);''','''  if (r->lighton_prefill_pack_calls != prefill_before) return 19;
  uint64_t stats[4] = {0};
  termite_metal_decode_runtime_lighton_activation_pool_stats(r, stats);
  if (stats[1] > 8*1024*1024 || stats[3] != 0) return 20;
  if (termite_metal_decode_runtime_set_lighton_activation_pool(r, 0)) return 21;
  free(weights);
  free(bias);''',1)
# Keep the original periodic values, avoid hundreds of millions of cosf calls
# when qualifying the actual vocabulary head.
old='''  for (size_t j = 0; j < in * out; j++)
    weights[j] = round_bf16(cosf((float)(j % 997) * .127f) * .015f);'''
new='''  uint16_t pattern[997];
  for (size_t j = 0; j < 997; j++) pattern[j] = round_bf16(cosf((float)j * .127f) * .015f);
  for (size_t j = 0; j < in * out; j++) weights[j] = pattern[j % 997];'''
assert old in method;method=method.replace(old,new,1)
method=method.replace('"decode_pack_reuse rows=%zu in=%zu steps=%zu cpu_max_abs=%g "', '"decode_pack_reuse rows=%zu in=%zu out=%zu activation_pool=%d steps=%zu cpu_max_abs=%g "')
method=method.replace('      rows, in, steps, cpu_worst,', '      rows, in, out, activation_pool ? 1 : 0, steps, cpu_worst,',1)
method=subprocess.check_output(['/opt/homebrew/opt/llvm/bin/clang-format','--assume-filename=check.m'],input=method,text=True)
s=s[:b]+'\n'+method+s[b:];anchor='''        if (argc == 2 && (strcmp(argv[1], "--check-prefill-pack-reuse")''';assert anchor in s
block='''if (argc == 2 && (strcmp(argv[1], "--check-decode-pack-reuse") == 0 || strcmp(argv[1], "--benchmark-decode-pack-reuse") == 0)) {
    const bool benchmark = strstr(argv[1], "benchmark") != NULL;
    const size_t shapes[][3] = {{32,2560,4096},{32,9216,2560},{17,1024,4096},{24,1024,4096},{31,1024,4096},{32,1024,4096},{17,2560,4096},{24,2560,4096},{31,2560,4096},{33,2560,4096},{32,2560,248320}};
    const size_t count = benchmark ? 2 : sizeof(shapes)/sizeof(shapes[0]);
    for(size_t pool=0;pool<2;pool++)for(size_t i=0;i<count;i++) { @autoreleasepool {
        int rc=decode_pack_reuse_check(r,shapes[i][0],shapes[i][1],shapes[i][2],benchmark,pool!=0);
        if(rc){fprintf(stderr,"DECODE_PACK_REUSE_FAIL rows=%zu in=%zu out=%zu pool=%zu rc=%d\\n",shapes[i][0],shapes[i][1],shapes[i][2],pool,rc);return 133;}
    }}
    termite_metal_decode_runtime_destroy(r);return 0;
}
'''
block=subprocess.check_output(['/opt/homebrew/opt/llvm/bin/clang-format','--assume-filename=check.m'],input=block,text=True);block=''.join('        '+line if line.strip()else line for line in block.splitlines(keepends=True))
s=s.replace(anchor,block+anchor,1);p.write_text(s)
print('29 explicit BF16 decode pack-buffer reuse prepared; F32 and prefill scopes unchanged')
