from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');dest=v/'engine54-product-proposal';m=json.loads((v/'engine54_product_proposal_formatted.json').read_text())
p='zig/pkg/inference/src/server/executor_microbatch.zig';s=Path(p).read_text()
needle='    next_execution_id: std.atomic.Value(u64) = .init(1),';assert s.count(needle)==1
s=s.replace(needle,needle+'''
    /// Configure before first submission. A stage with one physical executor
    /// can keep queued groups mergeable until its preceding callback finishes.
    /// The borrowed mutex must outlive every submission and broker teardown.
    execution_mutex: ?*std.Io.Mutex = null,
''')
needle='    fn executeGroup(self: *Broker, io: std.Io, shard: *BrokerShard, group: *Group) void {\n';assert s.count(needle)==1
s=s.replace(needle,needle+'''        // Lock before detaching the group. Tickets remain independently
        // admitted and may join up to the existing limits while we wait.
        // Filter cancellation/deadlines only after this lane becomes ready;
        // cancellation of its leader must not discard live followers.
        if (self.execution_mutex) |mutex| mutex.lockUncancelable(io);
        defer if (self.execution_mutex) |mutex| mutex.unlock(io);
''')
s+=(v/'engine54_late_seal_test.inc').read_text();target=dest/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(s);m['files'][p]='pending_format'
p='zig/pkg/inference/src/server/server.zig';s=(dest/p).read_text()
needle='        prefill_broker: executor_microbatch.Broker,';assert s.count(needle)==1
s=s.replace(needle,needle+'\n        vision_seal_mutex: std.Io.Mutex = .init,\n        prefill_seal_mutex: std.Io.Mutex = .init,')
needle='            stream_chunks: bool = false,';assert needle in s
s=s.replace(needle,needle+'\n            vision_late_seal: bool = false,\n            prefill_late_seal: bool = false,')
needle='                    .prefill_batch = prefill_batch,';assert s.count(needle)==1
s=s.replace(needle,needle+'''\n                    .vision_late_seal = epoch_auxiliary and metal_runtime.qualifiedM4DeviceDefault() and platform.env.getenvBool("ANTFLY_LIGHTONOCR3_VISION_LATE_SEAL"),
                    .prefill_late_seal = epoch_auxiliary and metal_runtime.qualifiedM4DeviceDefault() and platform.env.getenvBool("ANTFLY_LIGHTONOCR3_PREFILL_LATE_SEAL"),''')
needle='            ctx.* = .{ .allocator = a, .model = factory.model';a=s.index(needle);b=s.index('\n',a)+1
s=s[:b]+'''            if (factory.features.vision_late_seal) ctx.vision_broker.execution_mutex = &ctx.vision_seal_mutex;
            if (factory.features.prefill_late_seal) ctx.prefill_broker.execution_mutex = &ctx.prefill_seal_mutex;
'''+s[b:]
needle='                    const batch_argmax = ';a=s.index(needle);b=s.index('\n',s.index('std.debug.print("LIGHTONOCR3 batch_argmax_calls=',a))+1
s=s[:b]+'''                    std.debug.print("LIGHTONOCR3 vision_late_seal={d}\\nLIGHTONOCR3 prefill_late_seal={d}\\n", .{ @intFromBool(ctx.features.vision_late_seal), @intFromBool(ctx.features.prefill_late_seal) });
'''+s[b:]
needle='        "ANTFLY_LIGHTONOCR3_GPU_GREEDY_STREAM",';a=s.index(needle);s=s[:a]+'''        "ANTFLY_LIGHTONOCR3_VISION_LATE_SEAL", "ANTFLY_LIGHTONOCR3_PREFILL_LATE_SEAL",
'''+s[a:]
(dest/p).write_text(s)
p='zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';s=(dest/p).read_text();needle='    env["ANTFLY_LIGHTONOCR3_STREAM_CHUNKS"]'
a=s.index(needle);s=s[:a]+'''    env["ANTFLY_LIGHTONOCR3_VISION_LATE_SEAL"] = "1" if args.defer_vision_seal else "0"
    env["ANTFLY_LIGHTONOCR3_PREFILL_LATE_SEAL"] = "1" if args.defer_prefill_seal else "0"
'''+s[a:]
needle='    args = parser.parse_args()';s=s.replace(needle,'''    parser.add_argument("--defer-vision-seal", action="store_true", help="Keep queued vision groups open until their stage executor is ready")
    parser.add_argument("--defer-prefill-seal", action="store_true", help="Keep queued prefill groups open until their stage executor is ready")
'''+needle)
s=s.replace('        "batch_argmax": args.batch_argmax,','        "batch_argmax": args.batch_argmax,\n        "defer_vision_seal": args.defer_vision_seal,\n        "defer_prefill_seal": args.defer_prefill_seal,')
(dest/p).write_text(s)
(v/'engine54_product_proposal_late_seal_unformatted.json').write_text(json.dumps(m,indent=2)+'\n');print('prepared optional stage queue serialization; actual source still engine53')
