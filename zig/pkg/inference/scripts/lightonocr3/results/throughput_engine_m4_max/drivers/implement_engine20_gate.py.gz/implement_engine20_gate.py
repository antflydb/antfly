from pathlib import Path
p=Path('zig/pkg/inference/src/pipelines/generation.zig');s=p.read_text().replace('    execution_lock: ?*std.atomic.Mutex = null,','    execution_lock: ?*std.atomic.Mutex = null,\n    /// Optional FIFO/event admission for the same atomic backend mutex.\n    execution_gate: ?*execution_control_mod.ExecutionLane = null,',1)
# Check the existing import spelling before writing.
s=s.replace('const InferenceExecutionControl = @import("../execution_control.zig").InferenceExecutionControl;', 'const execution_control_mod = @import("../execution_control.zig");\nconst InferenceExecutionControl = execution_control_mod.InferenceExecutionControl;')
needle='''        if (self.execution_control) |control|
            try control.lockWithPoll(mutex, self.execution_contention_wait_ns)
        else
            platform.sync.lockYielding(mutex);'''
replacement='''        var control = self.execution_control orelse InferenceExecutionControl{};
        if (control.io == null) control.io = self.io;
        const gate = if (self.execution_lock == mutex) self.execution_gate else null;
        const queued = if (gate) |lane| try lane.acquireWithPriority(control, waiters != null) else null;
        errdefer if (queued) |lease| lease.release();
        try control.lockWithPoll(mutex, self.execution_contention_wait_ns);'''
assert needle in s;s=s.replace(needle,replacement,1)
needle='''        if (waiters != null) {
            (InferenceExecutionControl{}).lockWithPoll(mutex, if (self.execution_contention_wait_ns == 0) 100 * std.time.ns_per_us else self.execution_contention_wait_ns) catch unreachable;
        } else platform.sync.lockYielding(mutex);
    }
'''
replacement='''        // Cleanup ignores request cancellation while retaining an event wait
        // on the caller's live Io. It must retire borrowed GPU state first.
        if (self.execution_lock == mutex) if (self.execution_gate) |lane| {
            _ = lane.acquireWithPriority(.{ .io = self.io }, waiters != null) catch unreachable;
        };
        if (waiters != null) {
            (InferenceExecutionControl{}).lockWithPoll(mutex, if (self.execution_contention_wait_ns == 0) 100 * std.time.ns_per_us else self.execution_contention_wait_ns) catch unreachable;
        } else platform.sync.lockYielding(mutex);
    }

    fn unlockExecution(self: *const NativeGenerationPipeline, mutex: *std.atomic.Mutex) void {
        mutex.unlock();
        if (self.execution_lock == mutex) if (self.execution_gate) |lane| {
            (execution_control_mod.ExecutionLane.Lease{ .lane = lane }).release();
        };
    }
'''
assert needle in s;s=s.replace(needle,replacement,1)
# Only generation pipeline methods have this optional gate. Other mutexes
# (including per-page KV gates) retain ordinary atomic unlocks via the helper.
a=s.index('    fn unlockExecution(');b=s.index('\ntest ',a)
chunk=s[a:b]
for name in ['self.execution_lock','kv_mutation_mutex','direct_execution_mutex']:
 chunk=chunk.replace('defer if ('+name+') |mutex| mutex.unlock();','defer if ('+name+') |mutex| self.unlockExecution(mutex);')
chunk=chunk.replace('if (direct_execution_mutex) |mutex| platform.sync.lockYielding(mutex);','if (direct_execution_mutex) |mutex| try self.lockExecution(mutex);')
s=s[:a]+chunk+s[b:]
# Existing intentionally partial fixture now initializes the new dependency.
s=s.replace('    pipeline.execution_lock = &mutex;\n    pipeline.execution_phase_waiters', '    pipeline.execution_lock = &mutex;\n    pipeline.execution_gate = null;\n    pipeline.io = std.testing.io;\n    pipeline.execution_phase_waiters')
p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text().replace('        step_mutex: std.atomic.Mutex = .unlocked,','        step_mutex: std.atomic.Mutex = .unlocked,\n        step_gate: execution_control_mod.ExecutionLane = .{},\n        gate_events: bool = false,',1)
s=s.replace('            ctx.phase_fair = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_PHASE_FAIR");','            ctx.phase_fair = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_PHASE_FAIR");\n            ctx.gate_events = ctx.coordinator.usesStepEvents() and platform.env.getenvBoolDefault("ANTFLY_LIGHTONOCR3_GATE_EVENTS", true);',1)
s=s.replace('                std.debug.print("LIGHTONOCR3 executor_steps={d}\\n", .{ctx.worker_steps});','                std.debug.print("LIGHTONOCR3 gate_events={d} gate_event_acquisitions={d} gate_event_waits={d}\\n", .{ @intFromBool(ctx.gate_events), ctx.step_gate.acquisitions, ctx.step_gate.event_waits });\n                std.debug.print("LIGHTONOCR3 executor_steps={d}\\n", .{ctx.worker_steps});',1)
needle='            try control.lockWithPoll(&ctx.step_mutex, ctx.phase_wait_ns);'
replacement='''            const queued = if (ctx.gate_events) try ctx.step_gate.acquireWithPriority(control, true) else null;
            errdefer if (queued) |lease| lease.release();
            try control.lockWithPoll(&ctx.step_mutex, ctx.phase_wait_ns);'''
assert needle in s;s=s.replace(needle,replacement,1)
needle='''            if (ctx.phase_wait_ns == 0) return platform.sync.lockYielding(&ctx.step_mutex);'''
replacement='''            if (ctx.gate_events) {
                _ = ctx.step_gate.acquireWithPriority(.{ .io = if (ctx.worker_io) |*owner| owner.io() else null }, true) catch unreachable;
            }
            if (ctx.phase_wait_ns == 0) return platform.sync.lockYielding(&ctx.step_mutex);'''
s=s.replace(needle,replacement,1)
needle='''        fn admitPage(ctx: *LightOnStreamContext,'''
replacement='''        fn unlockStep(ctx: *LightOnStreamContext) void {
            ctx.step_mutex.unlock();
            if (ctx.gate_events) (execution_control_mod.ExecutionLane.Lease{ .lane = &ctx.step_gate }).release();
        }
        fn admitPage(ctx: *LightOnStreamContext,'''
assert needle in s;s=s.replace(needle,replacement,1)
a=s.index('        fn admitPage(ctx: *LightOnStreamContext,');b=s.index('        var step_mutex: std.atomic.Mutex = .unlocked;',a)
chunk=s[a:b].replace('ctx.step_mutex.unlock();','ctx.unlockStep();').replace('.execution_lock = &ctx.step_mutex,','.execution_lock = &ctx.step_mutex,\n                .execution_gate = if (ctx.gate_events) &ctx.step_gate else null,')
chunk=chunk.replace('if (ctx.phase_fair and ctx.phase_waiters.load(.acquire) != 0)', 'if (ctx.phase_fair and !ctx.gate_events and ctx.phase_waiters.load(.acquire) != 0)')
s=s[:a]+chunk+s[b:]
# Existing partial CPU resource-admission fixture also initializes gate state.
s=s.replace('    ctx.step_mutex = .unlocked;','    ctx.step_mutex = .unlocked;\n    ctx.step_gate = .{};\n    ctx.gate_events = false;')
p.write_text(s)
