from pathlib import Path
import datetime,hashlib,json,os,psutil,subprocess,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prep=json.loads((v/'engine82_real_ffn_preparation.json').read_text());assert all(sha(r/p)==h for p,h in prep['inputs'].items());assert sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')==prep['production_c_sha256']
assert json.loads((o/'paired73_4b_comparison_audit.json').read_text())['status']=='native_behind'
a=o/'engine89_real_tiles_audit.json';assert not a.exists();inputs=dict(prep['inputs']);inputs[str(v/'engine89_real_ffn_probe.m')]=sha(v/'engine89_real_ffn_probe.m')
d=dict(status='preparing',primary_throughput_eligible=False,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Four real FFN layer triplets; 256/512-thread larger packed FFN tiles versus current qualified packed FFN. Each shape uses ABBA, full output and packed bit identity, CPU corners and canaries. Original caps/reserve. Runs only after the entire primary73 comparison closes. No paused controller. No production changes or model throughput claim.',driver_sha256=sha(Path(__file__)),inputs=inputs,checks=[])
def save():a.write_text(json.dumps(d,indent=2)+'\n')
save()
try:
 binary=v/'engine89_real_ffn_probe';assert not binary.exists();cmd=['clang','-O3','-fobjc-arc','-I','zig/pkg/inference/src/backends',str(v/'engine89_real_ffn_probe.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(binary)]
 with Path('/private/tmp/ocr-engine89-tiles-build.txt').open('w')as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
 d['build_exit_code']=result.returncode;save();assert result.returncode==0;d['binary_sha256']=sha(binary);save()
 old=json.loads((o/'engine83_real_ffn_probe_retry_audit.json').read_text());d['real_weight_payloads']=old['real_weight_payloads'];save()
 with Path(prep['model_path']).open('rb')as f:
  for w in d['real_weight_payloads']:f.seek(w['offset']);assert hashlib.sha256(f.read(w['bytes'])).hexdigest()==w['sha256']
 for m,n,sg in [(64,64,8),(128,32,8),(128,64,16)]:
  available=psutil.virtual_memory().available
  row=dict(m=m,n=n,simdgroups=sg,available_bytes=available,working_estimate_bytes=prep['working_estimate_bytes'],os_reserve_bytes=prep['os_reserve_bytes']);d['checks'].append(row);save()
  if available<prep['working_estimate_bytes']+prep['os_reserve_bytes']:row['status']='skipped_original_reserve';save();continue
  shader=v/f'engine89_gate_m{m}n{n}s{sg}.metal';row['shader_sha256']=sha(shader)
  so=Path(f'/private/tmp/ocr-engine89-m{m}n{n}s{sg}-stdout.txt');se=Path(f'/private/tmp/ocr-engine89-m{m}n{n}s{sg}-stderr.txt');assert not so.exists()and not se.exists();print('START REAL89',m,n,sg,flush=True)
  with so.open('w')as out,se.open('w')as err:result=subprocess.run([str(binary),str(shader)],stdout=out,stderr=err,env=dict(os.environ,ENGINE89_M=str(m),ENGINE89_N=str(n),ENGINE89_THREADS=str(sg*32),ANTFLY_LIGHTONOCR3_THROUGHPUT='0'),timeout=900)
  records=[json.loads(l)for l in so.read_text().splitlines()if l.startswith('{"rows":')];row.update(exit_code=result.returncode,records=records,stdout_sha256=sha(so),stderr_sha256=sha(se));save();assert result.returncode==0 and len(records)==12
  assert all(x['output_bit_differences']==x['packed_differences']==x['norm_packed_differences']==0 and len(x['gpu_us'])==8 for x in records);row['status']='prototype_pass';save();print('DONE REAL89',m,n,sg,flush=True)
 d['status']='prototype_pass'if all(x['status']=='prototype_pass'for x in d['checks'])else'partial_memory_skips';save()
except BaseException as e:d.update(status='failed',error=repr(e));save();raise
finally:
 save();print('REAL89 DONE',d['status'],flush=True)
