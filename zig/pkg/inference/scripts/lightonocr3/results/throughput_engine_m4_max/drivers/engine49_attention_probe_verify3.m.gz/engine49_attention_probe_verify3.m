
#include "engine49_attention_runtime.m"
static NSString *sources[] = {
@""
 "#define QT 16\n"
 "#define KT 64\n"
 "#include <metal_stdlib>\n"
 "#include <metal_tensor>\n"
 "#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n"
 "using namespace metal;using namespace mpp::tensor_ops;\n"
 "struct LightOnPrefillParams {uint q_len,kv_tokens,num_heads,num_kv_heads,head_dim,key_row_bytes,base_key_row_bytes,query_position_offset,kv_position_offset,sliding_window,v_row_stride,page_size,block_count,contiguous_base_token,contiguous_blocks,format,v_element_bytes,has_sinks;float softcap;uint swa_scan_clamp;};\n"
 "kernel void engine49_v0_q16(\n"
 "    device float *q [[buffer(0)]], device half *k [[buffer(1)]], device half *v [[buffer(2)]],\n"
 "    device const uint *blocks [[buffer(3)]], device const float *sinks [[buffer(4)]],\n"
 "    device float *y [[buffer(5)]], constant LightOnPrefillParams &p [[buffer(6)]],\n"
 "    uint2 group [[threadgroup_position_in_grid]], uint tid [[thread_index_in_threadgroup]],\n"
 "    uint lane [[thread_index_in_simdgroup]], uint sg [[simdgroup_index_in_threadgroup]]) {\n"
 "    const uint q0 = group.x * QT, h = group.y, kh = h / (p.num_heads / p.num_kv_heads),\n"
 "               kw = p.key_row_bytes / 2;\n"
 "    threadgroup float scores[QT * KT], prob[QT * KT], maxima[QT], denom[QT], correction[QT];\n"
 "    threadgroup atomic_uint nonfinite_v;\n"
 "    if (tid < QT) {\n"
 "        maxima[tid] = -INFINITY;\n"
 "        denom[tid] = 0;\n"
 "    }\n"
 "    tensor<device float, dextents<int, 2>, tensor_inline> qa(q + h * 256, dextents<int, 2>(256, p.q_len),\n"
 "                                                             array<int, 2>{1, int(p.num_heads * 256)});\n"
 "    auto Q = qa.slice(0, int(q0));\n"
 "    tensor<threadgroup float, dextents<int, 2>, tensor_inline> S(scores + sg * 16, dextents<int, 2>(16, QT),\n"
 "                                                                 array<int, 2>{1, KT});\n"
 "    tensor<threadgroup float, dextents<int, 2>, tensor_inline> Pbase(prob, dextents<int, 2>(16, QT),\n"
 "                                                                     array<int, 2>{1, KT});\n"
 "    tensor<device half, dextents<int, 2>, tensor_inline> Vbase(\n"
 "        v + kh * 256 + sg * 64, dextents<int, 2>(64, 16), array<int, 2>{1, int(p.v_row_stride)});\n"
 "    constexpr auto qkd = matmul2d_descriptor(QT, 16, 256, false, true, false);\n"
 "    constexpr auto pvd =\n"
 "        matmul2d_descriptor(QT, 64, 16, false, false, false, matmul2d_descriptor::mode::multiply_accumulate);\n"
 "    matmul2d<qkd, execution_simdgroups<1>> qkop;\n"
 "    matmul2d<pvd, execution_simdgroups<1>> pvop;\n"
 "    auto out = pvop.get_destination_cooperative_tensor<decltype(Pbase), decltype(Vbase), float>();\n"
 "    for (ushort i = 0; i < out.get_capacity(); i++)\n"
 "        out[i] = 0;\n"
 "    uint end = min(p.kv_tokens, p.query_position_offset + min(q0 + QT, p.q_len) - p.kv_position_offset);\n"
 "    for (uint start = 0; start < end; start += KT) {\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint key_pass = 0; key_pass < KT / 64; key_pass++) {\n"
 "        uint key = start + sg * 16 + key_pass * 64, count = key < p.kv_tokens ? min(16u, p.kv_tokens - key) : 0;\n"
 "        if (count) {\n"
 "            uint physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "            tensor<device half, dextents<int, 2>, tensor_inline> K(\n"
 "                k + physical * kw + kh * 256, dextents<int, 2>(256, count), array<int, 2>{1, int(kw)});\n"
 "            auto dots = qkop.get_destination_cooperative_tensor<decltype(Q), decltype(K), float>();\n"
 "            qkop.run(Q, K, dots);\n"
 "            tensor<threadgroup float, dextents<int, 2>, tensor_inline> Sstep(scores + sg * 16 + key_pass * 64, dextents<int, 2>(16, QT), array<int, 2>{1, KT});\n"
 "            dots.store(Sstep);\n"
 "        } else\n"
 "            for (uint i = lane; i < QT * 16; i += 32)\n"
 "                scores[(i / 16) * KT + sg * 16 + key_pass * 64 + i % 16] = 0;\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint pass = 0; pass < QT / 4; pass++) {\n"
 "            uint row = sg + pass * 4;\n"
 "            float x[KT / 32], m = -INFINITY;\n"
 "            for (uint j = 0; j < KT / 32; j++) {\n"
 "                uint t = start + lane + j * 32;\n"
 "                bool valid = q0 + row < p.q_len && t < p.kv_tokens &&\n"
 "                             t + p.kv_position_offset <= p.query_position_offset + q0 + row;\n"
 "                x[j] = valid ? scores[row * KT + lane + j * 32] * .0625f : -INFINITY;\n"
 "                if (!isfinite(x[j]))\n"
 "                    x[j] = -INFINITY;\n"
 "                m = max(m, x[j]);\n"
 "            }\n"
 "            m = simd_max(m);\n"
 "            float nm = max(maxima[row], m),\n"
 "                  c = isfinite(maxima[row]) && isfinite(nm) ? exp(maxima[row] - nm) : 0, sum = 0;\n"
 "            for (uint j = 0; j < KT / 32; j++) {\n"
 "                float e = isfinite(x[j]) ? exp(x[j] - nm) : 0;\n"
 "                prob[row * KT + lane + j * 32] = e;\n"
 "                sum += e;\n"
 "            }\n"
 "            sum = simd_sum(sum);\n"
 "            if (lane == 0) {\n"
 "                maxima[row] = nm;\n"
 "                denom[row] = denom[row] * c + sum;\n"
 "                correction[row] = c;\n"
 "            }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "            auto c = out.get_multidimensional_index(i);\n"
 "            float scale = correction[c[1]];\n"
 "            out[i] = scale == 0 ? 0 : out[i] * scale;\n"
 "        }\n"
 "        if (tid == 0)\n"
 "            atomic_store_explicit(&nonfinite_v, 0, memory_order_relaxed);\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint i = tid; i < KT * 256; i += 128) {\n"
 "            uint t = start + i / 256, d = i % 256;\n"
 "            if (t < p.kv_tokens) {\n"
 "                uint physical = blocks[t / p.page_size] + t % p.page_size;\n"
 "                if (!isfinite(v[physical * p.v_row_stride + kh * 256 + d]))\n"
 "                    atomic_store_explicit(&nonfinite_v, 1, memory_order_relaxed);\n"
 "            }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        if (atomic_load_explicit(&nonfinite_v, memory_order_relaxed) == 0) {\n"
 "            for (uint part = 0; part < KT / 16; part++) {\n"
 "                uint key = start + part * 16;\n"
 "                if (key >= p.kv_tokens)\n"
 "                    break;\n"
 "                uint count = min(16u, p.kv_tokens - key),\n"
 "                     physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "                tensor<threadgroup float, dextents<int, 2>, tensor_inline> P(\n"
 "                    prob + part * 16, dextents<int, 2>(count, QT), array<int, 2>{1, KT});\n"
 "                tensor<device half, dextents<int, 2>, tensor_inline> V(\n"
 "                    v + physical * p.v_row_stride + kh * 256 + sg * 64, dextents<int, 2>(64, count),\n"
 "                    array<int, 2>{1, int(p.v_row_stride)});\n"
 "                pvop.run(P, V, out);\n"
 "            }\n"
 "        } else\n"
 "            for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "                auto c = out.get_multidimensional_index(i);\n"
 "                uint row = c[1], d = sg * 64 + c[0];\n"
 "                float sum = 0;\n"
 "                for (uint t = 0; t < KT && start + t < p.kv_tokens; t++) {\n"
 "                    float w = prob[row * KT + t];\n"
 "                    if (w != 0) {\n"
 "                        uint key = start + t, physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "                        sum += w * float(v[physical * p.v_row_stride + kh * 256 + d]);\n"
 "                    }\n"
 "                }\n"
 "                out[i] += sum;\n"
 "            }\n"
 "    }\n"
 "    for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "        auto c = out.get_multidimensional_index(i);\n"
 "        uint row = c[1], d = sg * 64 + c[0];\n"
 "        if (q0 + row >= p.q_len)\n"
 "            continue;\n"
 "        float value = denom[row] > 0 ? out[i] / denom[row] : 0;\n"
 "        if (denom[row] == 0) {\n"
 "            float sum = 0;\n"
 "            for (uint t = 0; t < p.kv_tokens; t++) {\n"
 "                bool allowed = t + p.kv_position_offset <= p.query_position_offset + q0 + row;\n"
 "                uint physical = allowed ? blocks[t / p.page_size] + t % p.page_size : 0;\n"
 "                sum += float(v[physical * p.v_row_stride + kh * 256 + d]);\n"
 "            }\n"
 "            value = sum / float(p.kv_tokens);\n"
 "        }\n"
 "        y[((q0 + row) * p.num_heads + h) * 256 + d] = value;\n"
 "    }\n"
 "}\n"
,
@""
 "#define QT 16\n"
 "#define KT 64\n"
 "#include <metal_stdlib>\n"
 "#include <metal_tensor>\n"
 "#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n"
 "using namespace metal;using namespace mpp::tensor_ops;\n"
 "struct LightOnPrefillParams {uint q_len,kv_tokens,num_heads,num_kv_heads,head_dim,key_row_bytes,base_key_row_bytes,query_position_offset,kv_position_offset,sliding_window,v_row_stride,page_size,block_count,contiguous_base_token,contiguous_blocks,format,v_element_bytes,has_sinks;float softcap;uint swa_scan_clamp;};\n"
 "kernel void engine49_v1_q16(\n"
 "    device float *q [[buffer(0)]], device half *k [[buffer(1)]], device half *v [[buffer(2)]],\n"
 "    device const uint *blocks [[buffer(3)]], device const float *sinks [[buffer(4)]],\n"
 "    device float *y [[buffer(5)]], constant LightOnPrefillParams &p [[buffer(6)]],\n"
 "    uint2 group [[threadgroup_position_in_grid]], uint tid [[thread_index_in_threadgroup]],\n"
 "    uint lane [[thread_index_in_simdgroup]], uint sg [[simdgroup_index_in_threadgroup]]) {\n"
 "    const uint q0 = group.x * QT, h = group.y, kh = h / (p.num_heads / p.num_kv_heads),\n"
 "               kw = p.key_row_bytes / 2;\n"
 "    threadgroup float scores[QT * KT], maxima[QT], denom[QT], correction[QT];\n"
 "    threadgroup float *prob = scores;\n"
 "    threadgroup atomic_uint nonfinite_v;\n"
 "    if (tid < QT) {\n"
 "        maxima[tid] = -INFINITY;\n"
 "        denom[tid] = 0;\n"
 "    }\n"
 "    tensor<device float, dextents<int, 2>, tensor_inline> qa(q + h * 256, dextents<int, 2>(256, p.q_len),\n"
 "                                                             array<int, 2>{1, int(p.num_heads * 256)});\n"
 "    auto Q = qa.slice(0, int(q0));\n"
 "    tensor<threadgroup float, dextents<int, 2>, tensor_inline> S(scores + sg * 16, dextents<int, 2>(16, QT),\n"
 "                                                                 array<int, 2>{1, KT});\n"
 "    tensor<threadgroup float, dextents<int, 2>, tensor_inline> Pbase(prob, dextents<int, 2>(16, QT),\n"
 "                                                                     array<int, 2>{1, KT});\n"
 "    tensor<device half, dextents<int, 2>, tensor_inline> Vbase(\n"
 "        v + kh * 256 + sg * 64, dextents<int, 2>(64, 16), array<int, 2>{1, int(p.v_row_stride)});\n"
 "    constexpr auto qkd = matmul2d_descriptor(QT, 16, 256, false, true, false);\n"
 "    constexpr auto pvd =\n"
 "        matmul2d_descriptor(QT, 64, 16, false, false, false, matmul2d_descriptor::mode::multiply_accumulate);\n"
 "    matmul2d<qkd, execution_simdgroups<1>> qkop;\n"
 "    matmul2d<pvd, execution_simdgroups<1>> pvop;\n"
 "    auto out = pvop.get_destination_cooperative_tensor<decltype(Pbase), decltype(Vbase), float>();\n"
 "    for (ushort i = 0; i < out.get_capacity(); i++)\n"
 "        out[i] = 0;\n"
 "    uint end = min(p.kv_tokens, p.query_position_offset + min(q0 + QT, p.q_len) - p.kv_position_offset);\n"
 "    for (uint start = 0; start < end; start += KT) {\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint key_pass = 0; key_pass < KT / 64; key_pass++) {\n"
 "        uint key = start + sg * 16 + key_pass * 64, count = key < p.kv_tokens ? min(16u, p.kv_tokens - key) : 0;\n"
 "        if (count) {\n"
 "            uint physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "            tensor<device half, dextents<int, 2>, tensor_inline> K(\n"
 "                k + physical * kw + kh * 256, dextents<int, 2>(256, count), array<int, 2>{1, int(kw)});\n"
 "            auto dots = qkop.get_destination_cooperative_tensor<decltype(Q), decltype(K), float>();\n"
 "            qkop.run(Q, K, dots);\n"
 "            tensor<threadgroup float, dextents<int, 2>, tensor_inline> Sstep(scores + sg * 16 + key_pass * 64, dextents<int, 2>(16, QT), array<int, 2>{1, KT});\n"
 "            dots.store(Sstep);\n"
 "        } else\n"
 "            for (uint i = lane; i < QT * 16; i += 32)\n"
 "                scores[(i / 16) * KT + sg * 16 + key_pass * 64 + i % 16] = 0;\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint pass = 0; pass < QT / 4; pass++) {\n"
 "            uint row = sg + pass * 4;\n"
 "            float x[KT / 32], m = -INFINITY;\n"
 "            for (uint j = 0; j < KT / 32; j++) {\n"
 "                uint t = start + lane + j * 32;\n"
 "                bool valid = q0 + row < p.q_len && t < p.kv_tokens &&\n"
 "                             t + p.kv_position_offset <= p.query_position_offset + q0 + row;\n"
 "                x[j] = valid ? scores[row * KT + lane + j * 32] * .0625f : -INFINITY;\n"
 "                if (!isfinite(x[j]))\n"
 "                    x[j] = -INFINITY;\n"
 "                m = max(m, x[j]);\n"
 "            }\n"
 "            m = simd_max(m);\n"
 "            float nm = max(maxima[row], m),\n"
 "                  c = isfinite(maxima[row]) && isfinite(nm) ? exp(maxima[row] - nm) : 0, sum = 0;\n"
 "            for (uint j = 0; j < KT / 32; j++) {\n"
 "                float e = isfinite(x[j]) ? exp(x[j] - nm) : 0;\n"
 "                prob[row * KT + lane + j * 32] = e;\n"
 "                sum += e;\n"
 "            }\n"
 "            sum = simd_sum(sum);\n"
 "            if (lane == 0) {\n"
 "                maxima[row] = nm;\n"
 "                denom[row] = denom[row] * c + sum;\n"
 "                correction[row] = c;\n"
 "            }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "            auto c = out.get_multidimensional_index(i);\n"
 "            float scale = correction[c[1]];\n"
 "            out[i] = scale == 0 ? 0 : out[i] * scale;\n"
 "        }\n"
 "        if (tid == 0)\n"
 "            atomic_store_explicit(&nonfinite_v, 0, memory_order_relaxed);\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint i = tid; i < KT * 256; i += 128) {\n"
 "            uint t = start + i / 256, d = i % 256;\n"
 "            if (t < p.kv_tokens) {\n"
 "                uint physical = blocks[t / p.page_size] + t % p.page_size;\n"
 "                if (!isfinite(v[physical * p.v_row_stride + kh * 256 + d]))\n"
 "                    atomic_store_explicit(&nonfinite_v, 1, memory_order_relaxed);\n"
 "            }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        if (atomic_load_explicit(&nonfinite_v, memory_order_relaxed) == 0) {\n"
 "            for (uint part = 0; part < KT / 16; part++) {\n"
 "                uint key = start + part * 16;\n"
 "                if (key >= p.kv_tokens)\n"
 "                    break;\n"
 "                uint count = min(16u, p.kv_tokens - key),\n"
 "                     physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "                tensor<threadgroup float, dextents<int, 2>, tensor_inline> P(\n"
 "                    prob + part * 16, dextents<int, 2>(count, QT), array<int, 2>{1, KT});\n"
 "                tensor<device half, dextents<int, 2>, tensor_inline> V(\n"
 "                    v + physical * p.v_row_stride + kh * 256 + sg * 64, dextents<int, 2>(64, count),\n"
 "                    array<int, 2>{1, int(p.v_row_stride)});\n"
 "                pvop.run(P, V, out);\n"
 "            }\n"
 "        } else\n"
 "            for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "                auto c = out.get_multidimensional_index(i);\n"
 "                uint row = c[1], d = sg * 64 + c[0];\n"
 "                float sum = 0;\n"
 "                for (uint t = 0; t < KT && start + t < p.kv_tokens; t++) {\n"
 "                    float w = prob[row * KT + t];\n"
 "                    if (w != 0) {\n"
 "                        uint key = start + t, physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "                        sum += w * float(v[physical * p.v_row_stride + kh * 256 + d]);\n"
 "                    }\n"
 "                }\n"
 "                out[i] += sum;\n"
 "            }\n"
 "    }\n"
 "    for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "        auto c = out.get_multidimensional_index(i);\n"
 "        uint row = c[1], d = sg * 64 + c[0];\n"
 "        if (q0 + row >= p.q_len)\n"
 "            continue;\n"
 "        float value = denom[row] > 0 ? out[i] / denom[row] : 0;\n"
 "        if (denom[row] == 0) {\n"
 "            float sum = 0;\n"
 "            for (uint t = 0; t < p.kv_tokens; t++) {\n"
 "                bool allowed = t + p.kv_position_offset <= p.query_position_offset + q0 + row;\n"
 "                uint physical = allowed ? blocks[t / p.page_size] + t % p.page_size : 0;\n"
 "                sum += float(v[physical * p.v_row_stride + kh * 256 + d]);\n"
 "            }\n"
 "            value = sum / float(p.kv_tokens);\n"
 "        }\n"
 "        y[((q0 + row) * p.num_heads + h) * 256 + d] = value;\n"
 "    }\n"
 "}\n"
,
@""
 "#define QT 32\n"
 "#define KT 64\n"
 "#include <metal_stdlib>\n"
 "#include <metal_tensor>\n"
 "#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n"
 "using namespace metal;using namespace mpp::tensor_ops;\n"
 "struct LightOnPrefillParams {uint q_len,kv_tokens,num_heads,num_kv_heads,head_dim,key_row_bytes,base_key_row_bytes,query_position_offset,kv_position_offset,sliding_window,v_row_stride,page_size,block_count,contiguous_base_token,contiguous_blocks,format,v_element_bytes,has_sinks;float softcap;uint swa_scan_clamp;};\n"
 "kernel void engine49_v2_q32(\n"
 "    device float *q [[buffer(0)]], device half *k [[buffer(1)]], device half *v [[buffer(2)]],\n"
 "    device const uint *blocks [[buffer(3)]], device const float *sinks [[buffer(4)]],\n"
 "    device float *y [[buffer(5)]], constant LightOnPrefillParams &p [[buffer(6)]],\n"
 "    uint2 group [[threadgroup_position_in_grid]], uint tid [[thread_index_in_threadgroup]],\n"
 "    uint lane [[thread_index_in_simdgroup]], uint sg [[simdgroup_index_in_threadgroup]]) {\n"
 "    const uint q0 = group.x * QT, h = group.y, kh = h / (p.num_heads / p.num_kv_heads),\n"
 "               kw = p.key_row_bytes / 2;\n"
 "    threadgroup float scores[QT * KT], maxima[QT], denom[QT], correction[QT];\n"
 "    threadgroup float *prob = scores;\n"
 "    threadgroup atomic_uint nonfinite_v;\n"
 "    if (tid < QT) {\n"
 "        maxima[tid] = -INFINITY;\n"
 "        denom[tid] = 0;\n"
 "    }\n"
 "    tensor<device float, dextents<int, 2>, tensor_inline> qa(q + h * 256, dextents<int, 2>(256, p.q_len),\n"
 "                                                             array<int, 2>{1, int(p.num_heads * 256)});\n"
 "    auto Q = qa.slice(0, int(q0));\n"
 "    tensor<threadgroup float, dextents<int, 2>, tensor_inline> S(scores + sg * 16, dextents<int, 2>(16, QT),\n"
 "                                                                 array<int, 2>{1, KT});\n"
 "    tensor<threadgroup float, dextents<int, 2>, tensor_inline> Pbase(prob, dextents<int, 2>(16, QT),\n"
 "                                                                     array<int, 2>{1, KT});\n"
 "    tensor<device half, dextents<int, 2>, tensor_inline> Vbase(\n"
 "        v + kh * 256 + sg * 64, dextents<int, 2>(64, 16), array<int, 2>{1, int(p.v_row_stride)});\n"
 "    constexpr auto qkd = matmul2d_descriptor(QT, 16, 256, false, true, false);\n"
 "    constexpr auto pvd =\n"
 "        matmul2d_descriptor(QT, 64, 16, false, false, false, matmul2d_descriptor::mode::multiply_accumulate);\n"
 "    matmul2d<qkd, execution_simdgroups<1>> qkop;\n"
 "    matmul2d<pvd, execution_simdgroups<1>> pvop;\n"
 "    auto out = pvop.get_destination_cooperative_tensor<decltype(Pbase), decltype(Vbase), float>();\n"
 "    for (ushort i = 0; i < out.get_capacity(); i++)\n"
 "        out[i] = 0;\n"
 "    uint end = min(p.kv_tokens, p.query_position_offset + min(q0 + QT, p.q_len) - p.kv_position_offset);\n"
 "    for (uint start = 0; start < end; start += KT) {\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint key_pass = 0; key_pass < KT / 64; key_pass++) {\n"
 "        uint key = start + sg * 16 + key_pass * 64, count = key < p.kv_tokens ? min(16u, p.kv_tokens - key) : 0;\n"
 "        if (count) {\n"
 "            uint physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "            tensor<device half, dextents<int, 2>, tensor_inline> K(\n"
 "                k + physical * kw + kh * 256, dextents<int, 2>(256, count), array<int, 2>{1, int(kw)});\n"
 "            auto dots = qkop.get_destination_cooperative_tensor<decltype(Q), decltype(K), float>();\n"
 "            qkop.run(Q, K, dots);\n"
 "            tensor<threadgroup float, dextents<int, 2>, tensor_inline> Sstep(scores + sg * 16 + key_pass * 64, dextents<int, 2>(16, QT), array<int, 2>{1, KT});\n"
 "            dots.store(Sstep);\n"
 "        } else\n"
 "            for (uint i = lane; i < QT * 16; i += 32)\n"
 "                scores[(i / 16) * KT + sg * 16 + key_pass * 64 + i % 16] = 0;\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint pass = 0; pass < QT / 4; pass++) {\n"
 "            uint row = sg + pass * 4;\n"
 "            float x[KT / 32], m = -INFINITY;\n"
 "            for (uint j = 0; j < KT / 32; j++) {\n"
 "                uint t = start + lane + j * 32;\n"
 "                bool valid = q0 + row < p.q_len && t < p.kv_tokens &&\n"
 "                             t + p.kv_position_offset <= p.query_position_offset + q0 + row;\n"
 "                x[j] = valid ? scores[row * KT + lane + j * 32] * .0625f : -INFINITY;\n"
 "                if (!isfinite(x[j]))\n"
 "                    x[j] = -INFINITY;\n"
 "                m = max(m, x[j]);\n"
 "            }\n"
 "            m = simd_max(m);\n"
 "            float nm = max(maxima[row], m),\n"
 "                  c = isfinite(maxima[row]) && isfinite(nm) ? exp(maxima[row] - nm) : 0, sum = 0;\n"
 "            for (uint j = 0; j < KT / 32; j++) {\n"
 "                float e = isfinite(x[j]) ? exp(x[j] - nm) : 0;\n"
 "                prob[row * KT + lane + j * 32] = e;\n"
 "                sum += e;\n"
 "            }\n"
 "            sum = simd_sum(sum);\n"
 "            if (lane == 0) {\n"
 "                maxima[row] = nm;\n"
 "                denom[row] = denom[row] * c + sum;\n"
 "                correction[row] = c;\n"
 "            }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "            auto c = out.get_multidimensional_index(i);\n"
 "            float scale = correction[c[1]];\n"
 "            out[i] = scale == 0 ? 0 : out[i] * scale;\n"
 "        }\n"
 "        if (tid == 0)\n"
 "            atomic_store_explicit(&nonfinite_v, 0, memory_order_relaxed);\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint i = tid; i < KT * 256; i += 128) {\n"
 "            uint t = start + i / 256, d = i % 256;\n"
 "            if (t < p.kv_tokens) {\n"
 "                uint physical = blocks[t / p.page_size] + t % p.page_size;\n"
 "                if (!isfinite(v[physical * p.v_row_stride + kh * 256 + d]))\n"
 "                    atomic_store_explicit(&nonfinite_v, 1, memory_order_relaxed);\n"
 "            }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        if (atomic_load_explicit(&nonfinite_v, memory_order_relaxed) == 0) {\n"
 "            for (uint part = 0; part < KT / 16; part++) {\n"
 "                uint key = start + part * 16;\n"
 "                if (key >= p.kv_tokens)\n"
 "                    break;\n"
 "                uint count = min(16u, p.kv_tokens - key),\n"
 "                     physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "                tensor<threadgroup float, dextents<int, 2>, tensor_inline> P(\n"
 "                    prob + part * 16, dextents<int, 2>(count, QT), array<int, 2>{1, KT});\n"
 "                tensor<device half, dextents<int, 2>, tensor_inline> V(\n"
 "                    v + physical * p.v_row_stride + kh * 256 + sg * 64, dextents<int, 2>(64, count),\n"
 "                    array<int, 2>{1, int(p.v_row_stride)});\n"
 "                pvop.run(P, V, out);\n"
 "            }\n"
 "        } else\n"
 "            for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "                auto c = out.get_multidimensional_index(i);\n"
 "                uint row = c[1], d = sg * 64 + c[0];\n"
 "                float sum = 0;\n"
 "                for (uint t = 0; t < KT && start + t < p.kv_tokens; t++) {\n"
 "                    float w = prob[row * KT + t];\n"
 "                    if (w != 0) {\n"
 "                        uint key = start + t, physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "                        sum += w * float(v[physical * p.v_row_stride + kh * 256 + d]);\n"
 "                    }\n"
 "                }\n"
 "                out[i] += sum;\n"
 "            }\n"
 "    }\n"
 "    for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "        auto c = out.get_multidimensional_index(i);\n"
 "        uint row = c[1], d = sg * 64 + c[0];\n"
 "        if (q0 + row >= p.q_len)\n"
 "            continue;\n"
 "        float value = denom[row] > 0 ? out[i] / denom[row] : 0;\n"
 "        if (denom[row] == 0) {\n"
 "            float sum = 0;\n"
 "            for (uint t = 0; t < p.kv_tokens; t++) {\n"
 "                bool allowed = t + p.kv_position_offset <= p.query_position_offset + q0 + row;\n"
 "                uint physical = allowed ? blocks[t / p.page_size] + t % p.page_size : 0;\n"
 "                sum += float(v[physical * p.v_row_stride + kh * 256 + d]);\n"
 "            }\n"
 "            value = sum / float(p.kv_tokens);\n"
 "        }\n"
 "        y[((q0 + row) * p.num_heads + h) * 256 + d] = value;\n"
 "    }\n"
 "}\n"
,
@""
 "#define QT 16\n"
 "#define KT 128\n"
 "#include <metal_stdlib>\n"
 "#include <metal_tensor>\n"
 "#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n"
 "using namespace metal;using namespace mpp::tensor_ops;\n"
 "struct LightOnPrefillParams {uint q_len,kv_tokens,num_heads,num_kv_heads,head_dim,key_row_bytes,base_key_row_bytes,query_position_offset,kv_position_offset,sliding_window,v_row_stride,page_size,block_count,contiguous_base_token,contiguous_blocks,format,v_element_bytes,has_sinks;float softcap;uint swa_scan_clamp;};\n"
 "kernel void engine49_v3_q16(\n"
 "    device float *q [[buffer(0)]], device half *k [[buffer(1)]], device half *v [[buffer(2)]],\n"
 "    device const uint *blocks [[buffer(3)]], device const float *sinks [[buffer(4)]],\n"
 "    device float *y [[buffer(5)]], constant LightOnPrefillParams &p [[buffer(6)]],\n"
 "    uint2 group [[threadgroup_position_in_grid]], uint tid [[thread_index_in_threadgroup]],\n"
 "    uint lane [[thread_index_in_simdgroup]], uint sg [[simdgroup_index_in_threadgroup]]) {\n"
 "    const uint q0 = group.x * QT, h = group.y, kh = h / (p.num_heads / p.num_kv_heads),\n"
 "               kw = p.key_row_bytes / 2;\n"
 "    threadgroup float scores[QT * KT], maxima[QT], denom[QT], correction[QT];\n"
 "    threadgroup float *prob = scores;\n"
 "    threadgroup atomic_uint nonfinite_v;\n"
 "    if (tid < QT) {\n"
 "        maxima[tid] = -INFINITY;\n"
 "        denom[tid] = 0;\n"
 "    }\n"
 "    tensor<device float, dextents<int, 2>, tensor_inline> qa(q + h * 256, dextents<int, 2>(256, p.q_len),\n"
 "                                                             array<int, 2>{1, int(p.num_heads * 256)});\n"
 "    auto Q = qa.slice(0, int(q0));\n"
 "    tensor<threadgroup float, dextents<int, 2>, tensor_inline> S(scores + sg * 16, dextents<int, 2>(16, QT),\n"
 "                                                                 array<int, 2>{1, KT});\n"
 "    tensor<threadgroup float, dextents<int, 2>, tensor_inline> Pbase(prob, dextents<int, 2>(16, QT),\n"
 "                                                                     array<int, 2>{1, KT});\n"
 "    tensor<device half, dextents<int, 2>, tensor_inline> Vbase(\n"
 "        v + kh * 256 + sg * 64, dextents<int, 2>(64, 16), array<int, 2>{1, int(p.v_row_stride)});\n"
 "    constexpr auto qkd = matmul2d_descriptor(QT, 16, 256, false, true, false);\n"
 "    constexpr auto pvd =\n"
 "        matmul2d_descriptor(QT, 64, 16, false, false, false, matmul2d_descriptor::mode::multiply_accumulate);\n"
 "    matmul2d<qkd, execution_simdgroups<1>> qkop;\n"
 "    matmul2d<pvd, execution_simdgroups<1>> pvop;\n"
 "    auto out = pvop.get_destination_cooperative_tensor<decltype(Pbase), decltype(Vbase), float>();\n"
 "    for (ushort i = 0; i < out.get_capacity(); i++)\n"
 "        out[i] = 0;\n"
 "    uint end = min(p.kv_tokens, p.query_position_offset + min(q0 + QT, p.q_len) - p.kv_position_offset);\n"
 "    for (uint start = 0; start < end; start += KT) {\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint key_pass = 0; key_pass < KT / 64; key_pass++) {\n"
 "        uint key = start + sg * 16 + key_pass * 64, count = key < p.kv_tokens ? min(16u, p.kv_tokens - key) : 0;\n"
 "        if (count) {\n"
 "            uint physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "            tensor<device half, dextents<int, 2>, tensor_inline> K(\n"
 "                k + physical * kw + kh * 256, dextents<int, 2>(256, count), array<int, 2>{1, int(kw)});\n"
 "            auto dots = qkop.get_destination_cooperative_tensor<decltype(Q), decltype(K), float>();\n"
 "            qkop.run(Q, K, dots);\n"
 "            tensor<threadgroup float, dextents<int, 2>, tensor_inline> Sstep(scores + sg * 16 + key_pass * 64, dextents<int, 2>(16, QT), array<int, 2>{1, KT});\n"
 "            dots.store(Sstep);\n"
 "        } else\n"
 "            for (uint i = lane; i < QT * 16; i += 32)\n"
 "                scores[(i / 16) * KT + sg * 16 + key_pass * 64 + i % 16] = 0;\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint pass = 0; pass < QT / 4; pass++) {\n"
 "            uint row = sg + pass * 4;\n"
 "            float x[KT / 32], m = -INFINITY;\n"
 "            for (uint j = 0; j < KT / 32; j++) {\n"
 "                uint t = start + lane + j * 32;\n"
 "                bool valid = q0 + row < p.q_len && t < p.kv_tokens &&\n"
 "                             t + p.kv_position_offset <= p.query_position_offset + q0 + row;\n"
 "                x[j] = valid ? scores[row * KT + lane + j * 32] * .0625f : -INFINITY;\n"
 "                if (!isfinite(x[j]))\n"
 "                    x[j] = -INFINITY;\n"
 "                m = max(m, x[j]);\n"
 "            }\n"
 "            m = simd_max(m);\n"
 "            float nm = max(maxima[row], m),\n"
 "                  c = isfinite(maxima[row]) && isfinite(nm) ? exp(maxima[row] - nm) : 0, sum = 0;\n"
 "            for (uint j = 0; j < KT / 32; j++) {\n"
 "                float e = isfinite(x[j]) ? exp(x[j] - nm) : 0;\n"
 "                prob[row * KT + lane + j * 32] = e;\n"
 "                sum += e;\n"
 "            }\n"
 "            sum = simd_sum(sum);\n"
 "            if (lane == 0) {\n"
 "                maxima[row] = nm;\n"
 "                denom[row] = denom[row] * c + sum;\n"
 "                correction[row] = c;\n"
 "            }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "            auto c = out.get_multidimensional_index(i);\n"
 "            float scale = correction[c[1]];\n"
 "            out[i] = scale == 0 ? 0 : out[i] * scale;\n"
 "        }\n"
 "        if (tid == 0)\n"
 "            atomic_store_explicit(&nonfinite_v, 0, memory_order_relaxed);\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint i = tid; i < KT * 256; i += 128) {\n"
 "            uint t = start + i / 256, d = i % 256;\n"
 "            if (t < p.kv_tokens) {\n"
 "                uint physical = blocks[t / p.page_size] + t % p.page_size;\n"
 "                if (!isfinite(v[physical * p.v_row_stride + kh * 256 + d]))\n"
 "                    atomic_store_explicit(&nonfinite_v, 1, memory_order_relaxed);\n"
 "            }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        if (atomic_load_explicit(&nonfinite_v, memory_order_relaxed) == 0) {\n"
 "            for (uint part = 0; part < KT / 16; part++) {\n"
 "                uint key = start + part * 16;\n"
 "                if (key >= p.kv_tokens)\n"
 "                    break;\n"
 "                uint count = min(16u, p.kv_tokens - key),\n"
 "                     physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "                tensor<threadgroup float, dextents<int, 2>, tensor_inline> P(\n"
 "                    prob + part * 16, dextents<int, 2>(count, QT), array<int, 2>{1, KT});\n"
 "                tensor<device half, dextents<int, 2>, tensor_inline> V(\n"
 "                    v + physical * p.v_row_stride + kh * 256 + sg * 64, dextents<int, 2>(64, count),\n"
 "                    array<int, 2>{1, int(p.v_row_stride)});\n"
 "                pvop.run(P, V, out);\n"
 "            }\n"
 "        } else\n"
 "            for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "                auto c = out.get_multidimensional_index(i);\n"
 "                uint row = c[1], d = sg * 64 + c[0];\n"
 "                float sum = 0;\n"
 "                for (uint t = 0; t < KT && start + t < p.kv_tokens; t++) {\n"
 "                    float w = prob[row * KT + t];\n"
 "                    if (w != 0) {\n"
 "                        uint key = start + t, physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "                        sum += w * float(v[physical * p.v_row_stride + kh * 256 + d]);\n"
 "                    }\n"
 "                }\n"
 "                out[i] += sum;\n"
 "            }\n"
 "    }\n"
 "    for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "        auto c = out.get_multidimensional_index(i);\n"
 "        uint row = c[1], d = sg * 64 + c[0];\n"
 "        if (q0 + row >= p.q_len)\n"
 "            continue;\n"
 "        float value = denom[row] > 0 ? out[i] / denom[row] : 0;\n"
 "        if (denom[row] == 0) {\n"
 "            float sum = 0;\n"
 "            for (uint t = 0; t < p.kv_tokens; t++) {\n"
 "                bool allowed = t + p.kv_position_offset <= p.query_position_offset + q0 + row;\n"
 "                uint physical = allowed ? blocks[t / p.page_size] + t % p.page_size : 0;\n"
 "                sum += float(v[physical * p.v_row_stride + kh * 256 + d]);\n"
 "            }\n"
 "            value = sum / float(p.kv_tokens);\n"
 "        }\n"
 "        y[((q0 + row) * p.num_heads + h) * 256 + d] = value;\n"
 "    }\n"
 "}\n"
,
@""
 "#define QT 32\n"
 "#define KT 128\n"
 "#include <metal_stdlib>\n"
 "#include <metal_tensor>\n"
 "#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n"
 "using namespace metal;using namespace mpp::tensor_ops;\n"
 "struct LightOnPrefillParams {uint q_len,kv_tokens,num_heads,num_kv_heads,head_dim,key_row_bytes,base_key_row_bytes,query_position_offset,kv_position_offset,sliding_window,v_row_stride,page_size,block_count,contiguous_base_token,contiguous_blocks,format,v_element_bytes,has_sinks;float softcap;uint swa_scan_clamp;};\n"
 "kernel void engine49_v4_q32(\n"
 "    device float *q [[buffer(0)]], device half *k [[buffer(1)]], device half *v [[buffer(2)]],\n"
 "    device const uint *blocks [[buffer(3)]], device const float *sinks [[buffer(4)]],\n"
 "    device float *y [[buffer(5)]], constant LightOnPrefillParams &p [[buffer(6)]],\n"
 "    uint2 group [[threadgroup_position_in_grid]], uint tid [[thread_index_in_threadgroup]],\n"
 "    uint lane [[thread_index_in_simdgroup]], uint sg [[simdgroup_index_in_threadgroup]]) {\n"
 "    const uint q0 = group.x * QT, h = group.y, kh = h / (p.num_heads / p.num_kv_heads),\n"
 "               kw = p.key_row_bytes / 2;\n"
 "    threadgroup float scores[QT * KT], maxima[QT], denom[QT], correction[QT];\n"
 "    threadgroup float *prob = scores;\n"
 "    threadgroup atomic_uint nonfinite_v;\n"
 "    if (tid < QT) {\n"
 "        maxima[tid] = -INFINITY;\n"
 "        denom[tid] = 0;\n"
 "    }\n"
 "    tensor<device float, dextents<int, 2>, tensor_inline> qa(q + h * 256, dextents<int, 2>(256, p.q_len),\n"
 "                                                             array<int, 2>{1, int(p.num_heads * 256)});\n"
 "    auto Q = qa.slice(0, int(q0));\n"
 "    tensor<threadgroup float, dextents<int, 2>, tensor_inline> S(scores + sg * 16, dextents<int, 2>(16, QT),\n"
 "                                                                 array<int, 2>{1, KT});\n"
 "    tensor<threadgroup float, dextents<int, 2>, tensor_inline> Pbase(prob, dextents<int, 2>(16, QT),\n"
 "                                                                     array<int, 2>{1, KT});\n"
 "    tensor<device half, dextents<int, 2>, tensor_inline> Vbase(\n"
 "        v + kh * 256 + sg * 64, dextents<int, 2>(64, 16), array<int, 2>{1, int(p.v_row_stride)});\n"
 "    constexpr auto qkd = matmul2d_descriptor(QT, 16, 256, false, true, false);\n"
 "    constexpr auto pvd =\n"
 "        matmul2d_descriptor(QT, 64, 16, false, false, false, matmul2d_descriptor::mode::multiply_accumulate);\n"
 "    matmul2d<qkd, execution_simdgroups<1>> qkop;\n"
 "    matmul2d<pvd, execution_simdgroups<1>> pvop;\n"
 "    auto out = pvop.get_destination_cooperative_tensor<decltype(Pbase), decltype(Vbase), float>();\n"
 "    for (ushort i = 0; i < out.get_capacity(); i++)\n"
 "        out[i] = 0;\n"
 "    uint end = min(p.kv_tokens, p.query_position_offset + min(q0 + QT, p.q_len) - p.kv_position_offset);\n"
 "    for (uint start = 0; start < end; start += KT) {\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint key_pass = 0; key_pass < KT / 64; key_pass++) {\n"
 "        uint key = start + sg * 16 + key_pass * 64, count = key < p.kv_tokens ? min(16u, p.kv_tokens - key) : 0;\n"
 "        if (count) {\n"
 "            uint physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "            tensor<device half, dextents<int, 2>, tensor_inline> K(\n"
 "                k + physical * kw + kh * 256, dextents<int, 2>(256, count), array<int, 2>{1, int(kw)});\n"
 "            auto dots = qkop.get_destination_cooperative_tensor<decltype(Q), decltype(K), float>();\n"
 "            qkop.run(Q, K, dots);\n"
 "            tensor<threadgroup float, dextents<int, 2>, tensor_inline> Sstep(scores + sg * 16 + key_pass * 64, dextents<int, 2>(16, QT), array<int, 2>{1, KT});\n"
 "            dots.store(Sstep);\n"
 "        } else\n"
 "            for (uint i = lane; i < QT * 16; i += 32)\n"
 "                scores[(i / 16) * KT + sg * 16 + key_pass * 64 + i % 16] = 0;\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint pass = 0; pass < QT / 4; pass++) {\n"
 "            uint row = sg + pass * 4;\n"
 "            float x[KT / 32], m = -INFINITY;\n"
 "            for (uint j = 0; j < KT / 32; j++) {\n"
 "                uint t = start + lane + j * 32;\n"
 "                bool valid = q0 + row < p.q_len && t < p.kv_tokens &&\n"
 "                             t + p.kv_position_offset <= p.query_position_offset + q0 + row;\n"
 "                x[j] = valid ? scores[row * KT + lane + j * 32] * .0625f : -INFINITY;\n"
 "                if (!isfinite(x[j]))\n"
 "                    x[j] = -INFINITY;\n"
 "                m = max(m, x[j]);\n"
 "            }\n"
 "            m = simd_max(m);\n"
 "            float nm = max(maxima[row], m),\n"
 "                  c = isfinite(maxima[row]) && isfinite(nm) ? exp(maxima[row] - nm) : 0, sum = 0;\n"
 "            for (uint j = 0; j < KT / 32; j++) {\n"
 "                float e = isfinite(x[j]) ? exp(x[j] - nm) : 0;\n"
 "                prob[row * KT + lane + j * 32] = e;\n"
 "                sum += e;\n"
 "            }\n"
 "            sum = simd_sum(sum);\n"
 "            if (lane == 0) {\n"
 "                maxima[row] = nm;\n"
 "                denom[row] = denom[row] * c + sum;\n"
 "                correction[row] = c;\n"
 "            }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "            auto c = out.get_multidimensional_index(i);\n"
 "            float scale = correction[c[1]];\n"
 "            out[i] = scale == 0 ? 0 : out[i] * scale;\n"
 "        }\n"
 "        if (tid == 0)\n"
 "            atomic_store_explicit(&nonfinite_v, 0, memory_order_relaxed);\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint i = tid; i < KT * 256; i += 128) {\n"
 "            uint t = start + i / 256, d = i % 256;\n"
 "            if (t < p.kv_tokens) {\n"
 "                uint physical = blocks[t / p.page_size] + t % p.page_size;\n"
 "                if (!isfinite(v[physical * p.v_row_stride + kh * 256 + d]))\n"
 "                    atomic_store_explicit(&nonfinite_v, 1, memory_order_relaxed);\n"
 "            }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        if (atomic_load_explicit(&nonfinite_v, memory_order_relaxed) == 0) {\n"
 "            for (uint part = 0; part < KT / 16; part++) {\n"
 "                uint key = start + part * 16;\n"
 "                if (key >= p.kv_tokens)\n"
 "                    break;\n"
 "                uint count = min(16u, p.kv_tokens - key),\n"
 "                     physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "                tensor<threadgroup float, dextents<int, 2>, tensor_inline> P(\n"
 "                    prob + part * 16, dextents<int, 2>(count, QT), array<int, 2>{1, KT});\n"
 "                tensor<device half, dextents<int, 2>, tensor_inline> V(\n"
 "                    v + physical * p.v_row_stride + kh * 256 + sg * 64, dextents<int, 2>(64, count),\n"
 "                    array<int, 2>{1, int(p.v_row_stride)});\n"
 "                pvop.run(P, V, out);\n"
 "            }\n"
 "        } else\n"
 "            for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "                auto c = out.get_multidimensional_index(i);\n"
 "                uint row = c[1], d = sg * 64 + c[0];\n"
 "                float sum = 0;\n"
 "                for (uint t = 0; t < KT && start + t < p.kv_tokens; t++) {\n"
 "                    float w = prob[row * KT + t];\n"
 "                    if (w != 0) {\n"
 "                        uint key = start + t, physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "                        sum += w * float(v[physical * p.v_row_stride + kh * 256 + d]);\n"
 "                    }\n"
 "                }\n"
 "                out[i] += sum;\n"
 "            }\n"
 "    }\n"
 "    for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "        auto c = out.get_multidimensional_index(i);\n"
 "        uint row = c[1], d = sg * 64 + c[0];\n"
 "        if (q0 + row >= p.q_len)\n"
 "            continue;\n"
 "        float value = denom[row] > 0 ? out[i] / denom[row] : 0;\n"
 "        if (denom[row] == 0) {\n"
 "            float sum = 0;\n"
 "            for (uint t = 0; t < p.kv_tokens; t++) {\n"
 "                bool allowed = t + p.kv_position_offset <= p.query_position_offset + q0 + row;\n"
 "                uint physical = allowed ? blocks[t / p.page_size] + t % p.page_size : 0;\n"
 "                sum += float(v[physical * p.v_row_stride + kh * 256 + d]);\n"
 "            }\n"
 "            value = sum / float(p.kv_tokens);\n"
 "        }\n"
 "        y[((q0 + row) * p.num_heads + h) * 256 + d] = value;\n"
 "    }\n"
 "}\n",
@""
 "#define QT 16\n"
 "#define KT 64\n"
 "#include <metal_stdlib>\n"
 "#include <metal_tensor>\n"
 "#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n"
 "using namespace metal;using namespace mpp::tensor_ops;\n"
 "struct LightOnPrefillParams {uint q_len,kv_tokens,num_heads,num_kv_heads,head_dim,key_row_bytes,base_key_row_bytes,query_position_offset,kv_position_offset,sliding_window,v_row_stride,page_size,block_count,contiguous_base_token,contiguous_blocks,format,v_element_bytes,has_sinks;float softcap;uint swa_scan_clamp;};\n"
 "kernel void engine49_v5_q16(\n"
 "    device float *q [[buffer(0)]], device half *k [[buffer(1)]], device half *v [[buffer(2)]],\n"
 "    device const uint *blocks [[buffer(3)]], device const float *sinks [[buffer(4)]],\n"
 "    device float *y [[buffer(5)]], constant LightOnPrefillParams &p [[buffer(6)]],\n"
 "    uint2 group [[threadgroup_position_in_grid]], uint tid [[thread_index_in_threadgroup]],\n"
 "    uint lane [[thread_index_in_simdgroup]], uint sg [[simdgroup_index_in_threadgroup]]) {\n"
 "    const uint q0 = group.x * QT, h = group.y, kh = h / (p.num_heads / p.num_kv_heads),\n"
 "               kw = p.key_row_bytes / 2;\n"
 "    threadgroup float scores[QT * KT], maxima[QT], denom[QT], correction[QT];\n"
 "    threadgroup float *prob = scores;\n"
 "    threadgroup atomic_uint nonfinite_v;\n"
 "    if (tid < QT) {\n"
 "        maxima[tid] = -INFINITY;\n"
 "        denom[tid] = 0;\n"
 "    }\n"
 "    threadgroup float cached_q[QT * 256];\n"
 "    for (uint i = tid; i < QT * 256; i += 128) {\n"
 "        uint row = i / 256, d = i % 256;\n"
 "        cached_q[i] = q0 + row < p.q_len ? q[((q0 + row) * p.num_heads + h) * 256 + d] : 0;\n"
 "    }\n"
 "    threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    tensor<threadgroup float, dextents<int, 2>, tensor_inline> Q(cached_q, dextents<int, 2>(256, QT), array<int, 2>{1,256});\n"
 "    tensor<threadgroup float, dextents<int, 2>, tensor_inline> S(scores + sg * 16, dextents<int, 2>(16, QT),\n"
 "                                                                 array<int, 2>{1, KT});\n"
 "    tensor<threadgroup float, dextents<int, 2>, tensor_inline> Pbase(prob, dextents<int, 2>(16, QT),\n"
 "                                                                     array<int, 2>{1, KT});\n"
 "    tensor<device half, dextents<int, 2>, tensor_inline> Vbase(\n"
 "        v + kh * 256 + sg * 64, dextents<int, 2>(64, 16), array<int, 2>{1, int(p.v_row_stride)});\n"
 "    constexpr auto qkd = matmul2d_descriptor(QT, 16, 256, false, true, false);\n"
 "    constexpr auto pvd =\n"
 "        matmul2d_descriptor(QT, 64, 16, false, false, false, matmul2d_descriptor::mode::multiply_accumulate);\n"
 "    matmul2d<qkd, execution_simdgroups<1>> qkop;\n"
 "    matmul2d<pvd, execution_simdgroups<1>> pvop;\n"
 "    auto out = pvop.get_destination_cooperative_tensor<decltype(Pbase), decltype(Vbase), float>();\n"
 "    for (ushort i = 0; i < out.get_capacity(); i++)\n"
 "        out[i] = 0;\n"
 "    uint end = min(p.kv_tokens, p.query_position_offset + min(q0 + QT, p.q_len) - p.kv_position_offset);\n"
 "    for (uint start = 0; start < end; start += KT) {\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint key_pass = 0; key_pass < KT / 64; key_pass++) {\n"
 "        uint key = start + sg * 16 + key_pass * 64, count = key < p.kv_tokens ? min(16u, p.kv_tokens - key) : 0;\n"
 "        if (count) {\n"
 "            uint physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "            tensor<device half, dextents<int, 2>, tensor_inline> K(\n"
 "                k + physical * kw + kh * 256, dextents<int, 2>(256, count), array<int, 2>{1, int(kw)});\n"
 "            auto dots = qkop.get_destination_cooperative_tensor<decltype(Q), decltype(K), float>();\n"
 "            qkop.run(Q, K, dots);\n"
 "            tensor<threadgroup float, dextents<int, 2>, tensor_inline> Sstep(scores + sg * 16 + key_pass * 64, dextents<int, 2>(16, QT), array<int, 2>{1, KT});\n"
 "            dots.store(Sstep);\n"
 "        } else\n"
 "            for (uint i = lane; i < QT * 16; i += 32)\n"
 "                scores[(i / 16) * KT + sg * 16 + key_pass * 64 + i % 16] = 0;\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint pass = 0; pass < QT / 4; pass++) {\n"
 "            uint row = sg + pass * 4;\n"
 "            float x[KT / 32], m = -INFINITY;\n"
 "            for (uint j = 0; j < KT / 32; j++) {\n"
 "                uint t = start + lane + j * 32;\n"
 "                bool valid = q0 + row < p.q_len && t < p.kv_tokens &&\n"
 "                             t + p.kv_position_offset <= p.query_position_offset + q0 + row;\n"
 "                x[j] = valid ? scores[row * KT + lane + j * 32] * .0625f : -INFINITY;\n"
 "                if (!isfinite(x[j]))\n"
 "                    x[j] = -INFINITY;\n"
 "                m = max(m, x[j]);\n"
 "            }\n"
 "            m = simd_max(m);\n"
 "            float nm = max(maxima[row], m),\n"
 "                  c = isfinite(maxima[row]) && isfinite(nm) ? exp(maxima[row] - nm) : 0, sum = 0;\n"
 "            for (uint j = 0; j < KT / 32; j++) {\n"
 "                float e = isfinite(x[j]) ? exp(x[j] - nm) : 0;\n"
 "                prob[row * KT + lane + j * 32] = e;\n"
 "                sum += e;\n"
 "            }\n"
 "            sum = simd_sum(sum);\n"
 "            if (lane == 0) {\n"
 "                maxima[row] = nm;\n"
 "                denom[row] = denom[row] * c + sum;\n"
 "                correction[row] = c;\n"
 "            }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "            auto c = out.get_multidimensional_index(i);\n"
 "            float scale = correction[c[1]];\n"
 "            out[i] = scale == 0 ? 0 : out[i] * scale;\n"
 "        }\n"
 "        if (tid == 0)\n"
 "            atomic_store_explicit(&nonfinite_v, 0, memory_order_relaxed);\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint i = tid; i < KT * 256; i += 128) {\n"
 "            uint t = start + i / 256, d = i % 256;\n"
 "            if (t < p.kv_tokens) {\n"
 "                uint physical = blocks[t / p.page_size] + t % p.page_size;\n"
 "                if (!isfinite(v[physical * p.v_row_stride + kh * 256 + d]))\n"
 "                    atomic_store_explicit(&nonfinite_v, 1, memory_order_relaxed);\n"
 "            }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        if (atomic_load_explicit(&nonfinite_v, memory_order_relaxed) == 0) {\n"
 "            for (uint part = 0; part < KT / 16; part++) {\n"
 "                uint key = start + part * 16;\n"
 "                if (key >= p.kv_tokens)\n"
 "                    break;\n"
 "                uint count = min(16u, p.kv_tokens - key),\n"
 "                     physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "                tensor<threadgroup float, dextents<int, 2>, tensor_inline> P(\n"
 "                    prob + part * 16, dextents<int, 2>(count, QT), array<int, 2>{1, KT});\n"
 "                tensor<device half, dextents<int, 2>, tensor_inline> V(\n"
 "                    v + physical * p.v_row_stride + kh * 256 + sg * 64, dextents<int, 2>(64, count),\n"
 "                    array<int, 2>{1, int(p.v_row_stride)});\n"
 "                pvop.run(P, V, out);\n"
 "            }\n"
 "        } else\n"
 "            for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "                auto c = out.get_multidimensional_index(i);\n"
 "                uint row = c[1], d = sg * 64 + c[0];\n"
 "                float sum = 0;\n"
 "                for (uint t = 0; t < KT && start + t < p.kv_tokens; t++) {\n"
 "                    float w = prob[row * KT + t];\n"
 "                    if (w != 0) {\n"
 "                        uint key = start + t, physical = blocks[key / p.page_size] + key % p.page_size;\n"
 "                        sum += w * float(v[physical * p.v_row_stride + kh * 256 + d]);\n"
 "                    }\n"
 "                }\n"
 "                out[i] += sum;\n"
 "            }\n"
 "    }\n"
 "    for (ushort i = 0; i < out.get_capacity(); i++) {\n"
 "        auto c = out.get_multidimensional_index(i);\n"
 "        uint row = c[1], d = sg * 64 + c[0];\n"
 "        if (q0 + row >= p.q_len)\n"
 "            continue;\n"
 "        float value = denom[row] > 0 ? out[i] / denom[row] : 0;\n"
 "        if (denom[row] == 0) {\n"
 "            float sum = 0;\n"
 "            for (uint t = 0; t < p.kv_tokens; t++) {\n"
 "                bool allowed = t + p.kv_position_offset <= p.query_position_offset + q0 + row;\n"
 "                uint physical = allowed ? blocks[t / p.page_size] + t % p.page_size : 0;\n"
 "                sum += float(v[physical * p.v_row_stride + kh * 256 + d]);\n"
 "            }\n"
 "            value = sum / float(p.kv_tokens);\n"
 "        }\n"
 "        y[((q0 + row) * p.num_heads + h) * 256 + d] = value;\n"
 "    }\n"
 "}\n"

};
typedef struct { termite_metal_decode_runtime *r; id<MTLComputePipelineState> psos[6]; id<MTLBuffer> q[8], k[8], v[8], y[8]; uint32_t *blocks; size_t n,heads,kh,nb; } Probe49;
void *probe49_create(size_t n,size_t heads,const float*q,const uint16_t*k,const uint16_t*v) {
 @autoreleasepool {
 Probe49*b=calloc(1,sizeof(*b));if(!b)return NULL;
 b->r=termite_metal_decode_runtime_create();if(!b->r)return NULL;
 termite_metal_decode_runtime_set_lightonocr3_projections(b->r,1);
 termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(b->r,1);
 b->psos[0]=b->r->lightonocr3_prefill_attention_direct_pipeline;
 for(int mode=1;mode<6;mode++){
  MTLCompileOptions *opt=[MTLCompileOptions new];opt.languageVersion=MTLLanguageVersion4_0;opt.mathMode=MTLMathModeSafe;
  NSError*err=nil;id<MTLLibrary>lib=[b->r->device newLibraryWithSource:sources[mode] options:opt error:&err];
  if(!lib){fprintf(stderr,"%s\n",err.localizedDescription.UTF8String);return NULL;}
  NSString*name=[NSString stringWithFormat:@"engine49_v%d_q%d",mode,(mode==2||mode==4)?32:16];
  b->psos[mode]=termite_metal_make_pipeline(b->r->device,lib,name);if(!b->psos[mode])return NULL;

  fprintf(stderr,"PIPELINE mode=%d shared_bytes=%lu\n",mode,(unsigned long)b->psos[mode].staticThreadgroupMemoryLength);
 }
 b->n=n;b->heads=heads;b->kh=heads/4;b->nb=(n+127)/128;b->blocks=calloc(b->nb,4);
 for(size_t p=0;p<b->nb;p++)b->blocks[p]=(b->nb-1-p)*128;
 size_t qs=n*heads*256,ks=n*b->kh*256;
 for(int z=0;z<8;z++){
 b->q[z]=[b->r->device newBufferWithLength:(qs+32)*4 options:MTLResourceStorageModeShared];
 b->k[z]=[b->r->device newBufferWithLength:b->nb*128*b->kh*256*2 options:MTLResourceStorageModeShared];
 b->v[z]=[b->r->device newBufferWithLength:b->k[z].length options:MTLResourceStorageModeShared];
 b->y[z]=[b->r->device newBufferWithLength:(qs+32)*4 options:MTLResourceStorageModeShared];
 if(!b->q[z]||!b->k[z]||!b->v[z]||!b->y[z])return NULL;
 memcpy((float*)b->q[z].contents+16,q+z*qs,qs*4);
 for(size_t t=0;t<n;t++){
 size_t physical=b->blocks[t/128]+t%128;
 memcpy((uint16_t*)b->k[z].contents+physical*b->kh*256,k+z*ks+t*b->kh*256,b->kh*256*2);
 memcpy((uint16_t*)b->v[z].contents+physical*b->kh*256,v+z*ks+t*b->kh*256,b->kh*256*2);
 }
 for(size_t j=0;j<qs+32;j++)((float*)b->y[z].contents)[j]=-12345.0f;
 }
 return b;
 }
}
int probe49_run(void*raw,int mode,double*us){
 @autoreleasepool{
 Probe49*b=raw;if(mode<0||mode>=6)return -9;
 b->r->lightonocr3_prefill_attention_direct_pipeline=b->psos[mode];
 engine49_query_tile=(mode==2||mode==4)?32:16;
 uint64_t calls=b->r->lightonocr3_prefill_attention_direct_dispatches;
 if(termite_metal_decode_runtime_begin_frame(b->r))return -1;
 for(int z=0;z<8;z++){
 b->r->attention_span_encoded_key_buffers[7]=b->k[z];b->r->attention_span_v_buffers[7]=b->v[z];
 b->r->attention_span_slot_key_row_bytes[7]=b->kh*256*2;b->r->attention_span_slot_v_row_stride[7]=b->kh*256;
 if(termite_metal_decode_runtime_attention_paged_slot_device(b->r,7,3,(__bridge void*)b->q[z],64,b->blocks,b->nb,128,b->n,b->n,b->heads,b->kh,256,b->kh*256*2,b->kh*256*2,0,0,0,0,NULL,0,(__bridge void*)b->y[z],64))return -2;
 }
 if(termite_metal_decode_runtime_submit_frame(b->r)||termite_metal_decode_runtime_wait_frame(b->r))return -3;
 if(b->r->lightonocr3_prefill_attention_direct_dispatches!=calls+8)return -4;
 *us=b->r->last_frame_gpu_nanos/1000.0;
 size_t qs=b->n*b->heads*256;
 for(int z=0;z<8;z++)for(int j=0;j<16;j++)if(((float*)b->y[z].contents)[j]!=-12345.0f||((float*)b->y[z].contents)[16+qs+j]!=-12345.0f)return -5;
 return 0;
 }
}
const float*probe49_output(void*raw,int z){Probe49*b=raw;return (float*)b->y[z].contents+16;}
void probe49_destroy(void*raw){
 if(!raw)return;Probe49*b=raw;termite_metal_decode_runtime_destroy(b->r);
 for(int z=0;z<8;z++){b->q[z]=nil;b->k[z]=nil;b->v[z]=nil;b->y[z]=nil;}
 for(int i=0;i<6;i++)b->psos[i]=nil;free(b->blocks);free(b);
}

// Copyright 2026 Antfly, Inc.
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Standalone dispatcher, full-output and independent CPU checks. Build like
// check_metal_projections.m. --benchmark emits balanced old/new JSON samples.

_Static_assert(sizeof(termite_metal_paged_attention_params) == 80, "Prefill Metal parameter ABI");
_Static_assert(offsetof(termite_metal_paged_attention_params, softcap) == 72, "Prefill softcap ABI");

static int check(termite_metal_decode_runtime *r, size_t n, size_t prefix, size_t heads, size_t page,
                 bool padded, int poison, bool benchmark) {
    const size_t kh = heads / 4, width = heads * 256, kv = n + prefix;
    const size_t blocks = (kv + page - 1) / page, physical = blocks * page;
    const size_t kstride = kh * 256 + (padded ? 16 : 0), vstride = kh * 256 + (padded ? 32 : 0);
    const size_t count = n * width, slot = 7;
    id<MTLBuffer> q = [r->device newBufferWithLength:(count + 8) * 4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> k = [r->device newBufferWithLength:physical * kstride * 2
                                             options:MTLResourceStorageModeShared];
    id<MTLBuffer> v = [r->device newBufferWithLength:physical * vstride * 2
                                             options:MTLResourceStorageModeShared];
    id<MTLBuffer> y = [r->device newBufferWithLength:(count + 8) * 4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> producer = [r->device newBufferWithLength:count * 4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> consumer = [r->device newBufferWithLength:count * 4 options:MTLResourceStorageModeShared];
    uint32_t *table = malloc(blocks * 4);
    float *gold = malloc(count * 4);
    if (!q || !k || !v || !y || !producer || !consumer || !table || !gold)
        return 1;
    uint32_t rng = 123;
    for (size_t i = 0; i < count; i++) {
        rng = rng * 1664525u + 1013904223u;
        ((float *)producer.contents)[i] = ((int)(rng >> 16) - 32768) * .00002f * (padded ? 8 : 1);
    }
    for (size_t i = 0; i < physical * kstride; i++) {
        rng = rng * 1664525u + 1013904223u;
        ((__fp16 *)k.contents)[i] = ((int)(rng >> 16) - 32768) * .00002f;
    }
    for (size_t i = 0; i < physical * vstride; i++) {
        rng = rng * 1664525u + 1013904223u;
        ((__fp16 *)v.contents)[i] = ((int)(rng >> 16) - 32768) * .00002f;
    }
    for (size_t i = 0; i < blocks; i++)
        table[i] = (uint32_t)((blocks - 1 - i) * page);
    if (poison == 1)
        for (size_t i = 0; i < width; i++)
            ((float *)producer.contents)[i] = NAN;
    if (poison == 2)
        for (size_t i = 0; i < kh * 256; i++)
            ((__fp16 *)k.contents)[table[0] * kstride + i] = NAN;
    if (poison == 3)
        ((__fp16 *)v.contents)[(table[(kv - 1) / page] + (kv - 1) % page) * vstride] = NAN;
    if (poison == 4)
        ((__fp16 *)v.contents)[(table[1 / page] + 1 % page) * vstride] = INFINITY;
    memcpy((char *)q.contents + 16, producer.contents, count * 4);
    for (size_t i = 0; i < 4; i++)
        ((uint32_t *)q.contents)[i] = ((uint32_t *)q.contents)[count + 4 + i] = 0xdeadbeef;
    r->attention_span_encoded_key_buffers[slot] = k;
    r->attention_span_v_buffers[slot] = v;
    r->attention_span_slot_key_row_bytes[slot] = kstride * 2;
    r->attention_span_slot_v_row_stride[slot] = vstride;
    const size_t trials = benchmark ? 30 : 1, modes = benchmark ? 2 : 9;
    float worst = 0;
    for (size_t trial = 0; trial < trials; trial++)
        for (size_t order = 0; order < modes; order++) {
            const size_t mode = benchmark ? (order + trial % 2) % 2 : order;
            if (mode == 0 || mode == 3)
                setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_ATTENTION_MPP", "1", 1);
            else
                unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_ATTENTION_MPP");
            id<MTLComputePipelineState> saved = r->lightonocr3_prefill_attention_mpp_pipeline;
            id<MTLComputePipelineState> saved32 = r->lightonocr3_prefill_attention_mpp32_pipeline;
            id<MTLComputePipelineState> saved_direct = r->lightonocr3_prefill_attention_direct_pipeline;
            if (mode == 2) {
                r->lightonocr3_prefill_attention_mpp_pipeline = nil;
                r->lightonocr3_prefill_attention_mpp32_pipeline = nil;
                r->lightonocr3_prefill_attention_direct_pipeline = nil;
            }
            if (mode == 7 || mode == 8)
                r->lightonocr3_prefill_attention_direct_pipeline = nil;
            if (mode == 7)
                r->lightonocr3_prefill_attention_mpp32_pipeline = nil;
            termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r, mode != 4);
            const uint64_t before = r->lightonocr3_prefill_attention_mpp_dispatches;
            const uint64_t before_direct = r->lightonocr3_prefill_attention_direct_dispatches;
            for (size_t i = 0; i < count + 8; i++)
                ((uint32_t *)y.contents)[i] = 0xdeadbeef;
            if (termite_metal_decode_runtime_begin_frame(r))
                return 2;
            if (mode >= 5) {
                if (termite_metal_decode_runtime_begin_planned_compute_scope(
                        r, TERMITE_METAL_COMPUTE_SOURCE_ATTENTION, TERMITE_METAL_COMPUTE_REGION_OTHER))
                    return 3;
                for (size_t i = 0; i < count; i++)
                    ((float *)q.contents)[i + 4] = -.9f;
                if (termite_metal_buffer_slice_last_dim_2d(r, (__bridge void *)producer, 0, n, width, 0,
                                                           width, (__bridge void *)q, 16))
                    return 4;
            }
            const uint64_t start = clock_gettime_nsec_np(CLOCK_UPTIME_RAW);
            int rc;
            if (mode == 6) {
                rc = termite_metal_encode_paged_attention_slot_on_encoder(
                    r, r->active_planned_compute_encoder, slot, 3, q, 16, table, blocks, page, n, kv, heads,
                    kh, 256, kstride * 2, kstride * 2, prefix + 17, 17, 0, 0, NULL, 0, y, 16, -1);
            } else {
                rc = termite_metal_decode_runtime_attention_paged_slot_device(
                    r, slot, 3, (__bridge void *)q, 16, table, blocks, page, n, kv, heads, kh, 256,
                    kstride * 2, kstride * 2, prefix + 17, 17, 0, 0, NULL, 0, (__bridge void *)y, 16);
            }
            if (rc) {
                fprintf(stderr, "encode failure %d\n", rc);
                return 5;
            }
            if (mode >= 5 && termite_metal_buffer_slice_last_dim_2d(r, (__bridge void *)y, 16, n, width, 0,
                                                                    width, (__bridge void *)consumer, 0))
                return 6;
            if (termite_metal_decode_runtime_submit_frame(r) || termite_metal_decode_runtime_wait_frame(r))
                return 7;
            const uint64_t elapsed = clock_gettime_nsec_np(CLOCK_UPTIME_RAW) - start;
            r->lightonocr3_prefill_attention_mpp_pipeline = saved;
            r->lightonocr3_prefill_attention_mpp32_pipeline = saved32;
            r->lightonocr3_prefill_attention_direct_pipeline = saved_direct;
            const bool eligible = n >= 128 && n <= 2048 && kv <= 4096;
            if (r->lightonocr3_prefill_attention_mpp_dispatches - before !=
                ((mode == 1 || mode >= 5) && eligible ? 1 : 0))
                return 8;
            const bool expected_direct = eligible && (mode == 1 || mode == 5 || mode == 6) && page % 16 == 0;
            if (r->lightonocr3_prefill_attention_direct_dispatches - before_direct !=
                (expected_direct ? 1 : 0))
                return 15;
            if (benchmark)
                printf("{\"heads\":%zu,\"queries\":%zu,\"keys\":%zu,\"trial\":%zu,\"mode\":%zu,\"wall_us\":%."
                       "4f,\"gpu_us\":%.4f}\n",
                       heads, n, kv, trial, mode, elapsed / 1000.0, r->last_frame_gpu_nanos / 1000.0);
            const float *got = (float *)y.contents + 4;
            if (mode == 0)
                memcpy(gold, got, count * 4);
            // The first balanced trial can run new before old only on later trials,
            // when the deterministic reference is already available.
            if (mode != 0)
                for (size_t i = 0; i < count; i++) {
                    if (isnan(got[i]) != isnan(gold[i]) || isinf(got[i]) != isinf(gold[i]) ||
                        (isinf(got[i]) && signbit(got[i]) != signbit(gold[i]))) {
                        fprintf(stderr, "nonfinite mismatch mode=%zu i=%zu got=%g expected=%g\n", mode, i,
                                got[i], gold[i]);
                        return 9;
                    }
                    if (isfinite(got[i]) && isfinite(gold[i]))
                        worst = fmaxf(worst, fabsf(got[i] - gold[i]));
                }
            if (mode >= 5 && memcmp(consumer.contents, got, count * 4))
                return 10;
            for (size_t i = 0; i < 4; i++)
                if (((uint32_t *)y.contents)[i] != 0xdeadbeef ||
                    ((uint32_t *)y.contents)[count + 4 + i] != 0xdeadbeef ||
                    ((uint32_t *)q.contents)[i] != 0xdeadbeef ||
                    ((uint32_t *)q.contents)[count + 4 + i] != 0xdeadbeef)
                    return 11;
        }
    // Independent double-precision samples cover first/tail queries and heads.
    double cpu_error = 0;
    if (!poison)
        for (size_t row_case = 0; row_case < 2; row_case++)
            for (size_t hcase = 0; hcase < 2; hcase++)
                for (size_t dcase = 0; dcase < 2; dcase++) {
                    size_t row = row_case ? n - 1 : 0, h = hcase ? heads - 1 : 0, d = dcase ? 255 : 0;
                    size_t key_head = h / 4;
                    double best = -INFINITY, sum = 0, value = 0;
                    for (size_t t = 0; t <= prefix + row; t++) {
                        size_t phys = table[t / page] + t % page;
                        double score = 0;
                        for (size_t i = 0; i < 256; i++)
                            score += (double)((float *)producer.contents)[row * width + h * 256 + i] *
                                     ((__fp16 *)k.contents)[phys * kstride + key_head * 256 + i];
                        score *= .0625;
                        double next = fmax(best, score), c = exp(best - next), weight = exp(score - next);
                        sum = sum * c + weight;
                        value =
                            value * c + weight * ((__fp16 *)v.contents)[phys * vstride + key_head * 256 + d];
                        best = next;
                    }
                    cpu_error = fmax(cpu_error, fabs(gold[row * width + h * 256 + d] - value / sum));
                }
    fprintf(
        stderr,
        "prefill_check queries=%zu keys=%zu heads=%zu page=%zu padded=%d poison=%d max_abs=%g cpu_error=%g\n",
        n, kv, heads, page, padded, poison, worst, cpu_error);
    if (!benchmark) {
        memset((char *)y.contents + 16, 0x5a, count * 4);
        if (termite_metal_decode_runtime_begin_frame(r) ||
            termite_metal_decode_runtime_begin_planned_compute_scope(
                r, TERMITE_METAL_COMPUTE_SOURCE_ATTENTION, TERMITE_METAL_COMPUTE_REGION_OTHER) ||
            termite_metal_decode_runtime_attention_paged_slot_device(
                r, slot, 3, (__bridge void *)q, 16, table, blocks, page, n, kv, heads, kh, 256, kstride * 2,
                kstride * 2, prefix + 17, 17, 0, 0, NULL, 0, (__bridge void *)y, 16) ||
            termite_metal_decode_runtime_cancel_frame(r) || r->active_planned_compute_encoder != nil ||
            r->active_frame_retained_resources != NULL)
            return 13;
        for (size_t i = 0; i < count; i++)
            if (((uint32_t *)y.contents)[i + 4] != 0x5a5a5a5a)
                return 14;
    }
    r->attention_span_encoded_key_buffers[slot] = nil;
    r->attention_span_v_buffers[slot] = nil;
    free(table);
    free(gold);
    unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_ATTENTION_MPP");
    termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r, 1);
    return worst > 2e-4 || cpu_error > 2e-4 ? 12 : 0;
}

int engine49_original_conformance_main(int argc, const char **argv) {
    @autoreleasepool {
        termite_metal_decode_runtime *r = termite_metal_decode_runtime_create();
        if (!r)
            return 1;
        termite_metal_decode_runtime_set_lightonocr3_projections(r, 1);
        termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r, 1);
        if (!r->lightonocr3_projections_enabled)
            return 77;
        if (!r->lightonocr3_prefill_attention_mpp_pipeline ||
            !r->lightonocr3_prefill_attention_mpp32_pipeline ||
            !r->lightonocr3_prefill_attention_direct_pipeline)
            return 2;
        setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_ATTENTION_MPP", "1", 1);
        const bool benchmark = argc == 2 && strcmp(argv[1], "--benchmark") == 0;
        const size_t lengths[] = {8, 17, 65, 127, 128, 129, 432, 662, 1024, 2048};
        for (size_t h = 8; h <= 16; h += 8)
            for (size_t i = 0; i < sizeof(lengths) / sizeof(lengths[0]); i++) {
                int rc = check(r, lengths[i], 0, h, 128, false, 0, benchmark);
                if (rc) {
                    fprintf(stderr, "FAIL heads=%zu seq=%zu rc=%d\n", h, lengths[i], rc);
                    return 10 + rc;
                }
            }
        if (!benchmark)
            for (size_t h = 8; h <= 16; h += 8) {
                if (check(r, 129, 63, h, 16, true, 0, false) || check(r, 432, 129, h, 128, true, 0, false))
                    return 30;
                for (int poison = 1; poison <= 4; poison++)
                    if (check(r, 129, 0, h, 128, false, poison, false))
                        return 31;
                if (check(r, 129, 63, h, 8, false, 0, false))
                    return 32;
                for (int poison = 1; poison <= 4; poison++)
                    if (check(r, 432, 0, h, 16, true, poison, false))
                        return 33;
            }
        termite_metal_decode_runtime_destroy(r);
    }
    return 0;
}

int probe49_conformance(void*raw,int mode) {
 @autoreleasepool{
 Probe49*b=raw;b->r->lightonocr3_prefill_attention_direct_pipeline=b->psos[mode];engine49_query_tile=(mode==2||mode==4)?32:16;
 const size_t lengths[]={128,129,432,554,662,1024,2048};
 for(size_t h=8;h<=16;h+=8){
  for(size_t i=0;i<sizeof(lengths)/sizeof(lengths[0]);i++){int rc=check(b->r,lengths[i],0,h,128,false,0,false);if(rc)return rc;}
  if(check(b->r,129,63,h,16,true,0,false)||check(b->r,432,129,h,128,true,0,false))return 30;
  for(int poison=1;poison<=4;poison++)if(check(b->r,129,0,h,128,false,poison,false)||check(b->r,432,0,h,16,true,poison,false))return 31;
  if(check(b->r,129,63,h,8,false,0,false))return 32;
 }
 return 0;
 }
}
