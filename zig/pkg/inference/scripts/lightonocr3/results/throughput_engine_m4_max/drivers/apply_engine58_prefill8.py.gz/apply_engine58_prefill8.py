from pathlib import Path
import json,hashlib,subprocess
v=Path('.venv-lighton-vllm-metal');freeze=json.loads((v/'engine57-freeze.json').read_text())
for f,h in freeze.items():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h,f
g=Path('zig/pkg/inference/src/pipelines/generation.zig');s=g.read_text()
s=s.replace('    pub const PreparedQwenPrefillItem = struct {','    // Uniform-length pages only; the caller reserves the complete group peak.\n    pub const max_prepared_qwen_prefill_items: usize = 8;\n\n    pub const PreparedQwenPrefillItem = struct {',1)
s=s.replace('items > 4 or seq == 0','items > max_prepared_qwen_prefill_items or seq == 0',1)
s=s.replace('items.len > 4) return error.InvalidBatchDecodeState;','items.len > max_prepared_qwen_prefill_items) return error.InvalidBatchDecodeState;',1)
s=s.replace('var mixed: [4]MixedBatchDecodeItem','var mixed: [max_prepared_qwen_prefill_items]MixedBatchDecodeItem',1)
s=s.replace('var reserved: [4]usize','var reserved: [max_prepared_qwen_prefill_items]usize',1)
s=s.replace('preparedQwenPrefillHostScratch(5, 662, 248320)','preparedQwenPrefillHostScratch(9, 662, 248320)',1)
needle='    try std.testing.expectError(error.InvalidBatchDecodeState, NativeGenerationPipeline.preparedQwenPrefillHostScratch(9, 662, 248320));'
assert needle in s
s=s.replace(needle,needle+'\n    const wide_bytes = try NativeGenerationPipeline.preparedQwenPrefillHostScratch(8, 662, 248320);\n    try std.testing.expectEqual(4 * (bytes - 32 * 1024) + 32 * 1024, wide_bytes);\n    try std.testing.expectError(error.InvalidBatchDecodeState, NativeGenerationPipeline.forwardPreparedQwenPrefillBatch(&.{}));')
s=s.replace('    try std.testing.expectError(error.InvalidBatchDecodeState, NativeGenerationPipeline.forwardPreparedQwenPrefillBatch(&.{}));', '    try std.testing.expectError(error.InvalidBatchDecodeState, NativeGenerationPipeline.forwardPreparedQwenPrefillBatch(&.{}));\n    var too_many: [9]NativeGenerationPipeline.PreparedQwenPrefillItem = undefined;\n    try std.testing.expectError(error.InvalidBatchDecodeState, NativeGenerationPipeline.forwardPreparedQwenPrefillBatch(&too_many));',1)
g.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text()
s=s.replace('orelse 4, 1), 4)) else 1','orelse 4, 1), generation.NativeGenerationPipeline.max_prepared_qwen_prefill_items)) else 1',1)
s=s.replace('var batch: [4]generation.NativeGenerationPipeline.PreparedQwenPrefillItem','var batch: [generation.NativeGenerationPipeline.max_prepared_qwen_prefill_items]generation.NativeGenerationPipeline.PreparedQwenPrefillItem',1)
s=s.replace('self.max_prefill_batch_items > 4','self.max_prefill_batch_items > generation.NativeGenerationPipeline.max_prepared_qwen_prefill_items',1)
s=s.replace('for ([_]usize{ 2, 4 }) |items| {','for ([_]usize{ 2, 4, 8 }) |items| {',1)
s=s.replace('for ([_]usize{ 0, 5 }) |items| {','for ([_]usize{ 0, 9 }) |items| {',1)
needle='    try std.testing.expectEqual(@as(u8, 2), batched.prefill_batch_items);'
assert needle in s
s=s.replace(needle,needle+'\n    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[4], "8", 1));\n    try std.testing.expectEqual(@as(u8, 8), Features.fromEnvironmentForModel(cfg).prefill_batch_items);\n    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[4], "99", 1));\n    try std.testing.expectEqual(@as(u8, 8), Features.fromEnvironmentForModel(cfg).prefill_batch_items);')
p.write_text(s)
subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt',str(g),str(p)],check=True)
subprocess.run(['python3',str(v/'prepare_queued_phase_priority.py'),str(v/'server-engine58-proposed.zig')],check=True)
p.write_bytes((v/'server-engine58-proposed.zig').read_bytes())
subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt',str(p)],check=True)
new={f:hashlib.sha256(Path(f).read_bytes()).hexdigest()for f in freeze};(v/'engine58-freeze.json').write_text(json.dumps(new,indent=2)+'\n')
for source,dest in [('run_engine57_verify_gpu_build.py','run_engine58_verify_gpu_build.py'),('run_engine57_budget_policies.py','run_engine58_budget_policies.py'),('run_engine57_prefill4_profile.py','run_engine58_prefill8_profile.py'),('engine57_benchmark_concurrency.py','engine58_benchmark_concurrency.py')]:
 target=v/dest;assert not target.exists();target.write_text((v/source).read_text().replace('engine57','engine58'))
bp=v/'run_engine58_budget_policies.py';s=bp.read_text();needle="    workspace_mode=re.findall"
pos=s.index(needle)
s=s[:pos]+"    queued_priority=os.environ.get('ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY','0')=='1';report['queued_phase_priority']=queued_priority\n    values=re.findall(r'LIGHTONOCR3 queued_phase_priority=(\\d+)',section);assert values and all((int(x)==1)==(queued_priority and expected_aux)for x in values),(values,queued_priority,expected_aux)\n"+s[pos:];bp.write_text(s)
print('engine58 frozen: eight-page uniform prefill with complete peak; optional queued phase priority, C and MSL unchanged')
