from pathlib import Path
import json,subprocess,sys,time
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
while True:
 p=Path('/private/tmp/ocr-engine71-transition-parent.txt');s=p.read_text()if p.exists()else''
 if 'Traceback'in s:raise RuntimeError(s[-2000:])
 if 'ENGINE71 PAIRED59 DONE'in s:break
 time.sleep(5)
d=json.loads((o/'paired59_4b_comparison_audit.json').read_text());assert d['status']in['repeated_win','early_stop_forward_loss','native_behind']
names=['run_engine71_08_paired60.py','run_engine71_florence_paired60.py']if d['status']=='repeated_win'else['run_engine71_gpu_diagnostic61.py']
for name in names:
 print('START',name,flush=True)
 with Path('/private/tmp/ocr-'+name.removesuffix('.py')+'-parent.txt').open('w')as f:subprocess.run([sys.executable,str(v/name)],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
print('ENGINE71 FOLLOW60 DONE',flush=True)
