"""Private reference diagnostics only; installed packages remain unchanged."""
import importlib.abc
import importlib.machinery
import os
import sys

directory=os.environ.get('ANTFLY_OCR_REFERENCE_PROFILE_DIR')
if directory:
    import hashlib
    import json
    import time

    def log(item):
        item.update(pid=os.getpid(),monotonic_ns=time.monotonic_ns())
        data=(json.dumps(item,separators=(',',':'))+'\n').encode()
        fd=os.open(os.path.join(directory,f'worker-{os.getpid()}.jsonl'),os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o644)
        try:os.write(fd,data)
        finally:os.close(fd)

    def install(module):
        import mlx.core as mx
        cls=module.MetalModelRunner
        if getattr(cls,'_antfly_ocr_diagnostic_installed',False):return
        cls._antfly_ocr_diagnostic_installed=True
        original_start=cls._start_paged_forward
        original_encode=cls._encode_features
        sync=os.environ.get('ANTFLY_OCR_REFERENCE_PROFILE_SYNC')=='1'
        def start(self,batch,prefill_reqs,decode_reqs,scheduler_output):
            if sync:mx.synchronize()
            began=time.perf_counter_ns()
            result=original_start(self,batch,prefill_reqs,decode_reqs,scheduler_output)
            if sync:mx.synchronize()
            state=self._execute_model_state
            log(dict(kind='forward',synchronized=sync,prefill_items=len(prefill_reqs),prefill_query_lengths=[len(x.token_ids)for x in prefill_reqs],decode_items=len(decode_reqs),scheduled_tokens=scheduler_output.total_num_scheduled_tokens,elapsed_wall_ns=time.perf_counter_ns()-began,logits_shape=list(state.logits.shape)if state is not None and state.logits is not None else None))
            return result
        def encode(self,features,*,evaluate=False):
            if sync:mx.synchronize()
            began=time.perf_counter_ns()
            result=original_encode(self,features,evaluate=evaluate)
            outputs=[self.encoder_cache.encoder_outputs[f.identifier]for f in features]
            if sync:
                mx.eval([(x.hidden_states,x.deepstack_visual_embeds or [])for x in outputs]);mx.synchronize()
            log(dict(kind='vision',synchronized=sync,items=len(features),hidden_shapes=[list(x.hidden_states.shape)for x in outputs],elapsed_wall_ns=time.perf_counter_ns()-began))
            return result
        cls._start_paged_forward=start
        cls._encode_features=encode
        log(dict(kind='installed',module=module.__file__,module_sha256=hashlib.sha256(open(module.__file__,'rb').read()).hexdigest(),synchronized=sync,scope='Private diagnostic. Extra synchronization perturbs pipeline overlap. Stage values are synchronized wall time, not pure GPU time; no primary throughput claim.'))

    class Loader:
        def __init__(self,loader):self.loader=loader
        def create_module(self,spec):
            return self.loader.create_module(spec)if hasattr(self.loader,'create_module')else None
        def exec_module(self,module):
            self.loader.exec_module(module);install(module)
    class Finder(importlib.abc.MetaPathFinder):
        def find_spec(self,fullname,path=None,target=None):
            if fullname!='vllm_metal.v1.model_runner':return None
            spec=importlib.machinery.PathFinder.find_spec(fullname,path)
            if spec is not None and spec.loader is not None:spec.loader=Loader(spec.loader)
            return spec
    sys.meta_path.insert(0,Finder())
