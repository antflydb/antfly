from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

v = Path('.venv-lighton-vllm-metal')
out = Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
for model in sys.argv[1:] or ['4b', '08']:
    assert model in ['4b', '08']
    cases = [(64, 2, False), (64, 1, True), (56, 2, True)] if model == '4b' else [(64, 4, False), (64, 2, True), (64, 1, True)]
    records = []
    for concurrency, blocks, stream in cases:
        label = f'vision_stream{int(stream)}_physical64_c{concurrency}_vf{blocks}_r128'
        dest = out / f'engine39_{model}_{label}'
        assert not (dest / 'report.json').exists()
        env = os.environ.copy()
        env.update(OCR_REFERENCE_LABEL='_primary_reference20_r0_auto_c64_r128', OCR_PHYSICAL32='0',
                   OCR_PHYSICAL64='1', OCR_CONCURRENCY=str(concurrency), OCR_REQUESTS='128', OCR_WIDE='1',
                   OCR_SCRATCH_GIB='10' if model == '4b' else '8', OCR_BACKEND_GIB='17' if model == '4b' else '16',
                   OCR_KV_GIB='4', OCR_CPU_PREPROCESS='1', OCR_PREFILL_DECODE_STREAK='0',
                   OCR_POLICIES='engineepoch', OCR_SHARED_CORE='1' if model == '4b' else '0',
                   OCR_BF16_PREFILL='1' if model == '4b' else '0', OCR_BF16='0', OCR_VISION_BATCH='0',
                   OCR_VISION_FRAME_BLOCKS=str(blocks), OCR_SINGLE_FRAME='1', OCR_STREAM_FIRST='0',
                   OCR_LOGICAL64='1', OCR_SHARED_DECODER_SCRATCH='1', OCR_DEVICE_RECURRENT_STATE='1',
                   OCR_ENCODER_SCOPES='1', OCR_ADMISSION_UNITS='512', OCR_VISION_STREAM=str(int(stream)),
                   OCR_DISABLE_64_ROW_TILE='0' if model == '4b' else '1')
        print('START', model, label, flush=True)
        with Path(f'/private/tmp/ocr-engine39-{model}-{label}-driver.txt').open('w') as log:
            result = subprocess.run([sys.executable, str(v / 'run_engine39_budget_no_prefill_policies_verify.py'), model + ':' + label], env=env, stdout=log, stderr=subprocess.STDOUT)
        print('DONE', model, label, result.returncode, flush=True)
        assert result.returncode == 0, (model, label, result.returncode)
        p = dest / 'report.json'
        d = json.loads(p.read_text())
        r = d['results'][0]
        x = r['policy_rounds'][0]
        assert r['status'] == 'ok' and r['serial_reference_parity'] and r['cross_runtime_content_parity']
        assert x['completed'] == 128 and not x['admission_pressures'] and not d['own_cpu_compile_overlap']
        oracle = json.loads((out / f'vllm_{model}_primary_reference20_r0_auto_c64_r128/report.json').read_text())
        assert {t['image_index']: t['text'] for t in r['references']} == {t['image_index']: t['text'] for t in oracle['references']}
        records.append(dict(concurrency=concurrency, vision_stream=stream, vision_frame_blocks=blocks,
                            admitted_retained_vision_blocks=blocks * (2 if stream else 1),
                            pages_per_second=x['pages_per_second'], process_cpu_ms=x['process_cpu_ms'],
                            framed_runtime_totals=x['framed_runtime_totals'], average_decode_rows=x['average_decode_rows'],
                            completed=128, full_fixture_string_identity=True, all_native_pages_equal_serial_reference=True,
                            stream_stats=x['vision_stream_stats'], report=str(p.relative_to(out)),
                            report_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
        audit = out / f'engine39_{model}_vision_comparison_audit.json'
        audit.write_text(json.dumps(dict(status='running', scope='Unpaired R128 candidates; fresh controls required for a vLLM win.', candidates=records), indent=2) + '\n')
    audit.write_text(json.dumps(dict(status='pass', scope='Complete unpaired R128 candidates; fresh controls required for a vLLM win.', candidates=records), indent=2) + '\n')
