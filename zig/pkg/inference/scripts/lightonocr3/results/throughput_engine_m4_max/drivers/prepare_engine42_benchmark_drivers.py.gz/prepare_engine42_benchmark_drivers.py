from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine41_budget_policies_verify.py').read_text().replace('engine41','engine42')
needle=" if os.environ.get('OCR_DISABLE_64_ROW_TILE','0')=='1':cmd+=['--disable-64-row-tile']"
assert s.count(needle)==1
s=s.replace(needle,needle+"\n wide_gate_disabled=os.environ.get('OCR_DISABLE_WIDE_GATE_UP','0')=='1'\n if wide_gate_disabled:cmd+=['--disable-wide-gate-up']")
needle="report['ocr_encoder_scopes']=encoder_scopes;"
assert s.count(needle)==1
s=s.replace(needle,"report['disable_wide_gate_up']=wide_gate_disabled;"+needle)
needle="    if physical64 and int(c)>32:assert max(sample['packed_core_rows_observed'])>32,sample"
assert s.count(needle)==1
s=s.replace(needle,needle+"""
    assert 'wide_gate_up_calls' in sample,sample
    if wide_gate_disabled or bf16:assert sample['wide_gate_up_calls']==0,sample
    elif physical64 and int(c)>32 and wide and not disable_mpp:assert sample['wide_gate_up_calls']>0,sample""")
(v/'run_engine42_budget_policies.py').write_text(s)
(v/'engine42_benchmark_concurrency.py').write_bytes(Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
for name in ['run_engine41_functional.py','engine41_verify_preset_only_test.py','engine41_verify_preset_physical32_test.py','engine41_verify_default_gpu_test.py']:
 (v/name.replace('engine41','engine42')).write_text((v/name).read_text().replace('engine41','engine42'))
