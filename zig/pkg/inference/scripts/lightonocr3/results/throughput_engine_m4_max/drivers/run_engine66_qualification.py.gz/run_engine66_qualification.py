from pathlib import Path
import json,hashlib,subprocess,sys,datetime
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=json.loads((o/'engine65_c_qualification_audit.json').read_text());assert d['status']=='pass' and len(d['checks'])==19
for p,h in d['input_sha256'].items():assert sha(p)==h,p
m=json.loads((o/'engine65_c_build_manifest.json').read_text());assert sha(m['binary'])==m['binary_sha256']
d.update(reused_unchanged_c_qualification=True,source_audit_sha256=sha(o/'engine65_c_qualification_audit.json'),scope='All C runtime, shader, header and conformance-checker input hashes and the previously tested C binary are identical. Reuse the 19 passing C suites; new projector frame scheduling is qualified by fresh Zig ownership tests and actual GPU integration.',verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(o/'engine66_c_qualification_audit.json').write_text(json.dumps(d,indent=2)+'\n')
for name,cmd in [('gpu-build',[sys.executable,str(v/'run_engine66_verify2_gpu_build.py')]),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine66','/private/tmp/ocr-engine66-verify2-gpu-build.txt']),('metal-disabled',[sys.executable,str(v/'run_engine66_metal_disabled.py')])]:
 print('START',name,flush=True)
 with Path('/private/tmp/ocr-engine66-'+name+'-driver.txt').open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True);assert r.returncode==0,(name,r.returncode)
print('ENGINE66 QUALIFICATION DONE',flush=True)
