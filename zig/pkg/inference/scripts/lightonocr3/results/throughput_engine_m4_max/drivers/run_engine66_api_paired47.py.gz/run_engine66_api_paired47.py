from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
(v if False else Path.cwd()/'.venv-lighton-vllm-metal').joinpath('engine66-paired47.pid').write_text(str(os.getpid()))

root = Path.cwd()
v = root / '.venv-lighton-vllm-metal'
scripts = root / 'zig/pkg/inference/scripts/lightonocr3'
out = scripts / 'results/throughput_engine_m4_max'
source = out / 'engine66_vision_pipeline46_4b_r128_audit.json'
while not source.exists() or json.loads(source.read_text())['status'] != 'pass':
    pp=Path('/private/tmp/ocr-engine66-screen1-parent.txt')
    if pp.exists() and 'unexpected runtime/check failure' in pp.read_text(): raise RuntimeError('native profile qualification failed')
    time.sleep(5)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
candidates = json.loads(source.read_text())['candidates']
eligible = [x for x in candidates if x['eligible']]
assert eligible
maximum_concurrency = max(x['settings'][0] for x in eligible)
wide_candidates = [x for x in eligible if x['settings'][0] == maximum_concurrency]
wide = max(wide_candidates or eligible, key=lambda x: x['pages_per_second'])
other = max((x for x in eligible if x['settings'] != wide['settings']), key=lambda x: x['pages_per_second'], default=None)
profiles = {'wide': wide}
# Retain only the best independently qualified native profile for this primary.
for p in profiles.values():
    assert sha(out / p['report']) == p['report_sha256']
for p, h in json.loads((v / 'engine66-freeze.json').read_text()).items():
    assert sha(root / p) == h, p

record = dict(status='running', created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              scope='Balanced A32/A64/B/B/A64/A32 controls, retaining the faster measured API reference independently on each side. Qualified two-bank streamed vision plus four-step native C64 with original caps and independently qualified full R128 outputs. API vLLM reference search at C32 and C64, max_model_len1024, gpu_memory_utilization0.65, automatic cache sizing (no override). Both run before native; choose the faster current control, then reverse the native/reference order with that fixed configuration. Auto capacity, maximum supported concurrency, and memory probe are retained in each server log. Reference concurrency and admitted capacity may differ from native; this measures usable framework throughput on a shared machine, not equal-concurrency kernel FLOPS. Original weights, three unique-UUID uncached fixtures, R128, max_tokens256, fresh serial strings; no own compilation/profiling during timings.',
              profiles=profiles, comparisons=[], reference_candidates=[], source_audit_sha256=sha(source))
audit = out / 'paired47_4b_comparison_audit.json'
assert not audit.exists()
def save():
    audit.write_text(json.dumps(record, indent=2) + '\n')

def reference(index, concurrency):
    label = f'_primary_reference47_r{index}_auto_c{concurrency}_r128_ctx1024'
    dest = out / ('vllm_4b' + label)
    assert not dest.exists()
    images = [root / 'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png', scripts / 'corpus/receipt.png', scripts / 'corpus/shipping.png']
    cmd = [sys.executable, str(scripts / 'benchmark_vllm_metal.py'), '--python', sys.executable,
           '--model-dir', str(v / 'ocr-models/lighton4b'), '--images', *map(str, images),
           '--concurrency', str(concurrency), '--requests', '128', '--max-tokens', '256', '--startup-timeout', '600', '--max-model-len', '1024', '--gpu-memory-utilization', '0.65', '--output-dir', str(dest)]
    print('START VLLM', index, concurrency, flush=True)
    with Path(f'/private/tmp/ocr-engine66-vllm-paired47-r{index}-c{concurrency}.txt').open('w') as log:
        subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=True)
    p = dest / 'report.json'
    d = json.loads(p.read_text())
    assert d['status'] == 'ok' and d['kv_cache_block_override'] is None and d['cache_override_admission']['admitted'] and d['results'][0]['serial_reference_parity']
    assert max(x['usage']['prompt_tokens'] for x in d['references'])+256<=1024
    print('DONE VLLM', index, concurrency, d['results'][0]['pages_per_second'], flush=True)
    return label, d, p

def native(key, index, oracle):
    c, pref, vis, vf, sv, sp, q = profiles[key]['settings']
    label = f'paired47_{key}_r{index}_c{c}_p{pref}_v{vis}_vf{vf}_r128'
    dest = out / ('engine66_4b_' + label)
    assert not dest.exists()
    env = os.environ.copy()
    env.update(OCR_REFERENCE_LABEL=oracle, OCR_PHYSICAL32='0', OCR_PHYSICAL64='1', OCR_CONCURRENCY=str(c),
               OCR_REQUESTS='128', OCR_WIDE='1', OCR_KV_GIB='4', OCR_BACKEND_GIB='17', OCR_SCRATCH_GIB='10',
               OCR_CPU_PREPROCESS='1', OCR_PREFILL_DECODE_STREAK='0', OCR_POLICIES='engineepoch', OCR_SHARED_CORE='1',
               OCR_BF16_PREFILL='1', OCR_BF16='0', OCR_DISABLE_64_ROW_TILE='0', OCR_DISABLE_WIDE_GATE_UP='0',
               OCR_WIDE64_GATE_UP='1', OCR_FULL64_GATE_UP='1', OCR_GPU_GREEDY_STREAM='0', OCR_STREAM_CHUNK_LAYERS='0',
               OCR_VISION_BATCH=str(int(vis > 1)), OCR_VISION_BATCH_ITEMS=str(vis), OCR_VISION_WAIT_US='2000',
               OCR_PREFILL_BATCH=str(int(pref > 1)), OCR_PREFILL_BATCH_ITEMS=str(pref), OCR_PREFILL_WAIT_US=str(profiles[key].get('prefill_wait_us', 100000)),
               OCR_VISION_FRAME_BLOCKS=str(vf), OCR_SINGLE_FRAME='1', OCR_STREAM_FIRST='0', OCR_LOGICAL64='1',
               OCR_SHARED_DECODER_SCRATCH='1', OCR_DEVICE_RECURRENT_STATE='1', OCR_ENCODER_SCOPES='1', OCR_ADMISSION_UNITS='512',
               OCR_BATCH_ARGMAX='1', OCR_DEFER_VISION_SEAL=str(sv), OCR_DEFER_PREFILL_SEAL=str(sp),
               OCR_CACHE_VISION_WORKSPACE='1', OCR_LARGE_VISION_PACK_REUSE=str(int(vis > 1)),
               ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY=str(q), OCR_TIMEOUT='900')
    env['OCR_RESIDENT_VISION_BUDGET']='1'
    env['OCR_GPU_TOKEN_BURST']='1'
    env['OCR_GPU_TOKEN_BURST_WIDTH']='4'
    env['OCR_PIPELINE_VISION']='1'
    print('START NATIVE', key, index, profiles[key]['settings'], flush=True)
    with Path(f'/private/tmp/ocr-engine66-native-paired47-{key}-r{index}-driver.txt').open('w') as log:
        subprocess.run([sys.executable, str(v / 'run_engine66_budget_policies.py'), '4b:' + label], env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    p = dest / 'report.json'
    d = json.loads(p.read_text())
    result = d['results'][0]
    s = result['policy_rounds'][0]
    assert result['status'] == 'ok' and result['serial_reference_parity'] and result['cross_runtime_content_parity']
    assert s['completed'] == 128 and not s['admission_pressures'] and not d['own_cpu_compile_overlap']
    assert s['host_recurrent_bytes_total'] == s['single_frame_topology_mismatches'] == s['gpu_greedy_stream_topology_mismatches'] == 0
    assert s['vision_workspace_reuses'] > 0 and s['batch_argmax_calls'] > 0
    assert d['queued_phase_priority'] == bool(q) and d['resident_vision_budget'] and d['gpu_token_burst']
    assert s['gpu_token_burst_steps']>0 and s['gpu_token_burst_topology_mismatches']==0
    assert s['gpu_token_burst_max_width']==4 and s['gpu_token_burst_extra_steps']>s['gpu_token_burst_steps']
    assert s['vision_pipeline_images']==128 and s['vision_pipeline_overlaps']>0 and d['pipeline_vision']
    print('DONE NATIVE', key, index, s['pages_per_second'], flush=True)
    return d, p

def compare(key, index, n, r):
    nd, np = n
    _, rd, rp = r
    result = nd['results'][0]
    assert {x['image_index']: x['text'] for x in result['references']} == {x['image_index']: x['text'] for x in rd['references']}
    a = result['policy_rounds'][0]['pages_per_second']
    b = rd['results'][0]['pages_per_second']
    row = dict(reference_concurrency=rd['results'][0]['concurrency'], reference_automatic_cache=True, profile=key, round=index, native_pages_per_second=a, reference_pages_per_second=b,
               native_to_vllm_ratio=a / b, full_fixture_string_identity=True, all_128_native_pages_equal_serial_reference=True,
               primary_throughput_eligible=True, native_report=str(np.relative_to(out)), native_report_sha256=sha(np),
               reference_report=str(rp.relative_to(out)), reference_report_sha256=sha(rp))
    record['comparisons'].append(row)
    save()
    print('COMPARISON', json.dumps(row), flush=True)

save()
refs=[reference(0,c) for c in [32,64]]
for label,d,p in refs:
 record['reference_candidates'].append(dict(concurrency=d['results'][0]['concurrency'],pages_per_second=d['results'][0]['pages_per_second'],report=str(p.relative_to(out)),report_sha256=sha(p)))
r0=max(refs,key=lambda x:x[1]['results'][0]['pages_per_second'])
record['selected_reference_concurrency']=r0[1]['results'][0]['concurrency'];save()
a0=native('wide',0,r0[0]);compare('wide',0,a0,r0)
if record['comparisons'][-1]['native_to_vllm_ratio']<=1:
 record['status']='early_stop_forward_loss';save();print('FINAL',record['status'],flush=True);sys.exit(0)
a1=native('wide',1,r0[0]);reverse_refs=[reference(1,c)for c in [64,32]]
for label,d,p in reverse_refs:
 record['reference_candidates'].append(dict(round=1,concurrency=d['results'][0]['concurrency'],pages_per_second=d['results'][0]['pages_per_second'],report=str(p.relative_to(out)),report_sha256=sha(p)))
r1=max(reverse_refs,key=lambda x:x[1]['results'][0]['pages_per_second']);compare('wide',1,a1,r1)
ratios=[x['native_to_vllm_ratio']for x in record['comparisons']]
record['status']='repeated_win'if min(ratios)>1 else'native_behind'
record['profile_outcomes']={'wide':'clear_repeated_win'if min(ratios)>=1.05 else'small_repeated_lead'if min(ratios)>1 else'native_behind'}
save();print('FINAL',record['status'],record['profile_outcomes'],flush=True)
