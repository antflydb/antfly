from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';out=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';manifest=out/'engine48_build_manifest.json';binary=json.loads(manifest.read_text())['binary_path'];label='cpu_sample_c64_r64_full64_0';target=out/('engine48_4b_'+label)
assert not(target/'report.json').exists()
env=os.environ.copy();env.update(OCR_CONCURRENCY='64',OCR_REQUESTS='64',OCR_WIDE='1',OCR_PHYSICAL32='0',OCR_PHYSICAL64='1',OCR_BF16='0',OCR_SCRATCH_GIB='10',OCR_BACKEND_GIB='17',OCR_KV_GIB='4',OCR_STREAM_FIRST='0',OCR_GPU_GREEDY_STREAM='0',OCR_SINGLE_FRAME='1',OCR_SHARED_CORE='1',OCR_BF16_PREFILL='1',OCR_POLICIES='engineepoch',OCR_REFERENCE_LABEL='_primary_reference20_r0_auto_c64_r128',OCR_VISION_BATCH='0',OCR_VISION_BATCH_ITEMS='1',OCR_VISION_FRAME_BLOCKS='2',OCR_PREFILL_BATCH='0',OCR_PREFILL_BATCH_ITEMS='1',OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_LOGICAL64='1',OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',OCR_ADMISSION_UNITS='512',OCR_DISABLE_64_ROW_TILE='0',OCR_WIDE64_GATE_UP='1',OCR_FULL64_GATE_UP='1',OCR_DISABLE_WIDE_GATE_UP='0')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();samples=[]
with open('/private/tmp/ocr-engine48-cpu-sample-driver.txt','w')as log:
 process=subprocess.Popen([sys.executable,str(v/'run_engine48_budget_policies_verify.py'),'4b:'+label],env=env,stdout=log,stderr=subprocess.STDOUT)
 start=time.monotonic();trigger=None;pid=None
 while process.poll()is None:
  raw=target/'lighton4b-batch-c64.txt'
  if trigger is None and raw.exists()and 'OCR_POLICY round=0' in raw.read_text():
   entries={}
   for line in subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines():
    fields=line.strip().split(None,2)
    if len(fields)==3:entries[int(fields[0])]=(int(fields[1]),fields[2])
   candidates=[]
   for candidate,(parent,command)in entries.items():
    if not command.startswith(binary+' '):continue
    ancestors=set();current=candidate
    while current in entries and current not in ancestors:ancestors.add(current);current=entries[current][0]
    if process.pid in ancestors:candidates.append(candidate)
   assert len(candidates)==1,candidates;pid=candidates[0];trigger=time.monotonic();print('verified own OCR descendant',pid,flush=True)
  if trigger is not None:
   for index,(stage,delay)in enumerate([('early',2),('middle',25),('late',50)]):
    if len(samples)!=index or time.monotonic()-trigger<delay:continue
    dest=Path('/private/tmp')/('ocr-engine48-cpu-'+stage+'-sample.txt');stamp=datetime.datetime.now(datetime.timezone.utc).isoformat();print('sample',stage,pid,flush=True)
    r=subprocess.run(['sample',str(pid),'3','1','-file',str(dest)],stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT)
    samples.append(dict(stage=stage,pid=pid,started_at=stamp,exit_code=r.returncode,path=str(dest),sha256=sha(dest)if dest.exists()else None))
  if time.monotonic()-start>600:raise RuntimeError('diagnostic exceeded expected duration')
  time.sleep(.2)
 rc=process.wait();print('exit',rc,'samples',len(samples),flush=True)
 if(target/'report.json').exists():
  p=target/'report.json';d=json.loads(p.read_text());d.update(primary_throughput=False,primary_throughput_eligible=False,instrumented_cpu_sample=True,own_cpu_sampling_overlap=True,own_cpu_compile_overlap=False);p.write_text(json.dumps(d,indent=2)+'\n')
  (target/'instrumentation_audit.json').write_text(json.dumps(dict(report_sha256=sha(p),binary_sha256=sha(Path(binary)),build_manifest_sha256=sha(manifest),primary_throughput_eligible=False,reason='Three three-second Mac CPU stack samples of this benchmark descendant only; no own CPU compilation. Current engine48 ReleaseFast binary; available symbols are used as-is.',samples=samples),indent=2)+'\n')
 sys.exit(rc)
