from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine42_budget_policies.py').read_text().replace('engine42','engine43')
needle=" if os.environ.get('OCR_DISABLE_64_ROW_TILE','0')=='1':cmd+=['--disable-64-row-tile']"
assert s.count(needle)==1
s=s.replace(needle,needle+"\n greedy_stream=os.environ.get('OCR_GPU_GREEDY_STREAM','0')=='1'\n if greedy_stream:cmd+=['--gpu-greedy-stream']")
needle="report['disable_wide_gate_up']=wide_gate_disabled;"
assert s.count(needle)==1
s=s.replace(needle,"report['gpu_greedy_stream']=greedy_stream;report['wide_gate_up_model_qualified']=model=='08';"+needle)
s=s.replace("if physical32 and not single:","if physical32 and not single and not greedy_stream:")
s=s.replace("if single:assert sample['standalone_wide_heads']==0","if single or greedy_stream:assert sample['standalone_wide_heads']==0")
s=s.replace("(sample['executor_steps']if single and not token_scope_disabled else 0)","(sample['executor_steps']if (single or greedy_stream) and not token_scope_disabled else 0)")
needle="    if single:assert sample['single_frame_steps']==sample['executor_steps'],sample"
assert s.count(needle)==1
s=s.replace(needle,needle+"""
    assert sample['gpu_greedy_stream_topology_mismatches']==0,sample
    assert sample['gpu_greedy_stream_steps']==(sample['executor_steps'] if greedy_stream else 0),sample
    assert sample['gpu_greedy_stream_two_frame_steps']==sample['stream_forward_splits'] if greedy_stream else sample['gpu_greedy_stream_two_frame_steps']==0,sample
    if greedy_stream:assert sample['gpu_greedy_stream_two_frame_steps']>0 and not single,sample""")
s=s.replace("if wide_gate_disabled or bf16:assert sample['wide_gate_up_calls']==0","if model=='4b' or wide_gate_disabled or bf16:assert sample['wide_gate_up_calls']==0")
(v/'run_engine43_budget_policies.py').write_text(s)
(v/'engine43_benchmark_concurrency.py').write_bytes(Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
for name in ['run_engine42_functional.py','engine42_verify_preset_only_test.py','engine42_verify_preset_physical32_test.py','engine42_verify_default_gpu_test.py']:
 (v/name.replace('engine42','engine43')).write_text((v/name).read_text().replace('engine42','engine43'))
