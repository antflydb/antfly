from pathlib import Path
import json,subprocess,sys,hashlib,datetime
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';p=root/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_engine_m4_max'
images=[root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png',p/'corpus/receipt.png',p/'corpus/shipping.png']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
audit=dict(scope='MLX-VLM proxy only: installed vLLM Metal has no Florence adapter. Native publisher Q4_K with no-repeat trigrams vs original MLX FP16 default greedy. Serial MLX is the only available valid batch size; prior batch2 parity failure excluded. R64 forward/reverse order on shared hardware, no own CPU compilation or sampling.',required_ratio=1.05,comparisons=[],status='running')
def save():(out/'paired14_florence_comparison_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
def ref(i):
 dest=out/f'mlx_florence_engine31_paired14_r{i}_reference';assert not(dest/'report.json').exists()
 cmd=[sys.executable,str(p/'benchmark_mlx_florence.py'),'--model-dir',str(v/'ocr-models/florence-fp16'),'--images',*[str(x)for x in images],'--batch-sizes','1','--requests','64','--max-tokens','256','--output-dir',str(dest)]
 print('START MLX proxy',i,flush=True)
 with open(f'/private/tmp/ocr-engine31-florence-paired14-reference{i}.txt','w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 assert r.returncode==0;d=json.loads((dest/'report.json').read_text());assert d['status']=='ok'and d['results'][0]['serial_reference_parity'];print('DONE MLX proxy',i,d['results'][0]['pages_per_second'],flush=True)
 return dest/'report.json',d
def native(i,oracle):
 print('START NATIVE',i,flush=True);r=subprocess.run([sys.executable,str(v/'run_engine31_florence_paired14_native.py'),str(i),str(oracle)]);assert r.returncode==0
 dest=out/f'engine31_florence_paired14_r{i}_native/report.json';d=json.loads(dest.read_text());r=d['results'][0];assert r['status']=='ok'and r['serial_reference_parity']and r['cross_runtime_content_parity']and r['policy_rounds'][0]['completed']==64
 print('DONE NATIVE',i,r['policy_rounds'][0]['pages_per_second'],flush=True);return dest,d
def compare(i,n,ref,order):
 np,nd=n;rp,rd=ref;r=nd['results'][0];s=r['policy_rounds'][0]
 # Native benchmark validates cross-runtime string identity against its supplied report.
 assert [x['text']for x in r['references']]==[x['text']for x in rd['references']]
 ratio=s['pages_per_second']/rd['results'][0]['pages_per_second'];audit['comparisons'].append(dict(round=i,order=order,native_report=str(np.relative_to(out)),native_report_sha256=sha(np),proxy_report=str(rp.relative_to(out)),proxy_report_sha256=sha(rp),native_pages_per_second=s['pages_per_second'],proxy_pages_per_second=rd['results'][0]['pages_per_second'],native_to_proxy_ratio=ratio,all_64_pages_equal_serial_reference=True,full_fixture_string_identity=True,single_frame=r['florence_single_frame']));save();print('COMPARE',i,ratio,flush=True)
save();r0=ref(0);compare(0,native(0,0),r0,'MLX proxy then native');n1=native(1,0);compare(1,n1,ref(1),'native then fresh MLX proxy');audit['status']='clear_repeated_proxy_win'if all(x['native_to_proxy_ratio']>=1.05 for x in audit['comparisons'])else'native_behind_proxy'if any(x['native_to_proxy_ratio']<=1 for x in audit['comparisons'])else'small_margin_requires_more_evidence';save();print(audit['status'],flush=True)
