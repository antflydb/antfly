from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
p=v/'run_engine45_gqa_ffn_ablation_budget.py'
assert not p.exists()
s=(v/'run_engine45_budget_policies.py').read_text()
needle=" print('START',key,flush=True)"
assert s.count(needle)==1
s=s.replace(needle," cmd+=['--disable-ocr-ffn-fusion']\n"+needle)
needle="report['wide64_gate_up']=wide64_gate_up;"
assert s.count(needle)==1
s=s.replace(needle,"report['ordinary_decoder_ffn_fusion_disabled']=True;"+needle)
p.write_text(s)
p=v/'run_engine45_gqa_ffn_ablation.py';assert not p.exists()
s=(v/'run_engine45_wide64_cases.py').read_text()
s=s.replace("label=f'wide64_gate_up_enabled","label=f'gqa_ffn_disabled_wide64_gate_up_enabled")
s=s.replace("v/'run_engine45_budget_policies.py'","v/'run_engine45_gqa_ffn_ablation_budget.py'")
s=s.replace("f'engine45_4b_wide64_gate_up_{mode}_audit.json'","f'engine45_4b_gqa_ffn_disabled_{mode}_audit.json'")
s=s.replace("records=[]","records=[]\n# The CLI disables the ordinary decoder FFN selector (attention layers).\n# Prepared recurrent-layer FFNs call C directly and retain their existing route.")
p.write_text(s)
