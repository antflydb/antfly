from pathlib import Path
v=Path('.venv-lighton-vllm-metal');variants=[(16,8,1),(16,16,1),(16,32,1),(16,32,2),(16,64,2),(16,64,4)]
msl='#include <metal_stdlib>\n#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\nusing namespace metal;\nusing namespace mpp::tensor_ops;\nstruct Params{uint rows,in_dim,out_dim,pad;};\n'
for i,(m,n,sg)in enumerate(variants):
 msl+=f'''kernel void wide_mpp_{i}(device float*x[[buffer(0)]],device bfloat*w[[buffer(1)]],device float*bias[[buffer(2)]],device float*y[[buffer(3)]],constant Params&p[[buffer(4)]],uint2 group[[threadgroup_position_in_grid]]){{
 tensor<device float,dextents<int,2>,tensor_inline>a(x,dextents<int,2>(p.in_dim,p.rows),array<int,2>{{1,int(p.in_dim)}});
 tensor<device bfloat,dextents<int,2>,tensor_inline>b(w,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{{1,int(p.in_dim)}});
 tensor<device float,dextents<int,2>,tensor_inline>c(y,dextents<int,2>(p.out_dim,p.rows),array<int,2>{{1,int(p.out_dim)}});
 auto left=a.slice(0,int(group.y)*{m});auto right=b.slice(0,int(group.x)*{n});auto dest=c.slice(int(group.x)*{n},int(group.y)*{m});
 constexpr auto desc=matmul2d_descriptor({m},{n},dynamic_length_v<int>,false,true,false);matmul2d<desc,execution_simdgroups<{sg}>>op;
 auto result=op.get_destination_cooperative_tensor<decltype(left),decltype(right),float>();op.run(left,right,result);
 for(ushort i=0;i<result.get_capacity();i++){{auto coord=result.get_multidimensional_index(i);int col=int(group.x)*{n}+coord[0],row=int(group.y)*{m}+coord[1];if(coord[0]>=0&&coord[0]<{n}&&coord[1]>=0&&coord[1]<{m}&&col<int(p.out_dim)&&row<int(p.rows))result[i]+=bias[col];}}
 result.store(dest);
}}\n'''
(v/'wide_mpp_probe.metal').write_text(msl)
s=(v/'wide_register_probe.m').read_text().replace('wide_register_probe.metal','wide_mpp_probe.metal').replace('WIDE_REGISTER','WIDE_MPP').replace('PROBE_FAIL','MPP_PROBE_FAIL')
s=s.replace('MTLSizeMake(out/(4*(32/sn)*tm),1,1)','MTLSizeMake(out/sn,1,1)').replace('threadsPerThreadgroup:MTLSizeMake(128,1,1)','threadsPerThreadgroup:MTLSizeMake(tm*32,1,1)').replace('const size_t sns[6]={16,16,16,32,32,32},tms[6]={1,2,4,1,2,4}','const size_t sns[6]={8,16,32,32,64,64},tms[6]={1,1,1,2,2,4}').replace('pipelines[variant].maxTotalThreadsPerThreadgroup<128','pipelines[variant].maxTotalThreadsPerThreadgroup<tms[variant]*32').replace('opts.fastMathEnabled=NO;','opts.fastMathEnabled=NO;opts.languageVersion=MTLLanguageVersion4_0;').replace('@"termite_lightonocr3_local_proj_vec16_%zu_%zu",sns[i],tms[i]','@"wide_mpp_%zu",i')
(v/'wide_mpp_probe.m').write_text(s)
