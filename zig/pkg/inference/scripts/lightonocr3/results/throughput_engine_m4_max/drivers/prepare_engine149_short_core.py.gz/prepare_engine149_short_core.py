from pathlib import Path
import json,hashlib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();p=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=p.read_text();needle='#import <Metal/Metal.h>';assert s.count(needle)==1;s=s.replace(needle,needle+'\nstatic int engine149_short_path=0;\nstatic int engine149_pick=0;')
a=s.index('        id<MTLComputePipelineState> pipelines[5]={runtime->qwen35_conv_pipeline',s.index('int termite_metal_decode_runtime_qwen35_core_device('));b=s.index('        const bool parallel_norm =',a);part=s[a:b];assert part.count('seq >= 128')==2;part=part.replace('runtime->qwen35_ocr_vector_loads_enabled && seq >= 128','runtime->qwen35_ocr_vector_loads_enabled && (seq >= 128 || (seq > 1 && engine149_short_path && (engine149_pick & 2)))').replace('const bool prefill_norm = seq >= 128','const bool prefill_norm = (seq >= 128 || (seq > 1 && engine149_short_path && (engine149_pick & 1)))');s=s[:a]+part+s[b:];(v/'engine149_short_core_kernels.m').write_text(s)
s=(r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine149_short_core_kernels.m"')
a=s.index('static int prefill_core_check(');b=s.index('static int compute_copy_check(',a);part=s[a:b];part=part.replace('            uint64_t before =','            engine149_short_path = variant != 0;\n            uint64_t before =');part=part.replace('variant == 1 && seq >= 128 ? 1 : 0','variant == 1 && (seq >= 128 || (seq > 1 && (engine149_pick & 1))) ? 1 : 0');part=part.replace('    free(state_seed);','    engine149_short_path = 0;\n    free(state_seed);');s=s[:a]+part+s[b:];(v/'engine149_short_core_checks.m').write_text(s)
s='''#define main unused_short149_main
#include "engine149_short_core_checks.m"
#undef main
int main(int argc,const char**argv){@autoreleasepool{
 if(argc<2)return 1;engine149_pick=atoi(argv[1]);if(engine149_pick<1||engine149_pick>3)return 2;
 const bool benchmark=argc==3&&strcmp(argv[2],"--benchmark")==0;
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 3;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 const size_t qs[]={1,2,4,8,16,17,22,31,32,42,48,63,64,65,96,127,128};
 for(size_t h=16;h<=32;h+=16)for(size_t i=0;i<sizeof(qs)/sizeof(qs[0]);i++)for(size_t init=0;init<2;init++){
 int rc=prefill_core_check(r,qs[i],h,init,benchmark);if(rc){fprintf(stderr,"SHORT149 FAIL pick=%d h=%zu seq=%zu init=%zu rc=%d\\n",engine149_pick,h,qs[i],init,rc);return rc+10;}
 }
 fprintf(stderr,"SHORT149 FULL CORE STATE INTERMEDIATE CANARY CHECKS PASS pick=%d benchmark=%d\\n",engine149_pick,benchmark);
 termite_metal_decode_runtime_destroy(r);return 0;
}}
''';(v/'engine149_short_core_probe.m').write_text(s)
ps=[v/f'engine149_short_core_{x}.m'for x in ['kernels','checks','probe']]+[Path(__file__)];(v/'engine149_short_core_preparation.json').write_text(json.dumps(dict(status='prepared_not_built_or_run',canonical_c_sha256=sha(p),scope='Private eligibility only for existing short prefill parallel norm and columns4 recurrence. Independent norm/columns/both picks, original arithmetic, no production global. No canonical changes.',source_sha256={str(p):sha(p)for p in ps}),indent=2)+'\n');print('Prepared149 short-core source only; no build/GPU work')
