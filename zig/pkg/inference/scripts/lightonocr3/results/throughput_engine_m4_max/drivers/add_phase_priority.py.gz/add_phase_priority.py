from pathlib import Path
p=Path('zig/pkg/inference/src/pipelines/generation.zig');s=p.read_text();a='    executor_sequence_control: ?InferenceExecutionControl = null,';assert s.count(a)==1;s=s.replace(a,a+'\n    execution_phase_waiters: ?*std.atomic.Value(usize) = null,',1)
a='''    fn lockExecution(self: *const NativeGenerationPipeline, mutex: *std.atomic.Mutex) !void {
        if (self.execution_control)''';assert s.count(a)==1;s=s.replace(a,'''    fn lockExecution(self: *const NativeGenerationPipeline, mutex: *std.atomic.Mutex) !void {
        const waiters = if (self.execution_lock == mutex) self.execution_phase_waiters else null;
        if (waiters) |count| _ = count.fetchAdd(1, .acq_rel);
        defer if (waiters) |count| { _ = count.fetchSub(1, .acq_rel); };
        if (self.execution_control)''',1)
a='    fn shouldStopOnEos(';i=s.index(a);s=s[:i]+'''    fn lockExecutionForCleanup(self: *const NativeGenerationPipeline, mutex: *std.atomic.Mutex) void {
        const waiters = if (self.execution_lock == mutex) self.execution_phase_waiters else null;
        if (waiters) |count| _ = count.fetchAdd(1, .acq_rel);
        defer if (waiters) |count| { _ = count.fetchSub(1, .acq_rel); };
        if (waiters != null) {
            (InferenceExecutionControl{}).lockWithPoll(mutex, 100 * std.time.ns_per_us) catch unreachable;
        } else platform.sync.lockYielding(mutex);
    }

'''+s[i:]
# Replace cleanup-only raw locks, not the fallbacks inside the two helpers.
s=s.replace('if (self.execution_lock) |mutex| platform.sync.lockYielding(mutex);','if (self.execution_lock) |mutex| self.lockExecutionForCleanup(mutex);')
a='''        if (self.execution_lock) |mutex| {
            platform.sync.lockYielding(mutex);
        }''';assert s.count(a)==1;s=s.replace(a,'''        if (self.execution_lock) |mutex| self.lockExecutionForCleanup(mutex);''',1);p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text();a='''        phase_wait_ns: u64 = 0,''';assert s.count(a)==1;s=s.replace(a,a+'''\n        phase_fair: bool = false,
        phase_waiters: std.atomic.Value(usize) = .init(0),
        phase_priority_yields: usize = 0,''',1)
a='''            ctx.phase_wait_ns = if (platform.env.getenvBool("ANTFLY_LIGHTONOCR3_PHASE_PARK")) ctx.execution_gate_wait_ns else 0;''';assert s.count(a)==1;s=s.replace(a,a+'''\n            ctx.phase_fair = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_PHASE_FAIR");''',1)
a='''        fn lockStep(ctx: *LightOnStreamContext, control: InferenceExecutionControl) !void {
            try control.lockWithPoll''';assert s.count(a)==1;s=s.replace(a,'''        fn lockStep(ctx: *LightOnStreamContext, control: InferenceExecutionControl) !void {
            if (ctx.phase_fair) _ = ctx.phase_waiters.fetchAdd(1, .acq_rel);
            defer if (ctx.phase_fair) { _ = ctx.phase_waiters.fetchSub(1, .acq_rel); };
            try control.lockWithPoll''',1)
a='''        fn lockStepForCleanup(ctx: *LightOnStreamContext) void {
            if (ctx.phase_wait_ns''';assert s.count(a)==1;s=s.replace(a,'''        fn lockStepForCleanup(ctx: *LightOnStreamContext) void {
            if (ctx.phase_fair) _ = ctx.phase_waiters.fetchAdd(1, .acq_rel);
            defer if (ctx.phase_fair) { _ = ctx.phase_waiters.fetchSub(1, .acq_rel); };
            if (ctx.phase_wait_ns''',1)
a='''            while (!ctx.worker_stop.load(.acquire)) {
                // Reset only after''';assert s.count(a)==1;s=s.replace(a,'''            while (!ctx.worker_stop.load(.acquire)) {
                // Request phases cannot enqueue decode until vision/prompt
                // preparation obtains this same GPU gate. Do not immediately
                // reacquire it forever just because continuations stay queued.
                if (ctx.phase_fair and ctx.phase_waiters.load(.acquire) != 0) {
                    ctx.phase_priority_yields += 1;
                    io.sleep(.fromMicroseconds(100), .awake) catch {};
                    continue;
                }
                // Reset only after''',1)
a='''            .executor_sequence_control = if (platform.env.getenvBool("ANTFLY_LIGHTONOCR3_EXECUTOR_TAIL")) control else null,''';assert s.count(a)==1;s=s.replace(a,a+'''\n            .execution_phase_waiters = if (ctx.phase_fair) &ctx.phase_waiters else null,''',1)
a='''                std.debug.print("LIGHTONOCR3 executor_tail_steps={d}\\n", .{ctx.worker_tail_steps});''';assert s.count(a)==1;s=s.replace(a,a+'''\n                std.debug.print("LIGHTONOCR3 phase_priority_yields={d} phase_fair={d}\\n", .{ctx.phase_priority_yields, @intFromBool(ctx.phase_fair)});''',1)
a='''            "ANTFLY_LIGHTONOCR3_EXECUTOR_TAIL",
        };''';assert s.count(a)==1;s=s.replace(a,'''            "ANTFLY_LIGHTONOCR3_EXECUTOR_TAIL",
            "ANTFLY_LIGHTONOCR3_PHASE_FAIR",
        };''',1)
a='''const engine = std.mem.eql(u8, policy, "enginetail")''';assert s.count(a)==1;s=s.replace(a,'''const engine = std.mem.eql(u8, policy, "enginetailfair") or std.mem.eql(u8, policy, "enginefullfair") or std.mem.eql(u8, policy, "enginetail")''',1)
s=s.replace('''or std.mem.eql(u8, policy, "enginetail")) "1" else "0"''','''or std.mem.eql(u8, policy, "enginetail") or std.mem.eql(u8, policy, "enginetailfair") or std.mem.eql(u8, policy, "enginefullfair")) "1" else "0"''')
a='''if (std.mem.eql(u8, policy, "enginetail")) "1" else "0", 1)''';assert s.count(a)==1;s=s.replace(a,'''if (std.mem.eql(u8, policy, "enginetail") or std.mem.eql(u8, policy, "enginetailfair")) "1" else "0", 1)''',1)
a='''            std.debug.print("OCR_POLICY round={d} name={s}\\n", .{ round, policy });''';assert s.count(a)==1;s=s.replace(a,'''            if (std.mem.startsWith(u8, policy, "engine")) {
                if (Env.setenv("ANTFLY_LIGHTONOCR3_PHASE_FAIR", if (std.mem.eql(u8, policy, "enginetailfair") or std.mem.eql(u8, policy, "enginefullfair")) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;
            }
'''+a,1);p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text().replace('''            "enginetail",
''','''            "enginetail",
            "enginetailfair",
            "enginefullfair",
''',1);p.write_text(s)
