from pathlib import Path
import datetime,hashlib,json,os,psutil,subprocess,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while True:
 parent=Path('/private/tmp/ocr-engine74-burst64-verify2-parent.txt').read_text()
 if 'Traceback'in parent:raise RuntimeError('Inspect failed burst screen before starting another GPU phase.')
 if 'ENGINE74 BURST64 DONE'in parent:break
 time.sleep(5)
prep=json.loads((v/'engine78_packed_ffn_proposal.json').read_text());assert all(sha(r/p)==h for p,h in prep['inputs'].items())
audit=o/'engine78_packed_ffn_probe_audit.json';assert not audit.exists();binary=v/'engine78_packed_ffn_probe';assert not binary.exists()
d=dict(status='preparing',primary_throughput_eligible=False,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope=prep['qualification'],preparation_sha256=sha(v/'engine78_packed_ffn_proposal.json'),inputs=prep['inputs'],driver_sha256=sha(Path(__file__)),working_estimate_bytes=prep['working_estimate_bytes'],os_reserve_bytes=prep['os_reserve_bytes'])
def save():audit.write_text(json.dumps(d,indent=2)+'\n')
save()
try:
 while psutil.virtual_memory().available<8*1024**3:time.sleep(5)
 cmd=['clang','-O3','-fobjc-arc','-I','zig/pkg/inference/src/backends',str(v/'engine78_packed_ffn_probe.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(binary)]
 build=Path('/private/tmp/ocr-engine78-build.txt');print('START PACKED FFN78 BUILD',flush=True)
 with build.open('w')as f:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
 d.update(build_exit_code=result.returncode,build_command=cmd,build_log_sha256=sha(build));save();assert result.returncode==0
 d['binary_sha256']=sha(binary);save()
 while psutil.virtual_memory().available<prep['working_estimate_bytes']+prep['os_reserve_bytes']:time.sleep(5)
 d.update(status='running',available_bytes_before_probe=psutil.virtual_memory().available);save();print('START PACKED FFN78 GPU',flush=True)
 stdout=Path('/private/tmp/ocr-engine78-stdout.txt');stderr=Path('/private/tmp/ocr-engine78-stderr.txt');assert not stdout.exists()and not stderr.exists()
 env=dict(os.environ,ANTFLY_LIGHTONOCR3_THROUGHPUT='0',TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY='1')
 for key in ['TERMITE_METAL_STAGE_TIMING','TERMITE_METAL_TRACE_ENCODER_TIMING','TERMITE_METAL_TRACE_ENCODERS']:env.pop(key,None)
 with stdout.open('w')as so,stderr.open('w')as se:result=subprocess.run([str(binary)],stdout=so,stderr=se,env=env,timeout=900)
 records=[json.loads(line)for line in stdout.read_text().splitlines()if line.startswith('{"variant":')]
 d.update(exit_code=result.returncode,records=records,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr));save();assert result.returncode==0 and len(records)==24
 assert len({(x['variant'],x['rows'],x['leg'])for x in records})==24
 assert all(x['max_abs']<=2e-4 and x['packed_differences']==x['norm_packed_differences']==0 and len(x['gpu_us'])==8 and len(x['host_encode_us'])==8 for x in records)
 assert 'PROBE78 FULL PACKED/OUTPUT/CORNER/CANARY CHECKS PASS'in stderr.read_text()
 d['status']='prototype_pass';save();print('ENGINE78 PACKED FFN PROBE DONE',flush=True)
except BaseException as e:
 d.update(status='failed',error=repr(e));save();raise
