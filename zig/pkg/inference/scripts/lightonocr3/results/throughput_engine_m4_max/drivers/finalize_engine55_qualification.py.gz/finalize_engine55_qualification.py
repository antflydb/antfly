from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
frozen=json.loads((v/'engine55-freeze.json').read_text());assert all(sha(p)==h for p,h in frozen.items())
c=json.loads((o/'engine55_c_qualification_audit.json').read_text());assert c['status']=='pass'and len(c['checks'])==14
assert 'DONE default_gpu_test 0'in Path('/private/tmp/ocr-engine55-functional-driver.txt').read_text()
a=json.loads((o/'engine55_stage_profiles_audit.json').read_text());assert a['status']=='pass'
smoke=o/'engine55_08_stage_queue_argmax_smoke_c8_r16/report.json';d=json.loads(smoke.read_text());rs=d['results'][0];s=rs['policy_rounds'][0];assert rs['status']=='ok'and rs['serial_reference_parity']and rs['cross_runtime_content_parity']and s['completed']==16 and not s['admission_pressures']
ref=o/'vllm_4b_diagnostic_reference29_stage_screen_c64_r64/report.json';rd=json.loads(ref.read_text());native=o/'engine55_4b_rolling_chunks0_trial0_c48_p3_vf2_r64_baseline_all_off_after_stages/report.json';nd=json.loads(native.read_text());nr=nd['results'][0];ns=nr['policy_rounds'][0]
assert rd['status']=='ok'and rd['results'][0]['serial_reference_parity']and nr['status']=='ok'and ns['completed']==64 and not ns['admission_pressures']
identity={x['image_index']:x['text']for x in nr['references']}=={x['image_index']:x['text']for x in rd['references']}
q=dict(status='pass',source_files=frozen,integration=dict(selected=238,passed=237,skipped=1),c_suites=14,functional_profiles=3,smoke_runtime_completed_before_checker_fix=True,smoke_verification='Original saved run replayed through verify2; only the invalid C8 wide-projection assertion changed, original execution driver SHA retained.',stage_profiles=a['candidates'],fresh_reference_screen=dict(native_pages_per_second=ns['pages_per_second'],vllm_pages_per_second=rd['results'][0]['pages_per_second'],native_to_vllm_ratio=ns['pages_per_second']/rd['results'][0]['pages_per_second'],full_fixture_string_identity=identity,requests=64,native_concurrency=48,vllm_concurrency=64,primary_r128_comparison=False),parity_goal_achieved=False)
(o/'engine55_full_qualification_audit.json').write_text(json.dumps(q,indent=2)+'\n')
ns={};src=(v/'archive_engine10_evidence.py').read_text();exec(src[:src.index("archive('qualification'")],ns)
ns['archive']('qualification',list(Path('/private/tmp').glob('ocr-engine55-*.txt')),'logs_manifest.json')
ns['archive']('drivers',[Path(__file__)],'drivers_manifest.json');print('engine55 qualified; fresh screen remains behind vLLM')
