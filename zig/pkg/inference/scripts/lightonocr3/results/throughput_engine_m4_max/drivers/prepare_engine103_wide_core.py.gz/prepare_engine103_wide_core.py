from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';s=(r/'zig/pkg/inference/src/backends/metal_kernels.m').read_text();base=hashlib.sha256(s.encode()).hexdigest()
for name,tail in [('handles','[15]'),('offsets','[15]'),('bytes','[15]'),('params','[6]')]:
 old=f'qwen35_core_batch_{name}[16]{tail}';assert s.count(old)==1;s=s.replace(old,f'qwen35_core_batch_{name}[64]{tail}')
s=s.replace('uint32_t lightonocr3_recurrent_parallel_traced_rows;','uint64_t lightonocr3_recurrent_parallel_traced_rows;')
a=s.index('int termite_metal_decode_runtime_qwen35_core_batch_begin(');b=s.index('void termite_metal_decode_runtime_qwen35_core_batch_abort(',a);part=s[a:b];assert 'rows > 16' in part;part=part.replace('rows > 16','rows > 64');s=s[:a]+part+s[b:]
a=s.index('static int termite_metal_lightonocr3_encode_recurrent_parallel(');b=s.index('int termite_metal_decode_runtime_qwen35_core_batch_end(',a);part=s[a:b]
for old,new in [('rows > 16','rows > 64'),('table[16]','table[64]'),('accesses[16 * 15]','accesses[64 * 15 + 1]'),('resources[16 * 15]','resources[64 * 15]'),('writes[16 * 6]','writes[64 * 6]'),('(1u << rows)','(UINT64_C(1) << (rows - 1))'),('|= 1u << rows','|= UINT64_C(1) << (rows - 1)')]:
 assert old in part,old;part=part.replace(old,new)
needle='    // Coalescing is independently qualified;';assert part.count(needle)==1
part=part.replace(needle,'''    // Inline Metal arguments are limited to 4 KiB. Larger cohorts use a
    // distinct slice of the existing frame-owned staging bank. The producer
    // retains that bank until completion; submitted/active frames use two banks.
    termite_metal_host_staging_slice staged = {nil, 0};
    size_t access_count = rows * 15;
    if (rows * sizeof(table[0]) > 4096) {
        if (runtime->active_frame_cb != cb ||
            termite_metal_decode_runtime_stage_host_bytes(runtime, table, rows * sizeof(table[0]), false, &staged) != 0)
            return -12;
        if (termite_metal_planned_range_make(staged.buffer, staged.offset, rows * sizeof(table[0]),
            TERMITE_METAL_PLANNED_RANGE_READ, &accesses[access_count++], -12) != 0) return -12;
    }
'''+needle)
part=part.replace('prepare_planned_compute_accesses(runtime, accesses, rows * 15, -12)','prepare_planned_compute_accesses(runtime, accesses, access_count, -12)')
part=part.replace('    [encoder setBytes:table length:rows * sizeof(table[0]) atIndex:0];','''    if (staged.buffer != nil) [encoder setBuffer:staged.buffer offset:staged.offset atIndex:0];
    else [encoder setBytes:table length:rows * sizeof(table[0]) atIndex:0];''')
s=s[:a]+part+s[b:];p=v/'engine103_wide_core_kernels.m';assert not p.exists();p.write_text(s)
s=(r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine103_wide_core_kernels.m"');a=s.index('static int fused_batch_core_check(');b=s.index('\nstatic int ',a+10);part=s[a:b]
part=part.replace('[2][16][15]','[2][64][15]').replace('producers[16], consumers[16]','producers[64], consumers[64]').replace('initial[16][15]','initial[64][15]')
a0=part.index('        setenv("TERMITE_METAL_DISABLE_QWEN35_FUSED_DECODE"');b0=part.index('        id<MTLComputePipelineState> saved',a0)
part=part[:a0]+'''        unsetenv("TERMITE_METAL_DISABLE_QWEN35_FUSED_DECODE");
        // Compare the exact existing parallel kernel in groups16 against a
        // wider table, with independent histories and shared immutable weights.
        if (termite_metal_decode_runtime_begin_frame(r)) return 60;
        for (size_t page = 0; page < pages; page++) {
            if (page % 16 == 0 && termite_metal_decode_runtime_qwen35_core_batch_begin(r, MIN(pages-page,(size_t)16)) != 1) return 61;
            if (termite_metal_decode_runtime_qwen35_core_device(r,handles[0][page],offsets[0][page],1,kh,vh,128,4,step != 0 || page % 2)) return 62;
            if ((page+1)%16==0 || page+1==pages) if(termite_metal_decode_runtime_qwen35_core_batch_end(r)) return 63;
        }
        if (termite_metal_decode_runtime_submit_frame(r) || termite_metal_decode_runtime_wait_frame(r)) return 64;
'''+part[b0:]
# Cases all use >=2 pages and avoid a trailing singleton in the group16 oracle.
needle='                    worst = fmaxf(worst, fabsf(got[i] - gold[i]));';assert needle in part;part=part.replace(needle,needle+'\n                    if (step < 6 && memcmp(gold+i,got+i,sizeof(float))) return 65;')
# Benchmark 16-page versus selected wider chunks with exactly the same layout.
a0=part.index('        const size_t orders[6][3]');b0=part.index('                for (size_t page = 0; page < pages; page++)',a0)
part=part[:a0]+'''        for (size_t trial = 0; trial < 32; trial++)
            for (size_t order = 0; order < 2; order++) {
                const size_t variant = (trial + order) % 2, mode = 1;
                const size_t cap = variant ? engine103_cap : 16;
                unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_RECURRENT_PARALLEL");
                setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_COALESCING", "1", 1);
'''+part[b0:]
old='''                    if (pages > 1 && termite_metal_decode_runtime_qwen35_core_batch_begin(r, pages) != 1)
                        return 17;
                    for (size_t page = 0; page < pages; page++)
                        if (termite_metal_decode_runtime_qwen35_core_device(
                                r, handles[mode][page], offsets[mode][page], 1, kh, vh, 128, 4, 1))
                            return 18;
                    if (pages > 1 && termite_metal_decode_runtime_qwen35_core_batch_end(r))
                        return 19;'''
new='''                    for (size_t page = 0; page < pages; page++) {
                        if (page % cap == 0 && termite_metal_decode_runtime_qwen35_core_batch_begin(r,MIN(pages-page,cap))!=1) return 17;
                        if (termite_metal_decode_runtime_qwen35_core_device(r,handles[mode][page],offsets[mode][page],1,kh,vh,128,4,1)) return 18;
                        if ((page+1)%cap==0 || page+1==pages) if(termite_metal_decode_runtime_qwen35_core_batch_end(r)) return 19;
                    }'''
assert old in part;part=part.replace(old,new).replace('(variant == 0 ? 0 : 16)','(16 * ((pages + cap - 1) / cap))')
# Include end-to-end frame wall time; CPU validation can outweigh GPU dispatch savings.
part=part.replace('r->last_frame_gpu_nanos / 16000.0);','r->last_frame_gpu_nanos / 16000.0);\n                printf("WALL103 trial=%zu variant=%zu wall_us=%.6f\\n", trial, variant, (clock_gettime_nsec_np(CLOCK_UPTIME_RAW)-start)/16000.0);')
s=s[:a]+part+s[b:];s=s.replace('static uint16_t round_bf16(', 'static size_t engine103_cap=64;\nstatic uint16_t round_bf16(',1);p=v/'engine103_wide_core_checks.m';assert not p.exists();p.write_text(s)
p=v/'engine103_wide_core_probe.m';assert not p.exists();p.write_text('''#define main engine103_unused_main
#include "engine103_wide_core_checks.m"
#undef main
int main(int argc,char **argv){@autoreleasepool{
 if(argc!=3)return 1;engine103_cap=strtoul(argv[1],NULL,10);size_t pages=strtoul(argv[2],NULL,10);
 if(engine103_cap<16||engine103_cap>64||pages<2||pages>64)return 2;
 setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL","1",1);
 void *raw=NULL;if(termite_metal_decode_runtime_create(&raw))return 3;
 termite_metal_decode_runtime*r=raw; r->qwen35_ocr_vector_loads_enabled=true;r->lightonocr3_projections_enabled=true;
 int rc=fused_batch_core_check(r,16,32,pages,true);if(!rc)fprintf(stderr,"WIDE103 FULL STATE/OUTPUT BITS/CANARIES PASS pages=%zu cap=%zu\\n",pages,engine103_cap);
 termite_metal_decode_runtime_destroy(r);return rc;
}}
''')
d=dict(production_c_sha256=base,scope='Privateonly;unchangedMetalshaderarithmetic;64-rowtableCPU/stagingprototype. Existingparallelgroup16fullstate/outputbitsexactnormal6stepsagainstwide table. FallbacktwoadditionalstepsCPUoriginaltolerance. Offset16/sharedweights/joinedoutputs/sharedscratch/GPUproducerconsumer/canaries. Benchmarksameworkspacegroup16vsselectedcap,balanced2orders32trials16repeatedcores. GPUandencodeandwholeframewall;no modelclaim.',files_sha256={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [v/'engine103_wide_core_kernels.m',v/'engine103_wide_core_checks.m',v/'engine103_wide_core_probe.m']});(v/'engine103_wide_core_preparation.json').write_text(json.dumps(d,indent=2)+'\n')
