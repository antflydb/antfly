from pathlib import Path
import hashlib,json,os,subprocess
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=json.loads((v/'engine72_recurrent_probe_preparation.json').read_text());assert sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')==p['production_c_sha256'];assert all(sha(r/f)==h for f,h in p['inputs'].items())
cmd=['clang','-O3','-fobjc-arc','-I','zig/pkg/inference/src/backends',str(v/'engine72_recurrent_probe.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(v/'engine72_recurrent_probe')]
assert not (v/'engine72_recurrent_probe').exists()
with Path('/private/tmp/ocr-engine72-probe-build.txt').open('w')as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
d=dict(exit_code=result.returncode,command=cmd,preparation_sha256=sha(v/'engine72_recurrent_probe_preparation.json'),inputs=p['inputs'],compiler_driver_sha256=sha(Path(__file__)))
if result.returncode==0:d.update(binary=str(v/'engine72_recurrent_probe'),binary_sha256=sha(v/'engine72_recurrent_probe'))
(o/'engine72_recurrent_probe_build_manifest.json').write_text(json.dumps(d,indent=2)+'\n');assert result.returncode==0,result.returncode;print('ISOLATED PROBE BUILD PASS',flush=True)
