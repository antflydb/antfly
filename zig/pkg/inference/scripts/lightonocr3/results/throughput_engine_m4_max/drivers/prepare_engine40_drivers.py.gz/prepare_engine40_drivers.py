from pathlib import Path

v = Path('.venv-lighton-vllm-metal')
s = (v / 'run_engine38_budget_no_prefill_policies.py').read_text().replace('engine38', 'engine40')
s = s.replace("planned_disabled=os.environ.get('OCR_DISABLE_PLANNED_MPP','0')=='1'", "planned_disabled=os.environ.get('OCR_DISABLE_PLANNED_MPP','0')=='1';hook=os.environ.get('OCR_PREFILL_BATCH','0')=='1';vision_items=int(os.environ.get('OCR_VISION_BATCH_ITEMS','4'))if vision_batch else 1;prefill_items=int(os.environ.get('OCR_PREFILL_BATCH_ITEMS','4'))if hook else 1")
s = s.replace(" if planned_disabled:cmd+=['--disable-planned-mpp']", " if planned_disabled:cmd+=['--disable-planned-mpp']\n cmd+=['--vision-batch-items',str(vision_items),'--prefill-batch-items',str(prefill_items)]\n if hook:cmd+=['--prefill-batch','--prefill-wait-us',os.environ.get('OCR_PREFILL_WAIT_US','100000')]")
s = s.replace("report['prefill_batch']=False", "report['prefill_batch']=hook;report['vision_batch_items']=vision_items;report['prefill_batch_items']=prefill_items")
s = s.replace("assert not prefill_batches,(sample,prefill_batches)", "assert (bool(prefill_batches)==hook) and all(1<=int(n)<=prefill_items for n,t in prefill_batches) and (not hook or sum(int(n)for n,t in prefill_batches)==int(requests)),(sample,prefill_batches)")
s = s.replace("and not sample['prefill_await_events']", "and sample['prefill_await_events']==hook")
s = s.replace('(4 if vision_batch else 1)', 'vision_items')
s = s.replace("if vision_batch:assert batches and max(sample['vision_batch_sizes'])>1 and max(sample['vision_batch_sizes'])<=4", "if vision_batch and vision_items>1:assert batches and max(sample['vision_batch_sizes'])>1 and max(sample['vision_batch_sizes'])<=vision_items")
old = "    if result['status']=='ok'and wide:assert (sample['wide_projection_tiles']>0)==(not bf16),sample"
assert old in s
s = s.replace(old, "    # A physical64 cohort need not visit the older 9..16-row projection tile.\n    if bf16:assert sample['wide_projection_tiles']==0,sample")
s = s.replace("enabled=share_decoder and not report['prefill_batch']", "enabled=share_decoder and device_state and expected_aux")
marker = "    encoder_stats=re.findall("
extra = r"""    host_permits=re.findall(r'prefill_host_scratch_acquisitions=(\d+) prefill_host_scratch_releases=(\d+) prefill_host_scratch_peak_bytes=(\d+)',section)
    assert host_permits and all(int(a)==int(b) for a,b,c in host_permits),host_permits
    sample['prefill_host_scratch_acquisitions']=sum(int(a)for a,b,c in host_permits)
    sample['prefill_host_scratch_releases']=sum(int(b)for a,b,c in host_permits)
    sample['prefill_host_scratch_peak_bytes']=max(int(c)for a,b,c in host_permits)
    assert sample['prefill_host_scratch_acquisitions']==len(prefill_batches) and (sample['prefill_host_scratch_peak_bytes']>0)==hook,host_permits
"""
assert marker in s
s = s.replace(marker, extra + marker)
(v / 'run_engine40_budget_policies.py').write_text(s)
(v / 'engine40_benchmark_concurrency.py').write_bytes(Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
for p in v.glob('engine38_verify_*test.py'):
    (v / p.name.replace('engine38', 'engine40')).write_text(p.read_text().replace('engine38', 'engine40'))
(v / 'run_engine40_functional.py').write_text((v / 'run_engine38_functional.py').read_text().replace('engine38', 'engine40'))
