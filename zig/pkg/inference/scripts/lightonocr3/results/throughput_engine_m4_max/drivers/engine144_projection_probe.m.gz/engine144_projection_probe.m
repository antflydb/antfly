#define main production_checks_main
#include "engine144_projection_checks.m"
#undef main

static int timed_linear(termite_metal_decode_runtime *r,bool on,size_t rows,size_t in,size_t out,
 id<MTLBuffer>source,id<MTLBuffer>zero,id<MTLBuffer>x,id<MTLBuffer>y,double *us){
 engine144_short_prefill=on;
 uint64_t before=r->frame_gpu_nanos,calls=engine144_calls;
 if(termite_metal_decode_runtime_begin_frame(r)||
    termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_PREFILL)||
    termite_metal_decode_runtime_apply_add_device(r,(__bridge void*)source,16,(__bridge void*)zero,0,rows*in,(__bridge void*)x,16)||
    termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_FFN,TERMITE_METAL_COMPUTE_REGION_FFN)||
    termite_metal_decode_runtime_apply_linear_multi_row_device(r,0,(__bridge void*)x,16,rows,in,out,(__bridge void*)y,16)||
    termite_metal_decode_runtime_end_planned_compute_scope(r)||
    termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r))return 1;
 if(engine144_calls-calls!=(on?1u:0u))return 2;
 *us=(r->frame_gpu_nanos-before)/1000.0;return 0;
}
static int probe_linear(termite_metal_decode_runtime*r,size_t rows,size_t in,size_t out){
 @autoreleasepool{
 id<MTLBuffer>source=[r->device newBufferWithLength:(rows*in+8)*4 options:MTLResourceStorageModeShared],
 zero=[r->device newBufferWithLength:rows*in*4 options:MTLResourceStorageModeShared],
 x=[r->device newBufferWithLength:(rows*in+8)*4 options:MTLResourceStorageModePrivate],
 y=[r->device newBufferWithLength:(rows*out+12)*4 options:MTLResourceStorageModeShared];
 uint16_t*w=malloc(in*out*2);float*b=malloc(out*4),*gold=malloc(rows*out*4);
 if(!source||!zero||!x||!y||!w||!b||!gold)return 3;
 memset(zero.contents,0,zero.length);
 float*input=(float*)source.contents+4,*got=(float*)y.contents+4;
 for(size_t i=0;i<rows*in;i++)input[i]=sinf(i*.013f)*.7f;
 uint32_t rng=123;for(size_t i=0;i<in*out;i++){rng=rng*1664525u+1013904223u;w[i]=round_bf16(((int)(rng>>16)-32768)*.000001f);}
 for(size_t i=0;i<out;i++)b[i]=cosf(i*.019f)*.2f;
 double cpu[4];
 for(size_t corner=0;corner<4;corner++){
  size_t row=corner/2?rows-1:0,col=corner%2?out-1:0;
  double sum=b[col];for(size_t k=0;k<in;k++)sum+=(double)input[row*in+k]*expand_bf16(w[col*in+k]);
  cpu[corner]=sum;
 }
 if(termite_metal_decode_runtime_prepare_linear_bf16(r,0,(uint8_t*)w,in*out*2,b,in,out))return 4;
 free(w);free(b);
 double us;if(timed_linear(r,false,rows,in,out,source,zero,x,y,&us))return 5;
 memcpy(gold,got,rows*out*4);
 for(size_t corner=0;corner<4;corner++){
  size_t row=corner/2?rows-1:0,col=corner%2?out-1:0;
  if(fabs(cpu[corner]-gold[row*out+col])>2e-4)return 6;
 }
 for(size_t leg=0;leg<4;leg++){
  const bool on=leg==1||leg==2;double total=0;float worst=0;double corner_error=0;
  for(size_t trial=0;trial<40;trial++){
   for(size_t i=0;i<4;i++)((uint32_t*)y.contents)[i]=0xdeadbeef;
   for(size_t i=rows*out+4;i<rows*out+12;i++)((uint32_t*)y.contents)[i]=0xcafebabe;
   if(timed_linear(r,on,rows,in,out,source,zero,x,y,&us))return 7;total+=us;
   for(size_t i=0;i<rows*out;i++){if(!isfinite(got[i]))return 8;worst=fmaxf(worst,fabsf(got[i]-gold[i]));}
   for(size_t c=0;c<4;c++){size_t row=c/2?rows-1:0,col=c%2?out-1:0;corner_error=fmax(corner_error,fabs(cpu[c]-got[row*out+col]));}
   for(size_t i=0;i<4;i++)if(((uint32_t*)y.contents)[i]!=0xdeadbeef)return 9;
   for(size_t i=rows*out+4;i<rows*out+12;i++)if(((uint32_t*)y.contents)[i]!=0xcafebabe)return 10;
  }
  if(worst>2e-4||corner_error>2e-4)return 11;
  fprintf(stderr,"SHORTPROJ144 rows=%zu in=%zu out=%zu on=%d leg=%zu gpu_us=%.3f max_abs=%g cpu_error=%g\n",rows,in,out,on,leg,total/40,worst,corner_error);
 }
 free(gold);return 0;
 }
}
int main(void){@autoreleasepool{
 setenv("TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS","1",1);
 unsetenv("TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS");
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);
 termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 if(termite_metal_decode_runtime_set_lighton_activation_pool(r,8*1024*1024))return 2;
 const size_t rows[]={17,22,27,31};
 for(size_t i=0;i<4;i++)for(size_t shape=0;shape<6;shape++){
  int rc=probe_linear(r,rows[i],(size_t[][2]){{2560,8192},{2560,4096},{4096,2560},{2560,1024},{2560,9216},{9216,2560}}[shape][0],(size_t[][2]){{2560,8192},{2560,4096},{4096,2560},{2560,1024},{2560,9216},{9216,2560}}[shape][1]);
  if(rc){fprintf(stderr,"SHORTPROJ144_FAIL rows=%zu shape=%zu rc=%d\n",rows[i],shape,rc);return 10+rc;}
 }
 termite_metal_decode_runtime_destroy(r);
}return 0;}
