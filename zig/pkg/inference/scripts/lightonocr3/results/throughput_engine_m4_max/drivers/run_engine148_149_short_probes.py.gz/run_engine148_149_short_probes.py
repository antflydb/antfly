from pathlib import Path
import json,hashlib,subprocess,datetime,statistics,os,sys,psutil
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((o/'engine145_group147_screen_audit.json').read_text())['status']=='screen_complete'
for p in psutil.process_iter(['cmdline']):
 try:assert not any(str(v/'qualified-binaries/engine145-test')==x for x in p.info['cmdline']or[]),'Owned model still active'
 except psutil.NoSuchProcess:pass
for n,kind in [(148,'short_prefill'),(149,'short_core')]:
 a=o/f'engine{n}_{kind}_audit.json';assert not a.exists();prep=json.loads((v/f'engine{n}_{kind}_preparation.json').read_text());assert all(sha(p)==h for p,h in prep['source_sha256'].items());d=dict(status='preregistered',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),preparation=prep,primary_throughput_eligible=False,scope='Isolated shape qualification only. Existing arithmetic; no whole-model throughput claim. No own model/build/profile overlap during timings.',runs=[])
 def save():a.write_text(json.dumps(d,indent=2)+'\n')
 save();binary=v/f'engine{n}_{kind}_probe';build=Path(f'/private/tmp/ocr-engine{n}-expanded-build.txt');assert not build.exists()
 command=['clang','-O3','-fobjc-arc','-I'+str(r/'zig/pkg/inference/src/backends'),str(v/f'engine{n}_{kind}_probe.m'),'-o',str(binary),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate'];d['build_command']=command;d['status']='building';save()
 with build.open('w')as out:p=subprocess.run(command,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')),stdout=out,stderr=subprocess.STDOUT)
 d.update(build_exit_code=p.returncode,build_log_sha256=sha(build));save();assert p.returncode==0
 d['binary_sha256']=sha(binary);save()
 picks=[0]if n==148 else[1,2,3]
 for pick in picks:
  for phase in ['check','benchmark']:
   so=Path(f'/private/tmp/ocr-engine{n}-expanded-p{pick}-{phase}-stdout.txt');se=Path(f'/private/tmp/ocr-engine{n}-expanded-p{pick}-{phase}-stderr.txt');assert not so.exists()and not se.exists();args=([str(pick)]if n==149 else[])+(['--benchmark']if phase=='benchmark'else[]);d['status']=f'p{pick}_{phase}_running';save();print('START',n,pick,phase,flush=True)
   with so.open('w')as out,se.open('w')as err:p=subprocess.run([str(binary),*args],env=dict(os.environ,MTL_DEBUG_LAYER='0'),stdout=out,stderr=err,timeout=1200)
   rec=dict(pick=pick,phase=phase,exit_code=p.returncode,stdout_sha256=sha(so),stderr_sha256=sha(se));d['runs'].append(rec);save();assert p.returncode==0,rec
   if phase=='benchmark':
    rows=[json.loads(l)for l in so.read_text().splitlines()if l.startswith('{')];assert len(rows)==(4320 if n==148 else 4080),len(rows);rec['record_count']=len(rows);rec['ratios']=[]
    keys=['heads','queries','keys','page_size']if n==148 else['heads','seq','initialized']
    for values in sorted({tuple(row[k]for k in keys)for row in rows}):
     xs=[row for row in rows if tuple(row[k]for k in keys)==values and row['trial']>=2];old=statistics.median(x['gpu_us']for x in xs if x['mode']==0);new=statistics.median(x['gpu_us']for x in xs if x['mode']==1);rec['ratios'].append(dict(zip(keys,values),old_median_gpu_us=old,new_median_gpu_us=new,old_over_new=old/new))
   else:
    assert ('SHORT148 CONTEXT PAGE OFFSET NUMERIC CHECKS PASS'if n==148 else'SHORT149 FULL CORE STATE INTERMEDIATE CANARY CHECKS PASS')in se.read_text()
    rec['shape_count']=se.read_text().count('prefill_check queries='if n==148 else'prefill_core_check seq=');assert rec['shape_count']==(72 if n==148 else 68),rec
   save();print('DONE',n,pick,phase,flush=True)
 d['status']='full_numeric_and_isolated_stage_pass_no_model_promotion';save();print('PASS',n,flush=True)
