from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name in ['run_engine90_verify3_gpu_build.py','run_engine90_metal_disabled.py','run_engine90_budget_policies.py','run_engine90_precision_memory_screen74.py']:
 p=v/name.replace('90','91');assert not p.exists();p.write_text((v/name).read_text().replace('engine90','engine91').replace('ENGINE90','ENGINE91'))
p=v/'engine91_benchmark_concurrency.py';assert not p.exists();p.write_bytes((r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
f=json.loads((v/'engine90-freeze.json').read_text());p=v/'engine91-freeze.json';assert not p.exists();p.write_text(json.dumps({f:sha(r/f)for f in f},indent=2)+'\n')
s=(v/'run_engine79_c_qualification.py').read_text().replace('engine79','engine91');s=s.replace("flags=['--check-gpu-token-burst-long'","flags=['--check-frame-staging-lifetime','--check-gpu-token-burst-long'")
s=s.replace('import subprocess,sys,json,datetime,os','import subprocess,sys,json,datetime,os,time,psutil')
s=s.replace('for flag in flags:\n','for flag in flags:\n while psutil.virtual_memory().available<8*1024**3:time.sleep(10)\n')
p=v/'run_engine91_c_qualification.py';assert not p.exists();p.write_text(s)
s=(v/'build_engine79_conformance.py').read_text().replace('engine79','engine91');p=v/'build_engine91_conformance.py';assert not p.exists();p.write_text(s)
p=v/'engine91_c_prefill_ffn_check.m';assert not p.exists();p.write_bytes((v/'engine80_c_prefill_ffn_check_verify2.m').read_bytes())
