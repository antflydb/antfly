from pathlib import Path
import json,subprocess,sys,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/paired73_4b_comparison_audit.json'
while True:
 d=json.loads(p.read_text())
 if d['status']=='native_behind':break
 assert d['status']=='running',d['status']
 time.sleep(5)
subprocess.run([sys.executable,str(v/'run_engine89_real_tiles_after_primary.py')],check=True)
print('ENGINE89 POST-PRIMARY PROBE DONE',flush=True)
