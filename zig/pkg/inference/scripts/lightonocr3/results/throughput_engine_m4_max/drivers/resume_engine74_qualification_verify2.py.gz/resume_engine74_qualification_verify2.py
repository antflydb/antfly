from pathlib import Path
import hashlib,json,subprocess,sys,types,re
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p,h in json.loads((v/'engine74-freeze.json').read_text()).items():assert sha(r/p)==h,p
old=v/'run_engine74_verify_gpu_build.py';s=old.read_text();part=s[s.index("print('exit',r.returncode)"):];assert part.count('any(int(w)==4')==1;part=part.replace('any(int(w)==4','any(int(w)==8').replace('bounded four-step token encoder','bounded eight-step token encoder')
new=v/'verify_engine74_saved_gpu_results2.py';assert not new.exists();new.write_text("from pathlib import Path\nimport re,sys,types\nr=types.SimpleNamespace(returncode=0)\nlog=Path('/private/tmp/ocr-engine74-verify2-gpu-build.txt').read_text()\nassert '258 selected; 257 passed; 1 skipped.' in log\n"+part)
for label,cmd in [('verify-saved-metal',[sys.executable,str(new)]),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine74','/private/tmp/ocr-engine74-verify2-gpu-build.txt']),('cpu',[sys.executable,str(v/'run_engine74_metal_disabled.py')])]:
 print('START ENGINE74 VERIFY2',label,flush=True)
 with Path('/private/tmp/ocr-engine74-verify2-'+label+'-parent.txt').open('w')as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE ENGINE74 VERIFY2',label,flush=True)
for p,h in json.loads((v/'engine74-freeze.json').read_text()).items():assert sha(r/p)==h,p
(o/'engine74_gpu_verification_correction_audit.json').write_text(json.dumps(dict(status='pass',reason='All 257 Metal tests passed. Original private post-checker retained a width4 expectation; separate saved-results verifier requires observed width8 and retains all other counters. No runtime changes or re-execution of native tests.',original_verifier_sha256=sha(old),corrected_saved_verifier_sha256=sha(new),native_test_log_sha256=sha('/private/tmp/ocr-engine74-verify2-gpu-build.txt')),indent=2)+'\n')
Path('/private/tmp/ocr-engine74-qualification-parent.txt').open('a').write('\nResumed by separate verify2 driver: corrected saved GPU verification, finalized identical binary, completed CPU checks. Failed original wrapper and all native test logs retained.\nENGINE74 QUALIFICATION DONE\n')
print('ENGINE74 QUALIFICATION DONE',flush=True)
