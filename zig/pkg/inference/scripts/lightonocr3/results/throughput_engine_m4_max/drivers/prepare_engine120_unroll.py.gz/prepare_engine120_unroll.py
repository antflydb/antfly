from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=(v/'prepare_engine119_vision.py').read_text().replace('119','120')
s=s.replace('using Acc=decltype(pvop.get_destination_cooperative_tensor<decltype(P0),decltype(V0),float>());Acc out[NPV]={{ @ACCINIT@ }};','@ACCDECL@')
s=s.replace('for(uint a=0;a<NPV;a++)for(ushort z=0;z<out[a].get_capacity();z++)out[a][z]=0;','@ACCZERO@')
needle=" text=text.replace('@ACCINIT@',','.join(['pvop.get_destination_cooperative_tensor<decltype(P0),decltype(V0),float>()']*npv))"
s=s.replace(needle," text=text.replace('@ACCDECL@','\\n'.join(f'auto out{i}=pvop.get_destination_cooperative_tensor<decltype(P0),decltype(V0),float>();'for i in range(npv))).replace('@ACCZERO@','\\n'.join(f'for(ushort z=0;z<out{i}.get_capacity();z++)out{i}[z]=0;'for i in range(npv)))")
needle=" assert '@'not in text"
code=''' marker='for(uint a=0;a<NPV;a++){'
 while marker in text:
  start=text.index(marker);pos=start+len(marker);depth=1
  while depth:
   depth+=(text[pos]=='{')-(text[pos]=='}');pos+=1
  body=text[start+len(marker):pos-1]
  replacement='\\n'.join('{const uint a='+str(i)+';'+body.replace('out[a]',f'out{i}')+'}'for i in range(npv))
  text=text[:start]+replacement+text[pos:]
'''
s=s.replace(needle,code+needle);(v/'prepare_engine120_vision.py').write_text(s)
s=(v/'engine119_vision_probe.m').read_text().replace('119','120');(v/'engine120_vision_probe.m').write_text(s)
