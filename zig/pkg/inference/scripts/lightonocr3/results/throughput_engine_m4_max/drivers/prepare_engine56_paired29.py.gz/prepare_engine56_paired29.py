from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine48_paired28.py').read_text().replace('paired28','paired29').replace('reference28','reference29').replace('engine48','engine56')
s=s.replace('4B engine56 native ON/OFF/OFF/ON full64 F32 matrix controls','4B engine56 fixed profile selected by its qualifying R64 throughput; fresh R128 comparison is an independent validation')
a=s.index("    c, vf, prefix, wide64, prefill, gqa_off, full64 = profile['settings']");b=s.index("    dest = out / f'engine56_",a)
s=s[:a]+'''    cfg=profile['settings']
    c,vf,prefill,vision=cfg['concurrency'],cfg['vision_frame_blocks'],cfg['prefill_items'],cfg['vision_items']
    prefix=0;wide64=True;full64=True
    label=f'paired29_r{round_index}_c{c}_v{vision}_p{prefill}_vf{vf}_workspace_r128'
    env=os.environ.copy()
    env.update(OCR_REFERENCE_LABEL=oracle,OCR_DISABLE_WIDE_GATE_UP='0',OCR_WIDE64_GATE_UP='1',OCR_FULL64_GATE_UP='1',OCR_GPU_GREEDY_STREAM='0',OCR_STREAM_CHUNK_LAYERS='0',OCR_PHYSICAL32='0',OCR_PHYSICAL64='1',
       OCR_CONCURRENCY=str(c),OCR_REQUESTS='128',OCR_WIDE='1',OCR_KV_GIB='4',OCR_BACKEND_GIB='17',OCR_SCRATCH_GIB='10',OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1',OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_DISABLE_64_ROW_TILE='0',
       OCR_VISION_BATCH=str(int(vision>1)),OCR_VISION_BATCH_ITEMS=str(vision),OCR_VISION_WAIT_US='2000',OCR_PREFILL_BATCH=str(int(prefill>1)),OCR_PREFILL_BATCH_ITEMS=str(prefill),OCR_PREFILL_WAIT_US='100000',OCR_VISION_FRAME_BLOCKS=str(vf),OCR_SINGLE_FRAME='1',OCR_STREAM_FIRST='0',OCR_LOGICAL64='1',OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',OCR_ADMISSION_UNITS='512',
       OCR_BATCH_ARGMAX=str(int(cfg['batch_argmax'])),OCR_DEFER_VISION_SEAL=str(int(cfg['defer_vision_seal'])),OCR_DEFER_PREFILL_SEAL=str(int(cfg['defer_prefill_seal'])),OCR_CACHE_VISION_WORKSPACE='1',OCR_LARGE_VISION_PACK_REUSE='1',OCR_TIMEOUT='900')
'''+s[b:]
s=s.replace('run_engine56_budget_policies_verify.py','run_engine56_budget_policies.py')
a=s.index("    prefix=record['selected_profiles'][model]['settings'][2]");b=s.index("    assert {x['image_index']",a)
s=s[:a]+'''    cfg=record['selected_profiles'][model]['settings']
    assert sample['wide_gate_up_calls']>0 and sample['full64_gate_up_calls']==0
    if cfg['prefill_items']>1:assert any(b['items']==cfg['prefill_items']for b in sample['prefill_batches'])
    assert sample['gpu_greedy_stream_steps']==sample['gpu_greedy_stream_two_frame_steps']==sample['stream_forward_splits']==0
    assert sample['vision_workspace_reuses']>0 and sample['vision_workspace_bytes']>0 and sample['batch_argmax_calls']>0
'''+s[b:]
a=s.index('for model in models:\n    source_audit=');b=s.index('\nsave()\nfor model in models:',a)
s=s[:a]+'''for model in models:
    source_audit=out/'engine56_workspace_profiles_verified_audit.json'
    d=json.loads(source_audit.read_text());assert d['status']=='pass'
    best=max((x for x in d['candidates']if x['eligible']),key=lambda x:x['pages_per_second'])
    p=out/best['report'];assert sha(p)==best['report_sha256']
    cfg=best.get('settings')
    if cfg is None:
        cfg=dict(concurrency=48,vision_items=1 if best['profile']=='prefill3_workspace'else4,prefill_items=3 if best['profile']=='prefill3_workspace'else1,vision_frame_blocks=2 if best['profile']=='prefill3_workspace'else1,batch_argmax=True,defer_vision_seal=best['profile']!='prefill3_workspace',defer_prefill_seal=False,cache_vision_workspace=True,large_vision_pack_reuse=True)
    record['selected_profiles'][model]=dict(settings=cfg,selection='Highest valid R64 qualification profile, fixed before the fresh R128 runs in both orders; over-budget profiles excluded.',source_audit_sha256=sha(source_audit),report=best['report'],report_sha256=sha(p),qualification_pages_per_second=best['pages_per_second'])
'''.replace('else4','else 4').replace('else1','else 1')+s[b:]
compile(s,'paired29','exec');(v/'run_engine56_paired29.py').write_text(s)
ns={};a=(v/'archive_engine10_evidence.py').read_text();exec(a[:a.index("archive('qualification'")],ns);ns['archive']('drivers',[Path(__file__),v/'run_engine56_paired29.py'],'drivers_manifest.json')
print('paired29 prepared; fixed selection from completed qualification audit')
