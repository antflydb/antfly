from pathlib import Path
import subprocess,os,json,hashlib,re
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
base=json.loads((v/'engine55-freeze.json').read_text());assert all(sha(p)==h for p,h in base.items())
proposal=v/'engine56-proposal';paths=[p for p in proposal.rglob('*')if p.is_file()];(v/'engine56-proposal-final.json').write_text(json.dumps({str(p.relative_to(proposal)):sha(p)for p in paths},indent=2)+'\n')
# Every MSL source function is unchanged; this is storage reuse and scheduling.
def shader_blocks(s):
 out={}
 for m in re.finditer(r'^static NSString \*(\w+)\(void\) \{',s,re.M):
  end=s.index('\n}\n',m.start())+3;out[m[1]]=hashlib.sha256(s[m.start():end].encode()).hexdigest()
 return out
c=Path('zig/pkg/inference/src/backends/metal_kernels.m');candidate=proposal/c
old=shader_blocks(c.read_text());new=shader_blocks(candidate.read_text());assert old==new and old
(o/'engine56_unchanged_shader_source_audit.json').write_text(json.dumps(dict(status='pass',source_functions=old),indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
renamed=[]
for p in paths:
 target=v/('engine56_final_'+p.name);target.write_bytes(p.read_bytes());renamed.append(target)
ns['archive']('drivers',renamed+list(v.glob('*engine56*.py'))+list(v.glob('engine56*.inc'))+[v/'engine56_product_checks.m',v/'engine56-proposal-final.json'],'drivers_manifest.json')
cmd=['clang','-O3','-fobjc-arc','-Izig/pkg/inference/src/backends',str(v/'engine56_product_checks.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(v/'engine56_proposal_conformance')]
log=Path('/private/tmp/ocr-engine56-proposal-build.txt')
with log.open('w')as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
assert r.returncode==0,r.returncode
inputs=[v/'engine56_product_checks.m',candidate,Path(__file__)]+[Path('zig/pkg/inference/src/backends')/x for x in ['metal_buffer_observation.h','metal_mtp_head.h','metal_mtp_head_impl.h']]
b=v/'engine56_proposal_conformance';manifest=dict(binary=str(b),binary_sha256=sha(b),input_sha256={str(p):sha(p)for p in inputs})
(o/'engine56_proposal_c_build_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');ns['archive']('qualification',[log],'logs_manifest.json');print('compiled proposal; unchanged shader source verified')
