from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=(v/'engine86_steel.metal').read_text();assert 'const thread GEMMParams* params [[buffer(3)]]'in s;s=s.replace('const thread GEMMParams* params [[buffer(3)]]','const thread GEMMParams* params').replace('#define METAL_FUNC inline\n','')
p=v/'engine86_steel_verify2.metal';assert not p.exists();p.write_text(s)
d=json.loads((v/'engine86_steel_probe_preparation.json').read_text());old=str(v/'engine86_steel.metal');assert d['input_sha256'].pop(old)==sha(v/'engine86_steel.metal');d['input_sha256'][str(p)]=sha(p);(v/'engine86_steel_probe_verify2_preparation.json').write_text(json.dumps(d,indent=2)+'\n')
s=(v/'run_engine86_steel_probe.py').read_text().replace('engine86_steel_probe_preparation.json','engine86_steel_probe_verify2_preparation.json').replace('engine86_steel_probe_audit.json','engine86_steel_probe_verify2_audit.json').replace('ocr-engine86-steel-stdout','ocr-engine86-steel-verify2-stdout').replace('ocr-engine86-steel-stderr','ocr-engine86-steel-verify2-stderr').replace("str(v/'engine86_steel.metal')","str(v/'engine86_steel_verify2.metal')")
a=s.index(" b=v/'engine86_real_ffn_probe';");b=s.index(" d['binary_sha256']=sha(b);save()",a)
s=s[:a]+" b=v/'engine86_real_ffn_probe';assert b.exists();old=json.loads((o/'engine86_steel_probe_audit.json').read_text());assert sha(b)==old['binary_sha256'];d['reused_exact_c_binary_from_initial_shader_failure']=True\n"+s[b:]
p=v/'run_engine86_steel_probe_verify2.py';assert not p.exists();p.write_text(s)
s=(v/'run_engine85_primary_queue_verify4.py').read_text().replace("'run_engine86_steel_probe.py'","'run_engine86_steel_probe_verify2.py'");p=v/'run_engine85_primary_queue_verify5.py';assert not p.exists();p.write_text(s)
