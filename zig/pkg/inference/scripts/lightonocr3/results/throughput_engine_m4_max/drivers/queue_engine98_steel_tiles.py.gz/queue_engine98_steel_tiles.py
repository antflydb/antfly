from pathlib import Path
import psutil,os,signal,json,subprocess,sys,datetime
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';a=o/'engine98_probe_queue_audit.json';assert not a.exists();d=dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='checking_own_waiter')
waiters=[]
for p in psutil.process_iter(['pid','cmdline']):
 try:
  c=p.info['cmdline']or[]
  if len(c)==2 and Path(p.cwd(),c[1]).resolve()==v/'run_engine96_mixed_screen76.py':waiters.append(p)
 except(psutil.NoSuchProcess,psutil.AccessDenied):pass
assert len(waiters)==1
p=waiters[0];d['waiter_pid']=p.pid
if p.children(recursive=True):
 d['status']='declined_model_child_active';a.write_text(json.dumps(d,indent=2)+'\n');print(d);sys.exit(0)
os.kill(p.pid,signal.SIGSTOP)
try:
 children=p.children(recursive=True);d['children_after_stop']=[c.pid for c in children]
 if children:
  d['status']='declined_child_raced_stop';a.write_text(json.dumps(d,indent=2)+'\n')
 else:
  d['status']='own_waiter_stopped_child_free';a.write_text(json.dumps(d,indent=2)+'\n');print('PAUSED own child-free waiter',p.pid,flush=True)
  with Path('/private/tmp/ocr-engine98-steel-parent.txt').open('w')as log:res=subprocess.run([sys.executable,str(v/'run_engine98_steel_tiles.py')],stdout=log,stderr=subprocess.STDOUT)
  d.update(status='probe_finished',probe_exit_code=res.returncode);a.write_text(json.dumps(d,indent=2)+'\n');print('PROBE98 DONE',res.returncode,flush=True)
finally:
 os.kill(p.pid,signal.SIGCONT);d['own_waiter_resumed']=True;a.write_text(json.dumps(d,indent=2)+'\n');print('RESUMED own waiter',p.pid,flush=True)
