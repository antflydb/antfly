from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal')
p=Path('zig/pkg/inference/src/server/server.zig')
s=p.read_text()
old='const control = InferenceExecutionControl{ .ptr = &group, .check_fn = executor_microbatch.ExecutionControl.check };'
assert s.count(old)==3
s=s.replace(old,'const control = lightOnMicrobatchExecutionControl(&group);')
marker='    fn executeLightOnPrefillBatch(raw: *anyopaque, items: []const executor_microbatch.ExecuteItem) void {'
assert s.count(marker)==1
s=s.replace(marker,'''    /// The broker executes synchronously on its leader's Io task. Retain that
    /// runtime when adapting group cancellation so contended GPU gates park on
    /// their event rather than repeatedly yielding for the whole GPU frame.
    fn lightOnMicrobatchExecutionControl(group: *executor_microbatch.ExecutionControl) InferenceExecutionControl {
        std.debug.assert(group.items.len > 0);
        return .{
            .io = group.items[0].control.io,
            .ptr = group,
            .check_fn = executor_microbatch.ExecutionControl.check,
        };
    }

'''+marker)
s+='''
test "LightOnOCR3 microbatch GPU gate parks and preserves group cancellation" {
    const Worker = struct {
        fn run(lane: *execution_control_mod.ExecutionLane, group: *executor_microbatch.ExecutionControl) !void {
            const lease = try lane.acquireWithPriority(Node.lightOnMicrobatchExecutionControl(group), true);
            defer lease.release();
        }
        fn waitUntilParked(lane: *execution_control_mod.ExecutionLane) !void {
            const deadline = platform.time.monotonicNs() + 5 * std.time.ns_per_s;
            while (true) {
                platform.sync.lockYielding(&lane.mutex);
                const parked = lane.event_waits > 0;
                lane.mutex.unlock();
                if (parked) return;
                if (platform.time.monotonicNs() >= deadline) return error.Timeout;
                try std.testing.io.sleep(.fromMilliseconds(1), .awake);
            }
        }
    };
    var value: usize = 0;
    var slot = executor_microbatch.ResultSlot{ .output = &value };
    var first_cancelled = std.atomic.Value(bool).init(false);
    var second_cancelled = std.atomic.Value(bool).init(false);
    const items = [_]executor_microbatch.ExecuteItem{
        .{ .allocator = std.testing.allocator, .identity = .{}, .payload = &value, .slot = &slot,
            .control = .{ .io = std.testing.io, .cancel_requested = &first_cancelled } },
        .{ .allocator = std.testing.allocator, .identity = .{}, .payload = &value, .slot = &slot,
            .control = .{ .io = std.testing.io, .cancel_requested = &second_cancelled } },
    };
    var group = executor_microbatch.ExecutionControl{ .items = &items };
    var lane = execution_control_mod.ExecutionLane{};
    const owner = try lane.acquire(.{ .io = std.testing.io });
    var released = false;
    defer if (!released) owner.release();
    var waiting = try std.testing.io.concurrent(Worker.run, .{ &lane, &group });
    defer _ = waiting.cancel(std.testing.io) catch {};
    try Worker.waitUntilParked(&lane);
    first_cancelled.store(true, .release);
    try Node.lightOnMicrobatchExecutionControl(&group).check();
    // A live peer retains the group, then owner release must wake it directly.
    owner.release();
    released = true;
    try waiting.await(std.testing.io);
    try std.testing.expect(lane.head == null and lane.tail == null and !lane.owned);

    // A fully cancelled group leaves the event queue without acquiring GPU
    // ownership. Its borrowed ticket storage is retained until await returns.
    lane.event_waits = 0;
    const second_owner = try lane.acquire(.{ .io = std.testing.io });
    defer second_owner.release();
    var cancelled = try std.testing.io.concurrent(Worker.run, .{ &lane, &group });
    defer _ = cancelled.cancel(std.testing.io) catch {};
    try Worker.waitUntilParked(&lane);
    second_cancelled.store(true, .release);
    try std.testing.expectError(error.Canceled, cancelled.await(std.testing.io));
    try std.testing.expect(lane.head == null and lane.tail == null and lane.owned);
}
'''
dest=v/'engine41_source_snapshot'/p
dest.parent.mkdir(parents=True,exist_ok=True)
dest.write_text(s)
(v/'engine41-proposal-base.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n')
print('Prepared ignored proposal only; actual frozen engine40 source unchanged.')
