from pathlib import Path
import ast,datetime,hashlib,json,os,shutil,subprocess,sys
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
audit=out/'engine71_precision_screen62_audit.json';record=json.loads(audit.read_text());backup=out/'engine71_precision_screen62_attempt1_audit.json';assert not backup.exists();shutil.copyfile(audit,backup)
old=v/'run_engine71_budget_policies.py';new=v/'run_engine71_budget_precision62_verify2.py';assert not new.exists();s=old.read_text();needle="model=='4b' and full64_gate_up and max(sample['packed_core_rows_observed'],default=0)==64";assert s.count(needle)==1;s=s.replace(needle,"model=='4b' and full64_gate_up and not bf16 and max(sample['packed_core_rows_observed'],default=0)==64");new.write_text(s)
record['failed_verification_attempts']=[record['cases'].pop()];record.update(continuation_driver_sha256=sha(Path(__file__)),original_failed_audit_sha256=sha(backup),verification_fix='Full64 F32 fused gate/up must be zero when BF16 inputs are selected. No runtime change, no parity/cap relaxation. All original stdout and pre-verification report retained.',verification_driver_sha256=sha(new))
primary=json.loads((out/'paired59_4b_comparison_audit.json').read_text());profiles=primary['profiles'];oracle=Path(primary['comparisons'][-1]['reference_report']).parent.name.removeprefix('vllm_4b')
source=(v/'run_engine71_api_paired59.py').read_text();node=next(x for x in ast.parse(source).body if isinstance(x,ast.FunctionDef)and x.name=='native');base=ast.get_source_segment(source,node)
def save():audit.write_text(json.dumps(record,indent=2)+'\n')
save()
for leg,bf16 in [(1,True),(2,True),(3,False)]:
 fn=base.replace('paired59','precision_screen62_'+('bf16'if bf16 else'f32')).replace("OCR_BF16='0'",f"OCR_BF16='{int(bf16)}'").replace('run_engine71_budget_policies.py','run_engine71_budget_precision62_verify2.py')
 if leg==1:
  p=out/'engine71_4b_precision_screen62_bf16_wide_r1_c64_p1_v1_vf3_r128/report.json';b=p.with_name('report_before_verification_fix.json');assert not b.exists();shutil.copyfile(p,b)
  fn=fn.replace('    assert not dest.exists()','    assert dest.exists()')
  os.environ.update(OCR_VERIFY_SAVED_RUN='1',OCR_ORIGINAL_EXECUTION_DRIVER_SHA=sha(old))
 else:
  os.environ.pop('OCR_VERIFY_SAVED_RUN',None);os.environ.pop('OCR_ORIGINAL_EXECUTION_DRIVER_SHA',None)
 exec(compile(fn,'precision62_verify2_'+str(leg),'exec'),globals());print('START PRECISION VERIFY2',leg,bf16,flush=True)
 d,p=native('wide',leg,oracle);s=d['results'][0]['policy_rounds'][0]
 record['cases'].append(dict(leg=leg,bf16_decode_inputs=bf16,status='pass',pages_per_second=s['pages_per_second'],report=str(p.relative_to(out)),report_sha256=sha(p),existing_run_reverified=(leg==1)))
 save();print('DONE PRECISION VERIFY2',record['cases'][-1],flush=True)
record['status']='pass';save();print('ENGINE71 PRECISION62 DONE',flush=True)
