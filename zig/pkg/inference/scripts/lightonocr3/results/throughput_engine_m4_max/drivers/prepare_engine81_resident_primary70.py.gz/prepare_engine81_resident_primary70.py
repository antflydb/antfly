from pathlib import Path
import ast
v=Path('.venv-lighton-vllm-metal');s=(v/'run_engine80_api_paired66.py').read_text();tree=ast.parse(s)
funcs={n.name:ast.get_source_segment(s,n)for n in tree.body if isinstance(n,ast.FunctionDef)}
ref=funcs['reference'].replace('engine80','engine81').replace('paired66','paired70').replace('_reference66','_reference70')
nat=funcs['native'].replace('engine80','engine81').replace('paired66','paired70_resident').replace("OCR_POLICIES='engineepoch'","OCR_POLICIES='engineepoch,engineepoch,engineepoch,engineepoch'")
nat=nat.replace("    env['OCR_PREFILL_FUSED_FFN']='1'","    env['OCR_PREFILL_FUSED_FFN']='1'\n    env['OCR_PREFILL_FFN_ROUNDS']='off,on,on,off'")
a=nat.index("    s = result['policy_rounds'][0]");b=nat.index("    print('DONE NATIVE'",a)
checks=nat[a:b].splitlines()[1:];checks=[x.replace("assert s['prefill_fused_ffn_calls'] > 0","assert (s['prefill_fused_ffn_calls'] > 0)==s['prefill_fused_ffn_enabled']") for x in checks]
nat=nat[:a]+"    samples=result['policy_rounds']\n    assert len(samples)==4 and [s['prefill_fused_ffn_enabled']for s in samples]==[False,True,True,False]\n    for s in samples:\n"+'\n'.join('    '+x for x in checks)+'\n'+nat[b:]
head='''from pathlib import Path
import datetime,hashlib,json,os,psutil,re,statistics,subprocess,sys,time
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while True:
 p=Path('/private/tmp/ocr-engine81-finalqualification-parent.txt');s=p.read_text()if p.exists()else''
 if 'Traceback'in s:raise RuntimeError(s[-3000:])
 if 'ENGINE81 FINAL QUALIFICATION DONE'in s:break
 time.sleep(5)
for p,h in json.loads((v/'engine81-freeze.json').read_text()).items():assert sha(root/p)==h,p
profiles=json.loads((out/'paired59_4b_comparison_audit.json').read_text())['profiles']
audit=out/'paired70_4b_comparison_audit.json';assert not audit.exists()
record=dict(status='running',scope='Strong independent vLLM API C16/C32/C64 model/cache admissions before and after one resident native 4B model with R128 OFF/ON/ON/OFF FFN policy rounds. Native ON serial warm references compile the optional PSOs before timing and must equal all full cross-runtime fixture strings. All timed OFF and ON outputs must equal these same serial references. Compare first ON round to strongest opening API control and second ON to strongest closing API control. Original caps/reserve/F32 decode/BF16 prefill; no own compilation or sampling during measurements. Temporal comparisons bracket the complete four-round native block, not individual adjacent native rounds. Different API/native concurrency/cache capacity and HTTP/native boundary retained explicitly.',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),profiles=profiles,comparisons=[],reference_candidates=[])
def save():audit.write_text(json.dumps(record,indent=2)+'\\n')
def wait_model_headroom():
 while psutil.virtual_memory().available<11348275670+6*1024**3+512*1024**2:
  print('WAIT original 4B admission',psutil.virtual_memory().available,flush=True);time.sleep(30)
'''
tail='''
save()
def reference_sweep(index,concurrencies):
 refs=[reference(index,c)for c in concurrencies]
 capacities=[]
 for _,_,rp in refs:
  values=[int(n)for n in re.findall(r'Hybrid shared cache: (\\d+) blocks',(rp.parent/'server.txt').read_text())]
  assert values,rp;capacities.extend(values)
 if min(capacities)>=320:
  full=reference(index,64,320)
  if full is not None:refs.append(full)
 else:
  record.setdefault('full_capacity_candidates_skipped',[]).append(dict(round=index,requested_blocks=320,observed_automatic_blocks=capacities,reason='Skip override: outside at least one fresh automatic admission.'));save()
 for label,d,p in refs:
  record['reference_candidates'].append(dict(round=index,blocks=d['kv_cache_block_override'],concurrency=d['results'][0]['concurrency'],pages_per_second=d['results'][0]['pages_per_second'],report=str(p.relative_to(out)),report_sha256=sha(p)))
 save();return max(refs,key=lambda x:x[1]['results'][0]['pages_per_second'])
r0=reference_sweep(0,[16,32,64])
nd,np=native('wide',0,r0[0]);samples=nd['results'][0]['policy_rounds']
record['native_control']=dict(report=str(np.relative_to(out)),report_sha256=sha(np),rounds=[{k:s.get(k)for k in ['round','prefill_fused_ffn_enabled','prefill_fused_ffn_calls','completed','pages_per_second','process_cpu_ms']}for s in samples],packed_to_ordinary_mean_ratio=statistics.mean(s['pages_per_second']for s in samples if s['prefill_fused_ffn_enabled'])/statistics.mean(s['pages_per_second']for s in samples if not s['prefill_fused_ffn_enabled']));save()
r1=reference_sweep(1,[64,32,16])
for index,(sample,ref)in enumerate([(samples[1],r0),(samples[2],r1)]):
 _,rd,rp=ref
 assert {x['image_index']:x['text']for x in nd['results'][0]['references']}=={x['image_index']:x['text']for x in rd['references']}
 a=sample['pages_per_second'];b=rd['results'][0]['pages_per_second']
 record['comparisons'].append(dict(round=index,native_policy_round=sample['round'],native_pages_per_second=a,reference_pages_per_second=b,native_to_vllm_ratio=a/b,reference_concurrency=rd['results'][0]['concurrency'],reference_blocks=rd['kv_cache_block_override'],all_128_native_pages_equal_serial=True,full_cross_runtime_fixture_string_identity=True,primary_throughput_eligible=True,native_report=str(np.relative_to(out)),native_report_sha256=sha(np),reference_report=str(rp.relative_to(out)),reference_report_sha256=sha(rp)));save()
ratios=[x['native_to_vllm_ratio']for x in record['comparisons']];record['status']='repeated_win'if min(ratios)>1 else'native_behind';save();print('ENGINE81 PRIMARY70 DONE',record['status'],ratios,flush=True)
'''
(v/'run_engine81_resident_primary70.py').write_text(head+ref+'\n\n'+nat+tail)
