from pathlib import Path
import datetime,hashlib,json,os,psutil,re,statistics,subprocess,sys,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prep=json.loads((v/'engine103_wide_core_preparation.json').read_text());assert all(sha(r/p)==h for p,h in prep['files_sha256'].items());assert sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')==prep['production_c_sha256'];a=o/'engine103_wide_core_audit.json';assert not a.exists();binary=v/'engine103_wide_core_probe';d=dict(status='running_private',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope=prep['scope'],driver_sha256=sha(Path(__file__)),binary_sha256=sha(binary),preparation_sha256=sha(v/'engine103_wide_core_preparation.json'),checks=[])
def save():a.write_text(json.dumps(d,indent=2)+'\n')
save()
try:
 for cap,pages in [(64,64),(32,64),(48,64),(24,64),(64,17),(64,29),(64,31),(64,63)]:
  while psutil.virtual_memory().available<8*1024**3:print('WAIT103 reserve',flush=True);time.sleep(15)
  row=dict(cap=cap,pages=pages,status='running',available_bytes=psutil.virtual_memory().available,working_estimate_bytes=2*1024**3,os_reserve_bytes=6*1024**3);d['checks'].append(row);save();so=Path(f'/private/tmp/ocr-engine103-wide-cap{cap}-pages{pages}-stdout.txt');se=Path(f'/private/tmp/ocr-engine103-wide-cap{cap}-pages{pages}-stderr.txt');assert not so.exists()and not se.exists();print('START103',cap,pages,flush=True)
  with so.open('w')as f,se.open('w')as e:p=subprocess.run([str(binary),str(cap),str(pages)],stdout=f,stderr=e,env=dict(os.environ,ANTFLY_LIGHTONOCR3_THROUGHPUT='0'),timeout=600)
  row.update(exit_code=p.returncode,stdout_sha256=sha(so),stderr_sha256=sha(se));save();assert p.returncode==0,(cap,pages,p.returncode)
  assert 'WIDE103 FULL STATE/OUTPUT BITS/CANARIES PASS'in se.read_text()
  records=[json.loads(x)for x in so.read_text().splitlines()if x.startswith('{')];wall=[dict(trial=int(t),variant=int(var),wall_us=float(w))for t,var,w in re.findall(r'WALL103 trial=(\d+) variant=(\d+) wall_us=([\d.]+)',so.read_text())];assert len(records)==len(wall)==64
  row['timings']={str(var):{k:statistics.median(x[k]for x in (wall if k=='wall_us'else records)if x['variant']==var and x['trial']>=4)for k in ['wall_us','gpu_us','encode_us']}for var in [0,1]};row['ratios']={k:row['timings']['1'][k]/row['timings']['0'][k]for k in ['wall_us','gpu_us','encode_us']};row['status']='prototype_pass';save();print('PASS103',cap,pages,row['ratios'],flush=True)
 d['status']='private_screen_complete';save()
except BaseException as e:d.update(status='failed_private_screen',error=repr(e));save();raise
