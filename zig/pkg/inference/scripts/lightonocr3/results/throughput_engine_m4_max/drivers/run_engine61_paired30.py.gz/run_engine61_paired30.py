from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path.cwd()
v = root / '.venv-lighton-vllm-metal'
scripts = root / 'zig/pkg/inference/scripts/lightonocr3'
out = scripts / 'results/throughput_engine_m4_max'
source = out / 'engine61_profiles_audit.json'
while not source.exists() or json.loads(source.read_text())['status'] != 'pass':
    time.sleep(5)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
candidates = json.loads(source.read_text())['candidates']
batched = max((x for x in candidates if x['eligible'] and x['settings'] != [64, 1, 1, 2, 0, 0, 0]), key=lambda x: x['pages_per_second'], default=None)
c64 = next(x for x in candidates if x['settings'] == [64, 1, 1, 2, 0, 0, 0])
assert c64['eligible']
profiles = {'c64': c64}
if batched is not None: profiles['candidate'] = batched
for p in profiles.values():
    assert sha(out / p['report']) == p['report_sha256']
for p, h in json.loads((v / 'engine61-freeze.json').read_text()).items():
    assert sha(root / p) == h, p

record = dict(status='running', created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              scope='Original 4B checkpoint and three fixtures; 128 requests; max_tokens256. Fixed C64/P1 profile retained from prior-runtime qualification, plus the highest valid engine61 R64 alternative if available; chosen before the independent R128 comparison. Each profile keeps its qualifying prefill wait. C64 retained independently because a one-window screen cannot measure its refill benefit. Fresh vLLM C64 automatic-cache controls before and after the symmetric native sequence. Prefix and processor caches disabled; media UUID unique. No own compilation or sampling during timings; shared machine otherwise uncontrolled.',
              profiles=profiles, comparisons=[], source_audit_sha256=sha(source))
audit = out / 'paired30_4b_comparison_audit.json'
assert not audit.exists()
def save():
    audit.write_text(json.dumps(record, indent=2) + '\n')

def reference(index):
    label = f'_primary_reference30_r{index}_auto_c64_r128'
    dest = out / ('vllm_4b' + label)
    assert not dest.exists()
    images = [root / 'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png', scripts / 'corpus/receipt.png', scripts / 'corpus/shipping.png']
    cmd = [sys.executable, str(scripts / 'benchmark_vllm_metal.py'), '--python', sys.executable,
           '--model-dir', str(v / 'ocr-models/lighton4b'), '--images', *map(str, images),
           '--concurrency', '64', '--requests', '128', '--max-tokens', '256', '--startup-timeout', '600', '--output-dir', str(dest)]
    print('START VLLM', index, flush=True)
    with Path(f'/private/tmp/ocr-engine61-vllm-paired30-r{index}.txt').open('w') as log:
        subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=True)
    p = dest / 'report.json'
    d = json.loads(p.read_text())
    assert d['status'] == 'ok' and d['kv_cache_block_override'] is None and d['results'][0]['serial_reference_parity']
    print('DONE VLLM', index, d['results'][0]['pages_per_second'], flush=True)
    return label, d, p

def native(key, index, oracle):
    c, pref, vis, vf, sv, sp, q = profiles[key]['settings']
    label = f'paired30_{key}_r{index}_c{c}_p{pref}_v{vis}_vf{vf}_r128'
    dest = out / ('engine61_4b_' + label)
    assert not dest.exists()
    env = os.environ.copy()
    env.update(OCR_REFERENCE_LABEL=oracle, OCR_PHYSICAL32='0', OCR_PHYSICAL64='1', OCR_CONCURRENCY=str(c),
               OCR_REQUESTS='128', OCR_WIDE='1', OCR_KV_GIB='4', OCR_BACKEND_GIB='17', OCR_SCRATCH_GIB='10',
               OCR_CPU_PREPROCESS='1', OCR_PREFILL_DECODE_STREAK='0', OCR_POLICIES='engineepoch', OCR_SHARED_CORE='1',
               OCR_BF16_PREFILL='1', OCR_BF16='0', OCR_DISABLE_64_ROW_TILE='0', OCR_DISABLE_WIDE_GATE_UP='0',
               OCR_WIDE64_GATE_UP='1', OCR_FULL64_GATE_UP='1', OCR_GPU_GREEDY_STREAM='0', OCR_STREAM_CHUNK_LAYERS='0',
               OCR_VISION_BATCH=str(int(vis > 1)), OCR_VISION_BATCH_ITEMS=str(vis), OCR_VISION_WAIT_US='2000',
               OCR_PREFILL_BATCH=str(int(pref > 1)), OCR_PREFILL_BATCH_ITEMS=str(pref), OCR_PREFILL_WAIT_US=str(profiles[key].get('prefill_wait_us', 100000)),
               OCR_VISION_FRAME_BLOCKS=str(vf), OCR_SINGLE_FRAME='1', OCR_STREAM_FIRST='0', OCR_LOGICAL64='1',
               OCR_SHARED_DECODER_SCRATCH='1', OCR_DEVICE_RECURRENT_STATE='1', OCR_ENCODER_SCOPES='1', OCR_ADMISSION_UNITS='512',
               OCR_BATCH_ARGMAX='1', OCR_DEFER_VISION_SEAL=str(sv), OCR_DEFER_PREFILL_SEAL=str(sp),
               OCR_CACHE_VISION_WORKSPACE='1', OCR_LARGE_VISION_PACK_REUSE=str(int(vis > 1)),
               ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY=str(q), OCR_TIMEOUT='900')
    print('START NATIVE', key, index, profiles[key]['settings'], flush=True)
    with Path(f'/private/tmp/ocr-engine61-native-paired30-{key}-r{index}-driver.txt').open('w') as log:
        subprocess.run([sys.executable, str(v / 'run_engine61_budget_policies.py'), '4b:' + label], env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    p = dest / 'report.json'
    d = json.loads(p.read_text())
    result = d['results'][0]
    s = result['policy_rounds'][0]
    assert result['status'] == 'ok' and result['serial_reference_parity'] and result['cross_runtime_content_parity']
    assert s['completed'] == 128 and not s['admission_pressures'] and not d['own_cpu_compile_overlap']
    assert s['host_recurrent_bytes_total'] == s['single_frame_topology_mismatches'] == s['gpu_greedy_stream_topology_mismatches'] == 0
    assert s['vision_workspace_reuses'] > 0 and s['batch_argmax_calls'] > 0
    assert d['queued_phase_priority'] == bool(q)
    print('DONE NATIVE', key, index, s['pages_per_second'], flush=True)
    return d, p

def compare(key, index, n, r):
    nd, np = n
    _, rd, rp = r
    result = nd['results'][0]
    assert {x['image_index']: x['text'] for x in result['references']} == {x['image_index']: x['text'] for x in rd['references']}
    a = result['policy_rounds'][0]['pages_per_second']
    b = rd['results'][0]['pages_per_second']
    row = dict(profile=key, round=index, native_pages_per_second=a, reference_pages_per_second=b,
               native_to_vllm_ratio=a / b, full_fixture_string_identity=True, all_128_native_pages_equal_serial_reference=True,
               primary_throughput_eligible=True, native_report=str(np.relative_to(out)), native_report_sha256=sha(np),
               reference_report=str(rp.relative_to(out)), reference_report_sha256=sha(rp))
    record['comparisons'].append(row)
    save()
    print('COMPARISON', json.dumps(row), flush=True)

save()
r0 = reference(0)
for key in profiles:
    compare(key, 0, native(key, 0, r0[0]), r0)
reverse = {key: native(key, 1, r0[0]) for key in reversed(profiles)}
r1 = reference(1)
for key in profiles:
    compare(key, 1, reverse[key], r1)
record['profile_outcomes'] = {}
for key in profiles:
    ratios = [x['native_to_vllm_ratio'] for x in record['comparisons'] if x['profile'] == key]
    assert len(ratios) == 2
    record['profile_outcomes'][key] = 'native_behind' if min(ratios) <= 1 else 'clear_repeated_win' if min(ratios) >= 1.05 else 'small_repeated_lead'
record['status'] = 'native_behind' if all(x == 'native_behind' for x in record['profile_outcomes'].values()) else 'repeated_win'
save()
print('FINAL', record['status'], record['profile_outcomes'], flush=True)
