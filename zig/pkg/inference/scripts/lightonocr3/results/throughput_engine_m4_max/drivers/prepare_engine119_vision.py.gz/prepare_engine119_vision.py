from pathlib import Path
import json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal'
plans=[(16,128,4,16,0),(32,128,8,16,0),(32,64,4,16,0),(64,32,4,16,0),(32,128,4,32,0),(32,64,8,16,0),(64,64,8,16,0),(64,64,4,32,0),(64,32,4,32,0),(64,32,4,16,1),(32,64,8,16,1)]
def shader(qb,kb,sgs,m,stage):
 pvtiles=(qb//m)*4;assert pvtiles%sgs==0;npv=pvtiles//sgs;qktiles=(qb//m)*(kb//32);assert qktiles<=sgs
 ident=f'q{qb}k{kb}s{sgs}m{m}t{stage}'
 text=f'''#include <metal_stdlib>
#include <metal_tensor>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;using namespace mpp::tensor_ops;
struct VisionParams{{uint batch,seq_len,num_heads,head_dim,bias_mode,has_mask,layout,reserved1;}};
kernel void vision119(device half*q[[buffer(0)]],device half*k[[buffer(1)]],device half*v[[buffer(2)]],device const float*bias[[buffer(3)]],device const float*mask[[buffer(4)]],device float*output[[buffer(5)]],constant VisionParams&p[[buffer(6)]],uint tid[[thread_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]],uint group[[threadgroup_position_in_grid]]){{
 constexpr uint QB={qb},KB={kb},SG={sgs},M={m},QKT={qktiles},NPV={npv};
 const uint tiles=(p.seq_len+QB-1)/QB,qtile=group%tiles,h=(group/tiles)%p.num_heads,b=group/(tiles*p.num_heads),q0=qtile*QB,base=(b*p.num_heads+h)*p.reserved1*64;
 threadgroup float scores[QB*KB],rowmax[QB],rowsum[QB],correction[QB];threadgroup half probs[QB*KB];
 if(tid<QB){{rowmax[tid]=-INFINITY;rowsum[tid]=0;}}threadgroup_barrier(mem_flags::mem_threadgroup);
 tensor<threadgroup half,dextents<int,2>,tensor_inline> P0(probs,dextents<int,2>(KB,M),array<int,2>{{1,KB}});
 @VDECL@
 constexpr auto qkd=matmul2d_descriptor(M,32,64,false,true,false);matmul2d<qkd,execution_simdgroups<1>> qkop;
 constexpr auto pvd=matmul2d_descriptor(M,16,KB,false,false,false,matmul2d_descriptor::mode::multiply_accumulate);matmul2d<pvd,execution_simdgroups<1>> pvop;
 using Acc=decltype(pvop.get_destination_cooperative_tensor<decltype(P0),decltype(V0),float>());Acc out[NPV]={{ @ACCINIT@ }};
 for(uint a=0;a<NPV;a++)for(ushort z=0;z<out[a].get_capacity();z++)out[a][z]=0;
 @STORAGE@
 for(uint start=0;start<p.seq_len;start+=KB){{
  @STAGE@
  if(sg<QKT){{uint qr=(sg/(KB/32))*M,kc=(sg%(KB/32))*32;
   tensor<device half,dextents<int,2>,tensor_inline> Q(q+base+(q0+qr)*64,dextents<int,2>(64,M),array<int,2>{{1,64}});
   @KDECL@
   tensor<threadgroup float,dextents<int,2>,tensor_inline> S(scores+qr*KB+kc,dextents<int,2>(32,M),array<int,2>{{1,KB}});
   auto dot=qkop.get_destination_cooperative_tensor<decltype(Q),decltype(K),float>();qkop.run(Q,K,dot);dot.store(S);
  }}
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint row=sg;row<QB;row+=SG){{float xs[KB/32],es[KB/32],mx=-INFINITY;
   for(uint j=0;j<KB/32;j++){{xs[j]=(q0+row<p.seq_len&&start+lane+j*32<p.seq_len)?scores[row*KB+lane+j*32]:-INFINITY;if(!isfinite(xs[j]))xs[j]=-INFINITY;mx=max(mx,xs[j]);}}
   mx=simd_max(mx);float nm=max(rowmax[row],mx),c=isfinite(nm)&&isfinite(rowmax[row])?exp(rowmax[row]-nm):0,sum=0;
   for(uint j=0;j<KB/32;j++){{es[j]=isfinite(xs[j])?exp(xs[j]-nm):0;probs[row*KB+lane+j*32]=half(es[j]);sum+=es[j];}}
   sum=simd_sum(sum);if(lane==0){{rowmax[row]=nm;rowsum[row]=rowsum[row]*c+sum;correction[row]=c;}}
  }}
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint a=0;a<NPV;a++){{uint tile=sg+a*SG,qr=(tile/4)*M,dc=(tile%4)*16;
   for(ushort z=0;z<out[a].get_capacity();z++){{auto c=out[a].get_multidimensional_index(z);out[a][z]*=correction[qr+c[1]];}}
   tensor<threadgroup half,dextents<int,2>,tensor_inline> P(probs+qr*KB,dextents<int,2>(KB,M),array<int,2>{{1,KB}});
   @VSTEP@
   pvop.run(P,V,out[a]);
  }}
  @ENDSTAGE@
 }}
 for(uint a=0;a<NPV;a++){{uint tile=sg+a*SG,qr=(tile/4)*M,dc=(tile%4)*16;
  for(ushort z=0;z<out[a].get_capacity();z++){{auto c=out[a].get_multidimensional_index(z);uint row=qr+c[1],d=dc+c[0];if(q0+row<p.seq_len)output[((b*p.seq_len+q0+row)*p.num_heads+h)*64+d]=rowsum[row]>0?out[a][z]/rowsum[row]:0;}}
 }}
}}
'''
 text=text.replace('@ACCINIT@',','.join(['pvop.get_destination_cooperative_tensor<decltype(P0),decltype(V0),float>()']*npv))
 if stage:
  text=text.replace(' @STORAGE@\n','').replace(' if(tid<QB)', ' threadgroup half keys[KB*64],values[KB*64];\n if(tid<QB)')
  text=text.replace('@STORAGE@','threadgroup half keys[KB*64],values[KB*64];').replace('@STAGE@','for(uint z=tid;z<KB*64;z+=SG*32){keys[z]=k[base+start*64+z];values[z]=v[base+start*64+z];}threadgroup_barrier(mem_flags::mem_threadgroup);').replace('@KDECL@','tensor<threadgroup half,dextents<int,2>,tensor_inline> K(keys+kc*64,dextents<int,2>(64,32),array<int,2>{1,64});').replace('@VDECL@','tensor<threadgroup half,dextents<int,2>,tensor_inline> V0(values,dextents<int,2>(16,KB),array<int,2>{1,64});').replace('@VSTEP@','tensor<threadgroup half,dextents<int,2>,tensor_inline> V(values+dc,dextents<int,2>(16,KB),array<int,2>{1,64});').replace('@ENDSTAGE@','threadgroup_barrier(mem_flags::mem_threadgroup);')
 else:
  text=text.replace('@STORAGE@','').replace('@STAGE@','').replace('@ENDSTAGE@','').replace('@KDECL@','tensor<device half,dextents<int,2>,tensor_inline> K(k+base+(start+kc)*64,dextents<int,2>(64,32),array<int,2>{1,64});').replace('@VDECL@','tensor<device half,dextents<int,2>,tensor_inline> V0(v+base,dextents<int,2>(16,KB),array<int,2>{1,64});').replace('@VSTEP@','tensor<device half,dextents<int,2>,tensor_inline> V(v+base+start*64+dc,dextents<int,2>(16,KB),array<int,2>{1,64});')
 assert '@'not in text
 (v/f'engine119_{ident}.metal').write_text(text);return dict(id=ident,q=qb,k=kb,sg=sgs,m=m,staged=stage)
records=[shader(*p)for p in plans];(v/'engine119_plans.json').write_text(json.dumps(records,indent=2)+'\n')
s=(r/'zig/pkg/inference/src/backends/metal_kernels.m').read_text();needle='#import <Metal/Metal.h>';s=s.replace(needle,needle+'\nstatic unsigned engine119_query_tile=16,engine119_threads=128;\nstatic id<MTLComputePipelineState> engine119_candidate;')
needle='pipeline=runtime->lightonocr3_vision_mpp_pipeline;params.reserved1=';assert s.count(needle)==1;s=s.replace(needle,'pipeline=engine119_candidate?:runtime->lightonocr3_vision_mpp_pipeline;params.reserved1=')
s=s.replace('const size_t query_tile = vision_packed != nil ? 16u : 32u;','const size_t query_tile = vision_packed != nil ? engine119_query_tile : 32u;').replace('MTLSizeMake(vision_packed != nil ? 128u : 256u, 1, 1)','MTLSizeMake(vision_packed != nil ? engine119_threads : 256u, 1, 1)');(v/'engine119_vision_kernels.m').write_text(s)
s=(r/'zig/pkg/inference/scripts/lightonocr3/check_metal_vision.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine119_vision_kernels.m"');(v/'engine119_vision_checks.m').write_text(s)
