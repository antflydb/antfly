from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

v = Path('.venv-lighton-vllm-metal')
out = Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
label = 'gpu_stage_diagnostic_physical64_c64_vf2_r128'
dest = out / ('engine39_4b_' + label)
assert not (dest / 'report.json').exists()
env = os.environ.copy()
env.update(OCR_REFERENCE_LABEL='_primary_reference20_r0_auto_c64_r128', OCR_PHYSICAL32='0',
           OCR_PHYSICAL64='1', OCR_CONCURRENCY='64', OCR_REQUESTS='128', OCR_WIDE='1',
           OCR_SCRATCH_GIB='10', OCR_BACKEND_GIB='17', OCR_KV_GIB='4', OCR_CPU_PREPROCESS='1',
           OCR_PREFILL_DECODE_STREAK='0', OCR_POLICIES='engineepoch', OCR_SHARED_CORE='1',
           OCR_BF16_PREFILL='1', OCR_BF16='0', OCR_VISION_BATCH='0', OCR_VISION_FRAME_BLOCKS='2',
           OCR_SINGLE_FRAME='1', OCR_STREAM_FIRST='0', OCR_LOGICAL64='1',
           OCR_SHARED_DECODER_SCRATCH='1', OCR_DEVICE_RECURRENT_STATE='1', OCR_ENCODER_SCOPES='1',
           OCR_ADMISSION_UNITS='512', OCR_VISION_STREAM='0', OCR_DISABLE_64_ROW_TILE='0',
           TERMITE_METAL_STAGE_TIMING='1', TERMITE_METAL_STAGE_TIMING_LOG_FRAMES='1',
           TERMITE_METAL_STAGE_TIMING_PREFILL_MAX='8', TERMITE_METAL_STAGE_TIMING_DECODE_START='400',
           TERMITE_METAL_STAGE_TIMING_DECODE_STRIDE='16', TERMITE_METAL_STAGE_TIMING_DECODE_MAX='16')
with Path('/private/tmp/ocr-engine39-gpu-stage-diagnostic-driver.txt').open('w') as log:
    result = subprocess.run([sys.executable, str(v / 'run_engine39_budget_no_prefill_policies_verify.py'), '4b:' + label], env=env, stdout=log, stderr=subprocess.STDOUT)
assert result.returncode == 0, result.returncode
p = dest / 'report.json'
d = json.loads(p.read_text())
d.update(primary_throughput_eligible=False, gpu_stage_timing_enabled=True,
         diagnostic_reason='GPU counter samples insert barriers and may alter encoder scheduling. Excluded from throughput comparisons; no own CPU compilation or CPU sampling overlaps this run.')
p.write_text(json.dumps(d, indent=2) + '\n')
r = d['results'][0]
assert r['status'] == 'ok' and r['serial_reference_parity'] and r['cross_runtime_content_parity']
raw = (dest / r['log']).read_text()
sections = raw.split('OCR_POLICY round=0 name=engineepoch')
assert len(sections) == 2
pattern = r'lightonocr3_gpu_frame regime=(\w+) frame=(\d+) gpu_ns=(\d+) attention_ns=(\d+) ffn_ns=(\d+) other_ns=(\d+)'
samples = [dict(regime=x[0], frame=int(x[1]), gpu_ns=int(x[2]), attention_ns=int(x[3]), ffn_ns=int(x[4]), other_ns=int(x[5])) for x in re.findall(pattern, sections[1])]
assert samples, 'No actual timed-cohort samples; do not infer performance from serial-reference frames.'
audit = dict(primary_throughput_eligible=False, samples_from_timed_cohort=samples,
             excluded_serial_reference_samples=len(re.findall(pattern, sections[0])),
             report=str(p.relative_to(out)), report_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
             interpretation='Measured whole-frame GPU time and timestamp-apportioned coarse buckets. Sampling can perturb scheduling; not a primary speed result.')
(out / 'engine39_4b_gpu_stage_diagnostic_audit.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps(audit, indent=2), flush=True)
