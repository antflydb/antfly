from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal')
stem='engine47_bf16_vs_f32_ffn_probe'
(v/(stem+'_kernels.m')).write_bytes((v/'engine47_bf16_ffn_probe_kernels.m').read_bytes())
(v/(stem+'_checks.m')).write_text((v/'engine47_bf16_ffn_probe_checks.m').read_text().replace('engine47_bf16_ffn_probe_kernels.m',stem+'_kernels.m'))
(v/(stem+'.metal')).write_bytes((v/'engine47_bf16_ffn_probe.metal').read_bytes())
(v/(stem+'_f32.metal')).write_bytes((v/'engine44_streamed_ffn_probe.metal').read_bytes())
s=(v/'engine47_bf16_ffn_probe.m').read_text().replace('engine47_bf16_ffn_probe',stem).replace('BF16_STREAM_FFN','BF16_VS_F32_FFN')
s=s.replace('#define STREAM_LAYERS 32','#define STREAM_LAYERS 32\nstatic id<MTLComputePipelineState> f32_pipelines[6];')
needle=' id<MTLBuffer> packed=p?[r->device newBufferWithLength:rows*in*2 options:MTLResourceStorageModePrivate]:nil;\n if(p&&!packed)return 30;'
assert s.count(needle)==1
s=s.replace(needle,''' bool bf16_input=p!=nil;
 if(!p)p=f32_pipelines[variant];
 id<MTLBuffer> packed=bf16_input?[r->device newBufferWithLength:rows*in*2 options:MTLResourceStorageModePrivate]:nil;
 if(bf16_input&&!packed)return 30;''')
s=s.replace('  if(!p){','  if(false){')
s=s.replace('termite_metal_planned_range_make(packed,0,rows*in*2,TERMITE_METAL_PLANNED_RANGE_WRITE,&a[6],-1)||','(bf16_input&&termite_metal_planned_range_make(packed,0,rows*in*2,TERMITE_METAL_PLANNED_RANGE_WRITE,&a[6],-1))||')
s=s.replace('termite_metal_decode_runtime_prepare_planned_compute_accesses(r,a,7,-1)','termite_metal_decode_runtime_prepare_planned_compute_accesses(r,a,bf16_input?7:6,-1)')
s=s.replace('   uint32_t count=(uint32_t)(rows*in);','   if(bf16_input){\n   uint32_t count=(uint32_t)(rows*in);')
s=s.replace('[e memoryBarrierWithScope:MTLBarrierScopeBuffers];pack_dispatches++;','[e memoryBarrierWithScope:MTLBarrierScopeBuffers];pack_dispatches++;\n   }')
s=s.replace('[e setComputePipelineState:p];[e setBuffer:packed offset:0 atIndex:0];','[e setComputePipelineState:p];[e setBuffer:bf16_input?packed:x offset:bf16_input?0:16 atIndex:0];')
s=s.replace('pack_dispatches!=(p?STREAM_LAYERS:0)','pack_dispatches!=(bf16_input?STREAM_LAYERS:0)')
needle=' id<MTLComputePipelineState>p[6];for(size_t i=0;i<6;i++){'
assert s.count(needle)==1
s=s.replace(needle,''' NSString*fsource=[NSString stringWithContentsOfFile:@".venv-lighton-vllm-metal/engine47_bf16_vs_f32_ffn_probe_f32.metal" encoding:NSUTF8StringEncoding error:&err];
 id<MTLLibrary>flib=[r->device newLibraryWithSource:fsource options:opts error:&err];if(!flib)return 31;
 id<MTLComputePipelineState>p[6];for(size_t i=0;i<6;i++){
  f32_pipelines[i]=termite_metal_make_pipeline(r->device,flib,[NSString stringWithFormat:@"gate_mpp_%zu",i]);
  if(!f32_pipelines[i]||f32_pipelines[i].threadExecutionWidth!=32||f32_pipelines[i].maxTotalThreadsPerThreadgroup<sgs[i]*32)return 32;''')
(v/(stem+'.m')).write_text(s)
plan=json.loads((v/'engine47-bf16-ffn-probe-plan.json').read_text())
plan['scope']='Direct same-process ABBA: BF16-input fused MPP versus F32-input fused MPP using the identical tile and exactly BF16-representable inputs. Both have BF16 weights/F32 accumulators/F32 outputs; BF16 candidate includes 32 GPU input packs while F32 has none. This isolates input precision/packing from the matrix-tile advantage. Runtime unchanged; not full-model throughput.'
(v/'engine47-bf16-vs-f32-ffn-probe-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s=(v/'build_engine47_bf16_ffn_probe.py').read_text().replace('engine47_bf16_ffn_probe',stem).replace('engine47-bf16-ffn-probe','engine47-bf16-vs-f32-ffn-probe')
s=s.replace("'engine47_bf16_vs_f32_ffn_probe.metal']","'engine47_bf16_vs_f32_ffn_probe.metal', 'engine47_bf16_vs_f32_ffn_probe_f32.metal']")
(v/'build_engine47_bf16_vs_f32_ffn_probe.py').write_text(s)
s=(v/'run_engine47_bf16_ffn_probe.py').read_text().replace('engine47_bf16_ffn_probe',stem).replace('engine47-bf16-ffn','engine47-bf16-vs-f32-ffn')
# The previous primary-driver archive is already immutable; repeated archive
# is a hash equality check and is harmless.
(v/'run_engine47_bf16_vs_f32_ffn_probe.py').write_text(s)
