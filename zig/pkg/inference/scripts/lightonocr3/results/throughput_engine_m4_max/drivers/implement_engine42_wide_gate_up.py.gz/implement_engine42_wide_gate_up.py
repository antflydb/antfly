from pathlib import Path
p=Path('zig/pkg/inference/src/backends/metal_kernels.m')
s=p.read_text()
def once(old,new):
 global s
 assert s.count(old)==1,(old[:100],s.count(old))
 s=s.replace(old,new)
once('    id<MTLComputePipelineState> lightonocr3_gate_up_wide16_pipeline;','    id<MTLComputePipelineState> lightonocr3_gate_up_wide16_pipeline;\n    id<MTLComputePipelineState> lightonocr3_gate_up_wide32_pipeline;\n    uint64_t lightonocr3_wide_gate_up_calls;')
once('template<uint N, uint M=8> inline void termite_lightonocr3_gate_up_small_body','template<uint N, uint M=8, uint SG=1> inline void termite_lightonocr3_gate_up_small_body')
a=s.index('template<uint N, uint M=8, uint SG=1> inline void termite_lightonocr3_gate_up_small_body')
b=s.index('kernel void termite_lightonocr3_gate_up_small16',a)
part=s[a:b];assert part.count('execution_simdgroups<1>')==1
s=s[:a]+part.replace('execution_simdgroups<1>','execution_simdgroups<SG>')+s[b:]
a=s.index('        "kernel void termite_lightonocr3_gate_up_wide16(')
b=s.index('\n',a)
line=s[a:b].replace('termite_lightonocr3_gate_up_wide16','termite_lightonocr3_gate_up_wide32').replace('small_body<16,16>','small_body<16,32,2>')
s=s[:b]+'\n'+line+s[b:]
needle='            runtime->lightonocr3_gate_up_wide16_pipeline = termite_metal_make_pipeline(device, tensor_library, @"termite_lightonocr3_gate_up_wide16");'
once(needle,needle+'\n            runtime->lightonocr3_gate_up_wide32_pipeline = termite_metal_make_pipeline(device, tensor_library, @"termite_lightonocr3_gate_up_wide32");')
needle='    runtime->lightonocr3_gate_up_wide16_pipeline = nil;'
once(needle,needle+'\n    runtime->lightonocr3_gate_up_wide32_pipeline = nil;')
once('if (runtime == NULL || rows > 16 || !termite_metal_lightonocr3_fast_projections(runtime) ||','if (runtime == NULL || rows > 64 || !termite_metal_lightonocr3_fast_projections(runtime) ||')
needle='''    id<MTLComputePipelineState> local=termite_metal_lightonocr3_local_gate_pipeline(runtime,rows,in_dim,out_dim);'''
once(needle,'''    // Qualified MPP tile for wide LightOn decoder batches. Preserve the
    // established narrow tiles and generic BF16 fallback independently.
    if (rows >= 32 &&
        ((in_dim == 1024 && out_dim == 3584) || (in_dim == 2560 && out_dim == 9216)) &&
        !termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP"))) {
        id<MTLComputePipelineState> wide = runtime->lightonocr3_gate_up_wide32_pipeline;
        if (wide != nil && wide.threadExecutionWidth == 32 &&
            wide.maxTotalThreadsPerThreadgroup >= 64 &&
            wide.staticThreadgroupMemoryLength <= runtime->device.maxThreadgroupMemoryLength)
            return wide;
    }
    if (rows > 16) return nil;
'''+needle)
needle='''    const bool explicit_enable = termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_BF16_FUSED_GATE_UP"));'''
once(needle,'''    if (rows >= 32 && rows <= 64 && input_offset % 16 == 0 &&
        termite_metal_lightonocr3_batch_gate_up_pipeline(runtime, rows, in_dim, out_dim) != nil)
        return termite_metal_decode_runtime_can_apply_bf16_gate_up(runtime, gate_slot, up_slot, rows, in_dim, out_dim);
'''+needle)
needle='''        else if (small == runtime->lightonocr3_gate_up_wide16_pipeline && small != nil)'''
once(needle,'''        else if (small == runtime->lightonocr3_gate_up_wide32_pipeline && small != nil) {
            [encoder dispatchThreadgroups:MTLSizeMake(out_dim / 16, (rows + 31u) / 32u, 1)
                    threadsPerThreadgroup:MTLSizeMake(64, 1, 1)];
            runtime->lightonocr3_wide_gate_up_calls =
                termite_metal_u64_saturating_add(runtime->lightonocr3_wide_gate_up_calls, 1);
        }
'''+needle)
once('''local_tg ? "lightonocr3_gate_up_local_tg" : local_vec ? "lightonocr3_gate_up_local_vector" : small != nil ? "lightonocr3_batch_gate_up"''','''local_tg ? "lightonocr3_gate_up_local_tg" : local_vec ? "lightonocr3_gate_up_local_vector" : small != nil && small == runtime->lightonocr3_gate_up_wide32_pipeline ? "lightonocr3_wide_gate_up_mpp" : small != nil ? "lightonocr3_batch_gate_up"''')
s+='''
uint64_t termite_metal_decode_runtime_lighton_wide_gate_up_calls(termite_metal_decode_runtime *runtime) {
    return runtime != NULL ? runtime->lightonocr3_wide_gate_up_calls : 0;
}
'''
p.write_text(s)
p=Path('zig/pkg/inference/src/backends/metal_runtime.zig')
s=p.read_text()
s+='''
pub extern fn termite_metal_decode_runtime_lighton_wide_gate_up_calls(runtime: ?*RawMetalDecodeRuntime) u64;
'''
p.write_text(s)
p=Path('zig/pkg/inference/src/ops/metal_compute.zig')
s=p.read_text()
needle='    lighton_standalone_head_start: u64 = 0,'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n    lighton_wide_gate_up_start: u64 = 0,')
needle='        self.lighton_standalone_head_start = metal_runtime_mod.termite_metal_decode_runtime_lighton_standalone_wide_head_calls(raw);'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n        self.lighton_wide_gate_up_start = metal_runtime_mod.termite_metal_decode_runtime_lighton_wide_gate_up_calls(raw);')
needle='    pub fn lightOnStandaloneWideHeads(cb: *const ops.ComputeBackend) u64 {'
assert s.count(needle)==1
s=s.replace(needle,'''    pub fn lightOnWideGateUpCalls(cb: *const ops.ComputeBackend) u64 {
        if (cb.kind() != .metal) return 0;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return metal_runtime_mod.termite_metal_decode_runtime_lighton_wide_gate_up_calls(self.provider_impl.raw_decode_runtime) -| self.lighton_wide_gate_up_start;
    }

'''+needle)
p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig')
s=p.read_text()
needle='                    const standalone_heads = if (comptime build_options.enable_metal)'
assert s.count(needle)==1
s=s.replace(needle,'''                    const wide_gate_up = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnWideGateUpCalls(&cb) else 0;
                    std.debug.print("LIGHTONOCR3 wide_gate_up_calls={d}\\\\n", .{wide_gate_up});
'''+needle)
# Generated Python string must contain a Zig newline escape, not two backslashes.
s=s.replace('wide_gate_up_calls={d}\\\\n','wide_gate_up_calls={d}\\n')
p.write_text(s)
print('Integrated measured M32N16/SG2 wide gate/up kernel and epoch-relative dispatch telemetry.')
