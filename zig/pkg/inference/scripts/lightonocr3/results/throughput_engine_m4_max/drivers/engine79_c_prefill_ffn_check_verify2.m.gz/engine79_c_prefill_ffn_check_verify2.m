#define main production_checks_main
#include "../zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m"
#undef main
#include "engine78_source.inc"
@interface Buffers78:NSObject { @public
 id<MTLBuffer> source,zero,x,g,u,activated,pnorm,pgated,y0,y1;
}
@end
@implementation Buffers78
@end
static id<MTLBuffer> buffer78(termite_metal_decode_runtime*r,size_t bytes){
 id<MTLBuffer>b=[r->device newBufferWithLength:bytes+32 options:MTLResourceStorageModeShared];
 if(b){uint32_t*p=b.contents;for(int i=0;i<4;i++)p[i]=p[(bytes+16)/4+i]=0xdeadbeefu;}return b;
}
static int canary78(id<MTLBuffer>b,size_t bytes){uint32_t*p=b.contents;for(int i=0;i<4;i++)if(p[i]!=0xdeadbeefu||p[(bytes+16)/4+i]!=0xdeadbeefu)return 1;return 0;}
static int frame78(termite_metal_decode_runtime*r,id<MTLComputePipelineState>pso,Buffers78*b,size_t rows,size_t variant,bool on,double*gpu_us,double*encode_us){
 size_t h=2560,f=9216;uint64_t start=clock_gettime_nsec_np(CLOCK_UPTIME_RAW);
 if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_PREFILL)||
    termite_metal_decode_runtime_apply_add_device(r,(__bridge void*)b->source,16,(__bridge void*)b->zero,0,rows*h,(__bridge void*)b->x,16)||
    termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_FFN,TERMITE_METAL_COMPUTE_REGION_FFN))return 1;
 if(!on){
  if(termite_metal_decode_runtime_apply_linear_multi_row_device(r,0,(__bridge void*)b->x,16,rows,h,f,(__bridge void*)b->g,16)||
     termite_metal_decode_runtime_apply_linear_multi_row_device(r,1,(__bridge void*)b->x,16,rows,h,f,(__bridge void*)b->u,16)||
     termite_metal_decode_runtime_apply_activation_multiply_device(r,2,(__bridge void*)b->g,16,(__bridge void*)b->u,16,rows,f,(__bridge void*)b->activated,16)||
     termite_metal_decode_runtime_apply_linear_multi_row_device(r,2,(__bridge void*)b->activated,16,rows,f,h,(__bridge void*)b->y0,16))return 2;
 }else{
  uint64_t before=r->lighton_prefill_ffn_calls;
  if(!antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,h,f)||
     antfly_metal_lighton_prefill_ffn_apply(r,0,1,2,rows,h,f,(__bridge void*)b->x,16,
        (__bridge void*)b->pnorm,16,(__bridge void*)b->pgated,16,(__bridge void*)b->y1,16))return 3;
  if(r->lighton_prefill_ffn_calls!=before+1)return 3;
 }

 if(termite_metal_decode_runtime_end_planned_compute_scope(r))return 4;*encode_us=(clock_gettime_nsec_np(CLOCK_UPTIME_RAW)-start)/1000.;
 if(termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r))return 5;*gpu_us=r->last_frame_gpu_nanos/1000.;return 0;
}
static bool same_corner78(double expected,float actual){if(isnan(expected))return isnan(actual);if(isinf(expected))return expected==actual;return isfinite(actual)&&fabs(expected-actual)<=2e-4;}
static int preflight79(termite_metal_decode_runtime*r,Buffers78*b,size_t rows){
 if(antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 70;
 if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_PREFILL))return 71;
 if(!antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 72;
 uint64_t calls=r->lighton_prefill_ffn_calls;
 if(antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,127,2560,9216)||
    antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,1025,2560,9216)||
    antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2561,9216)||
    antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,TERMITE_METAL_LINEAR_SLOT_CAPACITY,rows,2560,9216))return 73;
 size_t variant=rows<=512?1:0;id<MTLComputePipelineState>saved=r->lighton_prefill_ffn_pipelines[variant];r->lighton_prefill_ffn_pipelines[variant]=nil;
 if(antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 74;r->lighton_prefill_ffn_pipelines[variant]=saved;
 if(antfly_metal_lighton_prefill_ffn_apply(r,0,1,2,rows,2560,9216,(__bridge void*)b->x,16,(__bridge void*)b->pnorm,16,(__bridge void*)b->pgated,16,(__bridge void*)b->x,16)!=-3)return 75;
 if(antfly_metal_lighton_prefill_ffn_apply(r,0,1,2,rows,2560,9216,(__bridge void*)b->x,16,(__bridge void*)b->pgated,16,(__bridge void*)b->pgated,16,(__bridge void*)b->y1,16)!=-3)return 76;
 if(antfly_metal_lighton_prefill_ffn_apply(r,0,1,2,rows,2560,9216,(__bridge void*)b->x,16,(__bridge void*)b->pnorm,16,(__bridge void*)b->pgated,16,(__bridge void*)b->pnorm,16)!=-2)return 77;
 if(antfly_metal_lighton_prefill_ffn_apply(r,0,1,2,rows,2560,9216,(__bridge void*)b->x,16,(__bridge void*)b->pnorm,16,(__bridge void*)b->pgated,16,(__bridge void*)b->y1,SIZE_MAX-3)!=-2)return 78;
 if(r->lighton_prefill_ffn_calls!=calls)return 79;
 // Rollback is stable within the snapshot, and takes effect next frame.
 setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_FFN","1",1);
 if(!antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 80;
 if(termite_metal_decode_runtime_cancel_frame(r)||termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_PREFILL))return 81;
 if(antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 82;
 if(termite_metal_decode_runtime_cancel_frame(r))return 83;unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_FFN");
 setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN","0",1);
 if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_PREFILL))return 84;
 if(antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 85;
 if(termite_metal_decode_runtime_cancel_frame(r))return 86;setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN","1",1);
 if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_DECODE))return 87;
 if(antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 88;
 if(termite_metal_decode_runtime_cancel_frame(r))return 89;
 const char* rollback_flags[]={"TERMITE_METAL_DISABLE_LIGHTONOCR3_MPP","TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PROJECTIONS","TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PACK_REUSE","TERMITE_METAL_DISABLE_LIGHTONOCR3_PLANNED_MPP"};
 for(size_t i=0;i<4;++i){
  setenv(rollback_flags[i],"1",1);
  if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_PREFILL))return 90;
  if(antfly_metal_lighton_prefill_ffn_can_apply(r,0,1,2,rows,2560,9216))return 91;
  if(termite_metal_decode_runtime_cancel_frame(r))return 92;unsetenv(rollback_flags[i]);
 }
 return 0;
}
static int probe78(termite_metal_decode_runtime*r,id<MTLComputePipelineState>pso,size_t rows,size_t variant){@autoreleasepool{
 const size_t h=2560,f=9216;Buffers78*b=[Buffers78 new];b->source=buffer78(r,rows*h*4);b->zero=[r->device newBufferWithLength:rows*h*4 options:MTLResourceStorageModeShared];b->x=[r->device newBufferWithLength:rows*h*4+32 options:MTLResourceStorageModePrivate];
 b->g=buffer78(r,rows*f*4);b->u=buffer78(r,rows*f*4);b->activated=buffer78(r,rows*f*4);b->pnorm=buffer78(r,rows*h*2);b->pgated=buffer78(r,rows*f*2);b->y0=buffer78(r,rows*h*4);b->y1=buffer78(r,rows*h*4);
 if(!b->source||!b->zero||!b->x||!b->g||!b->u||!b->activated||!b->pnorm||!b->pgated||!b->y0||!b->y1)return 10;
 memset(b->zero.contents,0,b->zero.length);float*input=(float*)b->source.contents+4;for(size_t i=0;i<rows*h;i++)input[i]=sinf(i*.013f)*.7f;
 double expectedGU[2][4];uint16_t downCorners[2][9216];float downBias[2];
 for(size_t slot=0;slot<3;slot++){
  size_t in=slot==2?f:h,out=slot==2?h:f;uint16_t*w=malloc(in*out*2);float*bias=malloc(out*4);if(!w||!bias)return 11;uint32_t seed=123u+(uint32_t)slot*519u;
  for(size_t i=0;i<in*out;i++){seed=seed*1664525u+1013904223u;w[i]=round_bf16(((int)(seed>>16)-32768)*.0000003f);}for(size_t c=0;c<out;c++)bias[c]=cosf(c*.019f)*.05f;
  if(slot<2){
   for(size_t c=0;c<10;c++)memset(w+c*in,0,in*2);
   const float gates[10]={NAN,INFINITY,-INFINITY,-100.f,-20.f,-20.01f,-0.f,20.f,20.01f,0.f};
   const float ups[10]={INFINITY,1.f,NAN,INFINITY,1.f,1.f,-INFINITY,1.f,1.f,NAN};
   for(size_t c=0;c<10;c++)bias[c]=slot?ups[c]:gates[c];
   for(size_t corner=0;corner<4;corner++){size_t row=corner/2?rows-1:0,col=corner%2?out-1:0;double sum=bias[col];for(size_t k=0;k<in;k++)sum+=(double)expand_bf16(round_bf16(input[row*h+k]+0.0f))*expand_bf16(w[col*in+k]);expectedGU[slot][corner]=sum;}
  }else for(size_t corner=0;corner<2;corner++){size_t col=corner?out-1:0;memcpy(downCorners[corner],w+col*in,in*2);downBias[corner]=bias[col];}
  int rc=termite_metal_decode_runtime_prepare_linear_bf16(r,slot,(uint8_t*)w,in*out*2,bias,in,out);free(w);free(bias);if(rc)return 12;
 }
 int preflight=preflight79(r,b,rows);if(preflight)return preflight;
 double us,encode;if(frame78(r,pso,b,rows,variant,false,&us,&encode))return 13;
 float*g=(float*)b->g.contents+4,*u=(float*)b->u.contents+4,*activated=(float*)b->activated.contents+4,*gold=(float*)b->y0.contents+4;
 for(size_t c=0;c<4;c++){size_t row=c/2?rows-1:0,col=c%2?f-1:0;if(!same_corner78(expectedGU[0][c],g[row*f+col])||!same_corner78(expectedGU[1][c],u[row*f+col]))return 14;}
 double expectedOut[4];for(size_t corner=0;corner<4;corner++){size_t row=corner/2?rows-1:0,col=corner%2;double sum=downBias[col];for(size_t k=0;k<f;k++)sum+=(double)expand_bf16(round_bf16(activated[row*f+k]))*expand_bf16(downCorners[col][k]);expectedOut[corner]=sum;if(!same_corner78(sum,gold[row*h+(col?h-1:0)]))return 15;}
 for(size_t leg=0;leg<4;leg++){
  bool on=leg==1||leg==2;double times[8],encodes[8];float worst=0;size_t packedDiff=0,normDiff=0;
  for(size_t trial=0;trial<10;trial++){
   int rc=frame78(r,pso,b,rows,variant,on,&us,&encode);if(rc)return 20+rc;if(trial>=2){times[trial-2]=us;encodes[trial-2]=encode;}
   id<MTLBuffer>actual=on?b->y1:b->y0;float*got=(float*)actual.contents+4;
   for(size_t i=0;i<rows*h;i++){if(!isfinite(got[i])||!isfinite(gold[i]))return 30;worst=fmaxf(worst,fabsf(got[i]-gold[i]));}
   for(size_t c=0;c<4;c++){size_t row=c/2?rows-1:0,col=c%2?h-1:0;if(!same_corner78(expectedOut[c],got[row*h+col]))return 31;}
   if(on){uint16_t*pn=(uint16_t*)((char*)b->pnorm.contents+16),*pg=(uint16_t*)((char*)b->pgated.contents+16);for(size_t i=0;i<rows*h;i++)normDiff+=pn[i]!=round_bf16(input[i]+0.0f);for(size_t i=0;i<rows*f;i++)packedDiff+=pg[i]!=round_bf16(activated[i]);}
   id<MTLBuffer>bufs[]={b->source,b->g,b->u,b->activated,b->pnorm,b->pgated,b->y0,b->y1};size_t sizes[]={rows*h*4,rows*f*4,rows*f*4,rows*f*4,rows*h*2,rows*f*2,rows*h*4,rows*h*4};for(size_t j=0;j<8;j++)if(canary78(bufs[j],sizes[j]))return 32;
  }
  if(worst>2e-4f||packedDiff||normDiff){fprintf(stderr,"PACKED78_FAIL variant=%zu rows=%zu abs=%g packed_diff=%zu norm_diff=%zu\n",variant,rows,worst,packedDiff,normDiff);return 33;}
  printf("{\"variant\":%zu,\"rows\":%zu,\"leg\":%zu,\"mode\":%d,\"max_abs\":%.9g,\"packed_differences\":%zu,\"norm_packed_differences\":%zu,\"gpu_us\":[",variant,rows,leg,on,worst,packedDiff,normDiff);for(int t=0;t<8;t++)printf("%s%.6f",t?",":"",times[t]);printf("],\"host_encode_us\":[");for(int t=0;t<8;t++)printf("%s%.6f",t?",":"",encodes[t]);printf("]}\n");fflush(stdout);
 }
 return 0;
}}
int main(void){@autoreleasepool{
 setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY","1",1);setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN","1",1);
 setenv("TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS","1",1);unsetenv("TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS");termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);if(termite_metal_decode_runtime_set_lighton_activation_pool(r,8*1024*1024)||!r->lightonocr3_pack_bf16_pipeline||!r->lightonocr3_mpp_bf16_pipeline)return 2;
 const size_t rows[]={128,129,432,554,662,1024};for(size_t variant=0;variant<1;variant++){
  id<MTLComputePipelineState>pso=nil;
  for(size_t i=0;i<6;i++){int rc=probe78(r,pso,rows[i],variant);if(rc){fprintf(stderr,"PROBE78_FAIL variant=%zu rows=%zu rc=%d\n",variant,rows[i],rc);return 40+rc;}}
 }
 termite_metal_decode_runtime_destroy(r);fprintf(stderr,"ENGINE79 C PREFILL FFN CHECK PASS\n");return 0;
}}
