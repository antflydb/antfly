from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=p.read_text();assert hashlib.sha256(p.read_bytes()).hexdigest()=='2bad0979f93ee6e9f22e672ccd28bdbb5bafdeedd941d07846eb70f0aa672769'
s=s.replace('    TERMITE_METAL_FRAME_ENV_COUNT\n','    TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_PREFILL_FFN,\n    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_PREFILL_FFN,\n    TERMITE_METAL_FRAME_ENV_COUNT\n',1)
needle='    "TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_CORE_NORM",\n};';assert s.count(needle)==1;s=s.replace(needle,'    "TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_CORE_NORM",\n    "TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN",\n    "TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_FFN",\n};')
needle='    id<MTLComputePipelineState> lightonocr3_mpp_bf16_pipeline;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    id<MTLComputePipelineState> lighton_prefill_ffn_pipelines[2];\n    bool lighton_prefill_ffn_initialization_attempted;\n    uint64_t lighton_prefill_ffn_calls;')
shader=(v/'engine78_packed_gate.metal').read_text().replace('engine78','termite_lighton_prefill');source='// Same RNE packing and clamped SiLU as the ordinary prefill path.\nstatic NSString *termite_metal_lighton_prefill_ffn_source(void) {\n    return @'+json.dumps(shader)+';\n}\n\n'
needle='static NSString *termite_metal_lightonocr3_tensor_source(void) {';assert s.count(needle)==1;s=s.replace(needle,source+needle)
needle='int termite_metal_decode_runtime_apply_bf16_gate_up_device(';assert s.count(needle)==1;s=s.replace(needle,(v/'engine79_prefill_ffn_impl.inc').read_text()+'\n'+needle)
needle='    runtime->lightonocr3_mpp_bf16_pipeline = nil;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    runtime->lighton_prefill_ffn_pipelines[0] = nil;\n    runtime->lighton_prefill_ffn_pipelines[1] = nil;')
p.write_text(s);print('C optional prefill FFN source integrated; not yet compiled/qualified')
