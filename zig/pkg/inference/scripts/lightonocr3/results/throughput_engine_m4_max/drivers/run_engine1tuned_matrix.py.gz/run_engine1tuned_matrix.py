from pathlib import Path
import json,os,subprocess,sys,hashlib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';s=r/'zig/pkg/inference/scripts/lightonocr3';out=s/'results/throughput_engine_m4_max';manifest=out/'engine1_build_manifest.json';binary=json.loads(manifest.read_text())['binary_path']
for label in sys.argv[1:]:
 model,variant=label.split(':');env=os.environ.copy();features={'ANTFLY_LIGHTONOCR3_STEP_EVENTS':not variant.startswith('base'),'ANTFLY_LIGHTONOCR3_DECODE_WORKSPACE':not variant.startswith('base'),'ANTFLY_LIGHTONOCR3_WIDE_DECODE':variant.startswith('wide'),'ANTFLY_LIGHTONOCR3_PREPARED_DECODE':'plan'in variant};env.update({k:'1'if value else'0'for k,value in features.items()});target=out/('engine1tuned_'+model+'_'+variant)
 concurrency=os.environ.get('OCR_CONCURRENCY','16');requests=os.environ.get('OCR_REQUESTS','32');rows='16'if features['ANTFLY_LIGHTONOCR3_WIDE_DECODE']else'8'
 cmd=[sys.executable,str(s/'benchmark_concurrency.py'),'--native-test',binary,'--model',f'lighton{model}={v/"ocr-models"/("lighton"+model)}','--images',str(r/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(s/'corpus/receipt.png'),str(s/'corpus/shipping.png'),'--concurrency',concurrency,'--requests',requests,'--max-tokens','256','--modes','batch','--batch-rows',rows,'--batch-window',concurrency,'--batch-wait-us','20000','--memory-gib','24','--shared-memory-gib','28','--backend-memory-gib','16','--kv-memory-gib','4','--scratch-memory-gib','4','--timeout','900','--reference-report',str(s/'results/throughput_epoch_m4_max'/('vllm_'+model+'_reference')/'report.json'),'--output-dir',str(target),'--build-manifest',str(manifest),'--weight-residency','--continuous','--policy-rounds','default','default','--trace-packed-core','--recurrent-parallel','--prefill-attention-mpp','--prefill-core-norm','--require-packed-core','--require-recurrent-parallel','--require-prefill-attention-mpp','--require-prefill-core-norm']
 if os.environ.get('OCR_FAST_FLAGS','1')=='1':
  cmd += ['--frame-policy','--weight-handles','--recurrent-coalescing'];env['ANTFLY_LIGHTONOCR3_READY_COHORTS']='1'
  i=cmd.index('--policy-rounds');cmd[i+1:i+3]=['current','current']
 if 'plan' in variant:cmd.remove('--require-packed-core')
 print('START',label,flush=True)
 with open('/private/tmp/ocr-engine1tuned-'+model+'-'+variant+'.txt','w')as log:res=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('DONE',label,res.returncode,flush=True)
 if(target/'report.json').exists():
  report=json.loads((target/'report.json').read_text());report['engine_features']=features;report['prepared_blocks_raw']=[int(x)for x in __import__('re').findall(r'LIGHTONOCR3 prepared_blocks=(\d+)',(target/('lighton'+model+'-batch-c'+concurrency+'.txt')).read_text())];report['driver_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();(target/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps([{k:x.get(k)for k in ['status','policy_rounds']}for x in report['results']]),flush=True)
 if res.returncode:sys.exit(res.returncode)
