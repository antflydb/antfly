from pathlib import Path
import os,subprocess,sys,json,hashlib,re
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');src=o/'engine56_workspace_profiles_audit.json';d=json.loads(src.read_text());records=list(d['candidates'])
failed=o/'engine56_4b_rolling_chunks0_trial0_c48_p1_vf2_r64_store56_vision4_vf2_workspace';raw=(failed/'lighton4b-batch-c48.txt').read_text();fd=json.loads((failed/'report.json').read_text());assert fd['results'][0]['status']=='failed'and'admission_pressure=domain_backend'in raw and'FAIL (ResourceTemporarilyUnavailable)'in raw
records.append(dict(profile='vision4_vf2_workspace',eligible=False,reason='domain_backend_admission',report=str((failed/'report.json').relative_to(o)),log_sha256=hashlib.sha256(raw.encode()).hexdigest(),has_throughput_result=False))
audit=o/'engine56_workspace_profiles_verified_audit.json';assert not audit.exists()
for name,c,vision,prefill,vf in [('combined_workspace',48,4,3,1),('vision4_vf2_c36_workspace',36,4,1,2)]:
 label='store56_'+name;env=os.environ.copy();env.update(OCR_CASE_CONCURRENCY=str(c),OCR_CASE_PREFILL_ITEMS=str(prefill),OCR_CASE_VISION_FRAME_BLOCKS=str(vf),OCR_CASE_VISION_BATCH_ITEMS=str(vision),OCR_CASE_TAG=label,OCR_VISION_WAIT_US='2000',OCR_BATCH_ARGMAX='1',OCR_DEFER_VISION_SEAL='1',OCR_DEFER_PREFILL_SEAL='0',OCR_CACHE_VISION_WORKSPACE='1',OCR_LARGE_VISION_PACK_REUSE='1',OCR_TIMEOUT='240')
 print('START',label,flush=True)
 with Path('/private/tmp/ocr-engine56-4b-'+label+'-driver.txt').open('w')as log:r=subprocess.run([sys.executable,str(v/'run_engine56_vision4_profile.py'),'4b','0'],env=env,stdout=log,stderr=subprocess.STDOUT)
 print('DONE',label,r.returncode,flush=True)
 p=o/f'engine56_4b_rolling_chunks0_trial0_c{c}_p{prefill}_vf{vf}_r64_{label}'/'report.json'
 if r.returncode:
  if p.exists():
   target=p.parent/json.loads(p.read_text())['results'][0]['log'];text=target.read_text()
   if 'admission_pressure=domain_backend'in text and'FAIL (ResourceTemporarilyUnavailable)'in text:
    records.append(dict(profile=name,eligible=False,reason='domain_backend_admission',report=str(p.relative_to(o)),has_throughput_result=False));continue
  raise RuntimeError((label,r.returncode))
 rd=json.loads(p.read_text());rs=rd['results'][0];s=rs['policy_rounds'][0]
 assert rs['status']=='ok'and rs['serial_reference_parity']and rs['cross_runtime_content_parity']and s['completed']==64 and not s['admission_pressures']
 records.append(dict(profile=name,eligible=True,pages_per_second=s['pages_per_second'],process_cpu_ms=s['process_cpu_ms'],completed=64,settings=dict(concurrency=c,vision_items=vision,prefill_items=prefill,vision_frame_blocks=vf,batch_argmax=True,defer_vision_seal=True,defer_prefill_seal=False,cache_vision_workspace=True,large_vision_pack_reuse=True),vision_batch_sizes=s['vision_batch_sizes'],prefill_batches=s['prefill_batches'],vision_workspace_allocations=s['vision_workspace_allocations'],vision_workspace_reuses=s['vision_workspace_reuses'],vision_workspace_bytes=s['vision_workspace_bytes'],large_vision_pack_calls=s['large_vision_pack_calls'],large_vision_pack_reuse_hits=s['large_vision_pack_reuse_hits'],report=str(p.relative_to(o)),report_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 audit.write_text(json.dumps(dict(status='running',original_partial_audit_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),candidates=records),indent=2)+'\n')
audit.write_text(json.dumps(dict(status='pass',original_partial_audit_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),candidates=records),indent=2)+'\n')
