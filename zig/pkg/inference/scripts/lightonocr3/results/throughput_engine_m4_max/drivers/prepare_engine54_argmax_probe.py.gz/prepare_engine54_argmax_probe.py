from pathlib import Path
import ast,re,json,hashlib
v=Path('.venv-lighton-vllm-metal');source=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=source.read_text()
a=s.index('           "inline bool termite_argmax_suppressed_token');b=s.index('           "inline void termite_whisper_lse_push',a)
msl=''.join(ast.literal_eval(x.strip())for x in s[a:b].splitlines())
msl=msl.replace('kernel void termite_argmax_logits_suppress_partials','kernel void engine54_partials')
msl=msl.replace('uint block [[threadgroup_position_in_grid]])','uint2 group [[threadgroup_position_in_grid]])')
msl=msl.replace('    const uint block_size = 1024u;', '    const uint block = group.x;\n    logits += size_t(group.y) * p.out_dim;\n    partial_values += size_t(group.y) * ((p.out_dim + 1023u) / 1024u);\n    partial_ids += size_t(group.y) * ((p.out_dim + 1023u) / 1024u);\n    const uint block_size = 1024u;')
msl=msl.replace('kernel void termite_argmax_logits_reduce','kernel void engine54_reduce')
msl=msl.replace('    if (gid != 0u) return;', '    output += gid;\n    partial_values += size_t(gid) * partial_count;\n    partial_ids += size_t(gid) * partial_count;')
msl='#include <metal_stdlib>\nusing namespace metal;\nstruct termite_metal_argmax_suppress_params { uint out_dim; uint suppress_count; uint reserved0; uint reserved1; };\n'+msl
(v/'engine54_argmax.metal').write_text(msl)
(v/'engine54_argmax_runtime.m').write_bytes(source.read_bytes())
(v/'engine54_argmax_source.inc').write_text('static NSString *engine54_source(void) { return @'+json.dumps(msl)+'; }\n')
manifest=dict(status='prepared_only',base_source=str(source),base_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),msl_sha256=hashlib.sha256(msl.encode()).hexdigest(),scope='Private 2D row dispatch prototype, original suppression/tie/nonfinite arithmetic, no production source edits.')
(v/'engine54_argmax_plan.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('prepared private batched argmax source')
