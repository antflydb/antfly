from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/src/pipelines/generation.zig';s=p.read_text()
def rep(old,new):
 global s
 assert s.count(old)==1,(old[:100],s.count(old));s=s.replace(old,new)
rep('        greedy_tokens: ?[]u32 = null,\n        // Additional outputs','        greedy_tokens: ?[]u32 = null,\n        packed_greedy_tokens: ?[]u32 = null,\n        // Additional outputs')
rep('        var prefill_count: usize = 0;\n        // Validate','        var prefill_count: usize = 0;\n        var all_decode_greedy = cb.kind() == .metal;\n        // Validate')
rep('                    mixed[index] = .{ .state = work.decode_state, .total_sequence_len = item.total_sequence_len, .query_sequence_len = 1,','                    all_decode_greedy = all_decode_greedy and work.wants_greedy;\n                    mixed[index] = .{ .state = work.decode_state, .total_sequence_len = item.total_sequence_len, .query_sequence_len = 1,')
rep('        const logits_bytes = try std.math.mul(usize, try std.math.mul(usize, claimed.len, cfg.vocab_size), 2 * @sizeOf(f32));','''        var gpu_choices = false;
        if (comptime build_options.enable_metal) {
            if (all_decode_greedy and prefill_count < claimed.len and !cb.decoderRuntimeHasActiveFrame())
                gpu_choices = @import("../ops/metal_compute.zig").MetalCompute.reserveLightOnFrameArgmax(cb, claimed.len, cfg.vocab_size);
        }
        // Greedy decode returns token IDs. Only prefills retain independent
        // vocabulary rows, so admission follows the actual output lifetime.
        const host_rows = if (gpu_choices) prefill_count else claimed.len;
        const logits_bytes = try std.math.mul(usize, try std.math.mul(usize, host_rows, cfg.vocab_size), 2 * @sizeOf(f32));''')
rep('''        const logits = try cb.linearNoBias(last, head, claimed.len, cfg.hidden_size, cfg.vocab_size);
        defer cb.free(logits);
        const host = try cb.toFloat32(logits, a);
        gpt_arch.applyFinalLogitSoftcapInPlace(cfg, host);''','''        // A separate decode frame preserves the established F32 head inputs,
        // even when the preceding mixed model frame permits BF16 projections.
        var head_frame_active = false;
        defer if (head_frame_active) cb.decoderRuntimeCancelFrame() catch {};
        if (gpu_choices) {
            head_frame_active = try cb.decoderRuntimeBeginFrame();
            if (!head_frame_active) return error.ResidentImageOperationUnavailable;
            try cb.decoderRuntimeSetActiveFrameRegime(.decode);
        }
        const logits = try cb.linearNoBias(last, head, claimed.len, cfg.hidden_size, cfg.vocab_size);
        defer cb.free(logits);
        var tokens: ?[]u32 = null;
        errdefer if (tokens) |choices| a.free(choices);
        if (comptime build_options.enable_metal) {
            if (gpu_choices) {
                try @import("../ops/metal_compute.zig").MetalCompute.ensureFrameArgmaxScope(cb);
                tokens = try cb.decoderRuntimeArgmaxRowsSuppress(logits, 0, claimed.len, cfg.vocab_size, cfg.suppressTokenIds(), a) orelse return error.ResidentImageOperationUnavailable;
                head_frame_active = false;
                if (tokens.?.len != claimed.len) return error.InvalidBatchDecodeState;
            }
        }
        const host = if (gpu_choices) blk: {
            var rows: [64]i64 = undefined;
            var count: usize = 0;
            for (claimed, 0..) |item, index| if (item.phase == .prefill) {
                rows[count] = @intCast(index);
                count += 1;
            };
            const prefix_logits = try cb.embeddingLookup(logits, rows[0..count], count, cfg.vocab_size);
            defer cb.free(prefix_logits);
            break :blk try cb.toFloat32(prefix_logits, a);
        } else try cb.toFloat32(logits, a);
        gpt_arch.applyFinalLogitSoftcapInPlace(cfg, host);''')
rep('        return .{ .logits = host, .max_query_seq_len = total, .last_rows_only = true, .host_permit = host_lease };','''        if (platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3")) std.debug.print("LIGHTONOCR3 packed_gpu_decode_rows={d} packed_cpu_logit_rows={d} packed_standalone_wide_heads={d}\\n", .{ if (gpu_choices) claimed.len - prefill_count else 0, host_rows, @intFromBool(!gpu_choices and claimed.len > 16) });
        return .{ .logits = host, .packed_greedy_tokens = tokens, .max_query_seq_len = total, .last_rows_only = true, .host_permit = host_lease };''')
rep('        greedy_tokens: ?[]const u32 = null,\n        second_greedy_tokens:', '        greedy_tokens: ?[]const u32 = null,\n        packed_greedy_tokens: ?[]const u32 = null,\n        second_greedy_tokens:')
rep('            if (self.greedy_tokens) |tokens| {','''            if (self.packed_greedy_tokens) |tokens| {
                dispatchPackedGreedyResults(self.vocab_size, claimed, self.logits, tokens);
                return;
            }
            if (self.greedy_tokens) |tokens| {''')
rep('        defer if (result.greedy_tokens) |tokens| self.allocator.free(tokens);','        defer if (result.greedy_tokens) |tokens| self.allocator.free(tokens);\n        defer if (result.packed_greedy_tokens) |tokens| self.allocator.free(tokens);')
rep('            .greedy_tokens = result.greedy_tokens,','            .greedy_tokens = result.greedy_tokens,\n            .packed_greedy_tokens = result.packed_greedy_tokens,')
rep('    fn dispatchStepLogitsLayout(vocab_size:', '''    fn dispatchPackedGreedyResults(vocab_size: usize, claimed: []const runtime.scheduler.native_generate.StepItem, logits: ?[]const f32, tokens: []const u32) void {
        var prefills: usize = 0;
        var valid = tokens.len == claimed.len;
        for (claimed) |item| switch (item.phase) {
            .prefill => prefills += 1,
            .decode => {
                const work: *PendingDecodeBatchWork = @ptrCast(@alignCast(item.work_ptr));
                valid = valid and work.wants_greedy;
            },
            .waiting => valid = false,
        };
        const expected = std.math.mul(usize, prefills, vocab_size) catch {
            markStepFailed(claimed, error.InvalidBatchDecodeState);
            return;
        };
        if (!valid or logits == null or logits.?.len != expected) {
            markStepFailed(claimed, error.InvalidBatchDecodeState);
            return;
        }
        var row: usize = 0;
        for (claimed, tokens) |item, token| switch (item.phase) {
            .decode => publishGreedyToken(@ptrCast(@alignCast(item.work_ptr)), token),
            .prefill => {
                const work: *PendingPrefillBatchWork = @ptrCast(@alignCast(item.work_ptr));
                if (work.wants_last_logits) {
                    work.logits = work.allocator.dupe(f32, logits.?[row * vocab_size ..][0..vocab_size]) catch |err| blk: {
                        work.failure = err;
                        break :blk null;
                    };
                }
                row += 1;
                work.ready.store(true, .release);
            },
            .waiting => unreachable,
        };
    }

    fn dispatchStepLogitsLayout(vocab_size:''')
s+='''

test "LightOnOCR3 packed greedy publication keeps only independent prefix logits in either order" {
    const a = std.testing.allocator;
    for ([_]bool{false, true}) |reverse| {
        var state = NativeDecodeState.initContiguous(a);
        defer state.deinit();
        var decode = NativeGenerationPipeline.PendingDecodeBatchWork{ .allocator = a, .decode_state = &state, .token_id = 1, .seq_len = 701, .wants_greedy = true };
        var prefill = NativeGenerationPipeline.PendingPrefillBatchWork{ .allocator = a, .decode_state = &state, .token_ids = &.{}, .seq_len = 554, .query_seq_len = 554, .wants_last_logits = true };
        defer if (prefill.logits) |row| a.free(row);
        const d: runtime.scheduler.native_generate.StepItem = .{ .work_ptr = &decode, .phase = .decode, .query_sequence_len = 1, .total_sequence_len = 701, .kv_sequence_len = 701, .kv_position_offset = 0 };
        const p: runtime.scheduler.native_generate.StepItem = .{ .work_ptr = &prefill, .phase = .prefill, .query_sequence_len = 554, .total_sequence_len = 554, .kv_sequence_len = 0, .kv_position_offset = 0 };
        const items = if (reverse) [_]runtime.scheduler.native_generate.StepItem{p, d} else [_]runtime.scheduler.native_generate.StepItem{d, p};
        var logits = [_]f32{ 4, 5, 6 };
        NativeGenerationPipeline.dispatchPackedGreedyResults(3, &items, &logits, if (reverse) &.{99, 2} else &.{2, 99});
        logits[0] = 100;
        try std.testing.expectEqual(@as(?u32, 2), decode.greedy_token);
        try std.testing.expect(decode.logits == null);
        try std.testing.expectEqualSlices(f32, &.{4, 5, 6}, prefill.logits.?);
        try std.testing.expect(decode.ready.load(.acquire) and prefill.ready.load(.acquire));
    }
}
'''
p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';s=p.read_text();needle='                    sample["packed_prefill_pages"] = sum('
assert s.count(needle)==1;s=s.replace(needle,'''                    for counter in ["packed_gpu_decode_rows", "packed_cpu_logit_rows", "packed_standalone_wide_heads"]:
                        sample[counter] = sum(int(value) for value in re.findall(counter + r"=(\\d+)", section))
'''+needle);p.write_text(s)
