from pathlib import Path
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m')
s=p.read_text()
a=s.index('static int batch_gate_up_check(');b=s.index('\nstatic int prefill_columns_check',a)
part=s[a:b].replace('batch_gate_up_check','wide_gate_up_check')
part=part.replace('rows >= 2 && rows <= 16','rows >= 32 && rows <= 64')
part=part.replace('''"TERMITE_METAL_DISABLE_LIGHTONOCR3_BATCH_GATE_UP",
''','''"TERMITE_METAL_DISABLE_LIGHTONOCR3_BATCH_GATE_UP",
                                  "TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP",
''')
needle='''        r->lightonocr3_gate_up_wide16_pipeline = nil;'''
assert part.count(needle)==1
part=part.replace(needle,'''        id<MTLComputePipelineState> wide32 = r->lightonocr3_gate_up_wide32_pipeline;
        r->lightonocr3_gate_up_wide32_pipeline = nil;
'''+needle)
needle='''        r->lightonocr3_gate_up_wide16_pipeline = wide;'''
part=part.replace(needle,'''        // Missing specialized and generic PSOs must decline before dispatch.
        id<MTLComputePipelineState> generic = r->bf16_gate_up_mm_pipeline;
        r->bf16_gate_up_mm_pipeline = nil;
        if (termite_metal_decode_runtime_can_apply_bf16_gate_up(r, 0, 1, rows, in, out)) return 74;
        r->bf16_gate_up_mm_pipeline = generic;
        r->lightonocr3_gate_up_wide32_pipeline = wide32;
'''+needle)
part=part.replace('(benchmark ? 30 : 1)','(benchmark ? 30 : 3)')
part=part.replace('''                if (termite_metal_decode_runtime_begin_frame(r))
                    return 8;''','''                const uint64_t before_wide = r->lightonocr3_wide_gate_up_calls;
                if (termite_metal_decode_runtime_begin_frame(r) ||
                    termite_metal_decode_runtime_set_active_frame_regime(r, TERMITE_METAL_FRAME_REGIME_DECODE))
                    return 8;''')
part=part.replace('TERMITE_METAL_DISABLE_LIGHTONOCR3_LOCAL_KERNELS','TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP')
needle='''                float *ys = (float *)y.contents + 4;'''
part=part.replace(needle,'''                if (r->lightonocr3_wide_gate_up_calls - before_wide != (mode == 1 ? 1u : 0u)) return 75;
'''+needle)
part=part.replace('"batch_gate_up rows=','"wide_gate_up rows=').replace('"batch_gate_up_benchmark rows=','"wide_gate_up_benchmark rows=')
s=s[:b]+'\n'+part+s[b:]
needle='''        if (argc == 2 && strcmp(argv[1], "--check-wide64") == 0) {'''
assert s.count(needle)==1
s=s.replace(needle,'''        if (argc == 2 && strcmp(argv[1], "--check-wide-gate-up") == 0) {
            const size_t rows[] = {32, 33, 48, 56, 63, 64};
            if (termite_metal_lightonocr3_batch_gate_up_pipeline(r, 31, 2560, 9216) != nil ||
                termite_metal_lightonocr3_batch_gate_up_pipeline(r, 65, 2560, 9216) != nil ||
                termite_metal_lightonocr3_batch_gate_up_pipeline(r, 64, 1536, 4096) != nil) return 136;
            for (size_t i = 0; i < sizeof(rows)/sizeof(rows[0]); ++i)
                for (size_t model = 0; model < 2; ++model) {
                    int rc = wide_gate_up_check(r, rows[i], model ? 2560 : 1024,
                                                model ? 9216 : 3584, false);
                    if (rc) {
                        fprintf(stderr, "WIDE_GATE_UP_FAIL rows=%zu model=%zu rc=%d\\\\n", rows[i], model, rc);
                        return 136;
                    }
                }
            termite_metal_decode_runtime_destroy(r);
            return 0;
        }
'''+needle)
s=s.replace('rc=%d\\\\n", rows[i], model, rc);','rc=%d\\n", rows[i], model, rc);')
p.write_text(s)
print('Added dedicated wide gate/up conformance; original narrow and planned-MPP suites unchanged.')
