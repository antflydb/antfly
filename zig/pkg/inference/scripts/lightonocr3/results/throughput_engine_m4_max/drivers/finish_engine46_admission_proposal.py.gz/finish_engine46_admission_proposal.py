from pathlib import Path
import hashlib,json,difflib
v=Path('.venv-lighton-vllm-metal');rel=Path('zig/pkg/inference/src/pipelines/reading.zig');snapshot=v/'engine46_source_snapshot'/rel
s=snapshot.read_text();a=s.index('fn nativeFlorenceIncrementalRunRequest(');b=s.index('\nfn admitFlorenceFullPrefixFallback(',a)
part=s[a:b];needle='    var request = try nativeFlorenceRunRequestForLogits('
assert part.count(needle)==1
part=part.replace(needle,'''    const Checked = struct {
        fn add(x: usize, y: usize) !usize {
            return std.math.add(usize, x, y) catch error.ResourceLimitExceeded;
        }
        fn mul(x: usize, y: usize) !usize {
            return std.math.mul(usize, x, y) catch error.ResourceLimitExceeded;
        }
    };
'''+needle)
part=part.replace('std.math.add(usize,','Checked.add(').replace('std.math.mul(usize,','Checked.mul(')
# Keep the arithmetic helper bodies as the primitive checked operations.
part=part.replace('return Checked.add( x, y) catch','return std.math.add(usize, x, y) catch')
part=part.replace('return Checked.mul( x, y) catch','return std.math.mul(usize, x, y) catch')
s=s[:a]+part+s[b:];s+=(v/'engine46_florence_admission_tests.inc').read_text();snapshot.write_text(s)
original=rel.read_text();expected=json.loads((v/'engine46-flores-admission-proposal-base.json').read_text())[str(rel)]
assert hashlib.sha256(original.encode()).hexdigest()==expected
patch=''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel)))
(v/'engine46_florence_incremental_admission_verify.patch').write_text(patch)
print('Finished offline proposal and four cap/fallback tests; actual runtime stays frozen engine45.')
