from pathlib import Path
import json,hashlib,re
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prod=r/'zig/pkg/inference/src/backends/metal_kernels.m';base=prod.read_text();s=base
needle='    id<MTLComputePipelineState> qwen35_recurrent_columns4_pipeline;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    uint64_t engine76_columns_calls;')
needle='            pipelines[3] = runtime->qwen35_recurrent_columns4_pipeline;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n            runtime->engine76_columns_calls++;')
(v/'engine76_probe_kernels.m').write_text(s)
a=base.index('           "template<uint C>inline void termite_qwen35_recurrent_columns_body');b=base.index('\n',base.index('           "kernel void termite_qwen35_recurrent_columns4',a))
parts=re.findall(r'"((?:[^"\\]|\\.)*)"',base[a:b]);body=''.join(json.loads('"'+x+'"')for x in parts)
header='#include <metal_stdlib>\nusing namespace metal;\nstruct termite_qwen35_params { uint seq,key_heads,value_heads,dim,kernel_size,initialized; };\n'
sources=[]
for variant in [1,2]:
 src=body.replace('memory+=s[i]*conv[kb+i]','memory=fma(s[i],conv[kb+i],memory)').replace('out+=s[i]*conv[qb+i]','out=fma(s[i],conv[qb+i],out)')
 if variant==1:src=src.replace('s[i]+=conv[kb+i]*delta','s[i]=fma(conv[kb+i],delta,s[i])')
 assert src!=body
 src=header+src.replace('termite_qwen35_recurrent_columns_body',f'engine76_body{variant}').replace('termite_qwen35_recurrent_columns4',f'engine76_fma{variant}')
 p=v/f'engine76_fma{variant}.metal';p.write_text(src);sources.append(src)
(v/'engine76_sources.inc').write_text('static NSString *engine76_sources[2] = {'+','.join('@'+json.dumps(x)for x in sources)+'};\n')
checker=(r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine76_probe_kernels.m"\nstatic id<MTLComputePipelineState> engine76_base,engine76_candidate;\nstatic unsigned engine76_variant;')
a=checker.index('static int prefill_core_check(');b=checker.index('\nstatic ',a+10);part=checker[a:b]
needle='''            if (variant == 0 || variant == 3)
                setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_CORE_NORM", "1", 1);
            else
                unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_CORE_NORM");'''
assert part.count(needle)==1;part=part.replace(needle,'''            r->qwen35_recurrent_columns4_pipeline = variant == 0 ? engine76_base : engine76_candidate;
            uint64_t columns_before=r->engine76_columns_calls;
            unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_CORE_NORM");''').replace('(variant == 1 && seq >= 128 ? 1 : 0)','(seq >= 128 ? 1 : 0)')
part=part.replace('            if (benchmark)\n                printf','            if(r->engine76_columns_calls-columns_before!=1)return 91;\n            if (benchmark)\n                printf')
part=part.replace(r'printf("{\"seq\":%zu,',r'printf("{\"candidate\":%u,\"seq\":%zu,').replace('                       seq, vh, initialized, trial, variant, elapsed / 1000.0,','                       engine76_variant, seq, vh, initialized, trial, variant, elapsed / 1000.0,')
checker=checker[:a]+part+checker[b:];(v/'engine76_probe_checks.m').write_text(checker)
(v/'engine76_fma_probe.m').write_text('''#define main engine76_unused_main
#include "engine76_probe_checks.m"
#undef main
#include "engine76_sources.inc"
int main(int argc,char**argv){@autoreleasepool{
 if(argc!=2)return 1;engine76_variant=(unsigned)strtoul(argv[1],NULL,10);if(engine76_variant<1||engine76_variant>2)return 2;
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 3;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 unsetenv("TERMITE_METAL_DISABLE_QWEN35_PREFILL_COLUMNS");setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY","1",1);
 MTLCompileOptions*opt=[MTLCompileOptions new];opt.languageVersion=MTLLanguageVersion3_1;opt.fastMathEnabled=NO;opt.mathMode=MTLMathModeSafe;NSError*err=nil;
 id<MTLLibrary>lib=[r->device newLibraryWithSource:engine76_sources[engine76_variant-1] options:opt error:&err];if(!lib){fprintf(stderr,"%s\\n",err.localizedDescription.UTF8String);return 4;}
 engine76_base=r->qwen35_recurrent_columns4_pipeline;engine76_candidate=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"engine76_fma%u",engine76_variant]);if(!engine76_base||!engine76_candidate)return 5;
 const size_t lengths[]={128,432,554,662,2048};
 for(size_t h=16;h<=32;h+=16)for(size_t i=0;i<5;i++)for(size_t initialized=0;initialized<2;initialized++){
  if(prefill_core_check(r,lengths[i],h,initialized,true))return 6;
 }
 fprintf(stderr,"FMA PROBE PASS candidate=%u\\n",engine76_variant);termite_metal_decode_runtime_destroy(r);return 0;
}}
''')
inputs={str(p.relative_to(r)):sha(p)for p in [v/'engine76_probe_kernels.m',v/'engine76_probe_checks.m',v/'engine76_fma_probe.m',v/'engine76_fma1.metal',v/'engine76_fma2.metal',v/'engine76_sources.inc']}
(v/'engine76_preparation.json').write_text(json.dumps(dict(production_c_sha256=sha(prod),inputs=inputs,scope='Isolated explicit F32 FMA recurrent-prefill prototype. Same canonical state/dtype, Safe compilation, changes F32 rounding. No runtime promotion inferred. Full output/state and all canaries, nonzero offsets, GPU conv/norm producers, initialized/uninitialized, actual columns4 selection, alternating 30 trials.'),indent=2)+'\n')
(v/'run_engine76_fma_probe.py').write_text('''from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time,psutil
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while 'ENGINE74 BURST64 DONE' not in Path('/private/tmp/ocr-engine74-burst64-parent.txt').read_text():time.sleep(5)
p=json.loads((v/'engine76_preparation.json').read_text());assert sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')==p['production_c_sha256'] and all(sha(r/f)==h for f,h in p['inputs'].items())
binary=v/'engine76_fma_probe';assert not binary.exists();audit=o/'engine76_fma_probe_audit.json';assert not audit.exists()
d=dict(status='running',primary_throughput_eligible=False,scope=p['scope'],preparation_sha256=sha(v/'engine76_preparation.json'),driver_sha256=sha(Path(__file__)),checks=[])
def save():audit.write_text(json.dumps(d,indent=2)+'\\n')
save();cmd=['clang','-O3','-fobjc-arc','-I','zig/pkg/inference/src/backends',str(v/'engine76_fma_probe.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(binary)]
with Path('/private/tmp/ocr-engine76-build.txt').open('w')as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
d.update(build_exit_code=result.returncode,build_command=cmd,build_log_sha256=sha('/private/tmp/ocr-engine76-build.txt'));save();assert result.returncode==0
d['binary_sha256']=sha(binary);save()
for candidate in [1,2]:
 available=psutil.virtual_memory().available;need=512*1024**2;reserve=6*1024**3
 assert available>=need+reserve,(available,need,reserve)
 log=Path(f'/private/tmp/ocr-engine76-fma{candidate}.txt');print('START FMA',candidate,flush=True)
 with log.open('w')as f:result=subprocess.run([str(binary),str(candidate)],stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,ANTFLY_LIGHTONOCR3_THROUGHPUT='0'),timeout=900)
 text=log.read_text();records=[json.loads(x)for x in text.splitlines()if x.startswith('{"candidate":')]
 d['checks'].append(dict(candidate=candidate,exit_code=result.returncode,records=records,log=str(log),log_sha256=sha(log),available_bytes=available,working_estimate_bytes=need,os_reserve_bytes=reserve));save();assert result.returncode==0 and len(records)==1200 and f'FMA PROBE PASS candidate={candidate}' in text
 print('DONE FMA',candidate,len(records),flush=True)
d['status']='pass';save();print('ENGINE76 FMA PROBE DONE',flush=True)
''')
print('prepared F32 explicit-FMA prefill probes; no production edits')
