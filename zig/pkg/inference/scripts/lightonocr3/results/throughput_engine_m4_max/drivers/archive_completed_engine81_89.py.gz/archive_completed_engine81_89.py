from pathlib import Path
import subprocess,sys,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
for f in ['paired72_08_comparison_audit.json','paired72_florence_comparison_audit.json','paired73_4b_comparison_audit.json']:
 d=json.loads((o/f).read_text());assert d['status']not in ['running','preparing'],f
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine81_*','engine85_*','vllm_4b_primary_reference70_*','vllm_4b_primary_reference73_*','vllm_08_primary_reference72_*','mlx_florence_engine85_paired72_*'],check=True)
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
logs=[];drivers=[]
for tag in range(81,90):
 logs+=list(Path('/private/tmp').glob(f'ocr-engine{tag}-*.txt'));logs+=list(Path('/private/tmp').glob(f'ocr-run_engine{tag}_*.txt'))
 drivers += [p for p in v.glob(f'*engine{tag}*')if p.is_file()and p.suffix in ['.py','.m','.metal','.inc','.json','.patch','.zig']]
ns['archive']('qualification',sorted(set(logs)),'logs_manifest.json')
ns['archive']('drivers',sorted(set(drivers+[v/'engine86_MLX_LICENSE',Path('/private/tmp/prepare-ocr85.py'),Path('/private/tmp/prepare-ocr85-retry.py'),Path('/private/tmp/prepare-ocr85-primary.py'),Path('/private/tmp/prepare-ocr86-retry.py')])),'drivers_manifest.json')
print('Archived closed81–89 reports, logs and reproducible sources',flush=True)
