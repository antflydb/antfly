from pathlib import Path
import json,hashlib,subprocess
v=Path('.venv-lighton-vllm-metal')
frozen=json.loads((v/'engine42-freeze.json').read_text())
for name,h in frozen.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h,name
cmd=['clang','-O3','-fobjc-arc','zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m','-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(v/'engine42_conformance')]
with Path('/private/tmp/ocr-engine42-c-build.txt').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0,r.returncode
print('compiled',v/'engine42_conformance')
