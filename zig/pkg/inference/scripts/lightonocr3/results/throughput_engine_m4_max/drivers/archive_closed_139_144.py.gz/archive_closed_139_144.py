from pathlib import Path
import json,hashlib,gzip
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n in (142,143,144):
 a=o/(f'engine{n}_projection_audit.json'if n==144 else f'engine{n}_short_prefill_audit.json');assert 'pass_no_'in json.loads(a.read_text())['status']
assert json.loads((o/'engine139_chunk141_screen_audit.json').read_text())['status']=='screen_retired_four_profiles_completed_no_promotion'
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
logs=[p for n in range(139,145)for p in Path('/private/tmp').glob(f'ocr-engine{n}-*.txt')]
# Preserve exact executed smoke verifier recovered and hash-verified separately.
drivers=[p for p in v.iterdir()if p.is_file()and p.suffix in ('.py','.json','.m','.metal','.zig','.patch')and (any(f'engine{n}'in p.name for n in range(139,145))or p.name=='prepare_engine143_144.py')]
ns['archive']('qualification',logs,'logs_manifest.json');ns['archive']('drivers',drivers+[Path(__file__)],'drivers_manifest.json')
(o/'engine144_closed_archive_audit.json').write_text(json.dumps(dict(status='closed',logs={str(p):sha(p)for p in logs},drivers={str(p):sha(p)for p in drivers},scope='139 model smoke and retired four-profile screen;142 staged attention,143 direct attention,144 narrow prefill projections. All private probes isolated, no canonical C promotion or whole-model speed claim.'),indent=2)+'\n')
print('Archived',len(logs),'logs and',len(drivers),'drivers')
