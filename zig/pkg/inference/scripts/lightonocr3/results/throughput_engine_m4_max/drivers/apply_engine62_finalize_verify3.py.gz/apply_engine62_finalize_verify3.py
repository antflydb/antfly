from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();freeze=json.loads((v/'engine61-freeze.json').read_text())
changed={p for p,h in freeze.items()if sha(p)!=h};assert changed=={'zig/pkg/inference/src/models/gpt.zig','zig/pkg/inference/src/architectures/qwen3vl_projector.zig','zig/pkg/inference/src/ops/metal_compute.zig','zig/pkg/inference/src/server/server.zig','zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py'},changed
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
bench='zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py'
freeze={p:sha(p)for p in freeze};(v/'engine62-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
for src,dest in [('run_engine61_verify_gpu_build.py','run_engine62_verify_gpu_build.py'),('run_engine61_budget_policies.py','run_engine62_budget_policies.py'),('run_engine61_prefill8_profile.py','run_engine62_prefill8_profile.py'),('run_engine61_metal_disabled.py','run_engine62_metal_disabled.py'),('run_engine61_build_qualification.py','run_engine62_build_qualification.py')]:
 p=v/dest;assert not p.exists();p.write_text((v/src).read_text().replace('engine61','engine62'))
(v/'engine62_benchmark_concurrency.py').write_text(Path(bench).read_text())
p=v/'run_engine62_verify_gpu_build.py';s=p.read_text();s=once(s,"env.pop('TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP',None)","env['ANTFLY_LIGHTONOCR3_RESIDENT_VISION_BUDGET']='1'\nenv.pop('TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP',None)");p.write_text(s)
p=v/'run_engine62_budget_policies.py';s=p.read_text();a=" if large_vision_pack:cmd+=['--large-vision-pack-reuse']";s=once(s,a,a+"\n resident_vision=os.environ.get('OCR_RESIDENT_VISION_BUDGET','0')=='1'\n if resident_vision:cmd+=['--resident-vision-budget']");a="    workspace_mode=re.findall";pos=s.index(a);s=s[:pos]+"    values=re.findall(r'LIGHTONOCR3 resident_vision_budget=(\\d+)',section);assert values and all((int(x)==1)==resident_vision for x in values),(values,resident_vision)\n    report['resident_vision_budget']=resident_vision\n"+s[pos:];p.write_text(s)
print('engine62 frozen: explicit closed resident graph, conservative linear working bound, C and shaders unchanged')

p=v/'run_engine62_build_qualification.py';p.write_text(p.read_text().replace('ENGINE58 BUILD QUALIFICATION DONE','ENGINE62 BUILD QUALIFICATION DONE'))
