from pathlib import Path
import hashlib,json,re,statistics
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check_build(stem):
 p=out/f'{stem}_build_manifest.json';d=json.loads(p.read_text());assert d['exit_code']==0
 assert all(sha(Path(p))==s for p,s in d['input_sha256'].items())
 assert sha(Path(d['binary']))==d['binary_sha256']
 return dict(manifest=p.name,manifest_sha256=sha(p),binary_sha256=d['binary_sha256'])
tile=Path('/private/tmp/ocr-engine46-streamed-prefill-tiles-probe.txt')
if tile.exists():
 records=[]
 pat=r'LARGER_PREFILL rows=(\d+) in=(\d+) out=(\d+) layers=(\d+) variant=(\d+) on=(\d+) leg=(\d+) frame_gpu_us=([0-9.]+) projection_gpu_us=([0-9.]+) max_abs=([0-9.e+-]+) cpu_error=([0-9.e+-]+)'
 for m in re.finditer(pat,tile.read_text()):
  x=m.groups();r=dict(zip(['rows','in','out','layers','variant','on','leg'],map(int,x[:7])))
  r.update(zip(['frame_gpu_us','projection_gpu_us','max_abs','cpu_error'],map(float,x[7:])));records.append(r)
 assert len(records)==96,len(records)
 groups={}
 for r in records:
  assert r['layers']==32 and r['max_abs']<=2e-4 and r['cpu_error']<=2e-4
  groups.setdefault((r['rows'],r['in'],r['out'],r['variant']),[]).append(r)
 comparisons=[]
 for key,rs in sorted(groups.items()):
  assert len(rs)==4 and sorted(r['leg'] for r in rs)==[0,1,2,3]
  off=[r['frame_gpu_us'] for r in rs if not r['on']];on=[r['frame_gpu_us'] for r in rs if r['on']]
  assert len(off)==len(on)==2
  comparisons.append(dict(rows=key[0],in_dim=key[1],out_dim=key[2],variant=key[3],baseline_us=statistics.mean(off),candidate_us=statistics.mean(on),candidate_to_baseline=statistics.mean(on)/statistics.mean(off),both_candidate_legs_faster_than_both_control_legs=max(on)<min(off)))
 d=dict(status='pass',scope='Isolated representative streamed matrix probe, not full model throughput. 32 distinct weights per frame; full outputs/CPU corners/canaries/private producer; eight timed frames per ABBA leg. Runtime remains engine45.',build=check_build('engine46_streamed_prefill_tiles'),raw_log_sha256=sha(tile),records=records,comparisons=comparisons)
 (out/'engine46_streamed_prefill_tiles_audit.json').write_text(json.dumps(d,indent=2)+'\n')
 print('TILES',json.dumps(comparisons),flush=True)
for columns in [8,16]:
 p=Path(f'/private/tmp/ocr-engine46-prefill-columns{columns}-probe.txt')
 if not p.exists():continue
 # stdout JSON is buffered; ten unbuffered stderr conformance lines can
 # interrupt it mid-record in the combined log. Remove only that exact
 # independently checked stderr grammar, preserving every JSON byte.
 clean=re.sub(r'prefill_core_check seq=\d+ heads=\d+ initialized=1 max_abs=[0-9.e+-]+\n','',p.read_text())
 records=[json.loads(line) for line in re.findall(r'\{"columns":[^}]+\}',clean)]
 assert len({(r['seq'],r['heads'],r['trial'],r['mode']) for r in records})==600
 assert len(records)==600,(columns,len(records))
 checks=re.findall(r'prefill_core_check seq=(\d+) heads=(\d+) initialized=1 max_abs=([0-9.e+-]+)',p.read_text())
 assert len(checks)==10 and all(float(x[2])<=2e-4 for x in checks),checks
 groups={}
 for r in records:
  assert r['columns']==(columns if r['mode'] else 4)
  groups.setdefault((r['seq'],r['heads']),[]).append(r)
 comparisons=[]
 for (seq,heads),rs in sorted(groups.items()):
  off=[r['gpu_us'] for r in rs if r['mode']==0];on=[r['gpu_us'] for r in rs if r['mode']==1]
  assert len(off)==len(on)==30
  comparisons.append(dict(seq=seq,heads=heads,columns=columns,baseline_us=statistics.median(off),candidate_us=statistics.median(on),candidate_to_baseline=statistics.median(on)/statistics.median(off)))
 d=dict(status='pass',scope='Isolated recurrent prefill core. Both routes parallel norm; actual selection counter, full outputs/state, restored seed, offsets, canaries, GPU producers. CPU validation between frames can change clocks; these are diagnostic, not primary throughput.',build=check_build('engine46_prefill_columns_probe'),raw_log_sha256=sha(p),records=records,full_output_checks=checks,comparisons=comparisons)
 (out/f'engine46_prefill_columns{columns}_audit.json').write_text(json.dumps(d,indent=2)+'\n')
 print('COLUMNS',columns,json.dumps(comparisons),flush=True)
