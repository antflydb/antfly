from pathlib import Path
import json,hashlib,gzip
s=Path('.venv-lighton-vllm-metal/archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
folders=sorted(p.parent for p in out.glob('engine30_08_*/report.json'));assert len(folders)==5
archive('qualification',[Path('/private/tmp/ocr-engine30-small-profiles-driver.txt')]+[Path('/private/tmp/ocr-engine30-08-'+p.name.split('engine30_08_',1)[1]+'.txt')for p in folders],'logs_manifest.json')
records=[];index=out/'raw_logs_manifest.json';mapping=json.loads(index.read_text())
for folder in folders:
 p=folder/'report.json';d=json.loads(p.read_text());r=d['results'][0];sample=r['policy_rounds'][0];assert r['status']=='ok'and r['serial_reference_parity']and r['cross_runtime_content_parity']and not d['own_cpu_compile_overlap']and sample['completed']==128
 records.append(dict(report=str(p.relative_to(out)),report_sha256=sha(p),pages_per_second=sample['pages_per_second'],cpu_preprocess=d['cpu_preprocess'],vision_frame_blocks=d['vision_frame_blocks'],physical_rows=d['physical_rows'],shared_core_weights=d['shared_core_weights'],stream_first_layers=d['stream_first_layers'],prepared_blocks=sample['prepared_blocks'],executor_steps=sample['executor_steps'],stream_forward_splits=sample['stream_forward_splits'],admission_pressures=sample['admission_pressures'],completed=128,all_full_fixture_strings_equal=True))
 for p in folder.glob('*.txt'):
  raw=p.read_bytes();dest=p.with_name(p.name+'.gz');dest.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(dest.read_bytes())==raw;mapping[str(p.relative_to(out))]=dict(compressed_path=str(dest.relative_to(out)),raw_sha256=hashlib.sha256(raw).hexdigest(),raw_bytes=len(raw),compressed_sha256=sha(dest));p.unlink()
index.write_text(json.dumps(mapping,indent=2)+'\n');(out/'engine30_small_comparison_audit.json').write_text(json.dumps(dict(scope='Five complete native profiles, not yet a fresh repeated vLLM win. All stream profiles retain every prepared linear block; C32 has actual rows above16.',reports=records),indent=2)+'\n')
archive('drivers',[v/'archive_engine30_small.py',v/'run_engine30_paired10.py'],'drivers_manifest.json');print('archived',len(records))
