from pathlib import Path
import json,subprocess,sys,time
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');p=o/'paired55_4b_comparison_audit.json'
while True:
 parent=Path('/private/tmp/ocr-engine70-follow55-parent.txt');s=parent.read_text()if parent.exists()else''
 if 'Traceback'in s:raise RuntimeError(s[-2000:])
 if 'ENGINE70 PAIRED55 DONE'in s:break
 time.sleep(5)
d=json.loads(p.read_text())
names=['run_engine70_08_paired57.py','run_engine70_florence_paired57.py']if d['status']=='repeated_win'else['run_engine70_gpu_diagnostic56.py']
assert d['status']in['repeated_win','early_stop_forward_loss','native_behind'],d['status']
for name in names:
 print('START',name,flush=True)
 with Path('/private/tmp/ocr-'+name.removesuffix('.py')+'-parent.txt').open('w')as f:subprocess.run([sys.executable,str(v/name)],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
print('ENGINE70 FOLLOW56 DONE',flush=True)
