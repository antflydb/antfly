from pathlib import Path
import json,hashlib,gzip
s=Path('.venv-lighton-vllm-metal/archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
folders=sorted(p.parent for p in out.glob('engine31_florence_qualification*/report.json'));assert len(folders)==2
records=[];index=out/'raw_logs_manifest.json';mapping=json.loads(index.read_text())
for folder in folders:
 p=folder/'report.json';d=json.loads(p.read_text());r=d['results'][0];sample=r['policy_rounds'][0];assert r['status']=='ok'and r['serial_reference_parity']and r['cross_runtime_content_parity']and sample['completed']==16
 records.append(dict(report=str(p.relative_to(out)),report_sha256=sha(p),completed=16,full_fixture_string_identity=True,single_frame=r['florence_single_frame']))
 for p in folder.glob('*.txt'):
  raw=p.read_bytes();dest=p.with_name(p.name+'.gz');dest.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(dest.read_bytes())==raw;mapping[str(p.relative_to(out))]=dict(compressed_path=str(dest.relative_to(out)),raw_sha256=hashlib.sha256(raw).hexdigest(),raw_bytes=len(raw),compressed_sha256=sha(dest));p.unlink()
index.write_text(json.dumps(mapping,indent=2)+'\n')
audit=dict(selected=208,passed=207,skipped=1,leaked=0,actual_stream_splits=[0,20],requested_stream_layers=4,reader_checks=['preset16','physical32','feature_off'],c_qualification='engine31_c_qualification_audit.json',florence_on_off=records,freeze_sha256=sha(v/'engine31-freeze.json'),build_manifest_sha256=sha(out/'engine31_build_manifest.json'))
(out/'engine31_qualification_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
archive('qualification',list(Path('/private/tmp').glob('ocr-engine31-florence-qualification*.txt')),'logs_manifest.json')
archive('drivers',[v/'archive_engine31_qualification.py'],'drivers_manifest.json')
print('31 qualified, hash-bound and archived')
