from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import psutil
import re
import subprocess
import sys
import time

root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max'
(v/'engine65-close43-tune44.pid').write_text(str(os.getpid()))
start=time.monotonic()
while True:
    active=False
    for process in psutil.process_iter(['cmdline']):
        try:
            if any(str(x).endswith('/run_engine65_api_paired43.py') for x in (process.info['cmdline']or[])):active=True
        except(psutil.NoSuchProcess,psutil.AccessDenied):pass
    if not active:break
    if time.monotonic()-start>2000:raise TimeoutError('paired43 completion')
    time.sleep(2)

sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
original=json.loads((out/'paired43_4b_comparison_audit.json').read_text())
if len(original['comparisons'])==2:
    # Reuse the exact executed reference function, with a new unused C32 label.
    source=(v/'run_engine65_api_paired43.py').read_text()
    node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='reference')
    exec(ast.get_source_segment(source,node),globals())
    print('START C32 CLOSING REFERENCE before native concurrency search',flush=True)
    reference(1,32)
    report=dict(status='running',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Balanced A32/A64/B/B/A64/A32 comparison. Added closing C32 control before seeing either native result because forward C32/C64 references differ by only0.12%. Retain the faster measured reference separately on each side. Actual auto-sized cache capacity and different framework/native concurrency are explicit; no equal-concurrency kernel claim. Same original checkpoint, R128/max_tokens256, full fresh serial texts and uncached unique media. No own compile/profiling overlap.',source_comparison_audit_sha256=sha(out/'paired43_4b_comparison_audit.json'),driver_sha256=sha(Path(__file__)),comparisons=[],references=[])
    for index in (0,1):
        refs=[]
        for concurrency in (32,64):
            path=out/f'vllm_4b_primary_reference43_r{index}_auto_c{concurrency}_r128_ctx1024/report.json'
            data=json.loads(path.read_text())
            assert data['status']=='ok' and data['results'][0]['serial_reference_parity']
            assert data['results'][0]['completed']==128
            raw=(path.parent/'server.txt').read_text()
            capacities=re.findall(r'Maximum concurrency for 1,024 tokens per request: ([0-9.]+)x',raw)
            blocks=re.findall(r'Hybrid shared cache: (\d+) blocks',raw)
            assert capacities and blocks
            item=dict(round=index,concurrency=concurrency,pages_per_second=data['results'][0]['pages_per_second'],automatic_cache=True,cache_blocks=int(blocks[-1]),supported_context_concurrency=float(capacities[-1]),full_configured_concurrency_supported=float(capacities[-1])>=concurrency,report=str(path.relative_to(out)),report_sha256=sha(path))
            report['references'].append(item);refs.append((item,data))
        chosen,reference_data=max(refs,key=lambda x:x[0]['pages_per_second'])
        row=next(x for x in original['comparisons']if x['round']==index)
        native_path=out/row['native_report'];assert sha(native_path)==row['native_report_sha256']
        native=json.loads(native_path.read_text());result=native['results'][0];sample=result['policy_rounds'][0]
        assert result['status']=='ok' and result['serial_reference_parity'] and result['cross_runtime_content_parity']
        assert sample['completed']==128 and not sample['admission_pressures'] and sample['gpu_token_burst_max_width']==4
        assert {x['image_index']:x['text']for x in result['references']}=={x['image_index']:x['text']for x in reference_data['references']}
        a=sample['pages_per_second'];b=chosen['pages_per_second']
        report['comparisons'].append(dict(round=index,native_report=row['native_report'],native_report_sha256=sha(native_path),native_pages_per_second=a,best_reference=chosen,native_to_best_vllm_ratio=a/b,all_128_native_outputs_exact=True,primary_throughput_eligible=True))
    ratios=[x['native_to_best_vllm_ratio']for x in report['comparisons']]
    report['status']='clear_repeated_win'if min(ratios)>=1.05 else'small_repeated_lead'if min(ratios)>1 else'native_behind'
    dest=out/'paired43_4b_balanced_reference_audit.json';assert not dest.exists();dest.write_text(json.dumps(report,indent=2)+'\n')
    print('BALANCED COMPARISON',json.dumps(report),flush=True)
else:
    print('SKIP closing reference after predeclared forward stop',original['status'],flush=True)

print('START NATIVE CONCURRENCY44 after preceding GPU jobs finish',flush=True)
subprocess.run([sys.executable,str(v/'run_engine65_concurrency44.py')],check=True)
