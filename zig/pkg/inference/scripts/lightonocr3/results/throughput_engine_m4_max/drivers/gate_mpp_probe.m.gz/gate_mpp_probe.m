#define main production_checks_main
#include "../zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m"
#undef main
static int run_gate(termite_metal_decode_runtime*r,id<MTLComputePipelineState>p,size_t n,size_t sg,size_t rows,size_t in,size_t out,id<MTLBuffer>x,id<MTLBuffer>y,double*us){
 if(!p){uint64_t before=r->frame_gpu_nanos;if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_DECODE)||termite_metal_decode_runtime_apply_bf16_gate_up_device(r,0,1,(__bridge void*)x,16,rows,in,out,(__bridge void*)y,16)||termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r))return 1;*us=(r->frame_gpu_nanos-before)/1000.0;return 0;}
 id<MTLCommandBuffer>cb=[r->queue commandBuffer];id<MTLComputeCommandEncoder>e=[cb computeCommandEncoder];if(!e)return 2;termite_metal_linear_params params={(uint32_t)rows,(uint32_t)in,(uint32_t)out,0};
 [e setComputePipelineState:p];[e setBuffer:x offset:16 atIndex:0];[e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_weight_buffers[1] offset:0 atIndex:2];[e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:3];[e setBuffer:r->linear_bias_buffers[1] offset:0 atIndex:4];[e setBuffer:y offset:16 atIndex:5];[e setBytes:&params length:sizeof(params) atIndex:6];[e dispatchThreadgroups:MTLSizeMake(out/n,1,1) threadsPerThreadgroup:MTLSizeMake(sg*32,1,1)];[e endEncoding];[cb commit];[cb waitUntilCompleted];if(cb.status!=MTLCommandBufferStatusCompleted)return 3;*us=(cb.GPUEndTime-cb.GPUStartTime)*1e6;return 0;
}
static int probe_gate(termite_metal_decode_runtime*r,id<MTLComputePipelineState> __strong p[6],size_t rows,size_t in,size_t out){
 id<MTLBuffer>x=[r->device newBufferWithLength:(rows*in+4)*4 options:MTLResourceStorageModeShared],y=[r->device newBufferWithLength:(rows*out+12)*4 options:MTLResourceStorageModeShared];uint16_t*w=malloc(in*out*2);float*b=malloc(out*4),*gold=malloc(rows*out*4);if(!x||!y||!w||!b||!gold)return 1;float*v=(float*)x.contents+4,*got=(float*)y.contents+4;for(size_t i=0;i<rows*in;i++)v[i]=sinf(i*.013f)*.7f;
 double cpu[2][4]={0};uint32_t state=123;
 for(size_t slot=0;slot<2;slot++){
  for(size_t i=0;i<in*out;i++){state=state*1664525u+1013904223u;w[i]=round_bf16(((int)(state>>16)-32768)*.000001f);}for(size_t i=0;i<out;i++)b[i]=cosf(i*.019f+slot)*.2f;
  for(size_t corner=0;corner<4;corner++){size_t row=corner/2?rows-1:0,col=corner%2?out-1:0;double ref=b[col];for(size_t k=0;k<in;k++)ref+=(double)v[row*in+k]*expand_bf16(w[col*in+k]);cpu[slot][corner]=ref;}
  if(termite_metal_decode_runtime_prepare_linear_bf16(r,slot,(uint8_t*)w,in*out*2,b,in,out))return 2;
 }
 double us;if(run_gate(r,nil,0,0,rows,in,out,x,y,&us))return 3;memcpy(gold,got,rows*out*4);
 for(size_t corner=0;corner<4;corner++){size_t row=corner/2?rows-1:0,col=corner%2?out-1:0;double g=cpu[0][corner],u=cpu[1][corner];if(fabs(g/(1+exp(-g))*u-gold[row*out+col])>2e-4)return 4;}
 const size_t ns[6]={8,16,32,32,64,64},sgs[6]={1,1,1,2,2,4};
 for(size_t variant=0;variant<6;variant++)for(size_t round=0;round<4;round++){
  bool on=round==1||round==2;double total=0;float worst=0;
  for(size_t trial=0;trial<8;trial++){
   for(size_t i=0;i<4;i++)((uint32_t*)y.contents)[i]=0xdeadbeef;for(size_t i=rows*out+4;i<rows*out+12;i++)((uint32_t*)y.contents)[i]=0xcafebabe;
   if(run_gate(r,on?p[variant]:nil,ns[variant],sgs[variant],rows,in,out,x,y,&us))return 5;total+=us;
   for(size_t i=0;i<rows*out;i++){if(!isfinite(got[i]))return 6;worst=fmaxf(worst,fabsf(got[i]-gold[i]));}
   for(size_t i=0;i<4;i++)if(((uint32_t*)y.contents)[i]!=0xdeadbeef)return 7;for(size_t i=rows*out+4;i<rows*out+12;i++)if(((uint32_t*)y.contents)[i]!=0xcafebabe)return 8;
  }
  if(worst>2e-4)return 9;fprintf(stderr,"GATE_MPP rows=%zu in=%zu out=%zu variant=%zu on=%d round=%zu gpu_us=%.3f max_abs=%g\n",rows,in,out,variant,on,round,total/8,worst);
 }
 free(w);free(b);free(gold);return 0;
}
int main(void){@autoreleasepool{
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 NSError*err=nil;NSString*source=[NSString stringWithContentsOfFile:@".venv-lighton-vllm-metal/gate_mpp_probe.metal" encoding:NSUTF8StringEncoding error:&err];MTLCompileOptions*opts=[MTLCompileOptions new];opts.fastMathEnabled=NO;opts.languageVersion=MTLLanguageVersion4_0;id<MTLLibrary>lib=[r->device newLibraryWithSource:source options:opts error:&err];if(!lib){fprintf(stderr,"MSL_ERROR %s\n",err.description.UTF8String);return 2;}id<MTLComputePipelineState>p[6];for(size_t i=0;i<6;i++){p[i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"gate_mpp_%zu",i]);if(!p[i])return 3;}
 const size_t rows[]={4,8,9,12,16};for(size_t i=0;i<5;i++)for(size_t model=0;model<2;model++){int rc=probe_gate(r,p,rows[i],model?2560:1024,model?9216:3584);if(rc){fprintf(stderr,"GATE_PROBE_FAIL rows=%zu model=%zu rc=%d\n",rows[i],model,rc);return 10+rc;}}
 termite_metal_decode_runtime_destroy(r);
}return 0;}
