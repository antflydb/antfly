from pathlib import Path
import hashlib,json,subprocess,sys,time
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
p=Path('/private/tmp/ocr-engine52-verify-gpu-build-driver.txt')
marker='qualified bounded batched prefill and matched CPU scratch lifetimes'
print('WAIT engine52 native GPU build',flush=True)
while True:
 s=p.read_text()if p.exists()else''
 if marker in s:break
 if 'exit 1'in s or'Traceback'in s:raise RuntimeError('native build/check failure; preserve logs and stop')
 time.sleep(5)
def freeze():
 for name,h in json.loads((v/'engine52-freeze.json').read_text()).items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h,name
def archive(paths):
 ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
 ns['archive']('qualification',paths,'logs_manifest.json')
def run(label,cmd):
 print('START',label,flush=True);log=Path('/private/tmp/ocr-'+label+'.txt');assert not log.exists()
 with log.open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 archive([log]);print('DONE',label,r.returncode,flush=True);assert r.returncode==0,(label,r.returncode)
freeze()
run('engine52-finalize-driver',[sys.executable,str(v/'finalize_engine_build.py'),'engine52','/private/tmp/ocr-engine52-verify-gpu-build.txt'])
# PASS manifest and lossless full runtime patch now exist before any further work.
run('engine52-c-build-driver',[sys.executable,str(v/'build_engine52_conformance.py')])
run('engine52-c-checks-driver',[sys.executable,str(v/'run_engine52_c_and_bind.py')])
run('engine52-functional-driver',[sys.executable,str(v/'run_engine52_functional.py')])
run('engine52-resource-qualification-driver',[sys.executable,str(v/'run_engine52_resource_cases.py'),'qualification'])
freeze();archive([Path('/private/tmp/ocr-engine52-verify-gpu-build-driver.txt')])
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine52_*qualification*'],check=True)
run('engine52-resource-primary-driver',[sys.executable,str(v/'run_engine52_resource_cases.py'),'primary'])
freeze();archive(list(Path('/private/tmp').glob('ocr-engine52-4b-*resource_dedup*.txt'))+list(Path('/private/tmp').glob('ocr-engine52-08-*resource_dedup*.txt')))
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine52_*resource_dedup*primary*'],check=True)
print('COMPLETE',flush=True)
