from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal'
for kind in ['kernels','checks','probe']:
 s=(v/f'engine107_wide_core_{kind}.m').read_text().replace('engine107','engine108').replace('WIDE107','WIDE108').replace('WALL107','WALL108')
 if kind=='checks':
  needle='''    if (benchmark) {
        void *initial[64][15];''';assert s.count(needle)==1
  s=s.replace(needle,'''    if (benchmark) {
        // The correctness pass above keeps per-row guard bands. Timings use
        // exactly the contiguous projected/workspace layout of the model;
        // guard bands remain at each complete allocation's two boundaries.
        for(size_t k=0;k<4;k++) {
            const size_t j=input_columns[k];
            packed_inputs[k]=[r->device newBufferWithLength:(pages*counts[j]+8)*4 options:MTLResourceStorageModeShared];
            if(!packed_inputs[k])return 71;
            for(size_t i=0;i<4;i++)((uint32_t*)packed_inputs[k].contents)[i]=((uint32_t*)packed_inputs[k].contents)[pages*counts[j]+4+i]=0xdeadbeef;
            for(size_t page=0;page<pages;page++) {
                buffers[1][page][j]=packed_inputs[k];handles[1][page][j]=(__bridge void*)packed_inputs[k];offsets[1][page][j]=16+page*counts[j]*4;
            }
        }
        workspace=[r->device newBufferWithLength:(pages*(counts[9]+counts[10]+counts[11])+8)*4 options:MTLResourceStorageModeShared];
        joined=[r->device newBufferWithLength:(pages*counts[14]+8)*4 options:MTLResourceStorageModeShared];
        if(!workspace||!joined)return 72;
        for(size_t i=0;i<4;i++) {
            ((uint32_t*)workspace.contents)[i]=((uint32_t*)workspace.contents)[pages*(counts[9]+counts[10]+counts[11])+4+i]=0xdeadbeef;
            ((uint32_t*)joined.contents)[i]=((uint32_t*)joined.contents)[pages*counts[14]+4+i]=0xdeadbeef;
        }
        for(size_t page=0;page<pages;page++) {
            offsets[1][page][9]=16+page*counts[9]*4;
            offsets[1][page][10]=16+(pages*counts[9]+page*counts[10])*4;
            offsets[1][page][11]=16+(pages*(counts[9]+counts[10])+page*counts[11])*4;
            for(size_t j=9;j<=11;j++){buffers[1][page][j]=workspace;handles[1][page][j]=(__bridge void*)workspace;}
            buffers[1][page][14]=joined;handles[1][page][14]=(__bridge void*)joined;offsets[1][page][14]=16+page*counts[14]*4;
        }
        void *initial[64][15];''')
  needle='''        unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_RECURRENT_PARALLEL");
    }
''';assert s.count(needle)==1
  s=s.replace(needle,'''        for(size_t i=0;i<4;i++) {
            for(size_t k=0;k<4;k++) {size_t j=input_columns[k];if(((uint32_t*)packed_inputs[k].contents)[i]!=0xdeadbeef||((uint32_t*)packed_inputs[k].contents)[pages*counts[j]+4+i]!=0xdeadbeef)return 73;}
            if(((uint32_t*)workspace.contents)[i]!=0xdeadbeef||((uint32_t*)workspace.contents)[pages*(counts[9]+counts[10]+counts[11])+4+i]!=0xdeadbeef||((uint32_t*)joined.contents)[i]!=0xdeadbeef||((uint32_t*)joined.contents)[pages*counts[14]+4+i]!=0xdeadbeef)return 74;
        }
'''+needle)
 p=v/f'engine108_wide_core_{kind}.m';assert not p.exists();p.write_text(s)
d=json.loads((v/'engine107_wide_core_preparation.json').read_text());d['scope']+=' Source108Ckernelsbyteidentical107. Correctnesskeepsperrowguards;timingsrepacktodenseactualmodelprojected/workspaceviewswithouterallocationcanaries. Guarded107layoutwasnottheactualproductionCPUaliasvalidationtopology. Originalnarrowhelpercontrolretained. No modelclaim.';d['files_sha256']={str((v/f'engine108_wide_core_{k}.m').relative_to(r)):hashlib.sha256((v/f'engine108_wide_core_{k}.m').read_bytes()).hexdigest()for k in ['kernels','checks','probe']};(v/'engine108_wide_core_preparation.json').write_text(json.dumps(d,indent=2)+'\n')
s=(v/'run_engine107_wide_core_suppressed.py').read_text().replace('engine107','engine108').replace('WIDE107','WIDE108').replace('WALL107','WALL108').replace('WAIT107','WAIT108').replace('START107','START108').replace('PASS107','PASS108');(v/'run_engine108_wide_core_suppressed.py').write_text(s)
