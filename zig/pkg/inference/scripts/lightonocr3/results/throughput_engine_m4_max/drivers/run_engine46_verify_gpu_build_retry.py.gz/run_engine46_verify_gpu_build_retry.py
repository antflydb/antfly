from pathlib import Path
import subprocess,sys
s=Path('.venv-lighton-vllm-metal/engine5_gpu_tests.py').read_text();exec(s[:s.index('cmd=[str(')])
env.pop('TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP',None)
env['ANTFLY_LIGHTONOCR3_GPU_GREEDY_STREAM']='0'
env['TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP']='0'
env['ANTFLY_FLORENCE_CPU_PREPROCESS']='0'
env['ANTFLY_TEST_OCR_RASTER_PARITY']='0'
env['TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP']='0'
env['ANTFLY_TEST_FLORENCE2_INCREMENTAL_FALLBACK']='0'
env['ANTFLY_FLORENCE2_INCREMENTAL_ADMISSION']='1'
env['ANTFLY_INFERENCE_READ_BATCH_SIZE']='16'
root=Path.cwd();env['ANTFLY_LIGHTONOCR3_PHYSICAL32']='0';env['ANTFLY_LIGHTONOCR3_PHYSICAL64']='1';env['ANTFLY_LIGHTONOCR3_WIDE_DECODE']='1';env['ANTFLY_LIGHTONOCR3_BATCH_ROWS']='64';env['ANTFLY_LIGHTONOCR3_BATCH_WINDOW']='64'
env['ANTFLY_LIGHTONOCR3_LOGICAL64']='1'
env['ANTFLY_OCR_ENCODER_SCOPES']='1'
env['ANTFLY_LIGHTONOCR3_DEVICE_RECURRENT_STATE']='1'
env['ANTFLY_LIGHTONOCR3_SHARED_DECODER_SCRATCH']='1'
env['ANTFLY_LIGHTONOCR3_PREFILL_BATCH']='1';env['ANTFLY_LIGHTONOCR3_PREFILL_BATCH_ITEMS']='2';env['ANTFLY_LIGHTONOCR3_VISION_BATCH_ITEMS']='2';env['ANTFLY_LIGHTONOCR3_CPU_PREPROCESS']='1'
env['ANTFLY_LIGHTONOCR3_EPOCH_AUX']='1'
env['ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS']='0'
env['ANTFLY_LIGHTONOCR3_BATCH_ATTENTION']='1'
env['ANTFLY_LIGHTONOCR3_EXTENDED_EPOCH']='1'
env['ANTFLY_LIGHTONOCR3_CONTENTION_WAIT_US']='1000'
env['TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS']='1'
env['ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS']='0'
env['ANTFLY_LIGHTONOCR3_SINGLE_FRAME']='1'
env.pop('TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS',None)
env['ANTFLY_LIGHTONOCR3_PREFILL_DECODE_STREAK']='0'
env['ANTFLY_LIGHTONOCR3_PREFILL_WAIT_US']='1000000'
env['ANTFLY_LIGHTONOCR3_VISION_FRAME_BLOCKS']='1'
env['ANTFLY_LIGHTONOCR3_PHASE_FAIR']='1'
env['ANTFLY_LIGHTONOCR3_PHASE_PARK']='1'
env['ANTFLY_LIGHTONOCR3_EXECUTOR_TAIL']='1'
env['ANTFLY_LIGHTONOCR3_COMPACT_KV']='1'
env['ZIG_GLOBAL_CACHE_DIR']=str(root/'zig/.zig-cache/global')
filters=['LightOnOCR3','Qwen3-VL','batch decode context','execution lane','execution gate','projector residency','executor batch','coalesc','Florence','shared native provider','dynamic linear slot','decode GQA split','argmax','video buffer survives producer destruction','video Metal gather fences','native reader batching']
command=['/Users/ajroetker/bin/zig-0.17.0/zig','build','inference-test','-Doptimize=ReleaseFast','-Dstrip=true',*[f'-Dtest-filter={x}'for x in filters]]
with open('/private/tmp/ocr-engine46-verify-gpu-build-retry.txt','w')as out:r=subprocess.run(command,cwd=root/'zig',env=env,stdout=out,stderr=subprocess.STDOUT)
print('exit',r.returncode)
if r.returncode==0:
 import re
 log=Path('/private/tmp/ocr-engine46-verify-gpu-build-retry.txt').read_text()
 matches=re.findall(r'attention_batch_calls=(\d+) attention_batch_rows=(\d+)',log)
 kernels=re.findall(r'attention_batch_kernel_calls=(\d+)',log)
 assert matches and any(int(x)>0 and int(y)>=2*int(x) for x,y in matches),matches
 assert kernels and any(int(x)>0 for x in kernels),kernels
 print('qualified production batch attention counters',matches,kernels)
 pack=re.findall(r'prefill_pack_calls=(\d+) prefill_pack_reuse_hits=(\d+)',log)
 assert pack and any(int(x)>0 for x,y in pack),pack
 print('qualified prefill pack acquisitions and hits',pack)
if r.returncode==0:
 for scope in ['decode','vision']:
  counters=re.findall(scope+r'_pack_calls=(\d+) '+scope+r'_pack_reuse_hits=(\d+)',log)
  assert counters and all(int(y)<=int(x)for x,y in counters), (scope,counters)
  if scope=='vision':assert any(int(x)>0 and int(y)>0 for x,y in counters),(scope,counters)
  print('qualified',scope,'pack reuse',counters)
if r.returncode==0:
 splits=re.findall(r'stream_forward_splits=(\d+) stream_first_layers=(\d+)',log)
 assert splits and all(int(x)==0 and int(y)==0 for x,y in splits),splits
 print('qualified single-frame streaming disabled',splits)
if r.returncode==0:
 mpp=re.findall(r'mpp_planned_calls=(\d+) mpp_dedicated_calls=(\d+)',log)
 assert mpp and any(int(x)+int(y)>0 for x,y in mpp),mpp
 print('qualified actual MPP encoder counters',mpp)
if r.returncode==0:
 scopes=re.findall(r'token_encoder_scope_steps=(\d+)',log)
 frames=re.findall(r'single_frame_steps=(\d+) single_frame_topology_mismatches=(\d+)',log)
 assert scopes and frames and sum(map(int,scopes))>0 and sum(map(int,scopes))==sum(int(x)for x,y in frames) and all(int(y)==0 for x,y in frames),(scopes,frames)
 print('qualified token encoder scopes and exact single-frame topology',scopes,frames)
if r.returncode==0:
 recurrent=re.findall(r'device_recurrent_state=(\d+) recurrent_cache_pages=(\d+) host_recurrent_bytes_total=(\d+)',log)
 assert recurrent and all(int(a)==1 and int(b)>0 and int(c)==0 for a,b,c in recurrent),recurrent
 print('qualified GPU-only recurrent state with zero CPU matrices',recurrent)
if r.returncode==0:
 shared=re.findall(r'shared_decoder_scratch=(\d+) shared_decoder_peak_bytes=(\d+) peak_segments=(\d+)',log)
 assert shared and all(int(a)==1 and int(b)>0 and int(c)>0 for a,b,c in shared),shared
 assert log.count('decoder_scratch_release_after_backend=1')==len(shared),(shared,log.count('decoder_scratch_release_after_backend=1'))
 print('qualified shared decoder working-set owner and backend-first release',shared)
if r.returncode==0:
 scopes=re.findall(r'vision_encoder_scope_opens=(\d+) prefill_encoder_scope_opens=(\d+)',log)
 assert scopes and all(int(a)>0 and int(b)>0 for a,b in scopes),scopes
 print('qualified actual vision and prefill encoder scope entry',scopes)
if r.returncode==0:
 groups=re.findall(r'prefill_batch_items=(\d+) query_tokens=(\d+)',log)
 hosts=re.findall(r'prefill_host_scratch_acquisitions=(\d+) prefill_host_scratch_releases=(\d+) prefill_host_scratch_peak_bytes=(\d+)',log)
 assert groups and all(1<=int(n)<=2 for n,t in groups),groups
 assert hosts and all(int(a)==int(b)and int(c)>0 for a,b,c in hosts),hosts
 print('qualified bounded batched prefill and matched CPU scratch lifetimes',groups,hosts)
sys.exit(r.returncode)
