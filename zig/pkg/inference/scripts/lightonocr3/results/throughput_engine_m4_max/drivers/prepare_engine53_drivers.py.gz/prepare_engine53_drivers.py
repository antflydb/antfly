from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine48_verify_gpu_build.py').read_text().replace('engine48','engine53')
s=s.replace("env['ANTFLY_LIGHTONOCR3_GPU_GREEDY_STREAM']='0'","env['ANTFLY_LIGHTONOCR3_GPU_GREEDY_STREAM']='1'\nenv['ANTFLY_LIGHTONOCR3_STREAM_CHUNKS']='1'")
s=s.replace("env['ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS']='0'","env['ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS']='4'").replace("env['ANTFLY_LIGHTONOCR3_SINGLE_FRAME']='1'","env['ANTFLY_LIGHTONOCR3_SINGLE_FRAME']='0'")
a=s.index(' assert splits and');b=s.index("if r.returncode==0:\n mpp",a)
s=s[:a]+" assert splits and all(int(y)==4 for x,y in splits) and any(int(x)>0 for x,y in splits),splits\n print('qualified rolling layer chunks',splits)\n"+s[b:]
a=s.index(" frames=re.findall");b=s.index("if r.returncode==0:\n recurrent",a)
s=s[:a]+''' steps=re.findall(r'LIGHTONOCR3 gpu_greedy_stream_steps=(\\d+)',log)
 mismatches=re.findall(r'LIGHTONOCR3 gpu_greedy_stream_topology_mismatches=(\\d+)',log)
 multi=re.findall(r'LIGHTONOCR3 gpu_greedy_stream_multi_frame_steps=(\\d+)',log)
 submits=re.findall(r'LIGHTONOCR3 gpu_greedy_stream_frame_submits=(\\d+)',log)
 total=lambda xs:sum(map(int,xs))
 assert steps and scopes and total(steps)>0 and total(scopes)==total(steps),(scopes,steps)
 assert mismatches and total(mismatches)==0 and multi and total(multi)>0,(mismatches,multi)
 assert submits and total(submits)==total(steps)+sum(int(x) for x,y in splits),(submits,steps,splits)
 print('qualified multi-frame topology and one token scope',steps,multi,submits)
'''+s[b:]
(v/'run_engine53_verify_gpu_build.py').write_text(s)
for old,new in [('build_engine46_conformance_retry.py','build_engine53_conformance.py'),('run_engine46_c_qualification.py','run_engine53_c_qualification.py'),('run_engine46_c_and_bind.py','run_engine53_c_and_bind.py')]:
 s=(v/old).read_text().replace('engine46-freeze_retry','engine53-freeze').replace('build_engine46_conformance_retry','build_engine53_conformance').replace('engine46','engine53').replace('ocr-engine53-verify-gpu-build-retry','ocr-engine53-verify-gpu-build')
 (v/new).write_text(s)
for old in ['run_engine48_functional.py','engine48_verify_preset_only_test.py','engine48_verify_preset_physical32_test.py','engine48_verify_default_gpu_test.py']:
 (v/old.replace('engine48','engine53')).write_text((v/old).read_text().replace('engine48','engine53'))
files=json.loads((v/'engine48-freeze.json').read_text())
(v/'engine53-freeze.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files},indent=2)+'\n')
(v/'engine53_benchmark_concurrency.py').write_bytes(Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
for p in v.glob('*engine53*.py'):compile(p.read_text(),str(p),'exec')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('drivers',list(v.glob('*engine53*.py'))+list(v.glob('engine53*.inc'))+[v/'engine53-freeze.json'],'drivers_manifest.json')
print('frozen',len(files))
