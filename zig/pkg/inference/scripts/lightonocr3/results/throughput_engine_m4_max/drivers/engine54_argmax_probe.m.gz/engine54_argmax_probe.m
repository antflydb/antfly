#include "engine54_argmax_runtime.m"
#include "engine54_argmax_source.inc"
#include <time.h>
static id<MTLComputePipelineState> partial54,reduce54;
static double now54(void){struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);return ts.tv_sec+ts.tv_nsec*1e-9;}
static int encode54(termite_metal_decode_runtime*r,id<MTLBuffer>input,size_t offset,size_t rows,size_t dim,id<MTLBuffer>suppress,size_t count,int mode){
 id<MTLComputeCommandEncoder>e=r->active_planned_compute_encoder;
 size_t blocks=(dim+1023)/1024,bytes=rows*blocks*4;
 if(!e||termite_metal_decode_runtime_reserve_argmax_rows(r,rows,dim))return 1;
 if(!mode){for(size_t row=0;row<rows;row++)if(termite_metal_encode_argmax_logits_suppress_on_encoder_at(r,e,input,offset+row*dim*4,dim,suppress,count,row*4,row*blocks*4,-2))return 2;return 0;}
 termite_metal_planned_encoder_range ranges[4];size_t n=0;
 if(termite_metal_planned_range_make(input,offset,rows*dim*4,TERMITE_METAL_PLANNED_RANGE_READ,&ranges[n++],-3))return 3;
 if(count&&termite_metal_planned_range_make(suppress,0,count*4,TERMITE_METAL_PLANNED_RANGE_READ,&ranges[n++],-3))return 3;
 if(termite_metal_planned_range_make(r->sample_topk_values_buffer,0,bytes,TERMITE_METAL_PLANNED_RANGE_WRITE,&ranges[n++],-3)||termite_metal_planned_range_make(r->sample_topk_ids_buffer,0,bytes,TERMITE_METAL_PLANNED_RANGE_WRITE,&ranges[n++],-3)||termite_metal_decode_runtime_prepare_planned_compute_accesses(r,ranges,n,-3))return 3;
 uint32_t p[]={dim,count,0,0},block_count=blocks;
 [e setComputePipelineState:partial54];[e setBuffer:input offset:offset atIndex:0];[e setBuffer:suppress offset:0 atIndex:1];[e setBuffer:r->sample_topk_values_buffer offset:0 atIndex:2];[e setBuffer:r->sample_topk_ids_buffer offset:0 atIndex:3];[e setBytes:p length:sizeof(p) atIndex:4];[e setThreadgroupMemoryLength:1024 atIndex:0];[e setThreadgroupMemoryLength:1024 atIndex:1];[e dispatchThreadgroups:MTLSizeMake(blocks,rows,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];
 if(termite_metal_planned_range_make(r->sample_topk_values_buffer,0,bytes,TERMITE_METAL_PLANNED_RANGE_READ,&ranges[0],-4)||termite_metal_planned_range_make(r->sample_topk_ids_buffer,0,bytes,TERMITE_METAL_PLANNED_RANGE_READ,&ranges[1],-4)||termite_metal_planned_range_make(r->token_buffer,0,rows*4,TERMITE_METAL_PLANNED_RANGE_WRITE,&ranges[2],-4)||termite_metal_decode_runtime_prepare_planned_compute_accesses(r,ranges,3,-4))return 4;
 [e setComputePipelineState:reduce54];[e setBuffer:r->sample_topk_values_buffer offset:0 atIndex:0];[e setBuffer:r->sample_topk_ids_buffer offset:0 atIndex:1];[e setBuffer:r->token_buffer offset:0 atIndex:2];[e setBytes:&block_count length:4 atIndex:3];[e dispatchThreads:MTLSizeMake(rows,1,1) threadsPerThreadgroup:MTLSizeMake(MIN(rows,(size_t)32),1,1)];return 0;
}
static int frame54(termite_metal_decode_runtime*r,id<MTLBuffer>input,id<MTLBuffer>source,size_t rows,size_t dim,id<MTLBuffer>suppress,size_t count,int mode,double*gpu,double*encode){
 if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_OTHER,TERMITE_METAL_COMPUTE_REGION_OTHER))return 10;
 double t=now54();
 if(source&&termite_metal_buffer_slice_last_dim_2d(r,(__bridge void*)source,16,1,rows*dim,0,rows*dim,(__bridge void*)input,16))return 11;
 int rc=encode54(r,input,16,rows,dim,suppress,count,mode);if(rc)return 20+rc;
 id<MTLCommandBuffer>cb=r->active_frame_cb;
 if(termite_metal_decode_runtime_submit_frame(r))return 30;
 if(encode)*encode+=now54()-t;
 if(termite_metal_decode_runtime_wait_frame(r))return 31;
 if(gpu)*gpu+=cb.GPUEndTime-cb.GPUStartTime;
 return 0;
}
static uint32_t gold54(float*x,size_t dim,int32_t*sup,size_t n){float best=-INFINITY;uint32_t id=0;for(size_t i=0;i<dim;i++){bool skip=false;for(size_t j=0;j<n;j++)if(sup[j]>=0&&(size_t)sup[j]==i)skip=true;if(!skip&&(x[i]>best||(x[i]==best&&i<id))){best=x[i];id=i;}}return id;}
int main(void){@autoreleasepool{
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;
 NSError*err=nil;id<MTLLibrary>lib=[r->device newLibraryWithSource:engine54_source() options:nil error:&err];if(!lib){fprintf(stderr,"MSL %s\n",err.description.UTF8String);return 2;}
 partial54=termite_metal_make_pipeline(r->device,lib,@"engine54_partials");reduce54=termite_metal_make_pipeline(r->device,lib,@"engine54_reduce");if(!partial54||!reduce54)return 3;
 size_t row_cases[]={1,2,16,33,64},dims[]={1,1023,1024,1025,248320};int32_t sup[]={-1,2,1024};
 id<MTLBuffer>suppress=[r->device newBufferWithBytes:sup length:sizeof(sup) options:MTLResourceStorageModeShared];
 for(size_t ri=0;ri<5;ri++)for(size_t di=0;di<5;di++)for(size_t count=0;count<=3;count+=3){
  size_t rows=row_cases[ri],dim=dims[di],bytes=(rows*dim+8)*4;
  id<MTLBuffer>src=[r->device newBufferWithLength:bytes options:MTLResourceStorageModeShared],input=[r->device newBufferWithLength:bytes options:MTLResourceStorageModePrivate];if(!src||!input)return 4;
  float*x=src.contents;for(size_t i=0;i<rows*dim+8;i++)x[i]=sinf((float)(i%10007)*.031f);x+=4;
  for(size_t row=0;row<rows;row++){size_t off=row*dim;x[off]=row%3==0?NAN:-INFINITY;if(dim>7){x[off+2]=100;x[off+3]=100;x[off+7]=INFINITY;}if(dim>1025){x[off+1024]=INFINITY;x[off+1025]=INFINITY;}}
  uint32_t original[64];
  for(int mode=0;mode<2;mode++){
   int rc=frame54(r,input,src,rows,dim,suppress,count,mode,NULL,NULL);if(rc){fprintf(stderr,"case rc=%d rows=%zu dim=%zu count=%zu mode=%d\n",rc,rows,dim,count,mode);return rc;}
   uint32_t*t=r->token_buffer.contents;
   for(size_t row=0;row<rows;row++){uint32_t expected=gold54(x+row*dim,dim,sup,count);if(t[row]!=expected||(mode&&t[row]!=original[row])){fprintf(stderr,"mismatch rows=%zu dim=%zu count=%zu row=%zu mode=%d got=%u gold=%u old=%u\n",rows,dim,count,row,mode,t[row],expected,original[row]);return 40;}if(!mode)original[row]=t[row];}
  }
  fprintf(stderr,"CHECK rows=%zu dim=%zu suppress=%zu GPUproducer=pass CPU=pass legacy=pass\n",rows,dim,count);
  if(dim==248320&&rows>=16&&count==3){
   for(int trial=0;trial<4;trial++)for(int leg=0;leg<4;leg++){
    int mode=(leg==0||leg==3)?1:0;double gpu=0,encode=0,t=now54();
    for(int it=0;it<40;it++){int rc=frame54(r,input,NULL,rows,dim,suppress,count,mode,&gpu,&encode);if(rc)return rc;}
    fprintf(stderr,"TIME rows=%zu dim=%zu trial=%d leg=%d mode=%d frames=40 gpu_ms=%.9f encode_ms=%.9f wall_ms=%.9f\n",rows,dim,trial,leg,mode,gpu*1000,encode*1000,(now54()-t)*1000);
   }
  }
 }
 termite_metal_decode_runtime_destroy(r);fprintf(stderr,"ENGINE54 PROBE PASS\n");return 0;
}}
