from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
import psutil
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while 'ENGINE73D CPU DIAGNOSTIC DONE' not in Path('/private/tmp/ocr-engine73d-queue-parent.txt').read_text():time.sleep(5)
print('START ISOLATED CORE PROBE AFTER ALL PRIMARY TIMINGS',flush=True)
subprocess.run([sys.executable,str(v/'build_engine75_recurrent_probe.py')],check=True)
m=json.loads((o/'engine75_recurrent_probe_build_manifest.json').read_text());assert sha(m['binary'])==m['binary_sha256']
audit=o/'engine75_recurrent_probe_audit.json';assert not audit.exists();d=dict(status='running',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Value-major F32 persistent-state layout prototype only; no runtime interop qualification. Full logical state/output comparisons after ten continued steps and all canaries. ABBA 24-layer working sets; not primary throughput evidence and not promotable without full layout interoperability qualification.',primary_throughput_eligible=False,binary_sha256=m['binary_sha256'],checks=[])
def save():audit.write_text(json.dumps(d,indent=2)+'\n')
save()
counts=[8192,8192*4,32,32,32,32,8192*4,8192*4,32*128*128,8192,64,4096,4096,128,4096];writes=[7,8,9,10,11,14]
for pages in [0,33,48,64]:
 need=24*pages*4*(sum(counts)+15*8+sum(counts[i]for i in writes))+256*1024**2
 available=psutil.virtual_memory().available;reserve=6*1024**3
 row=dict(pages=pages,available_bytes=available,working_plus_gold_estimate_bytes=need,os_reserve_bytes=reserve)
 if available<need+reserve:
  row.update(status='skipped_before_allocation',reason='Keep original six-GiB reserve; insufficient actual available bytes.');d['checks'].append(row);save();print('SKIP MEMORY',row,flush=True);continue
 log=Path(f'/private/tmp/ocr-engine75-probe-pages{pages}.txt');env=dict(os.environ,ENGINE75_PAGES=str(pages),ANTFLY_LIGHTONOCR3_THROUGHPUT='0',TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY='1',TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP='0',TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP='0')
 print('START PROBE',pages,flush=True)
 with log.open('w')as f:result=subprocess.run([m['binary']],stdout=f,stderr=subprocess.STDOUT,env=env,timeout=900)
 row.update(status='pass'if result.returncode==0 else'failed',exit_code=result.returncode,log=str(log),log_sha256=sha(log));d['checks'].append(row);save()
 if result.returncode:d['status']='failed';save();raise SystemExit(result.returncode)
 text=log.read_text();assert text.count('LAYOUT PROTOTYPE READY mode=')==1
 records=[json.loads(x)for x in text.splitlines()if x.startswith('{"pages":')]
 if pages:assert len(records)==4 and all(x['pages']==pages and x['full_output_state_max_abs']<=2e-4 for x in records),(pages,len(records))
 row['records']=records;save();print('DONE PROBE',pages,len(records),flush=True)
d['status']='pass'if any(x.get('pages')==0 and x['status']=='pass'for x in d['checks'])else'insufficient_memory';save();print('ENGINE75 ISOLATED PROBE DONE',d['status'],flush=True)
