from pathlib import Path
import subprocess,sys,time,json,hashlib,os
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while True:
 s=Path('/private/tmp/ocr-engine79-qualification-parent.txt').read_text()
 if 'Traceback'in s:raise RuntimeError(s[-4000:])
 if 'ENGINE79 QUALIFICATION DONE'in s:break
 time.sleep(5)
# Preserve the preliminary binary and its exact source binding before changing GPT.
m=json.loads((o/'engine79_build_manifest.json').read_text());os.link(Path(m['binary_path']),v/'qualified-binaries/engine79-test');assert sha(v/'qualified-binaries/engine79-test')==m['binary_sha256']
manifest=json.loads((o/'engine70_c_build_manifest.json').read_text());inputs={p:sha(r/p)for p in manifest['input_sha256']}
(o/'engine79_c_build_manifest.json').write_text(json.dumps(dict(binary=str((v/'engine79_conformance').relative_to(r)),binary_sha256=sha(v/'engine79_conformance'),input_sha256=inputs),indent=2)+'\n')
subprocess.run([sys.executable,str(v/'prepare_engine80_dispatch_fix.py')],check=True)
assert all(sha(r/p)==h for p,h in inputs.items())
(o/'engine80_c_reuse_audit.json').write_text(json.dumps(dict(status='pass',scope='All nineteen engine79 C suites reused after exact source/header/checker/binary hashes. Engine80 changes only the GPT long-prompt FFN callback guard.',input_sha256=inputs,binary_sha256=sha(v/'engine79_conformance')),indent=2)+'\n')
for name,cmd in [('gpu',[sys.executable,str(v/'run_engine80_verify_gpu_build.py')]),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine80','/private/tmp/ocr-engine80-verify2-gpu-build.txt']),('cpu',[sys.executable,str(v/'run_engine80_metal_disabled.py')])]:
 print('START ENGINE80',name,flush=True)
 with Path('/private/tmp/ocr-engine80-'+name+'-parent.txt').open('w')as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 print('DONE ENGINE80',name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
print('ENGINE80 QUALIFICATION DONE',flush=True)
