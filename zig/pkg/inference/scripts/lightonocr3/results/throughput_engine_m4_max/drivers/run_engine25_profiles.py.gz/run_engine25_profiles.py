from pathlib import Path
import os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');base=os.environ.copy();base.update(OCR_REFERENCE_LABEL='_primary_reference8_r0_auto_c32_r128',OCR_PHYSICAL32='1',OCR_CONCURRENCY='32',OCR_REQUESTS='128',OCR_WIDE='1',OCR_SCRATCH_GIB='8',OCR_STREAM_FIRST='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1',OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_VISION_BATCH='0')
for label,sf,vf,wait in [('sf32_prefill100ms',1,1,100000),('vision4_prefill100ms',0,4,100000),('vision4_sf32_prefill1s',1,4,1000000)]:
 env=base.copy();env.update(OCR_SINGLE_FRAME=str(sf),OCR_VISION_FRAME_BLOCKS=str(vf),OCR_PREFILL_WAIT_US=str(wait))
 print('START',label,flush=True)
 r=subprocess.run([sys.executable,str(v/'run_engine25_policies.py'),'4b:'+label+'_f32_c32_r128_0'],env=env)
 print('DONE',label,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
