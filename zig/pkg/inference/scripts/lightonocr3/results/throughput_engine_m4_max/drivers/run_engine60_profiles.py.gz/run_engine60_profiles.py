from pathlib import Path
import subprocess,sys,os,json,collections,hashlib,time
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');records=[]
previous=json.loads((o/'engine59_profiles_verified_partial_audit.json').read_text());c64=next(x for x in previous['candidates']if x['settings']==[64,1,1,2,0,0,0]);assert c64['eligible'];assert hashlib.sha256((o/c64['report']).read_bytes()).hexdigest()==c64['report_sha256'];records=[dict(c64,compiled_runtime_reused_byte_identical=True)]
for c,p,vis,vf,sv,sp,q in [(56,6,1,2,0,0,0),(48,6,1,2,0,1,1),(40,8,1,2,0,1,1),(56,1,1,4,0,0,0)]:
 tag=f'queued_priority_v{vis}_sv{sv}_sp{sp}_q{q}'
 env=os.environ.copy();env.update(OCR_CASE_CONCURRENCY=str(c),OCR_CASE_PREFILL_ITEMS=str(p),OCR_CASE_VISION_FRAME_BLOCKS=str(vf),OCR_CASE_VISION_BATCH_ITEMS=str(vis),OCR_CASE_TAG=tag,OCR_BATCH_ARGMAX='1',OCR_CACHE_VISION_WORKSPACE='1',OCR_LARGE_VISION_PACK_REUSE=str(int(vis>1)),OCR_DEFER_VISION_SEAL=str(sv),OCR_DEFER_PREFILL_SEAL=str(sp),ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY=str(q),OCR_TIMEOUT='240')
 print('START',c,p,vis,vf,sv,sp,q,flush=True)
 r=subprocess.run([sys.executable,str(v/'run_engine60_prefill8_profile.py'),'4b','0'],env=env)
 print('DONE',c,p,vis,vf,sv,sp,q,r.returncode,flush=True)
 label=f'engine60_4b_rolling_chunks0_trial0_c{c}_p{p}_vf{vf}_r64_{tag}';report=o/label/'report.json'
 if r.returncode:
  assert report.exists(),label
  raw=report.parent/f'lighton4b-batch-c{c}.txt';text=raw.read_text()
  if 'admission_pressure='in text:reason='admission_pressure'
  elif 'Timeout'in text or 'DeadlineExceeded'in text:reason='runtime_timeout'
  else:raise RuntimeError((label,'unexpected failure'))
  records.append(dict(settings=[c,p,vis,vf,sv,sp,q],eligible=False,reason=reason,report=str(report.relative_to(o))))
 else:
  d=json.loads(report.read_text());s=d['results'][0]['policy_rounds'][0]
  assert d['queued_phase_priority']==bool(q) and s['completed']==64 and not s['admission_pressures']
  records.append(dict(settings=[c,p,vis,vf,sv,sp,q],eligible=True,pages_per_second=s['pages_per_second'],process_cpu_ms=s['process_cpu_ms'],average_decode_rows=s['average_decode_rows'],prefill_sizes=dict(collections.Counter(x['items']for x in s['prefill_batches'])),vision_sizes=dict(collections.Counter(s['vision_batch_sizes'])),report=str(report.relative_to(o)),report_sha256=hashlib.sha256(report.read_bytes()).hexdigest()))
 (o/'engine60_profiles_audit.json').write_text(json.dumps(dict(status='running',candidates=records),indent=2)+'\n')
(o/'engine60_profiles_audit.json').write_text(json.dumps(dict(status='pass',candidates=records),indent=2)+'\n')
print('ALL ENGINE60 PROFILES COMPLETE',flush=True)
