from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
(v/'engine73d-freeze.json').write_bytes((v/'engine71-freeze.json').read_bytes())
(v/'engine73d_benchmark_concurrency.py').write_bytes((v/'engine71_benchmark_concurrency.py').read_bytes())
(v/'run_engine73d_budget_policies.py').write_text((v/'run_engine71_budget_policies.py').read_text().replace('engine71','engine73d'))
s=(v/'run_engine71_verify2_gpu_build.py').read_text();s=s[:s.index('filters=')]+'''filters=['LightOnOCR3 real checkpoint transcribes']
command=['/Users/ajroetker/bin/zig-0.17.0/zig','build','inference-test','-Doptimize=ReleaseFast','-Dstrip=false',*[f'-Dtest-filter={x}'for x in filters]]
with open('/private/tmp/ocr-engine73d-gpu-build.txt','w')as out:r=subprocess.run(command,cwd=root/'zig',env=env,stdout=out,stderr=subprocess.STDOUT)
print('exit',r.returncode,flush=True)
assert r.returncode==0
'''
(v/'build_engine73d_diagnostic.py').write_text(s)
s=(v/'run_engine69_cpu_diagnostic53.py').read_text().replace('engine69','engine73d').replace('diagnostic53','diagnostic63').replace('paired52','paired59')
a=s.index("selected=json.loads");b=s.index("audit_path=",a)
s=s[:a]+"profiles=primary['profiles']; selected=profiles['wide']\n"+s[b:]
s=s.replace("run_engine73d_prefill_screen51.py","run_engine71_api_paired59.py").replace("fn=fn.replace('prefill_screen51','cpu_diagnostic63')", "fn=fn.replace('paired59','cpu_diagnostic63').replace('engine71','engine73d')")
s=s.replace("native('selected',0,oracle)","native('wide',0,oracle)")
(v/'run_engine73d_cpu_diagnostic63.py').write_text(s)
(v/'run_engine73d_queue.py').write_text('''from pathlib import Path
import time,subprocess,sys,json,hashlib
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';o=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
while not (o/'engine71_precision_screen62_audit.json').exists() or json.loads((o/'engine71_precision_screen62_audit.json').read_text())['status']=='running':time.sleep(5)
assert json.loads((o/'engine71_precision_screen62_audit.json').read_text())['status']=='pass'
for p,h in json.loads((v/'engine73d-freeze.json').read_text()).items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
for label,cmd in [('build',[sys.executable,str(v/'build_engine73d_diagnostic.py')]),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine73d','/private/tmp/ocr-engine73d-gpu-build.txt']),('sample',[sys.executable,str(v/'run_engine73d_cpu_diagnostic63.py')])]:
 print('START DEBUG DIAGNOSTIC',label,flush=True)
 with Path('/private/tmp/ocr-engine73d-'+label+'-parent.txt').open('w')as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE DEBUG DIAGNOSTIC',label,flush=True)
print('ENGINE73D CPU DIAGNOSTIC DONE',flush=True)
''')
print('prepared debug-symbol diagnostic; production unchanged')
