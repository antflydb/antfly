from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
p=v/'engine50_recurrent_probe.m';s=p.read_text();assert s.count('id<MTLComputePipelineState>*psos')==2
s=s.replace('id<MTLComputePipelineState>*psos','id<MTLComputePipelineState> __strong *psos')
(v/'engine50_recurrent_probe_verify2.m').write_text(s)
s=(v/'build_engine50_recurrent_probe.py').read_text().replace("engine50_recurrent_probe.m'","engine50_recurrent_probe_verify2.m'").replace("engine50_recurrent_probe'","engine50_recurrent_probe_verify2'").replace('engine50_recurrent_probe_build_manifest.json','engine50_recurrent_probe_build_verify2_manifest.json').replace('ocr-engine50-recurrent-probe-build.txt','ocr-engine50-recurrent-probe-build-verify2.txt')
(v/'build_engine50_recurrent_probe_verify2.py').write_text(s)
s=(v/'run_engine50_recurrent_probe.py').read_text().replace('engine50_recurrent_probe_build_manifest.json','engine50_recurrent_probe_build_verify2_manifest.json').replace('ocr-engine50-recurrent-probe-gpu.jsonl','ocr-engine50-recurrent-probe-gpu-verify2.jsonl').replace('ocr-engine50-recurrent-probe-gpu-stderr.txt','ocr-engine50-recurrent-probe-gpu-verify2-stderr.txt')
(v/'run_engine50_recurrent_probe_verify2.py').write_text(s)
record=dict(status='build_only_failure_corrected_no_gpu_run',initial_build_manifest_sha256=hashlib.sha256((out/'engine50_recurrent_probe_build_manifest.json').read_bytes()).hexdigest(),original_source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),corrected_source_sha256=hashlib.sha256((v/'engine50_recurrent_probe_verify2.m').read_bytes()).hexdigest(),change='Explicit __strong ownership on two pipeline-array function parameters; no shader/math/runtime change. Original failed build source/log/manifest preserved.')
(out/'engine50_recurrent_probe_build_retry_audit.json').write_text(json.dumps(record,indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('drivers',[v/n for n in ['prepare_engine50_recurrent_probe_verify2.py','engine50_recurrent_probe_verify2.m','build_engine50_recurrent_probe_verify2.py','run_engine50_recurrent_probe_verify2.py']],'drivers_manifest.json')
