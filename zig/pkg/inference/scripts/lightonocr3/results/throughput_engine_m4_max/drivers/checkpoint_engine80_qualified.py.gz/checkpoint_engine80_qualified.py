from pathlib import Path
import subprocess,sys,json,hashlib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();freeze=json.loads((v/'engine80-freeze.json').read_text());assert all(sha(r/p)==h for p,h in freeze.items())
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine80_08_paired67_*','vllm_08_primary_reference67_*','engine80_florence_paired67_*','mlx_florence_engine80_paired67_*','engine80_4b_ffn_screen68_enable0_wide_r0_*'],check=True)
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
logs=list(Path('/private/tmp').glob('ocr-engine79-*.txt'))
logs += [Path('/private/tmp')/x for x in ['ocr-engine80-qualification-parent.txt','ocr-engine80-gpu-parent.txt','ocr-engine80-finalize-parent.txt','ocr-engine80-cpu-parent.txt','ocr-engine80-verify2-gpu-build.txt','ocr-engine80-metal-disabled.txt','ocr-engine80-finalqualification-parent.txt','ocr-engine80-focused-c-verify2-build.txt','ocr-engine80-focused-c-verify2-stdout.txt','ocr-engine80-focused-c-verify2-stderr.txt','ocr-run_engine80_08_paired67-parent.txt','ocr-run_engine80_florence_paired67-parent.txt']]
for pattern in ['ocr-engine80-vllm-08-paired67-*.txt','ocr-engine80-florence-paired67-*.txt','ocr-engine75-layout-retry2-pages*.txt']:logs+=list(Path('/private/tmp').glob(pattern))
ns['archive']('qualification',sorted(set(logs)),'logs_manifest.json')
drivers=[]
for tag in ['79','80']:
 drivers += [p for p in v.glob('*engine'+tag+'*')if p.is_file()and p.suffix in ['.py','.m','.metal','.inc','.json','.patch']and p.name!='engine80_checkpoint_waiter.json']
drivers+=[v/'run_engine75_layout_retry2_before_engine80_4b.py']
ns['archive']('drivers',sorted(set(drivers)),'drivers_manifest.json')
# The only active result audit is screen68. No future native directory exists yet.
paths=[]
for p in o.rglob('*'):
 if p.is_file()and p.name!='engine80_prefill_ffn_screen68_audit.json':paths.append(str(p.relative_to(r)))
paths+=list(freeze)
subprocess.run(['git','add','--',*sorted(set(paths))],check=True)
assert all(sha(r/p)==h for p,h in freeze.items())
print('CHECKPOINT STAGED',len(set(paths)),flush=True)
