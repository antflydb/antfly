from pathlib import Path
import hashlib,json,os,subprocess,psutil,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
b=v/'engine91_c_prefill_ffn_check';source=v/'engine91_c_prefill_ffn_check.m';assert not b.exists();cmd=['clang','-O3','-fobjc-arc','-I','zig/pkg/inference/src/backends',str(source),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(b)]
with Path('/private/tmp/ocr-engine91-focused-ffn-build.txt').open('w')as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
assert p.returncode==0
while psutil.virtual_memory().available<768*1024**2+6*1024**3:time.sleep(5)
so=Path('/private/tmp/ocr-engine91-focused-ffn-stdout.txt');se=Path('/private/tmp/ocr-engine91-focused-ffn-stderr.txt');assert not so.exists()and not se.exists()
with so.open('w')as f,se.open('w')as e:p=subprocess.run([str(b)],stdout=f,stderr=e,env=dict(os.environ,ANTFLY_LIGHTONOCR3_THROUGHPUT='0',TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY='1'),timeout=900)
records=[json.loads(l)for l in so.read_text().splitlines()if l.startswith('{"variant":')]
a=o/'engine91_focused_ffn_audit.json';assert not a.exists();a.write_text(json.dumps(dict(status='pass'if p.returncode==0 else'failed',primary_throughput_eligible=False,scope='Fresh production-C packed FFN guards/rollback/PSO/bounds/alias/pending-producer/CPU/canary/full bits at six lengths, after ARC cleanup changes.',exit_code=p.returncode,records=records,binary_sha256=sha(b),source_sha256=sha(source),production_c_sha256=sha(r/'zig/pkg/inference/src/backends/metal_kernels.m'),checker_sha256=sha(r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m'),stdout_sha256=sha(so),stderr_sha256=sha(se)),indent=2)+'\n')
assert p.returncode==0 and len(records)==24 and all(x['max_abs']==x['packed_differences']==x['norm_packed_differences']==0 for x in records)
assert 'ENGINE79 C PREFILL FFN CHECK PASS'in se.read_text();print('ENGINE91 FRESH FOCUSED FFN PASS',flush=True)
