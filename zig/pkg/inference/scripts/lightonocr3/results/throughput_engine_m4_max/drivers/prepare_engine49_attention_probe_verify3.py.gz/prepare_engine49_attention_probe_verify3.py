from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
src=(v/'engine49_attention_v1.metal').read_text().replace('engine49_v1_q16','engine49_v5_q16')
a=src.index('    tensor<device float, dextents<int, 2>, tensor_inline> qa')
b=src.index('    tensor<threadgroup float, dextents<int, 2>, tensor_inline> S(',a)
src=src[:a]+'''    threadgroup float cached_q[QT * 256];
    for (uint i = tid; i < QT * 256; i += 128) {
        uint row = i / 256, d = i % 256;
        cached_q[i] = q0 + row < p.q_len ? q[((q0 + row) * p.num_heads + h) * 256 + d] : 0;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    tensor<threadgroup float, dextents<int, 2>, tensor_inline> Q(cached_q, dextents<int, 2>(256, QT), array<int, 2>{1,256});
'''+src[b:]
p=v/'engine49_attention_v5.metal';assert not p.exists();p.write_text(src)
p=v/'engine49_attention_probe.m';s=p.read_text()
a=s.index('typedef struct { termite_metal_decode_runtime')
s=s[:a].rstrip()
assert s.endswith('};')
s=s[:-2].rstrip()+',\n@""\n'+''.join(' '+json.dumps(x+'\n')+'\n'for x in src.splitlines())+'\n};\n'+p.read_text()[a:]
s=s.replace('psos[5]','psos[6]').replace('mode<5','mode<6').replace('mode>=5','mode>=6').replace('i<5;i++','i<6;i++').replace('mode<=4;mode++','mode<=5;mode++')
# Only the standalone helper's mode loop changes; original checker has its own independent modes.
p.write_text(s)
for name in ['build_engine49_attention_probe.py','run_engine49_attention_probe.py']:
 p=v/name;s=p.read_text().replace('preparation_verify2.json','preparation_verify3.json').replace('for mode in [1,2,3,4]:','for mode in [1,2,3,4,5]:')
 p.write_text(s)
rec=json.loads((out/'engine49_attention_probe_preparation_verify2.json').read_text())
rec['inputs'][str(v/'engine49_attention_v5.metal')]=''
rec['inputs']={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in rec['inputs']}
rec['specs'].append([16,64,True,'shared F32 Q'])
rec['scope']+=' Adds Q16/K64 alias variant with per-threadgroup F32 Q cached once, bounded static shared memory. Original checker modes unaffected.'
(out/'engine49_attention_probe_preparation_verify3.json').write_text(json.dumps(rec,indent=2)+'\n')
