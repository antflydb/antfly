from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';p=r/'zig/lib/image/src/processing.zig';s=p.read_text().replace('"work_control.zig"','"engine84_work_control.zig"')
(v/'engine84_work_control.zig').write_bytes((r/'zig/lib/image/src/work_control.zig').read_bytes())
s+='''

test "engine84 private horizontal ABBA benchmark" {
    const a = std.testing.allocator;
    const Case = struct { width: u32, height: u32, target: u32 };
    for ([_]Case{ .{ .width=1600, .height=2200, .target=896 }, .{ .width=2048, .height=1536, .target=672 }, .{ .width=512, .height=384, .target=1024 } }) |case| {
        for ([_]PixelFormat{ .rgb8, .rgba8 }) |format| {
            const channels: usize = @backingInt(format);
            const stride = @as(usize, case.width) * channels + 5;
            const bytes = try a.alloc(u8, (@as(usize, case.height)-1)*stride+@as(usize,case.width)*channels);
            defer a.free(bytes);
            for (bytes, 0..) |*value, i| value.* = @intCast((i*53+i/7*91)%256);
            const img = ImageU8{ .data=bytes, .width=case.width, .height=case.height, .format=format, .row_stride_bytes=stride };
            var axis = try buildPillowBicubicAxis(a,case.width,case.target,false);
            defer axis.deinit();
            const scalar = try a.alloc(u8,@as(usize,case.target)*case.height*3);
            defer a.free(scalar);
            const vector = try a.alloc(u8,scalar.len);
            defer a.free(vector);
            try pillowHorizontal(img,axis,scalar,case.target,false);
            try pillowHorizontal(img,axis,vector,case.target,true);
            try std.testing.expectEqualSlices(u8,scalar,vector);
            for (0..4) |leg| {
                const simd = leg==1 or leg==2;
                for (0..2) |_| {
                    if (simd) try pillowHorizontal(img,axis,vector,case.target,true) else try pillowHorizontal(img,axis,vector,case.target,false);
                }
                const start = std.Io.Clock.awake.now(std.testing.io).nanoseconds;
                for (0..6) |_| {
                    if (simd) try pillowHorizontal(img,axis,vector,case.target,true) else try pillowHorizontal(img,axis,vector,case.target,false);
                    std.mem.doNotOptimizeAway(vector);
                }
                const elapsed = std.Io.Clock.awake.now(std.testing.io).nanoseconds-start;
                try std.testing.expectEqualSlices(u8,scalar,vector);
                std.debug.print("HORIZONTAL84 width={d} height={d} target={d} channels={d} leg={d} simd={d} elapsed_ns={d} runs=6 exact=true\\n",.{case.width,case.height,case.target,channels,leg,@intFromBool(simd),elapsed});
            }
        }
    }
}
'''
(v/'engine84_processing_bench.zig').write_text(s)
(v/'engine84_horizontal_bench_inputs.json').write_text(json.dumps({str(x.relative_to(r)):hashlib.sha256(x.read_bytes()).hexdigest()for x in [p,v/'engine84_work_control.zig',v/'engine84_processing_bench.zig']},indent=2)+'\n')
