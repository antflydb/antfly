from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine71_verify2_gpu_build.py').read_text().replace('engine71','engine74').replace("GPU_TOKEN_BURST_WIDTH']='4'","GPU_TOKEN_BURST_WIDTH']='8'")
s=s.replace('sys.exit(r.returncode)', '''if r.returncode==0:
 widths=re.findall(r'gpu_token_burst_max_width=(\\d+)',log)
 assert widths and any(int(w)==8 for w in widths) and all(int(w)<=8 for w in widths),widths
 print('qualified actual width-eight GPU token handoff',widths)
sys.exit(r.returncode)''')
(v/'run_engine74_verify_gpu_build.py').write_text(s)
(v/'run_engine74_metal_disabled.py').write_text((v/'run_engine71_metal_disabled.py').read_text().replace('engine71','engine74'))
(v/'run_engine74_budget_policies.py').write_text((v/'run_engine71_budget_policies.py').read_text().replace('engine71','engine74').replace('assert burst_width in [2,3,4]','assert burst_width in range(2,9)'))
(v/'run_engine74_qualification_queue.py').write_text('''from pathlib import Path
import subprocess,sys,time,json,hashlib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while True:
 p=Path('/private/tmp/ocr-engine75-probe-parent.txt');s=p.read_text() if p.exists() else ''
 if 'Traceback'in s:raise RuntimeError('Layout prototype failed; inspect before mutating source.')
 if 'ENGINE75 ISOLATED PROBE DONE'in s:break
 time.sleep(5)
assert 'ENGINE73D CPU DIAGNOSTIC DONE' in Path('/private/tmp/ocr-engine73d-queue-parent.txt').read_text()
assert json.loads((o/'engine71_precision_screen62_audit.json').read_text())['status']=='pass'
for p,h in json.loads((v/'engine74-burst8-inputs.json').read_text()).items():assert sha(r/p)==h,p
assert not (o/'engine74_build_manifest.json').exists()
subprocess.run(['git','apply','--check',str(v/'engine74-burst8.patch')],check=True)
subprocess.run(['git','apply',str(v/'engine74-burst8.patch')],check=True)
subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt','zig/pkg/inference/src/pipelines/generation.zig','zig/pkg/inference/src/server/server.zig','zig/pkg/inference/src/ops/metal_compute.zig'],check=True)
f=json.loads((v/'engine71-freeze.json').read_text());f['docs/guides/lightonocr3.mdx']=None
f={p:sha(r/p) for p in f};(v/'engine74-freeze.json').write_text(json.dumps(f,indent=2)+'\\n')
(v/'engine74_benchmark_concurrency.py').write_bytes((r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
c=json.loads((o/'engine70_c_build_manifest.json').read_text());assert sha(r/c['binary'])==c['binary_sha256'] and all(sha(r/p)==h for p,h in c['input_sha256'].items())
(o/'engine74_c_reuse_audit.json').write_text(json.dumps(dict(status='pass',scope='Reuse all nineteen engine70 C suites only after exact C/header/checker input and binary hashes; width8 changes Zig scheduling and publication only.',reused_manifest_sha256=sha(o/'engine70_c_build_manifest.json'),input_sha256=c['input_sha256'],binary_sha256=c['binary_sha256']),indent=2)+'\\n')
for label,cmd in [('gpu',[sys.executable,str(v/'run_engine74_verify_gpu_build.py')]),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine74','/private/tmp/ocr-engine74-verify2-gpu-build.txt']),('cpu',[sys.executable,str(v/'run_engine74_metal_disabled.py')])]:
 print('START ENGINE74 QUALIFICATION',label,flush=True)
 with Path('/private/tmp/ocr-engine74-'+label+'-parent.txt').open('w')as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE ENGINE74 QUALIFICATION',label,flush=True)
for p,h in f.items():assert sha(r/p)==h,p
print('ENGINE74 QUALIFICATION DONE',flush=True)
''')
print('prepared width8 qualification; applies only after all queued diagnostics finish')
