from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';o=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';integration=root.parent/'feat-lightonocr3-main-integration';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while True:
 p=Path('/private/tmp/ocr-engine70-follow56-parent.txt');s=p.read_text()if p.exists()else''
 if 'Traceback'in s:raise RuntimeError(s[-2000:])
 if 'ENGINE70 FOLLOW56 DONE'in s:break
 time.sleep(5)
for p,h in json.loads((v/'engine70-freeze.json').read_text()).items():assert sha(root/p)==h,p
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='c3a2c534cf6b66db24d444144196074986092eb6'
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','zig/pkg/inference/src'],cwd=root)
assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=U'],cwd=integration)
assert not subprocess.check_output(['git','diff','--name-only'],cwd=integration)
assert subprocess.check_output(['git','rev-parse','--short=10','MERGE_HEAD'],cwd=integration,text=True).strip()=='730999bf2d'
env=dict(os.environ,PATH='/Users/ajroetker/bin/zig-0.17.0:'+os.environ['PATH'])
for name in ['engine69','engine70']:
 m=json.loads((o/f'{name}_build_manifest.json').read_text());p=Path(m['binary_path']);assert sha(p)==m['binary_sha256'];dest=v/'qualified-binaries'/f'{name}-test';dest.parent.mkdir(exist_ok=True)
 if not dest.exists():shutil.copy2(p,dest)
 assert sha(dest)==m['binary_sha256']
print('START MAIN MERGE COMMIT',flush=True)
with Path('/private/tmp/ocr-engine71-main-merge-commit.txt').open('w')as log:
 subprocess.run(['git','commit','--quiet','-m','Merge origin/main into native OCR throughput branch'],cwd=integration,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
merged=subprocess.check_output(['git','rev-parse','HEAD'],cwd=integration,text=True).strip()
with Path('/private/tmp/ocr-engine71-main-fast-forward.txt').open('w')as log:subprocess.run(['git','merge','--ff-only',merged],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
print('MAIN INTEGRATED',merged,flush=True)
subprocess.run([sys.executable,str(v/'prepare_engine71_main.py')],check=True)
for name,cmd in [('gpu-build',[sys.executable,str(v/'run_engine71_verify2_gpu_build.py')]),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine71','/private/tmp/ocr-engine71-verify2-gpu-build.txt']),('metal-disabled',[sys.executable,str(v/'run_engine71_metal_disabled.py')])]:
 print('START',name,flush=True)
 with Path('/private/tmp/ocr-engine71-'+name+'-driver.txt').open('w')as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
print('ENGINE71 QUALIFICATION DONE',flush=True)
subprocess.run([sys.executable,str(v/'run_engine71_prefill_batch_screen58.py')],check=True)
print('ENGINE71 PREFILL58 DONE',flush=True)
subprocess.run([sys.executable,str(v/'run_engine71_api_paired59.py')],check=True)
print('ENGINE71 PAIRED59 DONE',flush=True)
