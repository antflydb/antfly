from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine53_chunk_cases.py').read_text()
s=s.replace("records=[]", "c=int(os.environ.get('OCR_CASE_CONCURRENCY','60'));prefill=int(os.environ.get('OCR_CASE_PREFILL_ITEMS','2'));vf=int(os.environ.get('OCR_CASE_VISION_FRAME_BLOCKS','2'));tag=os.environ.get('OCR_CASE_TAG','profile2')\nrecords=[]")
s=s.replace("label=f'rolling_chunks{chunks}_trial{trial}_c64_vf{2 if large else 4}_r{n}'", "label=f'rolling_chunks{chunks}_trial{trial}_c{c}_p{prefill}_vf{vf}_r{n}_{tag}'")
s=s.replace("OCR_CONCURRENCY='64'", "OCR_CONCURRENCY=str(c)").replace("OCR_PREFILL_BATCH='0',OCR_PREFILL_BATCH_ITEMS='1'", "OCR_PREFILL_BATCH='1'if prefill>1 else'0',OCR_PREFILL_BATCH_ITEMS=str(prefill)").replace("OCR_VISION_FRAME_BLOCKS='2'if large else'4'", "OCR_VISION_FRAME_BLOCKS=str(vf)")
s=s.replace("engine53_{model}_rolling_chunks_r{n}_audit.json", "engine53_{model}_rolling_chunks_c{c}_p{prefill}_vf{vf}_r{n}_{tag}_audit.json")
assert "OCR_CONCURRENCY=str(c)"in s and"c{c}_p{prefill}"in s
compile(s,'large','exec');(v/'run_engine53_large_chunk_profiles.py').write_text(s)
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns);ns['archive']('drivers',[v/'prepare_engine53_large_chunk_profiles.py',v/'run_engine53_large_chunk_profiles.py'],'drivers_manifest.json')
