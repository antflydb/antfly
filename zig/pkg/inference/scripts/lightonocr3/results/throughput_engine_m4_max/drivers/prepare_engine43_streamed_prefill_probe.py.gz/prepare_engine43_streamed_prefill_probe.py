from pathlib import Path
import json,re,collections,statistics
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
raw=Path('/private/tmp/ocr-engine43-prefill-swizzle-probe.txt').read_text()
pat=r'PREFILL_SWIZZLE rows=(\d+) in=(\d+) out=(\d+) on=(\d+) leg=(\d+) gpu_us=([\d.]+) max_abs=([\deE.+-]+) cpu_error=([\deE.+-]+)'
records=[dict(zip(['rows','hidden','output','on','leg','gpu_us','max_abs','cpu_error'],[int(x)for x in m[:5]]+[float(x)for x in m[5:]]))for m in re.findall(pat,raw)]
assert len(records)==40 and 'FAIL'not in raw
groups=collections.defaultdict(list)
for x in records:groups[(x['rows'],x['hidden'],x['output'])].append(x)
comparisons=[]
for (r,h,n),xs in groups.items():
 off=[x['gpu_us']for x in xs if not x['on']];on=[x['gpu_us']for x in xs if x['on']]
 comparisons.append(dict(rows=r,hidden=h,output=n,candidate_to_baseline_ratio=statistics.mean(on)/statistics.mean(off),both_candidate_legs_faster_than_both_controls=max(on)<min(off)))
(o/'engine43_prefill_swizzle_probe_audit.json').write_text(json.dumps(dict(status='pass',scope='Identical outputs; mixed single-projection timings. Not promoted.',records=records,comparisons=comparisons),indent=2)+'\n')
ns={};src=(v/'archive_engine10_evidence.py').read_text();exec(src[:src.index("archive('qualification'")],ns)
ns['archive']('qualification',[Path('/private/tmp/ocr-engine43-prefill-swizzle-probe.txt')],'logs_manifest.json')
s=(v/'engine43_prefill_swizzle_probe_kernels.m').read_text()
needle='    bool prefill_row64_probe;';assert s.count(needle)==1
s=s.replace(needle,needle+'\n    uint32_t prefill_probe_variant;')
a=s.index('static int termite_metal_try_lightonocr3_mpp(');b=s.index('\n}\n',a)+2
part=s[a:b]
part=part.replace('const bool n32 = (in_dim','const bool n32 = (probe_prefill64 && runtime->prefill_probe_variant == 1) || (in_dim')
part=part.replace('if (probe_prefill64 && (!bf16 || runtime->prefill_swizzle_probe_pipeline','if (probe_prefill64 && runtime->prefill_probe_variant == 2 && (!bf16 || runtime->prefill_swizzle_probe_pipeline')
part=part.replace('probe_prefill64 ? runtime->prefill_swizzle_probe_pipeline','probe_prefill64 && runtime->prefill_probe_variant == 2 ? runtime->prefill_swizzle_probe_pipeline')
part=part.replace('[enc dispatchThreadgroups:(probe_prefill64\n','[enc dispatchThreadgroups:((probe_prefill64 && runtime->prefill_probe_variant == 2)\n')
s=s[:a]+part+s[b:]
(v/'engine43_streamed_prefill_probe_kernels.m').write_text(s)
s=(v/'engine43_prefill_swizzle_probe_checks.m').read_text().replace('engine43_prefill_swizzle_probe_kernels.m','engine43_streamed_prefill_probe_kernels.m')
(v/'engine43_streamed_prefill_probe_checks.m').write_text(s)
s=(v/'build_engine43_prefill_swizzle_probe.py').read_text().replace('engine43_prefill_swizzle_probe','engine43_streamed_prefill_probe').replace('ocr-engine43-prefill-swizzle-probe-build.txt','ocr-engine43-streamed-prefill-probe-build.txt')
(v/'build_engine43_streamed_prefill_probe.py').write_text(s)
print('Prepared streamed probe C policy copy only; actual runtime42 unchanged.')
