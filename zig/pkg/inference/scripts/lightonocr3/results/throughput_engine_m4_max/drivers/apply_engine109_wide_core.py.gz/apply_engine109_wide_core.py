from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();f=json.loads((v/'engine102-freeze.json').read_text());assert all(sha(r/p)==h for p,h in f.items())
(r/'zig/pkg/inference/src/backends/metal_kernels.m').write_bytes((v/'engine109_wide_runtime_kernels.m').read_bytes())
(r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').write_bytes((v/'engine109_wide_checker.m').read_bytes())
p=r/'zig/pkg/inference/src/backends/metal_runtime.zig';s=p.read_text();needle='pub extern fn termite_metal_decode_runtime_lighton_batch_argmax_stats(';a=s.index(needle);s=s[:a]+'''pub extern fn termite_metal_decode_runtime_lighton_recurrent_group_rows(runtime: ?*RawMetalDecodeRuntime) usize;
pub extern fn termite_metal_decode_runtime_lighton_wide_recurrent_stats(runtime: ?*RawMetalDecodeRuntime, out: *[3]u64) void;
'''+s[a:];p.write_text(s)
p=r/'zig/pkg/inference/src/ops/metal_compute.zig';s=p.read_text();needle='    pub fn lightOnBatchedArgmaxStats(';a=s.index(needle);s=s[:a]+'''    pub fn lightOnRecurrentGroupRows(cb: *const ops.ComputeBackend) usize {
        if (cb.kind() != .metal or cb.vtable.decoderRuntimeArgmaxRowsSuppress != &decoderRuntimeArgmaxRowsSuppressOp) return 16;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        if (!self.lighton_shared_core_weights_enabled) return 16;
        return metal_runtime_mod.termite_metal_decode_runtime_lighton_recurrent_group_rows(self.provider_impl.raw_decode_runtime);
    }

    pub fn lightOnWideRecurrentStats(cb: *const ops.ComputeBackend) [3]u64 {
        if (cb.kind() != .metal or cb.vtable.decoderRuntimeArgmaxRowsSuppress != &decoderRuntimeArgmaxRowsSuppressOp) return @splat(0);
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        var stats: [3]u64 = @splat(0);
        metal_runtime_mod.termite_metal_decode_runtime_lighton_wide_recurrent_stats(self.provider_impl.raw_decode_runtime, &stats);
        return stats;
    }

'''+s[a:]
s=s.replace('if (states.len < 2 or states.len > 16 or','if (states.len < 2 or states.len > lightOnRecurrentGroupRows(cb) or',1)
a=s.index('    pub fn lightOnPackedCore(');b=s.index('        const inputs = [_]CT{',a);part=s[a:b];part+='''        if (states.len > 16) for (states[1..]) |state| {
            for (0..4) |weight| {
                const first = &states[0].weights[weight].?;
                const other = &state.weights[weight].?;
                if (first.deviceHandle() != other.deviceHandle() or first.deviceByteOffset() != other.deviceByteOffset()) return null;
            }
        };
''';s=s[:a]+part+s[b:]
a=s.index('} else struct {\n    pub const OcrEncoderStage');s=s[:a]+s[a:].replace('    pub const OcrEncoderStage', '''    pub fn lightOnRecurrentGroupRows(_: *const ops.ComputeBackend) usize { return 16; }
    pub fn lightOnWideRecurrentStats(_: *const ops.ComputeBackend) [3]u64 { return @splat(0); }

    pub const OcrEncoderStage''',1);p.write_text(s)
p=r/'zig/pkg/inference/src/architectures/gpt.zig';s=p.read_text();a=s.index('fn qwen35PackedProjectedCore(');b=s.index('\nfn ',a+10);part=s[a:b];assert part.count('count < 16')==1;part=part.replace('count < 16','count < metal_compute_mod.MetalCompute.lightOnRecurrentGroupRows(cb)').replace('var states: [16]*metal_compute_mod.Qwen35LinearState','var states: [64]*metal_compute_mod.Qwen35LinearState');s=s[:a]+part+s[b:];p.write_text(s)
p=r/'zig/pkg/inference/src/server/server.zig';s=p.read_text();needle='                    const batch_argmax = if (comptime build_options.enable_metal)';assert s.count(needle)==1;s=s.replace(needle,'''                    const wide_recurrent = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnWideRecurrentStats(&cb) else @as([3]u64, @splat(0));
                    std.debug.print("LIGHTONOCR3 wide_recurrent_dispatches={d} wide_recurrent_max_rows={d} wide_recurrent_staged_bytes={d}\\n", .{ wide_recurrent[0], wide_recurrent[1], wide_recurrent[2] });
'''+needle);p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';s=p.read_text();needle='    if args.recurrent_parallel:\n';assert s.count(needle)==1;s=s.replace(needle,'''    env["TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE_RECURRENT"] = "1" if args.wide_recurrent or args.require_wide_recurrent else "0"
'''+needle)
needle='    parser.add_argument("--recurrent-parallel", action="store_true", default=None)';assert s.count(needle)==1;s=s.replace(needle,'''    parser.add_argument("--wide-recurrent", action="store_true")
    parser.add_argument("--require-wide-recurrent", action="store_true")
'''+needle)
needle='                    sample["packed_prefill_pages"] = sum(';assert s.count(needle)==1;s=s.replace(needle,'''                    wide_recurrent = [tuple(map(int, values)) for values in re.findall(r"LIGHTONOCR3 wide_recurrent_dispatches=(\\d+) wide_recurrent_max_rows=(\\d+) wide_recurrent_staged_bytes=(\\d+)", section)]
                    sample["wide_recurrent_dispatches"] = sum(calls for calls, _, _ in wide_recurrent)
                    sample["wide_recurrent_max_rows"] = max((rows for _, rows, _ in wide_recurrent), default=0)
                    sample["wide_recurrent_staged_bytes"] = sum(size for _, _, size in wide_recurrent)
                    if args.require_wide_recurrent and (not sample["wide_recurrent_dispatches"] or not 16 < sample["wide_recurrent_max_rows"] <= 64 or not sample["wide_recurrent_staged_bytes"]):
                        result["status"] = "missing_timed_wide_recurrent_steps"
'''+needle)
s=s.replace('<= 16 * int(groups)','<= (64 if args.wide_recurrent or args.require_wide_recurrent else 16) * int(groups)')
s=s.replace('        or args.prefill_stream_layers\n','')
s=s.replace('with layer streaming disabled','with decode layer streaming disabled')
p.write_text(s)
print('Applied source109 wide recurrent and packed-prefill streaming qualification inputs')
