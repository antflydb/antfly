from pathlib import Path
import datetime,hashlib,json,os,psutil,subprocess,sys,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';s=r/'zig/pkg/inference/scripts/lightonocr3';o=s/'results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=o/'paired131_4b_warmed_comparison_audit.json';assert not a.exists()
for p,h in json.loads((v/'engine113-freeze.json').read_text()).items():assert sha(r/p)==h,p
screen=json.loads((o/'engine113_remaining_cache94_audit.json').read_text());assert screen['status']=='screen_complete';selected=next(x for x in screen['runs']if x['profile']['name']=='4b_off');assert selected['status']=='passed';selected_prefill=1;selected_stream=0

d=dict(status='preparing',primary_throughput_eligible=True,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),scope='Preregisteredsource113wide64recurrent+packedmixedC62/P1/V1/VF3/width4. Width4andprefillcacheOFFfixedfromcompletedsource113screen94; no new kernel or precision changes. Longer256-page cohorts reduce start/drain effects for both runtimes. Prefillstream0andF32decodefixed. ActualfreshvLLMMetalAPI C64openingandclosing, originalBF16checkpoint/context1024/max256/util.7,uniquemediaUUIDs,prefixandprocessorcacheoff,automaticcachecapacityminimum320blockscheckedbeforewarming/timing. EachAPIserverfull256saturationwarmexcludedthen256timed. One residentnativewarm256excludedthentwotimed256rounds. AlloutputsrequiredexactnativeandopeningAPIstrings. Native1/openAPI,native2/closingAPI,bothmustwin. Nativecaps/reserveunchanged;reference23GiBavailablepreflight. Node.readvsloopbackHTTP. Sharedmachineuncontrolled,noownbuild/profile/GPUoverlap.',comparisons=[],selected_prefill_items=1,selected_prefill_stream_layers=selected_stream,screen_report_sha256=selected['report_sha256'],profile_selection='Preregistered source113 width4 C62 cacheOFF; both runtimes use256 warm plus256 timed requests. No tuning during paired comparison.')

def save():a.write_text(json.dumps(d,indent=2)+'\n')
def headroom(reference=False):
 minimum=max(11348275670+6*1024**3+512*1024**2,23*1024**3 if reference else 0)
 while psutil.virtual_memory().available<minimum:
  print('WAIT131 original modelreserve',psutil.virtual_memory().available,flush=True);time.sleep(15)
save()
def reference(index):
 headroom(reference=True);label=f'_primary_reference93_r{index}_c64_w256_r256_ctx1024';dest=o/('vllm_4b'+label);assert not dest.exists()
 cmd=[sys.executable,str(v/'engine94_benchmark_vllm_warm.py'),'--python',sys.executable,'--model-dir',str(v/'ocr-models/lighton4b'),'--images',str(r/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(s/'corpus/receipt.png'),str(s/'corpus/shipping.png'),'--concurrency','64','--requests','256','--warmup-requests','256','--minimum-auto-cache-blocks','320','--max-tokens','256','--startup-timeout','600','--max-model-len','1024','--gpu-memory-utilization','0.7','--output-dir',str(dest)]
 print('START131 actualVLLM',index,flush=True)
 with Path(f'/private/tmp/ocr-engine113-vllm-primary131-r{index}.txt').open('w')as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONPATH=str(s)))
 rp=dest/'report.json';report=json.loads(rp.read_text());d[f'vllm_r{index}']=dict(report=str(rp.relative_to(o)),report_sha256=sha(rp),exit_code=p.returncode);save()
 assert p.returncode==0 and report['status']=='ok'and report['automatic_cache_floor_admission']['admitted']
 result=report['results'][0];assert result['completed']==256 and result['serial_reference_parity'];assert len(report['saturation_warmups'])==1 and len(report['saturation_warmups'][0]['outputs'])==256
 print('DONE131 actualVLLM',index,result['pages_per_second'],flush=True);return label,report
try:
 oracle,opening=reference(0);headroom();label=f'paired131_wide_packed_s{selected_stream}_warm_then_two_c62_r256';env=dict(os.environ)
 env.update(OCR_PREFILL_ACTIVATION_POOL='0',OCR_WIDE_RECURRENT='1',OCR_PACKED_MIXED='1',OCR_PACKED_PREFILL_ITEMS=str(selected_prefill),OCR_REFERENCE_LABEL=oracle,OCR_PHYSICAL32='0',OCR_PHYSICAL64='1',OCR_CONCURRENCY='62',OCR_REQUESTS='256',OCR_WIDE='1',OCR_KV_GIB='4',OCR_BACKEND_GIB='17',OCR_SCRATCH_GIB='10',OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch,engineepoch,engineepoch',OCR_SHARED_CORE='1',OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_DISABLE_64_ROW_TILE='0',OCR_DISABLE_WIDE_GATE_UP='0',OCR_WIDE64_GATE_UP='1',OCR_FULL64_GATE_UP='1',OCR_GPU_GREEDY_STREAM='0',OCR_STREAM_CHUNK_LAYERS='0',OCR_VISION_BATCH='0',OCR_VISION_BATCH_ITEMS='1',OCR_PREFILL_BATCH='0',OCR_PREFILL_BATCH_ITEMS='1',OCR_VISION_FRAME_BLOCKS='3',OCR_SINGLE_FRAME='1',OCR_STREAM_FIRST='0',OCR_LOGICAL64='1',OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',OCR_ADMISSION_UNITS='512',OCR_BATCH_ARGMAX='1',OCR_DEFER_VISION_SEAL='0',OCR_DEFER_PREFILL_SEAL='0',OCR_CACHE_VISION_WORKSPACE='1',OCR_LARGE_VISION_PACK_REUSE='0',ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY='0',OCR_TIMEOUT='3600',OCR_PREFILL_FUSED_FFN='0',OCR_RESIDENT_VISION_BUDGET='1',OCR_GPU_TOKEN_BURST='1',OCR_GPU_TOKEN_BURST_WIDTH='4',OCR_PIPELINE_VISION='0',OCR_PREFILL_STREAM_LAYERS=str(selected_stream),OCR_REQUIRE_MEMORY_ROUNDS='1')
 for key in ['OCR_BF16_ROUNDS','OCR_PREFILL_FFN_ROUNDS','OCR_VERIFY_SAVED_RUN']:env.pop(key,None)
 print('START131 native resident warm+two',flush=True)
 with Path('/private/tmp/ocr-engine113-native-primary131.txt').open('w')as f:p=subprocess.run([sys.executable,str(v/'run_engine113_budget_policies.py'),'4b:'+label],env=env,stdout=f,stderr=subprocess.STDOUT)
 rp=o/('engine113_4b_'+label)/'report.json';nd=json.loads(rp.read_text());d['native']=dict(report=str(rp.relative_to(o)),report_sha256=sha(rp),exit_code=p.returncode);save();assert p.returncode==0
 result=nd['results'][0];rounds=result['policy_rounds'];assert result['status']=='ok'and result['serial_reference_parity']and result['cross_runtime_content_parity']and len(rounds)==3
 for sample in rounds:assert sample['completed']==256 and not sample['admission_pressures']and sample['mixed_steps']>0 and sample['packed_recurrent_groups']>0 and sample['host_recurrent_bytes_total']==0 and sample['wide_recurrent_dispatches']>0 and sample['wide_recurrent_staged_bytes']>0 and sample['gpu_token_burst_max_width']==4
 _,closing=reference(1)
 for sample,ref in zip(rounds[1:],[opening,closing]):
  nr=sample['pages_per_second'];vr=ref['results'][0]['pages_per_second'];d['comparisons'].append(dict(native_round=sample['round'],native_pages_per_second=nr,vllm_pages_per_second=vr,ratio=nr/vr))
 d['excluded_native_saturation_warm_round']=0;d['status']='repeated_native_win'if all(c['ratio']>1 for c in d['comparisons'])else'native_behind';save();print('PRIMARY131 DONE',d['status'],d['comparisons'],flush=True)
except BaseException as e:d.update(status='failed_or_reference_capacity_excluded',error=repr(e));save();raise
