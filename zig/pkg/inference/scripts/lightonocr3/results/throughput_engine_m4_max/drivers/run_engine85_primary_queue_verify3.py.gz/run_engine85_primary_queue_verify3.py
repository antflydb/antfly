from pathlib import Path
import subprocess,sys,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal'
while True:
 p=Path('/private/tmp/ocr-engine85-qualification-verify3-parent.txt');s=p.read_text()if p.exists()else''
 if 'ENGINE85 QUALIFICATION DONE'in s:break
 if 'Traceback'in s or any('DONE ENGINE85 '+k+' 1'in s for k in ['image','gpu','cpu','finalize']):raise RuntimeError(s[-4000:])
 time.sleep(5)
for name in ['run_engine85_08_paired72.py','run_engine85_florence_paired72.py','run_engine85_primary71.py']:
 print('START',name,flush=True)
 with Path('/private/tmp/ocr-'+name.removesuffix('.py')+'-parent.txt').open('w')as log:
  p=subprocess.run([sys.executable,str(v/name)],stdout=log,stderr=subprocess.STDOUT)
 print('DONE',name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
print('ENGINE85 PRIMARY QUEUE DONE',flush=True)
