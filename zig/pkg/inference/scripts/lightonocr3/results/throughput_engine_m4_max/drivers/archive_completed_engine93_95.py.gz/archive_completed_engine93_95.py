from pathlib import Path
import subprocess,sys,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
assert json.loads((o/'engine93_steel_tiles_audit.json').read_text())['status']=='complete_private_screen'
assert json.loads((o/'engine95_decode_ffn_audit.json').read_text())['status']=='prototype_pass'
assert json.loads((o/'engine94_mixed_screen75verify3_audit.json').read_text())['status']=='small_pass_4b_superseded_before_admission'
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine94_*'],check=True)
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
logs=[];drivers=[]
for tag in [93,94,95]:
 logs += [p for p in Path('/private/tmp').glob(f'ocr-engine{tag}-*.txt')]
 drivers += [p for p in v.glob(f'*engine{tag}*')if p.is_file()and p.suffix in ['.py','.m','.metal','.inc','.json','.patch','.zig']]
ns['archive']('qualification',sorted(set(logs)),'logs_manifest.json')
ns['archive']('drivers',sorted(set(drivers)),'drivers_manifest.json')
print('Archived completed93-95 evidence, including original harness failures and preserved source94 model outputs.',flush=True)
