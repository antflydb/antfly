from pathlib import Path
import bisect,collections,re,subprocess
v=Path('.venv-lighton-vllm-metal');obj=Path('zig/.zig-cache/o/d84bbc0b33467e05741360db2b39ac7a/test_zcu.o');raw=subprocess.check_output(['nm','-nm',str(obj)],text=True);entries=[]
for line in raw.splitlines():
 m=re.match(r'([0-9a-f]+) \(__TEXT,__text\).*? (\S+)$',line)
 if m:entries.append((int(m[1],16),m[2]))
entries.sort();addrs=[x[0]for x in entries];main=next(a for a,n in entries if n=='_main');final_main=0x100daf81c
for stage in ['prefill','decode']:
 p=Path('/private/tmp/ocr-engine17-cpu-'+stage+'-sample.txt');s=p.read_text();counts=collections.Counter();lines=[]
 for line in s.splitlines():
  m=re.search(r'\(in test\).*?\[(0x[0-9a-f]+)\]',line)
  if m and int(m[1],16)>=final_main:
   address=int(m[1],16)-final_main+main;i=bisect.bisect_right(addrs,address)-1
   if i>=0:
    a,n=entries[i];line+=' [object '+n+' + '+hex(address-a)+']'
    number=re.match(r'\s*\+?\s*(\d+)',line)
    if number:counts[n]+=int(number[1])
  lines.append(line)
 Path('/private/tmp/ocr-engine17-cpu-'+stage+'-symbolized.txt').write_text('\n'.join(lines)+'\n')
 print(stage,counts.most_common(14))
