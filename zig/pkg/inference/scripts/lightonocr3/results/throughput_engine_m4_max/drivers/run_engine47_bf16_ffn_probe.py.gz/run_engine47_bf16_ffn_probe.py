from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';out=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def freeze():
 d=json.loads((v/'engine45-freeze.json').read_text())
 assert all(sha(root/p)==s for p,s in d.items())
 m=json.loads((out/'engine45_build_manifest.json').read_text())
 assert sha(Path(m['binary_path']))==m['binary_sha256']
def archive(paths):
 ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
 ns['archive']('qualification',paths,'logs_manifest.json')
def run(name,cmd):
 print('START',name,flush=True)
 log=Path('/private/tmp/ocr-'+name+'.txt');assert not log.exists()
 with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 archive([log]);print('DONE',name,r.returncode,flush=True)
 assert r.returncode==0,(name,r.returncode)
def compress(patterns):
 subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),*patterns],check=True)
freeze()
archive([Path('/private/tmp/ocr-engine45-prefill4-then27-driver.txt')])
run('engine47-bf16-ffn-compile-driver',[sys.executable,str(v/'build_engine47_bf16_ffn_probe.py')])
archive([Path('/private/tmp/ocr-engine47-bf16-ffn-probe-build.txt')])
run('engine47-bf16-ffn-probe',[str(v/'engine47_bf16_ffn_probe')])
freeze()
print('BF16 FFN PROBE COMPLETE',flush=True)
