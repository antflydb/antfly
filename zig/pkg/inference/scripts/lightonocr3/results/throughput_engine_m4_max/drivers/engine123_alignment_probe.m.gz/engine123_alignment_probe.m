#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
int main(int argc,char**argv){if(argc!=2)return 1;int fd=open(argv[1],O_RDONLY);if(fd<0)return 2;struct stat st;if(fstat(fd,&st))return 3;size_t len=(size_t)st.st_size;uint8_t*base=mmap(NULL,len,PROT_READ,MAP_PRIVATE,fd,0);if(base==MAP_FAILED)return 4;close(fd);
 @autoreleasepool{
  uint64_t header;memcpy(&header,base,8);NSData*data=[NSData dataWithBytes:base+8 length:(NSUInteger)header];NSDictionary*meta=[NSJSONSerialization JSONObjectWithData:data options:0 error:nil];id<MTLDevice>d=MTLCreateSystemDefaultDevice();if(!d)return 5;size_t page=(size_t)getpagesize();fprintf(stdout,"page=%zu header=%llu max_buffer=%zu\n",page,(unsigned long long)header,(size_t)d.maxBufferLength);
  NSArray*names=@[@"model.language_model.layers.0.linear_attn.in_proj_a.weight",@"model.language_model.layers.0.mlp.gate_proj.weight",@"model.language_model.layers.0.mlp.down_proj.weight"];
  for(NSString*name in names){@autoreleasepool{
   NSDictionary*t=meta[name];if(!t){fprintf(stdout,"missing %s\n",name.UTF8String);continue;}NSArray*offsets=t[@"data_offsets"];size_t offset=8+(size_t)header+[offsets[0]unsignedLongLongValue],bytes=[offsets[1]unsignedLongLongValue]-[offsets[0]unsignedLongLongValue];if(offset>len||bytes>len-offset)return 6;
   id<MTLBuffer>b=nil;@try{b=[d newBufferWithBytesNoCopy:base+offset length:bytes options:MTLResourceStorageModeShared deallocator:nil];}@catch(NSException*e){fprintf(stdout,"direct_exception=%s\n",e.name.UTF8String);}
   fprintf(stdout,"name=%s bytes=%zu pointer_mod=%zu length_mod=%zu direct=%d contents_match=%d\n",name.UTF8String,bytes,offset%page,bytes%page,b!=nil,b&&b.contents==base+offset);b=nil;
   size_t start=offset/page*page,end=(offset+bytes+page-1)/page*page;id<MTLBuffer>region=nil;@try{region=[d newBufferWithBytesNoCopy:base+start length:end-start options:MTLResourceStorageModeShared deallocator:nil];}@catch(NSException*e){fprintf(stdout,"region_exception=%s\n",e.name.UTF8String);}
   fprintf(stdout,"region=%d region_bytes=%zu weight_offset=%zu contents_match=%d\n",region!=nil,end-start,offset-start,region&&((uint8_t*)region.contents+offset-start)==base+offset);region=nil;
  }}
 }munmap(base,len);return 0;}
