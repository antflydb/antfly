from pathlib import Path
import difflib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m';original=p.read_text();src=(v/'engine108_wide_core_checks.m').read_text();a=src.index('static int fused_batch_core_check(');b=src.index('\nstatic int ',a+10);part=src[a:b];part=part[:part.index('    if (benchmark) {')];part=part.replace('static int fused_batch_core_check(','static int wide_batch_core_check(').replace('size_t pages,\n                                  bool benchmark)', 'size_t pages)')
part+='''    if(pages>=29) {
        // Make both trajectories start with identical bits after fallback
        // qualification. Then overlap two wide tables in the two frame banks.
        for(size_t page=0;page<pages;page++)for(size_t j=0;j<15;j++)
            memcpy((char*)buffers[1][page][j].contents+offsets[1][page][j],(char*)buffers[0][page][j].contents+offsets[0][page][j],counts[j]*4);
        for(size_t step=0;step<2;step++) {
            if(termite_metal_decode_runtime_begin_frame(r))return 77;
            for(size_t page=0;page<pages;page++) {
                if(page%16==0&&MIN(pages-page,(size_t)16)>1&&termite_metal_decode_runtime_qwen35_core_batch_begin(r,MIN(pages-page,(size_t)16))!=1)return 78;
                if(termite_metal_decode_runtime_qwen35_core_device(r,handles[0][page],offsets[0][page],1,kh,vh,128,4,1))return 79;
                if(((page+1)%16==0||page+1==pages)&&r->qwen35_core_batch_active&&termite_metal_decode_runtime_qwen35_core_batch_end(r))return 80;
            }
            if(termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r))return 81;
            for(size_t page=0;page<pages;page++){id<MTLBuffer> swap=buffers[0][page][6];buffers[0][page][6]=buffers[0][page][7];buffers[0][page][7]=swap;handles[0][page][6]=(__bridge void*)buffers[0][page][6];handles[0][page][7]=(__bridge void*)buffers[0][page][7];}
        }
        for(size_t step=0;step<2;step++) {
            if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_qwen35_core_batch_begin(r,pages)!=1)return 82;
            for(size_t page=0;page<pages;page++)if(termite_metal_decode_runtime_qwen35_core_device(r,handles[1][page],offsets[1][page],1,kh,vh,128,4,1))return 83;
            if(termite_metal_decode_runtime_qwen35_core_batch_end(r))return 84;
            if(step==1) {
                if(r->submitted_frame_cb==nil||r->active_frame_cb==nil||r->frame_host_staging_buffers[0]==nil||r->frame_host_staging_buffers[1]==nil||r->frame_host_staging_buffers[0]==r->frame_host_staging_buffers[1])return 85;
                if(termite_metal_decode_runtime_wait_frame(r))return 86;
            }
            if(termite_metal_decode_runtime_submit_frame(r))return 87;
            for(size_t page=0;page<pages;page++){id<MTLBuffer> swap=buffers[1][page][6];buffers[1][page][6]=buffers[1][page][7];buffers[1][page][7]=swap;handles[1][page][6]=(__bridge void*)buffers[1][page][6];handles[1][page][7]=(__bridge void*)buffers[1][page][7];}
        }
        if(termite_metal_decode_runtime_wait_frame(r))return 88;
        const size_t outputs[6]={7,8,9,10,11,14};
        for(size_t page=0;page<pages;page++)for(size_t k=0;k<6;k++) {
            size_t j=outputs[k];if(memcmp((char*)buffers[0][page][j].contents+offsets[0][page][j],(char*)buffers[1][page][j].contents+offsets[1][page][j],counts[j]*4))return 89;
        }
        for(size_t mode=0;mode<2;mode++)for(size_t page=0;page<pages;page++)for(size_t j=0;j<15;j++) {
            const uint32_t *raw=(uint32_t*)((char*)buffers[mode][page][j].contents+offsets[mode][page][j]-16);
            for(size_t i=0;i<4;i++)if(raw[i]!=0xdeadbeef||raw[counts[j]+4+i]!=0xdeadbeef)return 90;
        }
        fprintf(stderr,"wide_batch_core_overlap pages=%zu heads=%zu full_bits=pass two_banks=pass canaries=pass\\n",pages,vh);
    }
    return 0;
}
'''
assert 'benchmark' not in part
needle='static int fused_batch_core_check(';assert original.count(needle)==1;s=original.replace(needle,part+'\n'+needle)
needle='        if (argc == 2 && strcmp(argv[1], "--check-gpu-token-burst-long") == 0) {';assert s.count(needle)==1
s=s.replace(needle,'''        if (argc == 2 && strcmp(argv[1], "--check-wide-recurrent") == 0) {
            unsetenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE_RECURRENT");
            if(termite_metal_decode_runtime_begin_frame(r))return 145;
            if(termite_metal_decode_runtime_qwen35_core_batch_begin(r,64)!=0||termite_metal_decode_runtime_cancel_frame(r))return 146;
            setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE_RECURRENT","1",1);
            setenv("TERMITE_METAL_ENABLE_PIPELINED_DECODE_FRAME","1",1);
            setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL","1",1);
            const size_t pages[]={2,16,17,24,28,29,31,32,48,63,64};
            for(size_t heads=16;heads<=32;heads+=16)for(size_t i=0;i<sizeof(pages)/sizeof(pages[0]);i++) {
                int rc=wide_batch_core_check(r,16,heads,pages[i]);
                if(rc){fprintf(stderr,"WIDE_RECURRENT_FAIL pages=%zu heads=%zu rc=%d\\n",pages[i],heads,rc);return rc;}
            }
            uint64_t stats[3]={0};termite_metal_decode_runtime_lighton_wide_recurrent_stats(r,stats);
            if(stats[0]==0||stats[1]!=64||stats[2]==0)return 147;
            fprintf(stderr,"wide_recurrent_dispatches=%llu max_rows=%llu staged_bytes=%llu full_state_output_bits=pass aliases=pass fallback=pass\\n",(unsigned long long)stats[0],(unsigned long long)stats[1],(unsigned long long)stats[2]);
            termite_metal_decode_runtime_destroy(r);return 0;
        }
'''+needle)
(v/'engine109_wide_checker.m').write_text(s);(v/'engine109_wide_checker.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/'+str(p.relative_to(r)),tofile='b/'+str(p.relative_to(r)))))
print('Prepared wide C validation, including two-bank overlap; not applied')
