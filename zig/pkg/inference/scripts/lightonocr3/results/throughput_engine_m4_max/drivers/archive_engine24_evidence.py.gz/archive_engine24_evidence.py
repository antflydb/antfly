from pathlib import Path
import json,hashlib,gzip,collections
s=Path('.venv-lighton-vllm-metal/archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")])
archive('qualification',list(Path('/private/tmp').glob('ocr-engine24*.txt'))+list(Path('/private/tmp').glob('ocr-engine-vllm-4b-primary8-*.txt')),'logs_manifest.json')
archive('drivers',list(v.glob('*engine24*.py'))+[v/'archive_engine24_evidence.py'],'drivers_manifest.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
for p in sorted(out.glob('engine24_*/report.json')):
 d=json.loads(p.read_text());assert not d.get('own_cpu_compile_overlap');res=d['results'][0]
 assert res['status']=='ok' and res['serial_reference_parity'] and res['cross_runtime_content_parity'],p
 for sample in res['policy_rounds']:
  assert sample['completed']==128 and not sample['admission_pressures'],p
  records.append(dict(report=str(p.relative_to(out)),sha256=sha(p),pages_per_second=sample['pages_per_second'],completed=128,exact_native_serial_and_cross_runtime_text=True,own_cpu_compile_overlap=False,prefill_batch_sizes=dict(collections.Counter(x['items']for x in sample.get('prefill_batches',[])))))
(out/'engine24_comparison_audit.json').write_text(json.dumps(dict(scope='Qualified engine24 primary runs. Small isolated wins do not establish repeatable vLLM parity; paired8 remains native_behind. Prefill-only 100ms result is a new candidate pending fresh repeated comparison.',reports=records),indent=2)+'\n')
# Lossless report logs, preserve raw byte hashes and original recorded paths.
index=out/'raw_logs_manifest.json';mapping=json.loads(index.read_text())
for folder in [*out.glob('engine24_*'),*out.glob('engine24debug_*'),*out.glob('vllm_4b_primary_reference8_*')]:
 if not folder.is_dir():continue
 for p in folder.glob('*.txt'):
  raw=p.read_bytes();dest=p.with_name(p.name+'.gz');packed=gzip.compress(raw,mtime=0);dest.write_bytes(packed);assert gzip.decompress(packed)==raw
  key=str(p.relative_to(out));mapping[key]={'compressed_path':str(dest.relative_to(out)),'raw_sha256':hashlib.sha256(raw).hexdigest(),'raw_bytes':len(raw),'compressed_sha256':sha(dest)};p.unlink()
index.write_text(json.dumps(mapping,indent=2)+'\n')
print('archived',len(records),'primary reports; debug diagnostics excluded from primary audit')
