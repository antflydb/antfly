"""Prepare an independent safetensors copy; never alter source checkpoint bytes."""
from pathlib import Path
import hashlib,json,struct
v=Path('.venv-lighton-vllm-metal');source=v/'ocr-models/lighton4b';target=v/'ocr-models/lighton4b-aligned64'
original=source/'model.safetensors';destination=target/'model.safetensors'
assert not target.exists(),target
before=original.stat();target.mkdir()
for child in source.iterdir():
 if child.name!='model.safetensors':
  (target/child.name).symlink_to(child.resolve(),target_is_directory=child.is_dir())
with original.open('rb')as src,destination.open('xb')as dst:
 prefix=src.read(8);assert len(prefix)==8
 length=struct.unpack('<Q',prefix)[0];header=src.read(length);assert len(header)==length
 metadata=json.loads(header);padding=(-(8+length))%64
 assert padding>0,(8+length,padding)
 aligned_header=header+b' '*padding
 aligned_prefix=struct.pack('<Q',len(aligned_header));dst.write(aligned_prefix);dst.write(aligned_header)
 old_digest=hashlib.sha256(prefix+header);new_digest=hashlib.sha256(aligned_prefix+aligned_header);body_digest=hashlib.sha256();body_bytes=0
 while data:=src.read(16*1024*1024):
  dst.write(data);old_digest.update(data);new_digest.update(data);body_digest.update(data);body_bytes+=len(data)
after=original.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
verified=hashlib.sha256();verified_body=hashlib.sha256()
with destination.open('rb')as dst:
 actual_prefix=dst.read(8);actual_len=struct.unpack('<Q',actual_prefix)[0];actual_header=dst.read(actual_len)
 assert json.loads(actual_header)==metadata
 verified.update(actual_prefix+actual_header)
 while data:=dst.read(16*1024*1024):verified.update(data);verified_body.update(data)
assert verified.hexdigest()==new_digest.hexdigest()
assert verified_body.hexdigest()==body_digest.hexdigest()
assert destination.stat().st_size==original.stat().st_size+padding
starts=[8+length+x['data_offsets'][0]for k,x in metadata.items()if k!='__metadata__']
aligned_starts=[8+len(aligned_header)+x['data_offsets'][0]for k,x in metadata.items()if k!='__metadata__']
record=dict(status='pass',source=str(original.resolve()),destination=str(destination.resolve()),
 source_sha256=old_digest.hexdigest(),destination_sha256=new_digest.hexdigest(),tensor_body_sha256=body_digest.hexdigest(),
 independently_verified_destination_tensor_body_sha256=verified_body.hexdigest(),tensor_body_bytes=body_bytes,
 original_data_offset=8+length,aligned_data_offset=8+len(aligned_header),padding_added_bytes=padding,
 tensor_metadata_identical=True,every_tensor_byte_identical=True,original_source_unmodified=True,
 original_tensor_offset_mod16=sorted(set(x%16 for x in starts)),aligned_tensor_offset_mod16=sorted(set(x%16 for x in aligned_starts)),
 scope='Independent checkpoint-layout diagnostic only; payload and tensor metadata identical. No speed claim until actual full-model timings.')
out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
(out/'engine45_4b_aligned_checkpoint_manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
