from pathlib import Path
import hashlib,json,subprocess
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';f=json.loads((v/'engine80-freeze.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert all(sha(r/p)==h for p,h in f.items())
p=r/'zig/pkg/inference/src/server/server.zig';s=p.read_text();needle='''            "ANTFLY_LIGHTONOCR3_EPOCH_AUX",
        };
        const Env = struct {''';assert s.count(needle)==1;s=s.replace(needle,'''            "ANTFLY_LIGHTONOCR3_EPOCH_AUX",
            "TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN",
        };
        const Env = struct {''',1)
needle='''        if (policy_names.len == 0 or policy_names.len > 16) return error.InvalidBenchmarkPolicy;
        for (policy_names, 0..) |policy, round| {''';new='''        if (policy_names.len == 0 or policy_names.len > 16) return error.InvalidBenchmarkPolicy;
        var parsed_prefill_ffn_rounds: ?std.json.Parsed([]const bool) = null;
        defer if (parsed_prefill_ffn_rounds) |*value| value.deinit();
        if (platform.env.getenv("ANTFLY_TEST_OCR_PREFILL_FFN_ROUNDS")) |raw| {
            parsed_prefill_ffn_rounds = try std.json.parseFromSlice([]const bool, allocator, raw, .{});
            if (parsed_prefill_ffn_rounds.?.value.len != policy_names.len) return error.InvalidBenchmarkPolicy;
        }
        for (policy_names, 0..) |policy, round| {''';assert s.count(needle)==1;s=s.replace(needle,new,1)
needle='''            std.debug.print("OCR_POLICY round={d} name={s}\\n", .{ round, policy });
            const latencies''';new='''            std.debug.print("OCR_POLICY round={d} name={s}\\n", .{ round, policy });
            if (parsed_prefill_ffn_rounds) |rounds| {
                const enabled = rounds.value[round];
                if (Env.setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN", if (enabled) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;
                std.debug.print("OCR_PREFILL_FFN_POLICY round={d} enabled={d}\\n", .{ round, @intFromBool(enabled) });
            }
            const latencies''';assert s.count(needle)==1;s=s.replace(needle,new,1);p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';s=p.read_text();needle='''    env["TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN"] = (
        "1" if args.prefill_fused_ffn else "0"
    )
''';new=needle+'''    env.pop("ANTFLY_TEST_OCR_PREFILL_FFN_ROUNDS", None)
    if args.prefill_ffn_rounds:
        env["ANTFLY_TEST_OCR_PREFILL_FFN_ROUNDS"] = json.dumps(
            [value == "on" for value in args.prefill_ffn_rounds]
        )
''';assert s.count(needle)==1;s=s.replace(needle,new,1)
needle='''        if args.require_prefill_fused_ffn:
            timed_samples = result.get("policy_rounds", [result])
            if not timed_samples or any(
                sample.get("prefill_fused_ffn_calls", 0) <= 0
                for sample in timed_samples
            ):
                result["status"] = "missing_timed_prefill_fused_ffn"
''';new='''        if args.prefill_ffn_rounds:
            observed = [
                bool(int(enabled))
                for _, enabled in re.findall(
                    r"OCR_PREFILL_FFN_POLICY round=(\\d+) enabled=([01])", text
                )
            ]
            expected = [value == "on" for value in args.prefill_ffn_rounds]
            if observed != expected:
                result["status"] = "missing_prefill_ffn_rounds"
            for sample, enabled in zip(result.get("policy_rounds", []), expected):
                sample["prefill_fused_ffn_enabled"] = enabled
        if args.require_prefill_fused_ffn:
            timed_samples = result.get("policy_rounds", [result])
            if not timed_samples or any(
                (sample.get("prefill_fused_ffn_calls", 0) > 0)
                != sample.get("prefill_fused_ffn_enabled", args.prefill_fused_ffn)
                for sample in timed_samples
            ):
                result["status"] = "missing_timed_prefill_fused_ffn"
''';assert s.count(needle)==1;s=s.replace(needle,new,1)
needle='''    parser.add_argument("--require-prefill-fused-ffn", action="store_true")''';new=needle+'''
    parser.add_argument(
        "--prefill-ffn-rounds", nargs="+", choices=("off", "on"),
        help="Override the FFN flag per policy round within one resident model",
    )''';assert s.count(needle)==1;s=s.replace(needle,new,1)
needle='''    if args.prefill_fused_ffn and not args.bf16_prefill_inputs:
        parser.error("--prefill-fused-ffn requires --bf16-prefill-inputs")
    if args.require_prefill_fused_ffn and not args.prefill_fused_ffn:
        parser.error("--require-prefill-fused-ffn requires --prefill-fused-ffn")''';new='''    prefill_ffn_enabled = args.prefill_fused_ffn or "on" in (args.prefill_ffn_rounds or [])
    if prefill_ffn_enabled and not args.bf16_prefill_inputs:
        parser.error("packed prefill FFN requires --bf16-prefill-inputs")
    if args.prefill_ffn_rounds and (
        not args.policy_rounds or len(args.prefill_ffn_rounds) != len(args.policy_rounds)
    ):
        parser.error("--prefill-ffn-rounds must match --policy-rounds length")
    if args.require_prefill_fused_ffn and not prefill_ffn_enabled:
        parser.error("--require-prefill-fused-ffn requires an enabled FFN round")''';assert s.count(needle)==1;s=s.replace(needle,new,1);p.write_text(s)
subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt',str(r/'zig/pkg/inference/src/server/server.zig')],check=True)
subprocess.run(['/Users/ajroetker/.local/bin/ruff','format',str(p)],check=True)
(v/'engine81-freeze.json').write_text(json.dumps({p:sha(r/p)for p in f},indent=2)+'\n')
(v/'engine81_benchmark_concurrency.py').write_bytes(p.read_bytes())
for old,new in [('run_engine80_verify_gpu_build.py','run_engine81_verify_gpu_build.py'),('run_engine80_budget_policies.py','run_engine81_budget_policies.py')]:
 s=(v/old).read_text().replace('engine80','engine81');(v/new).write_text(s)
# Only the benchmark harness and driver change. Kernels/runtime/ops are byte-identical.
print('ENGINE81 RESIDENT FFN ROUNDS PREPARED',flush=True)
