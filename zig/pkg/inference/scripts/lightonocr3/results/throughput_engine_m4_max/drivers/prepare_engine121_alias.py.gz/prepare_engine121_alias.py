from pathlib import Path
import json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';plans=[(16,128,4,16,32,16),(16,256,8,16,32,8),(16,512,8,16,64,8),(32,256,8,16,64,16),(64,128,8,16,64,16),(8,512,8,8,64,8)];records=[]
for qb,kb,sgs,m,qkn,pvn in plans:
 pvtiles=(qb//m)*(64//pvn);npv=pvtiles//sgs;qkt=(qb//m)*(kb//qkn);assert qkt==sgs and pvtiles%sgs==0 and qb%sgs==0;ident=f'q{qb}k{kb}s{sgs}m{m}n{qkn}v{pvn}';records.append(dict(id=ident,q=qb,k=kb,sg=sgs,m=m,qkn=qkn,pvn=pvn))
 text=f'''#include <metal_stdlib>
#include <metal_tensor>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;using namespace mpp::tensor_ops;
struct VisionParams{{uint batch,seq_len,num_heads,head_dim,bias_mode,has_mask,layout,reserved1;}};
kernel void vision121(device half*q[[buffer(0)]],device half*k[[buffer(1)]],device half*v[[buffer(2)]],device const float*bias[[buffer(3)]],device const float*mask[[buffer(4)]],device float*output[[buffer(5)]],constant VisionParams&p[[buffer(6)]],uint tid[[thread_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]],uint group[[threadgroup_position_in_grid]]){{
 constexpr uint QB={qb},KB={kb},SG={sgs},M={m},QN={qkn},VN={pvn},RPS=QB/SG;
 const uint tiles=(p.seq_len+QB-1)/QB,qtile=group%tiles,h=(group/tiles)%p.num_heads,b=group/(tiles*p.num_heads),q0=qtile*QB,base=(b*p.num_heads+h)*p.reserved1*64;
 // Every score is loaded before the first compact probability write. The
 // upper half then holds corrections/sums. All PV readers drain before reuse.
 union Tile{{float scores[QB*KB];half probs[2*QB*KB];}};threadgroup Tile tile;
 threadgroup float*correction=tile.scores+QB*KB/2;threadgroup float*denom=correction+QB;
 float maxima[RPS],sums[RPS];for(uint pass=0;pass<RPS;pass++){{maxima[pass]=-INFINITY;sums[pass]=0;}}
 tensor<threadgroup half,dextents<int,2>,tensor_inline> P0(tile.probs,dextents<int,2>(KB,M),array<int,2>{{1,KB}});
 tensor<device half,dextents<int,2>,tensor_inline> V0(v+base,dextents<int,2>(VN,KB),array<int,2>{{1,64}});
 constexpr auto qkd=matmul2d_descriptor(M,QN,64,false,true,false);matmul2d<qkd,execution_simdgroups<1>> qkop;
 constexpr auto pvd=matmul2d_descriptor(M,VN,KB,false,false,false,matmul2d_descriptor::mode::multiply_accumulate);matmul2d<pvd,execution_simdgroups<1>> pvop;
 @ACCDECL@
 @ACCZERO@
 for(uint start=0;start<p.seq_len;start+=KB){{
  uint qr=(sg/(KB/QN))*M,kc=(sg%(KB/QN))*QN;
  tensor<device half,dextents<int,2>,tensor_inline> Q(q+base+(q0+qr)*64,dextents<int,2>(64,M),array<int,2>{{1,64}});
  tensor<device half,dextents<int,2>,tensor_inline> K(k+base+(start+kc)*64,dextents<int,2>(64,QN),array<int,2>{{1,64}});
  tensor<threadgroup float,dextents<int,2>,tensor_inline> S(tile.scores+qr*KB+kc,dextents<int,2>(QN,M),array<int,2>{{1,KB}});
  auto dot=qkop.get_destination_cooperative_tensor<decltype(Q),decltype(K),float>();qkop.run(Q,K,dot);dot.store(S);
  threadgroup_barrier(mem_flags::mem_threadgroup);
  float xs[RPS][KB/32];
  for(uint pass=0;pass<RPS;pass++){{uint row=sg+pass*SG;for(uint j=0;j<KB/32;j++){{float value=(q0+row<p.seq_len&&start+lane+j*32<p.seq_len)?tile.scores[row*KB+lane+j*32]:-INFINITY;xs[pass][j]=isfinite(value)?value:-INFINITY;}}}}
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint pass=0;pass<RPS;pass++){{uint row=sg+pass*SG;float mx=-INFINITY;for(uint j=0;j<KB/32;j++)mx=max(mx,xs[pass][j]);mx=simd_max(mx);
   float nm=max(maxima[pass],mx),c=isfinite(nm)&&isfinite(maxima[pass])?exp(maxima[pass]-nm):0,sum=0;
   for(uint j=0;j<KB/32;j++){{float e=isfinite(xs[pass][j])?exp(xs[pass][j]-nm):0;tile.probs[row*KB+lane+j*32]=half(e);sum+=e;}}
   sum=simd_sum(sum);maxima[pass]=nm;sums[pass]=sums[pass]*c+sum;if(lane==0){{correction[row]=c;denom[row]=sums[pass];}}
  }}
  threadgroup_barrier(mem_flags::mem_threadgroup);
  @PVSTEP@
  threadgroup_barrier(mem_flags::mem_threadgroup);
 }}
 @OUTPUT@
}}
'''
 text=text.replace('@ACCDECL@','\n'.join(f'auto out{a}=pvop.get_destination_cooperative_tensor<decltype(P0),decltype(V0),float>();'for a in range(npv))).replace('@ACCZERO@','\n'.join(f'for(ushort z=0;z<out{a}.get_capacity();z++)out{a}[z]=0;'for a in range(npv)))
 steps=[];outputs=[]
 for a in range(npv):
  steps.append(f'''{{uint index=sg+{a}*SG,row=(index/(64/VN))*M,dc=(index%(64/VN))*VN;
   for(ushort z=0;z<out{a}.get_capacity();z++){{auto c=out{a}.get_multidimensional_index(z);out{a}[z]*=correction[row+c[1]];}}
   tensor<threadgroup half,dextents<int,2>,tensor_inline> P(tile.probs+row*KB,dextents<int,2>(KB,M),array<int,2>{{1,KB}});
   tensor<device half,dextents<int,2>,tensor_inline> V(v+base+start*64+dc,dextents<int,2>(VN,KB),array<int,2>{{1,64}});pvop.run(P,V,out{a});}}''')
  outputs.append(f'''{{uint index=sg+{a}*SG,row=(index/(64/VN))*M,dc=(index%(64/VN))*VN;for(ushort z=0;z<out{a}.get_capacity();z++){{auto c=out{a}.get_multidimensional_index(z);uint rr=row+c[1],d=dc+c[0];if(q0+rr<p.seq_len)output[((b*p.seq_len+q0+rr)*p.num_heads+h)*64+d]=denom[rr]>0?out{a}[z]/denom[rr]:0;}}}}''')
 text=text.replace('@PVSTEP@','\n'.join(steps)).replace('@OUTPUT@','\n'.join(outputs));assert '@'not in text;(v/f'engine121_{ident}.metal').write_text(text)
(v/'engine121_plans.json').write_text(json.dumps(records,indent=2)+'\n')
s=(v/'engine120_vision_kernels.m').read_text().replace('engine120_','engine121_')
s=s.replace('engine121_threads=128;','engine121_threads=128,engine121_key_tile=128;')
s=s.replace('const size_t vision_padded = (seq_len + 127u) / 128u * 128u;','const size_t vision_alignment=engine121_candidate?MAX(128u,engine121_key_tile):128u;\n        const size_t vision_padded=(seq_len+vision_alignment-1u)/vision_alignment*vision_alignment;')
(v/'engine121_vision_kernels.m').write_text(s)
s=(v/'engine120_vision_checks.m').read_text().replace('engine120_','engine121_').replace('VISION120','VISION121').replace('vision120','vision121');(v/'engine121_vision_checks.m').write_text(s)
s=(v/'engine120_vision_probe.m').read_text().replace('engine120_','engine121_').replace('VISION120','VISION121').replace('vision120','vision121')
s=s.replace('select120','select121')
s=s.replace('static void select121(', 'static unsigned candidate_key121=128;\nstatic void select121(').replace('engine121_candidate=mode?p:nil;','engine121_candidate=mode?p:nil;engine121_key_tile=mode?candidate_key121:128;')
s=s.replace('size_t qb=[plan[@"q"]unsignedLongValue],threads=', 'candidate_key121=[plan[@"k"]unsignedIntValue];size_t qb=[plan[@"q"]unsignedLongValue],threads=')
(v/'engine121_vision_probe.m').write_text(s)
