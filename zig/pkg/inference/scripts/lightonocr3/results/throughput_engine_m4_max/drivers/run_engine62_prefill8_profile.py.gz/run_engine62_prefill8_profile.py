from pathlib import Path
import json,os,subprocess,sys,hashlib
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
model=sys.argv[1];n=int(os.environ.get('OCR_CASE_REQUESTS','64'));schedule=[int(x)for x in sys.argv[2:]]or[0,4,2,8,0]
c=int(os.environ.get('OCR_CASE_CONCURRENCY','48'));prefill=int(os.environ.get('OCR_CASE_PREFILL_ITEMS','1'));vf=int(os.environ.get('OCR_CASE_VISION_FRAME_BLOCKS','1'));tag=os.environ.get('OCR_CASE_TAG','vision4');vision_items=int(os.environ.get('OCR_CASE_VISION_BATCH_ITEMS','4'))
records=[]
for trial,chunks in enumerate(schedule):
 large=model=='4b';prefix=chunks or (0 if large else 16)
 label=f'rolling_chunks{chunks}_trial{trial}_c{c}_p{prefill}_vf{vf}_r{n}_{tag}'
 target=o/f'engine62_{model}_{label}';assert not target.exists(),target
 env=os.environ.copy();env.update(OCR_REFERENCE_LABEL='_primary_reference20_r0_auto_c64_r128',OCR_PHYSICAL32='0',OCR_PHYSICAL64='1',OCR_CONCURRENCY=str(c),OCR_REQUESTS=str(n),OCR_WIDE='1',OCR_SCRATCH_GIB='10'if large else'8',OCR_BACKEND_GIB='17'if large else'16',OCR_KV_GIB='4',OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1'if large else'0',OCR_BF16_PREFILL='1'if large else'0',OCR_BF16='0',OCR_VISION_BATCH='1'if vision_items>1 else'0',OCR_VISION_BATCH_ITEMS=str(vision_items),OCR_PREFILL_BATCH='1'if prefill>1 else'0',OCR_PREFILL_BATCH_ITEMS=str(prefill),OCR_VISION_FRAME_BLOCKS=str(vf),OCR_SINGLE_FRAME='1'if not prefix else'0',OCR_STREAM_FIRST=str(prefix),OCR_STREAM_CHUNK_LAYERS=str(chunks),OCR_GPU_GREEDY_STREAM='1'if prefix else'0',OCR_LOGICAL64='1',OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',OCR_ADMISSION_UNITS='512',OCR_DISABLE_64_ROW_TILE='0'if large else'1',OCR_DISABLE_WIDE_GATE_UP='0',OCR_WIDE64_GATE_UP='1'if large else'0',OCR_FULL64_GATE_UP='1'if large else'0',ANTFLY_FLORENCE_CPU_PREPROCESS='0')
 print('START',model,label,flush=True)
 with Path(f'/private/tmp/ocr-engine62-{model}-{label}-driver.txt').open('w')as log:r=subprocess.run([sys.executable,str(v/'run_engine62_budget_policies.py'),model+':'+label],env=env,stdout=log,stderr=subprocess.STDOUT)
 print('DONE',model,label,r.returncode,flush=True);assert r.returncode==0,(label,r.returncode)
 p=target/'report.json';d=json.loads(p.read_text());rs=d['results'][0];s=rs['policy_rounds'][0]
 assert rs['status']=='ok'and rs['serial_reference_parity']and rs['cross_runtime_content_parity']
 assert s['completed']==n and not s['admission_pressures']and not d['own_cpu_compile_overlap']
 records.append(dict(chunks=chunks,trial=trial,pages_per_second=s['pages_per_second'],process_cpu_ms=s['process_cpu_ms'],completed=n,all_native_pages_equal_serial_reference=True,report=str(p.relative_to(o)),report_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 (o/f'engine62_{model}_rolling_chunks_c{c}_p{prefill}_vf{vf}_r{n}_{tag}_audit.json').write_text(json.dumps(dict(status='running',candidates=records),indent=2)+'\n')
(o/f'engine62_{model}_rolling_chunks_c{c}_p{prefill}_vf{vf}_r{n}_{tag}_audit.json').write_text(json.dumps(dict(status='pass',candidates=records),indent=2)+'\n')
