from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=(v/'run_engine45_paired26.py').read_text().replace('paired26','paired27').replace('reference26','reference27')
needle="    best = max(candidates, key=lambda x: x['pages_per_second'])"
assert s.count(needle)==1
s=s.replace(needle,"""    if model=='4b':
        pp=out/'engine45_4b_gqa_ffn_disabled_primary_audit.json'
        if pp.exists():
            extra=json.loads(pp.read_text());assert extra['status']=='pass'
            candidates += [dict(x,ordinary_decoder_ffn_disabled=True) for x in extra['candidates']]
"""+needle)
needle="settings = [best['concurrency'], best['vision_frame_blocks'], best.get('stream_first_layers',0), best.get('wide64_gate_up',False), best.get('prefill_batch_items',1)]"
assert s.count(needle)==1
s=s.replace(needle,needle[:-1]+", best.get('ordinary_decoder_ffn_disabled',False)]")
s=s.replace("c, vf, prefix, wide64, prefill = profile['settings']","c, vf, prefix, wide64, prefill, gqa_off = profile['settings']")
s=s.replace("str(v / 'run_engine45_budget_policies.py')","str(v / ('run_engine45_gqa_ffn_ablation_budget.py' if gqa_off else 'run_engine45_budget_policies.py'))")
s=s.replace("0.8B engine43 streaming sweep","0.8B engine45 streaming sweep")
s=s.replace("4B engine45 kernel/prefill sweeps","4B engine45 kernel/prefill/ordinary-FFN ablations")
p=v/'run_engine45_paired27.py';assert not p.exists();p.write_text(s)
