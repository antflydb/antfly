from pathlib import Path
import hashlib,json,gzip,subprocess,re
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();freeze=json.loads((v/'engine62-freeze.json').read_text());assert all(sha(p)==h for p,h in freeze.items())
patch=subprocess.check_output(['git','diff','--',*freeze]);(o/'engine62_runtime.patch.gz').write_bytes(gzip.compress(patch,mtime=0));(o/'engine62_build_manifest.json').write_text(json.dumps(dict(status='aborted_before_qualification',reason='Review required closing device linear fallback as well as host fallback before using smaller vision reservation. Stopped only own unfinished build tree; no throughput run.',runtime_files_sha256=freeze,runtime_source_diff_sha256=hashlib.sha256(patch).hexdigest()),indent=2)+'\n')
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text();s=once(s,'    BOOL lightonocr3_projections_enabled;','    BOOL lightonocr3_projections_enabled;\n    bool lighton_vision_mpp_required;')
a='void termite_metal_decode_runtime_set_lightonocr3_projections('
s=once(s,a,'''// Scoped by the serialized vision caller. Failed qualification must not
// enter a different device kernel under the smaller resident working bound.
int termite_metal_decode_runtime_require_lighton_vision_mpp(termite_metal_decode_runtime *runtime, int required) {
    if (runtime == NULL) return 0;
    const int previous = runtime->lighton_vision_mpp_required ? 1 : 0;
    runtime->lighton_vision_mpp_required = required != 0;
    return previous;
}

'''+a)
i=s.index('int termite_metal_decode_runtime_apply_linear_device(');pos=s.index('    if (runtime->linear_pipeline == nil',i);s=s[:pos]+'    if (runtime->lighton_vision_mpp_required) return -65;\n'+s[pos:]
i=s.index('int termite_metal_decode_runtime_apply_linear_multi_row_device(');pos=s.index('        const int wide_mpp_rc =',i);s=s[:pos]+'''        if (runtime->lighton_vision_mpp_required) {
            const int rc = termite_metal_try_lightonocr3_mpp(runtime, slot, input_buffer, input_offset,
                rows, in_dim, out_dim, output_buffer, output_offset);
            // Zero means unsupported before encoding. Negative failures already
            // own their encoded work and propagate without any fallback replay.
            return rc == 1 ? 0 : rc < 0 ? rc : -65;
        }
'''+s[pos:];p.write_text(s)
p=Path('zig/pkg/inference/src/backends/metal_runtime.zig');s=p.read_text();needle='pub extern fn termite_metal_decode_runtime_set_lightonocr3_projections';s=once(s,needle,'pub extern fn termite_metal_decode_runtime_require_lighton_vision_mpp(runtime: ?*RawMetalDecodeRuntime, required: c_int) c_int;\n'+needle);p.write_text(s)
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text();i=s.index('    fn decoderRuntimeApplyLinearOp(');pos=s.index('        var input =',i);s=s[:pos]+'''        var strict_runtime: ?*metal_runtime_mod.RawMetalDecodeRuntime = null;
        var previous: c_int = 0;
        if (self.require_qwen_vision_resident) {
            strict_runtime = self.provider_impl.raw_decode_runtime orelse return error.PreparedVisionUnavailable;
            previous = metal_runtime_mod.termite_metal_decode_runtime_require_lighton_vision_mpp(strict_runtime, 1);
        }
        defer if (strict_runtime) |runtime| {
            _ = metal_runtime_mod.termite_metal_decode_runtime_require_lighton_vision_mpp(runtime, previous);
        };
'''+s[pos:];p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text();test='''static int resident_vision_dispatch_check(termite_metal_decode_runtime *r) {
    const size_t rows = 128, in = 768, out = 768, count = rows * in, outputs = rows * out;
    id<MTLBuffer> source = [r->device newBufferWithLength:count * 4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> input = [r->device newBufferWithLength:count * 4 options:MTLResourceStorageModePrivate];
    id<MTLBuffer> output = [r->device newBufferWithLength:(outputs + 8) * 4 options:MTLResourceStorageModeShared];
    uint16_t *weights = malloc(in * out * 2);
    float *bias = calloc(out, 4);
    if (!source || !input || !output || !weights || !bias) return 140;
    for (size_t i = 0; i < count; ++i) ((float *)source.contents)[i] = 1;
    for (size_t i = 0; i < in * out; ++i) weights[i] = round_bf16(1);
    if (termite_metal_decode_runtime_prepare_linear_bf16(r, 0, (uint8_t *)weights, in * out * 2, bias, in, out)) return 141;
    setenv("TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS", "0", 1);
    setenv("TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS", "0", 1);
    if (termite_metal_decode_runtime_require_lighton_vision_mpp(r, 1) != 0) return 142;
    uint32_t *guard = output.contents;
    for (size_t i = 0; i < outputs + 8; ++i) guard[i] = 0xdeadbeefu;
    if (termite_metal_decode_runtime_begin_frame(r) ||
        termite_metal_buffer_slice_last_dim_2d(r, (__bridge void *)source, 0, rows, in, 0, in, (__bridge void *)input, 0) ||
        termite_metal_decode_runtime_apply_linear_multi_row_device(r, 0, (__bridge void *)input, 0, rows, in, out, (__bridge void *)output, 16) ||
        termite_metal_decode_runtime_submit_frame(r) || termite_metal_decode_runtime_wait_frame(r)) return 143;
    for (size_t i = 0; i < outputs; ++i) if (((float *)output.contents)[i + 4] != 768) return 144;
    for (size_t i = 0; i < 4; ++i) if (guard[i] != 0xdeadbeefu || guard[outputs + 4 + i] != 0xdeadbeefu) return 145;
    for (size_t mode = 0; mode < 5; ++mode) {
        for (size_t i = 0; i < outputs + 8; ++i) guard[i] = 0x1234abcdu;
        id<MTLComputePipelineState> saved = r->lightonocr3_mpp_f32_pipeline;
        const uint8_t dtype = r->linear_weight_dtypes[0];
        if (mode == 0) r->lightonocr3_mpp_f32_pipeline = nil;
        if (mode == 1) r->linear_weight_dtypes[0] = TERMITE_METAL_DENSE_LINEAR_DTYPE_F16;
        if (mode == 2) setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_MPP", "1", 1);
        if (termite_metal_decode_runtime_begin_frame(r)) return 146;
        const int rc = mode == 4
            ? termite_metal_decode_runtime_apply_linear_device(r, 0, (__bridge void *)input, 0, in, out, (__bridge void *)output, 16)
            : termite_metal_decode_runtime_apply_linear_multi_row_device(r, 0, (__bridge void *)input, 0, mode == 3 ? 16 : rows, in, out, (__bridge void *)output, 16);
        if (termite_metal_decode_runtime_cancel_frame(r)) return 147;
        r->lightonocr3_mpp_f32_pipeline = saved;
        r->linear_weight_dtypes[0] = dtype;
        unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_MPP");
        if (rc != -65) { fprintf(stderr, "resident_vision_dispatch mode=%zu rc=%d expected=-65\\n", mode, rc); return 148; }
        for (size_t i = 0; i < outputs + 8; ++i) if (guard[i] != 0x1234abcdu) return 149;
    }
    if (termite_metal_decode_runtime_require_lighton_vision_mpp(r, 0) != 1) return 150;
    if (termite_metal_decode_runtime_begin_frame(r) ||
        termite_metal_decode_runtime_apply_linear_multi_row_device(r, 0, (__bridge void *)input, 0, 16, in, out, (__bridge void *)output, 16) ||
        termite_metal_decode_runtime_submit_frame(r) || termite_metal_decode_runtime_wait_frame(r)) return 151;
    for (size_t i = 0; i < 16 * out; ++i) if (((float *)output.contents)[i + 4] != 768) return 152;
    unsetenv("TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS");
    unsetenv("TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS");
    free(weights); free(bias);
    fprintf(stderr, "resident_vision_dispatch positive=pass gpu_producer=pass missing_pipeline=pass dtype=pass disable=pass shape=pass scalar=pass no_fallback_writes=pass legacy_restored=pass\\n");
    return 0;
}

''';s=once(s,'int main(int argc, const char **argv) {',test+'int main(int argc, const char **argv) {');needle='        if (argc == 2 && strcmp(argv[1], "--check-vision-workspace-cache") == 0) {';s=once(s,needle,'''        if (argc == 2 && strcmp(argv[1], "--check-resident-vision-dispatch") == 0) {
            const int rc = resident_vision_dispatch_check(r);
            termite_metal_decode_runtime_destroy(r);
            return rc;
        }
'''+needle);p.write_text(s)
subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt','zig/pkg/inference/src/ops/metal_compute.zig','zig/pkg/inference/src/backends/metal_runtime.zig'],check=True)
freeze={p:sha(p)for p in freeze};(v/'engine63-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
for source,dest in [('run_engine62_verify_gpu_build.py','run_engine63_verify_gpu_build.py'),('run_engine62_budget_policies.py','run_engine63_budget_policies.py'),('run_engine62_prefill8_profile.py','run_engine63_prefill8_profile.py'),('run_engine62_metal_disabled.py','run_engine63_metal_disabled.py'),('engine62_benchmark_concurrency.py','engine63_benchmark_concurrency.py')]:
 p=v/dest;assert not p.exists();p.write_text((v/source).read_text().replace('engine62','engine63'))
# C shader strings are unchanged by the dispatch precondition.
def shaders(s):
 d={}
 for m in re.finditer(r'^static NSString \\*(\\w+)\\(void\\) \\{',s,re.M):
  end=s.index('\\n}\\n',m.start())+3;d[m[1]]=hashlib.sha256(s[m.start():end].encode()).hexdigest()
 return d
print('engine63 frozen: no host fallback and mandatory MPP device dispatch under resident budget')
