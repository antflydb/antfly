from pathlib import Path
import subprocess,sys
v=Path('.venv-lighton-vllm-metal')
for helper,args,label in [
 ('run_engine45_wide64_cases.py',['primary'],'hybrid-primary'),
 ('run_engine45_stream_cases.py',['primary','08'],'small-stream-primary'),
 ('run_engine45_florence_case_verify.py',['primary','8','16','1'],'florence-batch8-primary'),
 ('run_engine45_florence_case_verify.py',['primary','12','24','1'],'florence-batch12-primary')]:
 print('START',helper,args,flush=True)
 with Path('/private/tmp/ocr-engine45-'+label+'-driver.txt').open('w')as log:
  r=subprocess.run([sys.executable,str(v/helper),*args],stdout=log,stderr=subprocess.STDOUT)
 print('DONE',helper,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
