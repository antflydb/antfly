from pathlib import Path
import hashlib,json,os,subprocess,time,datetime,psutil
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while 'ENGINE76 FMA PROBE DONE' not in Path('/private/tmp/ocr-engine76-fma-afterqual-parent.txt').read_text():time.sleep(5)
m=json.loads((o/'engine75_recurrent_probe_build_manifest.json').read_text());assert sha(m['binary'])==m['binary_sha256'] and all(sha(r/p)==h for p,h in m['inputs'].items())
audit=o/'engine75_recurrent_probe_retry_audit.json';assert not audit.exists();d=dict(status='running',primary_throughput_eligible=False,scope='Retry the previously unmeasured value-major F32 state-layout prototype after the small FMA probe and before any native throughput process starts. Same binary/inputs. Full logical state/output checks over ten continued steps, canaries and 24-layer ABBA working sets only; not runtime interoperability qualification.',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),build_manifest_sha256=sha(o/'engine75_recurrent_probe_build_manifest.json'),binary_sha256=m['binary_sha256'],checks=[])
def save():audit.write_text(json.dumps(d,indent=2)+'\n')
save();counts=[8192,32768,32,32,32,32,32768,32768,524288,8192,64,4096,4096,128,4096];writes=[7,8,9,10,11,14]
for pages in [33,48,64]:
 available=psutil.virtual_memory().available;need=24*pages*4*(sum(counts)+15*8+sum(counts[i]for i in writes))+256*1024**2;reserve=6*1024**3
 row=dict(pages=pages,available_bytes=available,working_plus_gold_estimate_bytes=need,os_reserve_bytes=reserve)
 if available<need+reserve:
  row.update(status='skipped_before_allocation');d['checks'].append(row);save();print('SKIP RETRY MEMORY',row,flush=True);continue
 log=Path(f'/private/tmp/ocr-engine75-layout-retry-pages{pages}.txt');env=dict(os.environ,ENGINE75_PAGES=str(pages),ANTFLY_LIGHTONOCR3_THROUGHPUT='0',TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY='1',TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP='0',TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP='0')
 print('START LAYOUT RETRY',pages,flush=True)
 with log.open('w')as f:result=subprocess.run([m['binary']],stdout=f,stderr=subprocess.STDOUT,env=env,timeout=900)
 records=[json.loads(x)for x in log.read_text().splitlines()if x.startswith('{"pages":')]
 row.update(status='pass'if result.returncode==0 else'failed',exit_code=result.returncode,log=str(log),log_sha256=sha(log),records=records);d['checks'].append(row);save()
 if result.returncode:d['status']='failed';save();raise SystemExit(result.returncode)
 assert len(records)==4 and all(x['full_output_state_max_abs']<=2e-4 for x in records)
 print('DONE LAYOUT RETRY',pages,flush=True)
d['status']='prototype_pass'if any(x.get('records')for x in d['checks'])else'compiled_only_insufficient_memory';save();print('ENGINE75 LAYOUT RETRY DONE',d['status'],flush=True)
