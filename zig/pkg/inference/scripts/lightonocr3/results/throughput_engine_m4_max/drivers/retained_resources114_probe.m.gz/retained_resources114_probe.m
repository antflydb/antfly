#import <Foundation/Foundation.h>
#include <mach/mach_time.h>
static uint64_t now_ns(void){static mach_timebase_info_data_t b; if(!b.denom)mach_timebase_info(&b);return mach_absolute_time()*b.numer/b.denom;}
static double trial(NSArray *objects,size_t rows,bool dedup,size_t frames){
 const size_t layers=24,cols=15,cap=4096;uint64_t start=now_ns();
 for(size_t f=0;f<frames;f++){@autoreleasepool{
  CFMutableArrayRef a=CFArrayCreateMutable(NULL,0,&kCFTypeArrayCallBacks);
  CFMutableSetRef keys=dedup?CFSetCreateMutable(NULL,0,NULL):NULL;
  for(size_t l=0;l<layers;l++)for(size_t r=0;r<rows;r++)for(size_t c=0;c<cols;c++){
   size_t i=c<2?(l*64+r)*2+c:c<6?3072+l*4+c-2:3168+c-6;
   const void *p=(__bridge const void *)objects[i];
   if(keys&&CFSetContainsValue(keys,p))continue;
   CFArrayAppendValue(a,p);
   if(keys&&(size_t)CFSetGetCount(keys)<cap)CFSetAddValue(keys,p);
  }
  const size_t expected=dedup?layers*rows*2+layers*4+9:layers*rows*cols;
  if((size_t)CFArrayGetCount(a)!=expected)abort();
  if(keys)CFRelease(keys);CFRelease(a);
 }}return (now_ns()-start)/1e6;
}
int main(void){@autoreleasepool{
 NSMutableArray *objects=[NSMutableArray arrayWithCapacity:3200];for(size_t i=0;i<3200;i++)[objects addObject:[NSObject new]];
 puts("scope=CPU-only approximate recurrent-retain topology; no GPU/model timing or speed claim");
 for(size_t rows=32;rows<=64;rows+=(rows==32?16:15)){
  trial(objects,rows,false,10);trial(objects,rows,true,10);
  for(size_t order=0;order<4;order++){
   double a,b;if(order&1){b=trial(objects,rows,true,100);a=trial(objects,rows,false,100);}else{a=trial(objects,rows,false,100);b=trial(objects,rows,true,100);}
   printf("rows=%zu order=%zu frames=100 array_ms=%.6f set_ms=%.6f ratio=%.6f\n",rows,order,a,b,a/b);
  }
  if(rows==63)break;
 }
}}
