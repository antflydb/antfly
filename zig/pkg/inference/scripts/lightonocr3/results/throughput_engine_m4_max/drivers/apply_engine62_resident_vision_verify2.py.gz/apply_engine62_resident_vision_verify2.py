from pathlib import Path
import json,hashlib,subprocess
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();freeze=json.loads((v/'engine61-freeze.json').read_text());assert all(sha(p)==h for p,h in freeze.items())
d=json.loads((o/'paired30_4b_comparison_audit.json').read_text());assert len(d['comparisons'])==2 and all(x['native_to_vllm_ratio']<1 for x in d['comparisons']);d.update(status='early_stop_forward_losses',reason='Both profiles lost the first fresh control. Controller stopped during the active reverse candidate leg; that GPU child finished unchanged. C64 reverse and second reference were not run. Reverse candidate result is diagnostic only.')
p=o/'engine61_4b_paired30_candidate_r1_c56_p1_v1_vf4_r128/report.json';r=json.loads(p.read_text());assert r['results'][0]['status']=='ok' and r['results'][0]['serial_reference_parity'];d['unpaired_reverse_candidate']=dict(report=str(p.relative_to(o)),report_sha256=sha(p),pages_per_second=r['results'][0]['policy_rounds'][0]['pages_per_second']);(o/'paired30_4b_verified_partial_audit.json').write_text(json.dumps(d,indent=2)+'\n')

def change(path,fn):
 p=Path(path);old=p.read_text();new=fn(old);assert old!=new,path;p.write_text(new)
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
model='zig/pkg/inference/src/models/gpt.zig'
change(model,lambda s:once(s,'    qwen35_device_only_state: bool = false,','    qwen35_device_only_state: bool = false,\n    // Internal Metal-only vision admission contract; never loaded from model JSON.\n    qwen35_metal_resident_vision: bool = false,'))
projector='zig/pkg/inference/src/architectures/qwen3vl_projector.zig'
s=Path(projector).read_text();needle='fn estimateAdmissionForImageDimensions('
elig='''/// A closed Metal graph with these two qualified vision geometries can use
/// the linear working bound below. Callers must enforce resident execution.
pub fn supportsResidentVisionBudget(config: gpt_config.Config) bool {
    const h = config.vision_hidden_size;
    return config.family == .qwen3_5 and (h == 768 or h == 1024) and
        config.vision_num_attention_heads == h / 64 and
        config.vision_intermediate_size == h * 4 and
        config.vision_spatial_merge_size == 2 and
        config.vision_deepstack_visual_indexes_len == 0;
}

'''
s=once(s,needle,elig+needle);start=s.index(needle);pos=s.index('    try limits.validate();',start);s=s[:pos]+s[pos:].replace('    try limits.validate();','    try limits.validate();\n    if (config.qwen35_metal_resident_vision and !supportsResidentVisionBudget(config)) return error.UnsupportedResidentVisionBudget;',1)
a='    backend_scratch = try admissionAdd(backend_scratch, @max(attention_scores, ffn_intermediates));'
b='''    // Resident blocks reject every host fallback for norm, copies, linear,
    // activation, residual and SDPA. No S-by-S score tensor can be allocated.
    // Keep a deliberately loose linear bound even without pool reuse: all
    // block intermediates <=24H, BF16 projection packs <=3.5H, initial upload
    // <=H. Existing 7H + this 20H + merge (>=3H) covers >=30H before the
    // separately charged two SDPA packing banks. Frame grouping still scales
    // the complete bound, including weights/output ownership as before.
    const attention_working = if (config.qwen35_metal_resident_vision)
        try admissionMul(hidden_rows, 20)
    else
        attention_scores;
    backend_scratch = try admissionAdd(backend_scratch, @max(attention_working, ffn_intermediates));'''
s=once(s,a,b);s=once(s,'const Config = struct {\n    is_qwen35: bool = false,','const Config = struct {\n    is_qwen35: bool = false,\n    require_metal_resident_vision: bool = false,')
s=once(s,'        .is_qwen35 = config.family == .qwen3_5,','        .is_qwen35 = config.family == .qwen3_5,\n        .require_metal_resident_vision = config.qwen35_metal_resident_vision,')
helper='''const ResidentVisionScope = struct {
    cb: *const ComputeBackend,
    input: CT,
    owned: bool = false,
    enabled: bool = false,
    previous: bool = false,

    fn begin(cb: *const ComputeBackend, cfg: Config, input: CT) !ResidentVisionScope {
        var scope = ResidentVisionScope{ .cb = cb, .input = input };
        if (!cfg.require_metal_resident_vision) return scope;
        if (cb.kind() != .metal) return error.PreparedVisionUnavailable;
        if (comptime @import("build_options").enable_metal) {
            const M = metal_compute_mod.MetalCompute;
            if (!M.debugHasDeviceTensor(cb, input)) {
                scope.input = (try M.makeDeviceResident(cb, input)) orelse return error.PreparedVisionUnavailable;
                scope.owned = true;
            }
            scope.previous = M.requireQwenVisionResident(cb, true);
            scope.enabled = true;
            return scope;
        }
        return error.PreparedVisionUnavailable;
    }

    fn deinit(scope: *ResidentVisionScope) void {
        if (scope.enabled) _ = metal_compute_mod.MetalCompute.requireQwenVisionResident(scope.cb, scope.previous);
        if (scope.owned) scope.cb.free(scope.input);
    }
};

'''
s=once(s,'fn encoderBlock(',helper+'fn encoderBlock(')
start=s.index('fn encoderBlock(');end=s.index('\nfn visionAttention(',start);chunk=s[start:end];chunk=once(chunk,'    input: CT,','    input_ct: CT,');chunk=once(chunk,') !CT {',') !CT {\n    var resident_scope = try ResidentVisionScope.begin(cb, cfg, input_ct);\n    defer resident_scope.deinit();\n    const input = resident_scope.input;');s=s[:start]+chunk+s[end:]
start=s.index('fn mergeProjectedNamed(');end=s.index('\nfn layerNormNamed(',start);chunk=s[start:end];chunk=once(chunk,'    hidden: CT,','    hidden_ct: CT,');chunk=once(chunk,') !CT {',') !CT {\n    var resident_scope = try ResidentVisionScope.begin(cb, cfg, hidden_ct);\n    defer resident_scope.deinit();\n    const hidden = resident_scope.input;');s=s[:start]+chunk+s[end:]
s+='''

test "LightOnOCR3 resident vision budget preserves host banks and complete grouped working bounds" {
    for ([_]usize{768, 1024}) |h| {
        var cfg = gpt_config.Config{ .family = .qwen3_5, .hidden_size = if (h == 768) 1024 else 2560,
            .vision_hidden_size = @intCast(h), .vision_intermediate_size = @intCast(h * 4),
            .vision_num_attention_heads = @intCast(h / 64), .vision_patch_size = 16, .vision_spatial_merge_size = 2 };
        const dims = image.EncodedImageInfo{ .width = 2048, .height = 2048 };
        var limits = Limits{ .max_merged_tokens = 4096, .hard_max_merged_tokens = 4096 };
        const old = try estimateAdmissionForImageDimensions(&.{dims}, cfg, limits);
        cfg.qwen35_metal_resident_vision = true;
        const current = try estimateAdmissionForImageDimensions(&.{dims}, cfg, limits);
        const geometry = try targetGeometryForLayout(16, 2, dims.width, dims.height, limits);
        const hidden = geometry.patchCount() * h * @sizeOf(f32);
        const merge = geometry.tokenCount() * (12 * h + cfg.hidden_size) * @sizeOf(f32);
        const packed = std.mem.alignForward(usize, @min(geometry.patchCount(), 4096), 128) * h * 3 * @sizeOf(f32);
        try std.testing.expectEqual(27 * hidden + merge + packed, current.backend_scratch_bytes);
        try std.testing.expect(current.backend_scratch_bytes >= 30 * hidden + packed);
        try std.testing.expect(current.backend_scratch_bytes < old.backend_scratch_bytes);
        try std.testing.expectEqual(old.host_scratch_bytes, current.host_scratch_bytes);
        try std.testing.expectEqual(old.visual_tokens, current.visual_tokens);
        limits.metal_frame_blocks = 4;
        const grouped = try estimateAdmissionForImageDimensions(&.{dims}, cfg, limits);
        try std.testing.expectEqual(current.backend_scratch_bytes * 4, grouped.backend_scratch_bytes);
        try std.testing.expectEqual(current.host_scratch_bytes * 4, grouped.host_scratch_bytes);
        cfg.family = .qwen3_vl;
        try std.testing.expectError(error.UnsupportedResidentVisionBudget, estimateAdmissionForImageDimensions(&.{dims}, cfg, limits));
    }
}
''';Path(projector).write_text(s)
mc='zig/pkg/inference/src/ops/metal_compute.zig';s=Path(mc).read_text();s=once(s,'    require_prepared_vision: bool = false,','    require_prepared_vision: bool = false,\n    require_qwen_vision_resident: bool = false,')
a='    pub fn requireEmbeddingVisionPlan(cb: *const ops.ComputeBackend, require: bool) bool {'
b='''    pub fn requireQwenVisionResident(cb: *const ops.ComputeBackend, require: bool) bool {
        if (cb.kind() != .metal) return false;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        const previous = self.require_qwen_vision_resident;
        self.require_qwen_vision_resident = require;
        return previous;
    }

'''+a;s=once(s,a,b)
a='    pub fn requireEmbeddingVisionPlan(_: *const ops.ComputeBackend, _: bool) bool {';s=once(s,a,'    pub fn requireQwenVisionResident(_: *const ops.ComputeBackend, _: bool) bool {\n        return false;\n    }\n\n'+a)
# Guard each relevant host fallback before a CPU download or allocation.
def guard_range(s,start,end,needle):
 i=s.index(start);j=s.index(end,i);chunk=s[i:j];chunk=once(chunk,needle,'        if (self.require_qwen_vision_resident) return error.PreparedVisionUnavailable;\n'+needle);return s[:i]+chunk+s[j:]
s=guard_range(s,'    fn linearOpWithPlannedDispatch(','    fn linearPlannedOp(','        const result = try linearNoBiasOpWithPlannedDispatch')
s=guard_range(s,'    fn layerNormOp(','    fn layerNorm', '        const input_owned =') if False else s
start=s.index('    fn layerNormOp(');pos=s.index('        const input_owned =',start);s=s[:pos]+'        if (self.require_qwen_vision_resident) return error.PreparedVisionUnavailable;\n'+s[pos:]
s=guard_range(s,'    fn applyUnaryActivationOp(','    fn gqaCausalAttentionOp(','        const input_data = try hostSliceForBuf(input_buf);')
start=s.index('    fn addOp(');pos=s.index('        if (a_buf.lazy_multiply != null or b_buf.lazy_multiply != null)',start);s=s[:pos]+'        if (self.require_qwen_vision_resident) return error.PreparedVisionUnavailable;\n'+s[pos:]
start=s.index('    fn sliceLastDimOp(');pos=s.index('        const input_data = try hostSliceForBuf(input);',start);s=s[:pos]+'        if (self.require_qwen_vision_resident) return error.PreparedVisionUnavailable;\n'+s[pos:]
start=s.index('    fn scaledDotProductAttentionQwen3VlVisionOp(');pos=s.index('        if (try self.tryScaledDotProductAttentionResident(',start);s=s[:pos]+'''        if (self.require_qwen_vision_resident and
            (denseDeviceF32(q_ct) == null or denseDeviceF32(k_ct) == null or denseDeviceF32(v_ct) == null)) return error.PreparedVisionUnavailable;
'''+s[pos:];pos=s.index('        return self.hostFallbackSdpa(',pos);s=s[:pos]+'        if (self.require_qwen_vision_resident) return error.PreparedVisionUnavailable;\n'+s[pos:]
s+='''

test "LightOnOCR3 strict resident vision rejects fallbacks and restores ordinary execution" {
    if (!build_options.enable_metal or !metal_runtime_mod.metalDeviceAvailable()) return error.SkipZigTest;
    const a = std.testing.allocator;
    var store = testMetalWeightStoreInit(a);
    defer store.lazy_weights.deinit(a);
    var compute = try MetalCompute.init(a, &store, null);
    defer compute.deinit();
    var cb = compute.computeBackend();
    const input_data = [_]f32{1} ** (4 * 64);
    const weights = [_]f32{1} ** (64 * 64);
    const zeros = [_]f32{0} ** 64;
    const input = try cb.fromFloat32Shape(&input_data, &.{4, 64});
    defer cb.free(input);
    const weight = try cb.fromFloat32Shape(&weights, &.{64, 64});
    defer cb.free(weight);
    const bias = try cb.fromFloat32Shape(&zeros, &.{64});
    defer cb.free(bias);
    try std.testing.expect(!MetalCompute.requireQwenVisionResident(&cb, true));
    defer { _ = MetalCompute.requireQwenVisionResident(&cb, false); }
    try std.testing.expectError(error.PreparedVisionUnavailable, cb.linear(input, weight, bias, 4, 64, 64));
    try std.testing.expectError(error.PreparedVisionUnavailable, cb.scaledDotProductAttentionQwen3VlVision(input, input, input, 1, 4, 1, 64));
    const device = (try MetalCompute.makeDeviceResident(&cb, input)) orelse return error.TestUnexpectedResult;
    defer cb.free(device);
    const attended = try cb.scaledDotProductAttentionQwen3VlVision(device, device, device, 1, 4, 1, 64);
    defer cb.free(attended);
    const result = try cb.toFloat32(attended, a);
    defer a.free(result);
    for (result) |value| try std.testing.expectApproxEqAbs(@as(f32, 1), value, 0.00001);
    try std.testing.expectError(error.PreparedVisionUnavailable, cb.scaledDotProductAttentionQwen3VlVision(device, device, device, 1, 4, 2, 64));
    try std.testing.expect(MetalCompute.requireQwenVisionResident(&cb, false));
    const ordinary = try cb.linear(input, weight, bias, 4, 64, 64);
    defer cb.free(ordinary);
    const ordinary_result = try cb.toFloat32(ordinary, a);
    defer a.free(ordinary_result);
    for (ordinary_result) |value| try std.testing.expectApproxEqAbs(@as(f32, 64), value, 0.00001);
}
''';Path(mc).write_text(s)
server='zig/pkg/inference/src/server/server.zig';s=Path(server).read_text();s=once(s,'            queued_phase_priority: bool = false,','            queued_phase_priority: bool = false,\n            resident_vision_budget: bool = false,');s=once(s,'                var features = fromEnvironment();','                var features = fromEnvironment();\n                features.resident_vision_budget = cfg.qwen35_metal_resident_vision;')
a='            platform.env.getenvBool("ANTFLY_LIGHTONOCR3_DEVICE_RECURRENT_STATE");';s=once(s,a,a+'\n        cfg.qwen35_metal_resident_vision = metal_runtime.qualifiedM4DeviceDefault() and cfg.hasQwen35VisionArchitectureContract() and\n            qwen3vl_projector.supportsResidentVisionBudget(cfg) and platform.env.getenvBool("ANTFLY_LIGHTONOCR3_RESIDENT_VISION_BUDGET");')
a='                    std.debug.print("LIGHTONOCR3 vision_late_seal=';pos=s.index(a);s=s[:pos]+'                    std.debug.print("LIGHTONOCR3 resident_vision_budget={d}\\n", .{@intFromBool(ctx.features.resident_vision_budget)});\n'+s[pos:];Path(server).write_text(s)
bench='zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';s=Path(bench).read_text();s=once(s,'    args = parser.parse_args()','    parser.add_argument("--resident-vision-budget", action="store_true", help="Require resident vision operations and admit their bounded linear workspace")\n    args = parser.parse_args()');s=once(s,'    env["ANTFLY_LIGHTONOCR3_STREAM_CHUNKS"] =','    env["ANTFLY_LIGHTONOCR3_RESIDENT_VISION_BUDGET"] = "1" if args.resident_vision_budget else "0"\n    env["ANTFLY_LIGHTONOCR3_STREAM_CHUNKS"] =');s=once(s,'        "large_vision_pack_reuse": args.large_vision_pack_reuse,','        "large_vision_pack_reuse": args.large_vision_pack_reuse,\n        "resident_vision_budget": args.resident_vision_budget,');Path(bench).write_text(s)
subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt',model,projector,mc,server],check=True)
freeze={p:sha(p)for p in freeze};(v/'engine62-freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
for src,dest in [('run_engine61_verify_gpu_build.py','run_engine62_verify_gpu_build.py'),('run_engine61_budget_policies.py','run_engine62_budget_policies.py'),('run_engine61_prefill8_profile.py','run_engine62_prefill8_profile.py'),('run_engine61_metal_disabled.py','run_engine62_metal_disabled.py'),('run_engine61_build_qualification.py','run_engine62_build_qualification.py')]:
 p=v/dest;assert not p.exists();p.write_text((v/src).read_text().replace('engine61','engine62'))
(v/'engine62_benchmark_concurrency.py').write_text(Path(bench).read_text())
p=v/'run_engine62_verify_gpu_build.py';s=p.read_text();s=once(s,"env.pop('TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP',None)","env['ANTFLY_LIGHTONOCR3_RESIDENT_VISION_BUDGET']='1'\nenv.pop('TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP',None)");p.write_text(s)
p=v/'run_engine62_budget_policies.py';s=p.read_text();a=" if large_vision_pack:cmd+=['--large-vision-pack-reuse']";s=once(s,a,a+"\n resident_vision=os.environ.get('OCR_RESIDENT_VISION_BUDGET','0')=='1'\n if resident_vision:cmd+=['--resident-vision-budget']");a="    workspace_mode=re.findall";pos=s.index(a);s=s[:pos]+"    values=re.findall(r'LIGHTONOCR3 resident_vision_budget=(\\d+)',section);assert values and all((int(x)==1)==resident_vision for x in values),(values,resident_vision)\n    report['resident_vision_budget']=resident_vision\n"+s[pos:];p.write_text(s)
print('engine62 frozen: explicit closed resident graph, conservative linear working bound, C and shaders unchanged')
