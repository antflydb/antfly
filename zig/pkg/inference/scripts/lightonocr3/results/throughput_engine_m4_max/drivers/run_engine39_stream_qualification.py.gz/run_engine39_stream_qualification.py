from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

v = Path('.venv-lighton-vllm-metal')
out = Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
records = []
for model in ['08', '4b']:
    for stream in [False, True]:
        blocks = 1 if stream else 2
        label = f'vision_stream{int(stream)}_physical64_c64_vf{blocks}_r64_qualification'
        dest = out / f'engine39_{model}_{label}'
        assert not (dest / 'report.json').exists()
        env = os.environ.copy()
        env.update(OCR_REFERENCE_LABEL='_primary_reference20_r0_auto_c64_r128', OCR_PHYSICAL32='0',
                   OCR_PHYSICAL64='1', OCR_CONCURRENCY='64', OCR_REQUESTS='64', OCR_WIDE='1',
                   OCR_SCRATCH_GIB='10' if model == '4b' else '8', OCR_BACKEND_GIB='17' if model == '4b' else '16',
                   OCR_KV_GIB='4', OCR_CPU_PREPROCESS='1', OCR_PREFILL_DECODE_STREAK='0',
                   OCR_POLICIES='engineepoch', OCR_SHARED_CORE='1' if model == '4b' else '0',
                   OCR_BF16_PREFILL='1' if model == '4b' else '0', OCR_BF16='0', OCR_VISION_BATCH='0',
                   OCR_VISION_FRAME_BLOCKS=str(blocks), OCR_SINGLE_FRAME='1', OCR_STREAM_FIRST='0',
                   OCR_LOGICAL64='1', OCR_SHARED_DECODER_SCRATCH='1', OCR_DEVICE_RECURRENT_STATE='1',
                   OCR_ENCODER_SCOPES='1', OCR_ADMISSION_UNITS='512', OCR_VISION_STREAM=str(int(stream)),
                   OCR_DISABLE_64_ROW_TILE='0' if model == '4b' else '1')
        print('START', model, stream, flush=True)
        with Path(f'/private/tmp/ocr-engine39-{model}-stream{int(stream)}-qualification-driver.txt').open('w') as log:
            result = subprocess.run([sys.executable, str(v / 'run_engine39_budget_no_prefill_policies.py'), model + ':' + label], env=env, stdout=log, stderr=subprocess.STDOUT)
        assert result.returncode == 0, (model, stream, result.returncode)
        p = dest / 'report.json'
        d = json.loads(p.read_text())
        r = d['results'][0]
        x = r['policy_rounds'][0]
        assert r['status'] == 'ok' and r['serial_reference_parity'] and r['cross_runtime_content_parity']
        assert x['completed'] == 64 and not x['admission_pressures'] and max(x['packed_core_rows_observed']) > 32
        oracle = json.loads((out / f'vllm_{model}_primary_reference20_r0_auto_c64_r128/report.json').read_text())
        assert {t['image_index']: t['text'] for t in r['references']} == {t['image_index']: t['text'] for t in oracle['references']}
        records.append(dict(model=model, vision_stream=stream, vision_frame_blocks=blocks,
                            admitted_retained_vision_blocks=2, completed=64, full_fixture_string_identity=True,
                            all_native_pages_equal_serial_reference=True, stream_stats=x['vision_stream_stats'],
                            report=str(p.relative_to(out)), report_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
        (out / 'engine39_stream_qualification_audit.json').write_text(json.dumps(dict(status='running', checks=records), indent=2) + '\n')
        print('DONE', model, stream, flush=True)
(out / 'engine39_stream_qualification_audit.json').write_text(json.dumps(dict(status='pass', checks=records), indent=2) + '\n')
