from pathlib import Path
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text()
s=s.replace('        published_vision_peak: std.atomic.Value(usize) = .init(0),','        published_vision_peak: std.atomic.Value(usize) = .init(0),\n        published_vision_host_peak: std.atomic.Value(usize) = .init(0),',1)
s=s.replace('        vision_peak: reader_execution_pool.SharedPeak(model_manager_mod.GenerationAdmissionLease) = .{},','        vision_peak: reader_execution_pool.SharedPeak(model_manager_mod.GenerationAdmissionLease) = .{},\n        vision_host_peak: reader_execution_pool.SharedPeak(model_manager_mod.GenerationAdmissionLease) = .{},',1)
s=s.replace('.vision_peak = .{ .max_increments = factory.epoch_page_limit },', '.vision_peak = .{ .max_increments = factory.epoch_page_limit }, .vision_host_peak = .{ .max_increments = factory.epoch_page_limit },',1)
anchor='''            ctx.vision_peak.deinit();
            ctx.model.unlockNativeGeneration();''';assert anchor in s;s=s.replace(anchor,'''            if (platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3")) std.debug.print("LIGHTONOCR3 shared_vision_host_peak_bytes={d} peak_segments={d}\\n", .{ ctx.vision_host_peak.bytes, ctx.vision_host_peak.count });
            ctx.vision_peak.deinit();
            ctx.vision_host_peak.deinit();
            ctx.model.unlockNativeGeneration();''',1)
anchor='''        fn finishPhaseWait(ctx: *LightOnStreamContext) void {''';assert anchor in s;s=s.replace(anchor,'''        fn acquireVisionHostPeak(factory: *Factory, bytes: usize) !model_manager_mod.GenerationAdmissionLease {
            return factory.node.model_manager.acquireGenerationResources(&.{.{ .session = factory.model.session, .resources = .{ .backend_class = .gpu, .limits = factory.limits, .amounts = .{ .host_scratch_bytes = bytes } } }});
        }
'''+anchor,1)
s=s.replace('factory: *Factory, peak: ?usize, amounts: runtime.tier.memory.AdmissionAmounts)', 'factory: *Factory, peak: ?usize, host_peak: usize, amounts: runtime.tier.memory.AdmissionAmounts)',1)
s=s.replace('''            if (needs_auxiliary or needs_peak) {''','''            const needs_host_peak = host_peak > 0 and (ctx.phase_wait_ns == 0 or host_peak > ctx.published_vision_host_peak.load(.acquire));
            if (needs_auxiliary or needs_peak or needs_host_peak) {''',1)
anchor='''                    if (ctx.phase_wait_ns != 0) ctx.published_vision_peak.store(ctx.vision_peak.bytes, .release);
                }
            }
            return factory.node.model_manager.acquireGenerationResources''';assert anchor in s;s=s.replace(anchor,'''                    if (ctx.phase_wait_ns != 0) ctx.published_vision_peak.store(ctx.vision_peak.bytes, .release);
                }
                if (host_peak != 0) {
                    try ctx.vision_host_peak.grow(host_peak, factory, acquireVisionHostPeak);
                    if (ctx.phase_wait_ns != 0) ctx.published_vision_host_peak.store(ctx.vision_host_peak.bytes, .release);
                }
            }
            return factory.node.model_manager.acquireGenerationResources''',1)
s=s.replace('''        // complete larger host/device envelope before enabling grouped frames.
        vision_amounts.host_scratch_bytes = try std.math.mul(usize, vision_amounts.host_scratch_bytes, features.vision_frame_blocks);''','''        // larger device envelope before enabling grouped frames. Each page
        // still owns its complete original host envelope. Only one GPU gate
        // owner can retain the additional grouped-block host working sets.''',1)
anchor='''        const shared_vision_bytes = try memory.visionBatchPeak(features.vision_batch_items);
        const amounts = if (share_vision_peak) memory.amounts else try memory.finish();''';assert anchor in s;s=s.replace(anchor,'''        const shared_vision_bytes = try memory.visionBatchPeak(features.vision_batch_items);
        const shared_vision_host_bytes = try memory.visionFrameHostPeak(features.vision_frame_blocks, features.vision_batch_items);
        const amounts = if (share_vision_peak) memory.amounts else try (try memory.finish()).merge(.{
            .host_scratch_bytes = try memory.visionFrameHostPeak(features.vision_frame_blocks, 1),
        });''',1)
s=s.replace('ctx.admitPage(&factory, if (share_vision_peak) shared_vision_bytes else null, amounts)', 'ctx.admitPage(&factory, if (share_vision_peak) shared_vision_bytes else null, if (share_vision_peak) shared_vision_host_bytes else 0, amounts)',1)
s=s.replace('ctx.admitPage(&factory, null, page)', 'ctx.admitPage(&factory, null, 0, page)')
s=s.replace('''        vision_backend_peak: usize = 0,
''','''        vision_backend_peak: usize = 0,
        vision_host_peak: usize = 0,
''',1)
anchor='''            self.vision_backend_peak = @max(self.vision_backend_peak, vision.backend_scratch_bytes);''';assert anchor in s;s=s.replace(anchor,anchor+'\n            self.vision_host_peak = @max(self.vision_host_peak, vision.host_scratch_bytes);',1)
anchor='''        fn finish(self: @This()) !runtime.tier.memory.AdmissionAmounts {''';assert anchor in s;s=s.replace(anchor,'''        fn visionFrameHostPeak(self: @This(), blocks: usize, max_items: usize) !usize {
            if (blocks == 0 or blocks > 4 or max_items == 0 or max_items > 4) return error.ResourceLimitExceeded;
            // Page leases already cover one complete host working set each,
            // including overlapping CPU image preparation. Grouped blocks
            // can add at most this many complete sets at the single GPU gate.
            return product(&.{ self.vision_host_peak, blocks - 1, max_items });
        }
'''+anchor,1)
anchor='''    try std.testing.expectEqual(@as(usize, 4000), four_image_peak);''';assert anchor in s;s=s.replace(anchor,anchor+'''
    try std.testing.expectEqual(@as(usize, 0), try memory.visionFrameHostPeak(1, 4));
    try std.testing.expectEqual(@as(usize, 300), try memory.visionFrameHostPeak(4, 1));
    try std.testing.expectEqual(@as(usize, 1200), try memory.visionFrameHostPeak(4, 4));
    try std.testing.expectError(error.ResourceLimitExceeded, memory.visionFrameHostPeak(0, 1));
    try std.testing.expectError(error.ResourceLimitExceeded, memory.visionFrameHostPeak(5, 1));
    try std.testing.expectError(error.ResourceLimitExceeded, memory.visionFrameHostPeak(4, 0));
    try std.testing.expectError(error.ResourceLimitExceeded, memory.visionFrameHostPeak(4, 5));''',1)
p.write_text(s)
p=Path('zig/pkg/inference/src/server/reader_execution_pool.zig');s=p.read_text();s+='''

test "LightOnOCR3 shared host and device vision peaks preserve the combined scratch cap" {
    const memory = @import("../runtime/tier/memory.zig");
    const Factory = struct {
        fn host(controller: *memory.AdmissionController, bytes: usize) !memory.AdmissionLease {
            return controller.tryAcquire(.gpu, .{ .combined_limit_bytes = 220, .host_limit_bytes = 100, .backend_limit_bytes = 200, .scratch_limit_bytes = 220 }, .{ .host_scratch_bytes = bytes }, false);
        }
        fn device(controller: *memory.AdmissionController, bytes: usize) !memory.AdmissionLease {
            return controller.tryAcquire(.gpu, .{ .combined_limit_bytes = 220, .host_limit_bytes = 100, .backend_limit_bytes = 200, .scratch_limit_bytes = 220 }, .{ .backend_scratch_bytes = bytes }, false);
        }
    };
    var controller = memory.AdmissionController{};
    defer controller.deinit();
    var host = SharedPeak(memory.AdmissionLease){};
    defer host.deinit();
    var device = SharedPeak(memory.AdmissionLease){};
    defer device.deinit();
    try device.grow(128, &controller, Factory.device);
    try host.grow(64, &controller, Factory.host);
    var page = try Factory.host(&controller, 20);
    defer page.release();
    try std.testing.expectError(error.ResourceTemporarilyUnavailable, host.grow(80, &controller, Factory.host));
    try std.testing.expectEqual(@as(usize, 64), host.bytes);
    try std.testing.expectEqual(@as(usize, 1), host.count);
    page.release();
    try host.grow(80, &controller, Factory.host);
    try std.testing.expectEqual(@as(usize, 128), controller.admitted.backend_scratch_bytes);
    try std.testing.expectEqual(@as(usize, 80), controller.admitted.host_scratch_bytes);
    var edge = try Factory.device(&controller, 12);
    defer edge.release();
    try std.testing.expectError(error.ResourceTemporarilyUnavailable, device.grow(129, &controller, Factory.device));
    try std.testing.expectEqual(@as(usize, 128), device.bytes);
    edge.release();
    try device.grow(129, &controller, Factory.device);
    device.deinit();
    try std.testing.expectEqual(@as(usize, 80), controller.admitted.host_scratch_bytes);
    try std.testing.expectEqual(@as(usize, 0), controller.admitted.backend_scratch_bytes);
    host.deinit();
    try std.testing.expectEqual(@as(usize, 0), controller.admitted.hostTotalBytes() + controller.admitted.backendTotalBytes());
}
''';p.write_text(s)
print('28 full base page-host admission preserved; extra grouped host peak gets a shared GPU-owner lease')
