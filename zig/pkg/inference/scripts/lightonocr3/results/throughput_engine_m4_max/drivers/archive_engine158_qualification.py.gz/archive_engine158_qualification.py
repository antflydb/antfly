from pathlib import Path
import hashlib
import json

root = Path.cwd()
v = root / '.venv-lighton-vllm-metal'
o = root / 'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

freeze = json.loads((v / 'engine158-freeze.json').read_text())
assert all(sha(path) == expected for path, expected in freeze.items())
smoke_audit = o / 'engine158_remaining_short160_audit.json'
assert json.loads(smoke_audit.read_text())['status'] == 'screen_complete'
report_path = o / 'engine158_4b_short160_4b_profile_c16_r16/report.json'
report = json.loads(report_path.read_text())
result = report['results'][0]
sample = result['policy_rounds'][0]
assert result['cross_runtime_full_fixture_string_identity']
assert sample['completed'] == 16 and not sample['admission_pressures']
assert sample['packed_prefill_chunks'] == 142
assert sample['short_prefill_core_dispatches'] == 3408
assert sample['short_direct_attention_dispatches'] == 712
qualification = o / 'engine158_qualification_audit.json'
record = json.loads(qualification.read_text())
record.update(
    status='cpu_metal_C24_and_real_short_model_pass_speed_pending',
    model_smoke_audit_sha256=sha(smoke_audit),
    model_smoke_report_sha256=sha(report_path),
    short_core_dispatches=3408,
    short_direct_attention_dispatches=712,
)
qualification.write_text(json.dumps(record, indent=2) + '\n')
(o / 'engine158_short160_exact_output_audit.json').write_text(json.dumps({
    'status': 'all_16_outputs_exact_actual_short_dispatches_qualified',
    'scope': 'Source158: per-reader counter deltas qualify 3408 short-core and 712 short-direct-attention dispatches. Full actual API fixture strings match, native parity covers every page, 142 chunks/16 starts/16 finishes, up to8 prefixes per step, no admission pressure. Original caps and reserves retained. Cold smoke rate is not primary throughput evidence. Historical Cbuild scope literal source154 names the initial routing change; build input hashes and actual155/158 manifests distinguish test/counter revisions.',
    'report_sha256': sha(report_path),
    'build_manifest_sha256': sha(o / 'engine158_build_manifest.json'),
    'binary_sha256': sha(v / 'qualified-binaries/engine158-test'),
    'frozen_source_verified': True,
    'primary_throughput_eligible': False,
}, indent=2) + '\n')
namespace = {}
source = (v / 'archive_engine10_evidence.py').read_text()
exec(source[:source.index("archive('qualification'")], namespace)
logs = [*Path('/private/tmp').glob('ocr-engine158-c-*.txt')]
logs += [Path('/private/tmp') / name for name in [
    'ocr-engine158-c-parent.txt', 'ocr-engine158-packed-cpu.txt',
    'ocr-engine158-cpu-parent.txt', 'ocr-engine158-verify3-gpu-build.txt',
    'ocr-engine158-gpu-qualification-parent.txt', 'ocr-engine158-short160-parent.txt',
    'ocr-engine158-short160-4b_profile-driver.txt',
    'ocr-engine158-4b-short160_4b_profile_c16_r16.txt',
]]
logs = list(dict.fromkeys(logs))
drivers = [v / name for name in [
    'prepare_engine158_short_counters.py', 'engine158-freeze.json',
    'run_engine158_c_qualification.py', 'run_engine158_cpu_build.py',
    'run_engine158_gpu_build.py', 'save_engine158_manifest.py',
    'run_engine158_budget_policies.py', 'engine158_benchmark_concurrency.py',
    'run_engine158_short160_smoke.py',
]] + [Path(__file__)]
namespace['archive']('qualification', logs, 'logs_manifest.json')
namespace['archive']('drivers', drivers, 'drivers_manifest.json')
print('158 qualification and160 smoke archived;161 active/waiting files untouched')
