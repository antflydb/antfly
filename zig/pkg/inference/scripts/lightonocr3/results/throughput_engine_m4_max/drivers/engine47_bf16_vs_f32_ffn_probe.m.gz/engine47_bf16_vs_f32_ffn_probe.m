#define main production_checks_main
#include "engine47_bf16_vs_f32_ffn_probe_checks.m"
#undef main
#define STREAM_LAYERS 32
static id<MTLComputePipelineState> f32_pipelines[6];
static const size_t ms[6]={32,32,32,64,64,64},ns[6]={16,32,32,16,32,64},sgs[6]={2,2,4,4,4,8};
static int stream_frame(termite_metal_decode_runtime*r,id<MTLComputePipelineState>p,size_t variant,
 size_t rows,size_t in,size_t out,id<MTLBuffer>source,id<MTLBuffer>zero,id<MTLBuffer>x,
 id<MTLBuffer> __strong y[STREAM_LAYERS],double*us){
 bool bf16_input=p!=nil;
 if(!p)p=f32_pipelines[variant];
 id<MTLBuffer> packed=bf16_input?[r->device newBufferWithLength:rows*in*2 options:MTLResourceStorageModePrivate]:nil;
 if(bf16_input&&!packed)return 30;
 uint64_t before=r->frame_gpu_nanos;size_t dispatches=0,pack_dispatches=0;
 if(termite_metal_decode_runtime_begin_frame(r)||
    termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_DECODE)||
    termite_metal_decode_runtime_apply_add_device(r,(__bridge void*)source,16,(__bridge void*)zero,0,rows*in,(__bridge void*)x,16)||
    termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_FFN,TERMITE_METAL_COMPUTE_REGION_FFN))return 1;
 for(size_t layer=0;layer<STREAM_LAYERS;layer++){
  size_t gate=2*layer,up=gate+1;
  if(false){
   if(termite_metal_decode_runtime_apply_bf16_gate_up_device(r,gate,up,(__bridge void*)x,16,rows,in,out,(__bridge void*)y[layer],16))return 2;
  }else{
   id<MTLComputeCommandEncoder>e=r->active_planned_compute_encoder;if(!e)return 3;
   termite_metal_planned_encoder_range a[7];
   if(termite_metal_planned_range_make(x,16,rows*in*4,TERMITE_METAL_PLANNED_RANGE_READ,&a[0],-1)||
      termite_metal_planned_range_make(r->linear_weight_buffers[gate],0,in*out*2,TERMITE_METAL_PLANNED_RANGE_READ,&a[1],-1)||
      termite_metal_planned_range_make(r->linear_weight_buffers[up],0,in*out*2,TERMITE_METAL_PLANNED_RANGE_READ,&a[2],-1)||
      termite_metal_planned_range_make(r->linear_bias_buffers[gate],0,out*4,TERMITE_METAL_PLANNED_RANGE_READ,&a[3],-1)||
      termite_metal_planned_range_make(r->linear_bias_buffers[up],0,out*4,TERMITE_METAL_PLANNED_RANGE_READ,&a[4],-1)||
      termite_metal_planned_range_make(y[layer],16,rows*out*4,TERMITE_METAL_PLANNED_RANGE_WRITE,&a[5],-1)||
      (bf16_input&&termite_metal_planned_range_make(packed,0,rows*in*2,TERMITE_METAL_PLANNED_RANGE_WRITE,&a[6],-1))||
      termite_metal_decode_runtime_prepare_planned_compute_accesses(r,a,bf16_input?7:6,-1))return 4;
   termite_metal_linear_params params={(uint32_t)rows,(uint32_t)in,(uint32_t)out,0};
   if(bf16_input){
   uint32_t count=(uint32_t)(rows*in);
   [e setComputePipelineState:r->lightonocr3_pack_bf16_pipeline];
   [e setBuffer:x offset:16 atIndex:0];[e setBuffer:packed offset:0 atIndex:1];
   [e setBytes:&count length:sizeof(count) atIndex:2];
   [e dispatchThreads:MTLSizeMake(count,1,1) threadsPerThreadgroup:MTLSizeMake(termite_metal_thread_width(r->lightonocr3_pack_bf16_pipeline,count),1,1)];
   [e memoryBarrierWithScope:MTLBarrierScopeBuffers];pack_dispatches++;
   }
   [e setComputePipelineState:p];[e setBuffer:bf16_input?packed:x offset:bf16_input?0:16 atIndex:0];
   [e setBuffer:r->linear_weight_buffers[gate] offset:0 atIndex:1];[e setBuffer:r->linear_weight_buffers[up] offset:0 atIndex:2];
   [e setBuffer:r->linear_bias_buffers[gate] offset:0 atIndex:3];[e setBuffer:r->linear_bias_buffers[up] offset:0 atIndex:4];
   [e setBuffer:y[layer] offset:16 atIndex:5];[e setBytes:&params length:sizeof(params) atIndex:6];
   [e dispatchThreadgroups:MTLSizeMake((out+ns[variant]-1)/ns[variant],(rows+ms[variant]-1)/ms[variant],1) threadsPerThreadgroup:MTLSizeMake(sgs[variant]*32,1,1)];
  }
  dispatches++;
 }
 if(dispatches!=STREAM_LAYERS||pack_dispatches!=(bf16_input?STREAM_LAYERS:0))return 5;
 if(termite_metal_decode_runtime_end_planned_compute_scope(r)||
    termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r))return 6;
 *us=(r->frame_gpu_nanos-before)/1000.0;return 0;
}
static int stream_case(termite_metal_decode_runtime*r,id<MTLComputePipelineState> __strong pipelines[6],size_t rows){
 @autoreleasepool{
 const size_t in=2560,out=9216,n=rows*out;
 id<MTLBuffer>source=[r->device newBufferWithLength:(rows*in+8)*4 options:MTLResourceStorageModeShared],
 zero=[r->device newBufferWithLength:rows*in*4 options:MTLResourceStorageModeShared],
 x=[r->device newBufferWithLength:(rows*in+8)*4 options:MTLResourceStorageModePrivate],y[STREAM_LAYERS];
 float*gold[STREAM_LAYERS]={0};double cpu[STREAM_LAYERS][2][4];
 uint16_t*w=malloc(in*out*2);float*b=malloc(out*4);if(!source||!zero||!x||!w||!b)return 10;
 memset(zero.contents,0,zero.length);float*input=(float*)source.contents+4;
 for(size_t i=0;i<rows*in;i++)input[i]=expand_bf16(round_bf16(sinf(i*.013f)*.7f));
 uint32_t rng=123;
 for(size_t layer=0;layer<STREAM_LAYERS;layer++){
  y[layer]=[r->device newBufferWithLength:(n+12)*4 options:MTLResourceStorageModeShared];gold[layer]=malloc(n*4);
  if(!y[layer]||!gold[layer])return 11;
  for(size_t pair=0;pair<2;pair++){
   for(size_t i=0;i<in*out;i++){rng=rng*1664525u+1013904223u;w[i]=round_bf16(((int)(rng>>16)-32768)*.000001f);}
   for(size_t i=0;i<out;i++)b[i]=cosf(i*.019f+2*layer+pair)*.2f;
   for(size_t c=0;c<4;c++){
    size_t row=c/2?rows-1:0,col=c%2?out-1:0;double sum=b[col];
    for(size_t k=0;k<in;k++)sum+=(double)input[row*in+k]*expand_bf16(w[col*in+k]);
    cpu[layer][pair][c]=sum;
   }
   if(termite_metal_decode_runtime_prepare_linear_bf16(r,2*layer+pair,(uint8_t*)w,in*out*2,b,in,out))return 12;
  }
 }
 free(w);free(b);double us;
 for(size_t warm=0;warm<2;warm++)if(stream_frame(r,nil,0,rows,in,out,source,zero,x,y,&us))return 13;
 for(size_t layer=0;layer<STREAM_LAYERS;layer++)memcpy(gold[layer],(float*)y[layer].contents+4,n*4);
 const size_t variants[]={0,3,4,5};
 for(size_t pick=0;pick<4;pick++)for(size_t leg=0;leg<4;leg++){
  size_t variant=variants[pick];bool on=leg==1||leg==2;id<MTLComputePipelineState>p=on?pipelines[variant]:nil;
  for(size_t layer=0;layer<STREAM_LAYERS;layer++){
   uint32_t*raw=y[layer].contents;for(size_t i=0;i<4;i++)raw[i]=0xdeadbeef;for(size_t i=n+4;i<n+12;i++)raw[i]=0xcafebabe;
  }
  for(size_t warm=0;warm<2;warm++)if(stream_frame(r,p,variant,rows,in,out,source,zero,x,y,&us))return 14;
  double total=0;for(size_t trial=0;trial<8;trial++){
   if(stream_frame(r,p,variant,rows,in,out,source,zero,x,y,&us))return 15;total+=us;
  }
  float worst=0;double corner_error=0;
  for(size_t layer=0;layer<STREAM_LAYERS;layer++){
   float*got=(float*)y[layer].contents+4;uint32_t*raw=y[layer].contents;
   for(size_t i=0;i<n;i++){if(!isfinite(got[i]))return 16;worst=fmaxf(worst,fabsf(got[i]-gold[layer][i]));}
   for(size_t c=0;c<4;c++){
    size_t row=c/2?rows-1:0,col=c%2?out-1:0;double g=cpu[layer][0][c],u=cpu[layer][1][c];
    corner_error=fmax(corner_error,fabs(g/(1+exp(-g))*u-got[row*out+col]));
   }
   for(size_t i=0;i<4;i++)if(raw[i]!=0xdeadbeef)return 17;for(size_t i=n+4;i<n+12;i++)if(raw[i]!=0xcafebabe)return 18;
  }
  if(worst>2e-4||corner_error>2e-4)return 19;
  fprintf(stderr,"BF16_VS_F32_FFN rows=%zu in=%zu out=%zu layers=%d variant=%zu on=%d leg=%zu frame_gpu_us=%.3f projection_gpu_us=%.3f max_abs=%g cpu_error=%g\n",
   rows,in,out,STREAM_LAYERS,variant,on,leg,total/8,total/8/STREAM_LAYERS,worst,corner_error);
 }
 for(size_t layer=0;layer<STREAM_LAYERS;layer++)free(gold[layer]);
 return 0;
 }
}
int main(void){@autoreleasepool{
 unsetenv("TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS");
 unsetenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP");
 setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP","1",1);
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 NSError*err=nil;NSString*source=[NSString stringWithContentsOfFile:@".venv-lighton-vllm-metal/engine47_bf16_vs_f32_ffn_probe.metal" encoding:NSUTF8StringEncoding error:&err];
 MTLCompileOptions*opts=[MTLCompileOptions new];opts.fastMathEnabled=NO;opts.mathMode=MTLMathModeSafe;opts.languageVersion=MTLLanguageVersion4_0;
 id<MTLLibrary>lib=[r->device newLibraryWithSource:source options:opts error:&err];if(!lib){fprintf(stderr,"MSL_ERROR %s\n",err.description.UTF8String);return 2;}
 NSString*fsource=[NSString stringWithContentsOfFile:@".venv-lighton-vllm-metal/engine47_bf16_vs_f32_ffn_probe_f32.metal" encoding:NSUTF8StringEncoding error:&err];
 id<MTLLibrary>flib=[r->device newLibraryWithSource:fsource options:opts error:&err];if(!flib)return 31;
 id<MTLComputePipelineState>p[6];for(size_t i=0;i<6;i++){
  f32_pipelines[i]=termite_metal_make_pipeline(r->device,flib,[NSString stringWithFormat:@"gate_mpp_%zu",i]);
  if(!f32_pipelines[i]||f32_pipelines[i].threadExecutionWidth!=32||f32_pipelines[i].maxTotalThreadsPerThreadgroup<sgs[i]*32)return 32;
  p[i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"gate_mpp_%zu",i]);
  if(!p[i]||p[i].threadExecutionWidth!=32||p[i].maxTotalThreadsPerThreadgroup<sgs[i]*32||p[i].staticThreadgroupMemoryLength>r->device.maxThreadgroupMemoryLength)return 3;
 }
 const size_t rows[]={64,48,33};
 for(size_t i=0;i<3;i++){int rc=stream_case(r,p,rows[i]);if(rc){fprintf(stderr,"BF16_VS_F32_FFN_FAIL rows=%zu rc=%d\n",rows[i],rc);return 20+rc;}}
 termite_metal_decode_runtime_destroy(r);
}return 0;}
