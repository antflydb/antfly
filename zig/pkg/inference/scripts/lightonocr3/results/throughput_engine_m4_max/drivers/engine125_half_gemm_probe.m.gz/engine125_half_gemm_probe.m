#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <math.h>
#include <string.h>
struct Params{uint32_t rows,in_dim,out_dim,pad;};
static uint16_t bf(float x){uint32_t u;memcpy(&u,&x,4);return(uint16_t)((u+0x7fff+((u>>16)&1))>>16);}
static float expand(uint16_t x){uint32_t u=(uint32_t)x<<16;float f;memcpy(&f,&u,4);return f;}
int main(){@autoreleasepool{
 id<MTLDevice>d=MTLCreateSystemDefaultDevice();if(!d)return 1;NSError*err=nil;
 NSString*src=[NSString stringWithContentsOfFile:@".venv-lighton-vllm-metal/engine125_half_gemm.metal" encoding:NSUTF8StringEncoding error:&err];MTLCompileOptions*opt=[MTLCompileOptions new];opt.languageVersion=MTLLanguageVersion4_0;opt.fastMathEnabled=NO;
 id<MTLLibrary>lib=[d newLibraryWithSource:src options:opt error:&err];if(!lib){fprintf(stderr,"%s\n",err.description.UTF8String);return 2;}
 id<MTLComputePipelineState>p[2];for(int m=0;m<2;m++){NSString*n=m?@"termite_lightonocr3_mpp_half_32_64":@"termite_lightonocr3_mpp_bfloat_32_64";p[m]=[d newComputePipelineStateWithFunction:[lib newFunctionWithName:n] error:&err];if(!p[m])return 3;}
 id<MTLCommandQueue>q=[d newCommandQueue];const uint32_t shapes[][3]={{432,2560,9216},{432,9216,2560},{2160,1024,4096},{2160,4096,1024},{2160,1024,1024}};
 for(size_t c=0;c<5;c++){@autoreleasepool{struct Params par={shapes[c][0],shapes[c][1],shapes[c][2],0};size_t nx=(size_t)par.rows*par.in_dim,nw=(size_t)par.out_dim*par.in_dim,ny=(size_t)par.rows*par.out_dim;
 id<MTLBuffer>x[2],w[2],y[2];for(int m=0;m<2;m++){x[m]=[d newBufferWithLength:nx*2 options:MTLResourceStorageModeShared];w[m]=[d newBufferWithLength:nw*2 options:MTLResourceStorageModeShared];y[m]=[d newBufferWithLength:ny*4+32 options:MTLResourceStorageModeShared];if(!x[m]||!w[m]||!y[m])return 4;memset(y[m].contents,0xcd,ny*4+32);}
 id<MTLBuffer>b=[d newBufferWithLength:par.out_dim*4 options:MTLResourceStorageModeShared];memset(b.contents,0,b.length);
 for(size_t i=0;i<nx;i++){uint16_t v=bf(sinf(i*.013f)*.7f);((uint16_t*)x[0].contents)[i]=v;((_Float16*)x[1].contents)[i]=(_Float16)expand(v);}for(size_t i=0;i<nw;i++){uint16_t v=bf(cosf(i*.017f)*.03f);((uint16_t*)w[0].contents)[i]=v;((_Float16*)w[1].contents)[i]=(_Float16)expand(v);}
 for(int trial=0;trial<16;trial++)for(int order=0;order<2;order++){int m=order^(trial&1);id<MTLCommandBuffer>cb=[q commandBuffer];id<MTLComputeCommandEncoder>e=[cb computeCommandEncoder];[e setComputePipelineState:p[m]];[e setBuffer:x[m] offset:0 atIndex:0];[e setBuffer:w[m] offset:0 atIndex:1];[e setBuffer:b offset:0 atIndex:2];[e setBuffer:y[m] offset:16 atIndex:3];[e setBytes:&par length:sizeof(par) atIndex:4];[e dispatchThreadgroups:MTLSizeMake((par.out_dim+63)/64,(par.rows+31)/32,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];[e endEncoding];[cb commit];[cb waitUntilCompleted];if(cb.status!=MTLCommandBufferStatusCompleted)return 5;
 for(size_t i=0;i<16;i++)if(((uint8_t*)y[m].contents)[i]!=0xcd||((uint8_t*)y[m].contents)[16+ny*4+i]!=0xcd)return 6;
 if(trial>=4)printf("{\"case\":%zu,\"rows\":%u,\"in\":%u,\"out\":%u,\"half\":%d,\"trial\":%d,\"gpu_us\":%.6f}\n",c,par.rows,par.in_dim,par.out_dim,m,trial,(cb.GPUEndTime-cb.GPUStartTime)*1e6);
 }
 float maxerr=0;size_t diffs=0;float*a=(float*)((char*)y[0].contents+16),*z=(float*)((char*)y[1].contents+16);for(size_t i=0;i<ny;i++){if(!isfinite(a[i])||!isfinite(z[i]))return 7;maxerr=fmaxf(maxerr,fabsf(a[i]-z[i]));uint32_t u,v;memcpy(&u,a+i,4);memcpy(&v,z+i,4);diffs+=u!=v;}fprintf(stderr,"HALF125 case=%zu full_output_diffs=%zu max_abs=%.9g guards=pass\n",c,diffs,maxerr);fflush(stdout);
 }}return 0;
}}
