from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

root = Path.cwd()
v = root / '.venv-lighton-vllm-metal'
scripts = root / 'zig/pkg/inference/scripts/lightonocr3'
out = scripts / 'results/throughput_engine_m4_max'
images = [root / 'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png', scripts / 'corpus/receipt.png', scripts / 'corpus/shipping.png']
models = sys.argv[1:] or ['4b']
assert models==['4b']
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

record = dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              scope='Fresh vLLM C64 automatic-cache controls in both orders against the fastest qualified native profile (4B engine57 fixed profile selected by its qualifying R64 throughput; fresh R128 comparison is an independent validation). C64 was the winning concurrency in prior C16/C32/C48/C64 searches (paired16/18). Shared machine uncontrolled; no own compilation or sampling during timings.',
              comparisons=[], selected_profiles={}, status='running')
audit = out / ('paired29_' + '_'.join(models) + '_comparison_audit.json')
assert not audit.exists()

def save():
    audit.write_text(json.dumps(record, indent=2) + '\n')

def reference(model, round_index):
    label = f'_primary_reference29_r{round_index}_auto_c64_r128'
    dest = out / ('vllm_' + model + label)
    assert not (dest / 'report.json').exists()
    cmd = [sys.executable, str(scripts / 'benchmark_vllm_metal.py'), '--python', sys.executable,
           '--model-dir', str(v / 'ocr-models' / ('lighton' + model)), '--images', *map(str, images),
           '--concurrency', '64', '--requests', '128', '--max-tokens', '256', '--startup-timeout', '600',
           '--output-dir', str(dest)]
    print('START VLLM', model, round_index, flush=True)
    with Path(f'/private/tmp/ocr-engine57-vllm-{model}-paired29-r{round_index}.txt').open('w') as log:
        subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=True)
    p = dest / 'report.json'
    d = json.loads(p.read_text())
    assert d['status'] == 'ok' and d['kv_cache_block_override'] is None and d['results'][0]['serial_reference_parity']
    print('DONE VLLM', model, round_index, d['results'][0]['pages_per_second'], flush=True)
    return label, d, p

def native(model, round_index, oracle):
    profile = record['selected_profiles'][model]
    cfg=profile['settings']
    c,vf,prefill,vision=cfg['concurrency'],cfg['vision_frame_blocks'],cfg['prefill_items'],cfg['vision_items']
    prefix=0;wide64=True;full64=True
    label=f'paired29_r{round_index}_c{c}_v{vision}_p{prefill}_vf{vf}_workspace_r128'
    env=os.environ.copy()
    env.update(OCR_REFERENCE_LABEL=oracle,OCR_DISABLE_WIDE_GATE_UP='0',OCR_WIDE64_GATE_UP='1',OCR_FULL64_GATE_UP='1',OCR_GPU_GREEDY_STREAM='0',OCR_STREAM_CHUNK_LAYERS='0',OCR_PHYSICAL32='0',OCR_PHYSICAL64='1',
       OCR_CONCURRENCY=str(c),OCR_REQUESTS='128',OCR_WIDE='1',OCR_KV_GIB='4',OCR_BACKEND_GIB='17',OCR_SCRATCH_GIB='10',OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1',OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_DISABLE_64_ROW_TILE='0',
       OCR_VISION_BATCH=str(int(vision>1)),OCR_VISION_BATCH_ITEMS=str(vision),OCR_VISION_WAIT_US='2000',OCR_PREFILL_BATCH=str(int(prefill>1)),OCR_PREFILL_BATCH_ITEMS=str(prefill),OCR_PREFILL_WAIT_US='100000',OCR_VISION_FRAME_BLOCKS=str(vf),OCR_SINGLE_FRAME='1',OCR_STREAM_FIRST='0',OCR_LOGICAL64='1',OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',OCR_ADMISSION_UNITS='512',
       OCR_BATCH_ARGMAX=str(int(cfg['batch_argmax'])),OCR_DEFER_VISION_SEAL=str(int(cfg['defer_vision_seal'])),OCR_DEFER_PREFILL_SEAL=str(int(cfg['defer_prefill_seal'])),OCR_CACHE_VISION_WORKSPACE='1',OCR_LARGE_VISION_PACK_REUSE='1',OCR_TIMEOUT='900')
    dest = out / f'engine57_{model}_{label}'
    assert not (dest / 'report.json').exists()
    print('START NATIVE', model, round_index, profile['settings'], flush=True)
    subprocess.run([sys.executable, str(v / 'run_engine57_budget_policies.py'), model + ':' + label], env=env, check=True)
    p = dest / 'report.json'
    d = json.loads(p.read_text())
    assert not d['own_cpu_compile_overlap']
    return d, p

def compare(model, round_index, n, ref, order):
    nd, np = n
    label, rd, rp = ref
    r = nd['results'][0]
    sample = r['policy_rounds'][0]
    assert r['status'] == 'ok' and r['serial_reference_parity'] and r['cross_runtime_content_parity']
    assert sample['completed'] == 128 and not sample['admission_pressures']
    assert sample['gpu_greedy_stream_topology_mismatches']==0 and sample['single_frame_topology_mismatches']==0
    assert sample['host_recurrent_bytes_total']==0
    cfg=record['selected_profiles'][model]['settings']
    assert sample['wide_gate_up_calls']>0 and sample['full64_gate_up_calls']==0
    if cfg['prefill_items']>1:assert any(b['items']==cfg['prefill_items']for b in sample['prefill_batches'])
    assert sample['gpu_greedy_stream_steps']==sample['gpu_greedy_stream_two_frame_steps']==sample['stream_forward_splits']==0
    assert sample['vision_workspace_reuses']>0 and sample['vision_workspace_bytes']>0 and sample['batch_argmax_calls']>0
    assert {x['image_index']: x['text'] for x in r['references']} == {x['image_index']: x['text'] for x in rd['references']}
    a, b = sample['pages_per_second'], rd['results'][0]['pages_per_second']
    item = dict(model=model, round=round_index, order=order, native_report=str(np.relative_to(out)),
                native_report_sha256=sha(np), reference_report=str(rp.relative_to(out)), reference_report_sha256=sha(rp),
                native_pages_per_second=a, reference_pages_per_second=b, native_to_vllm_ratio=a / b,
                full_fixture_string_identity=True, all_128_native_pages_equal_serial_reference=True,
                primary_throughput_eligible=True)
    record['comparisons'].append(item)
    save()
    print('COMPARISON', json.dumps(item), flush=True)

for model in models:
    source_audit=out/'engine56_workspace_profiles_verified_audit.json'
    d=json.loads(source_audit.read_text());assert d['status']=='pass'
    best=max((x for x in d['candidates']if x['eligible']),key=lambda x:x['pages_per_second'])
    p=out/best['report'];assert sha(p)==best['report_sha256']
    cfg=best.get('settings')
    if cfg is None:
        cfg=dict(concurrency=48,vision_items=1 if best['profile']=='prefill3_workspace'else 4,prefill_items=3 if best['profile']=='prefill3_workspace'else 1,vision_frame_blocks=2 if best['profile']=='prefill3_workspace'else 1,batch_argmax=True,defer_vision_seal=best['profile']!='prefill3_workspace',defer_prefill_seal=False,cache_vision_workspace=True,large_vision_pack_reuse=True)
    record['selected_profiles'][model]=dict(settings=cfg,selection='Highest valid R64 qualification profile, fixed before the fresh R128 runs in both orders; over-budget profiles excluded.',source_audit_sha256=sha(source_audit),report=best['report'],report_sha256=sha(p),qualification_pages_per_second=best['pages_per_second'])

save()
for model in models:
    ref0 = reference(model, 0)
    compare(model, 0, native(model, 0, ref0[0]), ref0, 'fresh vLLM C64 then native')
    n1 = native(model, 1, ref0[0])
    ref1 = reference(model, 1)
    compare(model, 1, n1, ref1, 'native then fresh vLLM C64')
ratios = [x['native_to_vllm_ratio'] for x in record['comparisons']]
record['status'] = 'native_behind' if any(x <= 1 for x in ratios) else 'clear_repeated_win' if all(x >= 1.05 for x in ratios) else 'small_repeated_lead'
save()
print('FINAL', record['status'], flush=True)
