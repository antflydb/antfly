from pathlib import Path
r=Path.cwd();v=r/'.venv-lighton-vllm-metal'
s=(v/'run_engine81_resident_primary70_verify2.py').read_text().replace('engine81','engine85').replace('ENGINE81','ENGINE85').replace('primary70','primary71').replace('paired70','paired71').replace('reference70','reference71').replace('finalqualification-verify2','qualification').replace('ENGINE85 FINAL QUALIFICATION DONE','ENGINE85 QUALIFICATION DONE')
s=s.replace("OCR_POLICIES='engineepoch,engineepoch,engineepoch,engineepoch'","OCR_POLICIES='engineepoch,engineepoch'")
s=s.replace("env['OCR_PREFILL_FUSED_FFN']='1'","env['OCR_PREFILL_FUSED_FFN']='0'")
s=s.replace("env['OCR_PREFILL_FFN_ROUNDS']='off,on,on,off'","env['OCR_PREFILL_FFN_ROUNDS']='off,off'\n    env['OCR_REQUIRE_PREFILL_FFN']='0'")
s=s.replace("len(samples)==4 and [s['prefill_fused_ffn_enabled']for s in samples]==[False,True,True,False]","len(samples)==2 and [s['prefill_fused_ffn_enabled']for s in samples]==[False,False]")
a=s.index("record['native_control']=dict(");b=s.index('\nr1=reference_sweep',a)
s=s[:a]+"record['native_control']=dict(report=str(np.relative_to(out)),report_sha256=sha(np),rounds=[{k:s.get(k)for k in ['round','prefill_fused_ffn_enabled','prefill_fused_ffn_calls','completed','pages_per_second','process_cpu_ms']}for s in samples]);save()"+s[b:]
s=s.replace('[(samples[1],r0),(samples[2],r1)]','[(samples[0],r0),(samples[1],r1)]')
s=s.replace("scope='Strong independent", "scope='Preregistered original FFN OFF policy, exact integer SIMD preprocessing and two-byte FFN scratch, no policy selection from timings. Strong independent")
s=s.replace('with R128 OFF/ON/ON/OFF FFN policy rounds. Native ON serial warm references compile the optional PSOs before timing and must equal all full cross-runtime fixture strings. All timed OFF and ON outputs must equal these same serial references. Compare first ON round to strongest opening API control and second ON to strongest closing API control.', 'with two R128 FFN-OFF policy rounds. All timed outputs must equal full cross-runtime serial references. Compare first native round to strongest opening API control and second native round to strongest closing API control.').replace('four-round native block','two-round native block')
p=v/'run_engine85_primary71.py';assert not p.exists();p.write_text(s)
for old,new in [('run_engine80_08_paired67.py','run_engine85_08_paired72.py'),('run_engine80_florence_paired67.py','run_engine85_florence_paired72.py')]:
 p=v/new;assert not p.exists();p.write_text((v/old).read_text().replace('engine80','engine85').replace('paired67','paired72').replace('reference67','reference72'))
