from pathlib import Path
import os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');base=os.environ.copy();base.update(OCR_REFERENCE_LABEL='_primary_reference9_loadcheck_auto_c32_r128',OCR_PHYSICAL32='1',OCR_REQUESTS='128',OCR_WIDE='1',OCR_SCRATCH_GIB='8',OCR_STREAM_FIRST='0',OCR_SINGLE_FRAME='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1',OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_VISION_BATCH='0')
# Isolate event groups first, then prefill priority, then bounded vision groups.
for label,c,vf,wait,streak in [('events100ms_streak4_vision1',32,1,100000,4),('events100ms_streak0_vision1',32,1,100000,0),('events100ms_streak0_vision4',24,4,100000,0),('events100ms_streak0_vision2',28,2,100000,0)]:
 env=base.copy();env.update(OCR_CONCURRENCY=str(c),OCR_VISION_FRAME_BLOCKS=str(vf),OCR_PREFILL_WAIT_US=str(wait),OCR_PREFILL_DECODE_STREAK=str(streak))
 print('START',label,c,flush=True)
 r=subprocess.run([sys.executable,str(v/'run_engine28_policies.py'),'4b:'+label+f'_f32_c{c}_r128_0'],env=env)
 print('DONE',label,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
