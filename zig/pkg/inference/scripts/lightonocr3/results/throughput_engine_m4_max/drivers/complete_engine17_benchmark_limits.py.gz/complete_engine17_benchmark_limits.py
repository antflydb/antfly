from pathlib import Path
import hashlib,json,shutil
v=Path('.venv-lighton-vllm-metal');shutil.copyfile(v/'engine17-freeze.json',v/'engine17-initial-cancelled-freeze.json')
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text().replace('if (concurrency == 0 or concurrency > 16) return error.InvalidBenchmarkConcurrency;', 'if (concurrency == 0 or concurrency > 32) return error.InvalidBenchmarkConcurrency;',1).replace('var tasks: [16]ConcurrentOcrBenchTask = undefined;','var tasks: [32]ConcurrentOcrBenchTask = undefined;',1).replace('var threads: [16]std.Thread = undefined;','var threads: [32]std.Thread = undefined;',1);p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text().replace('any(c < 1 or c > 16 for c in args.concurrency)', 'any(c < 1 or c > 32 for c in args.concurrency)',1).replace('concurrency must be 1..16','concurrency must be 1..32',1).replace('if not 1 <= args.batch_window <= 16:', 'if not 1 <= args.batch_window <= 32:',1).replace('batch window must be 1..16','batch window must be 1..32',1);p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_vllm_metal.py');s=p.read_text().replace('c > 16', 'c > 32',1).replace('concurrency must be 1..16', 'concurrency must be 1..32',1);p.write_text(s)
(v/'engine17_benchmark_concurrency.py').write_bytes(Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
files=json.loads((v/'engine17-freeze.json').read_text());files['zig/pkg/inference/scripts/lightonocr3/benchmark_vllm_metal.py']='';(v/'engine17-freeze.json').write_text(json.dumps({f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in files},indent=2)+'\n')
for name in ['ocr-engine17-gpu-build.txt','ocr-engine17-gpu-build-driver.txt']:
 p=Path('/private/tmp')/name
 if p.exists():p.rename(p.with_name(name.replace('-gpu-build','-initial-cancelled-gpu-build')))
