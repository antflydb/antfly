from pathlib import Path
import os,subprocess,sys,json,hashlib
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');records=[]
for name,vision,prefill,vf in [('vision_stage',4,1,1),('prefill_stage',1,3,2),('combined_stage',4,3,1)]:
 label='stage55_'+name;env=os.environ.copy();env.update(OCR_CASE_CONCURRENCY='48',OCR_CASE_PREFILL_ITEMS=str(prefill),OCR_CASE_VISION_FRAME_BLOCKS=str(vf),OCR_CASE_VISION_BATCH_ITEMS=str(vision),OCR_CASE_TAG=label,OCR_VISION_WAIT_US='2000',OCR_BATCH_ARGMAX='1',OCR_DEFER_VISION_SEAL='1'if vision>1 else'0',OCR_DEFER_PREFILL_SEAL='1'if prefill>1 else'0',OCR_TIMEOUT='240')
 print('START',label,flush=True)
 with Path('/private/tmp/ocr-engine55-4b-'+label+'-driver.txt').open('w')as log:r=subprocess.run([sys.executable,str(v/'run_engine55_vision4_profile_verify2.py'),'4b','0'],env=env,stdout=log,stderr=subprocess.STDOUT)
 print('DONE',label,r.returncode,flush=True);assert r.returncode==0,(label,r.returncode)
 p=o/f'engine55_4b_rolling_chunks0_trial0_c48_p{prefill}_vf{vf}_r64_{label}'/'report.json';d=json.loads(p.read_text());s=d['results'][0]['policy_rounds'][0]
 assert s['completed']==64 and not s['admission_pressures']
 records.append(dict(profile=name,pages_per_second=s['pages_per_second'],completed=64,vision_batch_sizes=s['vision_batch_sizes'],prefill_batches=s['prefill_batches'],report=str(p.relative_to(o)),report_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 (o/'engine55_stage_profiles_audit.json').write_text(json.dumps(dict(status='running',candidates=records),indent=2)+'\n')
(o/'engine55_stage_profiles_audit.json').write_text(json.dumps(dict(status='pass',candidates=records),indent=2)+'\n')
