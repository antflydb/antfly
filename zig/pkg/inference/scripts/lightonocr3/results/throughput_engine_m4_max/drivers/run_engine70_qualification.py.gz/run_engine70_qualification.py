from pathlib import Path
import subprocess,sys,json,hashlib,datetime,re
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';o=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name,cmd in [('c-qualification',[sys.executable,str(v/'run_engine70_c_qualification.py')]),('gpu-build',[sys.executable,str(v/'run_engine70_verify2_gpu_build.py')]),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine70','/private/tmp/ocr-engine70-verify2-gpu-build.txt']),('metal-disabled',[sys.executable,str(v/'run_engine70_metal_disabled.py')])]:
 print('START',name,flush=True)
 with Path('/private/tmp/ocr-engine70-'+name+'-driver.txt').open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 if name=='c-qualification':
  prev=json.loads((o/'engine68_c_build_manifest.json').read_text());inputs={p:sha(root/p)for p in prev['input_sha256']}
  d=json.loads((o/'engine70_c_qualification_audit.json').read_text());d.update(input_sha256=inputs,scope='Fresh nineteen checks, including same-frame stability, next-frame refresh and disabled-policy live settings through actual gate/up dispatch selection. No shader changes.',verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat());(o/'engine70_c_qualification_audit.json').write_text(json.dumps(d,indent=2)+'\n')
  (o/'engine70_c_build_manifest.json').write_text(json.dumps(dict(binary=str((v/'engine70_conformance').relative_to(root)),binary_sha256=sha(v/'engine70_conformance'),input_sha256=inputs,compiler_driver_sha256=sha(v/'build_engine70_conformance.py'),qualification_driver_sha256=sha(v/'run_engine70_c_qualification.py')),indent=2)+'\n')
print('ENGINE70 QUALIFICATION DONE',flush=True)
