from pathlib import Path
import json,hashlib,subprocess,os
v=Path('.venv-lighton-vllm-metal')
frozen=json.loads((v/'engine53-freeze.json').read_text())
for name,h in frozen.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h,name
cmd=['clang','-O3','-fobjc-arc','zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m','-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(v/'engine53_conformance')]
with Path('/private/tmp/ocr-engine53-c-build.txt').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/"clang-cache")))
assert r.returncode==0,r.returncode
print('compiled',v/'engine53_conformance')
