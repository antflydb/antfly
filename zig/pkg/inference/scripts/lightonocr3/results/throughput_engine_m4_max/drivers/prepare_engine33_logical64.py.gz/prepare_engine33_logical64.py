from pathlib import Path

files = {}

def change(name, old, new):
    text = files.get(name, Path(name).read_text())
    assert text.count(old) == 1, (name, text.count(old), old[:70])
    files[name] = text.replace(old, new, 1)

server = "zig/pkg/inference/src/server/server.zig"
pool = "zig/pkg/inference/src/server/reader_execution_pool.zig"
scheduler = "zig/pkg/inference/src/runtime/scheduler/native_generate.zig"
bench = "zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py"

change(pool, "pub const Pool = struct {", "pub const Pool = struct {\n    pub const max_capacity: usize = 64;")
change(pool, "capacity > 32", "capacity > max_capacity")
change(pool, "pool.join(.{}, 33,", "pool.join(.{}, 65,")
base = files[pool]
start = base.index('test "LightOnOCR3 logical window keeps thirty-two')
end = base.index('test "LightOnOCR3 extended epoch', start)
block = base[start:end]
block = block.replace("thirty-two", "sixty-four").replace("pool.join(.{}, 65,", "pool.joinBounded(.{}, 65, 256,").replace("pool.join(.{}, 32,", "pool.joinBounded(.{}, 64, 256,").replace("[32]Pool.Lease", "[64]Pool.Lease").replace("@as(usize, 32), pool.users", "@as(usize, 64), pool.users").replace("for (1..32)", "for (1..64)")
files[pool] = base[:end] + block + base[end:]

change(server, "controls: [32]?InferenceExecutionControl", "controls: [reader_execution_pool.Pool.max_capacity]?InferenceExecutionControl")
change(server, "unreachable; // The pool admits at most thirty-two live page leases.", "unreachable; // Pool capacity and the control table share this bound.")
change(server, "var tasks: [16]Task = undefined;\n        var threads: [16]std.Thread = undefined;", "var tasks: [reader_execution_pool.Pool.max_capacity]Task = undefined;\n        var threads: [reader_execution_pool.Pool.max_capacity]std.Thread = undefined;")
change(server, "const count = @min(images.len, effectiveLightOnReadWindow());", "const count = lightOnContinuousWorkerCount(images.len);")
change(server, "if (concurrency == 0 or concurrency > 32) return error.InvalidBenchmarkConcurrency;", "if (concurrency == 0 or concurrency > reader_execution_pool.Pool.max_capacity) return error.InvalidBenchmarkConcurrency;")
change(server, "if (requests == 0 or pages_per_request == 0 or pages_per_request > 8) return error.InvalidBenchmarkConcurrency;", "if (requests == 0 or pages_per_request == 0 or pages_per_request > max_read_batch_images) return error.InvalidBenchmarkConcurrency;")
change(server, "var tasks: [32]ConcurrentOcrBenchTask = undefined;\n            var threads: [32]std.Thread = undefined;", "var tasks: [reader_execution_pool.Pool.max_capacity]ConcurrentOcrBenchTask = undefined;\n            var threads: [reader_execution_pool.Pool.max_capacity]std.Thread = undefined;")
change(server,
       '    const ceiling: usize = if (metal_runtime.lightOnThroughputFeatureEnabled("ANTFLY_LIGHTONOCR3_WIDE_DECODE")) 32 else 16;\n    return @min(@max(platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_BATCH_WINDOW") orelse (if (effectiveLightOnReadRows() > 16)',
       '    const ceiling: usize = if (!metal_runtime.lightOnThroughputFeatureEnabled("ANTFLY_LIGHTONOCR3_WIDE_DECODE")) 16 else if (lightOnPhysicalRowCeiling() == 32 and platform.env.getenvBool("ANTFLY_LIGHTONOCR3_LOGICAL64")) reader_execution_pool.Pool.max_capacity else 32;\n    return @min(@max(platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_BATCH_WINDOW") orelse (if (ceiling > 32) ceiling else if (effectiveLightOnReadRows() > 16)')
needle = "/// Give concurrent OCR pages time to reach the same cohort before acquiring"
change(server, needle, "fn lightOnContinuousWorkerCount(images: usize) usize {\n    return @min(images, effectiveLightOnReadWindow(), reader_execution_pool.Pool.max_capacity);\n}\n\n" + needle)
change(server, '        "ANTFLY_LIGHTONOCR3_PHYSICAL32",\n    };', '        "ANTFLY_LIGHTONOCR3_PHYSICAL32",\n        "ANTFLY_LIGHTONOCR3_LOGICAL64",\n    };')

test = '''
test "LightOnOCR3 logical64 isolates physical rows and bounds multi-image workers" {
    if (comptime !@import("builtin").link_libc) return error.SkipZigTest;
    const a = std.testing.allocator;
    const Env = struct {
        extern "c" fn setenv([*:0]const u8, [*:0]const u8, c_int) c_int;
        extern "c" fn unsetenv([*:0]const u8) c_int;
    };
    const names = [_][:0]const u8{ "ANTFLY_LIGHTONOCR3_WIDE_DECODE", "ANTFLY_LIGHTONOCR3_PHYSICAL32", "ANTFLY_LIGHTONOCR3_LOGICAL64", "ANTFLY_LIGHTONOCR3_BATCH_ROWS", "ANTFLY_LIGHTONOCR3_BATCH_WINDOW" };
    var old: [names.len]?[:0]u8 = @splat(null);
    var saved: usize = 0;
    defer for (names[0..saved], old[0..saved]) |name, value| {
        if (value) |s| { _ = Env.setenv(name, s, 1); a.free(s); } else _ = Env.unsetenv(name);
    };
    for (names, 0..) |name, i| {
        if (platform.env.getenv(name)) |value| old[i] = try a.dupeSentinel(u8, value, 0);
        saved += 1;
    }
    for (names[0..3]) |name| try std.testing.expectEqual(@as(c_int, 0), Env.setenv(name, "1", 1));
    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[3], "32", 1));
    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[4], "128", 1));
    const eligible = metal_runtime.qualifiedM4DeviceDefault();
    const window: usize = if (eligible) 64 else 32;
    try std.testing.expectEqual(window, effectiveLightOnReadWindow());
    try std.testing.expectEqual(window, lightOnContinuousWorkerCount(128));
    try std.testing.expectEqual(@as(usize, 17), lightOnContinuousWorkerCount(17));
    var node: Node = undefined;
    node.config = .{};
    const policy = node.lightOnOcrPolicy(32);
    try std.testing.expectEqual(@as(usize, if (eligible) 32 else 16), policy.max_step_items);
    try std.testing.expectEqual(@as(?usize, window), policy.max_active_requests_for_batching);
    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[2], "0", 1));
    try std.testing.expectEqual(@as(usize, 32), effectiveLightOnReadWindow());
    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[4], "24", 1));
    try std.testing.expectEqual(@as(usize, 24), effectiveLightOnReadWindow());
    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[2], "1", 1));
    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[1], "0", 1));
    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[4], "128", 1));
    try std.testing.expectEqual(@as(usize, 32), effectiveLightOnReadWindow());
    try std.testing.expectEqual(@as(usize, 16), effectiveLightOnReadRows());
}

'''
needle = 'test "LightOnOCR3 read routing preserves image-only and grounding prompts" {'
change(server, needle, test + needle)
change(server,
       "    try std.testing.expectEqual(@as(usize, 2), ctx.registered_window_peak);\n}",
       """    try std.testing.expectEqual(@as(usize, 2), ctx.registered_window_peak);
    var expired_slots: [63]usize = undefined;
    for (&expired_slots) |*slot| slot.* = ctx.register(.{ .deadline_ns = 0 });
    const last_live = ctx.register(.{});
    try std.testing.expectEqual(@as(usize, 63), last_live);
    try Node.LightOnStreamContext.check(&ctx);
    ctx.unregister(last_live);
    try std.testing.expectError(error.Timeout, Node.LightOnStreamContext.check(&ctx));
    for (expired_slots) |slot| ctx.unregister(slot);
    try std.testing.expectError(error.Cancelled, Node.LightOnStreamContext.check(&ctx));
    try std.testing.expectEqual(@as(usize, 64), ctx.registered_window_peak);
    try std.testing.expectEqual(@as(usize, 0), ctx.registered_pages);
}""")

test = '''
test "LightOnOCR3 logical64 executor drains two physical32 steps without allocating" {
    var coordinator = NativeGenerateCoordinator.init(std.testing.allocator);
    defer coordinator.deinit();
    coordinator.setPolicy(.{ .max_step_items = 32, .max_active_requests_for_batching = 64, .allow_mixed_sequence_lengths = true });
    var leases: [64]Lease = undefined;
    var count: usize = 0;
    defer for (leases[0..count]) |lease| coordinator.release(lease);
    for (&leases, 0..) |*lease, i| {
        lease.* = try coordinator.acquire(.{ .requested_units = 1, .prompt_bytes = 1, .max_tokens = 1 });
        count += 1;
        coordinator.beginDecode(lease, 4);
        try coordinator.enqueueDecodeWork(lease.*, @ptrFromInt(i + 1), 5, 4, 0, .{});
    }
    var storage: [32]StepItem = undefined;
    var step = std.ArrayListUnmanaged(StepItem).empty;
    const budget = coordinator.defaultStepBudget();
    coordinator.allocator = std.testing.failing_allocator;
    defer coordinator.allocator = std.testing.allocator;
    var seen: u64 = 0;
    for (0..2) |_| {
        var leader = coordinator.claimNextStep(budget, &storage, &step).?;
        try std.testing.expectEqual(@as(usize, 32), step.items.len);
        for (step.items) |item| {
            const index = @intFromPtr(item.work_ptr) - 1;
            try std.testing.expect(index < 64);
            const bit = @as(u64, 1) << @as(u6, @intCast(index));
            try std.testing.expect(seen & bit == 0);
            seen |= bit;
        }
        coordinator.completeStep(&leader, step.items);
    }
    try std.testing.expectEqual(std.math.maxInt(u64), seen);
    try std.testing.expect(coordinator.claimNextStep(budget, &storage, &step) == null);
    try std.testing.expectEqual(@as(u64, 2), coordinator.schedulerStats().step_batch_size_17_plus_total);
    coordinator.allocator = std.testing.allocator;
}

'''
needle = 'test "LightOnOCR3 executor queue wakes preserve selective publication and cancellation" {'
change(scheduler, needle, test + needle)

change(bench, '            "ANTFLY_LIGHTONOCR3_TOKEN_ENCODER",', '            "ANTFLY_LIGHTONOCR3_LOGICAL64",\n            "ANTFLY_LIGHTONOCR3_TOKEN_ENCODER",')
change(bench, '    env["ANTFLY_LIGHTONOCR3_PHYSICAL32"] = "1" if args.physical32 else "0"', '    env["ANTFLY_LIGHTONOCR3_LOGICAL64"] = "1" if args.logical64 else "0"\n    env["ANTFLY_LIGHTONOCR3_PHYSICAL32"] = "1" if args.physical32 else "0"')
change(bench, '    parser.add_argument("--physical32", action="store_true")', '    parser.add_argument("--physical32", action="store_true")\n    parser.add_argument("--logical64", action="store_true")')
change(bench, "any(c < 1 or c > 32 for c in args.concurrency)", "any(c < 1 or c > 64 for c in args.concurrency)")
change(bench, "requests must be positive; concurrency must be 1..32", "requests must be positive; concurrency must be 1..64")
change(bench, "if not 1 <= args.pages_per_request <= 8 or not 1 <= args.batch_rows <= 32:", "if not 1 <= args.pages_per_request <= 64 or not 1 <= args.batch_rows <= 32:")
change(bench, "pages per request must be 1..8; batch rows must be 1..32", "pages per request must be 1..64; batch rows must be 1..32")
change(bench, '    if not 1 <= args.batch_window <= 32:\n        parser.error("batch window must be 1..32")', '    if args.logical64 and not args.physical32:\n        parser.error("--logical64 requires --physical32")\n    if not 1 <= args.batch_window <= (64 if args.logical64 else 32):\n        parser.error("batch window must be 1..32, or 1..64 with --logical64")')
reference = "zig/pkg/inference/scripts/lightonocr3/benchmark_vllm_metal.py"
change(reference, "any(c < 1 or c > 32 for c in args.concurrency)", "any(c < 1 or c > 64 for c in args.concurrency)")
change(reference, "requests must be positive; concurrency must be 1..32", "requests must be positive; concurrency must be 1..64")

# Assert every edit before writing any runtime source.
for name, text in files.items():
    Path(name).write_text(text)
print("Applied33", len(files), "files; C, model math and memory admission unchanged")
