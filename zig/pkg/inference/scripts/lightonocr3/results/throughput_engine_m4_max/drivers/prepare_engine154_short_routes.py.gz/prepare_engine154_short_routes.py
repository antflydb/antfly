from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=p.read_text();f=json.loads((v/'engine145-freeze.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert all(sha(p)==h for p,h in f.items());assert json.loads((r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/engine149_short_core_audit.json').read_text())['status'].endswith('no_model_promotion')
a=s.index('static id<MTLComputePipelineState> termite_metal_lightonocr3_prefill_attention_pipeline(');b=s.index('static void termite_metal_lightonocr3_dispatch_prefill_attention(',a);part=s[a:b];assert part.count('queries >= 128')==1;part=part.replace('queries >= 128','queries >= 32');needle='''    return runtime->lightonocr3_projections_enabled && runtime->qwen35_ocr_vector_loads_enabled &&''';assert part.count(needle)==1;part=part.replace(needle,'''    // Short queries only use the direct-KV pipeline at measured crossovers.
    // A missing/disabled direct pipeline falls back to generic attention;
    // staging K/V for these shapes is slower. Single-token decode is unchanged.
    const bool short_direct = p->q_len < 128 && p->kv_tokens >= 256 &&
        ((p->num_heads == 16 && p->q_len >= 32) || (p->num_heads == 8 && p->q_len >= 64)) &&
        pipeline != nil && pipeline == runtime->lightonocr3_prefill_attention_direct_pipeline;
'''+needle);part=part.replace('p->q_len >= 128 && p->q_len <= 2048','(p->q_len >= 128 || short_direct) && p->q_len <= 2048');s=s[:a]+part+s[b:]
s=s.replace('if (runtime->lightonocr3_prefill_attention_mpp_dispatches++ == 0 &&','if ((runtime->lightonocr3_prefill_attention_mpp_dispatches++ == 0 || p->q_len < 128) &&')
a=s.index('        id<MTLComputePipelineState> pipelines[5]={runtime->qwen35_conv_pipeline',s.index('int termite_metal_decode_runtime_qwen35_core_device('));b=s.index('        const bool parallel_norm =',a);part=s[a:b];assert part.count('seq >= 128')==2;part=part.replace('seq >= 128','seq >= 2');part=part.replace('if (prefill_norm && runtime->lightonocr3_prefill_norm_dispatches++ == 0 &&','if (prefill_norm && (runtime->lightonocr3_prefill_norm_dispatches++ == 0 || seq < 128) &&');s=s[:a]+part+s[b:]
a=s.index('static int termite_metal_try_lightonocr3_mpp(');b=s.index('\n}',a)+2;part=s[a:b];needle='    const bool four_row_enabled =';assert part.count(needle)==1;part=part.replace(needle,'''    // Retain F32 inputs for short prefill projections. The existing MPP
    // implementation already covers these row counts for decoder cohorts.
    const bool short_prefill = !bf16 && rows >= 17 && rows <= 31 && runtime->active_frame_cb != nil &&
        runtime->active_frame_regime == TERMITE_METAL_FRAME_REGIME_PREFILL &&
        !termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_WIDE_MPP);
'''+needle);part=part.replace('rows < 32u && !small_tile && !segment4 &&','rows < 32u && !small_tile && !segment4 && !short_prefill &&');part=part.replace('const bool small_rows = small_default || wide_decode || wide_head ||','const bool small_rows = small_default || wide_decode || wide_head || short_prefill ||');s=s[:a]+part+s[b:];p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m';s=p.read_text();needle='static int apply_projection(';assert s.count(needle)==1;s=s.replace(needle,'static bool projection_prefill_phase = false;\n'+needle);s=s.replace('termite_metal_decode_runtime_set_active_frame_regime(r, TERMITE_METAL_FRAME_REGIME_DECODE))) return -200;','termite_metal_decode_runtime_set_active_frame_regime(r, projection_prefill_phase ? TERMITE_METAL_FRAME_REGIME_PREFILL : TERMITE_METAL_FRAME_REGIME_DECODE))) return -200;');s=s.replace('variant == 1 && seq >= 128 ? 1 : 0','variant == 1 && seq >= 2 ? 1 : 0');needle='''        const size_t prefill_lengths[] = {8,128,129,432,662,2048};
        for (size_t h = 16; h <= 32; h += 16) for (size_t j = 0; j < 6; j++)
            if (prefill_core_check(r,prefill_lengths[j],h,j%2,false)) return 104;''';replacement='''        const size_t prefill_lengths[] = {1,2,3,4,7,8,15,16,17,22,31,32,33,42,48,63,64,65,95,96,127,128,129,432,662,2048};
        for (size_t h = 16; h <= 32; h += 16)
            for (size_t j = 0; j < sizeof(prefill_lengths)/sizeof(prefill_lengths[0]); j++)
                for (size_t init = 0; init < 2; init++)
                    if (prefill_core_check(r,prefill_lengths[j],h,init != 0,false)) return 104;
        projection_prefill_phase = true;
        const size_t short_rows[] = {17,22,27,31};
        const size_t short_shapes[][2] = {{2560,8192},{2560,4096},{4096,2560},{2560,1024},{2560,9216},{9216,2560}};
        for (size_t i=0;i<4;i++) for (size_t j=0;j<6;j++) {
            const uint64_t before = r->lightonocr3_wide_mpp_projection_calls;
            if (projection(r,short_rows[i],short_shapes[j][0],short_shapes[j][1],0)) return 127;
            if (r->lightonocr3_wide_mpp_projection_calls <= before) return 128;
        }
        if (projection(r,22,2560,8192,1)) return 129;
        projection_prefill_phase = false;''';assert needle in s;s=s.replace(needle,replacement);p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/check_metal_prefill_attention.m';s=p.read_text();needle='            const bool eligible = n >= 128 && n <= 2048 && kv <= 4096;';replacement='''            const bool short_shape = n < 128 && kv >= 256 && page % 16 == 0 &&
                ((heads == 16 && n >= 32) || (heads == 8 && n >= 64));
            const bool short_direct = short_shape && (mode == 1 || mode == 5 || mode == 6);
            const bool eligible = (n >= 128 || short_direct) && n <= 2048 && kv <= 4096;''';assert needle in s;s=s.replace(needle,replacement)
needle='''        termite_metal_decode_runtime_destroy(r);
''';assert s.count(needle)==1;s=s.replace(needle,'''        if (!benchmark) {
            const size_t short_queries[] = {1,2,17,31,32,33,42,48,63,64,65,95,127};
            for (size_t h=8;h<=16;h+=8) for (size_t i=0;i<sizeof(short_queries)/sizeof(short_queries[0]);i++)
                for (size_t prefix=256;prefix<=1024;prefix*=4) for (size_t page=16;page<=128;page*=8)
                    if (check(r,short_queries[i],prefix,h,page,i%2,0,false)) return 34;
            for (size_t h=8;h<=16;h+=8) {
                if (check(r,32,256,h,8,true,0,false) || check(r,64,256,h,8,true,0,false)) return 35;
                for (int poison=1;poison<=4;poison++)
                    if (check(r,64,256,h,16,true,poison,false)) return 36;
            }
        }
'''+needle);p.write_text(s)
f[str(p.relative_to(r))]=sha(p);f={p:sha(p)for p in f};(v/'engine154-freeze.json').write_text(json.dumps(f,indent=2)+'\n');print('source154 production short routes and numerical coverage prepared; frozen',len(f),'files')
