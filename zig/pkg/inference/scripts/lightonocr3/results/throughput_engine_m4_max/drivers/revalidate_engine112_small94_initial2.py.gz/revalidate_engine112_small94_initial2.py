from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';s=r/'zig/pkg/inference/scripts/lightonocr3';o=s/'results/throughput_engine_m4_max';sys.path.insert(0,str(s));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=o/'engine112_08_cache94_small_on_c64_r64';original=old/'report.json';d=json.loads(original.read_text());raw=(old/d['results'][0]['log']).read_bytes();dest=o/'engine112_08_cache94_small_on_saved_revalidation113';assert not dest.exists();dest.mkdir()
settings=d['settings'].copy()
for key in ['reference_report','build_manifest']:
 if settings.get(key):settings[key]=Path(settings[key])
args=argparse.Namespace(**settings,native_test=Path(json.loads((o/'engine112_build_manifest.json').read_text())['binary_path']),images=[Path(x['path'])for x in d['images']],output_dir=dest)
spec=importlib.util.spec_from_file_location('saved_parser113',v/'engine113_benchmark_concurrency.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
class SavedProcess:
 returncode=0
 def __init__(self,command,**kwargs):
  assert command==[str(args.native_test.resolve()),'--test-filter','LightOnOCR3 real checkpoint']
  kwargs['stdout'].write(raw.decode());kwargs['stdout'].flush()
 def wait(self,timeout=None):return 0
mod.subprocess.Popen=SavedProcess
result=mod.run(args,Path(d['models']['lighton08']['directory']),'lighton08','batch',64,dest)
result['policy_rounds']=[dict(prior,**parsed)for prior,parsed in zip(d['results'][0]['policy_rounds'],result['policy_rounds'])]
assert result['status']=='ok'and result['serial_reference_parity']and result['cross_runtime_content_parity']
sample=result['policy_rounds'][0];assert sample['completed']==64 and not sample['admission_pressures'];assert sample['prefill_activation_pool']==1 and sample['prefill_activation_pool_hits']==114 and sample['prefill_activation_pool_hit_bytes']==580951168 and sample['activation_pool_peak_bytes']==64*1024**2
assert sample['elapsed_ms']==d['results'][0]['policy_rounds'][0]['elapsed_ms'] and sample['pages_per_second']==3.7813
assert sha(dest/result['log'])==hashlib.sha256(raw).hexdigest()
report=dict(d);report['results']=[result];report['saved_run_revalidation']=dict(original_report=str(original.relative_to(o)),original_report_sha256=sha(original),original_raw_log_sha256=hashlib.sha256(raw).hexdigest(),parser_sha256=sha(v/'engine113_benchmark_concurrency.py'),validation_driver_sha256=sha(Path(__file__)),scope='Replayed saved native log through corrected full parser; no native process, no GPU work, no new timing. Original failed report/log preserved untouched. Native binary/runtime qualification remains112.');(dest/'report.json').write_text(json.dumps(report,indent=2)+'\n')
a=dict(status='saved_run_revalidation_pass',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),report=str((dest/'report.json').relative_to(o)),report_sha256=sha(dest/'report.json'),original_report_sha256=sha(original),scope=report['saved_run_revalidation']['scope'],prefill_hits=114,prefill_hit_bytes=580951168,peak_bytes=64*1024**2,completed=64)
(o/'engine112_small94_saved_revalidation113_audit.json').write_text(json.dumps(a,indent=2)+'\n');print(a)
