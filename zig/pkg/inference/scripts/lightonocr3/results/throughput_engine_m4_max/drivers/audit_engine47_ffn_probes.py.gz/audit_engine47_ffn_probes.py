from pathlib import Path
import hashlib,json,re,statistics
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for stem,tag,label in [('engine47_bf16_ffn_probe','BF16_STREAM_FFN','bf16-ffn'),('engine47_bf16_vs_f32_ffn_probe','BF16_VS_F32_FFN','bf16-vs-f32-ffn')]:
 p=Path('/private/tmp/ocr-engine47-'+label+'-probe.txt')
 pat=tag+r' rows=(\d+) in=(\d+) out=(\d+) layers=(\d+) variant=(\d+) on=(\d+) leg=(\d+) frame_gpu_us=([0-9.]+) projection_gpu_us=([0-9.]+) max_abs=([0-9.e+-]+) cpu_error=([0-9.e+-]+)'
 records=[]
 for m in re.finditer(pat,p.read_text()):
  x=m.groups();d=dict(zip(['rows','in','out','layers','variant','on','leg'],map(int,x[:7])));d.update(zip(['frame_gpu_us','projection_gpu_us','max_abs','cpu_error'],map(float,x[7:])));records.append(d)
 assert len(records)==48
 assert all(x['layers']==32 and x['max_abs']<=2e-4 and x['cpu_error']<=2e-4 for x in records)
 groups={}
 for r in records:groups.setdefault((r['rows'],r['variant']),[]).append(r)
 comparisons=[]
 for (rows,var),rs in sorted(groups.items()):
  assert len(rs)==4 and sorted(x['leg']for x in rs)==[0,1,2,3]
  on=[r['frame_gpu_us']for r in rs if r['on']];off=[r['frame_gpu_us']for r in rs if not r['on']]
  comparisons.append(dict(rows=rows,variant=var,candidate_to_baseline=statistics.mean(on)/statistics.mean(off),both_candidate_legs_faster_than_both_control=max(on)<min(off)))
 manifest=out/(stem+'_build_manifest.json');build=json.loads(manifest.read_text());assert build['exit_code']==0
 assert sha(Path(build['binary']))==build['binary_sha256']
 assert all(sha(Path(p))==s for p,s in build['input_sha256'].items())
 audit=dict(status='pass',primary_throughput_eligible=False,raw_log_sha256=sha(p),build_manifest_sha256=sha(manifest),records=records,comparisons=comparisons,
 scope='Isolated 32-distinct-weight-pair streamed FFN probe; source is exactly BF16 representable, same-math CPU/fullGPU reference. Candidate includes 32 GPU packs/frame; offsets/canaries/private producer. Not full-model throughput.',
 decision='BF16 adds only about 4–6% versus the same F32-input MPP tile, despite a larger gain versus generic fusion. Do not change runtime precision. Next assess the F32 full64 tile with explicit rollout and full-model controls.')
 (out/(stem+'_audit.json')).write_text(json.dumps(audit,indent=2)+'\n')
 print(stem,comparisons)
frozen=json.loads((v/'engine45-freeze.json').read_text());assert all(sha(Path(p))==s for p,s in frozen.items())
(out/'engine45_post_paired27_and_probe47_freeze_audit.json').write_text(json.dumps(dict(status='pass',runtime_files_sha256=frozen,scope='All paired27/full-prefill4 and both probe47 jobs complete; source21 unchanged before next runtime edits.'),indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('qualification',[Path('/private/tmp/ocr-engine47-bf16-ffn-probe-driver.txt'),Path('/private/tmp/ocr-engine47-bf16-vs-f32-ffn-probe-driver.txt')],'logs_manifest.json')
