from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';s=(v/'engine106_wide_core_kernels.m').read_text();needle='typedef struct termite_metal_decode_runtime {';assert s.count(needle)==1
s=s.replace(needle,'''typedef struct {
    void *buffer;
    size_t begin, end;
    uint16_t next;
    bool write;
} termite_metal_core_access_interval;
'''+needle)
needle='    uint32_t qwen35_core_batch_params[64][6];';assert s.count(needle)==1;s=s.replace(needle,needle+'''
    uint16_t qwen35_core_batch_interval_heads[2048];
    termite_metal_core_access_interval qwen35_core_batch_intervals[64 * 15];
    size_t qwen35_core_batch_interval_count;''')
a=s.index('int termite_metal_decode_runtime_qwen35_core_batch_begin(');b=s.index('void termite_metal_decode_runtime_qwen35_core_batch_abort(',a);part=s[a:b];needle='    runtime->qwen35_core_batch_count = 0;';assert part.count(needle)==1;part=part.replace(needle,needle+'''
    if (rows > 16) {
        memset(runtime->qwen35_core_batch_interval_heads,0,sizeof(runtime->qwen35_core_batch_interval_heads));
        runtime->qwen35_core_batch_interval_count=0;
    }''');s=s[:a]+part+s[b:]
needle='int termite_metal_decode_runtime_qwen35_core_device(';assert s.count(needle)==1
helper='''// An exact interval index avoids the quadratic cross-page alias scan in
// wide batches. Each row is checked entirely before any of its ranges are
// inserted, preserving the generic core's supported within-row aliases.
static size_t termite_metal_qwen35_core_interval_bucket(void *buffer) {
    const uint64_t key=(uint64_t)(uintptr_t)buffer;
    return (size_t)(((key >> 4) * UINT64_C(11400714819323198485)) >> 53);
}
static int termite_metal_qwen35_core_collect_intervals(termite_metal_decode_runtime *runtime,
    void *const *handles,const size_t *offsets,const size_t *counts) {
    const uint16_t *heads=runtime->qwen35_core_batch_interval_heads;
    for(size_t j=0;j<15;j++) {
        const bool write=j==7||j==8||j==9||j==10||j==11||j==14;
        const size_t begin=offsets[j],end=begin+counts[j]*sizeof(float);
        for(uint16_t link=heads[termite_metal_qwen35_core_interval_bucket(handles[j])];link;link=runtime->qwen35_core_batch_intervals[link-1].next) {
            const termite_metal_core_access_interval *prior=&runtime->qwen35_core_batch_intervals[link-1];
            if(prior->buffer==handles[j]&&(write||prior->write)&&begin<prior->end&&prior->begin<end)return -11;
        }
    }
    for(size_t j=0;j<15;j++) {
        const bool write=j==7||j==8||j==9||j==10||j==11||j==14;
        const size_t begin=offsets[j],end=begin+counts[j]*sizeof(float);
        const size_t bucket=termite_metal_qwen35_core_interval_bucket(handles[j]);
        bool merged=false;
        for(uint16_t link=heads[bucket];link;link=runtime->qwen35_core_batch_intervals[link-1].next) {
            termite_metal_core_access_interval *prior=&runtime->qwen35_core_batch_intervals[link-1];
            // Merge only overlapping or adjacent ranges with identical access
            // modes. Gaps and read-only regions never become spurious writes.
            if(prior->buffer==handles[j]&&prior->write==write&&begin<=prior->end&&prior->begin<=end) {
                prior->begin=MIN(prior->begin,begin);prior->end=MAX(prior->end,end);merged=true;break;
            }
        }
        if(!merged) {
            const size_t index=runtime->qwen35_core_batch_interval_count++;
            if(index>=64*15)return -11;
            runtime->qwen35_core_batch_intervals[index]=(termite_metal_core_access_interval){handles[j],begin,end,runtime->qwen35_core_batch_interval_heads[bucket],write};
            runtime->qwen35_core_batch_interval_heads[bucket]=(uint16_t)(index+1);
        }
    }
    return 0;
}
'''
s=s.replace(needle,helper+needle)
a=s.index('        if (runtime->qwen35_core_batch_active) {',s.index(needle));b=s.index('            memcpy(runtime->qwen35_core_batch_handles[row]',a);part=s[a:b];loop=part.index('            const size_t writes[6]');prefix=part[:loop];old=part[loop:];part=prefix+'''            if(runtime->qwen35_core_batch_expected>16) {
                const int aliases=termite_metal_qwen35_core_collect_intervals(runtime,handles,offsets,counts);
                if(aliases)return aliases;
            } else {
'''+old+'            }\n';s=s[:a]+part+s[b:]
p=v/'engine107_wide_core_kernels.m';assert not p.exists();p.write_text(s)
for kind in ['checks','probe']:
 s=(v/f'engine106_wide_core_{kind}.m').read_text().replace('engine106','engine107').replace('WIDE106','WIDE107').replace('WALL106','WALL107')
 if kind=='checks':
  needle='    id<MTLBuffer> producers[64], consumers[64];';assert s.count(needle)==1
  s=s.replace(needle,'''    if(pages>16) for(size_t alias=0;alias<4;alias++) {
        if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_qwen35_core_batch_begin(r,pages)!=1)return 67;
        if(termite_metal_decode_runtime_qwen35_core_device(r,handles[1][0],offsets[1][0],1,kh,vh,128,4,1))return 68;
        void *bad[15];size_t off[15];memcpy(bad,handles[1][1],sizeof(bad));memcpy(off,offsets[1][1],sizeof(off));
        if(alias==0||alias==1){bad[8]=handles[1][0][8];off[8]=offsets[1][0][8]+(alias==1?16:0);}
        if(alias==2){bad[0]=handles[1][0][9];off[0]=offsets[1][0][9];}
        if(alias==3){bad[0]=handles[1][0][0];off[0]=offsets[1][0][0];}
        const int rc=termite_metal_decode_runtime_qwen35_core_device(r,bad,off,1,kh,vh,128,4,1);
        if(rc!=(alias==3?0:-11))return 69;
        termite_metal_decode_runtime_qwen35_core_batch_abort(r);
        if(termite_metal_decode_runtime_cancel_frame(r))return 70;
    }
'''+needle)
 p=v/f'engine107_wide_core_{kind}.m';assert not p.exists();p.write_text(s)
d=json.loads((v/'engine106_wide_core_preparation.json').read_text());d['scope']+=' Source107exactperbufferintervalhashvalidation forwidegroups preservesread/writecrosspagerules andwithinrowaliascontract;sharedreadduplicateandadjacentonlyrangesmerge. Fouradditionalnegative/readonlyaliaschecks. Productionnarrowhelperandcrosspagevalidatorunchanged.';d['files_sha256']={str((v/f'engine107_wide_core_{k}.m').relative_to(r)):hashlib.sha256((v/f'engine107_wide_core_{k}.m').read_bytes()).hexdigest()for k in ['kernels','checks','probe']};(v/'engine107_wide_core_preparation.json').write_text(json.dumps(d,indent=2)+'\n')
s=(v/'run_engine105_wide_core_suppressed.py').read_text().replace('engine105','engine107').replace('engine104','engine107').replace('WIDE104','WIDE107').replace('WALL104','WALL107').replace('WAIT105','WAIT107').replace('START105','START107').replace('PASS105','PASS107');s=s.replace('Source105reusessameimmutable104binary.','Source107immutablebinarywithoriginalproductionnarrowhelperandlinearwidevalidation.');(v/'run_engine107_wide_core_suppressed.py').write_text(s)
