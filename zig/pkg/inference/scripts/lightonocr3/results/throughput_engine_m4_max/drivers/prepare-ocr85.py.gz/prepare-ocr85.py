from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal'
for f in ['run_engine84_verify_gpu_build.py','run_engine84_metal_disabled.py','run_engine84_qualification.py','run_engine84_budget_policies.py','engine84_benchmark_concurrency.py']:
 p=v/f
 if p.exists():
  q=v/f.replace('84','85');assert not q.exists();q.write_text(p.read_text().replace('engine84','engine85').replace('ENGINE84','ENGINE85'))
f=json.loads((v/'engine84-freeze.json').read_text());(v/'engine85-freeze.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest()for p in f},indent=2)+'\n')
