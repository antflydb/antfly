from pathlib import Path
import subprocess,sys,json,hashlib,os
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=json.loads((v/'engine85-freeze.json').read_text());assert all(sha(r/p)==h for p,h in f.items())
for name,cmd,cwd in [('image',['/Users/ajroetker/bin/zig-0.17.0/zig','build','lib-image-test','-Doptimize=ReleaseFast'],r/'zig'),('gpu',[sys.executable,str(v/'run_engine85_verify_gpu_build.py')],r),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine85','/private/tmp/ocr-engine85-verify2-gpu-build.txt'],r),('cpu',[sys.executable,str(v/'run_engine85_metal_disabled.py')],r)]:
 print('START ENGINE85',name,flush=True)
 with Path('/private/tmp/ocr-engine85-'+name+'-parent.txt').open('w')as log:result=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(r/'zig/.zig-cache/global')))
 print('DONE ENGINE85',name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
 assert all(sha(r/p)==h for p,h in f.items())
m=json.loads((o/'engine85_build_manifest.json').read_text());os.link(Path(m['binary_path']),v/'qualified-binaries/engine85-test');assert sha(v/'qualified-binaries/engine85-test')==m['binary_sha256']
old=json.loads((o/'engine80_c_build_manifest.json').read_text());assert all(sha(r/p)==h for p,h in old['input_sha256'].items())
(o/'engine85_c_reuse_audit.json').write_text(json.dumps(dict(status='pass',scope='Only exact integer CPU horizontal resizing and the Zig private BF16 scratch capacity change. C/header/checker inputs remain byte-identical to source80; reuse nineteen C suites, extended FFN guards and real-weight source82/83 checks.',input_sha256=old['input_sha256'],binary_sha256=old['binary_sha256']),indent=2)+'\n')
print('ENGINE85 QUALIFICATION DONE',flush=True)
