from pathlib import Path
import json,subprocess,sys,hashlib,re
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';p=root/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_engine_m4_max';manifest=out/'engine37_build_manifest.json';binary=json.loads(manifest.read_text())['binary_path']
oracle=out/'mlx_florence_engine31_paired14_r0_reference/report.json'
checks=[];native_reference=None
for enabled in [False,True]:
 dest=out/f'engine37_florence_encoder_qualification_enabled{int(enabled)}'
 command=[sys.executable,str(p/'benchmark_concurrency.py'),'--native-test',binary,'--model','florence=/Users/ajroetker/.antfly/inference/models/antflydb/florence-2-base','--images',str(root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(p/'corpus/receipt.png'),str(p/'corpus/shipping.png'),'--requests','16','--concurrency','8','--max-tokens','256','--modes','batch','--native-read-batch-size','8','--batch-wait-us','5000','--florence-batch-wait-us','5000','--memory-gib','24','--shared-memory-gib','28','--backend-memory-gib','16','--kv-memory-gib','4','--scratch-memory-gib','8','--timeout','600','--reference-report',str(oracle),'--build-manifest',str(manifest),'--output-dir',str(dest),'--require-florence-no-repeat-argmax','--require-florence-single-frame','--policy-rounds','current']
 if enabled:command+=['--ocr-encoder-scopes']
 print('START',enabled,flush=True)
 with open(f'/private/tmp/ocr-engine37-florence-encoder-qualification-{int(enabled)}.txt','w')as stream:result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
 assert result.returncode==0,(enabled,result.returncode)
 rp=dest/'report.json';d=json.loads(rp.read_text());r=d['results'][0];sample=r['policy_rounds'][0]
 assert r['status']=='ok'and r['serial_reference_parity']and r['cross_runtime_content_parity']and sample['completed']==16
 frames=r['florence_single_frame'];assert frames['steps']>0 and frames['api_fallbacks']==0 and frames['topology_mismatches']==0,frames
 texts={x['image_index']:x['text']for x in r['references']}
 if native_reference is None:native_reference=texts
 else:assert texts==native_reference
 reference={x['image_index']:x['text']for x in json.loads(oracle.read_text())['references']}
 assert{k:''.join(t.split())for k,t in texts.items()}=={k:''.join(t.split())for k,t in reference.items()}
 timed=(dest/r['log']).read_text().split('OCR_POLICY round=0')[1]
 scopes=list(map(int,re.findall(r'FLORENCE2 encoder_scope_opens=(\d+)',timed)))
 assert scopes and all((x>0)==enabled for x in scopes),scopes
 checks.append(dict(enabled=enabled,completed=16,native_full_fixture_string_identity=True,cross_runtime_full_fixture_string_identity=texts==reference,cross_runtime_whitespace_normalized_content=True,encoder_scope_opens=scopes,single_frame=frames,primary_throughput_eligible=False,report=str(rp.relative_to(out)),report_sha256=hashlib.sha256(rp.read_bytes()).hexdigest()))
 print('QUALIFIED',enabled,scopes,flush=True)
(out/'engine37_florence_encoder_qualification_audit.json').write_text(json.dumps(dict(checks=checks,status='pass',scope='On/off qualification only. Florence native Q4_K/no-repeat vs MLX FP16/default greedy; actual vLLM adapter unavailable.'),indent=2)+'\n')
