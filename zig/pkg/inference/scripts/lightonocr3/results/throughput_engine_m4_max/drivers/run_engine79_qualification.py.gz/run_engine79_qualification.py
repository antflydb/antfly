from pathlib import Path
import subprocess,sys,json,hashlib,os
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=json.loads((v/'engine79-freeze.json').read_text());assert all(sha(r/p)==h for p,h in f.items())
# Standalone checker covers production C helper and fresh original nineteen suites.
for name,cmd in [('c-build',[sys.executable,str(v/'build_engine79_conformance.py')]),('c-qualification',[sys.executable,str(v/'run_engine79_c_qualification.py')]),('gpu',[sys.executable,str(v/'run_engine79_verify_gpu_build.py')]),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine79','/private/tmp/ocr-engine79-verify2-gpu-build.txt']),('cpu',[sys.executable,str(v/'run_engine79_metal_disabled.py')])]:
 print('START ENGINE79',name,flush=True)
 with Path('/private/tmp/ocr-engine79-'+name+'-parent.txt').open('w')as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 print('DONE ENGINE79',name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
 assert all(sha(r/p)==h for p,h in f.items())
print('ENGINE79 QUALIFICATION DONE',flush=True)
