from pathlib import Path
import hashlib,json,re,subprocess
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';out=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';old=json.loads((v/'engine68-freeze.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((out/'engine68_prefill_stream49_4b_r128_audit.json').read_text());assert a['status']=='pass'
for p,h in old.items():assert sha(root/p)==h,p
p=root/'zig/pkg/inference/src/ops/metal_compute.zig';s=p.read_text();old_expr='@as(u64, 1) << @intCast(rows)';assert s.count(old_expr)==4
helper='''/// Page counts are one based; the largest supported cohort owns bit 63.
fn lightOnReportedRowBit(rows: usize) u64 {
    if (rows == 0 or rows > 64) return 0;
    return @as(u64, 1) << @as(u6, @intCast(rows - 1));
}
'''
test='''test "LightOnOCR3 row reporting covers sixty-four cohorts without shift overflow" {
    var seen: u64 = 0;
    for (1..65) |rows| {
        const bit = lightOnReportedRowBit(rows);
        try std.testing.expect(bit != 0);
        try std.testing.expectEqual(@as(u64, 0), seen & bit);
        seen |= bit;
    }
    try std.testing.expectEqual(std.math.maxInt(u64), seen);
    try std.testing.expectEqual(@as(u64, 1), lightOnReportedRowBit(1));
    try std.testing.expectEqual(@as(u64, 1) << 63, lightOnReportedRowBit(64));
    try std.testing.expectEqual(@as(u64, 0), lightOnReportedRowBit(0));
    try std.testing.expectEqual(@as(u64, 0), lightOnReportedRowBit(65));
    try std.testing.expectEqual(@as(u64, 0), lightOnReportedRowBit(std.math.maxInt(usize)));
}
'''
s=s.replace(old_expr,'lightOnReportedRowBit(rows)')+'\n'+helper+'\n'+test
(v/'engine68-before69-metal_compute.zig').write_bytes(p.read_bytes());p.write_text(s)
p=root/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';s=p.read_text();anchor='def run(';assert anchor in s
# Keep the reporting helper separate from hardware setup so saved logs can
# independently verify observed streaming rather than merely requested flags.
helper_py='''def prefill_stream_observation(text):
    values = re.findall(
        r"LIGHTONOCR3 prefill_stream_layers=(\\d+) prefill_stream_splits=(\\d+)", text
    )
    return {
        "prefill_stream_layers_observed": sorted({int(k) for k, _ in values}),
        "prefill_stream_splits": sum(int(n) for _, n in values),
    }


'''
s=s.replace(anchor,helper_py+anchor,1)
anchor='''                    for counter in (
                        "prepared_blocks",''';assert anchor in s
s=s.replace(anchor,'''                    sample.update(prefill_stream_observation(section))
                    for counter in (
                        "prepared_blocks",''',1)
(v/'engine68-before69-benchmark_concurrency.py').write_bytes(p.read_bytes());p.write_text(s)
subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt',str(root/'zig/pkg/inference/src/ops/metal_compute.zig')],check=True)
subprocess.run(['/Users/ajroetker/.local/bin/ruff','format',str(p)],check=True)
(v/'engine69_trace_mask_debug_check.zig').write_text('const std = @import("std");\n'+helper+'\n'+test)
(v/'engine69-freeze.json').write_text(json.dumps({p:sha(root/p)for p in old},indent=2)+'\n')
print('engine69 trace boundary and observed counter reporting applied and frozen')
