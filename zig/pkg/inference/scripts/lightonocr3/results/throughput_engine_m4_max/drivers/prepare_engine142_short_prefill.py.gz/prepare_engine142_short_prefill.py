from pathlib import Path
import json,hashlib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=p.read_text();a=s.index('static bool termite_metal_lightonocr3_prefill_attention_mpp_eligible(');b=s.index('static void termite_metal_lightonocr3_dispatch_prefill_attention(',a);part=s[a:b];assert part.count('p->q_len >= 128')==1;part=part.replace('p->q_len >= 128','p->q_len >= 2');s=s[:a]+part+s[b:];(v/'engine142_short_prefill_kernels.m').write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/check_metal_prefill_attention.m';c=p.read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine142_short_prefill_kernels.m"');assert c.count('const bool eligible = n >= 128')==1;c=c.replace('const bool eligible = n >= 128','const bool eligible = n >= 2').replace('const bool expected_direct = eligible &&','const bool expected_direct = eligible && n >= 128 &&');(v/'engine142_short_prefill_checks.m').write_text(c)
probe='''#define main unused_prefill142_main
#include "engine142_short_prefill_checks.m"
#undef main
int main(int argc,const char**argv){@autoreleasepool{
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_ATTENTION_MPP","1",1);
 bool benchmark=argc==2&&strcmp(argv[1],"--benchmark")==0;
 const size_t shortq[]={1,2,3,4,7,8,15,16,17,22,31,42,48,63,64,65,95,127};
 if(!benchmark){
  for(size_t h=8;h<=16;h+=8)for(size_t i=0;i<sizeof(shortq)/sizeof(shortq[0]);i++){
   int rc=check(r,shortq[i],512,h,128,i%2,0,false);if(rc){fprintf(stderr,"SHORT142_FAIL heads=%zu q=%zu rc=%d\\n",h,shortq[i],rc);return rc+10;}
  }
  const size_t poisonq[]={2,17,42,127};for(size_t h=8;h<=16;h+=8)for(size_t i=0;i<4;i++)for(int poison=1;poison<=4;poison++){
   int rc=check(r,poisonq[i],63,h,i%2?8:16,true,poison,false);if(rc){fprintf(stderr,"SHORT142_POISON_FAIL heads=%zu q=%zu poison=%d rc=%d\\n",h,poisonq[i],poison,rc);return rc+40;}
  }
  fprintf(stderr,"SHORT142 FULL OUTPUT CPU FRAGMENTED OFFSET CANARY CANCEL NONFINITE CHECKS PASS\\n");
 }else{
  const size_t qs[]={2,8,16,22,42,48,64,96,127};for(size_t h=8;h<=16;h+=8)for(size_t i=0;i<sizeof(qs)/sizeof(qs[0]);i++){
   int rc=check(r,qs[i],512,h,128,false,0,true);if(rc)return rc+80;
  }
  fprintf(stderr,"SHORT142 BALANCED SHORT-PREFIX TIMINGS PASS\\n");
 }
 termite_metal_decode_runtime_destroy(r);return 0;
}}
''';(v/'engine142_short_prefill_probe.m').write_text(probe);d=dict(status='prepared_not_compiled_or_run',scope='Private eligibility-only expansion of existing F32-query/probability MPP prefill attention from128..2048 to2..2048 queries; q1 decode route unchanged. No shader math, dtype, scratch or budget change. Realistic past-prefix512/offset17, fragmented pages, twoheadshapes, fullCPU/reference/canary/cancellation/nonfinite checks before isolated timing. Must wait for owned chunk128 cohort to finish; no own GPU/build overlap.',canonical_c_sha256=hashlib.sha256((r/'zig/pkg/inference/src/backends/metal_kernels.m').read_bytes()).hexdigest(),source_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in [v/'engine142_short_prefill_kernels.m',v/'engine142_short_prefill_checks.m',v/'engine142_short_prefill_probe.m',Path(__file__)]});(v/'engine142_short_prefill_preparation.json').write_text(json.dumps(d,indent=2)+'\n');print('Private short-query attention guard prototype prepared; no runtime edits or GPU work')
