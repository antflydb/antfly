from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=(v/'engine115_chunk.metal').read_text();a=s.index('kernel void chunk_state115(');head=s[:a];t=s[a:]
t=t.replace('threadgroup float s[128*16],qm[256],km[256],delta[256];','threadgroup float s[128*16],qm[256],km[256],delta[256];\n threadgroup half hq[2048],hk[2048],hs[2048],hd[256],hm[256];')
needle='  device const float*c=coef+((start/16)*p.value_heads+h)*544;';t=t.replace(needle,needle+'''\n  for(uint z=tid;z<2048;z+=128){uint row=z/128,d=z%128;hq[z]=half(x[(start+row)*channels+kh*128+d]);hk[z]=half(x[(start+row)*channels+(p.key_heads+kh)*128+d]);hs[z]=half(s[z]);}
  for(uint z=tid;z<256;z+=128)hm[z]=half(c[256+z]);
  threadgroup_barrier(mem_flags::mem_threadgroup);''')
t=t.replace('simdgroup_float8x8 q,k,ss;','simdgroup_half8x8 q,k,ss;').replace('simdgroup_load(q,x+(start+rb)*channels+kh*128+d,channels);','simdgroup_load(q,hq+rb*128+d,128);').replace('simdgroup_load(k,x+(start+rb)*channels+(p.key_heads+kh)*128+d,channels);','simdgroup_load(k,hk+rb*128+d,128);').replace('simdgroup_load(ss,s+d*16+vb,16);','simdgroup_load(ss,hs+d*16+vb,16);')
needle='  auto out=make_filled_simdgroup_matrix<float,8>(0.0f);';t=t.replace(needle,'  for(uint z=tid;z<256;z+=128)hd[z]=half(delta[z]);\n  threadgroup_barrier(mem_flags::mem_threadgroup);\n'+needle)
t=t.replace('simdgroup_float8x8 m,dd;simdgroup_load(m,c+256+rb*16+d,16);simdgroup_load(dd,delta+d*16+vb,16);','simdgroup_half8x8 m,dd;simdgroup_load(m,hm+rb*16+d,16);simdgroup_load(dd,hd+d*16+vb,16);')
t=t.replace('delta[z]*=c[528+i];','delta[z]*=c[528+i];hd[z]=half(delta[z]);')
t=t.replace('simdgroup_float8x8 k,dd;simdgroup_load(k,x+(start+d)*channels+(p.key_heads+kh)*128+kb,channels,0,true);simdgroup_load(dd,delta+d*16+vc,16);','simdgroup_half8x8 k,dd;simdgroup_load(k,hk+d*128+kb,128,0,true);simdgroup_load(dd,hd+d*16+vc,16);')
(v/'engine117_chunk.metal').write_text(head+t)
s=(v/'engine115_chunk_probe.m').read_text().replace('engine115_chunk.metal','engine117_chunk.metal').replace('CHUNK115','HALF117');(v/'engine117_chunk_probe.m').write_text(s)
