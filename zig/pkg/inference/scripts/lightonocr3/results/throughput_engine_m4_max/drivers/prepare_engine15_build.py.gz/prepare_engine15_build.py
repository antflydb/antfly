from pathlib import Path
import json,hashlib
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text();a=s.index('static int ocr_attention_batch_check(');b=s.index('\nint main(',a);part=s[a:b]
part=part.replace('for(size_t m=0;m<2;m++){\n        const size_t mode=(trial&1)?1-m:m;', '''for(size_t m=0;m<(benchmark?2u:4u);m++){
        const size_t variant=(trial&1)?1-m:m;
        const size_t mode=variant?1:0;
        id<MTLComputePipelineState> saved_stage=r->lightonocr3_gqa_split_stage_pipeline;
        if(variant==2)r->lightonocr3_gqa_split_stage_pipeline=nil;
        if(variant==3)setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_GQA_SPLIT","1",1);''')
part=part.replace('if(r->lighton_attention_batch->count!=rows||', 'if(r->lighton_attention_batch->count!=(variant>=2?0:rows)||')
part=part.replace('        elapsed[mode]+=', '''        r->lightonocr3_gqa_split_stage_pipeline=saved_stage;
        if(variant==3)unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_GQA_SPLIT");
        elapsed[mode]+=''')
s=s[:a]+part+s[b:];p.write_text(s)
p=Path('.venv-lighton-vllm-metal/run_engine14_gpu_build.py');s=p.read_text().replace('engine14','engine15').replace("env['ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS']='1'", "env['ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS']='0'\nenv['ANTFLY_LIGHTONOCR3_BATCH_ATTENTION']='1'")
Path('.venv-lighton-vllm-metal/run_engine15_gpu_build.py').write_text(s)
files=json.loads(Path('.venv-lighton-vllm-metal/engine14-freeze.json').read_text());Path('.venv-lighton-vllm-metal/engine15-freeze.json').write_text(json.dumps({f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in files},indent=2)+'\n')
