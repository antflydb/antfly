from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
p=v/'engine49_attention_runtime.m';s=p.read_text()
old='runtime->lightonocr3_prefill_attention_mpp32_pipeline ? 32 : engine49_query_tile;'
assert s.count(old)==1
s=s.replace(old,'runtime->lightonocr3_prefill_attention_mpp32_pipeline ? 32 : (termite_metal_lightonocr3_prefill_attention_pipeline(runtime, p->q_len, p->page_size) == runtime->lightonocr3_prefill_attention_direct_pipeline ? engine49_query_tile : 16);')
# Prepared private sources have not been built/executed. Preserve original archived versions,
# bind corrected contents by a new immutable preparation record and named archive copy.
p.write_text(s);(v/'engine49_attention_runtime_verify4.m').write_text(s)
prep=json.loads((out/'engine49_attention_probe_preparation_verify3.json').read_text())
prep['inputs'][str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
prep['scope']+=' Review correction before compilation: private query tile override applies only to the direct pipeline; staged Q16 fallback retains its own geometry.'
(out/'engine49_attention_probe_preparation_verify4.json').write_text(json.dumps(prep,indent=2)+'\n')
p=v/'build_engine49_attention_probe_verify3.py';s=p.read_text()
assert 'preparation_verify3.json'in s
s=s.replace('preparation_verify3.json','preparation_verify4.json')
s=s.replace('record=dict(command=cmd,','record=dict(builder_path=str(Path(__file__)),builder_sha256=sha(__file__),preparation="engine49_attention_probe_preparation_verify4.json",command=cmd,')
p.write_text(s);(v/'build_engine49_attention_probe_verify4.py').write_text(s)
record=dict(status='review_corrected_before_compilation',runtime_path='engine49_attention_runtime.m',runtime_sha256=hashlib.sha256((v/'engine49_attention_runtime.m').read_bytes()).hexdigest(),runtime_named_archive_copy='engine49_attention_runtime_verify4.m',builder_entrypoint='build_engine49_attention_probe_verify3.py',builder_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),builder_named_archive_copy='build_engine49_attention_probe_verify4.py',reason='Keep staged fallback geometry unchanged when testing Q32 direct kernels. Parent orchestration already queued the prepared entrypoint; actual contents and immutable original archive are both preserved. No GPU run or compile has used earlier preparation versions.')
(out/'engine49_attention_prebuild_review_correction.json').write_text(json.dumps(record,indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('drivers',[v/n for n in ['prepare_engine49_attention_probe_verify4.py','engine49_attention_runtime_verify4.m','build_engine49_attention_probe_verify4.py']],'drivers_manifest.json')
