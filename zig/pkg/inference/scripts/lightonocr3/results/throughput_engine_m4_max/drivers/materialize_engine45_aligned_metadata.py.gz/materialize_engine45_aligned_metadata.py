from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal');source=(v/'ocr-models/lighton4b').resolve();target=v/'ocr-models/lighton4b-aligned64'
records=[]
for child in target.iterdir():
 if not child.is_symlink():continue
 resolved=child.resolve();assert resolved.is_relative_to(source) and resolved.is_file(),child
 data=resolved.read_bytes();digest=hashlib.sha256(data).hexdigest()
 child.unlink();child.write_bytes(data);assert hashlib.sha256(child.read_bytes()).hexdigest()==digest
 records.append(dict(file=child.name,sha256=digest,bytes=len(data)))
o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
(o/'engine45_4b_aligned_checkpoint_materialization_manifest.json').write_text(json.dumps(dict(status='pass',metadata_files=records,metadata_identical_to_source=True,all_metadata_within_checkpoint_root=True,source_unchanged=True),indent=2)+'\n')
print('Materialized',len(records),'unchanged metadata files inside the independent model root')
