from pathlib import Path
import subprocess,sys,time
v=Path('.venv-lighton-vllm-metal')
p=Path('/private/tmp/ocr-engine45-remaining-then46-driver.txt')
while True:
 s=p.read_text() if p.exists() else ''
 if 'ALL COMPLETE' in s or 'Traceback (most recent call last)' in s:break
 time.sleep(5)
time.sleep(3)
if 'ALL COMPLETE' not in s:raise RuntimeError('Prior sequential qualification failed; inspect before running more GPU jobs')
r=subprocess.run([sys.executable,str(v/'run_engine45_gqa_ffn_ablation.py'),'primary'])
assert r.returncode==0,r.returncode
print('ABLATION COMPLETE',flush=True)
