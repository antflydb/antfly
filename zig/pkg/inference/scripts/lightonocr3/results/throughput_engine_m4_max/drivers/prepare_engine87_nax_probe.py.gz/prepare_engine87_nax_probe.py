from pathlib import Path
import json,hashlib,re
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';base=v/'lib/python3.12/site-packages/mlx/include';seen={};sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def flatten(name):
 if name in seen:return ''
 p=base/name;seen[name]=sha(p);return re.sub(r'^#include "([^"]+)"',lambda m:flatten(m[1]),p.read_text().replace('#pragma once',''),flags=re.M)
s='#include <metal_stdlib>\nusing namespace metal;\n';s+=flatten('mlx/backend/metal/kernels/complex.h');s+=flatten('mlx/backend/metal/kernels/steel/gemm/gemm_nax.h')
s+='''
struct Engine87Params {uint rows,in_dim,out_dim,pad;};
kernel void engine86_steel(device const bfloat*x[[buffer(0)]],device const bfloat*w[[buffer(1)]],device const float*bias[[buffer(2)]],device float*y[[buffer(3)]],constant Engine87Params&p[[buffer(4)]],uint sg[[simdgroup_index_in_threadgroup]],uint2 group[[threadgroup_position_in_grid]]) {
 const uint m=group.y*32+(sg/2)*16,n=group.x*64+(sg%2)*32;
 const short sm=short(clamp(int(p.rows)-int(m),0,16));
 auto tile=mlx::steel::gemm_loop<bfloat,16,32,32,32,false,true,false,true,true,float>(x+size_t(m)*p.in_dim,w+size_t(n)*p.in_dim,int(p.in_dim),int(p.in_dim),int(p.in_dim),int(p.in_dim/32),sm,32);
 if(sm>0)tile.store_safe(y+size_t(m)*p.out_dim+n,int(p.out_dim),short2(32,sm));
}
'''
p=v/'engine87_nax.metal';assert not p.exists();p.write_text(s)
d=json.loads((v/'engine86_steel_probe_verify2_preparation.json').read_text());d['mlx_headers_sha256']=seen;d['scope']='Private MLX NAX BF16/F32 GEMM primitive comparison; native operand/accumulator precision preserved. Four real FFN weights, no production change.';d['input_sha256'].pop(str(v/'engine86_steel_verify2.metal'));d['input_sha256'][str(p)]=sha(p);p=v/'engine87_nax_probe_preparation.json';assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n')
s=(v/'run_engine86_steel_probe_verify2.py').read_text().replace('engine86_steel_probe_verify2_preparation.json','engine87_nax_probe_preparation.json').replace('engine86_steel_probe_verify2_audit.json','engine87_nax_probe_audit.json').replace('engine86_steel_verify2.metal','engine87_nax.metal').replace('ocr-engine86-steel-verify2-','ocr-engine87-nax-').replace('WAIT STEEL86','WAIT NAX87').replace('STEEL86 PROTOTYPE PASS','NAX87 PROTOTYPE PASS').replace('original MPP vs MLX Steel BF16','original MPP vs MLX NAX BF16')
p=v/'run_engine87_nax_probe.py';assert not p.exists();p.write_text(s)
p=v/'run_engine85_primary71.py';s=p.read_text();assert 'run_engine87_nax_probe.py'not in s
needle='r0=reference_sweep(0,[16,32,64])';assert s.count(needle)==1
s=s.replace(needle,"print('START ISOLATED NAX PROBE BEFORE ALL 4B PRIMARY TIMINGS',flush=True)\nwith Path('/private/tmp/ocr-engine87-nax-parent.txt').open('w')as log:subprocess.run([sys.executable,str(v/'run_engine87_nax_probe.py')],stdout=log,stderr=subprocess.STDOUT,check=True)\n"+needle);p.write_text(s)
print('PREPARED NAX and ordered after small models, before fresh 4B controls')
