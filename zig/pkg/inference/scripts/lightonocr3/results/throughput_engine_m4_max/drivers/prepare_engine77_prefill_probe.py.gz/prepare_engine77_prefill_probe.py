from pathlib import Path
import hashlib,json,re
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();prod=r/'zig/pkg/inference/src/backends/metal_kernels.m';base=prod.read_text();s=base
needle='    id<MTLComputePipelineState> lightonocr3_mpp_bf16_pipeline;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    id<MTLComputePipelineState> engine77_psos[3];\n    uint32_t engine77_variant;\n    uint64_t engine77_calls;')
a=s.index('    id<MTLComputePipelineState> pipeline =\n        segment4 ?');b=s.index('    if (pipeline == nil',a)
s=s[:b]+'''    const bool engine77_on = bf16 && rows >= 128 && rows <= 1024 && runtime->engine77_variant >= 1 && runtime->engine77_variant <= 3;
    if (engine77_on) pipeline = runtime->engine77_psos[runtime->engine77_variant - 1];
    if (engine77_on && (pipeline == nil || pipeline.maxTotalThreadsPerThreadgroup < 256 || pipeline.staticThreadgroupMemoryLength > runtime->device.maxThreadgroupMemoryLength)) return 0;
'''+s[b:]
needle='''    size_t tm = (small_tile || segment4) ? 8 : (n32 ? 64 : 32), tn = segment4 ? 8 : small_tile ? (four_row_mpp ? 16 : 32) : (n32 ? 32 : 64);
    [enc dispatchThreadgroups:MTLSizeMake((out_dim + tn - 1) / tn, (rows + tm - 1) / tm, 1)
        threadsPerThreadgroup:MTLSizeMake((small_tile || segment4) ? 32 : 128, 1, 1)];'''
assert s.count(needle)==1
s=s.replace(needle,'''    size_t tm = (small_tile || segment4) ? 8 : (n32 ? 64 : 32), tn = segment4 ? 8 : small_tile ? (four_row_mpp ? 16 : 32) : (n32 ? 32 : 64);
    if (engine77_on) { const size_t ms[3]={128,128,32},ns[3]={32,64,128}; tm=ms[runtime->engine77_variant-1];tn=ns[runtime->engine77_variant-1]; }
    [enc dispatchThreadgroups:MTLSizeMake((out_dim + tn - 1) / tn, (rows + tm - 1) / tm, 1)
        threadsPerThreadgroup:MTLSizeMake(engine77_on ? 256 : (small_tile || segment4) ? 32 : 128, 1, 1)];
    if(engine77_on) runtime->engine77_calls++;''')
(v/'engine77_probe_kernels.m').write_text(s)
checker=(r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine77_probe_kernels.m"');(v/'engine77_probe_checks.m').write_text(checker)
a=base.index('        "kernel void termite_lightonocr3_mpp_bfloat_32_64(');b=base.index('        "kernel void termite_lightonocr3_mpp_bfloat_64_32(',a);body=''.join(json.loads('"'+x+'"')for x in re.findall(r'"((?:[^"\\]|\\.)*)"',base[a:b]))
header='#include <metal_stdlib>\n#include <metal_tensor>\n#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\nusing namespace metal;using namespace mpp::tensor_ops;\nstruct Params {uint rows,in_dim,out_dim,reserved;};\n';sources=[]
for variant,(m,n)in enumerate([(128,32),(128,64),(32,128)],1):
 src=body.replace('termite_lightonocr3_mpp_bfloat_32_64',f'engine77_prefill_{variant}').replace('int(group.y)*32',f'int(group.y)*{m}').replace('int(group.x)*64',f'int(group.x)*{n}').replace('matmul2d_descriptor(32,64,',f'matmul2d_descriptor({m},{n},').replace('execution_simdgroups<4>','execution_simdgroups<8>').replace('coord[0]<64',f'coord[0]<{n}').replace('coord[1]<32',f'coord[1]<{m}')
 assert src!=body;sources.append(header+src);(v/f'engine77_prefill_{variant}.metal').write_text(header+src)
(v/'engine77_sources.inc').write_text('static NSString *engine77_sources[3]={'+','.join('@'+json.dumps(x)for x in sources)+'};\n')
h=(v/'engine43_prefill64x64_probe.m').read_text();h=h[:h.index('int main(void)')];h=h.replace('engine43_prefill64x64_probe_checks.m','engine77_probe_checks.m').replace('#undef main','#undef main\n#include "engine77_sources.inc"\nstatic uint32_t engine77_candidate;').replace('r->prefill_row64_probe=on;','r->engine77_variant=on?engine77_candidate:0;').replace('r->prefill_row64_probe_calls','r->engine77_calls')
h=h.replace('const bool on=leg==1||leg==2;double total=0;float worst=0;double corner_error=0;','const bool on=leg==1||leg==2;double times[8];float worst=0;double corner_error=0;').replace('trial<40','trial<10').replace('total+=us;','if(trial>=2)times[trial-2]=us;')
a=h.index('  fprintf(stderr,"PREFILL64X64 rows=');b=h.index('\n',a)
h=h[:a]+'''  printf("{\\"candidate\\":%u,\\"rows\\":%zu,\\"in\\":%zu,\\"out\\":%zu,\\"mode\\":%d,\\"leg\\":%zu,\\"max_abs\\":%.9g,\\"cpu_error\\":%.9g,\\"gpu_us\\":[",engine77_candidate,rows,in,out,on,leg,worst,corner_error);
  for(int t=0;t<8;t++)printf("%s%.6f",t?",":"",times[t]);printf("]}\\n");fflush(stdout);'''+h[b:]
h=h.replace('free(gold);return 0;','free(w);free(b);free(gold);return 0;')
h+='''int main(void){@autoreleasepool{
 setenv("TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS","1",1);unsetenv("TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS");
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 if(termite_metal_decode_runtime_set_lighton_activation_pool(r,8*1024*1024))return 2;
 size_t ready=0;
 for(size_t i=0;i<3;i++){
  MTLCompileOptions*opt=[MTLCompileOptions new];opt.languageVersion=MTLLanguageVersion4_0;opt.fastMathEnabled=NO;opt.mathMode=MTLMathModeSafe;NSError*err=nil;
  id<MTLLibrary>lib=[r->device newLibraryWithSource:engine77_sources[i] options:opt error:&err];
  if(!lib){fprintf(stderr,"UNSUPPORTED77 candidate=%zu error=%s\\n",i+1,err.localizedDescription.UTF8String);continue;}
  r->engine77_psos[i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"engine77_prefill_%zu",i+1]);
  id<MTLComputePipelineState>p=r->engine77_psos[i];if(!p||p.maxTotalThreadsPerThreadgroup<256||p.staticThreadgroupMemoryLength>r->device.maxThreadgroupMemoryLength){fprintf(stderr,"UNSUPPORTED77 candidate=%zu PSO\\n",i+1);continue;}
  ready++;fprintf(stderr,"CANDIDATE77 READY candidate=%zu\\n",i+1);engine77_candidate=(uint32_t)i+1;
  const size_t rows[]={432,554,662},shapes[][2]={{2560,8192},{2560,4096},{4096,2560},{2560,1024},{2560,9216},{9216,2560}};
  for(size_t a=0;a<3;a++)for(size_t b=0;b<6;b++){
   int rc=probe_linear(r,rows[a],shapes[b][0],shapes[b][1]);
   if(rc){fprintf(stderr,"PROBE77 FAIL candidate=%zu rows=%zu in=%zu out=%zu rc=%d\\n",i+1,rows[a],shapes[b][0],shapes[b][1],rc);return 10+rc;}
  }
 }
 for(size_t i=0;i<3;i++)r->engine77_psos[i]=nil;
 termite_metal_decode_runtime_destroy(r);fprintf(stderr,"PROBE77 SCREEN COMPLETE ready=%zu\\n",ready);return 0;
}}
'''
(v/'engine77_prefill_probe.m').write_text(h)
inputs={str(p.relative_to(r)):sha(p)for p in [v/'engine77_probe_kernels.m',v/'engine77_probe_checks.m',v/'engine77_sources.inc',v/'engine77_prefill_probe.m',*[v/f'engine77_prefill_{i}.metal'for i in [1,2,3]]]}
(v/'engine77_prefill_preparation.json').write_text(json.dumps(dict(production_c_sha256=sha(prod),inputs=inputs,scope='Stage-one isolated new prefill matrix tiles only, one weight per shape exceeding cache for larger matrices. Same BF16 GPU packing/weights/F32 accumulation/output. GPU-produced private input, full outputs and independent CPU corners, offsets/canaries, actual selection counters, ABBA two warm/eight measured per leg. Screen only; large distinct-weight confirmation and full runtime qualification/model/paired-vLLM tests required before promotion.'),indent=2)+'\n');print('prepared novel prefill matrix screen; no production edits')
