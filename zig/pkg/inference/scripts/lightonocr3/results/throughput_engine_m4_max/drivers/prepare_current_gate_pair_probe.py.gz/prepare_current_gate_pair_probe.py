from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "../zig/pkg/inference/src/backends/metal_kernels.m"')
a=s.index('static int batch_gate_up_check(');b=s.index('\nstatic int prefill_columns_check',a);part=s[a:b]
a2='''                if (termite_metal_decode_runtime_begin_frame(r))
                    return 8;''';assert a2 in part;part=part.replace(a2,a2+'''
                if (termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_DECODE) || termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_FFN,TERMITE_METAL_COMPUTE_REGION_FFN))return 74;''',1)
old='''                        if (termite_metal_decode_runtime_begin_planned_compute_scope(
                                r, TERMITE_METAL_COMPUTE_SOURCE_FFN, TERMITE_METAL_COMPUTE_REGION_FFN) ||
                            termite_metal_decode_runtime_apply_add_device''';assert old in part;part=part.replace(old,'                        if (termite_metal_decode_runtime_apply_add_device',1)
part=part.replace('if (mode == 1 && termite_metal_decode_runtime_end_planned_compute_scope(r))','if (false && termite_metal_decode_runtime_end_planned_compute_scope(r))',1)
a2='''                if (termite_metal_decode_runtime_submit_frame(r) ||''';assert a2 in part;part=part.replace(a2,'''                if (termite_metal_decode_runtime_end_planned_compute_scope(r))return 75;
'''+a2,1)
s=s[:a]+part+s[b:];(v/'current_gate_pair_probe.m').write_text(s)
