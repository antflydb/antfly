from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';s=(v/'engine82_real_ffn_probe.m').read_text();s=s.replace('tile_m82=wide?32:0;tile_n82=wide?128:0;tile_threads82=wide?256:0;','tile_m82=wide?strtoul(getenv("ENGINE89_M"),NULL,10):0;tile_n82=wide?strtoul(getenv("ENGINE89_N"),NULL,10):0;tile_threads82=wide?strtoul(getenv("ENGINE89_THREADS"),NULL,10):0;')
s=s.replace('candidate.maxTotalThreadsPerThreadgroup<256','candidate.maxTotalThreadsPerThreadgroup<strtoul(getenv("ENGINE89_THREADS"),NULL,10)');p=v/'engine89_real_ffn_probe.m';assert not p.exists();p.write_text(s)
for m,n,sg in [(64,64,8),(128,32,8),(128,64,16)]:
 s=(v/'engine82_real_gate.metal').read_text().replace('engine78_gate<32,128,8>',f'engine78_gate<{m},{n},{sg}>');p=v/f'engine89_gate_m{m}n{n}s{sg}.metal';assert not p.exists();p.write_text(s)
