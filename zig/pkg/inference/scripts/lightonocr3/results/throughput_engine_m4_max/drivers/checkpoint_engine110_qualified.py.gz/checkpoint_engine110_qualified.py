from pathlib import Path
import datetime,gzip,hashlib,json,os,psutil,signal,subprocess,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();a=o/'engine110_checkpoint_audit.json';assert not a.exists();d=dict(status='checking_own_waiter',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)))
def save():a.write_text(json.dumps(d,indent=2)+'\n')
f=json.loads((v/'engine110-freeze.json').read_text());assert all(sha(p)==h for p,h in f.items());screen=json.loads((o/'engine110_mixed_screen89_audit.json').read_text());done=[x for x in screen['runs']if x['status']=='passed'];assert len(done)==2 and any(x['model']=='4b'and x['prefill_stream_layers']==0 for x in done)
waiters=[]
for p in psutil.process_iter(['cmdline']):
 try:
  c=p.info['cmdline']or[]
  if len(c)==2 and Path(p.cwd(),c[1]).resolve()==v/'run_engine110_mixed_screen89.py':waiters.append(p)
 except(psutil.NoSuchProcess,psutil.AccessDenied):pass
assert len(waiters)==1;p=waiters[0];d['waiter_pid']=p.pid
if p.children(recursive=True):d['status']='declined_model_child_active';save();print(d);sys.exit(0)
os.kill(p.pid,signal.SIGSTOP)
try:
 if p.children(recursive=True):d['status']='declined_child_raced_stop';save();sys.exit(0)
 d['status']='paused_own_child_free_waiter';save();print('PAUSED',p.pid,flush=True)
 subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine110_08_mixed_screen89*','engine110_4b_mixed_screen89_s0*'],check=True)
 ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
 logs=[q for q in Path('/private/tmp').glob('ocr-engine110-*.txt')if not any(x in q.name for x in ['screen89-parent','s8-p1-driver','checkpoint'])]
 ns['archive']('qualification',logs,'logs_manifest.json')
 drivers=[q for q in v.glob('*engine110*')if q.is_file()and q.suffix in ['.py','.json','.m','.inc','.metal']and q.name!=Path(__file__).name]
 drivers += [v/'archive_closed_engine102_109.py']
 ns['archive']('drivers',drivers,'drivers_manifest.json')
 c=json.loads((o/'engine109_c_build_manifest.json').read_text());assert all(sha(q)==h for q,h in c['input_sha256'].items())
 q=dict(scope='Source110scopedwide-counters+wide64kernel+packedstreamintegration. 328Metal/6skip292CPU/38skip,21C109suitesreusedafterexactinputverification. Fuzz2400layouts115575accepted1190rejectedmatcheslegacyvalidator. Small64alloutputs+stream8and4B128alloutputs+stream0exact/nopressure.4Bstream8currentlypendingoriginalreserve. ActualvLLM4BobjectiveSTILLUNMET(last102paired86reverse-1.2percent).',cpu=dict(passed=292,skipped=38),metal=dict(passed=328,skipped=6),freeze_sha256=sha(v/'engine110-freeze.json'),c_reuse_sha256=sha(o/'engine110_c_reuse_audit.json'),interval_fuzz_sha256=sha('/private/tmp/ocr-engine110-interval-fuzz.txt'),reports=[dict(report=x['report'],report_sha256=x['report_sha256'])for x in done]);(o/'engine110_qualification_audit.json').write_text(json.dumps(q,indent=2)+'\n')
 readme=o/'README.md';s=readme.read_text();s+='''\n\nSource110 passes 328 Metal-enabled tests (six skips) and 292 CPU tests\n(38 skips). The 21 C suites are reused after exact C/checker/header input\nverification. A separate CPU-only interval fuzz check agrees exactly with\nthe legacy validator on 2,400 layouts: 115,575 accepted rows and 1,190\nrejected rows. Its small-model C64/R64 packed+wide+stream8 screen returns all\n64 exact outputs at 3.9505 pages/s. Actual counters record 3,726 wide\ndispatches, 6,775,488 staged bytes, 126 prefill splits and 1,533 GPU decode\nchoices. The 4B C63/R128 wide+packed/stream0 screen returns all 128 exact\noutputs at 1.1260 pages/s without admission pressure. These are independent\ncold screens; no fresh matched speed claim follows. The 4B stream8 screen\nwaits for the original reserve. Both experimental options remain off by\ndefault.\n''';readme.write_text(s)
 assert all(sha(q)==h for q,h in f.items());production=['zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py','zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m','zig/pkg/inference/src/architectures/gpt.zig','zig/pkg/inference/src/backends/metal_kernels.m','zig/pkg/inference/src/backends/metal_runtime.zig','zig/pkg/inference/src/ops/metal_compute.zig','zig/pkg/inference/src/server/server.zig']
 subprocess.run(['git','add','--',*production,str(o.relative_to(r))],check=True)
 for name in ['engine110_mixed_screen89_audit.json','engine110_checkpoint_audit.json']:subprocess.run(['git','restore','--staged','--',str((o/name).relative_to(r))],check=True)
 subprocess.run(['git','diff','--cached','--check'],check=True);subprocess.run(['git','commit','-m','Add bounded wide recurrent OCR kernels with indexed alias checks'],check=True)
 assert all(sha(q)==h for q,h in f.items());d['commit']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();d['status']='pushing';save();subprocess.run(['git','push','origin','HEAD'],check=True);d['status']='pushed';save();print('PUSHED110',d['commit'],flush=True)
finally:
 if all(sha(q)==h for q,h in f.items()):os.kill(p.pid,signal.SIGCONT);d['waiter_resumed']=True;print('RESUMED',p.pid,flush=True)
 else:os.kill(p.pid,signal.SIGTERM);os.kill(p.pid,signal.SIGCONT);d['waiter_retired_source_changed']=True
 save()
