// Experimental mixed F32-input/BF16-weight adaptation of Apple's MLX GemvWide.
// Copyright (c) 2023-2024 Apple Inc. Portions adapted for Antfly.
// SPDX-License-Identifier: MIT
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
#include <metal_stdlib>
using namespace metal;
struct Params{uint rows,in_dim,out_dim,pad;};
template<uint NV,uint KL>inline void wide_gemv_body(device const float*x,device const ushort*w,device const float*b,device float*y,constant Params&p,uint group,uint sg,uint lane){
 constexpr uint U=8;uint kl=lane%KL,col=group*4+sg*(32/KL)+lane/KL;
 device const ushort4*w4=(device const ushort4*)(w+col*p.in_dim);device const float4*x4=(device const float4*)x;
 uint nk=p.in_dim/4,main=nk-nk%(KL*U);
 for(uint vec0=0;vec0<p.rows;vec0+=NV){
  uint off[NV];float result[NV]={0};
  #pragma unroll
  for(uint v=0;v<NV;v++)off[v]=min(vec0+v,p.rows-1)*nk;
  for(uint base=0;base<main;base+=KL*U){
   float4 wf[U];
   #pragma unroll
   for(uint i=0;i<U;i++)wf[i]=as_type<float4>(uint4(w4[base+i*KL+kl])<<16);
   #pragma unroll
   for(uint v=0;v<NV;v++){float acc=0;
    #pragma unroll
    for(uint i=0;i<U;i++)acc+=dot(wf[i],x4[off[v]+base+i*KL+kl]);
    result[v]+=acc;
   }
  }
  for(uint k=main+kl;k<nk;k+=KL){float4 wf=as_type<float4>(uint4(w4[k])<<16);
   #pragma unroll
   for(uint v=0;v<NV;v++)result[v]+=dot(wf,x4[off[v]+k]);
  }
  #pragma unroll
  for(uint v=0;v<NV;v++){
   #pragma unroll
   for(uint shift=KL/2;shift>=1;shift>>=1)result[v]+=simd_shuffle_down(result[v],shift);
  }
  if(kl==0){
   #pragma unroll
   for(uint v=0;v<NV;v++)if(vec0+v<p.rows)y[(vec0+v)*p.out_dim+col]=result[v]+b[col];
  }
 }
}
kernel void wide_gemv_0(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant Params&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){wide_gemv_body<3,16>(x,w,b,y,p,group,sg,lane);}
kernel void wide_gemv_1(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant Params&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){wide_gemv_body<3,32>(x,w,b,y,p,group,sg,lane);}
kernel void wide_gemv_2(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant Params&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){wide_gemv_body<4,16>(x,w,b,y,p,group,sg,lane);}
kernel void wide_gemv_3(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant Params&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){wide_gemv_body<4,32>(x,w,b,y,p,group,sg,lane);}
kernel void wide_gemv_4(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant Params&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){wide_gemv_body<8,16>(x,w,b,y,p,group,sg,lane);}
kernel void wide_gemv_5(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant Params&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){wide_gemv_body<8,32>(x,w,b,y,p,group,sg,lane);}
kernel void wide_gemv_6(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant Params&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){wide_gemv_body<16,16>(x,w,b,y,p,group,sg,lane);}
kernel void wide_gemv_7(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant Params&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){wide_gemv_body<16,32>(x,w,b,y,p,group,sg,lane);}
kernel void wide_gemv_8(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant Params&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){wide_gemv_body<4,8>(x,w,b,y,p,group,sg,lane);}
kernel void wide_gemv_9(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant Params&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){wide_gemv_body<8,8>(x,w,b,y,p,group,sg,lane);}
kernel void wide_gemv_10(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant Params&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){wide_gemv_body<16,8>(x,w,b,y,p,group,sg,lane);}
