from pathlib import Path
import subprocess,json,hashlib
v=Path('.venv-lighton-vllm-metal');p=Path('zig/pkg/inference/src/server/executor_microbatch.zig');f=json.loads((v/'engine55-freeze.json').read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()==f[str(p)]
cmd=['/Users/ajroetker/bin/zig-0.17.0/zig','test',str(p),'-OReleaseFast','--cache-dir','zig/.zig-cache','--global-cache-dir','zig/.zig-cache/global','--test-filter','LightOnOCR3 microbatch keeps queued']
with Path('/private/tmp/ocr-engine55-broker-focused.txt').open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
print('focused broker exit',r.returncode);raise SystemExit(r.returncode)
