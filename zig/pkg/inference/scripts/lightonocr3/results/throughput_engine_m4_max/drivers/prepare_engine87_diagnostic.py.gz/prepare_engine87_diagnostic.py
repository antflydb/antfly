from pathlib import Path
import json,hashlib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';s=(v/'engine86_real_ffn_probe.m').read_text();needle='if(fabsf(got[i]-gold[layer][i])>2e-4f+2e-5f*fabsf(gold[layer][i]))return 33;';assert needle in s
s=s.replace(needle,'if(fabsf(got[i]-gold[layer][i])>2e-4f+2e-5f*fabsf(gold[layer][i])){fprintf(stderr,"NAX87 FIRST ERROR rows=%zu layer=%zu trial=%zu i=%zu got=%.9g gold=%.9g abs=%.9g g0=%.9g u0=%.9g act0=%.9g\\n",rows,layer,trial,i,got[i],gold[layer][i],fabsf(got[i]-gold[layer][i]),((float*)b->g.contents+4)[0],((float*)b->u.contents+4)[0],((float*)b->activated.contents+4)[0]);return 33;}')
p=v/'engine87_diagnostic.m';assert not p.exists();p.write_text(s)
o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';p=o/'paired71_4b_comparison_audit.json';d=json.loads(p.read_text());assert d['status']=='running'and not d['comparisons']and not d['reference_candidates'];d.update(status='failed_pre_primary_probe',reason='Private NAX prototype exceeds full-output numerical bound before any actual vLLM or native primary model load. All primary profiles/timings remain unmeasured.',probe_audit='engine87_nax_probe_audit.json');p.write_text(json.dumps(d,indent=2)+'\n')
s=(v/'run_engine85_primary71.py').read_text().replace('paired71','paired73').replace('reference71','reference73').replace('PRIMARY71','PRIMARY73');a=s.index("print('START ISOLATED NAX PROBE BEFORE");b=s.index('r0=reference_sweep',a);s=s[:a]+s[b:]
p=v/'run_engine85_primary73.py';assert not p.exists();p.write_text(s)
