from pathlib import Path
import gzip,hashlib,json
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');raw=p.read_bytes();v=Path('.venv-lighton-vllm-metal');(v/'head_all_rows_baseline_kernels.m.gz').write_bytes(gzip.compress(raw,mtime=0));(v/'head_all_rows_baseline_build.json').write_text(json.dumps({'source_sha256':hashlib.sha256(raw).hexdigest(),'binary_sha256':hashlib.sha256((v/'head_all_rows_probe').read_bytes()).hexdigest(),'rollback_flag':'TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_MPP=1'},indent=2)+'\n')
s=raw.decode();old='''    if (rows < 9 || rows > 16 || !head || !termite_metal_lightonocr3_fast_projections(r) ||''';assert old in s;s=s.replace(old,'''    const bool projection = rows >= 9 && rows <= 16 && r->active_frame_cb != nil &&
        r->active_frame_regime == TERMITE_METAL_FRAME_REGIME_DECODE && (
        (in == 1024 && (out == 3584 || out == 4096 || out == 6144 || (out == 2048 && rows >= 13))) ||
        (in == 2560 && (out == 4096 || out == 8192 || out == 9216)) ||
        (in == 4096 && out == 2560 && rows >= 13) || (in == 2048 && out == 1024 && rows == 16));
    if (rows < 9 || rows > 16 || (!head && !projection) || !termite_metal_lightonocr3_fast_projections(r) ||''',1)
s=s.replace('''    const size_t variant = 2, columns = 64, threads = 128;''','''    const size_t variant = head || (in == 2560 && out == 8192) ? 2 :
        (in == 1024 && out == 3584) || (in == 2560 && out == 9216) ? 1 : 0;
    const size_t columns = variant == 2 ? 64 : variant == 1 ? 16 : 8;
    const size_t threads = variant == 2 ? 128 : 32;''',1)
p.write_text(s)
