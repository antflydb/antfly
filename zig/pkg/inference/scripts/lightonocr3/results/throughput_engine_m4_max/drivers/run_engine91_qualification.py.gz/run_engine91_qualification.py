from pathlib import Path
import hashlib,json,os,subprocess,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=json.loads((v/'engine91-freeze.json').read_text());assert all(sha(r/p)==h for p,h in f.items())
phases=[('image',['/Users/ajroetker/bin/zig-0.17.0/zig','build','lib-image-test','-Doptimize=ReleaseFast'],r/'zig'),('c-build',[sys.executable,str(v/'build_engine91_conformance.py')],r),('c-qualification',[sys.executable,str(v/'run_engine91_c_qualification.py')],r),('focused-ffn',[sys.executable,str(v/'run_engine91_focused_ffn.py')],r),('gpu',[sys.executable,str(v/'run_engine91_verify3_gpu_build.py')],r),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine91','/private/tmp/ocr-engine91-verify3-gpu-build.txt'],r),('cpu',[sys.executable,str(v/'run_engine91_metal_disabled.py')],r)]
for name,cmd,cwd in phases:
 print('START ENGINE91',name,flush=True)
 with Path('/private/tmp/ocr-engine91-'+name+'-parent.txt').open('w')as log:p=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(r/'zig/.zig-cache/global')))
 print('DONE ENGINE91',name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 assert all(sha(r/p)==h for p,h in f.items())
m=json.loads((o/'engine91_build_manifest.json').read_text());os.link(m['binary_path'],v/'qualified-binaries/engine91-test');assert sha(v/'qualified-binaries/engine91-test')==m['binary_sha256']
old=json.loads((o/'engine80_c_build_manifest.json').read_text());inputs={p:sha(r/p)for p in old['input_sha256']};a=o/'engine91_c_build_manifest.json';assert not a.exists();a.write_text(json.dumps(dict(binary=str((v/'engine91_conformance').relative_to(r)),binary_sha256=sha(v/'engine91_conformance'),input_sha256=inputs,compiler_driver_sha256=sha(v/'build_engine91_conformance.py'),qualification_driver_sha256=sha(v/'run_engine91_c_qualification.py'),scope='Fresh20C suites including canceled/active/submitted producer teardown and weak staging-buffer/pipeline/MPS-plan lifetimes; fresh6-length packed FFN checks. No prior-C qualification reuse.'),indent=2)+'\n')
print('ENGINE91 QUALIFICATION DONE',flush=True)
