from pathlib import Path
import subprocess,sys,time,json,hashlib
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
def run(name,cmd):
 p=Path('/private/tmp/ocr-engine57-'+name+'-driver.txt');assert not p.exists(),p
 print('START',name,flush=True)
 with p.open('w')as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True);assert r.returncode==0,(name,r.returncode)
print('WAIT native Metal build',flush=True)
p=Path('/private/tmp/ocr-engine57-verify-gpu-build-driver.txt')
while True:
 s=p.read_text()if p.exists()else''
 if 'qualified retained vision packing workspace counters'in s:break
 if 'exit 1'in s or'Traceback'in s:raise RuntimeError('native Metal build/check failure')
 time.sleep(3)
run('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine57','/private/tmp/ocr-engine57-verify-gpu-build.txt'])
print('WAIT Metal-disabled build',flush=True)
p=Path('/private/tmp/ocr-engine57-metal-disabled-driver.txt')
while True:
 s=p.read_text()if p.exists()else''
 if 'Metal-disabled exit 0'in s:break
 if 'Metal-disabled exit 1'in s or'Traceback'in s:raise RuntimeError('Metal-disabled build/check failure')
 time.sleep(3)
m=json.loads((o/'engine56_c_build_manifest.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(p)==h for p,h in m['input_sha256'].items())
assert json.loads((o/'engine56_c_qualification_audit.json').read_text())['status']=='pass'
assert json.loads((o/'engine57_metal_enabled_source_equivalence_audit.json').read_text())['status']=='pass'
(o/'engine57_c_qualification_reuse_audit.json').write_text(json.dumps(dict(status='pass',c_suites=16,source='engine56',input_sha256=m['input_sha256'],source_build_manifest_sha256=sha(o/'engine56_c_build_manifest.json'),reason='Every C/header/checker input remains byte-identical. Only CPU fallback declarations changed; Metal-enabled implementation prefix is also byte-identical.'),indent=2)+'\n')
run('license-headers',[sys.executable,'scripts/license_headers.py','--check'])
run('apache-boundary',[sys.executable,'scripts/check_apache_boundary.py'])
ns={};a=(v/'archive_engine10_evidence.py').read_text();exec(a[:a.index("archive('qualification'")],ns)
ns['archive']('qualification',list(Path('/private/tmp').glob('ocr-engine57-*.txt')),'logs_manifest.json')
# All own compilers have exited before any primary throughput timing starts.
run('paired29',[sys.executable,str(v/'run_engine57_paired29.py'),'4b'])
for p,h in json.loads((v/'engine57-freeze.json').read_text()).items():assert sha(p)==h,p
ns['archive']('qualification',list(Path('/private/tmp').glob('ocr-engine57-*.txt')),'logs_manifest.json')
print('PAIR COMPLETE',flush=True)
