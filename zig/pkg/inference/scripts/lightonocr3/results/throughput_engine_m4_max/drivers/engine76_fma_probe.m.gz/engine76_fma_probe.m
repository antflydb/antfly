#define main engine76_unused_main
#include "engine76_probe_checks.m"
#undef main
#include "engine76_sources.inc"
int main(int argc,char**argv){@autoreleasepool{
 if(argc!=2)return 1;engine76_variant=(unsigned)strtoul(argv[1],NULL,10);if(engine76_variant<1||engine76_variant>2)return 2;
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 3;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 unsetenv("TERMITE_METAL_DISABLE_QWEN35_PREFILL_COLUMNS");setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY","1",1);
 MTLCompileOptions*opt=[MTLCompileOptions new];opt.languageVersion=MTLLanguageVersion3_1;opt.fastMathEnabled=NO;opt.mathMode=MTLMathModeSafe;NSError*err=nil;
 id<MTLLibrary>lib=[r->device newLibraryWithSource:engine76_sources[engine76_variant-1] options:opt error:&err];if(!lib){fprintf(stderr,"%s\n",err.localizedDescription.UTF8String);return 4;}
 engine76_base=r->qwen35_recurrent_columns4_pipeline;engine76_candidate=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"engine76_fma%u",engine76_variant]);if(!engine76_base||!engine76_candidate)return 5;
 const size_t lengths[]={128,432,554,662,2048};
 for(size_t h=16;h<=32;h+=16)for(size_t i=0;i<5;i++)for(size_t initialized=0;initialized<2;initialized++){
  if(prefill_core_check(r,lengths[i],h,initialized,true))return 6;
 }
 fprintf(stderr,"FMA PROBE PASS candidate=%u\n",engine76_variant);termite_metal_decode_runtime_destroy(r);return 0;
}}
