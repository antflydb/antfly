from pathlib import Path
import os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
for model in sys.argv[1:]or['08']:
 assert model in ['08','4b']
 c=16 if model=='08'else 32
 refs=[p for p in out.glob('vllm_'+model+'_primary_reference10_r0_auto_c*_r128/report.json')]
 if refs:
  import json
  best=max(refs,key=lambda p:json.loads(p.read_text())['results'][0]['pages_per_second']);oracle=best.parent.name.removeprefix('vllm_'+model)
 else:oracle='_primary_reference9_loadcheck_auto_c32_r128'if model=='4b'else'_primary_reference7_auto_c32_r128'
 for stream,single in [(12,0),(16,0),(0,1)]:
  env=os.environ.copy();env.update(OCR_REFERENCE_LABEL=oracle,OCR_CONCURRENCY=str(c),OCR_PHYSICAL32='0'if model=='08'else'1',OCR_REQUESTS='128',OCR_WIDE='1',OCR_SCRATCH_GIB='8'if model=='08'else'10',OCR_BACKEND_GIB='16'if model=='08'else'17',OCR_CPU_PREPROCESS='1',OCR_VISION_FRAME_BLOCKS='4',OCR_BF16='0',OCR_BF16_PREFILL='0'if model=='08'else'1',OCR_SHARED_CORE='0'if model=='08'else'1',OCR_STREAM_FIRST=str(stream),OCR_SINGLE_FRAME=str(single),OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_VISION_BATCH='0')
  label=f'nohook_c{c}_cpu1_vision4_cache'+('0'if model=='08'else'1')+f'_stream{stream}_sf{single}_f32_r128_0'
  print('START',model,label,flush=True);r=subprocess.run([sys.executable,str(v/'run_engine30_budget_no_prefill_policies.py'),model+':'+label],env=env);print('DONE',model,label,r.returncode,flush=True)
  if r.returncode:sys.exit(r.returncode)
