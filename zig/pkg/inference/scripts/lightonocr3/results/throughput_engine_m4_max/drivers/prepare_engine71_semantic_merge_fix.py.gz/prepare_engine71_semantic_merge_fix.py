from pathlib import Path
import hashlib,json,subprocess
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();f=json.loads((v/'engine71-freeze.json').read_text())
for p,h in f.items():assert sha(r/p)==h,p
(v/'engine71-before-merge-fix-freeze.json').write_text(json.dumps(f,indent=2)+'\n')
p=r/'zig/pkg/inference/src/server/server.zig';s=p.read_text();(v/'engine71-before-merge-fix-server.zig').write_text(s)
assert s.count('isQwen3VlReadModel(')==1;s=s.replace('!isQwen3VlReadModel(&manifest)','!isGenerativeReadModel(&manifest)')
a=s.index('test "LightOnOCR3 read routing preserves image-only and grounding prompts"');b=s.index('\ntest ',a+1);part=s[a:b]
anchor='    try std.testing.expect(isGenerativeReadModel(&manifest));';assert part.count(anchor)==1
part=part.replace(anchor,anchor+'\n    try std.testing.expect(Node.runtimeManifestMatchesTask(null, .reader, &manifest));\n    try std.testing.expectEqual(Node.runtimeTaskBit(.reader), Node.runtimeManifestTaskMask(&manifest));')
anchor='    try std.testing.expect(!isGenerativeReadModel(&manifest));';assert part.count(anchor)==1
part=part.replace(anchor,anchor+'\n    try std.testing.expect(!Node.runtimeManifestMatchesTask(null, .reader, &manifest));\n    try std.testing.expectEqual(Node.runtimeTaskBit(.generator), Node.runtimeManifestTaskMask(&manifest));')
p.write_text(s[:a]+part+s[b:]);subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt',str(p)],check=True)
(v/'engine71-freeze.json').write_text(json.dumps({p:sha(r/p)for p in f},indent=2)+'\n');print('corrected model-instance reader dispatch and extended existing runtime-task regression; refrozen44')
