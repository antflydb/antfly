from pathlib import Path
import hashlib,json

root=Path.cwd();v=root/'.venv-lighton-vllm-metal'
for p,h in json.loads((v/'engine64-freeze.json').read_text()).items():
    assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p

def edit(path, fn):
    p=root/path
    (v/('engine64-before65-'+p.name)).write_bytes(p.read_bytes())
    old=p.read_text();new=fn(old);assert old!=new,path;p.write_text(new)

def generation(s):
    s=s.replace('gpu_token_burst_lighton_decode: bool = false,','gpu_token_burst_lighton_decode: bool = false,\n    gpu_token_burst_width: u8 = 2,')
    s=s.replace('return self.acceptTokens(&.{token}, false);','return self.acceptTokens(&.{token}, 0);')
    s=s.replace('tokens: []const u32, first_reserved: bool','tokens: []const u32, reserved: usize')
    s=s.replace('tokens.len > 2 or (first_reserved and tokens.len != 2)','tokens.len > 4 or (reserved != 0 and reserved != tokens.len - 1)')
    s=s.replace('if (!first_reserved or index != 0)', 'if (index >= reserved)')
    s=s.replace('// Publish both accepted outputs while the work is still borrowed;', '// Publish every accepted output while the work is still borrowed;')
    s=s.replace('second_greedy_tokens: ?[]u32 = null,','// Additional outputs, step-major: (steps - 1) * cohort rows.\n        second_greedy_tokens: ?[]u32 = null,')
    a=s.index('    /// Both GPU steps complete before publishing either result.')
    b=s.index('\n    fn forwardScheduledStep(',a)
    s=s[:a]+'''    /// All GPU steps drain before publication. Only one submitted and one
    /// active frame exist at a time. Two logits banks are reused in order;
    /// the cohort's independent page states stay borrowed for the whole burst.
    fn finishLightOnGpuTokenBurst(
        self: *NativeGenerationPipeline,
        claimed: []const runtime.scheduler.native_generate.StepItem,
        items: []MixedBatchDecodeItem,
        first_logits: ops.CT,
        head: ops.CT,
        embedding_slot: usize,
        steps: usize,
        before_frames: u64,
        before_argmax: u64,
    ) !StepForwardResult {
        if (comptime !build_options.enable_metal) return error.UnsupportedOperation;
        if (steps < 2 or steps > 4) return error.InvalidBatchDecodeState;
        const M = @import("../ops/metal_compute.zig").MetalCompute;
        const first = try self.allocator.alloc(u32, claimed.len);
        errdefer self.allocator.free(first);
        const rest = try self.allocator.alloc(u32, (steps - 1) * claimed.len);
        errdefer self.allocator.free(rest);
        var second_logits: ?ops.CT = null;
        var previous_hidden: ?ops.CT = null;
        defer {
            // No resource or page borrow can retire before its producer.
            self.cb.decoderRuntimeWaitSubmittedFrame() catch {};
            if (previous_hidden) |hidden| self.cb.free(hidden);
            if (second_logits) |logits| self.cb.free(logits);
        }
        try M.encodeLightOnBurstArgmax(&self.cb, first_logits, claimed.len, self.gpt_config.vocab_size, self.gpt_config.suppressTokenIds());
        try self.cb.decoderRuntimeSubmitFrame();
        for (1..steps) |step| {
            if (!try self.cb.decoderRuntimeBeginFrame()) return error.StreamedForwardFrameUnavailable;
            try self.cb.decoderRuntimeSetActiveFrameRegime(.decode);
            if (!try self.cb.decoderRuntimeBeginPlannedComputeScope()) return error.StreamedForwardFrameUnavailable;
            M.noteLightOnTokenEncoderScope(&self.cb);
            for (items) |*item| {
                // Eligibility reserved all outputs in the request's original
                // max_tokens allowance. Only metadata is advanced on the CPU.
                try item.state.appendGeneratedToken();
                item.total_sequence_len += 1;
                var decode = BorrowedDecodeStateRuntime.init(item.state);
                const next = decode.makeDecodeContext(item.total_sequence_len, 1);
                item.kv_sequence_len = next.kv_sequence_len;
                item.kv_position_offset = next.kv_position_offset;
            }
            const metadata_bytes = 64 * (@sizeOf(gpt_arch.DecodeContext.KvBatchView) + @sizeOf(?*gpt_arch.Qwen35LinearCache) + 3 * @sizeOf(u32)) + 128;
            var metadata: [metadata_bytes]u8 align(@alignOf(gpt_arch.DecodeContext.KvBatchView)) = undefined;
            var fba = std.heap.FixedBufferAllocator.init(&metadata);
            var owned = try buildOwnedMixedBatchDecodeContext(fba.allocator(), items);
            defer owned.deinit();
            owned.context.prepared_lighton_decode = true;
            try self.cb.checkExecutionControl();
            const embedded = try M.lightOnBurstEmbedding(&self.cb, embedding_slot, claimed.len, self.gpt_config.hidden_size);
            const hidden = try gpt_arch.forwardFinalHiddenTensorFromEmbeddingsWithLayer0Overrides(&self.cb, self.allocator, self.gpt_config, embedded, .{}, claimed.len, 1, &owned.context, null);
            // The current hidden must survive an encoding error too. The C
            // frame retains encoded resources until cancel/drain.
            defer self.cb.free(hidden.hidden);
            if (second_logits == null) {
                second_logits = try self.cb.linearNoBias(hidden.hidden, head, claimed.len, self.gpt_config.hidden_size, self.gpt_config.vocab_size);
            } else {
                // The bank from step-2 has completed before this frame began.
                // No additional vocabulary-sized allocation as width grows.
                const output = if (step % 2 == 0) first_logits else second_logits.?;
                try M.lightOnBurstHeadInto(&self.cb, hidden.hidden, head, output, claimed.len, self.gpt_config.hidden_size, self.gpt_config.vocab_size);
            }
            const logits = if (step % 2 == 0) first_logits else second_logits.?;
            try M.encodeLightOnBurstArgmax(&self.cb, logits, claimed.len, self.gpt_config.vocab_size, self.gpt_config.suppressTokenIds());
            // Copy the previous token buffer before the next producer may
            // overwrite it. GPU embedding already captured its dependency.
            try self.cb.decoderRuntimeWaitSubmittedFrame();
            const output_tokens = if (step == 1) first else rest[(step - 2) * claimed.len ..][0..claimed.len];
            try M.readLightOnBurstTokens(&self.cb, output_tokens);
            if (previous_hidden) |old| self.cb.free(old);
            previous_hidden = null;
            try self.cb.decoderRuntimeSubmitFrame();
        }
        try self.cb.decoderRuntimeWaitSubmittedFrame();
        try M.readLightOnBurstTokens(&self.cb, rest[(steps - 2) * claimed.len ..][0..claimed.len]);
        try self.cb.checkExecutionControl();
        M.noteLightOnBurst(&self.cb, self.cb.debugTimingSnapshot().provider.decoder_runtime_frame_submits -| before_frames, M.argmaxOnFrameCount(&self.cb) -| before_argmax, steps, claimed.len);
        return .{ .logits = null, .greedy_tokens = first, .second_greedy_tokens = rest, .max_query_seq_len = 1 };
    }
''' +s[b:]
    # Keep each successful hidden CT until its producer has drained, including
    # across the next loop's encoding. No pool retirement while in flight.
    s=s.replace('            defer self.cb.free(hidden.hidden);', '            var hidden_owned = true;\n            defer if (hidden_owned) self.cb.free(hidden.hidden);')
    s=s.replace('            try self.cb.decoderRuntimeSubmitFrame();\n        }\n        try self.cb.decoderRuntimeWaitSubmittedFrame();', '            try self.cb.decoderRuntimeSubmitFrame();\n            previous_hidden = hidden.hidden;\n            hidden_owned = false;\n        }\n        try self.cb.decoderRuntimeWaitSubmittedFrame();')
    s=s.replace('var burst_slot: ?usize = null;','var burst_slot: ?usize = null;\n                    var burst_steps: usize = std.math.clamp(@as(usize, self.gpu_token_burst_width), 2, 4);')
    old='''                            if (sequence.generated >= sequence.max_tokens or sequence.max_tokens - sequence.generated < 2 or
                                sequence.seq_len.* > sequence.token_ids.len or sequence.token_ids.len - sequence.seq_len.* < 2) break :eligible false;'''
    new=old+'''
                            burst_steps = @min(burst_steps, @min(sequence.max_tokens - sequence.generated, sequence.token_ids.len - sequence.seq_len.*));'''
    assert old in s;s=s.replace(old,new)
    s=s.replace('logits, head, slot, before_frames, before_argmax);','logits, head, slot, burst_steps, before_frames, before_argmax);')
    s=s.replace('''                        sequence.acceptTokens(&.{ token, second[row] }, true) catch |err| {''','''                        const count = 1 + second.len / claimed.len;
                        if (second.len % claimed.len != 0 or count < 2 or count > 4) {
                            work.failure = error.InvalidBatchDecodeState;
                            work.ready.store(true, .release);
                            continue;
                        }
                        var choices: [4]u32 = undefined;
                        choices[0] = token;
                        for (1..count) |step| choices[step] = second[(step - 1) * claimed.len + row];
                        sequence.acceptTokens(choices[0..count], count - 1) catch |err| {''')
    s=s.replace('test "LightOnOCR3 GPU token burst publishes pairs once with EOS length cancellation and KV accounting" {', 'test "LightOnOCR3 GPU token burst publishes widths two through four with EOS length cancellation and KV accounting" {')
    a=s.index('    // First EOS, second EOS, exact length, continuing pair, cancellation before')
    b=s.index('\n}',a)+2
    t=s[a:b]
    t=t.replace('for (0..6) |scenario| {','for (2..5) |width| {\n    for (0..8) |scenario| {')
    t=t.replace('if (scenario == 4) 1 else if (scenario == 5) 2 else 100', 'if (scenario == 4) 1 else if (scenario == 5) 2 else if (scenario == 7) width else 100')
    t=t.replace('.max_tokens = if (scenario == 2) 3 else 8,','.max_tokens = if (scenario == 2) 1 + width else 8,')
    t=t.replace('// The encoder reserved the first sampled output to run step two.\n        try state.appendGeneratedToken();', '// Reserve every sampled output consumed by a subsequent GPU step.\n        for (1..width) |_| try state.appendGeneratedToken();')
    t=t.replace('const second: u32 = if (scenario == 1) 99 else 12;', 'var second: [3]u32 = .{12,13,14};\n        if (scenario == 1) second[width - 2] = 99;\n        if (scenario == 6) second[width / 2 - 1] = 99;')
    t=t.replace('.second_greedy_tokens = &.{second},','.second_greedy_tokens = second[0 .. width - 1],')
    t=t.replace('if (scenario == 0 or scenario == 4) 0 else if (scenario == 1 or scenario == 5) 1 else 2;', 'if (scenario == 0 or scenario == 4) 0 else if (scenario == 1 or scenario == 7) width - 1 else if (scenario == 5) 1 else if (scenario == 6) width / 2 else width;')
    t=t.replace('@as(usize, if (accepted == 2) 8 else 7)', '@as(usize, 6 + width - 1 + @intFromBool(accepted == width))')
    t=t.replace('if (accepted > 0) try std.testing.expectEqual(@as(i64, 11), tokens[6]);\n        if (accepted == 2) try std.testing.expectEqual(@as(i64, 12), tokens[7]);', 'for (0..accepted) |i| try std.testing.expectEqual(@as(i64, @intCast(11 + i)), tokens[6 + i]);')
    t=t.replace('@as(usize, 8), step.items[0].total_sequence_len', '@as(usize, 6 + width), step.items[0].total_sequence_len').replace('@as(usize, 8), step.items[0].kv_sequence_len', '@as(usize, 6 + width), step.items[0].kv_sequence_len')
    t=t.replace('if (scenario >= 4)', 'if (scenario == 4 or scenario == 5 or scenario == 7)').replace('if (scenario < 2)', 'if (scenario < 2 or scenario == 6)')
    t=t[:-2]+'\n    }\n}'
    s=s[:a]+t+s[b:]
    return s

def compute(s):
    a=s.index('    pub fn encodeLightOnBurstArgmax(')
    s=s[:a]+'''    /// Reuse a completed logits bank without a temporary or CPU fallback.
    pub fn lightOnBurstHeadInto(cb: *const ops.ComputeBackend, input: CT, weight: CT, output: CT, rows: usize, dim: usize, vocab: usize) !void {
        if (cb.kind() != .metal or !cb.decoderRuntimeHasActiveFrame() or rows < 2 or rows > 64 or
            (dim != 1024 and dim != 2560) or vocab != 248320) return error.ResidentImageOperationUnavailable;
        if (!try linearNoBiasIntoOp(cb.ptr, input, weight, output, rows, dim, vocab)) return error.ResidentImageOperationUnavailable;
    }

''' +s[a:]
    s=s.replace('lighton_gpu_token_bursts: u64 = 0,','lighton_gpu_token_bursts: u64 = 0,\n    lighton_gpu_token_burst_extra_steps: u64 = 0,\n    lighton_gpu_token_burst_extra_rows: u64 = 0,\n    lighton_gpu_token_burst_max_width: u64 = 0,')
    s=s.replace('self.lighton_gpu_token_bursts = 0;', 'self.lighton_gpu_token_bursts = 0;\n        self.lighton_gpu_token_burst_extra_steps = 0;\n        self.lighton_gpu_token_burst_extra_rows = 0;\n        self.lighton_gpu_token_burst_max_width = 0;')
    s=s.replace('pub fn noteLightOnBurst(cb: *const ops.ComputeBackend, frames: u64, argmaxes: u64) void {','pub fn noteLightOnBurst(cb: *const ops.ComputeBackend, frames: u64, argmaxes: u64, width: usize, rows: usize) void {')
    s=s.replace('self.lighton_gpu_token_burst_mismatches += @intFromBool(frames != 2 or argmaxes != 2);','''self.lighton_gpu_token_burst_mismatches += @intFromBool(width < 2 or width > 4 or frames != width or argmaxes != width);
        self.lighton_gpu_token_burst_extra_steps += width - 1;
        self.lighton_gpu_token_burst_extra_rows += (width - 1) * rows;
        self.lighton_gpu_token_burst_max_width = @max(self.lighton_gpu_token_burst_max_width, width);''')
    a=s.index('    pub fn lightOnBurstStats(');b=s.index('\n    pub fn lightOnSingleFrameStats(',a)
    s=s[:a]+'''    pub fn lightOnBurstStats(cb: *const ops.ComputeBackend) [5]u64 {
        if (cb.kind() != .metal) return @splat(0);
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return .{ self.lighton_gpu_token_bursts, self.lighton_gpu_token_burst_mismatches, self.lighton_gpu_token_burst_extra_steps, self.lighton_gpu_token_burst_extra_rows, self.lighton_gpu_token_burst_max_width };
    }
''' +s[b:]
    return s

def server(s):
    s=s.replace('gpu_token_burst: bool = false,','gpu_token_burst: bool = false,\n            gpu_token_burst_width: u8 = 2,')
    s=s.replace('                features.stream_chunks = features.gpu_greedy_stream', '                features.gpu_token_burst_width = @intCast(std.math.clamp(platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_GPU_TOKEN_BURST_WIDTH") orelse 2, 2, 4));\n                features.stream_chunks = features.gpu_greedy_stream')
    s=s.replace('@as([2]u64, @splat(0));\n                    std.debug.print("LIGHTONOCR3 gpu_token_burst_enabled=', '@as([5]u64, @splat(0));\n                    std.debug.print("LIGHTONOCR3 gpu_token_burst_enabled=')
    needle='.{ @intFromBool(ctx.features.gpu_token_burst), burst[0], burst[1] });'
    assert needle in s;s=s.replace(needle,needle+'''\n                    std.debug.print("LIGHTONOCR3 gpu_token_burst_extra_steps={d} gpu_token_burst_extra_rows={d} gpu_token_burst_max_width={d}\\n", .{ burst[2], burst[3], burst[4] });''')
    s=s.replace('.gpu_token_burst_lighton_decode = ctx.features.gpu_token_burst,','.gpu_token_burst_lighton_decode = ctx.features.gpu_token_burst,\n            .gpu_token_burst_width = ctx.features.gpu_token_burst_width,')
    # A third hidden/embedding can coexist while encoding the next frame.
    # Four MiB covers both rounded allocations at the largest admitted shape.
    s=s.replace('                return amounts;\n            }\n            fn needsAuxiliary', '                if (features.gpu_token_burst and features.gpu_token_burst_width > 2) amounts.backend_scratch_bytes += 4 * 1024 * 1024;\n                return amounts;\n            }\n            fn needsAuxiliary')
    return s

def checks(s):
    s=s.replace('gpu_token_burst_check(termite_metal_decode_runtime *r)', 'gpu_token_burst_check(termite_metal_decode_runtime *r, size_t width)')
    s=s.replace('for(size_t t=7;t<=13;t+=6)for(size_t d=0;d<dim;d++)', 'for(size_t t=7;t<=23;t++)for(size_t d=0;d<dim;d++)')
    a=s.index('            if(antfly_metal_lighton_embed_tokens(r,slot,rows,dim,(__bridge void*)embed,16)||')
    b=s.index('            // Cancel an encoded, unsubmitted argmax;',a)
    s=s[:a]+'''            for(size_t step=1;step<width;step++) {
                // Step one already owns an active frame. Thereafter retain one
                // submitted producer while encoding its successor.
                if(step>1 && (termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_OTHER,TERMITE_METAL_COMPUTE_REGION_OTHER)))return 170;
                id<MTLBuffer> next=(step%2)?later:source;
                if(antfly_metal_lighton_embed_tokens(r,slot,rows,dim,(__bridge void*)embed,16)||
                    termite_metal_buffer_slice_last_dim_2d(r,(__bridge void*)next,0,1,rows*vocab,0,rows*vocab,(__bridge void*)logits,0)||
                    termite_metal_decode_runtime_argmax_from_logits_rows_suppress_device(r,(__bridge void*)logits,0,rows,vocab,NULL,0,&unused,2)||
                    termite_metal_decode_runtime_wait_frame(r)||antfly_metal_lighton_read_tokens(r,first,rows))return 161;
                for(size_t row=0;row<rows;row++) {
                    uint32_t previous=((step-1)%2)?(row%2?23:21):(row%2?13:7);
                    if(first[row]!=previous)return 162;
                    if(step>1)for(size_t d=0;d<dim;d++) {
                        uint32_t input=((step-2)%2)?(row%2?23:21):(row%2?13:7);
                        float expected=(float)(input*2+(d%17))/8;
                        if(out[4+row*dim+d]!=expected)return 165;
                    }
                }
                if(termite_metal_decode_runtime_submit_frame(r))return 163;
            }
            if(termite_metal_decode_runtime_wait_frame(r)||antfly_metal_lighton_read_tokens(r,second,rows))return 163;
            for(size_t row=0;row<rows;row++) {
                uint32_t final=((width-1)%2)?(row%2?23:21):(row%2?13:7);
                uint32_t input=((width-2)%2)?(row%2?23:21):(row%2?13:7);
                if(second[row]!=final)return 164;
                for(size_t d=0;d<dim;d++){float expected=(float)(input*2+(d%17))/8;if(out[4+row*dim+d]!=expected)return 165;}
            }
            for(size_t i=0;i<4;i++)if(out[i]!=-999||out[4+rows*dim+i]!=-999)return 166;
            for(size_t i=rows;i<rows+4;i++)if(tokens[i]!=0x1234abcd)return 167;
''' +s[b:]
    s=s.replace('two_frames=pass gpu_tokens=pass', 'frames=%zu gpu_tokens=pass').replace('cancel=pass\\n",dim,rows);', 'cancel=pass\\n",dim,rows,width);')
    s=s.replace('int rc=gpu_token_burst_check(r);','int rc=gpu_token_burst_check(r,2);')
    a=s.index('        if (argc == 2 && strcmp(argv[1], "--check-gpu-token-burst") == 0)')
    s=s[:a]+'''        if (argc == 2 && strcmp(argv[1], "--check-gpu-token-burst-long") == 0) {
            int rc=gpu_token_burst_check(r,3);
            if(!rc)rc=gpu_token_burst_check(r,4);
            termite_metal_decode_runtime_destroy(r);
            return rc;
        }
''' +s[a:]
    return s

edit('zig/pkg/inference/src/pipelines/generation.zig', generation)
edit('zig/pkg/inference/src/ops/metal_compute.zig', compute)
edit('zig/pkg/inference/src/server/server.zig', server)
edit('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m', checks)
print('Engine65 proposal applied; unqualified')
