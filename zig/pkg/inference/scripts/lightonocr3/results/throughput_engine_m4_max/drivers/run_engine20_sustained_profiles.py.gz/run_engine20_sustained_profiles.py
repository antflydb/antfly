from pathlib import Path
import os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');base=os.environ.copy();base.update(OCR_CONCURRENCY='16',OCR_REQUESTS='128',OCR_WIDE='1',OCR_SCRATCH_GIB='8',OCR_STREAM_FIRST='0',OCR_SINGLE_FRAME='0',OCR_POLICIES='engineepoch')
for model,shared,prefill in [('08','0','0'),('4b','1','1')]:
 env=base.copy();env.update(OCR_SHARED_CORE=shared,OCR_BF16_PREFILL=prefill)
 cmd=[sys.executable,str(v/'run_engine20_policies.py'),model+':gate_events_epoch256_c16_r128_cache'+shared+'_prefill'+prefill+'_0']
 print('START',model,flush=True);res=subprocess.run(cmd,env=env);print('DONE',model,res.returncode,flush=True)
 if res.returncode:sys.exit(res.returncode)
