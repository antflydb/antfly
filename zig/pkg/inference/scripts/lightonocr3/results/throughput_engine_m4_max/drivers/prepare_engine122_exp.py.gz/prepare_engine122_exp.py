from pathlib import Path
import json,re
v=Path('.venv-lighton-vllm-metal');base=(v/'engine120_q16k128s4m16t0.metal').read_text().replace('vision120','vision122')
plans=[]
for ident in ['fast_exp','fast_exp2']:
 if ident=='fast_exp':s=base.replace('exp(','fast::exp(')
 else:
  s,n=re.subn(r'\bexp\(([^()]*)\)',r'fast::exp2((\1)*1.4426950408889634f)',base);assert n==2
 (v/f'engine122_{ident}.metal').write_text(s);plans.append(dict(id=ident,q=16,k=128,sg=4,m=16,fast=1))
(v/'engine122_plans.json').write_text(json.dumps(plans,indent=2)+'\n')
s=(v/'engine120_vision_kernels.m').read_text().replace('engine120_','engine122_');(v/'engine122_vision_kernels.m').write_text(s)
s=(v/'engine120_vision_checks.m').read_text().replace('engine120_','engine122_');(v/'engine122_vision_checks.m').write_text(s)
s=(v/'engine120_vision_probe.m').read_text().replace('engine120_','engine122_').replace('VISION120','VISION122').replace('vision120','vision122').replace('select120','select122');s=s.replace('if(qb==16&&','if(![plan[@"fast"]boolValue]&&qb==16&&');needle='  fprintf(stderr,"VISION122 FULL OUTPUT CPU GUARDS PASS id=%s\\n",ident.UTF8String);';assert needle in s
extra='''  for(size_t h=12;h<=16;h+=4){VisionCheck*c=make_case_heads(r,1,578,h);((float*)c->q.contents)[4+3]=NAN;((float*)c->k.contents)[4+((578/2)*h+5)*64+31]=INFINITY;select122(1,p,qb,threads);run_case(r,c,YES);}
'''
s=s.replace(needle,extra+needle);(v/'engine122_vision_probe.m').write_text(s)
