from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal')
base=Path('zig/pkg/inference/src/backends/metal_kernels.m').read_bytes()
(v/'engine47_bf16_ffn_probe_kernels.m').write_bytes(base)
s=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine47_bf16_ffn_probe_kernels.m"')
(v/'engine47_bf16_ffn_probe_checks.m').write_text(s)
s=(v/'engine44_streamed_ffn_probe.metal').read_text()
assert s.count('device float*x')==6
assert s.count('tensor<device float,dextents<int,2>,tensor_inline>a(x')==6
s=s.replace('device float*x','device bfloat*x').replace('tensor<device float,dextents<int,2>,tensor_inline>a(x','tensor<device bfloat,dextents<int,2>,tensor_inline>a(x')
(v/'engine47_bf16_ffn_probe.metal').write_text(s)
s=(v/'engine44_streamed_ffn_probe.m').read_text().replace('engine44_streamed_ffn_probe','engine47_bf16_ffn_probe').replace('STREAM_FFN','BF16_STREAM_FFN')
needle=' uint64_t before=r->frame_gpu_nanos;size_t dispatches=0;';assert s.count(needle)==1
s=s.replace(needle,''' id<MTLBuffer> packed=p?[r->device newBufferWithLength:rows*in*2 options:MTLResourceStorageModePrivate]:nil;
 if(p&&!packed)return 30;
 uint64_t before=r->frame_gpu_nanos;size_t dispatches=0,pack_dispatches=0;''')
s=s.replace('termite_metal_planned_encoder_range a[6]','termite_metal_planned_encoder_range a[7]')
needle='termite_metal_decode_runtime_prepare_planned_compute_accesses(r,a,6,-1)';assert s.count(needle)==1
s=s.replace(needle,'''termite_metal_planned_range_make(packed,0,rows*in*2,TERMITE_METAL_PLANNED_RANGE_WRITE,&a[6],-1)||
      termite_metal_decode_runtime_prepare_planned_compute_accesses(r,a,7,-1)''')
needle='   [e setComputePipelineState:p];[e setBuffer:x offset:16 atIndex:0];';assert s.count(needle)==1
s=s.replace(needle,'''   uint32_t count=(uint32_t)(rows*in);
   [e setComputePipelineState:r->lightonocr3_pack_bf16_pipeline];
   [e setBuffer:x offset:16 atIndex:0];[e setBuffer:packed offset:0 atIndex:1];
   [e setBytes:&count length:sizeof(count) atIndex:2];
   [e dispatchThreads:MTLSizeMake(count,1,1) threadsPerThreadgroup:MTLSizeMake(termite_metal_thread_width(r->lightonocr3_pack_bf16_pipeline,count),1,1)];
   [e memoryBarrierWithScope:MTLBarrierScopeBuffers];pack_dispatches++;
   [e setComputePipelineState:p];[e setBuffer:packed offset:0 atIndex:0];''')
s=s.replace('if(dispatches!=STREAM_LAYERS)return 5;','if(dispatches!=STREAM_LAYERS||pack_dispatches!=(p?STREAM_LAYERS:0))return 5;')
needle='input[i]=sinf(i*.013f)*.7f;';assert s.count(needle)==1
s=s.replace(needle,'input[i]=expand_bf16(round_bf16(sinf(i*.013f)*.7f));')
needle=' unsetenv("TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS");';assert s.count(needle)==1
s=s.replace(needle,needle+'''
 unsetenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP");
 setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP","1",1);''')
(v/'engine47_bf16_ffn_probe.m').write_text(s)
plan=dict(status='prepared_only_not_compiled_or_run',base_engine='engine45',base_c_sha256=hashlib.sha256(base).hexdigest(),
 scope='Isolated BF16-input fused gate/up probe only; runtime unchanged. BF16 inputs and BF16 weights, F32 accumulators/output and activation. No F16 lowering. Source inputs are exactly BF16 representable so old F32-input generic fusion is the same-math reference. A GPU pack dispatch is still required for every candidate projection and included in GPU timing; it is not omitted merely because the source is BF16 representable.',
 rows=[64,48,33],variants=[0,3,4,5],distinct_weight_pairs=32,ABBA_legs=4,warm_frames_per_leg=2,timed_frames_per_leg=8,
 checks='Full GPU comparison and CPU corners <=2e-4; output canaries/nonzero offsets; private GPU producer, exact 32 pack dispatches in candidate frames and zero baseline. Future full-model use requires an explicit BF16 FFN policy, real dispatch/pack counters, memory admission and full OCR output qualification. No promotion based on this probe alone.')
(v/'engine47-bf16-ffn-probe-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s=(v/'build_engine44_streamed_ffn_probe.py').read_text().replace('engine44_streamed_ffn_probe','engine47_bf16_ffn_probe').replace('engine44-streamed-ffn-probe','engine47-bf16-ffn-probe')
(v/'build_engine47_bf16_ffn_probe.py').write_text(s)
print('Prepared ignored BF16 FFN probe only; do not compile/run during primary timings.')
