from pathlib import Path
import os,subprocess,sys,json,hashlib
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');records=[]
profiles=[('prefill3_workspace',1,3,2,0,0),('vision4_workspace',4,1,1,1,0),('vision4_vf2_workspace',4,1,2,1,0),('combined_workspace',4,3,1,1,0)]
for name,vision,prefill,vf,seal_v,seal_p in profiles:
 label='store56_'+name;env=os.environ.copy();env.update(OCR_CASE_CONCURRENCY='48',OCR_CASE_PREFILL_ITEMS=str(prefill),OCR_CASE_VISION_FRAME_BLOCKS=str(vf),OCR_CASE_VISION_BATCH_ITEMS=str(vision),OCR_CASE_TAG=label,OCR_VISION_WAIT_US='2000',OCR_BATCH_ARGMAX='1',OCR_DEFER_VISION_SEAL=str(seal_v),OCR_DEFER_PREFILL_SEAL=str(seal_p),OCR_CACHE_VISION_WORKSPACE='1',OCR_LARGE_VISION_PACK_REUSE='1',OCR_TIMEOUT='240')
 print('START',label,flush=True)
 with Path('/private/tmp/ocr-engine56-4b-'+label+'-driver.txt').open('w')as log:r=subprocess.run([sys.executable,str(v/'run_engine56_vision4_profile.py'),'4b','0'],env=env,stdout=log,stderr=subprocess.STDOUT)
 print('DONE',label,r.returncode,flush=True)
 p=o/f'engine56_4b_rolling_chunks0_trial0_c48_p{prefill}_vf{vf}_r64_{label}'/'report.json'
 if r.returncode:
  if p.exists():
   d=json.loads(p.read_text());rs=d['results'][0];s=rs.get('policy_rounds',[{}])[0]
   if rs['status']=='ok'and s.get('completed')==64 and s.get('admission_pressures'):
    records.append(dict(profile=name,eligible=False,reason='admission_pressure',events=s['admission_pressures'],report=str(p.relative_to(o))));continue
  raise RuntimeError((label,r.returncode))
 d=json.loads(p.read_text());rs=d['results'][0];s=rs['policy_rounds'][0]
 assert rs['status']=='ok'and rs['serial_reference_parity']and rs['cross_runtime_content_parity']and s['completed']==64 and not s['admission_pressures']
 records.append(dict(profile=name,eligible=True,pages_per_second=s['pages_per_second'],process_cpu_ms=s['process_cpu_ms'],completed=64,vision_batch_sizes=s['vision_batch_sizes'],prefill_batches=s['prefill_batches'],vision_workspace_allocations=s['vision_workspace_allocations'],vision_workspace_reuses=s['vision_workspace_reuses'],vision_workspace_bytes=s['vision_workspace_bytes'],large_vision_pack_calls=s['large_vision_pack_calls'],large_vision_pack_reuse_hits=s['large_vision_pack_reuse_hits'],report=str(p.relative_to(o)),report_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 (o/'engine56_workspace_profiles_audit.json').write_text(json.dumps(dict(status='running',candidates=records),indent=2)+'\n')
(o/'engine56_workspace_profiles_audit.json').write_text(json.dumps(dict(status='pass',candidates=records),indent=2)+'\n')
