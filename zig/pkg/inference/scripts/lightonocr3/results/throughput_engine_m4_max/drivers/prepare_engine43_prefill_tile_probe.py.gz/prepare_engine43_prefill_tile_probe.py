from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal')
s=Path('zig/pkg/inference/src/backends/metal_kernels.m').read_text()
original_sha=hashlib.sha256(s.encode()).hexdigest()
needle='    uint64_t lightonocr3_wide_gate_up_calls;'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n    bool prefill_row64_probe;\n    uint64_t prefill_row64_probe_calls;')
a=s.index('static int termite_metal_try_lightonocr3_mpp(')
b=s.index('\nstatic ',a+10)
part=s[a:b]
needle='    const bool n32 = (in_dim == 4096 && out_dim == 4096) ||'
assert part.count(needle)==1
part=part.replace(needle,'''    const bool probe_prefill64 = runtime->prefill_row64_probe &&
        runtime->active_frame_regime == TERMITE_METAL_FRAME_REGIME_PREFILL &&
        rows >= 128 && rows <= 2048 &&
        ((in_dim == 2560 && out_dim == 9216) || (in_dim == 9216 && out_dim == 2560));
    const bool n32 = probe_prefill64 || (in_dim == 4096 && out_dim == 4096) ||''')
needle='    if (!owned && runtime->active_frame_regime == TERMITE_METAL_FRAME_REGIME_DECODE) {'
# Count the successful candidate dispatch immediately before the function's final finish.
pos=part.rindex('    return ')
part=part[:pos]+'    if (probe_prefill64) runtime->prefill_row64_probe_calls += 1;\n'+part[pos:]
s=s[:a]+part+s[b:]
(v/'engine43_prefill_tile_probe_kernels.m').write_text(s)
s=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine43_prefill_tile_probe_kernels.m"')
(v/'engine43_prefill_tile_probe_checks.m').write_text(s)
(v/'engine43-prefill-tile-probe-plan.json').write_text(json.dumps(dict(scope='Isolated existing M64N32 vs M32N64 BF16 prefill FFN tiles; actual runtime42 unchanged.',base_c_sha256=original_sha,rows=[128,432,554,662,1024],shapes=[[2560,9216],[9216,2560]],ABBA_trials_per_leg=40,input_precision='BF16 packing identical in both modes; CPU corners round input to BF16 before dot.',checks='Actual GPU producer/private input, full GPU reference, independent CPU corners, nonzero offsets/canaries, exact dispatch selection counter.'),indent=2)+'\n')
