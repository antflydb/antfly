#define main production_checks_main
#include "static_extent_candidate_checks.m"
#undef main
int main(void) {
 @autoreleasepool {
  termite_metal_decode_runtime *r=termite_metal_decode_runtime_create();if(!r)return 1;
  termite_metal_decode_runtime_set_lightonocr3_projections(r,1);
  for(size_t i=0;i<4;i++)if(!r->static_extent_gate[i])return 2;
  for(size_t rows=8;rows<=16;rows+=8)for(size_t model=0;model<2;model++){
   size_t in=model?2560:1024,out=model?9216:3584;
   for(size_t trial=0;trial<4;trial++){
    bool enabled=trial==1||trial==2;r->static_extent_gate_enabled=enabled;
    fprintf(stderr,"STATIC_EXTENT rows=%zu model=%zu enabled=%d trial=%zu\n",rows,model,enabled,trial);
    int rc=batch_gate_up_check(r,rows,in,out,true);if(rc){fprintf(stderr,"FAIL rc=%d\n",rc);return rc+10;}
   }
  }
  for(size_t i=0;i<4;i++)r->static_extent_gate[i]=nil;
  termite_metal_decode_runtime_destroy(r);
 }
 return 0;
}
