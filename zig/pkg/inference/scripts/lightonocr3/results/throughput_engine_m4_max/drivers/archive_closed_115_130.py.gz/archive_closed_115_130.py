from pathlib import Path
import hashlib,json,subprocess,sys
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();f=json.loads((v/'engine113-freeze.json').read_text());assert all(sha(Path(p))==h for p,h in f.items())
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
nums=list(range(115,131));logs=sorted(p for n in nums for p in Path('/private/tmp').glob(f'ocr-engine{n}-*')if p.is_file());logs+=sorted(p for n in [124,126,129,131]for p in Path('/private/tmp').glob(f'ocr-engine113-profile{n}-*')if p.is_file());logs+=[Path('/private/tmp/ocr-engine113-primary131-parent.txt')]
ns['archive']('qualification',sorted(set(logs)),'logs_manifest.json')
ps=[p for n in nums for p in v.glob(f'*engine{n}*')if p.is_file()and (p.suffix in ['.py','.json','.m','.inc','.metal']or p.name.endswith('MLX_LICENSE'))];ps += [v/f'run_engine113_profile{n}.py'for n in [124,126,129]]+[v/'audit_private115_128.py',v/'run_engine113_primary131.py',v/'archive_closed_115_130.py'];index=json.loads((o/'drivers/drivers_manifest.json').read_text());paths=[]
for p in sorted(set(ps)):
 h=sha(p);old=index.get(p.name+'.gz')
 if old and old['raw_sha256']!=h:
  q=v/(p.stem+'_closed130_'+h[:10]+p.suffix);assert not q.exists()or q.read_bytes()==p.read_bytes();q.write_bytes(p.read_bytes());paths.append(q)
 else:paths.append(p)
ns['archive']('drivers',paths,'drivers_manifest.json')
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),*[f'engine113_4b_profile{n}*'for n in [124,126,129]]],check=True)
d=dict(status='private_experiments_closed_no_new_runtime_promotion',scope='Qualified compiled runtime remains112/parser113 at451ea2.115-130 are private isolation experiments only; no production code change, no whole-model speed claim. Numerical/compile exclusions kept.131retired before model load;132paired macro is active and not archived here.',canonical_freeze_sha256=sha(v/'engine113-freeze.json'),qualified_manifest_sha256=sha(o/'engine113_build_manifest.json'),reports={p.name:sha(p)for n in nums for p in o.glob(f'engine{n}_*.json')},profile_interpretation_sha256=sha(o/'engine113_profiles124_126_129_interpretation_audit.json'))
(o/'engine130_closed_checkpoint_audit.json').write_text(json.dumps(d,indent=2)+'\n');print('Closed private115-130 archived; active132 untouched')
