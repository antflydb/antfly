from pathlib import Path
import subprocess,sys
r=Path.cwd();binary=r/'.venv-lighton-vllm-metal/engine10_conformance'
for label,args in [('wide-projection-tiles',['--check-wide-projection-tiles']),('wide',['--check-wide']),('full',[])]:
 with open('/private/tmp/ocr-engine10-'+label+'-conformance.txt','w')as log:p=subprocess.run([str(binary),*args],stdout=log,stderr=subprocess.STDOUT)
 print(label,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
