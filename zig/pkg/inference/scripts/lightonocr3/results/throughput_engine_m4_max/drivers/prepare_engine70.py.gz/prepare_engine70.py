from pathlib import Path
import hashlib,json,re
root=Path.cwd();v=root/'.venv-lighton-vllm-metal'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((v/'engine69-freeze.json').read_text())
for p,h in old.items():assert sha(root/p)==h,p
p=root/'zig/pkg/inference/src/backends/metal_kernels.m';s=p.read_text();(v/'engine69-before70-metal_kernels.m').write_text(s)
flags=['DISABLE_LIGHTONOCR3_PARALLEL_NORM','DISABLE_LIGHTONOCR3_PREFILL_NORM','DISABLE_QWEN35_CORE_BATCH','DISABLE_QWEN35_CORE_PARALLEL_NORM','DISABLE_QWEN35_PREFILL_CONV_VEC4','DISABLE_QWEN35_FUSED_DECODE','DISABLE_LIGHTONOCR3_RECURRENT_PARALLEL','TRACE_LIGHTONOCR3_RECURRENT_PARALLEL','DISABLE_LIGHTONOCR3_BATCH_GATE_UP','ENABLE_LIGHTONOCR3_FULL64_GATE_UP','ENABLE_LIGHTONOCR3_WIDE64_GATE_UP','DISABLE_LIGHTONOCR3_WIDE_GATE_UP','DISABLE_QWEN35_PREFILL_COLUMNS','DISABLE_LIGHTONOCR3_PREFILL_CORE_NORM','ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL','ENABLE_LIGHTONOCR3_RECURRENT_COALESCING','ENABLE_LIGHTONOCR3_PREFILL_CORE_NORM']
assert all('TERMITE_METAL_FRAME_'+x not in s for x in flags)
s=s.replace('    TERMITE_METAL_FRAME_ENV_COUNT\n',''.join('    TERMITE_METAL_FRAME_'+x+',\n'for x in flags)+'    TERMITE_METAL_FRAME_ENV_COUNT\n',1)
anchor='    "TERMITE_METAL_ENABLE_LIGHTONOCR3_LARGE_VISION_PACK_REUSE",\n};'
assert anchor in s;s=s.replace(anchor,anchor[:-3]+''.join('    "TERMITE_METAL_'+x+'",\n'for x in flags)+'};\n_Static_assert(TERMITE_METAL_FRAME_ENV_COUNT <= 64, "Frame policy bitset capacity");',1)
# Resolve legacy default-on and serving-preset semantics exactly once per frame.
anchor='static bool termite_metal_frame_env_enabled('
helper='''static bool termite_metal_frame_env_resolve(termite_metal_frame_env_key key) {
    const char *name = termite_metal_frame_env_names[key];
    if (key == TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL ||
        key == TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_PREFILL_CORE_NORM) {
        const char *value = getenv(name);
        return value == NULL || termite_metal_env_flag_enabled(value);
    }
    if (key == TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_RECURRENT_COALESCING)
        return termite_metal_lightonocr3_profile_feature_enabled(name);
    return termite_metal_env_flag_enabled(getenv(name));
}

'''
s=s.replace(anchor,helper+anchor,1)
s=s.replace('return termite_metal_env_flag_enabled(getenv(termite_metal_frame_env_names[key]));','return termite_metal_frame_env_resolve(key);',1)
s=s.replace('if (termite_metal_env_flag_enabled(getenv(termite_metal_frame_env_names[key])))','if (termite_metal_frame_env_resolve(key))',1)
functions=['termite_metal_lightonocr3_prefill_norm_threads','termite_metal_decode_runtime_qwen35_core_batch_begin','termite_metal_qwen35_parallel_norm_available','termite_metal_qwen35_prefill_conv_vec4_available','termite_metal_qwen35_fused_decode_available','termite_metal_lightonocr3_encode_recurrent_parallel','termite_metal_lightonocr3_batch_gate_up_pipeline','termite_metal_decode_runtime_qwen35_core_device']
counts={}
for name in functions:
 match=re.search(r'\b'+name+r'\([^;]*?\)\s*\{',s,re.S);assert match,name
 start=match.start();end=s.index('\n}',match.end())+2
 part=s[start:end];before=part
 for flag in flags+['DISABLE_LIGHTONOCR3_PROJECTIONS','DISABLE_LIGHTONOCR3_BATCH_PROJECTIONS','DISABLE_LIGHTONOCR3_MPP','LIGHTONOCR3_BF16_ACTIVATIONS']:
  expr='termite_metal_env_flag_enabled(getenv("TERMITE_METAL_'+flag+'"))'
  part=part.replace(expr,'termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_'+flag+')')
 for flag in ['ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL','ENABLE_LIGHTONOCR3_PREFILL_CORE_NORM']:
  part=part.replace('termite_metal_lightonocr3_feature_default_enabled("TERMITE_METAL_'+flag+'")','termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_'+flag+')')
 part=part.replace('termite_metal_lightonocr3_profile_feature_enabled("TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_COALESCING")','termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_RECURRENT_COALESCING)')
 assert part!=before,name;counts[name]=part.count('termite_metal_frame_env_enabled(')
 s=s[:start]+part+s[end:]
p.write_text(s)
p=root/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m';s=p.read_text();(v/'engine69-before70-check_metal_projections.m').write_text(s)
helper='''static int frame_policy_refresh_check(termite_metal_decode_runtime *r) {
    const char *names[] = {"TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY",
        "TERMITE_METAL_DISABLE_LIGHTONOCR3_BATCH_GATE_UP",
        "TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL",
        "TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_COALESCING"};
    char *saved[4] = {0};
    for (size_t i = 0; i < 4; ++i) {
        const char *value = getenv(names[i]);
        if (value != NULL) saved[i] = strdup(value);
    }
    int rc = 0;
    setenv(names[0], "1", 1);
    setenv(names[1], "0", 1);
    unsetenv(names[2]); // Default-on remains enabled when absent.
    setenv(names[3], "1", 1);
    if (termite_metal_decode_runtime_begin_frame(r)) { rc = 1; goto done; }
    id<MTLComputePipelineState> before = termite_metal_lightonocr3_batch_gate_up_pipeline(r, 32, 2560, 9216);
    if (before == nil || !termite_metal_frame_env_enabled(r, TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL) ||
        !termite_metal_frame_env_enabled(r, TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_RECURRENT_COALESCING)) { rc = 2; goto done; }
    setenv(names[1], "1", 1); setenv(names[2], "0", 1); setenv(names[3], "0", 1);
    if (termite_metal_lightonocr3_batch_gate_up_pipeline(r, 32, 2560, 9216) != before ||
        !termite_metal_frame_env_enabled(r, TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL) ||
        !termite_metal_frame_env_enabled(r, TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_RECURRENT_COALESCING)) { rc = 3; goto done; }
    if (termite_metal_decode_runtime_submit_frame(r) || termite_metal_decode_runtime_begin_frame(r)) { rc = 4; goto done; }
    if (termite_metal_lightonocr3_batch_gate_up_pipeline(r, 32, 2560, 9216) != nil ||
        termite_metal_frame_env_enabled(r, TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL) ||
        termite_metal_frame_env_enabled(r, TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_RECURRENT_COALESCING)) { rc = 5; goto done; }
    if (termite_metal_decode_runtime_cancel_frame(r) || termite_metal_decode_runtime_wait_frame(r)) { rc = 6; goto done; }
    setenv(names[0], "0", 1); setenv(names[1], "0", 1);
    if (termite_metal_decode_runtime_begin_frame(r)) { rc = 7; goto done; }
    if (termite_metal_frame_env_enabled(r, TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_BATCH_GATE_UP)) { rc = 8; goto done; }
    setenv(names[1], "1", 1);
    if (!termite_metal_frame_env_enabled(r, TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_BATCH_GATE_UP)) rc = 9;
done:
    if (r->active_frame_cb != nil) termite_metal_decode_runtime_cancel_frame(r);
    if (r->submitted_frame_cb != nil) termite_metal_decode_runtime_wait_frame(r);
    for (size_t i = 0; i < 4; ++i) {
        if (saved[i] != NULL) { setenv(names[i], saved[i], 1); free(saved[i]); }
        else unsetenv(names[i]);
    }
    fprintf(stderr, "frame_policy_refresh same_frame=stable next_frame=refreshed rollback=live rc=%d\\n", rc);
    return rc;
}

'''
s=s.replace('static int frame_metadata_check(',helper+'static int frame_metadata_check(',1)
s=s.replace('          int rc = frame_metadata_check(r);','          int rc = frame_policy_refresh_check(r);\n          if (rc == 0) rc = frame_metadata_check(r);',1);p.write_text(s)
(v/'engine70-freeze.json').write_text(json.dumps({p:sha(root/p)for p in old},indent=2)+'\n')
print('applied bounded frame policy extension',counts)
