from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=json.loads((v/'engine48-freeze.json').read_text());assert all(sha(Path(p))==h for p,h in frozen.items())
m=json.loads((out/'engine48_build_manifest.json').read_text());assert sha(Path(m['binary_path']))==m['binary_sha256']
checks=[out/n for n in ['engine48_4b_full64_gate_up_qualification_audit.json','engine48_4b_stream_qualification_audit.json','engine48_08_stream_qualification_audit.json','engine48_florence_batch12_c24_cpu1_r32_qualification_audit.json','engine48_c_qualification_reuse_audit.json']]
assert all(json.loads(p.read_text())['status']=='pass'for p in checks)
log=Path('/private/tmp/ocr-engine48-functional-driver.txt').read_text()
assert all('DONE '+name+' 0' in log for name in ['preset_only_test','preset_physical32_test','default_gpu_test'])
# The prepared orchestrator expected a descriptive alias for the small-model
# stream audit; the canonical driver uses model_stream_qualification_audit.
audit=dict(status='pass',checks=[dict(path=str(p.relative_to(out)),sha256=sha(p)) for p in checks],runtime_files_sha256=frozen,binary_sha256=m['binary_sha256'],
 verification_recovery='Original orchestrator used an incorrect small-model audit filename in its final check. Canonical audit paths verified here; all GPU checks already completed and passed. No runtime changes or GPU reruns.')
p=out/'engine48_full_qualification_audit.json';assert not p.exists();p.write_text(json.dumps(audit,indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
paths=[Path('/private/tmp/ocr-engine48-qualification-driver.txt')]
paths+=list(Path('/private/tmp').glob('ocr-engine48-*-qualification-driver.txt'))
ns['archive']('qualification',paths,'logs_manifest.json')
print('ALL ENGINE48 QUALIFICATION VERIFIED',flush=True)
