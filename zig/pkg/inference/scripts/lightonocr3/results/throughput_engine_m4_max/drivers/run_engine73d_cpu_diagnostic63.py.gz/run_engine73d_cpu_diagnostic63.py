from pathlib import Path
import ast,datetime,hashlib,json,os,signal,subprocess,sys,time
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
primary=json.loads((out/'paired59_4b_comparison_audit.json').read_text());assert primary['status']in['early_stop_forward_loss','native_behind']
profiles=primary['profiles']; selected=profiles['wide']
audit_path=out/'engine73d_cpu_diagnostic63_audit.json'
if '--worker'in sys.argv:
 source=(v/'run_engine71_api_paired59.py').read_text();tree=ast.parse(source);node=next(x for x in tree.body if isinstance(x,ast.FunctionDef)and x.name=='native');fn=ast.get_source_segment(source,node)
 fn=fn.replace('paired59','cpu_diagnostic63').replace('engine71','engine73d').replace("OCR_REQUESTS='128'","OCR_REQUESTS='64'").replace('_r128','_r64').replace('==128','==64').replace('== 128','== 64')
 exec(compile(fn,'extracted_native_diagnostic63','exec'),globals())
 oracle=Path(primary['comparisons'][-1]['reference_report']).parent.name.removeprefix('vllm_4b')
 d,p=native('wide',0,oracle)
 d.update(diagnostic_driver_sha256=sha(Path(__file__)),extracted_native_source_sha256=hashlib.sha256(fn.encode()).hexdigest(),own_profiling_overlap=True,primary_throughput_eligible=False,diagnostic_scope='Separate sampled CPU diagnostic: R64, exact outputs, original caps. Never use this sampled rate as a primary throughput comparison.')
 p.write_text(json.dumps(d,indent=2)+'\n')
 print('DIAGNOSTIC REPORT',p,flush=True)
 sys.exit(0)
assert not audit_path.exists()
record=dict(status='running',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Separate sampled R64 CPU diagnostic only after the fresh 4B primary loses. Exact outputs and unchanged caps; no primary eligibility. Samples target only the native binary descended from this private worker.',primary_throughput_eligible=False,diagnostic_driver_sha256=sha(Path(__file__)),selected_profile=selected,samples=[])
def save():audit_path.write_text(json.dumps(record,indent=2)+'\n')
save();binary=json.loads((out/'engine73d_build_manifest.json').read_text())['binary_path'];start=time.monotonic();policy_started=None;next_sample=0
with Path('/private/tmp/ocr-engine73d-cpu-diagnostic63-worker.txt').open('w')as log:
 worker=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--worker'],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:
  while worker.poll()is None:
   if time.monotonic()-start>900:raise TimeoutError('CPU diagnostic exceeded 900 seconds')
   raws=list(out.glob('engine73d_4b_cpu_diagnostic63_*_r64/lighton4b-batch-c64.txt'))
   ready=bool(raws)and'OCR_POLICY round=0'in raws[0].read_text()
   if ready and policy_started is None:policy_started=time.monotonic()
   if ready and len(record['samples'])<3 and time.monotonic()-policy_started>=next_sample:
    rows=[]
    for line in subprocess.check_output(['ps','-axo','pid,ppid,command'],text=True).splitlines()[1:]:
     parts=line.split(None,2)
     if len(parts)==3:rows.append((int(parts[0]),int(parts[1]),parts[2]))
    descendants={worker.pid}
    while True:
     more={pid for pid,parent,cmd in rows if parent in descendants}-descendants
     if not more:break
     descendants|=more
    targets=[pid for pid,parent,cmd in rows if pid in descendants and cmd.split(None,1)[0]==binary]
    if targets:
     assert len(targets)==1,targets
     path=Path('/private/tmp')/f'ocr-engine73d-cpu-diagnostic63-sample{len(record["samples"])}.txt'
     print('SAMPLE OWN NATIVE',targets[0],path,flush=True)
     r=subprocess.run(['/usr/bin/sample',str(targets[0]),'5','10','-file',str(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=30)
     record['samples'].append(dict(pid=targets[0],path=str(path),exit_code=r.returncode,message=r.stdout,sha256=sha(path)if path.exists()else None));save();next_sample+=35
   time.sleep(1)
  assert worker.returncode==0,worker.returncode
 finally:
  if worker.poll()is None:
   os.killpg(worker.pid,signal.SIGTERM)
   try:worker.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(worker.pid,signal.SIGKILL);worker.wait()
reports=list(out.glob('engine73d_4b_cpu_diagnostic63_*_r64/report.json'));assert len(reports)==1
record.update(status='pass'if any(x['exit_code']==0 for x in record['samples'])else'sampling_unavailable',native_report=str(reports[0].relative_to(out)),native_report_sha256=sha(reports[0]))
save();print('CPU DIAGNOSTIC',record['status'],flush=True)
