from pathlib import Path
import subprocess,sys,time,hashlib,json
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
wait=Path('/private/tmp/ocr-engine49-capacity-then-attention-driver.txt')
print('WAIT engine49 sequence',flush=True)
while True:
 s=wait.read_text()if wait.exists()else''
 if 'COMPLETE'in s or 'Traceback (most recent call last)'in s:break
 time.sleep(5)
for p,h in json.loads((v/'engine48-freeze.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
def archive(paths):
 ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns);ns['archive']('qualification',paths,'logs_manifest.json')
for label,script in [('engine50-recurrent-probe-build-driver','build_engine50_recurrent_probe.py'),('engine50-recurrent-probe-gpu-driver','run_engine50_recurrent_probe.py')]:
 print('START',label,flush=True);log=Path('/private/tmp/ocr-'+label+'.txt');assert not log.exists()
 with log.open('w')as f:r=subprocess.run([sys.executable,str(v/script)],stdout=f,stderr=subprocess.STDOUT)
 archive([log]);print('DONE',label,r.returncode,flush=True)
 archive(list(Path('/private/tmp').glob('ocr-engine50-recurrent-probe-gpu*.txt'))+list(Path('/private/tmp').glob('ocr-engine50-recurrent-probe-gpu*.jsonl'))+[Path('/private/tmp/ocr-engine50-recurrent-probe-build.txt')])
 assert r.returncode==0,(label,r.returncode)
print('COMPLETE',flush=True)
