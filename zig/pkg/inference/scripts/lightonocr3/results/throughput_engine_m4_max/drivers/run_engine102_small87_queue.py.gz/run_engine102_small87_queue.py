from pathlib import Path
import datetime,hashlib,json,os,psutil,signal,subprocess,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';a=o/'engine102_small87_queue_audit.json';assert not a.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();d=dict(status='checking_waiter',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),runs=[])
def save():a.write_text(json.dumps(d,indent=2)+'\n')
f=json.loads((v/'engine102-freeze.json').read_text());assert all(sha(r/p)==h for p,h in f.items());waiters=[]
for p in psutil.process_iter(['cmdline']):
 try:
  c=p.info['cmdline']or[]
  if len(c)==2 and Path(p.cwd(),c[1]).resolve()==v/'run_engine102_primary86.py':waiters.append(p)
 except(psutil.NoSuchProcess,psutil.AccessDenied):pass
assert len(waiters)==1;p=waiters[0];d['waiter_pid']=p.pid
if p.children(recursive=True):d['status']='declined_primary_child_active';save();print(d);sys.exit(0)
os.kill(p.pid,signal.SIGSTOP)
try:
 assert not p.children(recursive=True);d['status']='paused_own_child_free_waiter';save();print('PAUSED86',p.pid,flush=True)
 for name in ['run_engine102_08_warmed87.py','run_engine102_florence_warmed87.py']:
  assert all(sha(r/p)==h for p,h in f.items());record=dict(driver=name,status='running');d['runs'].append(record);save();print('START',name,flush=True)
  log=Path('/private/tmp')/('ocr-engine102-'+name.removesuffix('.py')+'-parent.txt');assert not log.exists()
  with log.open('w')as out:child=subprocess.run([sys.executable,str(v/name)],stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONPATH=str(r/'zig/pkg/inference/scripts/lightonocr3')))
  record.update(status='finished',exit_code=child.returncode,log_sha256=sha(log));save();print('DONE',name,child.returncode,flush=True)
 d['status']='complete';save()
finally:
 if all(sha(r/p)==h for p,h in f.items()):os.kill(p.pid,signal.SIGCONT);d['waiter_resumed']=True;print('RESUMED86',p.pid,flush=True)
 else:os.kill(p.pid,signal.SIGTERM);os.kill(p.pid,signal.SIGCONT);d['waiter_retired_source_changed']=True
 save()
