from pathlib import Path
import subprocess,sys
v=Path('.venv-lighton-vllm-metal')
for helper,args in [('run_engine44_functional.py',[]),('run_engine44_wide64_cases.py',['qualification']),('run_engine44_florence_preprocess_cases.py',['qualification'])]:
 print('START',helper,args,flush=True)
 with Path('/private/tmp/ocr-engine44-'+helper.removesuffix('.py')+'-driver.txt').open('w')as log:
  r=subprocess.run([sys.executable,str(v/helper),*args],stdout=log,stderr=subprocess.STDOUT)
 print('DONE',helper,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
