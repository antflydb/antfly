#include <metal_stdlib>
using namespace metal;
struct termite_qwen35_params{uint seq,key_heads,value_heads,dim,kernel_size,initialized;};
struct CoreRow{device float*buffers[15];termite_qwen35_params params;};
template<uint C>inline void termite_qwen35_recurrent_columns_body(device float*state,device const float*conv,device const float*gates,device float*output,constant termite_qwen35_params&p,uint gid,uint lane){
 constexpr uint K=4*C;uint column=gid/32,h=column/(128/C),col=(column%(128/C))*C+lane%C,klane=lane/C;if(h>=p.value_heads)return;
 uint kh=h/(p.value_heads/p.key_heads),channels=(2*p.key_heads+p.value_heads)*128,base=h*128*128+klane*K*128+col;
 float s[K];
 #pragma unroll
 for(uint i=0;i<K;i++)s[i]=p.initialized?state[base+i*128]:0;
 for(uint t=0;t<p.seq;t++){
  uint qb=t*channels+kh*128+klane*K,kb=qb+p.key_heads*128;float decay=gates[(t*p.value_heads+h)*2],beta=gates[(t*p.value_heads+h)*2+1];float memory=0;
  #pragma unroll
  for(uint i=0;i<K;i++){s[i]*=decay;memory+=s[i]*conv[kb+i];}
  #pragma unroll
  for(uint step=16/C;step>0;step/=2)memory+=simd_shuffle_xor(memory,step*C);
  float delta=(conv[t*channels+2*p.key_heads*128+h*128+col]-memory)*beta,out=0;
  #pragma unroll
  for(uint i=0;i<K;i++){s[i]+=conv[kb+i]*delta;out+=s[i]*conv[qb+i];}
  #pragma unroll
  for(uint step=16/C;step>0;step/=2)out+=simd_shuffle_xor(out,step*C);
  if(klane==0)output[(t*p.value_heads+h)*128+col]=out;
 }
 #pragma unroll
 for(uint i=0;i<K;i++)state[base+i*128]=s[i];
}
kernel void batch165_conv(constant CoreRow*rows[[buffer(0)]],uint2 id[[thread_position_in_grid]],ushort lane[[thread_index_in_simdgroup]]){
constant CoreRow&r=rows[id.y];constant termite_qwen35_params&p=r.params;uint gid=id.x;
device const float*mixed=r.buffers[0],*weight=r.buffers[1],*beta=r.buffers[2],*a=r.buffers[3],*alog=r.buffers[4],*dt=r.buffers[5],*history=r.buffers[6];
device float*next=r.buffers[7],*state=r.buffers[8],*conv=r.buffers[9],*gates=r.buffers[10],*core=r.buffers[11];device const float*z=r.buffers[12];device float*output=r.buffers[14];

 uint channels=(2*p.key_heads+p.value_heads)*p.dim;
 if(gid>=p.seq*(channels/4))return;uint t=gid/(channels/4),c=gid%(channels/4)*4;
 float4 w0=*((device const float4*)(weight+c*4)),w1=*((device const float4*)(weight+(c+1)*4)),w2=*((device const float4*)(weight+(c+2)*4)),w3=*((device const float4*)(weight+(c+3)*4));
 float4 sum=0;
 #pragma unroll
 for(uint k=0;k<4;k++){int src=int(t)+int(k)-3;float4 x=0;if(src>=0)x=*((device const float4*)(mixed+uint(src)*channels+c));else if(p.initialized)x=float4(history[c*4+uint(4+src)],history[(c+1)*4+uint(4+src)],history[(c+2)*4+uint(4+src)],history[(c+3)*4+uint(4+src)]);sum+=x*float4(w0[k],w1[k],w2[k],w3[k]);}
 *((device float4*)(conv+t*channels+c))=sum/(1.0f+exp(-sum));

}
kernel void batch165_history(constant CoreRow*rows[[buffer(0)]],uint2 id[[thread_position_in_grid]],ushort lane[[thread_index_in_simdgroup]]){
constant CoreRow&r=rows[id.y];constant termite_qwen35_params&p=r.params;uint gid=id.x;
device const float*mixed=r.buffers[0],*weight=r.buffers[1],*beta=r.buffers[2],*a=r.buffers[3],*alog=r.buffers[4],*dt=r.buffers[5],*history=r.buffers[6];
device float*next=r.buffers[7],*state=r.buffers[8],*conv=r.buffers[9],*gates=r.buffers[10],*core=r.buffers[11];device const float*z=r.buffers[12];device float*output=r.buffers[14];

    uint channels=(2*p.key_heads+p.value_heads)*p.dim;
    if(gid>=channels*p.kernel_size)return;
    uint c=gid/p.kernel_size,slot=gid%p.kernel_size;
    int src=int(p.seq)+int(slot)-int(p.kernel_size);
    next[gid]=src>=0?mixed[uint(src)*channels+c]:(p.initialized?history[c*p.kernel_size+uint(int(p.kernel_size)+src)]:0.0f);

}
kernel void batch165_prepare(constant CoreRow*rows[[buffer(0)]],uint2 id[[thread_position_in_grid]],ushort lane[[thread_index_in_simdgroup]]){
constant CoreRow&r=rows[id.y];constant termite_qwen35_params&p=r.params;uint gid=id.x;
device const float*mixed=r.buffers[0],*weight=r.buffers[1],*beta=r.buffers[2],*a=r.buffers[3],*alog=r.buffers[4],*dt=r.buffers[5],*history=r.buffers[6];
device float*next=r.buffers[7],*state=r.buffers[8],*conv=r.buffers[9],*gates=r.buffers[10],*core=r.buffers[11];device const float*z=r.buffers[12];device float*output=r.buffers[14];

    uint row=gid/32; if(row>=p.seq*p.value_heads)return;uint t=row/p.value_heads,h=row%p.value_heads;
    if(h<p.key_heads) {
        uint qb=t*(2*p.key_heads+p.value_heads)*p.dim+h*p.dim,kb=qb+p.key_heads*p.dim;
        float qs=0,ks=0;
        for(uint d=uint(lane);d<p.dim;d+=32){float q=conv[qb+d],k=conv[kb+d];qs+=q*q;ks+=k*k;}
        float qn=1.0f/sqrt(simd_sum(qs)+1e-6f)/sqrt(float(p.dim)),kn=1.0f/sqrt(simd_sum(ks)+1e-6f);
        for(uint d=uint(lane);d<p.dim;d+=32){conv[qb+d]*=qn;conv[kb+d]*=kn;}
    }
    if(lane==0) {
        float x=a[row]+dt[h];
        float sp=x>20.0f?x:(x< -20.0f?exp(x):log(1.0f+exp(x)));
        gates[row*2]=exp(-exp(alog[h])*sp);
        gates[row*2+1]=1.0f/(1.0f+exp(-beta[row]));
    }

}
kernel void batch165_norm(constant CoreRow*rows[[buffer(0)]],uint2 id[[thread_position_in_grid]],ushort lane[[thread_index_in_simdgroup]]){
constant CoreRow&r=rows[id.y];constant termite_qwen35_params&p=r.params;uint gid=id.x;
device const float*mixed=r.buffers[0],*weight=r.buffers[13],*beta=r.buffers[2],*a=r.buffers[3],*alog=r.buffers[4],*dt=r.buffers[5],*history=r.buffers[6];
device float*next=r.buffers[7],*state=r.buffers[8],*conv=r.buffers[9],*gates=r.buffers[10],*core=r.buffers[11];device const float*z=r.buffers[12];device float*output=r.buffers[14];

    uint h=gid/32; if(h>=p.seq*p.value_heads)return; uint base=h*p.dim;
    float sum=0;
    for(uint d=uint(lane);d<p.dim;d+=32){float v=core[base+d];sum+=v*v;}
    float scale=1.0f/sqrt(simd_sum(sum)/float(p.dim)+1e-6f);
    for(uint d=uint(lane);d<p.dim;d+=32){float gate=z[base+d];output[base+d]=core[base+d]*scale*weight[d]*(gate/(1.0f+exp(-gate)));}

}
kernel void batch165_recurrent(constant CoreRow*rows[[buffer(0)]],uint2 id[[thread_position_in_grid]],ushort lane[[thread_index_in_simdgroup]]){constant CoreRow&r=rows[id.y];termite_qwen35_recurrent_columns_body<4>(r.buffers[8],r.buffers[9],r.buffers[10],r.buffers[11],r.params,id.x,lane);}
