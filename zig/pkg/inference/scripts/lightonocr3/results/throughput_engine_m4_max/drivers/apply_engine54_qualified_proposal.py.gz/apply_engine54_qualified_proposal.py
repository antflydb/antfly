from pathlib import Path
import json,hashlib,shutil
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
frozen=json.loads((v/'engine53-freeze.json').read_text());assert all(sha(p)==h for p,h in frozen.items())
for name in ['engine53_08_rolling_chunks_r64_audit.json','engine53_4b_rolling_chunks_c60_p2_vf2_r64_profile2_audit.json','engine53_4b_rolling_chunks_c48_p1_vf1_r64_vision4_audit.json','engine53_4b_rolling_chunks_c48_p3_vf2_r64_prefill3_c48_audit.json','engine53_4b_rolling_chunks_c48_p1_vf1_r64_vision4_wait100ms_audit.json','engine53_4b_rolling_chunks_c48_p3_vf1_r64_vision4_prefill3_wait100ms_audit.json']:
 assert json.loads((o/name).read_text())['status']=='pass',name
log=Path('/private/tmp/ocr-engine54-product-batch-argmax.txt').read_text();assert log.count('batch_argmax_check rows=')==6 and 'rows=65'in log
m=json.loads((v/'engine54_product_proposal_late_seal_unformatted.json').read_text());proposal=v/'engine54-product-proposal';files={p:sha(proposal/p)for p in m['files']}
(v/'engine54_product_proposal_final.json').write_text(json.dumps(dict(status='reviewed_before_native_build',files=files,base_engine53=frozen),indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
renamed=[]
for p,h in files.items():
 target=v/('engine54_final_'+Path(p).name);shutil.copyfile(proposal/p,target);renamed.append(target)
ns['archive']('drivers',renamed+[v/'engine54_product_proposal_final.json',Path(__file__),v/'prepare_engine54_late_seal_proposal.py',v/'prepare_engine54_cancelable_lane_proposal.py',v/'engine54_late_seal_test.inc',v/'engine54_execution_lane_wait.inc'],'drivers_manifest.json')
ns['archive']('qualification',list(Path('/private/tmp').glob('ocr-engine53-*.txt'))+[Path('/private/tmp/ocr-engine54-product-c-build.txt'),Path('/private/tmp/ocr-engine54-product-batch-argmax.txt')],'logs_manifest.json')
(o/'engine53_post_all_controls_freeze_audit.json').write_text(json.dumps(dict(status='pass',files=frozen),indent=2)+'\n')
(o/'engine54_product_batch_argmax_audit.json').write_text(json.dumps(dict(status='pass',rows=[1,2,16,33,64,65],checks=['CPU/legacy parity','private GPU producer','suppressed and unsuppressed','nonfinite/ties','token canaries','both missing-PSO fallbacks','wrong vocabulary fallback','planned and standalone','cancellation'],log_sha256=sha('/private/tmp/ocr-engine54-product-batch-argmax.txt'),build_manifest_sha256=sha(o/'engine54_product_c_build_manifest.json')),indent=2)+'\n')
for p in files:shutil.copyfile(proposal/p,p)
allfiles=list(frozen)+['zig/pkg/inference/src/server/executor_microbatch.zig']
(v/'engine54-freeze.json').write_text(json.dumps({p:sha(p)for p in allfiles},indent=2)+'\n')
shutil.copyfile('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py',v/'engine54_benchmark_concurrency.py')
s=(v/'run_engine53_verify_gpu_build.py').read_text().replace('engine53','engine54')
s=s.replace("env['ANTFLY_LIGHTONOCR3_GPU_GREEDY_STREAM']='1'","env['ANTFLY_LIGHTONOCR3_GPU_GREEDY_STREAM']='1'\nenv['TERMITE_METAL_ENABLE_LIGHTONOCR3_BATCH_ARGMAX']='1'\nenv['ANTFLY_LIGHTONOCR3_VISION_LATE_SEAL']='1'\nenv['ANTFLY_LIGHTONOCR3_PREFILL_LATE_SEAL']='1'")
s=s.replace("filters=['LightOnOCR3'","filters=['microbatch broker','LightOnOCR3'")
s=s.replace('sys.exit(r.returncode)', '''if r.returncode==0:
 calls=re.findall(r'LIGHTONOCR3 batch_argmax_calls=(\\d+)',log)
 rows=re.findall(r'LIGHTONOCR3 batch_argmax_rows=(\\d+)',log)
 assert calls and rows and sum(map(int,calls))>0 and sum(map(int,rows))>=2*sum(map(int,calls)),(calls,rows)
 print('qualified actual two-dispatch batch argmax counters',calls,rows)
sys.exit(r.returncode)''')
(v/'run_engine54_verify_gpu_build.py').write_text(s)
for p in [v/'run_engine54_verify_gpu_build.py',v/'engine54_benchmark_concurrency.py']:compile(p.read_text(),str(p),'exec')
ns['archive']('drivers',[v/'run_engine54_verify_gpu_build.py',v/'engine54_benchmark_concurrency.py',v/'engine54-freeze.json'],'drivers_manifest.json')
print('applied engine54; frozen',len(allfiles),'files')
