from pathlib import Path
import subprocess,sys,json,hashlib
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';s=root/'zig/pkg/inference/scripts/lightonocr3';o=s/'results/throughput_engine_m4_max';dest=o/'vllm_4b_diagnostic_reference29_stage_screen_c64_r64';assert not dest.exists()
cmd=[sys.executable,str(s/'benchmark_vllm_metal.py'),'--python',sys.executable,'--model-dir',str(v/'ocr-models/lighton4b'),'--images',str(root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(s/'corpus/receipt.png'),str(s/'corpus/shipping.png'),'--concurrency','64','--requests','64','--max-tokens','256','--startup-timeout','600','--output-dir',str(dest)]
log=Path('/private/tmp/ocr-engine55-vllm-stage-screen.txt')
with log.open('w')as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
assert r.returncode==0,r.returncode
p=dest/'report.json';d=json.loads(p.read_text());assert d['status']=='ok'and d['kv_cache_block_override']is None and d['results'][0]['serial_reference_parity']
(o/'engine55_vllm_stage_screen_audit.json').write_text(json.dumps(dict(status='pass',primary_full_model_comparison=False,scope='Fresh R64 reference diagnostic, automatic cache and original benchmark settings; not a paired R128 claim.',pages_per_second=d['results'][0]['pages_per_second'],report=str(p.relative_to(o)),report_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest()),indent=2)+'\n')
print('reference R64 screen',d['results'][0]['pages_per_second'],flush=True)
