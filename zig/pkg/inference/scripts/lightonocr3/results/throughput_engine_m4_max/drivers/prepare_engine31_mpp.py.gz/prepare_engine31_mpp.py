from pathlib import Path
import hashlib,json,subprocess
v=Path('.venv-lighton-vllm-metal');freeze=json.loads((v/'engine30-freeze.json').read_text())
for f,h in freeze.items():
 if f not in ['zig/pkg/inference/src/pipelines/reading.zig','zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py']:assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h,f
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text()
for old,new in [('    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_VISION_PACK_REUSE,','    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_VISION_PACK_REUSE,\n    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_PLANNED_MPP,'),('    "TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_PACK_REUSE",','    "TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_PACK_REUSE",\n    "TERMITE_METAL_DISABLE_LIGHTONOCR3_PLANNED_MPP",'),('    uint64_t lighton_vision_pack_reuse_hits;','    uint64_t lighton_vision_pack_reuse_hits;\n    uint64_t lighton_mpp_planned_calls;\n    uint64_t lighton_mpp_dedicated_calls;')]:assert old in s;s=s.replace(old,new,1)
a=s.index('static int termite_metal_try_lightonocr3_mpp(');tail='    return rc == 0 ? 1 : rc;\n}\n';b=s.index(tail,a)+len(tail);m=s[a:b]
old='''    id<MTLComputeCommandEncoder> enc =
        termite_metal_tracked_compute_command_encoder_for(cb, TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);''';assert old in m
new='''    // Preserve a caller's serial/planned encoder instead of closing it for
    // every projection. Register all real storage, including the BF16 pack,
    // so concurrent scopes retain their producer/consumer barriers as well.
    id<MTLComputeCommandEncoder> enc = nil;
    bool planned = false;
    if (!owned && runtime->active_planned_compute_encoder != nil &&
        !termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_PLANNED_MPP)) {
        termite_metal_planned_encoder_range accesses[5];
        __unsafe_unretained id<MTLBuffer> buffers[5] = {input, runtime->linear_weight_buffers[slot],
            runtime->linear_bias_buffers[slot], output, packed};
        const size_t offsets[5] = {input_offset, 0, 0, output_offset, 0};
        const size_t sizes[5] = {rows * in_dim * 4u, in_dim * out_dim * 2u,
            out_dim * 4u, rows * out_dim * 4u, rows * in_dim * 2u};
        const uint32_t types[5] = {TERMITE_METAL_PLANNED_RANGE_READ, TERMITE_METAL_PLANNED_RANGE_READ,
            TERMITE_METAL_PLANNED_RANGE_READ, TERMITE_METAL_PLANNED_RANGE_WRITE, TERMITE_METAL_PLANNED_RANGE_WRITE};
        const size_t count = bf16 ? 5u : 4u;
        for (size_t i = 0; i < count; ++i)
            if (termite_metal_planned_range_make(buffers[i], offsets[i], sizes[i], types[i], &accesses[i], -11)) return -11;
        if (termite_metal_decode_runtime_prepare_planned_compute_accesses(runtime, accesses, count, -11)) return -11;
        enc = runtime->active_planned_compute_encoder;
        planned = enc != nil;
    }
    if (!planned)
        enc = termite_metal_tracked_compute_command_encoder_for(cb, TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);'''
m=m.replace(old,new,1).replace('    [enc endEncoding];','    if (!planned) [enc endEncoding];',1)
anchor='''    int rc = termite_metal_decode_runtime_finish_command_buffer(cb, owned, -12);''';assert anchor in m;m=m.replace(anchor,anchor+'''
    if (rc == 0) {
        if (planned) runtime->lighton_mpp_planned_calls += 1;
        else runtime->lighton_mpp_dedicated_calls += 1;
    }''',1);s=s[:a]+m+s[b:]
s+='''
void termite_metal_decode_runtime_lighton_mpp_encoder_stats(termite_metal_decode_runtime *runtime, uint64_t *out) {
    if (out == NULL) return;
    out[0] = runtime != NULL ? runtime->lighton_mpp_planned_calls : 0;
    out[1] = runtime != NULL ? runtime->lighton_mpp_dedicated_calls : 0;
}
''';p.write_text(s)
p=Path('zig/pkg/inference/src/backends/metal_runtime.zig');s=p.read_text();anchor='pub extern fn termite_metal_decode_runtime_lighton_vision_pack_stats(runtime: ?*RawMetalDecodeRuntime, out: *[2]u64) void;';assert anchor in s;s=s.replace(anchor,anchor+'\npub extern fn termite_metal_decode_runtime_lighton_mpp_encoder_stats(runtime: ?*RawMetalDecodeRuntime, out: *[2]u64) void;',1);p.write_text(s)
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text();anchor='    lighton_vision_pack_baseline: [2]u64 = @splat(0),';assert anchor in s;s=s.replace(anchor,anchor+'\n    lighton_mpp_encoder_baseline: [2]u64 = @splat(0),',1)
anchor='        metal_runtime_mod.termite_metal_decode_runtime_lighton_vision_pack_stats(raw, &self.lighton_vision_pack_baseline);';assert anchor in s;s=s.replace(anchor,anchor+'\n        metal_runtime_mod.termite_metal_decode_runtime_lighton_mpp_encoder_stats(raw, &self.lighton_mpp_encoder_baseline);',1)
a=s.index('    pub fn lightOnVisionPackStats(');b=s.index('    pub fn lightOnBatchAttentionStats(',a);method=s[a:b].replace('lightOnVisionPackStats','lightOnMppEncoderStats').replace('lighton_vision_pack','lighton_mpp_encoder');s=s[:b]+method+s[b:];p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text();anchor='                    std.debug.print("LIGHTONOCR3 vision_pack_calls={d} vision_pack_reuse_hits={d}\\n", .{ vision_pack[0], vision_pack[1] });';assert anchor in s;s=s.replace(anchor,anchor+'''
                    const mpp_encoder = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnMppEncoderStats(&cb) else @as([2]u64, @splat(0));
                    std.debug.print("LIGHTONOCR3 mpp_planned_calls={d} mpp_dedicated_calls={d}\\n", .{ mpp_encoder[0], mpp_encoder[1] });''',1);p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text();anchor='    if args.bf16_prefill_inputs:';assert anchor in s;s=s.replace(anchor,'    if args.disable_planned_mpp:\n        env["TERMITE_METAL_DISABLE_LIGHTONOCR3_PLANNED_MPP"] = "1"\n'+anchor,1)
anchor='    parser.add_argument("--disable-prefill-pack-reuse", action="store_true")';assert anchor in s;s=s.replace(anchor,'    parser.add_argument("--disable-planned-mpp", action="store_true")\n'+anchor,1);p.write_text(s)
print('31 planned-aware MPP projections and independent encoder counters prepared')
