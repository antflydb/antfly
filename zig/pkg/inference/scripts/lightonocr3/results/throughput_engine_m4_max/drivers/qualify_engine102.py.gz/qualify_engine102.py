from pathlib import Path
import hashlib,json,subprocess,os,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f={p:sha(p)for p in json.loads((v/'engine101-freeze.json').read_text())};(v/'engine102-freeze.json').write_text(json.dumps(f,indent=2)+'\n')
for old,new in [('run_engine101_gpu_build.py','run_engine102_gpu_build.py'),('run_engine101_budget_policies.py','run_engine102_budget_policies.py')]:
 s=(v/old).read_text().replace('engine101','engine102')
 if 'budget' in old:
  s=s.replace("packed_head_count=sum(int(p)+int(q)>16 for p,q,t in re.findall(r'LIGHTONOCR3 packed_step_prefill_items=(\\d+) packed_step_decode_items=(\\d+) packed_step_query_rows=(\\d+)',section))", "packed_head_count=sum(map(int,re.findall(r'packed_standalone_wide_heads=(\\d+)',section)))")
  needle="    if os.environ.get('OCR_PACKED_MIXED','0')=='1':assert sample['packed_input_frames']==sample['packed_steps'],sample"
  assert needle in s;s=s.replace(needle,needle+"\n    if os.environ.get('OCR_PACKED_MIXED','0')=='1':assert sample['packed_gpu_decode_rows']==sample['packed_decode_rows'] and sample['packed_cpu_logit_rows']==sample['packed_prefill_pages'],sample")
 (v/new).write_text(s)
(v/'engine102_benchmark_concurrency.py').write_bytes((r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
s=(v/'run_engine102_gpu_build.py').read_text();start=s.index('filters=');end=s.index("with open(",start);scope={};exec(s[start:s.index('command=',start)],scope);filters=scope['filters'];env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(r/'zig/.zig-cache/global'))
cmd=['/Users/ajroetker/bin/zig-0.17.0/zig','build','inference-test','-Dmetal=false','-Doptimize=ReleaseFast','-Dstrip=true','--summary','all',*[f'-Dtest-filter={x}'for x in filters]]
with open('/private/tmp/ocr-engine102-packed-cpu.txt','w')as out:p=subprocess.run(cmd,cwd=r/'zig',env=env,stdout=out,stderr=subprocess.STDOUT)
print('CPU_EXIT',p.returncode,flush=True);assert p.returncode==0
assert all(sha(p)==h for p,h in f.items())
sys.exit(0)
