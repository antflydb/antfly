from pathlib import Path
import os,json,subprocess,sys,hashlib
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');src=o/'engine55_stage_profiles_audit.json';d=json.loads(src.read_text());assert d['status']=='pass'
best=max(d['candidates'],key=lambda x:x['pages_per_second']);settings={'vision_stage':(4,1,1),'prefill_stage':(1,3,2),'combined_stage':(4,3,1)};vision,prefill,vf=settings[best['profile']]
records=[];audit=o/'engine55_4b_stage_primary_controls_audit.json';assert not audit.exists()
for trial,on in enumerate([True,False,False,True]):
 label=f'stage_controls_{best["profile"]}_enabled{int(on)}_trial{trial}'
 env=os.environ.copy();env.update(OCR_CASE_REQUESTS='128',OCR_CASE_CONCURRENCY='48',OCR_CASE_PREFILL_ITEMS=str(prefill),OCR_CASE_VISION_FRAME_BLOCKS=str(vf),OCR_CASE_VISION_BATCH_ITEMS=str(vision),OCR_CASE_TAG=label,OCR_VISION_WAIT_US='2000',OCR_PREFILL_WAIT_US='100000',OCR_BATCH_ARGMAX=str(int(on)),OCR_DEFER_VISION_SEAL=str(int(on and vision>1)),OCR_DEFER_PREFILL_SEAL=str(int(on and prefill>1)),OCR_TIMEOUT='900')
 print('START',label,flush=True)
 with Path('/private/tmp/ocr-engine55-'+label+'-driver.txt').open('w')as log:r=subprocess.run([sys.executable,str(v/'run_engine55_vision4_profile.py'),'4b','0'],env=env,stdout=log,stderr=subprocess.STDOUT)
 print('DONE',label,r.returncode,flush=True);assert r.returncode==0,(label,r.returncode)
 p=o/f'engine55_4b_rolling_chunks0_trial0_c48_p{prefill}_vf{vf}_r128_{label}'/'report.json';rd=json.loads(p.read_text());rs=rd['results'][0];s=rs['policy_rounds'][0]
 assert rs['status']=='ok'and rs['serial_reference_parity']and rs['cross_runtime_content_parity']and s['completed']==128 and not s['admission_pressures']and not rd['own_cpu_compile_overlap']
 records.append(dict(trial=trial,enabled=on,pages_per_second=s['pages_per_second'],completed=128,process_cpu_ms=s['process_cpu_ms'],batch_argmax_calls=s['batch_argmax_calls'],vision_batch_sizes=s['vision_batch_sizes'],prefill_batches=s['prefill_batches'],report=str(p.relative_to(o)),report_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 audit.write_text(json.dumps(dict(status='running',qualification_selection=best,candidates=records),indent=2)+'\n')
means={str(on):sum(x['pages_per_second']for x in records if x['enabled']==on)/2 for on in [False,True]};selected=means['True']>means['False']
result=dict(status='pass',qualification_selection=best,qualification_audit_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),candidates=records,mean_rates=means,selected_enabled=selected,selected_settings=dict(concurrency=48,vision_items=vision,prefill_items=prefill,vision_frame_blocks=vf,batch_argmax=selected,defer_vision_seal=selected and vision>1,defer_prefill_seal=selected and prefill>1),selection='Highest qualifying R64 profile, then higher mean across the two R128 runs per mode in ON/OFF/OFF/ON order; fresh cross-runtime comparisons remain separate.')
audit.write_text(json.dumps(result,indent=2)+'\n');print('CONTROL RESULT',json.dumps(result['selected_settings']),means,flush=True)
