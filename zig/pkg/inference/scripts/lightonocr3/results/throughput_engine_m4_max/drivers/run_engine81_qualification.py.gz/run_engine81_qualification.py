from pathlib import Path
import subprocess,sys,json,hashlib,os
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=json.loads((v/'engine81-freeze.json').read_text());assert all(sha(r/p)==h for p,h in f.items())
for name,cmd in [('gpu',[sys.executable,str(v/'run_engine81_verify_gpu_build.py')]),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine81','/private/tmp/ocr-engine81-verify2-gpu-build.txt']),('resident-rounds',[sys.executable,str(v/'qualify_engine81_resident_ffn_rounds.py')])]:
 print('START ENGINE81',name,flush=True)
 with Path('/private/tmp/ocr-engine81-'+name+'-parent.txt').open('w')as log:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 print('DONE ENGINE81',name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
 assert all(sha(r/p)==h for p,h in f.items())
m=json.loads((o/'engine81_build_manifest.json').read_text());os.link(Path(m['binary_path']),v/'qualified-binaries/engine81-test');assert sha(v/'qualified-binaries/engine81-test')==m['binary_sha256']
print('ENGINE81 QUALIFICATION DONE',flush=True)
