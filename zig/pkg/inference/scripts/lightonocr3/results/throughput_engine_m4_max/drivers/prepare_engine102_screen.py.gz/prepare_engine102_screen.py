from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=(v/'run_engine101_mixed_screen82.py').read_text().replace('engine101','engine102').replace('screen82','screen83').replace('mixed82','mixed83')
a=s.index(" for model,c,requests,prefill,estimate,reference in ");b=s.index(':\n  while',a)
s=s[:a]+" for model,c,requests,prefill,estimate,reference in [('08',16,32,1,3000000000,'_primary_reference72_r0_c16_r32_ctx1024'),('4b',64,128,1,11348275670,'_primary_reference73_r0_auto_c64_r128_ctx1024')]"+s[b:]
s=s.replace("OCR_PHYSICAL64='1'","OCR_PHYSICAL64='1'if model=='4b'else'0'").replace("OCR_LOGICAL64='1'","OCR_LOGICAL64='1'if model=='4b'else'0'")
s=s.replace("scope='C64sharedcapfailureexcluded; retryC60underoriginalcaps. Coldscreenonly.","scope='Source102GPUgreedychoiceswithprefix-onlyCPUlogitsandactualhostlease. C64originalcaps. Coldscreenonly.")
s=s.replace('Freshsource100 qualifiedbinary','Freshsource102 qualifiedbinary')
s=s.replace("d['status']='mixed_screen_pass'","d['status']='mixed_screen_pass'")
(v/'run_engine102_mixed_screen83.py').write_text(s)
