from pathlib import Path
import json,subprocess,sys,time
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');p=o/'paired52_4b_comparison_audit.json'
while True:
 if p.exists():
  d=json.loads(p.read_text())
  if d['status']!='running':break
 parent=Path('/private/tmp/ocr-engine69-4b-api-paired52-parent.txt')
 if parent.exists()and'Traceback'in parent.read_text():raise RuntimeError('primary failed unexpectedly; no follow-up')
 time.sleep(5)
jobs=['08_paired54','florence_paired54']if d['status']=='repeated_win'else['cpu_diagnostic53']if d['status']in['early_stop_forward_loss','native_behind']else[]
assert jobs,d['status']
for name in jobs:
 print('START',name,flush=True)
 with Path('/private/tmp/ocr-engine69-'+name+'-parent.txt').open('w')as f:
  subprocess.run([sys.executable,str(v/('run_engine69_'+name+'.py'))],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
print('ENGINE69 FOLLOW52 DONE',flush=True)
