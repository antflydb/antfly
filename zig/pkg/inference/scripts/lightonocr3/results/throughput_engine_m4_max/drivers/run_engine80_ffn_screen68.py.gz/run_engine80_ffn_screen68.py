from pathlib import Path
import ast,datetime,hashlib,json,os,statistics,subprocess,sys,time,psutil
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p,h in json.loads((v/'engine80-freeze.json').read_text()).items():assert sha(root/p)==h,p
prior=json.loads((out/'paired59_4b_comparison_audit.json').read_text());profiles=prior['profiles'];oracle=Path(prior['comparisons'][-1]['reference_report']).parent.name.removeprefix('vllm_4b')
audit=out/'engine80_prefill_ffn_screen68_audit.json';assert not audit.exists()
d=dict(status='running',scope='Fixed source80 C64 single-page prefill/VF3/width4 original-cap 4B ABBA: ordinary/packed/packed/ordinary FFN. Every R128 page and three full cross-runtime fixture strings must match. No new vLLM timing claim.',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),cases=[])
def save():audit.write_text(json.dumps(d,indent=2)+'\n')
def wait_model_headroom():
 while psutil.virtual_memory().available<11348275670+6*1024**3+512*1024**2:
  print('WAIT original 4B admission',psutil.virtual_memory().available,flush=True);time.sleep(30)
save();source=(v/'run_engine80_api_paired66.py').read_text();node=next(x for x in ast.parse(source).body if isinstance(x,ast.FunctionDef)and x.name=='native');base=ast.get_source_segment(source,node)
for leg,enabled in enumerate([False,True,True,False]):
 fn=base.replace('paired66',f'ffn_screen68_enable{int(enabled)}').replace("env['OCR_PREFILL_FUSED_FFN']='1'",f"env['OCR_PREFILL_FUSED_FFN']='{int(enabled)}'").replace("assert s['prefill_fused_ffn_calls'] > 0",f"assert (s['prefill_fused_ffn_calls'] > 0)=={enabled}")
 exec(compile(fn,'extracted_native_ffn_screen68_'+str(leg),'exec'),globals())
 print('START FFN SCREEN68',leg,enabled,flush=True)
 try:
  report,p=native('wide',leg,oracle);sample=report['results'][0]['policy_rounds'][0]
  d['cases'].append(dict(leg=leg,enabled=enabled,pages_per_second=sample['pages_per_second'],observed_calls=sample['prefill_fused_ffn_calls'],report=str(p.relative_to(out)),report_sha256=sha(p)));save()
 except BaseException as e:d.update(status='failed',error=repr(e));save();raise
rates={str(enabled):statistics.mean(x['pages_per_second']for x in d['cases']if x['enabled']==enabled)for enabled in [False,True]}
d.update(status='pass',mean_rates=rates,packed_to_ordinary_ratio=rates['True']/rates['False']);save();print('ENGINE80 FFN SCREEN68 DONE',rates,flush=True)
