from pathlib import Path
import ast,hashlib,json,os,subprocess,sys
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
record={'selected_profiles':{'08':{'settings':[4,4,16,False,1]}}}
os.environ['OCR_PREFILL_FFN_ROUNDS']='off,on,on,off'
os.environ['OCR_REQUIRE_PREFILL_FFN']='0'
def native(model, round_index, oracle):
    profile = record['selected_profiles'][model]
    c, vf, prefix, wide64, prefill = profile['settings']
    old_tile, bf16 = int(model == '08'), 0
    label = f'resident_ffn_qualification69_r{round_index}_physical64_c{c}_vf{vf}_prefix{prefix}_wide64{int(wide64)}_p{prefill}_r4'
    env = os.environ.copy()
    env.update(OCR_REFERENCE_LABEL=oracle, OCR_DISABLE_WIDE_GATE_UP='0', OCR_WIDE64_GATE_UP=str(int(wide64)), OCR_GPU_GREEDY_STREAM=str(int(prefix>0)), OCR_PHYSICAL32='0', OCR_PHYSICAL64='1',
               OCR_CONCURRENCY=str(c), OCR_REQUESTS='4', OCR_WIDE='1', OCR_KV_GIB='4',
               OCR_BACKEND_GIB='17' if model == '4b' else '16', OCR_SCRATCH_GIB='10' if model == '4b' else '8',
               OCR_CPU_PREPROCESS='1', OCR_PREFILL_DECODE_STREAK='0', OCR_POLICIES='engineepoch,engineepoch,engineepoch,engineepoch',
               OCR_SHARED_CORE='1' if model == '4b' else '0', OCR_BF16_PREFILL='1',
               OCR_BF16=str(bf16), OCR_DISABLE_64_ROW_TILE=str(old_tile), OCR_VISION_BATCH='0',
               OCR_VISION_BATCH_ITEMS='1', OCR_VISION_WAIT_US='20000',
               OCR_PREFILL_BATCH=str(int(prefill>1)), OCR_PREFILL_BATCH_ITEMS=str(prefill), OCR_PREFILL_WAIT_US='1000000' if prefill>1 else '100000',
               OCR_VISION_FRAME_BLOCKS=str(vf), OCR_SINGLE_FRAME=str(int(prefix==0)), OCR_STREAM_FIRST=str(prefix),
               OCR_LOGICAL64='1', OCR_SHARED_DECODER_SCRATCH='1', OCR_DEVICE_RECURRENT_STATE='1',
               OCR_ENCODER_SCOPES='1', OCR_ADMISSION_UNITS='512', OCR_BATCH_ARGMAX='1', OCR_CACHE_VISION_WORKSPACE='1', OCR_LARGE_VISION_PACK_REUSE='0', OCR_DEFER_VISION_SEAL='0', OCR_DEFER_PREFILL_SEAL='0', ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY='0', OCR_STREAM_CHUNK_LAYERS='0', OCR_FULL64_GATE_UP='0', OCR_GPU_TOKEN_BURST='0', OCR_PIPELINE_VISION='0')
    dest = out / f'engine81_{model}_{label}'
    assert not (dest / 'report.json').exists()
    print('START NATIVE', model, round_index, profile['settings'], flush=True)
    subprocess.run([sys.executable, str(v / 'run_engine81_budget_policies.py'), model + ':' + label], env=env, check=True)
    p = dest / 'report.json'
    d = json.loads(p.read_text())
    assert not d['own_cpu_compile_overlap']
    return d, p
report,p=native('08',0,'_primary_reference67_r0_auto_c64_r128')
r=report['results'][0];rounds=r['policy_rounds'];assert r['status']=='ok'and r['serial_reference_parity']and len(rounds)==4
assert [s['prefill_fused_ffn_enabled']for s in rounds]==[False,True,True,False]
assert all(s['completed']==4 and s['prefill_fused_ffn_calls']==0 and not s['admission_pressures']for s in rounds)
(out/'engine81_resident_ffn_rounds_qualification_audit.json').write_text(json.dumps(dict(status='pass',primary_throughput_eligible=False,scope='Four resident 0.8B rounds exercise off/on/on/off frame-policy overrides and serial output consistency. Shape is deliberately ineligible for the 4B kernel, so observed FFN calls remain zero. Original caps retained. Not a performance comparison.',driver_sha256=sha(Path(__file__)),report=str(p.relative_to(out)),report_sha256=sha(p)),indent=2)+'\n')
print('ENGINE81 RESIDENT FFN ROUNDS QUALIFICATION DONE',flush=True)
