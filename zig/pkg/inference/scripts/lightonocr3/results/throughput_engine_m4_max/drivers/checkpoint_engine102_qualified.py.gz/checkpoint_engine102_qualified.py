from pathlib import Path
import datetime,hashlib,json,os,psutil,signal,subprocess,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();a=o/'engine102_checkpoint_audit.json';assert not a.exists();d=dict(status='checking_own_waiter',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)))
def save():a.write_text(json.dumps(d,indent=2)+'\n')
f=json.loads((v/'engine102-freeze.json').read_text());assert all(sha(r/p)==h for p,h in f.items());assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='feat/lightonocr3-08b';assert json.loads((o/'engine102_mixed_screen84_audit.json').read_text())['status']=='mixed_screen_pass'
waiters=[]
for p in psutil.process_iter(['cmdline']):
 try:
  c=p.info['cmdline']or[]
  if len(c)==2 and Path(p.cwd(),c[1]).resolve()==v/'run_engine102_primary85.py':waiters.append(p)
 except(psutil.NoSuchProcess,psutil.AccessDenied):pass
assert len(waiters)==1;p=waiters[0];d['waiter_pid']=p.pid
if p.children(recursive=True):d['status']='declined_primary_child_active';save();print(d);sys.exit(0)
os.kill(p.pid,signal.SIGSTOP)
try:
 if p.children(recursive=True):d['status']='declined_child_raced_stop';save();sys.exit(0)
 d['status']='paused_own_child_free_waiter';save();print('PAUSED',p.pid,flush=True)
 subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine102_08_mixed_screen83*','engine102_4b_mixed_screen83*','engine102_4b_mixed_screen84*'],check=True)
 ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
 logs=[q for q in Path('/private/tmp').glob('ocr-engine102-*.txt')if not any(x in q.name for x in ['primary85','checkpoint'])]
 ns['archive']('qualification',logs,'logs_manifest.json')
 drivers=[q for q in v.glob('*engine102*')if q.is_file()and q.suffix in ['.py','.json','.m','.inc','.metal']and q.name!=Path(__file__).name]
 drivers += [v/'archive_completed_engine96_101.py']
 ns['archive']('drivers',drivers,'drivers_manifest.json')
 c=json.loads((o/'engine91_c_build_manifest.json').read_text());assert all(sha(r/q)==h for q,h in c['input_sha256'].items());assert sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')=='ab7db0fab1cab774c127bf2a32560a4879980a29b4405f19ac75f4d70012ef83'
 q=dict(scope='Source102 defaultOFF regression plus exact0.8B C16/R32 and4B C63/R128 packedmixed screens. 4BC64fullcontentpassesbutadmissionpressureexcludesrate. C91arithmetic/checker/headersunchanged;20C suitesreusedafterexactinputhashverification. No freshwarmedactualvLLMcomparisonhasstarted;4Bspeedobjectivepending.',cpu=dict(passed=292,skipped=38),metal=dict(passed=328,skipped=6),source_inputs_sha256=sha(v/'engine102-freeze.json'),c_qualification_manifest_sha256=sha(o/'engine91_c_build_manifest.json'),small_report_sha256=sha(o/'engine102_08_mixed_screen83_p1_c16_r32/report.json'),large_report_sha256=sha(o/'engine102_4b_mixed_screen84_p1_c63_r128/report.json'))
 (o/'engine102_qualification_audit.json').write_text(json.dumps(q,indent=2)+'\n')
 readme=o/'README.md';s=readme.read_text();s+='''\n\nSource102 keeps mixed greedy decode token choices on the GPU and downloads\nfull logits only for prefills. It validates the complete publication layout\nbefore exposing results and admits the actual independent prefix-logit\nlifetime. A separate decode head frame preserves F32 head inputs. It passes\n328 Metal-enabled tests (six skips) and 292 CPU tests (38 skips; broader\nfilter selection than source101). The unchanged C91 inputs are verified\nbefore reusing its 20 C suites. All 32 small-model outputs match exactly;\nits 307 mixed decode rows use GPU choices and only 32 prefix rows reach CPU\nlogits. The 4B C64 run returns all 128 outputs but records four transient\nshared-cap pressure events and is excluded. C63/R128 passes all 128 outputs\nwithout pressure at 1.1031 pages/s. This remains a cold screen, not a matched\nvLLM win. A preregistered warmed opening/native/closing comparison is pending\nthe original memory reserve. Packed execution stays opt-in.\n''';readme.write_text(s)
 assert all(sha(r/q)==h for q,h in f.items());d['status']='committing';save()
 production=['zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py','zig/pkg/inference/src/architectures/gpt.zig','zig/pkg/inference/src/pipelines/generation.zig','zig/pkg/inference/src/runtime/scheduler/native_generate.zig','zig/pkg/inference/src/server/server.zig']
 subprocess.run(['git','add','--',*production,str(o.relative_to(r))],check=True)
 for name in ['paired85_4b_warmed_comparison_audit.json','engine102_checkpoint_audit.json']:subprocess.run(['git','restore','--staged','--',str((o/name).relative_to(r))],check=True)
 subprocess.run(['git','diff','--cached','--check'],check=True)
 subprocess.run(['git','commit','-m','Batch mixed OCR state and keep greedy decode choices on GPU'],check=True)
 assert all(sha(r/q)==h for q,h in f.items());d['commit']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();d['status']='pushing';save();subprocess.run(['git','push','origin','HEAD'],check=True)
 d['status']='pushed';save();print('PUSHED102',d['commit'],flush=True)
finally:
 if all(sha(r/q)==h for q,h in f.items()):os.kill(p.pid,signal.SIGCONT);d['waiter_resumed']=True;print('RESUMED',p.pid,flush=True)
 else:os.kill(p.pid,signal.SIGTERM);os.kill(p.pid,signal.SIGCONT);d['waiter_retired_source_changed']=True
 save()
