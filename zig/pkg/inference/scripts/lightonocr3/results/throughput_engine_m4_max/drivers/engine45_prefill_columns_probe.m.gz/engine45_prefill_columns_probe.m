#define main production_checks_main
#include "engine45_prefill_columns_probe_checks.m"
#undef main
int main(int argc,char**argv){@autoreleasepool{
 if(argc!=2)return 1;
 size_t columns=(size_t)strtoul(argv[1],NULL,10);if(columns!=8&&columns!=16)return 2;
 unsetenv("TERMITE_METAL_DISABLE_QWEN35_PREFILL_COLUMNS");
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 3;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);
 termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 r->prefill_columns_probe_pick=(uint32_t)columns;
 const size_t lengths[]={128,432,554,662,2048};
 for(size_t h=16;h<=32;h+=16)for(size_t i=0;i<5;i++){
  int rc=prefill_core_check(r,lengths[i],h,true,true);
  if(rc){fprintf(stderr,"PREFILL_COLUMNS_FAIL columns=%zu heads=%zu seq=%zu rc=%d\n",columns,h,lengths[i],rc);return 20+rc;}
 }
 termite_metal_decode_runtime_destroy(r);
}return 0;}
