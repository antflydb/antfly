from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal')
variants=[(32,16,2),(32,32,2),(32,32,4),(64,16,4),(64,32,4),(64,64,8)]
header='#include <metal_stdlib>\n#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\nusing namespace metal;using namespace mpp::tensor_ops;\nstruct Params{uint rows,in_dim,out_dim,pad;};\n'
old=(v/'gate_mpp_probe.metal').read_text()
# Regenerate from the prior known mathematical template with explicit new tiles.
template=(v/'prepare_gate_mpp_probe.py').read_text()
start=template.index(" msl+=f'''")+len(" msl+=f'''")
end=template.index("'''",start)
body=template[start:end].replace(r'\n','\n')
msl=header
for i,(m,n,sg)in enumerate(variants):
 msl+=eval('f'+repr(body))
(v/'engine42_wide_ffn_probe.metal').write_text(msl)
kernels=Path('zig/pkg/inference/src/backends/metal_kernels.m').read_bytes()
(v/'engine42_ffn_probe_kernels.m').write_bytes(kernels)
checker=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine42_ffn_probe_kernels.m"')
(v/'engine42_ffn_probe_checks.m').write_text(checker)
s=(v/'gate_mpp_probe.m').read_text().replace('#include "../zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m"','#include "engine42_ffn_probe_checks.m"')
a=s.index('static int run_gate(');b=s.index('static int probe_gate(',a)
s=s[:a]+'''static int run_gate(termite_metal_decode_runtime*r,id<MTLComputePipelineState>p,size_t n,size_t m,size_t sg,size_t rows,size_t in,size_t out,id<MTLBuffer>x,id<MTLBuffer>y,double*us){
 id<MTLBuffer>zero=[r->device newBufferWithLength:rows*in*4 options:MTLResourceStorageModeShared];
 id<MTLBuffer>device_input=[r->device newBufferWithLength:(rows*in+4)*4 options:MTLResourceStorageModePrivate];
 if(!zero||!device_input)return 10;memset(zero.contents,0,rows*in*4);
 if(p&&(p.threadExecutionWidth!=32||p.maxTotalThreadsPerThreadgroup<sg*32||p.staticThreadgroupMemoryLength>r->device.maxThreadgroupMemoryLength))return 11;
 uint64_t before=r->frame_gpu_nanos;
 if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_DECODE))return 12;
 if(termite_metal_decode_runtime_apply_add_device(r,(__bridge void*)x,16,(__bridge void*)zero,0,rows*in,(__bridge void*)device_input,16))return 13;
 if(termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_FFN,TERMITE_METAL_COMPUTE_REGION_FFN))return 14;
 if(!p){
  if(termite_metal_decode_runtime_apply_bf16_gate_up_device(r,0,1,(__bridge void*)device_input,16,rows,in,out,(__bridge void*)y,16))return 15;
 }else{
  id<MTLComputeCommandEncoder>e=r->active_planned_compute_encoder;if(!e)return 16;
  termite_metal_linear_params params={(uint32_t)rows,(uint32_t)in,(uint32_t)out,0};
  [e setComputePipelineState:p];[e setBuffer:device_input offset:16 atIndex:0];
  [e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_weight_buffers[1] offset:0 atIndex:2];
  [e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:3];[e setBuffer:r->linear_bias_buffers[1] offset:0 atIndex:4];
  [e setBuffer:y offset:16 atIndex:5];[e setBytes:&params length:sizeof(params) atIndex:6];
  [e dispatchThreadgroups:MTLSizeMake((out+n-1)/n,(rows+m-1)/m,1) threadsPerThreadgroup:MTLSizeMake(sg*32,1,1)];
 }
 if(termite_metal_decode_runtime_end_planned_compute_scope(r)||termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r))return 17;
 *us=(r->frame_gpu_nanos-before)/1000.0;return 0;
}
'''+s[b:]
s=s.replace('run_gate(r,nil,0,0,rows','run_gate(r,nil,0,0,0,rows')
s=s.replace('const size_t ns[6]={8,16,32,32,64,64},sgs[6]={1,1,1,2,2,4};','const size_t ms[6]={32,32,32,64,64,64},ns[6]={16,32,32,16,32,64},sgs[6]={2,2,4,4,4,8};')
s=s.replace('run_gate(r,on?p[variant]:nil,ns[variant],sgs[variant],rows','run_gate(r,on?p[variant]:nil,ns[variant],ms[variant],sgs[variant],rows')
s=s.replace('trial<8','trial<20').replace('total/8','total/20')
s=s.replace('GATE_MPP','WIDE_FFN_MPP').replace('GATE_PROBE_FAIL','WIDE_FFN_PROBE_FAIL')
s=s.replace('gate_mpp_probe.metal','engine42_wide_ffn_probe.metal')
s=s.replace('opts.fastMathEnabled=NO;','opts.fastMathEnabled=NO;opts.mathMode=MTLMathModeSafe;')
s=s.replace('const size_t rows[]={4,8,9,12,16};for(size_t i=0;i<5;i++)','const size_t rows[]={32,33,48,56,63,64};for(size_t i=0;i<6;i++)')
(v/'engine42_wide_ffn_probe.m').write_text(s)
manifest=dict(status='prepared_only_not_compiled_or_run',base_engine='engine41',c_source_sha256=hashlib.sha256(kernels).hexdigest(),variants=variants,rows=[32,33,48,56,63,64],trials_per_ABBA_leg=20,checks='Full outputs and CPU corners within2e-4, prefix/suffix canaries, nonzero offsets, actual GPU producer, same planned frame for baseline and candidate.',reason='Prepared C linear blocks already fuse gate/up for rows>=32 using the generic SIMD BF16 kernel. Probe MPP fused tiles against that actual baseline; do not assume fusion is absent.')
(v/'engine42-wide-ffn-probe-plan.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Prepared ignored wide-FFN probe only. Compile/run only after primary GPU jobs finish.')
