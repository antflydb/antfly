#define main engine75_unused_main
#include "engine75_probe_checks.m"
#undef main
#include "engine75_recurrent_source.inc"
#define LAYERS72 24
#define PAGES72 64
typedef struct {
 id<MTLBuffer> buffers[LAYERS72][PAGES72][15];
 void *handles[LAYERS72][PAGES72][15];
 float *gold[LAYERS72][PAGES72][6];
} Working72;
static const size_t writes72[]={7,8,9,10,11,14};
static int select72(termite_metal_decode_runtime*r,id<MTLComputePipelineState> __strong *psos,int mode){
 engine72_threads=512;
 r->lightonocr3_recurrent_parallel_pipeline=psos[mode];
 return !psos[mode]||psos[mode].maxTotalThreadsPerThreadgroup<engine72_threads;
}
static void fill72(Working72*w,size_t pages,const size_t*counts){
 for(size_t l=0;l<LAYERS72;l++)for(size_t p=0;p<pages;p++)for(size_t j=0;j<15;j++){
  float pattern[256];for(size_t i=0;i<256;i++)pattern[i]=j==13?.5f+(i%7)*.1f:sinf(i*.013f+j+l*.17f+p*.03f)*.1f;
  float*dst=(float*)w->buffers[l][p][j].contents+4;
  for(size_t i=0;i<counts[j];i+=256)memcpy(dst+i,pattern,MIN((size_t)256,counts[j]-i)*4);
 }
}
static int frame72(termite_metal_decode_runtime*r,Working72*w,size_t pages,size_t vh,const size_t*counts,double*gpu_us){
 size_t offsets[15];for(int j=0;j<15;j++)offsets[j]=16;
 uint64_t calls=r->lightonocr3_recurrent_parallel_dispatches;
 if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_OTHER,TERMITE_METAL_COMPUTE_REGION_OTHER))return 1;
 for(size_t l=0;l<LAYERS72;l++)for(size_t p=0;p<pages;p+=16){
  size_t rows=MIN((size_t)16,pages-p);
  if(rows>1&&termite_metal_decode_runtime_qwen35_core_batch_begin(r,rows)!=1)return 2;
  for(size_t i=0;i<rows;i++)if(termite_metal_decode_runtime_qwen35_core_device(r,w->handles[l][p+i],offsets,1,16,vh,128,4,1))return 3;
  if(rows>1&&termite_metal_decode_runtime_qwen35_core_batch_end(r))return 4;
 }
 if(termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r))return 5;
 if(r->lightonocr3_recurrent_parallel_dispatches-calls!=LAYERS72*((pages+15)/16))return 6;
 *gpu_us=r->last_frame_gpu_nanos/1000.;
 for(size_t l=0;l<LAYERS72;l++)for(size_t p=0;p<pages;p++){
  id<MTLBuffer>b=w->buffers[l][p][6];w->buffers[l][p][6]=w->buffers[l][p][7];w->buffers[l][p][7]=b;
  w->handles[l][p][6]=(__bridge void*)w->buffers[l][p][6];w->handles[l][p][7]=(__bridge void*)w->buffers[l][p][7];
 }
 return 0;
}
static int working72(termite_metal_decode_runtime*r,id<MTLComputePipelineState> __strong *psos,size_t pages){
 const size_t vh=32,channels=8192;
 const size_t counts[15]={channels,channels*4,vh,vh,vh,vh,channels*4,channels*4,vh*128*128,channels,vh*2,vh*128,vh*128,128,vh*128};
 Working72*w=calloc(1,sizeof(*w));if(!w)return 10;
 for(size_t l=0;l<LAYERS72;l++)for(size_t p=0;p<pages;p++)for(size_t j=0;j<15;j++){
  w->buffers[l][p][j]=[r->device newBufferWithLength:(counts[j]+8)*4 options:MTLResourceStorageModeShared];if(!w->buffers[l][p][j])return 11;
  w->handles[l][p][j]=(__bridge void*)w->buffers[l][p][j];
  for(size_t i=0;i<4;i++){((uint32_t*)w->buffers[l][p][j].contents)[i]=0xdeadbeef;((uint32_t*)w->buffers[l][p][j].contents)[counts[j]+4+i]=0xdeadbeef;}
 }
 for(int candidate=1;candidate<=1;candidate++)for(int leg=0;leg<4;leg++){
  int mode=(leg==0||leg==3)?0:candidate;
  if(select72(r,psos,mode))return 12;
  fill72(w,pages,counts);
  if(mode)for(size_t l=0;l<LAYERS72;l++)for(size_t p=0;p<pages;p++){
   float*state=(float*)w->buffers[l][p][8].contents+4;
   float temporary[128*128];
   for(size_t h=0;h<vh;h++){
    memcpy(temporary,state+h*128*128,sizeof(temporary));
    for(size_t k=0;k<128;k++)for(size_t c=0;c<128;c++)state[h*128*128+c*128+k]=temporary[k*128+c];
   }
  }
  double us;
  for(int warm=0;warm<2;warm++){int rc=frame72(r,w,pages,vh,counts,&us);if(rc)return 20+rc;}
  double times[8];
  for(int t=0;t<8;t++){int rc=frame72(r,w,pages,vh,counts,&times[t]);if(rc)return 30+rc;}
  float error=0;size_t checked=0;
  for(size_t l=0;l<LAYERS72;l++)for(size_t p=0;p<pages;p++){
   for(size_t j=0;j<15;j++)for(size_t i=0;i<4;i++)if(((uint32_t*)w->buffers[l][p][j].contents)[i]!=0xdeadbeef||((uint32_t*)w->buffers[l][p][j].contents)[counts[j]+4+i]!=0xdeadbeef)return 40;
   for(size_t a=0;a<6;a++){
    // History buffers were swapped after the frame, so the current history is slot6.
    size_t j=writes72[a],actual=j==7?6:j;float*got=(float*)w->buffers[l][p][actual].contents+4;
    if(leg==0){
     if(!w->gold[l][p][a])w->gold[l][p][a]=malloc(counts[j]*4);
     if(!w->gold[l][p][a])return 41;
     memcpy(w->gold[l][p][a],got,counts[j]*4);
    }else for(size_t i=0;i<counts[j];i++){
     size_t physical=(mode && j==8)?(i/(128*128))*(128*128)+(i%128)*128+(i/128)%128:i;
     if(!isfinite(got[physical])||!isfinite(w->gold[l][p][a][i]))return 42;
     error=fmaxf(error,fabsf(got[physical]-w->gold[l][p][a][i]));
    }
    checked+=counts[j];
   }
  }
  if(error>2e-4f){fprintf(stderr,"ERROR mode=%d abs=%g\n",mode,error);return 43;}
  printf("{\"pages\":%zu,\"layers\":24,\"heads\":32,\"candidate\":%d,\"leg\":%d,\"mode\":%d,\"threads\":%lu,\"checked_elements\":%zu,\"full_output_state_max_abs\":%.9g,\"gpu_us\":[",pages,candidate,leg,mode,engine72_threads,checked,error);
  for(int t=0;t<8;t++)printf("%s%.6f",t?",":"",times[t]);
  printf("]}\n");fflush(stdout);
 }
 for(size_t l=0;l<LAYERS72;l++)for(size_t p=0;p<pages;p++){
  for(size_t j=0;j<15;j++)w->buffers[l][p][j]=nil;
  for(size_t a=0;a<6;a++)free(w->gold[l][p][a]);
 }
 free(w);return 0;
}
int main(void){@autoreleasepool{
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_RECURRENT_PARALLEL");unsetenv("TERMITE_METAL_DISABLE_QWEN35_FUSED_DECODE");
 setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL","1",1);
 id<MTLComputePipelineState>psos[3];psos[0]=r->lightonocr3_recurrent_parallel_pipeline;
 for(int i=1;i<=1;i++){
  MTLCompileOptions*opt=[MTLCompileOptions new];opt.languageVersion=MTLLanguageVersion3_1;opt.fastMathEnabled=NO;opt.mathMode=MTLMathModeSafe;NSError*err=nil;
  id<MTLLibrary>lib=[r->device newLibraryWithSource:engine75_source options:opt error:&err];
  if(!lib){fprintf(stderr,"%s\n",err.localizedDescription.UTF8String);return 2;}
  psos[i]=termite_metal_make_pipeline(r->device,lib,@"engine75_value_major");if(!psos[i])return 3;
  fprintf(stderr,"PSO mode=%d shared=%lu max_threads=%lu\n",i,(unsigned long)psos[i].staticThreadgroupMemoryLength,(unsigned long)psos[i].maxTotalThreadsPerThreadgroup);
  if(select72(r,psos,i))return 4;
  // Layout prototype: staged canonical-state conformance cannot qualify this PSO.
  // The ABBA harness below transposes initial state and compares every logical
  // output/state element after ten continued steps, plus all buffer canaries.
  // Full runtime layout interop is required separately before any promotion.
  fprintf(stderr,"LAYOUT PROTOTYPE READY mode=%d\n",i);
 }
 const char *requested = getenv("ENGINE75_PAGES"); const size_t pages[]={requested ? (size_t)strtoul(requested,NULL,10) : 0};
 for(int i=0;i<1;i++){if(!pages[i])continue;if(pages[i]!=33 && pages[i]!=48 && pages[i]!=64)return 90;int rc=working72(r,psos,pages[i]);if(rc)return rc;}
 termite_metal_decode_runtime_destroy(r);return 0;
}}
