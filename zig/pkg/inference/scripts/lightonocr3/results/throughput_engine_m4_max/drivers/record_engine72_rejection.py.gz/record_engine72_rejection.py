from pathlib import Path
import hashlib,json,statistics,datetime
r=Path.cwd();o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';p=o/'engine72_recurrent_probe_audit.json';d=json.loads(p.read_text());rows=[]
for case in d['checks']:
 if not case.get('records'):continue
 for candidate in [1,2]:
  records=[x for x in case['records'] if x['candidate']==candidate]
  a=[t for x in records if x['mode']==0 for t in x['gpu_us']];b=[t for x in records if x['mode']==candidate for t in x['gpu_us']]
  rows.append(dict(pages=case['pages'],candidate=candidate,baseline_median_us=statistics.median(a),candidate_median_us=statistics.median(b),candidate_to_baseline_duration_ratio=statistics.median(b)/statistics.median(a),maximum_absolute_error=max(x['full_output_state_max_abs']for x in records)))
p=o/'engine72_recurrent_probe_review.json';assert not p.exists();p.write_text(json.dumps(dict(decision='rejected',reason='Every candidate is slower in both completed large working sets. No production shader changes.',primary_throughput_eligible=False,audit_sha256=hashlib.sha256((o/'engine72_recurrent_probe_audit.json').read_bytes()).hexdigest(),comparisons=rows),indent=2)+'\n')
for row in rows:print(row)
