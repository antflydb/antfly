from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
s=(v/'engine46_reading_formatted.zig').read_text()
a=s.index('fn decodeNativeFlorenceBatchIncrementalFromEncoder(')
b=s.index('        var finished_count: usize = 0;',a)
s=s[:b]+'''        // Exercise cache/frame cleanup and the caller's supplemental admission
        // with real checkpoint tensors; this hook is absent from production.
        if (comptime @import("builtin").is_test) {
            if (platform.env.getenvBool("ANTFLY_TEST_FLORENCE2_INCREMENTAL_FALLBACK"))
                return error.UnsupportedOperation;
        }

'''+s[b:]
needle='        const result = try self.decodeNativeFlorenceBatchFromEncoder(cb, florence_cfg, encoder.hidden, batch, encoder.seq_len);'
assert s.count(needle)==1
s=s.replace(needle,'''        if (platform.env.getenvBool("ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX"))
            std.debug.print("FLORENCE2 full_prefix_decode_started=1\\n", .{});
'''+needle)
# Python literal above must produce the MSL/Zig escaped newline, not a physical
# newline within its string literal.
s=s.replace('std.debug.print("FLORENCE2 full_prefix_decode_started=1\n", .{});','std.debug.print("FLORENCE2 full_prefix_decode_started=1\\n", .{});')
s=s.replace('''        // The invocation admits incremental logits and the full decoder/KV
        // storage. Its caller admits a supplement before a full-prefix fallback.''','''        // The caller admits incremental or full-prefix logits and full KV.
        // A larger fallback peak is admitted before entering that decoder.''')
p=v/'engine46_reading_fallback_verified.zig';assert not p.exists();p.write_text(s)
s=(v/'run_engine46_florence_admission_case.py').read_text()
s=s.replace("n=max(32,b) if mode=='qualification' else 128","n=(64 if b>=24 else 32) if mode=='qualification' else 128")
p=v/'run_engine46_florence_admission_case_verify.py';assert not p.exists();p.write_text(s)
print('Prepared test-only real cache/frame fallback hook; runtime still unchanged.')
