#define main production_checks_main
#include "../zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m"
#undef main
static id<MTLBuffer> packed_input;
static int dispatch_probe(termite_metal_decode_runtime*r,id<MTLComputePipelineState> p,size_t sn,size_t tm,size_t rows,size_t in,size_t out,id<MTLBuffer>x,id<MTLBuffer>y,double*gpu_us){
 id<MTLCommandBuffer> cb=[r->queue commandBuffer];id<MTLComputeCommandEncoder> e=[cb computeCommandEncoder];if(!e)return 1;
 termite_metal_linear_params params={(uint32_t)rows,(uint32_t)in,(uint32_t)out,0};
 uint32_t count=(uint32_t)(rows*in);[e setComputePipelineState:r->lightonocr3_pack_bf16_pipeline];[e setBuffer:x offset:16 atIndex:0];[e setBuffer:packed_input offset:0 atIndex:1];[e setBytes:&count length:4 atIndex:2];[e dispatchThreads:MTLSizeMake(count,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];[e memoryBarrierWithScope:MTLBarrierScopeBuffers];
 [e setComputePipelineState:p];[e setBuffer:packed_input offset:0 atIndex:0];[e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:2];[e setBuffer:y offset:16 atIndex:3];[e setBytes:&params length:sizeof(params) atIndex:4];
 [e dispatchThreadgroups:MTLSizeMake(out/sn,1,1) threadsPerThreadgroup:MTLSizeMake(tm*32,1,1)];[e endEncoding];[cb commit];[cb waitUntilCompleted];if(cb.status!=MTLCommandBufferStatusCompleted)return 2;*gpu_us=(cb.GPUEndTime-cb.GPUStartTime)*1e6;return 0;
}
static int probe(termite_metal_decode_runtime*r,id<MTLComputePipelineState> __strong pipelines[6],size_t rows,size_t in,size_t out){
 id<MTLBuffer>x=[r->device newBufferWithLength:(rows*in+8)*4 options:MTLResourceStorageModeShared],y=[r->device newBufferWithLength:(rows*out+12)*4 options:MTLResourceStorageModeShared];
 uint16_t*w=malloc(in*out*2);float*b=malloc(out*4),*gold=malloc(rows*out*4);if(!x||!y||!w||!b||!gold)return 1;
 float*v=(float*)x.contents+4,*got=(float*)y.contents+4;uint32_t state=123;for(size_t i=0;i<in*out;i++){state=state*1664525u+1013904223u;w[i]=round_bf16(((int)(state>>16)-32768)*.000001f);}for(size_t i=0;i<rows*in;i++)v[i]=expand_bf16(round_bf16(sinf(i*.013f)*.7f));for(size_t i=0;i<out;i++)b[i]=cosf(i*.019f)*.2f;
 if(termite_metal_decode_runtime_prepare_linear_bf16(r,0,(uint8_t*)w,in*out*2,b,in,out))return 2;
 if(apply_projection(r,rows,in,out,x,4,y))return 3;memcpy(gold,got,rows*out*4);
 for(size_t row=0;row<rows;row+=rows-1)for(size_t col=0;col<out;col+=out/2-1){double ref=b[col];for(size_t k=0;k<in;k++){uint32_t bits=(uint32_t)w[col*in+k]<<16;float value;memcpy(&value,&bits,4);ref+=(double)v[row*in+k]*value;}if(fabs(gold[row*out+col]-ref)>2e-4)return 11;}
 const size_t sns[6]={8,16,32,32,64,64},tms[6]={1,1,1,2,2,4};
 for(size_t variant=0;variant<6;variant++){
  if(!pipelines[variant]||pipelines[variant].maxTotalThreadsPerThreadgroup<tms[variant]*32)return 4;
  for(size_t round=0;round<4;round++){
   bool on=round==1||round==2;double elapsed=0;float worst=0;
   for(size_t trial=0;trial<12;trial++){
    for(size_t i=0;i<4;i++)((uint32_t*)y.contents)[i]=0xdeadbeefu;for(size_t i=rows*out+4;i<rows*out+12;i++)((uint32_t*)y.contents)[i]=0xcafebabeu;
    if(on){double us=0;if(dispatch_probe(r,pipelines[variant],sns[variant],tms[variant],rows,in,out,x,y,&us))return 5;elapsed+=us;}
    else{uint64_t before=r->frame_gpu_nanos;if(apply_projection(r,rows,in,out,x,4,y))return 6;elapsed+=(r->frame_gpu_nanos-before)/1000.0;}
    for(size_t i=0;i<rows*out;i++){if(!isfinite(got[i]))return 7;worst=fmaxf(worst,fabsf(got[i]-gold[i]));}
    for(size_t i=0;i<4;i++)if(((uint32_t*)y.contents)[i]!=0xdeadbeefu)return 8;for(size_t i=rows*out+4;i<rows*out+12;i++)if(((uint32_t*)y.contents)[i]!=0xcafebabeu)return 9;
   }
   if(worst>2e-4f)return 10;fprintf(stderr,"BF16_TILE rows=%zu in=%zu out=%zu variant=%zu on=%d round=%zu gpu_us=%.3f max_abs=%g\n",rows,in,out,variant,on,round,elapsed/12,worst);
  }
 }
 free(w);free(b);free(gold);return 0;
}
int main(void){@autoreleasepool{
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);packed_input=[r->device newBufferWithLength:16*9216*2 options:MTLResourceStorageModePrivate];if(!packed_input)return 9;
 NSError*err=nil;NSString*source=[NSString stringWithContentsOfFile:@".venv-lighton-vllm-metal/bf16_tile_probe.metal" encoding:NSUTF8StringEncoding error:&err];MTLCompileOptions*opts=[MTLCompileOptions new];opts.fastMathEnabled=NO;opts.languageVersion=MTLLanguageVersion4_0;id<MTLLibrary>lib=[r->device newLibraryWithSource:source options:opts error:&err];if(!lib){fprintf(stderr,"MSL_ERROR %s\n",err.description.UTF8String);return 2;}
 id<MTLComputePipelineState> p[6];const size_t sns[6]={8,16,32,32,64,64},tms[6]={1,1,1,2,2,4};for(size_t i=0;i<6;i++){p[i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"wide_mpp_%zu",i]);}
 const size_t shapes[][2]={{1024,6144},{1024,2048},{2048,1024},{1024,4096},{2560,8192},{2560,4096},{4096,2560},{2560,1024},{3584,1024},{9216,2560},{1024,3584},{2560,9216}};
 for(size_t rows=8;rows<=16;rows+=8)for(size_t shape=0;shape<sizeof(shapes)/sizeof(shapes[0]);shape++){int rc=probe(r,p,rows,shapes[shape][0],shapes[shape][1]);if(rc){fprintf(stderr,"MPP_PROBE_FAIL rows=%zu shape=%zu rc=%d\n",rows,shape,rc);return 10+rc;}}
 termite_metal_decode_runtime_destroy(r);
}return 0;}
