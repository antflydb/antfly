from pathlib import Path
import json,hashlib,gzip,collections
s=Path('.venv-lighton-vllm-metal/archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")])
archive('qualification',list(Path('/private/tmp').glob('ocr-engine25*.txt')),'logs_manifest.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
for p in sorted(out.glob('engine25_*/report.json')):
 d=json.loads(p.read_text());r=d['results'][0];item=dict(report=str(p.relative_to(out)),sha256=sha(p),status=r['status'],primary_throughput_eligible=r['status']=='ok')
 if r['status']=='ok':
  assert r['serial_reference_parity'] and r['cross_runtime_content_parity'] and not d['own_cpu_compile_overlap']
  samples=r['policy_rounds'];assert len(samples)==1;s=samples[0];assert s['completed']==128 and not s['admission_pressures']
  item.update(pages_per_second=s['pages_per_second'],completed=128,exact_native_and_cross_runtime_text=True,own_cpu_compile_overlap=False,prefill_group_sizes=dict(collections.Counter(x['items']for x in s['prefill_batches'])))
 else:
  audit=p.parent/'admission_audit.json';assert audit.exists();item.update(admission_audit=str(audit.relative_to(out)),admission_audit_sha256=sha(audit),scope='Failed under unchanged 8 GiB scratch cap; no partial throughput.')
 records.append(item)
(out/'engine25_comparison_audit.json').write_text(json.dumps(dict(scope='Single-frame32 is flat. Longer prefill collection regresses before readiness fix. Vision grouping fails C32 scratch admission; caps unchanged. No fresh repeated vLLM win established.',reports=records),indent=2)+'\n')
index=out/'raw_logs_manifest.json';mapping=json.loads(index.read_text())
for folder in out.glob('engine25_*'):
 if not folder.is_dir():continue
 for p in folder.glob('*.txt'):
  raw=p.read_bytes();dest=p.with_name(p.name+'.gz');packed=gzip.compress(raw,mtime=0);dest.write_bytes(packed);assert gzip.decompress(packed)==raw
  mapping[str(p.relative_to(out))]={'compressed_path':str(dest.relative_to(out)),'raw_sha256':hashlib.sha256(raw).hexdigest(),'raw_bytes':len(raw),'compressed_sha256':sha(dest)};p.unlink()
index.write_text(json.dumps(mapping,indent=2)+'\n')
archive('drivers',[v/'archive_engine25_evidence.py'],'drivers_manifest.json')
print('engine25 archived',len(records),'reports')
