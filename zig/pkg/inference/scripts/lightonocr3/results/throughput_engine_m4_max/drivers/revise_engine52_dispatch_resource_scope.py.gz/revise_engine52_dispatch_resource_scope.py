from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text()
s=s.replace('typedef struct { uintptr_t key; uint8_t usage; } termite_metal_lighton_resource_entry;','''typedef struct { uintptr_t key; uint8_t usage; } termite_metal_lighton_resource_entry;
typedef struct {
    termite_metal_lighton_resource_entry entries[512];
    size_t count;
} termite_metal_lighton_resource_cache;
_Static_assert(sizeof(termite_metal_lighton_resource_cache) <= 8256, "bounded dispatch resource metadata");''')
a=s.index('    // Fixed 8 KiB host metadata;');b=s.index('    uint64_t lighton_resource_declaration_stats[4];',a)
s=s[:a]+'    // Counters only; deduplication metadata stays on the dispatch stack.\n'+s[b:]
a=s.index('// Resource usage declarations are monotonic');b=s.index('// 0 declines before encoding, 1 encoded, negative values report a frame error.',a)
s=s[:a]+(v/'engine52_resource_declarations_verify2.inc').read_text()+'\n'+s[b:]
p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text()
a=s.index('static int recurrent_resource_cache_check(void)');b=s.index('int main(int argc, const char **argv)',a)
s=s[:a]+(v/'engine52_resource_declaration_checks_verify2.inc').read_text()+'\n'+s[b:];p.write_text(s)
record=dict(status='review_revised_before_build',scope='Per-dispatch exact-object deduplication and complete read/write union; no cross-dispatch cached permissions or ownership/lifetime assumptions. Original GPU shader text unchanged. Fixed <=8256 byte stack set plus bounded arrays, only32 bytes added persistent counters. Initial encoder cache proposal never compiled or executed.',references=['https://developer.apple.com/documentation/metal/mtlcomputecommandencoder/useresources(_:usage:)','https://developer.apple.com/documentation/metal/mtlcommandbufferdescriptor/retainedreferences'],reason='Other operations can reconfigure resource usage in one encoder; re-declare complete usage for every recurrent dispatch.')
(o/'engine52_resource_scope_review_audit.json').write_text(json.dumps(record,indent=2)+'\n')
print('Revised to per-dispatch scope before build')
