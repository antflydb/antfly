from pathlib import Path
import hashlib,json,re
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';src=r/'zig/pkg/inference/src/backends/metal_kernels.m';old=src.read_text();a=old.index('        "kernel void termite_lightonocr3_recurrent_parallel(');b=old.index('        "kernel void termite_lightonocr3_prefill_prepare_parallel',a);strings=[]
for line in old[a:b].splitlines():
 m=re.match(r'\s*(".*")\s*$',line)
 if m:strings.append(json.loads(m[1]))
s=''.join(strings);assert s.startswith('kernel void')and s.endswith('}\n');s=s.replace('termite_lightonocr3_recurrent_parallel','termite_lightonocr3_fused_prefill164')
needle='    uint ratio = p.value_heads / p.key_heads, kh = h / ratio;\n';assert s.count(needle)==1;s=s.replace(needle,needle+'''    uint channels=(2*p.key_heads+p.value_heads)*128;
    uint col=simd*TM;
    float4 previous[4][TM/4];
    for(uint i=0;i<4;i++)for(uint t=0;t<TM/4;t++)
        previous[i][t]=p.initialized?*((device const float4*)(state+h*128*128+(lane*4+i)*128+col+t*4)):float4(0);
    for(uint row=0;row<p.seq;row++) {
''')
needle='''                float x = t == 3 ? mixed[c] : (p.initialized ? history[c * 4 + t + 1] : 0.0f);''';assert needle in s;s=s.replace(needle,'''                int position=int(row)+int(t)-3;
                float x=position>=0?mixed[uint(position)*channels+c]:(p.initialized?history[c*4+uint(position+4)]:0.0f);''').replace('if (j == 2 || h % ratio == 0)\n                    next','if (row+1==p.seq && (j == 2 || h % ratio == 0))\n                    next')
s=s.replace('float x = a[h] + dt[h]','float x = a[row*p.value_heads+h] + dt[h]').replace('exp(-beta[h])','exp(-beta[row*p.value_heads+h])').replace('gates[h * 2]','gates[(row*p.value_heads+h)*2]').replace('gates[h * 2 + 1]','gates[(row*p.value_heads+h)*2+1]')
s=s.replace('conv[kh * 128 + d]','conv[row*channels+kh * 128 + d]').replace('conv[(p.key_heads + kh) * 128 + d]','conv[row*channels+(p.key_heads + kh) * 128 + d]').replace('conv[2 * p.key_heads * 128 + h * 128 + d]','conv[row*channels+2 * p.key_heads * 128 + h * 128 + d]')
needle='''    uint col = simd * TM;
    float4 memories[TM / 4], previous[4][TM / 4], outputs[TM / 4];''';assert needle in s;s=s.replace(needle,'    float4 memories[TM / 4], outputs[TM / 4];')
needle='''            float4 v = p.initialized
                           ? *((device const float4 *)(state + h * 128 * 128 + key * 128 + col + t * 4))
                           : float4(0);
            previous[i][t] = v * scales[2];''';assert needle in s;s=s.replace(needle,'            previous[i][t] *= scales[2];');needle='''            *((device float4 *)(state + h * 128 * 128 + key * 128 + col + t * 4)) = v;''';assert needle in s;s=s.replace(needle,'            previous[i][t] = v;')
s=s.replace('core + h * 128 + col','core + (row*p.value_heads+h) * 128 + col').replace('z + h * 128 + col','z + (row*p.value_heads+h) * 128 + col').replace('output + h * 128 + col','output + (row*p.value_heads+h) * 128 + col')
s=s[:-2]+'''    threadgroup_barrier(mem_flags::mem_threadgroup);
    }
    for(uint i=0;i<4;i++)for(uint t=0;t<TM/4;t++)
        *((device float4*)(state+h*128*128+(lane*4+i)*128+col+t*4))=previous[i][t];
}
'''
shader=v/'engine164_fused_prefix.metal';shader.write_text('#include <metal_stdlib>\nusing namespace metal;\nstruct CoreParams{uint seq,key_heads,value_heads,dim,kernel_size,initialized;};\nstruct CoreRow{device float*buffers[15];CoreParams params;};\n'+s)
helper='''
static id<MTLComputePipelineState> engine164_pipeline=nil;
static uint64_t engine164_calls=0;
static int engine164_apply(termite_metal_decode_runtime*r,void*const*handles,const size_t*offsets,size_t seq,size_t kh,size_t vh,size_t dim,size_t kernel,int initialized){
 if(!r||!r->active_frame_cb||!engine164_pipeline||seq<1||seq>2048||kh!=16||(vh!=16&&vh!=32)||dim!=128||kernel!=4)return -101;
 const size_t channels=(2*kh+vh)*128;
 const size_t counts[15]={seq*channels,channels*4,seq*vh,seq*vh,vh,vh,channels*4,channels*4,vh*128*128,seq*channels,seq*vh*2,seq*vh*128,seq*vh*128,128,seq*vh*128};
 termite_metal_lightonocr3_recurrent_row table={0};uint32_t params[6]={(uint32_t)seq,(uint32_t)kh,(uint32_t)vh,128,4,(uint32_t)initialized};memcpy(table.params,params,sizeof(params));
 __unsafe_unretained id<MTLResource> resources[15],writes[6];size_t nw=0;
 for(size_t j=0;j<15;j++){
 id<MTLBuffer>b=(__bridge id<MTLBuffer>)handles[j];size_t bytes=counts[j]*4;
 if(!b||offsets[j]%16||offsets[j]>b.length||bytes>b.length-offsets[j]||!b.gpuAddress)return -102;
 table.buffers[j]=b.gpuAddress+offsets[j];resources[j]=b;
 if(j==7||j==8||j==9||j==10||j==11||j==14)writes[nw++]=b;
 if(termite_metal_decode_runtime_retain_frame_resource(r,b))return -103;
 }
 // Private serial stage probe. Planned producers/cancellation/alias cases
 // still need separate qualification before any production integration.
 termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
 id<MTLComputeCommandEncoder>enc=termite_metal_tracked_compute_command_encoder_for(r->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_OTHER);
 if(!enc)return -104;
 [enc setComputePipelineState:engine164_pipeline];[enc setBytes:&table length:sizeof(table) atIndex:0];
 [enc useResources:resources count:15 usage:MTLResourceUsageRead];[enc useResources:writes count:nw usage:MTLResourceUsageWrite];
 [enc dispatchThreadgroups:MTLSizeMake(vh,1,1)threadsPerThreadgroup:MTLSizeMake(512,1,1)];[enc endEncoding];engine164_calls++;return 0;
}
'''
checks=(r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine164_fused_prefix_kernels.m"\n'+helper)
(v/'engine164_fused_prefix_kernels.m').write_text(old)
a=checks.index('static int prefill_core_check(');b=checks.index('static int compute_copy_check(',a);part=checks[a:b];part=part.replace('benchmark ? 2 : 4','2');a1=part.index('            if (variant == 0 || variant == 3)');b1=part.index('            uint64_t before =',a1);part=part[:a1]+'''            unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_CORE_NORM");
            uint64_t before_calls=engine164_calls;
'''+part[b1:];needle='''            if (termite_metal_decode_runtime_qwen35_core_device(r, handles[mode], offsets, seq, kh, vh, 128,
                                                                4, initialized) ||''';replacement='''            int rc=variant==1?engine164_apply(r,handles[mode],offsets,seq,kh,vh,128,4,initialized):termite_metal_decode_runtime_qwen35_core_device(r,handles[mode],offsets,seq,kh,vh,128,4,initialized);
            if (rc ||''';assert needle in part;part=part.replace(needle,replacement)
a1=part.index('            r->lightonocr3_prefill_prepare_pipeline = saved;');b1=part.index('            if (benchmark)\n',a1);part=part[:a1]+'''            if(engine164_calls-before_calls!=(variant==1?1:0))return 10;
'''+part[b1:];# Remove now-unused reference counters from the cloned check.
part=part.replace('            uint64_t before = r->lightonocr3_prefill_norm_dispatches;\n','').replace('            uint64_t short_before[2], short_after[2];\n            termite_metal_decode_runtime_lighton_short_prefill_stats(r, short_before);\n','');checks=checks[:a]+part+checks[b:];(v/'engine164_fused_prefix_checks.m').write_text(checks)
probe='''#define main unused_engine164_main
#include "engine164_fused_prefix_checks.m"
#undef main
int main(int argc,const char**argv){@autoreleasepool{
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 NSError*error=nil;NSString*source=[NSString stringWithContentsOfFile:@".venv-lighton-vllm-metal/engine164_fused_prefix.metal" encoding:NSUTF8StringEncoding error:&error];
 MTLCompileOptions*options=[[MTLCompileOptions alloc]init];options.fastMathEnabled=NO;
 id<MTLLibrary>library=[r->device newLibraryWithSource:source options:options error:&error];if(!library){fprintf(stderr,"COMPILE164 %s\\n",error.localizedDescription.UTF8String);return 2;}
 engine164_pipeline=termite_metal_make_pipeline(r->device,library,@"termite_lightonocr3_fused_prefill164");
 if(!engine164_pipeline||engine164_pipeline.threadExecutionWidth!=32||engine164_pipeline.maxTotalThreadsPerThreadgroup<512)return 3;
 const bool benchmark=argc==2&&strcmp(argv[1],"--benchmark")==0;
 const size_t qs[]={1,2,4,8,16,17,22,31,32,42,48,63,64,65,96,112,120,127,128,129,432,554,662,1024,2048};
 for(size_t h=16;h<=32;h+=16)for(size_t i=0;i<sizeof(qs)/sizeof(qs[0]);i++)for(size_t init=0;init<2;init++){
 if(benchmark&&qs[i]!=22&&qs[i]!=42&&qs[i]!=48&&qs[i]!=64&&qs[i]!=96&&qs[i]!=120&&qs[i]!=128&&qs[i]!=432&&qs[i]!=662)continue;
 int rc=prefill_core_check(r,qs[i],h,init,benchmark);if(rc){fprintf(stderr,"FAIL164 q=%zu h=%zu init=%zu rc=%d\\n",qs[i],h,init,rc);return rc+20;}
 }
 fprintf(stderr,"FUSED164 FULL CORE STATE INTERMEDIATE CANARY CHECKS PASS benchmark=%d\\n",benchmark);termite_metal_decode_runtime_destroy(r);return 0;
}}
''';(v/'engine164_fused_prefix_probe.m').write_text(probe)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();ps=[shader,*[v/f'engine164_fused_prefix_{x}.m'for x in ['kernels','checks','probe']],Path(__file__)];(v/'engine164_fused_prefix_preparation.json').write_text(json.dumps(dict(status='prepared_not_built_or_run',scope='Private F32 fused short-prefix recurrent core, adapted from existing512threaddecode kernel. Persistent state held in registers across tokens; full intermediate debugwrites retained. Same dtypes. Serial stage prototype only, not production-qualified for planned/cancel/alias cases. No canonical change.',canonical_c_sha256=sha(src),source_sha256={str(p):sha(p)for p in ps}),indent=2)+'\n');print('164 fusedprefix private sources prepared; canonical unchanged')
