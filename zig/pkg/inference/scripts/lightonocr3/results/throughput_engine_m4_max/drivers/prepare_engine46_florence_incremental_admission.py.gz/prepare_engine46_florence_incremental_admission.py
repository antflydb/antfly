from pathlib import Path
import hashlib,json,difflib
v=Path('.venv-lighton-vllm-metal');relative=Path('zig/pkg/inference/src/pipelines/reading.zig')
original=relative.read_text();s=original
a=s.index('    fn readBatchNativeFlorencePixels(');b=s.index('\n    fn decodeNativeFlorenceBatchIncrementalFromEncoder(',a);part=s[a:b]
needle='''        var run_permit: ?session_mod.RunPermit = null;
        defer if (run_permit) |*permit| permit.deinit();'''
assert part.count(needle)==1
part=part.replace(needle,needle+'''
        var fallback_permit: ?session_mod.RunPermit = null;
        defer if (fallback_permit) |*permit| permit.deinit();''')
old='''        run_permit = try self.vision_encoder.admit(try nativeFlorenceRunRequest(
            florence_cfg,
            batch,
            pixel_values.len,
            prompt_i32.len,
            self.config.max_length,
        ));'''
new='''        const backend = self.vision_encoder.backend();
        const use_cached_decode = (backend == .native or backend == .cuda or backend == .metal) and
            !florenceKvCacheDisabled();
        const incremental_admission = if (comptime build_options.enable_metal)
            use_cached_decode and backend == .metal and
                @import("../backends/metal_runtime.zig").qualifiedM4DeviceDefault() and
                platform.env.getenvBoolDefault("ANTFLY_FLORENCE2_INCREMENTAL_ADMISSION", true)
        else
            false;
        const full_request = try nativeFlorenceRunRequest(
            florence_cfg, batch, pixel_values.len, prompt_i32.len, self.config.max_length);
        const request = if (incremental_admission)
            try nativeFlorenceIncrementalRunRequest(
                florence_cfg, batch, pixel_values.len, prompt_i32.len, self.config.max_length)
        else
            full_request;
        var fallback_attempts: usize = 0;
        var fallback_acquisitions: usize = 0;
        defer if (platform.env.getenvBool("ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX"))
            std.debug.print("FLORENCE2 incremental_admission={d} logits_rows={d} fallback_supplement_attempts={d} fallback_supplements_acquired={d}\\n",
                .{ @intFromBool(incremental_admission), if (incremental_admission) @as(usize, 1) else @max(self.config.max_length, 1), fallback_attempts, fallback_acquisitions });
        run_permit = try self.vision_encoder.admit(request);'''
assert part.count(old)==1;part=part.replace(old,new)
old='''        const backend = self.vision_encoder.backend();
        if ((backend == .native or backend == .cuda or backend == .metal) and !florenceKvCacheDisabled()) {'''
assert part.count(old)==1;part=part.replace(old,'        if (use_cached_decode) {')
needle='''        const result = try self.decodeNativeFlorenceBatchFromEncoder(cb, florence_cfg, encoder.hidden, batch, encoder.seq_len);'''
assert part.count(needle)==1
part=part.replace(needle,'''        if (incremental_admission) {
            // No full-prefix decoder or logits allocation may start until its
            // additional peak is admitted. Keep both permits through backend
            // teardown; the existing KV reservation is never reduced.
            fallback_attempts += 1;
            fallback_permit = try admitFlorenceFullPrefixFallback(
                self.vision_encoder, &run_permit.?, full_request);
            fallback_acquisitions += 1;
        }
'''+needle)
s=s[:a]+part+s[b:]
old='''        // This invocation already admits full-prefix logits and decoder/KV
        // storage. Keep each incremental decoder, head and reduction in one
        // frame; token publication and row compaction follow its completion.'''
new='''        // The invocation admits incremental logits and the full decoder/KV
        // storage. Its caller admits a supplement before a full-prefix fallback.
        // Token publication and row compaction follow frame completion.'''
assert s.count(old)==1;s=s.replace(old,new)
a=s.index('fn nativeFlorenceRunRequest(');b=s.index('\nfn compactDecoderInputIds(',a)
body=s[a:b]
body=body.replace('fn nativeFlorenceRunRequest(','fn nativeFlorenceRunRequestForLogits(',1)
old='''    max_length: usize,
) !session_mod.RunRequest {'''
assert body.count(old)==1;body=body.replace(old,'''    max_length: usize,
    logits_rows: usize,
) !session_mod.RunRequest {''')
old='''    const decoder_length = @max(max_length, 1);'''
assert body.count(old)==1
body=body.replace(old,old+'\n    if (logits_rows == 0 or logits_rows > decoder_length) return error.InvalidInputShape;')
old='const logits_bytes = try Checked.mul(try Checked.mul(batch, decoder_length),'
assert body.count(old)==1;body=body.replace(old,'const logits_bytes = try Checked.mul(try Checked.mul(batch, logits_rows),')
wrappers='''fn nativeFlorenceRunRequest(
    cfg: florence_arch.Config,
    batch: usize,
    pixel_count: usize,
    prompt_length: usize,
    max_length: usize,
) !session_mod.RunRequest {
    return nativeFlorenceRunRequestForLogits(
        cfg, batch, pixel_count, prompt_length, max_length, @max(max_length, 1));
}

fn nativeFlorenceIncrementalRunRequest(
    cfg: florence_arch.Config,
    batch: usize,
    pixel_count: usize,
    prompt_length: usize,
    max_length: usize,
) !session_mod.RunRequest {
    var request = try nativeFlorenceRunRequestForLogits(
        cfg, batch, pixel_count, prompt_length, max_length, 1);
    // decoder IDs, encoder/self masks, per-row state, and retained/compacting
    // cache descriptors are host-owned independently of the GPU logits/KV.
    const history_and_masks = std.math.add(usize,
        try std.math.mul(usize, max_length, 2), request.sequence) catch
        return error.ResourceLimitExceeded;
    const ids_and_masks = try std.math.mul(usize,
        try std.math.mul(usize, batch, history_and_masks), @sizeOf(i64));
    const per_row = @sizeOf(ReadResult) + 3 * @sizeOf(usize) + 2 * @sizeOf(i64) +
        3 * @sizeOf(u32) + @sizeOf(bool);
    const row_metadata = try std.math.mul(usize, batch, per_row);
    // Bound the CT/cache/view descriptors across active-row compaction, plus
    // a small invocation envelope. Full backing KV stays charged separately.
    const cache_metadata = try std.math.mul(usize, cfg.decoder_layers, 4096);
    request.host_preprocess_bytes = std.math.add(usize,
        try std.math.add(usize, ids_and_masks, row_metadata),
        try std.math.add(usize, cache_metadata, 64 * 1024)) catch
        return error.ResourceLimitExceeded;
    return request;
}

fn admitFlorenceFullPrefixFallback(
    session: backends.Session,
    base: *const session_mod.RunPermit,
    full_request: session_mod.RunRequest,
) !session_mod.RunPermit {
    var request = full_request;
    if (base.request) |owned|
        request.host_preprocess_bytes = @max(request.host_preprocess_bytes, owned.host_preprocess_bytes);
    const target = if (session.run_admission) |admission|
        try admission.estimateRequest(request, &.{})
    else
        @import("../runtime/tier/memory.zig").AdmissionAmounts{};
    return session.admitSupplement(base, target);
}

'''
s=s[:a]+wrappers+body+s[b:]
snapshot=v/'engine46_source_snapshot'/relative;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_text(s)
(v/'engine46-flores-admission-proposal-base.json').write_text(json.dumps({str(relative):hashlib.sha256(original.encode()).hexdigest()},indent=2)+'\n')
patch=''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/'+str(relative),tofile='b/'+str(relative)))
(v/'engine46_florence_incremental_admission.patch').write_text(patch)
print('Prepared offline reading proposal only. Actual runtime remains frozen engine45.')
