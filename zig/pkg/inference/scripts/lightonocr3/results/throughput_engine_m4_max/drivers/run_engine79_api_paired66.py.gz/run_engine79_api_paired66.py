from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import psutil

root = Path.cwd()
v = root / '.venv-lighton-vllm-metal'
(v/'engine79-paired66.pid').write_text(str(os.getpid()))
scripts = root / 'zig/pkg/inference/scripts/lightonocr3'
out = scripts / 'results/throughput_engine_m4_max'
source = out / 'engine71_prefill_batch_screen58_4b_r128_audit.json'
while True:
    parent=Path('/private/tmp/ocr-engine79-finalqualification-parent.txt')
    content=parent.read_text()if parent.exists()else''
    if 'Traceback' in content:raise RuntimeError(content[-3000:])
    if 'ENGINE79 FINAL QUALIFICATION DONE' in content:break
    time.sleep(5)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
profiles = json.loads((out/'paired59_4b_comparison_audit.json').read_text())['profiles']
for p,h in json.loads((v/'engine79-freeze.json').read_text()).items():assert sha(root/p)==h,p

record = dict(status='running', created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              scope='Balanced A16/A32/A64/guarded-full64/B/B/guarded-full64/A64/A32/A16 controls, retaining the faster measured API reference independently on each side. Experimental packed prefill FFN enabled on qualified source79. Merged origin/main with the highest-throughput eligible independently screened native policy across C64/C60/C56 and P1/P2/P4, synchronous VF3 vision and four-step native decode, original caps, full R128 outputs. API vLLM reference search at C16, C32 and C64, plus explicit 320-block C64 only when within EVERY automatic capacity, max_model_len1024, gpu_memory_utilization0.7, automatic cache sizing (no override). Both run before native; choose the faster current control, then reverse the native/reference order with that fixed configuration. Auto capacity, maximum supported concurrency, and memory probe are retained in each server log. Reference concurrency and admitted capacity may differ from native; this measures usable framework throughput on a shared machine, not equal-concurrency kernel FLOPS. Original weights, three unique-UUID uncached fixtures, R128, max_tokens256, fresh serial strings; no own compilation/profiling during timings.',
              profiles=profiles, comparisons=[], reference_candidates=[], source_audit_sha256=sha(source))
audit = out / 'paired66_4b_comparison_audit.json'
assert not audit.exists()
def save():
    audit.write_text(json.dumps(record, indent=2) + '\n')

def wait_model_headroom():
    while psutil.virtual_memory().available < 11348275670 + 6*1024**3 + 512*1024**2:
        print('WAIT 4B original memory admission headroom',psutil.virtual_memory().available,flush=True)
        time.sleep(30)

def reference(index, concurrency, blocks=None):
    wait_model_headroom()
    label = f'_primary_reference66_r{index}_{"auto" if blocks is None else "b"+str(blocks)}_c{concurrency}_r128_ctx1024'
    dest = out / ('vllm_4b' + label)
    assert not dest.exists()
    images = [root / 'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png', scripts / 'corpus/receipt.png', scripts / 'corpus/shipping.png']
    cmd = [sys.executable, str(scripts / 'benchmark_vllm_metal.py'), '--python', sys.executable,
           '--model-dir', str(v / 'ocr-models/lighton4b'), '--images', *map(str, images),
           '--concurrency', str(concurrency), '--requests', '128', '--max-tokens', '256', '--startup-timeout', '600', '--max-model-len', '1024', '--gpu-memory-utilization', '0.7', '--output-dir', str(dest)]
    if blocks is not None: cmd += ['--kv-cache-blocks', str(blocks)]
    print('START VLLM', index, concurrency, blocks, flush=True)
    with Path(f'/private/tmp/ocr-engine79-vllm-paired66-r{index}-c{concurrency}-b{blocks}.txt').open('w') as log:
        result = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT)
    p = dest / 'report.json'
    d = json.loads(p.read_text())
    if result.returncode:
        if blocks is not None and not d.get('cache_override_admission', {}).get('admitted', True):
            assert not d.get('results') and not d.get('references')
            record.setdefault('excluded_reference_attempts', []).append(dict(round=index, concurrency=concurrency, blocks=blocks, reason=d['cache_override_admission'], report=str(p.relative_to(out)), report_sha256=sha(p)))
            save(); print('EXCLUDED UNSAFE CACHE OVERRIDE', blocks, flush=True); return None
        raise RuntimeError(('reference failed', p, result.returncode))
    assert d['status'] == 'ok' and d['kv_cache_block_override'] == blocks and d['cache_override_admission']['admitted'] and d['results'][0]['serial_reference_parity']
    assert max(x['usage']['prompt_tokens'] for x in d['references'])+256<=1024
    print('DONE VLLM', index, concurrency, d['results'][0]['pages_per_second'], flush=True)
    return label, d, p

def native(key, index, oracle):
    wait_model_headroom()
    c, pref, vis, vf, sv, sp, q = profiles[key]['settings']
    label = f'paired66_{key}_r{index}_c{c}_p{pref}_v{vis}_vf{vf}_r128'
    dest = out / ('engine79_4b_' + label)
    assert not dest.exists()
    env = os.environ.copy()
    env.update(OCR_REFERENCE_LABEL=oracle, OCR_PHYSICAL32='0', OCR_PHYSICAL64='1', OCR_CONCURRENCY=str(c),
               OCR_REQUESTS='128', OCR_WIDE='1', OCR_KV_GIB='4', OCR_BACKEND_GIB='17', OCR_SCRATCH_GIB='10',
               OCR_CPU_PREPROCESS='1', OCR_PREFILL_DECODE_STREAK='0', OCR_POLICIES='engineepoch', OCR_SHARED_CORE='1',
               OCR_BF16_PREFILL='1', OCR_BF16='0', OCR_DISABLE_64_ROW_TILE='0', OCR_DISABLE_WIDE_GATE_UP='0',
               OCR_WIDE64_GATE_UP='1', OCR_FULL64_GATE_UP='1', OCR_GPU_GREEDY_STREAM='0', OCR_STREAM_CHUNK_LAYERS='0',
               OCR_VISION_BATCH=str(int(vis > 1)), OCR_VISION_BATCH_ITEMS=str(vis), OCR_VISION_WAIT_US='2000',
               OCR_PREFILL_BATCH=str(int(pref > 1)), OCR_PREFILL_BATCH_ITEMS=str(pref), OCR_PREFILL_WAIT_US=str(profiles[key].get('prefill_wait_us', 100000)),
               OCR_VISION_FRAME_BLOCKS=str(vf), OCR_SINGLE_FRAME='1', OCR_STREAM_FIRST='0', OCR_LOGICAL64='1',
               OCR_SHARED_DECODER_SCRATCH='1', OCR_DEVICE_RECURRENT_STATE='1', OCR_ENCODER_SCOPES='1', OCR_ADMISSION_UNITS='512',
               OCR_BATCH_ARGMAX='1', OCR_DEFER_VISION_SEAL=str(sv), OCR_DEFER_PREFILL_SEAL=str(sp),
               OCR_CACHE_VISION_WORKSPACE='1', OCR_LARGE_VISION_PACK_REUSE=str(int(vis > 1)),
               ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY=str(q), OCR_TIMEOUT='900')
    env['OCR_PREFILL_FUSED_FFN']='1'
    env['OCR_RESIDENT_VISION_BUDGET']='1'
    env['OCR_GPU_TOKEN_BURST']='1'
    env['OCR_GPU_TOKEN_BURST_WIDTH']='4'
    env['OCR_PIPELINE_VISION']=str(int(profiles[key]['pipeline_vision']))
    env['OCR_PREFILL_STREAM_LAYERS']=str(profiles[key]['prefill_stream_layers'])
    print('START NATIVE', key, index, profiles[key]['settings'], flush=True)
    with Path(f'/private/tmp/ocr-engine79-native-paired66-{key}-r{index}-driver.txt').open('w') as log:
        subprocess.run([sys.executable, str(v / 'run_engine79_budget_policies.py'), '4b:' + label], env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    p = dest / 'report.json'
    d = json.loads(p.read_text())
    result = d['results'][0]
    s = result['policy_rounds'][0]
    assert result['status'] == 'ok' and result['serial_reference_parity'] and result['cross_runtime_content_parity']
    assert s['prefill_fused_ffn_calls'] > 0
    assert s['completed'] == 128 and not s['admission_pressures'] and not d['own_cpu_compile_overlap']
    assert s['host_recurrent_bytes_total'] == s['single_frame_topology_mismatches'] == s['gpu_greedy_stream_topology_mismatches'] == 0
    assert s['vision_workspace_reuses'] > 0 and s['batch_argmax_calls'] > 0
    assert d['queued_phase_priority'] == bool(q) and d['resident_vision_budget'] and d['gpu_token_burst']
    assert s['gpu_token_burst_steps']>0 and s['gpu_token_burst_topology_mismatches']==0
    assert s['gpu_token_burst_max_width']==4 and s['gpu_token_burst_extra_steps']>s['gpu_token_burst_steps']
    assert (s['vision_pipeline_images']==128 and s['vision_pipeline_overlaps']>0)==profiles[key]['pipeline_vision']
    assert d['pipeline_vision']==profiles[key]['pipeline_vision'] and ((s['prefill_stream_splits']>0)==(profiles[key]['prefill_stream_layers']>0))
    assert d['prefill_stream_layers']==profiles[key]['prefill_stream_layers']
    print('DONE NATIVE', key, index, s['pages_per_second'], flush=True)
    return d, p

def compare(key, index, n, r):
    nd, np = n
    _, rd, rp = r
    result = nd['results'][0]
    assert {x['image_index']: x['text'] for x in result['references']} == {x['image_index']: x['text'] for x in rd['references']}
    a = result['policy_rounds'][0]['pages_per_second']
    b = rd['results'][0]['pages_per_second']
    row = dict(reference_concurrency=rd['results'][0]['concurrency'], reference_automatic_cache=rd['kv_cache_block_override'] is None, profile=key, round=index, native_pages_per_second=a, reference_pages_per_second=b,
               native_to_vllm_ratio=a / b, full_fixture_string_identity=True, all_128_native_pages_equal_serial_reference=True,
               primary_throughput_eligible=True, native_report=str(np.relative_to(out)), native_report_sha256=sha(np),
               reference_report=str(rp.relative_to(out)), reference_report_sha256=sha(rp))
    record['comparisons'].append(row)
    save()
    print('COMPARISON', json.dumps(row), flush=True)

save()
refs=[reference(0,c) for c in [16,32,64]]
capacities=[]
for _,_,rp in refs:
 log=(rp.parent/'server.txt').read_text()
 values=[int(n)for n in re.findall(r'Hybrid shared cache: (\d+) blocks',log)]
 assert values, rp
 capacities.extend(values)
full=None
if min(capacities)>=320:
 full=reference(0,64,320)
 if full is not None:refs.append(full)
else:
 record['full_capacity_candidate_skipped']=dict(requested_blocks=320, observed_automatic_blocks=capacities, reason='Skip before launching any override: not within every fresh automatic capacity.')
 save()

for label,d,p in refs:
 record['reference_candidates'].append(dict(blocks=d['kv_cache_block_override'],concurrency=d['results'][0]['concurrency'],pages_per_second=d['results'][0]['pages_per_second'],report=str(p.relative_to(out)),report_sha256=sha(p)))
r0=max(refs,key=lambda x:x[1]['results'][0]['pages_per_second'])
record['selected_reference_concurrency']=r0[1]['results'][0]['concurrency'];save()
a0=native('wide',0,r0[0]);compare('wide',0,a0,r0)
if record['comparisons'][-1]['native_to_vllm_ratio']<=1:
 record['status']='early_stop_forward_loss';save();print('FINAL',record['status'],flush=True);sys.exit(0)
a1=native('wide',1,r0[0]);reverse_refs=[]
if full is not None:
 closing_full=reference(1,64,320)
 if closing_full is not None:reverse_refs.append(closing_full)
reverse_refs.extend(reference(1,c)for c in [64,32,16])
for label,d,p in reverse_refs:
 record['reference_candidates'].append(dict(round=1,blocks=d['kv_cache_block_override'],concurrency=d['results'][0]['concurrency'],pages_per_second=d['results'][0]['pages_per_second'],report=str(p.relative_to(out)),report_sha256=sha(p)))
r1=max(reverse_refs,key=lambda x:x[1]['results'][0]['pages_per_second']);compare('wide',1,a1,r1)
ratios=[x['native_to_vllm_ratio']for x in record['comparisons']]
record['status']='repeated_win'if min(ratios)>1 else'native_behind'
record['profile_outcomes']={'wide':'clear_repeated_win'if min(ratios)>=1.05 else'small_repeated_lead'if min(ratios)>1 else'native_behind'}
save();print('FINAL',record['status'],record['profile_outcomes'],flush=True)
