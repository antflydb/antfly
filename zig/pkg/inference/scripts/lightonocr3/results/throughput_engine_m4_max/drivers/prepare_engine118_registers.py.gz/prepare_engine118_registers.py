from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=(v/'engine115_chunk.metal').read_text();a=s.index('// One group owns');coef=s[:a]
needle=' if(tid<16){float prefix=';pos=coef.index(needle)
pack=''' device half*packed=(device half*)(coef+(p.seq/16)*p.value_heads*544)+((start/16)*p.key_heads+kh)*4096;
 if(h%(p.value_heads/p.key_heads)==0)for(uint z=tid;z<2048;z+=128){uint row=z/128,d=z%128;packed[z]=half(x[(start+row)*channels+kh*128+d]);packed[2048+z]=half(x[(start+row)*channels+(p.key_heads+kh)*128+d]);}
'''
coef=coef[:pos]+pack+coef[pos:]
state=r'''
// Private mixed operands: FP16 Q/K and state-dot inputs; F32 state registers,
// coefficients, triangular solve and state update. No production default.
kernel void chunk_state115(device float*state[[buffer(8)]],device const float*x[[buffer(9)]],device const float*g[[buffer(10)]],device float*y[[buffer(11)]],constant Params&p[[buffer(15)]],device const float*coef[[buffer(16)]],uint tid[[thread_index_in_threadgroup]],uint sg[[simdgroup_index_in_threadgroup]],uint group[[threadgroup_position_in_grid]]){
 const uint h=group/8,v0=(group%8)*16,kh=h/(p.value_heads/p.key_heads),channels=(2*p.key_heads+p.value_heads)*128;
 const uint rb=(sg/2)*8,vb=(sg%2)*8,v=tid%16;
 threadgroup float qm[256],km[256],delta[256];
 threadgroup half hs[2048],hd[256],hm[256];
 float values[16];
 for(uint n=0;n<16;n++){uint k=tid/16+8*n;values[n]=p.initialized?state[(h*128+k)*128+v0+v]:0.0f;}
 for(uint start=0;start+16<=p.seq;start+=16){
  device const float*c=coef+((start/16)*p.value_heads+h)*544;
  device const half*hq=(device const half*)(coef+(p.seq/16)*p.value_heads*544)+((start/16)*p.key_heads+kh)*4096;
  device const half*hk=hq+2048;
  for(uint n=0;n<16;n++)hs[tid+128*n]=half(values[n]);
  for(uint z=tid;z<256;z+=128)hm[z]=half(c[256+z]);
  threadgroup_barrier(mem_flags::mem_threadgroup);
  auto aq=make_filled_simdgroup_matrix<float,8>(0.0f),ak=make_filled_simdgroup_matrix<float,8>(0.0f);
  for(uint d=0;d<128;d+=8){
   simdgroup_half8x8 q,k,ss;simdgroup_load(q,hq+rb*128+d,128);simdgroup_load(k,hk+rb*128+d,128);simdgroup_load(ss,hs+d*16+vb,16);
   simdgroup_multiply_accumulate(aq,q,ss,aq);simdgroup_multiply_accumulate(ak,k,ss,ak);
  }
  simdgroup_store(aq,qm+rb*16+vb,16);simdgroup_store(ak,km+rb*16+vb,16);
  threadgroup_barrier(mem_flags::mem_threadgroup);
  if(tid<16)for(uint i=0;i<16;i++){
   const float beta=g[((start+i)*p.value_heads+h)*2+1];float d=beta*(x[(start+i)*channels+2*p.key_heads*128+h*128+v0+tid]-c[512+i]*km[i*16+tid]);
   for(uint j=0;j<i;j++)d-=c[i*16+j]*delta[j*16+tid];delta[i*16+tid]=d;
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint z=tid;z<256;z+=128)hd[z]=half(delta[z]);
  threadgroup_barrier(mem_flags::mem_threadgroup);
  auto out=make_filled_simdgroup_matrix<float,8>(0.0f);
  for(uint d=0;d<16;d+=8){simdgroup_half8x8 m,dd;simdgroup_load(m,hm+rb*16+d,16);simdgroup_load(dd,hd+d*16+vb,16);simdgroup_multiply_accumulate(out,m,dd,out);}
  simdgroup_store(out,km+rb*16+vb,16);
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint z=tid;z<256;z+=128){uint i=z/16,vc=z%16;y[((start+i)*p.value_heads+h)*128+v0+vc]=c[512+i]*qm[z]+km[z];delta[z]*=c[528+i];}
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint n=0;n<16;n++){
   uint k=tid/16+8*n;float next=values[n]*c[527];
   for(uint i=0;i<16;i++)next+=x[(start+i)*channels+(p.key_heads+kh)*128+k]*delta[i*16+v];values[n]=next;
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);
 }
 for(uint n=0;n<16;n++){uint k=tid/16+8*n;state[(h*128+k)*128+v0+v]=values[n];}
}
'''
(v/'engine118_chunk.metal').write_text(coef+state)
s=(v/'engine115_chunk_kernels.m').read_text();old='(seq/16)*value_heads*544*4';assert old in s;s=s.replace(old,'(seq/16)*(value_heads*544*4+key_heads*4096*2)');(v/'engine118_chunk_kernels.m').write_text(s)
s=(v/'engine115_chunk_checks.m').read_text().replace('engine115_chunk_kernels.m','engine118_chunk_kernels.m');(v/'engine118_chunk_checks.m').write_text(s)
s=(v/'engine115_chunk_probe.m').read_text().replace('engine115_chunk_checks.m','engine118_chunk_checks.m').replace('engine115_chunk.metal','engine118_chunk.metal').replace('CHUNK115','REGISTER118').replace('(2048/16)*32*544*4','(2048/16)*(32*544*4+16*4096*2)');(v/'engine118_chunk_probe.m').write_text(s)
