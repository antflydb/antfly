from pathlib import Path
import hashlib,json,os,psutil,subprocess,datetime,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=json.loads((v/'engine88_register_probe_preparation.json').read_text());assert all(sha(r/f)==h for f,h in p['input_sha256'].items());assert sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')==p['production_c_sha256']
a=o/'engine88_register_probe_audit.json';assert not a.exists();d=dict(status='preparing',primary_throughput_eligible=False,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),preparation=p,driver_sha256=sha(Path(__file__)),scope='Isolated four-real-layer ordinary FFN, full-K MPP vs original register-coordinate MPP BF16 operands/F32 accumulation, ABBA. No packed FFN fusion and no dtype reduction. All output elements bounded 2e-4+2e-5*abs(baseline); record packed/output differences caused by reduction order. CPU corners and all canaries. Not full model speed or OCR quality evidence.')
def save():a.write_text(json.dumps(d,indent=2)+'\n')
save()
try:
 b=v/'engine86_real_ffn_probe';assert b.exists();old=json.loads((o/'engine86_steel_probe_audit.json').read_text());assert sha(b)==old['binary_sha256'];d['reused_exact_c_binary_from_initial_shader_failure']=True
 d['binary_sha256']=sha(b);save()
 need=2*1024**3;reserve=6*1024**3
 while psutil.virtual_memory().available<need+reserve:
  d.update(status='waiting_original_reserve',available_bytes=psutil.virtual_memory().available);save();print('WAIT REGISTER88',d['available_bytes'],flush=True);time.sleep(15)
 original=json.loads((o/'engine83_real_ffn_probe_retry_audit.json').read_text());d['real_weight_payloads']=original['real_weight_payloads'];save()
 model=Path(json.loads((v/'engine82_real_ffn_preparation.json').read_text())['model_path']);before=model.stat()
 with model.open('rb')as f:
  for w in d['real_weight_payloads']:
   f.seek(w['offset']);assert hashlib.sha256(f.read(w['bytes'])).hexdigest()==w['sha256']
 assert before.st_mtime_ns==model.stat().st_mtime_ns
 so=Path('/private/tmp/ocr-engine88-register-stdout.txt');se=Path('/private/tmp/ocr-engine88-register-stderr.txt');assert not so.exists()and not se.exists();d['status']='running';save()
 with so.open('w')as f,se.open('w')as e:result=subprocess.run([str(b),str(v/'engine88_register_gemm.metal')],stdout=f,stderr=e,env=dict(os.environ,ANTFLY_LIGHTONOCR3_THROUGHPUT='0'),timeout=900)
 records=[json.loads(l)for l in so.read_text().splitlines()if l.startswith('{"rows":')];d.update(exit_code=result.returncode,records=records,stdout_sha256=sha(so),stderr_sha256=sha(se));save();assert result.returncode==0 and len(records)==12
 assert all(x['max_abs']<=2e-4 and len(x['gpu_us'])==8 for x in records)
 assert 'REAL86 FULL REAL-WEIGHT OUTPUT/CPU/CANARY CHECKS PASS'in se.read_text();d['status']='prototype_pass';save();print('REGISTER88 PROTOTYPE PASS',flush=True)
except BaseException as e:d.update(status='failed',error=repr(e));save();raise
