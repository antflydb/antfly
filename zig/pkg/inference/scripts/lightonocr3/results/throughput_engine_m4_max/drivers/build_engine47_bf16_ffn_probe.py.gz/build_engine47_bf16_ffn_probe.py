from pathlib import Path
import hashlib
import json
import os
import subprocess

v = Path('.venv-lighton-vllm-metal')
out = Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
inputs = [v / n for n in ['engine47_bf16_ffn_probe_kernels.m', 'engine47_bf16_ffn_probe_checks.m', 'engine47_bf16_ffn_probe.m', 'engine47_bf16_ffn_probe.metal']]
inputs += [Path('zig/pkg/inference/src/backends') / n for n in ['metal_buffer_observation.h', 'metal_mtp_head.h', 'metal_mtp_head_impl.h']]
plan = json.loads((v / 'engine47-bf16-ffn-probe-plan.json').read_text())
assert sha(Path('zig/pkg/inference/src/backends/metal_kernels.m')) == plan['base_c_sha256']
binary = v / 'engine47_bf16_ffn_probe'
assert not binary.exists()
command = ['clang', '-O3', '-fobjc-arc', '-I', 'zig/pkg/inference/src/backends', str(v / 'engine47_bf16_ffn_probe.m'),
           '-framework', 'Foundation', '-framework', 'Metal', '-framework', 'MetalPerformanceShaders',
           '-framework', 'Accelerate', '-o', str(binary)]
env = os.environ.copy()
env['CLANG_MODULE_CACHE_PATH'] = str(v / 'clang-cache')
with Path('/private/tmp/ocr-engine47-bf16-ffn-probe-build.txt').open('w') as log:
    result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
record = dict(command=command, exit_code=result.returncode, input_sha256={str(p): sha(p) for p in inputs})
if result.returncode == 0:
    record.update(binary=str(binary), binary_sha256=sha(binary))
(out / 'engine47_bf16_ffn_probe_build_manifest.json').write_text(json.dumps(record, indent=2) + '\n')
assert result.returncode == 0, result.returncode
print(json.dumps(record, indent=2))
