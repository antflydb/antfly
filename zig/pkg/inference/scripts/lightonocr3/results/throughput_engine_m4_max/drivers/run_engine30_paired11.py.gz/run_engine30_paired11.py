from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max'
images=[root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png',scripts/'corpus/receipt.png',scripts/'corpus/shipping.png']
profiles={'4b':dict(concurrency=32,bf16='0',shared='1',prefill='1',physical32='1'),'08':dict(concurrency=16,bf16='0',shared='0',prefill='0',physical32='0')}
models=sys.argv[1:] or ['4b','08'];assert all(m in profiles for m in models)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Fresh automatic-capacity vLLM C16/C32 controls and native selected profiles, then reverse-order repetition at the winning server concurrency. R128 mixed pages; no own CPU compilation or sampling; shared machine uncontrolled.',required_ratio=1.05,models=models,profiles=profiles,stream_first_layers=0,single_frame=True,cpu_preprocess=True,prefill_batch=False,vision_frame_blocks=4,comparisons=[],status='running')
def save(): (out/('paired11_'+('_'.join(models))+'_comparison_audit.json')).write_text(json.dumps(record,indent=2)+'\n')
def reference(model,round,c):
 label=f'_primary_reference11_r{round}_auto_c{c}_r128';dest=out/('vllm_'+model+label);assert not(dest/'report.json').exists(),dest
 cmd=[sys.executable,str(scripts/'benchmark_vllm_metal.py'),'--python',sys.executable,'--model-dir',str(v/'ocr-models'/('lighton'+model)),'--images',*[str(p)for p in images],'--concurrency',str(c),'--requests','128','--max-tokens','256','--startup-timeout','600','--output-dir',str(dest)]
 print('START VLLM',model,round,c,flush=True)
 with open(f'/private/tmp/ocr-engine-vllm-{model}-primary11-r{round}-auto-c{c}-r128.txt','w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 print('DONE VLLM',model,round,c,r.returncode,flush=True);assert r.returncode==0
 d=json.loads((dest/'report.json').read_text());assert d['status']=='ok' and d['kv_cache_block_override'] is None and d['results'][0]['serial_reference_parity']
 return label,d,dest/'report.json'
def native(model,round,oracle):
 p=profiles[model];c=p['concurrency'];label=f'paired11_r{round}_native_c{c}_bf16{p["bf16"]}_cache{p["shared"]}_prefill{p["prefill"]}_sf'+os.environ.get('OCR_PAIRED_SINGLE_FRAME','1')+'_vision'+os.environ.get('OCR_PAIRED_VISION_FRAME_BLOCKS','4')+'_wait'+os.environ.get('OCR_PAIRED_PREFILL_WAIT_US','100000');dest=out/('engine30_'+model+'_'+label);assert not(dest/'report.json').exists(),dest
 env=os.environ.copy();env.update(OCR_CONCURRENCY=str(c),OCR_REQUESTS='128',OCR_WIDE='1',OCR_SCRATCH_GIB=('10' if model=='4b' else '8'),OCR_BACKEND_GIB=('17' if model=='4b' else '16'),OCR_PREFILL_DECODE_STREAK='0',OCR_STREAM_FIRST='0',OCR_CPU_PREPROCESS='1',OCR_SINGLE_FRAME=os.environ.get('OCR_PAIRED_SINGLE_FRAME','1'),OCR_VISION_FRAME_BLOCKS=os.environ.get('OCR_PAIRED_VISION_FRAME_BLOCKS','4'),OCR_PREFILL_WAIT_US=os.environ.get('OCR_PAIRED_PREFILL_WAIT_US','100000'),OCR_SHARED_CORE=p['shared'],OCR_BF16_PREFILL=p['prefill'],OCR_BF16=p['bf16'],OCR_PHYSICAL32=p['physical32'],OCR_REFERENCE_LABEL=oracle,OCR_POLICIES='engineepoch',OCR_VISION_BATCH='0')
 print('START NATIVE',model,round,p,flush=True);r=subprocess.run([sys.executable,str(v/os.environ.get('OCR_PAIRED_DRIVER','run_engine30_budget_no_prefill_policies.py')),model+':'+label],env=env);print('DONE NATIVE',model,round,r.returncode,flush=True);assert r.returncode==0
 d=json.loads((dest/'report.json').read_text());assert d['results'][0]['status']=='ok' and not d['own_cpu_compile_overlap']
 return d,dest/'report.json'
def compare(model,round,n,r,order):
 nd,np=n;label,rd,rp=r;nr=nd['results'][0];sample=nr['policy_rounds'][0]
 assert nr['serial_reference_parity'] and nr['cross_runtime_content_parity'] and sample['completed']==128
 assert {x['image_index']:x['text']for x in nr['references']}=={x['image_index']:x['text']for x in rd['references']}
 ratio=sample['pages_per_second']/rd['results'][0]['pages_per_second']
 item=dict(model=model,round=round,order=order,native_report=str(np.relative_to(out)),native_report_sha256=sha(np),reference_report=str(rp.relative_to(out)),reference_report_sha256=sha(rp),native_pages_per_second=sample['pages_per_second'],reference_pages_per_second=rd['results'][0]['pages_per_second'],native_to_vllm_ratio=ratio,full_fixture_string_identity=True,all_128_native_pages_equal_serial_reference=True,primary_throughput_eligible=True)
 record['comparisons'].append(item);save();print('COMPARISON',json.dumps(item),flush=True)
 # Complete the reverse order even after a loss to expose ordering effects.
save();winners={}
for model in models:
 refs=[reference(model,0,c)for c in [16,32]];best=max(refs,key=lambda x:x[1]['results'][0]['pages_per_second']);winners[model]=best
 compare(model,0,native(model,0,best[0]),best,'vLLM C16 then vLLM C32 then native')
for model in models:
 best=winners[model];n=native(model,1,best[0]);c=best[1]['results'][0]['concurrency'];ref=reference(model,1,c)
 compare(model,1,n,ref,'native then fresh vLLM at previous winning concurrency')
record['status']='native_behind'if any(x['native_to_vllm_ratio']<=1 for x in record['comparisons'])else 'clear_repeated_win'if all(x['native_to_vllm_ratio']>=record['required_ratio']for x in record['comparisons'])else 'small_margin_requires_more_evidence';save()
print('FINAL',record['status'],flush=True);sys.exit(0 if record['status']=='clear_repeated_win'else 2)
