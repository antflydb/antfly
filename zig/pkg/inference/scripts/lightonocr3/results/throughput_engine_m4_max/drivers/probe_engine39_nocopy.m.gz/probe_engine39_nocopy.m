#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

// Read-only diagnostic; run after the primary timing chain finishes.
int main(int argc, const char **argv) {
  if (argc != 2) return 2;
  @autoreleasepool {
    id<MTLDevice> device = MTLCreateSystemDefaultDevice();
    if (!device) return 3;
    int fd = open(argv[1], O_RDONLY);
    struct stat info;
    if (fd < 0 || fstat(fd, &info)) return 4;
    void *mapped = mmap(NULL, info.st_size, PROT_READ, MAP_SHARED, fd, 0);
    close(fd);
    if (mapped == MAP_FAILED) return 5;
    uint64_t header;
    memcpy(&header, mapped, sizeof(header));
    const size_t offsets[] = {0, 64, 8 + header};
    const size_t length = 2 * (size_t)sysconf(_SC_PAGESIZE);
    if (offsets[2] + length > (size_t)info.st_size) return 6;
    id<MTLCommandQueue> queue = [device newCommandQueue];
    int rc = 0;
    for (size_t i = 0; i < 3; i++) {
      void *source = (uint8_t *)mapped + offsets[i];
      id<MTLBuffer> buffer = [device newBufferWithBytesNoCopy:source length:length
          options:MTLResourceStorageModeShared deallocator:nil];
      fprintf(stderr, "offset=%zu buffer=%s", offsets[i], buffer ? "accepted" : "declined");
      if (!buffer) { fprintf(stderr, "\n"); continue; }
      id<MTLBuffer> output = [device newBufferWithLength:16 options:MTLResourceStorageModeShared];
      id<MTLCommandBuffer> command = [queue commandBuffer];
      id<MTLBlitCommandEncoder> encoder = [command blitCommandEncoder];
      [encoder copyFromBuffer:buffer sourceOffset:0 toBuffer:output destinationOffset:0 size:16];
      [encoder endEncoding];
      [command commit];
      [command waitUntilCompleted];
      const bool valid = command.status == MTLCommandBufferStatusCompleted &&
          !memcmp(source, output.contents, 16);
      fprintf(stderr, " contents_alias=%d storage=%lu bytes=%lu allocated=%lu gpu_read=%s\n",
          buffer.contents == source, (unsigned long)buffer.storageMode,
          (unsigned long)buffer.length, (unsigned long)buffer.allocatedSize,
          valid ? "pass" : "fail");
      if (!valid) rc = 7;
    }
    // All command buffers have completed and the buffer objects leave this
    // scope before the read-only mapping is released.
    // Process exit releases the mapping after the autorelease pool drains.
    return rc;
  }
}
