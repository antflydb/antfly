from pathlib import Path
import json,subprocess,sys
root=Path.cwd();p=root/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_engine_m4_max';manifest=out/'engine30_build_manifest.json';binary=json.loads(manifest.read_text())['binary_path']
for i,disabled in enumerate([False,False]):
 rows=8
 command=[sys.executable,str(p/'benchmark_concurrency.py'),'--native-test',binary,'--model','florence=/Users/ajroetker/.antfly/inference/models/antflydb/florence-2-base','--images',str(root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(p/'corpus/receipt.png'),str(p/'corpus/shipping.png'),'--requests','64','--concurrency','8','--max-tokens','256','--modes','batch','--native-read-batch-size',str(rows),'--batch-wait-us','5000','--florence-batch-wait-us','5000','--memory-gib','24','--shared-memory-gib','28','--backend-memory-gib','16','--kv-memory-gib','4','--scratch-memory-gib','8','--timeout','600','--reference-report',str(out/'mlx_florence_engine30_serial_reference/report.json'),'--build-manifest',str(manifest),'--output-dir',str(out/f'engine30_florence_serial_round{i}_disabled{int(disabled)}')]
 command+=['--require-florence-no-repeat-argmax','--policy-rounds','current','current']
 if disabled:command+=['--disable-florence-no-repeat-argmax']
 print('START',i,'disabled',disabled,flush=True)
 with open(f'/private/tmp/ocr-engine30-florence-serial-round{i}.txt','w')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 print('DONE',i,rows,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
