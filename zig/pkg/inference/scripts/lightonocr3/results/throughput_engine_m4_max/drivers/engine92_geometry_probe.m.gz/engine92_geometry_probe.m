#define main engine92_unused_main
#include "engine92_geometry_checks.m"
#undef main
int main(int argc,char**argv){@autoreleasepool{
 if(argc!=3)return 1;engine92_kind=(unsigned)strtoul(argv[1],NULL,10);engine92_width=(unsigned)strtoul(argv[2],NULL,10);
 if(engine92_kind<1||engine92_kind>3||engine92_width<32||engine92_width>512||engine92_width%32)return 2;
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 3;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 unsetenv("TERMITE_METAL_DISABLE_QWEN35_PREFILL_COLUMNS");setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY","1",1);
 if((engine92_kind!=2&&engine92_width>r->qwen35_recurrent_columns4_pipeline.maxTotalThreadsPerThreadgroup)||(engine92_kind!=1&&(engine92_width>r->lightonocr3_prefill_prepare_pipeline.maxTotalThreadsPerThreadgroup||engine92_width>r->lightonocr3_prefill_norm_pipeline.maxTotalThreadsPerThreadgroup))){termite_metal_decode_runtime_destroy(r);return 77;}
 const size_t lengths[]={128,432,554,662,2048};
 for(size_t h=16;h<=32;h+=16)for(size_t i=0;i<5;i++)for(size_t initialized=0;initialized<2;initialized++)if(prefill_core_check(r,lengths[i],h,initialized,true))return 6;
 fprintf(stderr,"GEOMETRY92 EXACT FULL OUTPUT/STATE/CANARY PASS kind=%u width=%u\n",engine92_kind,engine92_width);termite_metal_decode_runtime_destroy(r);return 0;
}}
