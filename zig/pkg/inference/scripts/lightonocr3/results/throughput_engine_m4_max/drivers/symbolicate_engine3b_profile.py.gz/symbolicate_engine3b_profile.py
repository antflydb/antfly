from pathlib import Path
import re,json,bisect,subprocess,hashlib
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';p=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/engine3b_cpu_profile';meta=json.loads((v/'symbols_70ffd1f16a3eb0cfa41d65270ebf45f4.json').read_text());syms=meta['symbols'];syms.append(dict(name='_main',binary_address=0x1000e0858,matched=True,checked_words=8));syms.sort(key=lambda x:x['binary_address']);addresses=[x['binary_address']for x in syms]
s=(p/'sample.txt').read_text()
def mapped(offset):
 pc=0x1000e0858+int(offset);i=bisect.bisect_right(addresses,pc)-1
 if i<0:return'UNKNOWN'
 sym=syms[i];return sym['name']+'+'+str(pc-addresses[i])+(' [UNVERIFIED]'if not sym['matched']else'')
resolved=re.sub(r'main  \(in test\) \+ (\d+)',lambda m:m.group(0)+' [Zig: '+mapped(m[1])+']',s);(p/'sample_symbolicated.txt').write_text(resolved)
a=s.index('Total number in stack');top=[]
for line in s[a:].splitlines():
 m=re.match(r'\s*(\d+)\s+main  \(in test\) \+ (\d+)',line)
 if m:top.append(dict(samples=int(m[1]),main_offset=int(m[2]),symbol=mapped(m[2])))
(p/'symbolicated_summary.json').write_text(json.dumps(dict(binary_sha256=meta['binary_sha256'],object_sha256=hashlib.sha256((root/'zig/.zig-cache/o/70ffd1f16a3eb0cfa41d65270ebf45f4/test_zcu.o').read_bytes()).hexdigest(),method='Map main-relative addresses with compiler object symbols; verify first 32 bytes against linked executable, ignoring relocation words. 7616/7617 function prefixes match. Repeated recursive libBLAS unwind frames are excluded from attribution.',top_recursive_counts=top),indent=2)+'\n')
print(json.dumps(top[:30],indent=2))
