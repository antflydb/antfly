from pathlib import Path
import os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');base=os.environ.copy();base.update(OCR_REFERENCE_LABEL='_primary_reference9_loadcheck_auto_c32_r128',OCR_PHYSICAL32='1',OCR_CONCURRENCY='32',OCR_REQUESTS='128',OCR_WIDE='1',OCR_SCRATCH_GIB='10',OCR_BACKEND_GIB='17',OCR_STREAM_FIRST='0',OCR_PREFILL_DECODE_STREAK='0',OCR_PREFILL_WAIT_US='100000',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1',OCR_BF16_PREFILL='1',OCR_VISION_BATCH='0',OCR_VISION_FRAME_BLOCKS='4')
for bf16,vision_off,decode_off in [(0,0,0)]:
 sf=0
 env=base.copy();env.update(OCR_SINGLE_FRAME=str(sf),OCR_BF16=str(bf16),OCR_DISABLE_VISION_PACK_REUSE=str(vision_off),OCR_DISABLE_DECODE_PACK_REUSE=str(decode_off));label=f'vision4_c32_device17_scratch10_sf{sf}_bf16{bf16}_visionoff{vision_off}_decodeoff{decode_off}_nohook_r128_0';print('START',label,flush=True)
 r=subprocess.run([sys.executable,str(v/'run_engine29_budget_no_prefill_policies.py'),'4b:'+label],env=env)
 print('DONE',label,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
