from pathlib import Path
import os,sys,subprocess,json,hashlib,time,ctypes
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p,h in json.loads((v/'engine66-freeze.json').read_text()).items():assert sha(root/p)==h,p
profiles={f'vf{vf}':dict(settings=[64,1,1,vf,0,0,0],prefill_wait_us=100000)for vf in [1,2]}
audit=out/'engine66_vision_pipeline46_4b_r128_audit.json';assert not audit.exists()
record=dict(status='running',scope='New bounded resident vision pipeline with two fully charged groups, plus qualified four-step greedy decode. C64/P1/V1, VF1 and VF2 screened under original caps. Rank actual eligible throughput; all full R128 outputs and admission checked. Saved reference used for quality only, not a fresh speed claim.',candidates=[])
def save():audit.write_text(json.dumps(record,indent=2)+'\n')
save()
def native(key, index, oracle):
    c, pref, vis, vf, sv, sp, q = profiles[key]['settings']
    label = f'vision_pipeline46_{key}_r{index}_c{c}_p{pref}_v{vis}_vf{vf}_r128'
    dest = out / ('engine66_4b_' + label)
    assert not dest.exists()
    env = os.environ.copy()
    env.update(OCR_REFERENCE_LABEL=oracle, OCR_PHYSICAL32='0', OCR_PHYSICAL64='1', OCR_CONCURRENCY=str(c),
               OCR_REQUESTS='128', OCR_WIDE='1', OCR_KV_GIB='4', OCR_BACKEND_GIB='17', OCR_SCRATCH_GIB='10',
               OCR_CPU_PREPROCESS='1', OCR_PREFILL_DECODE_STREAK='0', OCR_POLICIES='engineepoch', OCR_SHARED_CORE='1',
               OCR_BF16_PREFILL='1', OCR_BF16='0', OCR_DISABLE_64_ROW_TILE='0', OCR_DISABLE_WIDE_GATE_UP='0',
               OCR_WIDE64_GATE_UP='1', OCR_FULL64_GATE_UP='1', OCR_GPU_GREEDY_STREAM='0', OCR_STREAM_CHUNK_LAYERS='0',
               OCR_VISION_BATCH=str(int(vis > 1)), OCR_VISION_BATCH_ITEMS=str(vis), OCR_VISION_WAIT_US='2000',
               OCR_PREFILL_BATCH=str(int(pref > 1)), OCR_PREFILL_BATCH_ITEMS=str(pref), OCR_PREFILL_WAIT_US=str(profiles[key].get('prefill_wait_us', 100000)),
               OCR_VISION_FRAME_BLOCKS=str(vf), OCR_SINGLE_FRAME='1', OCR_STREAM_FIRST='0', OCR_LOGICAL64='1',
               OCR_SHARED_DECODER_SCRATCH='1', OCR_DEVICE_RECURRENT_STATE='1', OCR_ENCODER_SCOPES='1', OCR_ADMISSION_UNITS='512',
               OCR_BATCH_ARGMAX='1', OCR_DEFER_VISION_SEAL=str(sv), OCR_DEFER_PREFILL_SEAL=str(sp),
               OCR_CACHE_VISION_WORKSPACE='1', OCR_LARGE_VISION_PACK_REUSE=str(int(vis > 1)),
               ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY=str(q), OCR_TIMEOUT='900')
    env['OCR_RESIDENT_VISION_BUDGET']='1'
    env['OCR_GPU_TOKEN_BURST']='1'
    env['OCR_GPU_TOKEN_BURST_WIDTH']='4'
    env['OCR_PIPELINE_VISION']='1'
    print('START NATIVE', key, index, profiles[key]['settings'], flush=True)
    with Path(f'/private/tmp/ocr-engine66-native-vision_pipeline46-{key}-r{index}-driver.txt').open('w') as log:
        subprocess.run([sys.executable, str(v / 'run_engine66_budget_policies.py'), '4b:' + label], env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    p = dest / 'report.json'
    d = json.loads(p.read_text())
    result = d['results'][0]
    s = result['policy_rounds'][0]
    assert result['status'] == 'ok' and result['serial_reference_parity'] and result['cross_runtime_content_parity']
    assert s['completed'] == 128 and not s['admission_pressures'] and not d['own_cpu_compile_overlap']
    assert s['host_recurrent_bytes_total'] == s['single_frame_topology_mismatches'] == s['gpu_greedy_stream_topology_mismatches'] == 0
    assert s['vision_workspace_reuses'] > 0 and s['batch_argmax_calls'] > 0
    assert d['queued_phase_priority'] == bool(q) and d['resident_vision_budget'] and d['gpu_token_burst']
    assert s['gpu_token_burst_steps']>0 and s['gpu_token_burst_topology_mismatches']==0
    assert s['gpu_token_burst_max_width']==4 and s['gpu_token_burst_extra_steps']>s['gpu_token_burst_steps']
    assert s['vision_pipeline_images']==128 and s['vision_pipeline_overlaps']>0
    print('DONE NATIVE', key, index, s['pages_per_second'], flush=True)
    return d, p
for vf in [1,2]:
 key=f'vf{vf}'
 try:
  d,p=native(key,0,'_primary_reference43_r0_auto_c64_r128_ctx1024')
 except (AssertionError,subprocess.CalledProcessError):
  p=out/f'engine66_4b_vision_pipeline46_{key}_r0_c64_p1_v1_vf{vf}_r128/report.json'
  assert p.exists(),p
  d=json.loads(p.read_text());raw=(p.parent/'lighton4b-batch-c64.txt').read_text()
  if'admission_pressure='not in raw:raise
  record['candidates'].append(dict(settings=profiles[key]['settings'],eligible=False,reason='admission_pressure',report=str(p.relative_to(out)),report_sha256=sha(p)));save();continue
 s=d['results'][0]['policy_rounds'][0]
 row=dict(settings=profiles[key]['settings'],eligible=True,pages_per_second=s['pages_per_second'],gpu_token_burst_steps=s['gpu_token_burst_steps'],process_cpu_ms=s['process_cpu_ms'],report=str(p.relative_to(out)),report_sha256=sha(p))
 record['candidates'].append(row);save();print('ADMITTED R128 PROFILE',json.dumps(row),flush=True)
eligible=[x for x in record['candidates']if x['eligible']]
assert eligible,record
record['selected']=max(eligible,key=lambda x:x['pages_per_second']);record['status']='pass';save();print('SELECTED VISION PIPELINE PROFILE',json.dumps(record['selected']),flush=True)
