from pathlib import Path
import hashlib,json,os,psutil,re,subprocess,time,datetime
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not (o/'engine73d_cpu_diagnostic65_audit.json').exists()
assert not list(o.glob('engine74_4b_burst_screen64_*/report.json'))
targets=[]
for p in psutil.process_iter(['cmdline']):
 cmd=p.info['cmdline']or[]
 if cmd and cmd[-1]=='.venv-lighton-vllm-metal/queue_engine73d_cpu_retry65.py':targets.append(p)
assert len(targets)==1;waiter=targets[0];waiter.suspend()
audit=o/'engine77_prefill_probe_verify2_audit.json';assert not audit.exists()
d=dict(status='preparing',primary_throughput_eligible=False,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),paused_own_child_free_waiter_pid=waiter.pid)
def save():audit.write_text(json.dumps(d,indent=2)+'\n')
try:
 assert not waiter.children(recursive=True) and not (o/'engine73d_cpu_diagnostic65_audit.json').exists()
 prep=json.loads((v/'engine77_prefill_preparation_verify2.json').read_text());assert sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')==prep['production_c_sha256'] and all(sha(r/f)==h for f,h in prep['inputs'].items())
 d.update(scope=prep['scope'],preparation_sha256=sha(v/'engine77_prefill_preparation_verify2.json'),inputs=prep['inputs']);save()
 while psutil.virtual_memory().available < 8*1024**3:time.sleep(5)
 binary=v/'engine77_prefill_probe_verify2';assert not binary.exists();cmd=['clang','-O3','-fobjc-arc','-I','zig/pkg/inference/src/backends',str(v/'engine77_prefill_probe_verify2.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(binary)]
 print('START PREFILL77 BUILD',flush=True)
 log=Path('/private/tmp/ocr-engine77-prefill-verify2-build.txt')
 with log.open('w')as f:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
 d.update(build_command=cmd,build_exit_code=result.returncode,build_log_sha256=sha(log));save();assert result.returncode==0
 d['binary_sha256']=sha(binary);save()
 while psutil.virtual_memory().available < 6*1024**3+512*1024**2:time.sleep(5)
 d.update(status='running',available_bytes_before_probe=psutil.virtual_memory().available,working_estimate_bytes=512*1024**2,os_reserve_bytes=6*1024**3);save();print('START PREFILL77 SCREEN',flush=True)
 stdout=Path('/private/tmp/ocr-engine77-prefill-verify2-stdout.txt');stderr=Path('/private/tmp/ocr-engine77-prefill-verify2-stderr.txt');assert not stdout.exists()and not stderr.exists()
 env=dict(os.environ,ANTFLY_LIGHTONOCR3_THROUGHPUT='0',TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY='1')
 for key in ['TERMITE_METAL_STAGE_TIMING','TERMITE_METAL_TRACE_ENCODER_TIMING','TERMITE_METAL_TRACE_ENCODERS']:env.pop(key,None)
 with stdout.open('w')as so,stderr.open('w')as se:result=subprocess.run([str(binary)],stdout=so,stderr=se,env=env,timeout=900)
 records=[json.loads(s)for s in stdout.read_text().splitlines()if s.startswith('{"candidate":')];ready=[int(x)for x in re.findall(r'CANDIDATE77 READY candidate=(\d+)',stderr.read_text())]
 d.update(exit_code=result.returncode,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr),ready_candidates=ready,records=records);save()
 assert result.returncode==0 and len(records)==len(ready)*72 and all(x['max_abs']<=2e-4 and x['cpu_error']<=2e-4 and len(x['gpu_us'])==8 for x in records)
 assert len({(x['candidate'],x['rows'],x['in'],x['out'],x['leg'])for x in records})==len(records)
 d['status']='screen_pass'if ready else'unsupported';save();print('ENGINE77 PREFILL SCREEN DONE',d['status'],len(records),flush=True)
except BaseException as e:
 d.update(status='failed',error=repr(e));save();raise
finally:
 if waiter.is_running():waiter.resume()
 d['own_waiter_resumed']=True;save();print('RESUMED OWN CPU DIAGNOSTIC WAITER',flush=True)
