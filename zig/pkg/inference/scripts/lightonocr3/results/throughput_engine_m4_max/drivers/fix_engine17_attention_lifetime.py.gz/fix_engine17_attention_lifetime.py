from pathlib import Path
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text();needle='void termite_metal_decode_runtime_lighton_attention_batch_stats('
idx=s.index(needle);s=s[:idx]+'''// The provider may outlive a backend epoch. Release admitted scratch only
// after both active and submitted work have been retired by the epoch owner.
int termite_metal_decode_runtime_lighton_attention_batch_release(termite_metal_decode_runtime *runtime) {
    if (runtime == NULL) return -1;
    if (runtime->active_frame_cb != nil || runtime->submitted_frame_cb != nil) return -2;
    termite_metal_lighton_attention_batch_abort(runtime);
    runtime->lighton_attention_batch_scratch[0] = nil;
    runtime->lighton_attention_batch_scratch[1] = nil;
    return 0;
}

'''+s[idx:]
needle='    termite_metal_decode_runtime_memory_add_buffer(snapshot, runtime->attention_decode_gqa_split_scratch_buffer_alt, &snapshot->scratch_bytes);';assert needle in s;s=s.replace(needle,needle+'''
    termite_metal_decode_runtime_memory_add_buffer(snapshot, runtime->lighton_attention_batch_scratch[0], &snapshot->scratch_bytes);
    termite_metal_decode_runtime_memory_add_buffer(snapshot, runtime->lighton_attention_batch_scratch[1], &snapshot->scratch_bytes);''',1);p.write_text(s)
p=Path('zig/pkg/inference/src/backends/metal_runtime.zig');s=p.read_text();s+='\npub extern fn termite_metal_decode_runtime_lighton_attention_batch_release(runtime: ?*RawMetalDecodeRuntime) c_int;\n';p.write_text(s)
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text().replace('    lighton_batch_attention: bool = false,','    lighton_batch_attention: bool = false,\n    lighton_attention_batch_baseline: [3]u64 = @splat(0),',1)
needle='''        self.lighton_batch_attention = enabled and self.lightonocr3_projections and metal_runtime_mod.qualifiedM4DeviceDefault();''';s=s.replace(needle,needle+'\n        metal_runtime_mod.termite_metal_decode_runtime_lighton_attention_batch_stats(self.provider_impl.raw_decode_runtime, &self.lighton_attention_batch_baseline);',1)
idx=s.index('pub fn lightOnBatchAttentionStats(');end=s.index('    pub fn setLightOnStreamFirstLayers',idx);part=s[idx:end].replace('        return result;','        for (&result, self.lighton_attention_batch_baseline) |*value, baseline| value.* -|= baseline;\n        return result;',1);s=s[:idx]+part+s[end:]
needle='''        // The admitted request/epoch still owns the vision workspace lease.''';s=s.replace(needle,'''        if (self.lighton_batch_attention) {
            const attention_release_rc = metal_runtime_mod.termite_metal_decode_runtime_lighton_attention_batch_release(runtime);
            std.debug.assert(attention_release_rc == 0);
            self.lighton_batch_attention = false;
        }
'''+needle,1);p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text();needle='''            termite_metal_decode_runtime_destroy(r);return 0;
        }
        if (argc == 2 && strcmp(argv[1], "--check-activation-pool")'''
repl='''            if (r->lighton_attention_batch_scratch[0] == nil && r->lighton_attention_batch_scratch[1] == nil) return 126;
            if (termite_metal_decode_runtime_begin_frame(r) || termite_metal_decode_runtime_lighton_attention_batch_begin(r)) return 127;
            if (termite_metal_decode_runtime_lighton_attention_batch_release(r) != -2 || r->lighton_attention_batch == NULL) return 128;
            if (termite_metal_decode_runtime_cancel_frame(r) || termite_metal_decode_runtime_lighton_attention_batch_release(r)) return 129;
            if (r->lighton_attention_batch != NULL || r->lighton_attention_batch_scratch[0] != nil || r->lighton_attention_batch_scratch[1] != nil) return 130;
            termite_metal_decode_runtime_destroy(r);return 0;
        }
        if (argc == 2 && strcmp(argv[1], "--check-activation-pool")'''
assert needle in s;s=s.replace(needle,repl,1);p.write_text(s)
