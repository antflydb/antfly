#include "engine93_ffn_prefix.inc"
#include "engine82_weight_offsets.inc"
static uint16_t *weights82[4][3];
static float cpu_error82;
static int cpu_corner82(double expected,float actual){
    cpu_error82=fmaxf(cpu_error82,fabs(expected-actual));
    return isfinite(actual)&&fabs(expected-actual)<=2e-4+2e-5*fabs(expected)?0:1;
}
static int probe82(termite_metal_decode_runtime*r,id<MTLComputePipelineState>candidate,size_t rows){@autoreleasepool{
    const size_t h=2560,f=9216;Buffers78*b=[Buffers78 new];
    b->source=buffer78(r,rows*h*4);b->zero=[r->device newBufferWithLength:rows*h*4 options:MTLResourceStorageModeShared];b->x=[r->device newBufferWithLength:rows*h*4+32 options:MTLResourceStorageModePrivate];
    b->g=buffer78(r,rows*f*4);b->u=buffer78(r,rows*f*4);b->activated=buffer78(r,rows*f*4);b->pnorm=buffer78(r,rows*h*2);b->pgated=buffer78(r,rows*f*2);b->y0=buffer78(r,rows*h*4);b->y1=buffer78(r,rows*h*4);
    if(!b->source||!b->zero||!b->x||!b->g||!b->u||!b->activated||!b->pnorm||!b->pgated||!b->y0||!b->y1)return 10;
    memset(b->zero.contents,0,b->zero.length);float*input=(float*)b->source.contents+4;
    for(size_t i=0;i<rows*h;i++)input[i]=sinf(i*.013f)*.7f;
    float*gold[4]={0};uint16_t*packed[4]={0};double gpu,encode;size_t variant=rows<=512?1:0;
    id<MTLComputePipelineState>original=r->lightonocr3_mpp_bf16_pipeline;
    for(size_t layer=0;layer<4;layer++){
        slot_base82=layer*3;
        if(frame78(r,nil,b,rows,0,false,&gpu,&encode))return 11;
        float*g=(float*)b->g.contents+4,*u=(float*)b->u.contents+4,*act=(float*)b->activated.contents+4,*out=(float*)b->y0.contents+4;
        for(size_t corner=0;corner<4;corner++){
            size_t row=corner/2?rows-1:0,col=corner%2?f-1:0;
            for(size_t kind=0;kind<2;kind++){
                double expected=0;
                for(size_t k=0;k<h;k++)expected+=(double)expand_bf16(round_bf16(input[row*h+k]+0.f))*expand_bf16(weights82[layer][kind][col*h+k]);
                if(cpu_corner82(expected,(kind?u:g)[row*f+col]))return 12;
            }
            col=corner%2?h-1:0;double expected=0;
            for(size_t k=0;k<f;k++)expected+=(double)expand_bf16(round_bf16(act[row*f+k]))*expand_bf16(weights82[layer][2][col*f+k]);
            if(cpu_corner82(expected,out[row*h+col]))return 13;
        }
        gold[layer]=malloc(rows*h*4);packed[layer]=malloc(rows*f*2);
        if(!gold[layer]||!packed[layer])return 14;
        memcpy(gold[layer],out,rows*h*4);for(size_t i=0;i<rows*f;i++)packed[layer][i]=round_bf16(act[i]);
    }
    for(size_t leg=0;leg<4;leg++){
        bool candidate_enabled=leg==1||leg==2;double times[8],encodes[8];float worst=0;size_t diffs=0,packedDiff=0,normDiff=0;
        r->lightonocr3_mpp_bf16_pipeline=candidate_enabled?candidate:original;
        engine93_m=candidate_enabled?strtoul(getenv("ENGINE93_M"),NULL,10):0;engine93_n=candidate_enabled?strtoul(getenv("ENGINE93_N"),NULL,10):0;engine93_threads=candidate_enabled?strtoul(getenv("ENGINE93_THREADS"),NULL,10):0;
        
        for(size_t trial=0;trial<10;trial++){
            size_t layer=trial%4;slot_base82=layer*3;
            int rc=frame78(r,nil,b,rows,0,false,&gpu,&encode);if(rc)return 20+rc;
            if(trial>=2){times[trial-2]=gpu;encodes[trial-2]=encode;}
            float*got=(float*)b->y0.contents+4;uint16_t*pn=(uint16_t*)((char*)b->pnorm.contents+16),*pg=(uint16_t*)((char*)b->pgated.contents+16);
            for(size_t i=0;i<rows*h;i++){
                if(!isfinite(got[i]))return 30;
                uint32_t ga,gb;memcpy(&ga,got+i,4);memcpy(&gb,gold[layer]+i,4);diffs+=ga!=gb;
                worst=fmaxf(worst,fabsf(got[i]-gold[layer][i]));if(fabsf(got[i]-gold[layer][i])>2e-4f+2e-5f*fabsf(gold[layer][i]))return 33;
            }
            for(size_t i=0;i<rows*f;i++)packedDiff+=round_bf16(((float*)b->activated.contents+4)[i])!=packed[layer][i];
            id<MTLBuffer>bufs[]={b->source,b->g,b->u,b->activated,b->pnorm,b->pgated,b->y0,b->y1};
            size_t sizes[]={rows*h*4,rows*f*4,rows*f*4,rows*f*4,rows*h*2,rows*f*2,rows*h*4,rows*h*4};
            for(size_t j=0;j<8;j++)if(canary78(bufs[j],sizes[j]))return 31;
        }
        printf("{\"rows\":%zu,\"leg\":%zu,\"candidate_enabled\":%d,\"real_layers\":[0,8,16,24],\"output_bit_differences\":%zu,\"packed_differences\":%zu,\"norm_packed_differences\":%zu,\"max_abs\":%.9g,\"cpu_max_abs\":%.9g,\"gpu_us\":[",rows,leg,candidate_enabled,diffs,packedDiff,normDiff,worst,cpu_error82);
        for(size_t i=0;i<8;i++)printf("%s%.6f",i?",":"",times[i]);printf("],\"host_encode_us\":[");
        for(size_t i=0;i<8;i++)printf("%s%.6f",i?",":"",encodes[i]);printf("]}\n");fflush(stdout);
        if(!candidate_enabled&&(diffs||packedDiff||normDiff))return 32;
    }
    r->lightonocr3_mpp_bf16_pipeline=original;engine93_m=engine93_n=engine93_threads=0;
    for(size_t i=0;i<4;i++){free(gold[i]);free(packed[i]);}
    return 0;
}}
int main(int argc,char**argv){@autoreleasepool{
    if(argc!=2)return 100;
    setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY","1",1);setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_PREFILL_FFN","1",1);setenv("TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS","1",1);unsetenv("TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS");
    termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 101;
    termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
    termite_metal_initialize_lighton_prefill_ffn(r);if(!r->lighton_prefill_ffn_pipelines[0]||!r->lighton_prefill_ffn_pipelines[1])return 102;
    NSError*error=nil;NSString*source=[NSString stringWithContentsOfFile:[NSString stringWithUTF8String:argv[1]] encoding:NSUTF8StringEncoding error:&error];if(!source)return 103;
    MTLCompileOptions*opts=[MTLCompileOptions new];opts.languageVersion=MTLLanguageVersion4_0;opts.fastMathEnabled=NO;opts.mathMode=MTLMathModeSafe;
    id<MTLLibrary>lib=[r->device newLibraryWithSource:source options:opts error:&error];if(!lib){fprintf(stderr,"%s\n",error.description.UTF8String);return 104;}
    id<MTLComputePipelineState>candidate=termite_metal_make_pipeline(r->device,lib,@"engine86_steel");
    if(!candidate||candidate.threadExecutionWidth!=32||candidate.maxTotalThreadsPerThreadgroup<strtoul(getenv("ENGINE93_THREADS"),NULL,10)||candidate.staticThreadgroupMemoryLength>r->device.maxThreadgroupMemoryLength)return 105;
    int fd=open(model_path82,O_RDONLY);if(fd<0)return 106;
    for(size_t layer=0;layer<4;layer++)for(size_t kind=0;kind<3;kind++){
        const size_t bytes=2560u*9216u*2;weights82[layer][kind]=malloc(bytes);if(!weights82[layer][kind])return 107;
        size_t read_bytes=0;while(read_bytes<bytes){ssize_t got=pread(fd,(char*)weights82[layer][kind]+read_bytes,bytes-read_bytes,weight_offsets82[layer][kind]+read_bytes);if(got<=0)return 108;read_bytes+=(size_t)got;}
        size_t in=kind==2?9216:2560,out=kind==2?2560:9216;float*bias=calloc(out,4);if(!bias)return 109;
        int rc=termite_metal_decode_runtime_prepare_linear_bf16(r,layer*3+kind,(uint8_t*)weights82[layer][kind],bytes,bias,in,out);free(bias);if(rc)return 110;
    }
    close(fd);
    const size_t rows[]={432,554,662};for(size_t i=0;i<3;i++){int rc=probe82(r,candidate,rows[i]);if(rc){fprintf(stderr,"REAL93_FAIL rows=%zu rc=%d\n",rows[i],rc);return rc;}}
    termite_metal_decode_runtime_destroy(r);for(size_t l=0;l<4;l++)for(size_t k=0;k<3;k++)free(weights82[l][k]);
    fprintf(stderr,"REAL93 FULL REAL-WEIGHT OUTPUT/CPU/CANARY CHECKS PASS; STEEL FLOAT REDUCTION ORDER CAN DIFFER\n");return 0;
}}
