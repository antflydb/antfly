from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
for old,new in [('build_engine55_conformance.py','build_engine56_conformance.py'),('run_engine55_c_qualification.py','run_engine56_c_qualification.py'),('run_engine55_c_and_bind.py','run_engine56_c_and_bind.py'),('run_engine55_functional.py','run_engine56_functional.py'),('engine55_verify_preset_only_test.py','engine56_verify_preset_only_test.py'),('engine55_verify_preset_physical32_test.py','engine56_verify_preset_physical32_test.py'),('engine55_verify_default_gpu_test.py','engine56_verify_default_gpu_test.py')]:
 s=(v/old).read_text().replace('engine55','engine56')
 if new=='run_engine56_c_qualification.py':s=s.replace("flags=['--check-batch-argmax'","flags=['--check-vision-workspace-cache','--check-large-vision-pack-reuse','--check-batch-argmax'")
 if new=='run_engine56_c_and_bind.py':s=s.replace('==14','==16').replace('ALL 14 C','ALL 16 C')
 (v/new).write_text(s)
s=(v/'run_engine55_budget_policies_verify2.py').read_text().replace('engine55','engine56')
needle=" batch_argmax=os.environ.get('OCR_BATCH_ARGMAX','0')=='1'";assert needle in s
s=s.replace(needle,""" cache_vision=os.environ.get('OCR_CACHE_VISION_WORKSPACE','0')=='1'
 large_vision_pack=os.environ.get('OCR_LARGE_VISION_PACK_REUSE','0')=='1'
 if cache_vision:cmd+=['--cache-vision-workspace']
 if large_vision_pack:cmd+=['--large-vision-pack-reuse']
"""+needle)
s=s.replace("report['batch_argmax']=batch_argmax;","report['cache_vision_workspace']=cache_vision;report['large_vision_pack_reuse']=large_vision_pack;report['batch_argmax']=batch_argmax;")
needle="    assert 'batch_argmax_calls'in sample and 'batch_argmax_rows'in sample,sample";assert needle in s
s=s.replace(needle,"""    workspace_mode=re.findall(r'LIGHTONOCR3 vision_workspace_cache=(\\d+)',section)
    assert workspace_mode and all((int(x)==1)==(cache_vision and expected_aux)for x in workspace_mode),(workspace_mode,cache_vision,expected_aux)
    assert sample['vision_workspace_allocations']>0,sample
    if cache_vision and expected_aux:assert sample['vision_workspace_reuses']>0 and sample['vision_workspace_bytes']>0,sample
    else:assert sample['vision_workspace_bytes']==0,sample
    assert 0<=sample['large_vision_pack_reuse_hits']<=sample['large_vision_pack_calls'],sample
    if not large_vision_pack:assert sample['large_vision_pack_calls']==sample['large_vision_pack_reuse_hits']==0,sample
    elif vision_items>=3 and max(sample['vision_batch_sizes'],default=0)>2:assert sample['large_vision_pack_calls']>0 and sample['large_vision_pack_reuse_hits']>0,sample
"""+needle)
compile(s,'budget56','exec');(v/'run_engine56_budget_policies.py').write_text(s)
for old in ['run_engine55_vision4_profile_verify2.py','run_engine55_large_chunk_profiles_verify2.py','run_engine55_chunk_cases_verify2.py']:
 name=old.replace('engine55','engine56').replace('_verify2','');s=(v/old).read_text().replace('engine55','engine56').replace('run_engine56_budget_policies_verify2.py','run_engine56_budget_policies.py');(v/name).write_text(s)
s=(v/'run_engine55_stage_smoke.py').read_text().replace('engine55','engine56').replace("env=os.environ.copy();env.update(","env=os.environ.copy();env.update(OCR_CACHE_VISION_WORKSPACE='1',OCR_LARGE_VISION_PACK_REUSE='1',")
(v/'run_engine56_stage_smoke.py').write_text(s)
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
paths=[v/'prepare_engine56_drivers.py']+[v/x for x in ['build_engine56_conformance.py','run_engine56_c_qualification.py','run_engine56_c_and_bind.py','run_engine56_functional.py','engine56_verify_preset_only_test.py','engine56_verify_preset_physical32_test.py','engine56_verify_default_gpu_test.py','run_engine56_budget_policies.py','run_engine56_vision4_profile.py','run_engine56_large_chunk_profiles.py','run_engine56_chunk_cases.py','run_engine56_stage_smoke.py']]
for p in paths:compile(p.read_text(),str(p),'exec')
ns['archive']('drivers',paths,'drivers_manifest.json');print('prepared C16, functional3 and checked engine56 native drivers')
