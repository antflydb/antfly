from pathlib import Path
import datetime,hashlib,json,os,psutil,re,statistics,subprocess,sys,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while True:
 q=Path('/private/tmp/ocr-engine90-qualification-parent.txt');s=q.read_text()if q.exists()else''
 if 'ENGINE90 QUALIFICATION DONE'in s:break
 if 'Traceback'in s or any('DONE ENGINE90 '+k+' 1'in s for k in ['image','gpu','cpu','finalize']):raise RuntimeError(s[-3000:])
 time.sleep(5)
for p,h in json.loads((v/'engine90-freeze.json').read_text()).items():assert sha(r/p)==h,p
m=json.loads((o/'engine90_build_manifest.json').read_text());binary=Path(m['binary_path']);assert sha(binary)==m['binary_sha256']
a=o/'engine90_precision_memory_screen74_audit.json';assert not a.exists();d=dict(status='waiting_original_4b_admission',primary_throughput_eligible=False,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='One resident4B model, five R128 precision rounds: OFF saturation warm excluded, then OFF/ON/ON/OFF decode BF16 input ABBA. Prefill remains BF16 in every round, original weights/F32 accumulators/F32 recurrent states/original caps/reserve. FFN option stays OFF. Every output must equal F32 serial references and full saved cross-runtime fixture strings. Outside-timing buffer lifetime gauges and5-second RSS/system-available samples diagnose retention; these gauges are not physical GPU residency. HistoricalvLLM report used only as full-string oracle, never timing comparator. No own compile or other GPU job overlaps. Profile selection excludes round0 and requires bothBF16 ON rounds to exceed both saturated F32 controls by5%.',binary_sha256=m['binary_sha256'],driver_sha256=sha(Path(__file__)),monitor_samples=[])
def save():a.write_text(json.dumps(d,indent=2)+'\n')
save()
while psutil.virtual_memory().available<11348275670+6*1024**3+512*1024**2:
 print('WAIT PRECISION74 original admission',psutil.virtual_memory().available,flush=True);time.sleep(30)
label='precision_memory_screen74_offwarm_off_on_on_off_c64_r128';dest=o/('engine90_4b_'+label);assert not dest.exists();env=dict(os.environ)
env.update(OCR_REFERENCE_LABEL='_primary_reference73_r0_auto_c64_r128_ctx1024',OCR_PHYSICAL32='0',OCR_PHYSICAL64='1',OCR_CONCURRENCY='64',OCR_REQUESTS='128',OCR_WIDE='1',OCR_KV_GIB='4',OCR_BACKEND_GIB='17',OCR_SCRATCH_GIB='10',OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES=','.join(['engineepoch']*5),OCR_SHARED_CORE='1',OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_DISABLE_64_ROW_TILE='0',OCR_DISABLE_WIDE_GATE_UP='0',OCR_WIDE64_GATE_UP='1',OCR_FULL64_GATE_UP='1',OCR_GPU_GREEDY_STREAM='0',OCR_STREAM_CHUNK_LAYERS='0',OCR_VISION_BATCH='0',OCR_VISION_BATCH_ITEMS='1',OCR_VISION_WAIT_US='2000',OCR_PREFILL_BATCH='0',OCR_PREFILL_BATCH_ITEMS='1',OCR_PREFILL_WAIT_US='100000',OCR_VISION_FRAME_BLOCKS='3',OCR_SINGLE_FRAME='1',OCR_STREAM_FIRST='0',OCR_LOGICAL64='1',OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',OCR_ADMISSION_UNITS='512',OCR_BATCH_ARGMAX='1',OCR_DEFER_VISION_SEAL='0',OCR_DEFER_PREFILL_SEAL='0',OCR_CACHE_VISION_WORKSPACE='1',OCR_LARGE_VISION_PACK_REUSE='0',ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY='0',OCR_TIMEOUT='1800',OCR_PREFILL_FUSED_FFN='0',OCR_RESIDENT_VISION_BUDGET='1',OCR_GPU_TOKEN_BURST='1',OCR_GPU_TOKEN_BURST_WIDTH='4',OCR_PIPELINE_VISION='0',OCR_PREFILL_STREAM_LAYERS='0',OCR_BF16_ROUNDS='off,off,on,on,off',OCR_REQUIRE_MEMORY_ROUNDS='1')
env.pop('OCR_PREFILL_FFN_ROUNDS',None)
d['status']='running';save();print('START RESIDENT PRECISION74 OFFWARM/OFF/ON/ON/OFF',flush=True)
with Path('/private/tmp/ocr-engine90-precision74-driver.txt').open('w')as log:
 p=subprocess.Popen([sys.executable,str(v/'run_engine90_budget_policies.py'),'4b:'+label],env=env,stdout=log,stderr=subprocess.STDOUT)
 started=time.monotonic()
 while p.poll()is None:
  for child in psutil.Process(p.pid).children(recursive=True):
   try:
    cmd=child.cmdline()
    if cmd and cmd[0]==str(binary):
     raw=dest/'lighton4b-batch-c64.txt';text=raw.read_text()if raw.exists()else'';rounds=re.findall(r'OCR_POLICY round=(\d+)',text)
     d['monitor_samples'].append(dict(elapsed_seconds=round(time.monotonic()-started,3),pid=child.pid,round=int(rounds[-1])if rounds else None,rss_bytes=child.memory_info().rss,available_bytes=psutil.virtual_memory().available));save()
   except(psutil.NoSuchProcess,psutil.AccessDenied):pass
  time.sleep(5)
 d['exit_code']=p.returncode;save();assert p.returncode==0,p.returncode
p=dest/'report.json';nd=json.loads(p.read_text());result=nd['results'][0];samples=result['policy_rounds'];assert result['status']=='ok'and result['serial_reference_parity']and result['cross_runtime_content_parity']
assert [s['bf16_projection_enabled']for s in samples]==[False,False,True,True,False]
for s in samples:
 assert s['completed']==128 and not s['admission_pressures']and s['prefill_fused_ffn_calls']==0
 assert (s['decode_pack_calls']>0)==s['bf16_projection_enabled']
 assert s['host_recurrent_bytes_total']==s['single_frame_topology_mismatches']==s['gpu_token_burst_topology_mismatches']==0
 assert set(s['buffer_lifetime_gauges'])=={'before','after'}
controls=[samples[1],samples[4]];on=[samples[2],samples[3]];ratios=[s['pages_per_second']/max(x['pages_per_second']for x in controls)for s in on]
d.update(status='bf16_screen_win'if min(ratios)>1.05 else'hold_no_clear_bf16_screen_win',report=str(p.relative_to(o)),report_sha256=sha(p),saturation_warm_excluded_round=0,rounds=[{k:s.get(k)for k in ['round','pages_per_second','bf16_projection_enabled','decode_pack_calls','process_cpu_ms','framed_runtime_totals','buffer_lifetime_gauges']}for s in samples],bf16_to_strongest_saturated_f32_ratios=ratios)
save();print('PRECISION74 DONE',d['status'],ratios,flush=True)
