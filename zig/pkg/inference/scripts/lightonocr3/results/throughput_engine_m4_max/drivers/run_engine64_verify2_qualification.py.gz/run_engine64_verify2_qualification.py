from pathlib import Path
import hashlib,json,subprocess,sys
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
a=json.loads((o/'engine64_c_qualification_audit.json').read_text());assert a['status']=='pass'and len(a['checks'])==18
for p,h in a['input_sha256'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
for name,cmd in [('verify2-gpu-build',[sys.executable,str(v/'run_engine64_verify2_gpu_build.py')]),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine64','/private/tmp/ocr-engine64-verify2-gpu-build.txt']),('metal-disabled',[sys.executable,str(v/'run_engine64_metal_disabled.py')])]:
 print('START',name,flush=True)
 with Path('/private/tmp/ocr-engine64-verify2-'+name+'-driver.txt').open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True);assert r.returncode==0,(name,r.returncode)
print('ENGINE64 VERIFY2 QUALIFICATION DONE',flush=True)
