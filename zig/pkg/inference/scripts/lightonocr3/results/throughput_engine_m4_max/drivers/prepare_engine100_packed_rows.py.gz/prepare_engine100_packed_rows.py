from pathlib import Path
import difflib,json,hashlib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';p=Path('zig/pkg/inference/src/pipelines/generation.zig');original=p.read_text();s=original;start=s.index('    fn forwardPackedScheduledQwenStep(');end=s.index('\n    fn forwardScheduledStep(',start);part=s[start:end];a=part.index('        for (claimed, 0..) |item, index| {\n            if (item.phase == .prefill) {',part.index('        var consumed = false;'));b=part.index('        consumed = true;',a)
part=part[:a]+'''        var embedding_weight: ?CT = null;
        defer if (embedding_weight) |weight| cb.free(weight);
        var index: usize = 0;
        while (index < claimed.len) {
            const item = claimed[index];
            if (item.phase == .prefill) {
                const work: *PendingPrefillBatchWork = @ptrCast(@alignCast(item.work_ptr));
                if (!try cb.copyRows2D(a, combined, offsets[index], work.prepared_prompt.?.input_embeddings.?, 0, lengths[index], cfg.hidden_size)) return error.UnsupportedTensorType;
                index += 1;
            } else {
                var count: usize = 1;
                while (index + count < claimed.len and claimed[index + count].phase == .decode) : (count += 1) {}
                var ids: [64]i64 = undefined;
                for (claimed[index..][0..count], 0..) |decode, row| {
                    const work: *PendingDecodeBatchWork = @ptrCast(@alignCast(decode.work_ptr));
                    ids[row] = work.token_id;
                }
                if (embedding_weight == null) embedding_weight = try gpt_arch.getEmbeddingWeight(cb, cfg);
                const embedding = try cb.embeddingLookup(embedding_weight.?, ids[0..count], count, cfg.hidden_size);
                defer cb.free(embedding);
                if (!try cb.copyRows2D(a, combined, offsets[index], embedding, 0, count, cfg.hidden_size)) return error.UnsupportedTensorType;
                index += count;
            }
        }
'''+part[b:]
a=part.index('        const last = (try cb.allocUninitF32Shape(');b=part.index('        const head = ',a)
part=part[:a]+'''        // The model has closed its frame. One gather selects every page's
        // final row without issuing an owned blit/submit/wait per page.
        var last_indices: [64]i64 = undefined;
        for (claimed, 0..) |_, row| last_indices[row] = @intCast(offsets[row] + lengths[row] - 1);
        const last = try cb.embeddingLookup(hidden.hidden, last_indices[0..claimed.len], claimed.len, cfg.hidden_size);
        defer cb.free(last);
'''+part[b:]
s=s[:start]+part+s[end:];diff=''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/'+str(p),tofile='b/'+str(p)));q=v/'engine100-unqualified.patch';assert not q.exists();q.write_text(diff);(v/'engine100_rows_preparation.json').write_text(json.dumps(dict(scope='Prepared only; notapplied/compiled/executed. Batchcontiguousdecodeembeddings andgatherlastrowsinonekernelafterframeclosure. Noarithmeticalordtypechange; existingF32gatherlookup reused.',base_file_sha256=hashlib.sha256(original.encode()).hexdigest(),patch_sha256=hashlib.sha256(diff.encode()).hexdigest()),indent=2)+'\n');print('Prepared patch; canonicalsource99untouched')
