// Copyright 2026 Antfly, Inc.
// SPDX-License-Identifier: Apache-2.0
#define main production_checks_main
#include "../zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m"
#undef main
int main(void) {@autoreleasepool {
 const char *flags[]={"TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY","TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_COALESCING","TERMITE_METAL_ENABLE_LIGHTONOCR3_WEIGHT_RESIDENCY"};
 const char *falsy[]={"","0","false","FALSE","no","off"};
 setenv("ANTFLY_LIGHTONOCR3_THROUGHPUT","1",1);
 const bool eligible=termite_metal_qualified_m4_device_default()!=0;
 for(size_t f=0;f<3;f++){
  unsetenv(flags[f]);if(termite_metal_lightonocr3_profile_feature_enabled(flags[f])!=eligible)return 1;
  for(size_t v=0;v<6;v++){setenv(flags[f],falsy[v],1);if(termite_metal_lightonocr3_profile_feature_enabled(flags[f]))return 2;}
  unsetenv(flags[f]);
 }
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 3;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);
 if(termite_metal_decode_runtime_begin_frame(r)||r->lighton_frame_policy_valid!=eligible)return 4;
 if(termite_metal_decode_runtime_cancel_frame(r))return 5;
 setenv(flags[0],"0",1);
 if(termite_metal_decode_runtime_begin_frame(r)||r->lighton_frame_policy_valid)return 6;
 if(termite_metal_decode_runtime_cancel_frame(r))return 7;
 setenv("ANTFLY_LIGHTONOCR3_THROUGHPUT","0",1);
 for(size_t f=0;f<3;f++){unsetenv(flags[f]);if(termite_metal_lightonocr3_profile_feature_enabled(flags[f]))return 8;}
 termite_metal_decode_runtime_destroy(r);
 fprintf(stderr,"profile_default_check flags=3 falsy_cases=18 frame_begin_override_pass=1 eligible=%d\n",eligible);return 0;
}}
