from pathlib import Path
import subprocess,sys,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
for name in ['engine99_mixed_screen79_audit.json','engine101_mixed_screen82_audit.json']:assert json.loads((o/name).read_text())['status']=='mixed_screen_pass'
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),*[f'engine{x}_*'for x in range(96,102)]],check=True)
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
logs=[];drivers=[]
for tag in range(96,102):
 logs += list(Path('/private/tmp').glob(f'ocr-engine{tag}-*.txt'))
 drivers += [p for p in v.glob(f'*engine{tag}*')if p.is_file()and p.suffix in ['.py','.m','.metal','.inc','.json','.patch','.zig']]
ns['archive']('qualification',sorted(set(logs)),'logs_manifest.json')
import hashlib
index=json.loads((o/'drivers/drivers_manifest.json').read_text());renamed=[]
for p in sorted(set(drivers)):
 h=hashlib.sha256(p.read_bytes()).hexdigest();entry=index.get(p.name+'.gz')
 if entry and entry['raw_sha256']!=h:
  q=v/(p.stem+'_closed101_'+h[:10]+p.suffix);assert not q.exists()or q.read_bytes()==p.read_bytes();q.write_bytes(p.read_bytes());renamed.append(q)
 else:renamed.append(p)
ns['archive']('drivers',renamed,'drivers_manifest.json')
print('Archived closed96-101 evidence; source102activejobs untouched.',flush=True)
