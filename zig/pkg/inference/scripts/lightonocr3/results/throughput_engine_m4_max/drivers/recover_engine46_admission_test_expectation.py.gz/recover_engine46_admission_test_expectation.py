from pathlib import Path
import hashlib,json,gzip,subprocess
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=json.loads((v/'engine46-freeze.json').read_text());assert all(sha(Path(p))==s for p,s in frozen.items())
patch=subprocess.check_output(['git','diff','--',*frozen]);(out/'engine46_initial_build_runtime.patch.gz').write_bytes(gzip.compress(patch,mtime=0))
binary=Path('zig/.zig-cache/o/7b16b1abc89813100cb95698047ab368/test')
audit=dict(status='failed_test_expectation',selected=234,passed=232,skipped=1,failed=1,leaked=0,
 reason='Supplemental deficit fits individually, but cannot fit while the base is retained. Ordinary Session.admitSupplement returns ResourceTemporarilyUnavailable here, matching existing session tests. The new test expected ResourceLimitExceeded. Production admission code is unchanged.',
 runtime_files_sha256=frozen,runtime_source_diff_sha256=hashlib.sha256(patch).hexdigest(),binary_path=str(binary.resolve()),binary_sha256=sha(binary))
(out/'engine46_initial_build_failure_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('qualification',[Path('/private/tmp/ocr-engine46-verify-gpu-build.txt'),Path('/private/tmp/ocr-engine46-verify-gpu-build-driver.txt')],'logs_manifest.json')
p=Path('zig/pkg/inference/src/pipelines/reading.zig');s=p.read_text()
old='try std.testing.expectError(error.ResourceLimitExceeded, admitFlorenceFullPrefixFallback(session, &base, full));'
new='try std.testing.expectError(error.ResourceTemporarilyUnavailable, admitFlorenceFullPrefixFallback(session, &base, full));'
assert s.count(old)==1;p.write_text(s.replace(old,new))
# Keep executed initial input files immutable. Retry drivers use a new freeze
# filename; final output names remain engine46 for the downstream verifiers.
s=(v/'run_engine46_verify_gpu_build_final.py').read_text().replace('ocr-engine46-verify-gpu-build','ocr-engine46-verify-gpu-build-retry')
(v/'run_engine46_verify_gpu_build_retry.py').write_text(s)
s=(v/'build_engine46_conformance.py').read_text().replace('engine46-freeze.json','engine46-freeze_retry.json')
(v/'build_engine46_conformance_retry.py').write_text(s)
s=(v/'finalize_engine_build.py').read_text()
old="f'{name}-freeze.json'";assert s.count(old)==1
s=s.replace(old,"'engine46-freeze_retry.json'")
(v/'finalize_engine46_build_retry.py').write_text(s)
(v/'engine46-freeze_retry.json').write_text(json.dumps({p:sha(Path(p))for p in frozen},indent=2)+'\n')
ns['archive']('drivers',[v/x for x in ['recover_engine46_admission_test_expectation.py','run_engine46_verify_gpu_build_retry.py','build_engine46_conformance_retry.py','finalize_engine46_build_retry.py','engine46-freeze_retry.json']],'drivers_manifest.json')
print('Corrected only the new supplemental-denial test expectation; production bytes unchanged.')
