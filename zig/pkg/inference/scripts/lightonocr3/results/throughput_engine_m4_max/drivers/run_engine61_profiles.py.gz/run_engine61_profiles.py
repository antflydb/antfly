from pathlib import Path
import subprocess,sys,os,json,collections,hashlib,time
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');records=[]
parent=Path('/private/tmp/ocr-engine61-build-qualification-parent.txt')
while 'ENGINE58 BUILD QUALIFICATION DONE'not in parent.read_text():
 if 'Traceback'in parent.read_text():raise RuntimeError('build qualification failed')
 time.sleep(5)
assert (o/'engine61_build_manifest.json').exists()
old=json.loads((o/'engine60_profiles_verified_partial_audit.json').read_text());c64=next(x for x in old['candidates']if x['settings']==[64,1,1,2,0,0,0]);assert c64['eligible'];assert hashlib.sha256((o/c64['report']).read_bytes()).hexdigest()==c64['report_sha256'];c64=dict(c64,selection='Fixed C64/P1 candidate retained from prior-runtime qualification; new engine61 R128 runs independently validate it.');c64.pop('compiled_runtime_reused_byte_identical',None);records=[c64]
for c,p,vis,vf,sv,sp,q in [(56,1,1,4,0,0,0),(40,8,1,2,0,1,0)]:
 tag=f'queued_priority_v{vis}_sv{sv}_sp{sp}_q{q}'
 env=os.environ.copy();env.update(OCR_CASE_CONCURRENCY=str(c),OCR_CASE_PREFILL_ITEMS=str(p),OCR_CASE_VISION_FRAME_BLOCKS=str(vf),OCR_CASE_VISION_BATCH_ITEMS=str(vis),OCR_CASE_TAG=tag,OCR_BATCH_ARGMAX='1',OCR_CACHE_VISION_WORKSPACE='1',OCR_LARGE_VISION_PACK_REUSE=str(int(vis>1)),OCR_DEFER_VISION_SEAL=str(sv),OCR_DEFER_PREFILL_SEAL=str(sp),ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY=str(q),OCR_TIMEOUT='240')
 env['OCR_PREFILL_WAIT_US']='1000000'if p==8 else'100000'
 print('START',c,p,vis,vf,sv,sp,q,flush=True)
 r=subprocess.run([sys.executable,str(v/'run_engine61_prefill8_profile.py'),'4b','0'],env=env)
 print('DONE',c,p,vis,vf,sv,sp,q,r.returncode,flush=True)
 label=f'engine61_4b_rolling_chunks0_trial0_c{c}_p{p}_vf{vf}_r64_{tag}';report=o/label/'report.json'
 if r.returncode:
  assert report.exists(),label
  raw=report.parent/f'lighton4b-batch-c{c}.txt';text=raw.read_text()
  if 'admission_pressure='in text:reason='admission_pressure'
  elif 'Timeout'in text or 'DeadlineExceeded'in text:reason='runtime_timeout'
  else:raise RuntimeError((label,'unexpected failure'))
  records.append(dict(settings=[c,p,vis,vf,sv,sp,q],eligible=False,reason=reason,report=str(report.relative_to(o))))
 else:
  d=json.loads(report.read_text());s=d['results'][0]['policy_rounds'][0]
  assert d['queued_phase_priority']==bool(q) and s['completed']==64 and not s['admission_pressures']
  assert all(x['items']==1 or x['items']*x['tokens_per_item']<=4096 for x in s['prefill_batches'])
  records.append(dict(settings=[c,p,vis,vf,sv,sp,q],prefill_wait_us=int(env['OCR_PREFILL_WAIT_US']),eight_page_group_observed=any(x['items']==8 for x in s['prefill_batches']),eligible=True,pages_per_second=s['pages_per_second'],process_cpu_ms=s['process_cpu_ms'],average_decode_rows=s['average_decode_rows'],prefill_sizes=dict(collections.Counter(x['items']for x in s['prefill_batches'])),vision_sizes=dict(collections.Counter(s['vision_batch_sizes'])),report=str(report.relative_to(o)),report_sha256=hashlib.sha256(report.read_bytes()).hexdigest()))
 (o/'engine61_profiles_audit.json').write_text(json.dumps(dict(status='running',candidates=records),indent=2)+'\n')
(o/'engine61_profiles_audit.json').write_text(json.dumps(dict(status='pass',candidates=records),indent=2)+'\n')
print('ALL ENGINE61 PROFILES COMPLETE',flush=True)
