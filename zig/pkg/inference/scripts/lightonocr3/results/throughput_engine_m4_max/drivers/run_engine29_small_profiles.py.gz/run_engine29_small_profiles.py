from pathlib import Path
import os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');base=os.environ.copy();base.update(OCR_REFERENCE_LABEL='_primary_reference7_auto_c32_r128',OCR_PHYSICAL32='0',OCR_CONCURRENCY='16',OCR_REQUESTS='128',OCR_WIDE='1',OCR_SCRATCH_GIB='8',OCR_STREAM_FIRST='0',OCR_SINGLE_FRAME='0',OCR_POLICIES='engineepoch',OCR_BF16='0',OCR_VISION_BATCH='0',OCR_VISION_FRAME_BLOCKS='4',OCR_PREFILL_WAIT_US='100000',OCR_PREFILL_DECODE_STREAK='0')
for hook,shared,prefill in [(0,1,0),(0,1,1),(1,1,0),(1,1,1)]:
 env=base.copy();env.update(OCR_SHARED_CORE=str(shared),OCR_BF16_PREFILL=str(prefill));label=f'vision4_c16_streak0_hook{hook}_cache{shared}_prefill{prefill}_r128_0';print('START',label,flush=True)
 driver='run_engine29_budget_policies.py'if hook else'run_engine29_checked_no_prefill_policies.py'
 r=subprocess.run([sys.executable,str(v/driver),'08:'+label],env=env);print('DONE',label,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
