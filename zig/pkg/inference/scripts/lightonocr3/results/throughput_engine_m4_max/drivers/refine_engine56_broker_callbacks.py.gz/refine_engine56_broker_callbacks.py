from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal');p=v/'engine56-proposal/zig/pkg/inference/src/server/executor_microbatch.zig';s=p.read_text()
old='''                const ticket_live = !expired and !ticket.cancel_requested.load(.acquire) and !isCanceled(ticket.cancellation);
                live = live or ticket_live;
                if (ticket_live) if (ticket.deadline) |deadline| {
                    if (live_deadline == null or deadline.raw.nanoseconds < live_deadline.?.raw.nanoseconds) live_deadline = deadline;
                };'''
new='''                if (!expired and !ticket.cancel_requested.load(.acquire)) {
                    // One live member is sufficient to keep the group queued.
                    // Avoid repeatedly checking every request's callback while
                    // another stage owns this lane. An unexpired canceled
                    // member may shorten this wait once; it cannot extend it.
                    live = live or !isCanceled(ticket.cancellation);
                    if (ticket.deadline) |deadline| {
                        if (live_deadline == null or deadline.raw.nanoseconds < live_deadline.?.raw.nanoseconds) live_deadline = deadline;
                    }
                }'''
assert old in s;s=s.replace(old,new);p.write_text(s)
(v/'engine56_executor_microbatch_verify2.zig').write_text(s)
print('kept one-live-member short circuit and bounded deadlines')
