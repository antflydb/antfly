from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine46_verify_gpu_build.py').read_text()
needle="env['ANTFLY_TEST_OCR_RASTER_PARITY']='0'"
assert s.count(needle)==1
s=s.replace(needle,needle+"""
env['TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP']='0'
env['ANTFLY_TEST_FLORENCE2_INCREMENTAL_FALLBACK']='0'
env['ANTFLY_FLORENCE2_INCREMENTAL_ADMISSION']='1'""")
p=v/'run_engine46_verify_gpu_build_final.py';assert not p.exists();p.write_text(s)
s=(v/'build_engine45_conformance.py').read_text().replace('engine45','engine46')
s=s.replace('import json,hashlib,subprocess','import json,hashlib,subprocess,os')
s=s.replace('r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)','r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/\"clang-cache\")))')
p=v/'build_engine46_conformance.py';assert not p.exists();p.write_text(s)
s=(v/'run_engine45_c_qualification.py').read_text().replace('engine45','engine46')
s=s.replace("flags=['--check-wide-gate-up',","flags=['--check-wide-gate-up-full64','--check-wide-gate-up',")
s=s.replace("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP='0'","TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP='0',TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP='0'")
p=v/'run_engine46_c_qualification.py';assert not p.exists();p.write_text(s)
p=v/'engine46_benchmark_concurrency.py';assert not p.exists();p.write_bytes(Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
old=json.loads((v/'engine45-freeze.json').read_text())
p=v/'engine46-freeze.json';assert not p.exists()
p.write_text(json.dumps({k:hashlib.sha256(Path(k).read_bytes()).hexdigest() for k in old},indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('drivers',[v/x for x in ['prepare_engine46_build_inputs.py','run_engine46_verify_gpu_build_final.py','build_engine46_conformance.py','run_engine46_c_qualification.py','engine46_benchmark_concurrency.py','engine46-freeze.json']],'drivers_manifest.json')
print('Frozen 21 engine46 inputs; no BF16 precision changes; 13 C suites planned.')
