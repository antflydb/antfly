from pathlib import Path
p=Path('zig/pkg/inference/src/server/reader_execution_pool.zig');s=p.read_text().replace('capacity > 16','capacity > 32',1)
s+='''
test "LightOnOCR3 logical window keeps thirty-two independent leases bounded" {
    const Fake = struct {
        created: usize = 0,
        destroyed: usize = 0,
        fn create(raw: *anyopaque) !*anyopaque {
            const self: *@This() = @ptrCast(@alignCast(raw));
            self.created += 1;
            return raw;
        }
        fn destroy(raw: *anyopaque) void {
            const self: *@This() = @ptrCast(@alignCast(raw));
            self.destroyed += 1;
        }
    };
    var fake = Fake{};
    var pool = Pool{};
    try std.testing.expectError(error.InvalidReaderCapacity, pool.join(.{}, 33, &fake, Fake.create, Fake.destroy));
    var leases: [32]Pool.Lease = undefined;
    for (&leases) |*lease| lease.* = try pool.join(.{}, 32, &fake, Fake.create, Fake.destroy);
    try std.testing.expectEqual(@as(usize, 32), pool.users);
    try std.testing.expectEqual(@as(usize, 1), fake.created);
    for (1..32) |i| {
        leases[i].release();
        leases[i] = try pool.join(.{}, 32, &fake, Fake.create, Fake.destroy);
        try std.testing.expectEqual(leases[0].context, leases[i].context);
    }
    try std.testing.expectEqual(@as(usize, 0), fake.destroyed);
    for (&leases) |*lease| lease.release();
    try std.testing.expectEqual(@as(usize, 1), fake.destroyed);
    try std.testing.expect(pool.context == null and pool.users == 0);
}
''';p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text().replace('        controls: [16]?InferenceExecutionControl = @splat(null),','        controls: [32]?InferenceExecutionControl = @splat(null),',1).replace('The pool admits at most sixteen live page leases.','The pool admits at most thirty-two live page leases.',1)
s=s.replace('''fn effectiveLightOnReadWindow() usize {
    return @min(@max(platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_BATCH_WINDOW") orelse 8, 1), 16);
}''','''fn effectiveLightOnReadWindow() usize {
    // A wider logical window can keep the physical sixteen-row forward full
    // while peers finish vision/prefill or retire. Every page still acquires
    // its own resource lease; this does not increase a forward's row limit.
    const ceiling: usize = if (platform.env.getenvBool("ANTFLY_LIGHTONOCR3_WIDE_DECODE")) 32 else 16;
    return @min(@max(platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_BATCH_WINDOW") orelse 8, 1), ceiling);
}''',1);p.write_text(s)
