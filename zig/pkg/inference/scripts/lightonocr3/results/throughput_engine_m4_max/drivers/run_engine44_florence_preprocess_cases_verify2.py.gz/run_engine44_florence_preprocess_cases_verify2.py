from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';p=root/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_engine_m4_max'
mode=sys.argv[1];assert mode in ['qualification','primary']
manifest=out/'engine44_build_manifest.json';binary=json.loads(manifest.read_text())['binary_path']
oracle=out/'mlx_florence_engine37_paired19_r1_reference/report.json'
old=json.loads((out/'engine37_florence_encoder_qualification_enabled0/report.json').read_text())
old_texts={x['image_index']:x['text']for x in old['results'][0]['references']}
proxy_texts={i:x['text']for i,x in enumerate(json.loads(oracle.read_text())['references'])}
cases=[(8,8,16,False),(8,8,16,True),(1,1,3,False),(1,1,3,True)] if mode=='qualification' else [(c,8,128,e) for c in [8,16,32] for e in [False,True]]
records=[]
for c,b,n,enabled in cases:
 label=f'florence_cpu_preprocess_enabled{int(enabled)}_c{c}_rows{b}_r{n}_{mode}_verify2'
 dest=out/f'engine44_{label}';assert not(dest/'report.json').exists()
 env=os.environ.copy();env['PYTHONPATH']=str(p);env['ANTFLY_FLORENCE_CPU_PREPROCESS']=str(int(enabled))
 cmd=[sys.executable,str(v/'engine44_benchmark_concurrency.py'),'--native-test',binary,
  '--model','florence=/Users/ajroetker/.antfly/inference/models/antflydb/florence-2-base',
  '--images',str(root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(p/'corpus/receipt.png'),str(p/'corpus/shipping.png'),
  '--requests',str(n),'--concurrency',str(c),'--max-tokens','256','--modes','batch','--native-read-batch-size',str(b),
  '--batch-wait-us','5000','--florence-batch-wait-us','5000','--memory-gib','24','--shared-memory-gib','28',
  '--backend-memory-gib','16','--kv-memory-gib','4','--scratch-memory-gib','8','--timeout','900',
  '--reference-report',str(oracle),'--build-manifest',str(manifest),'--output-dir',str(dest),'--policy-rounds','current']
 if b>1:cmd+=['--require-florence-no-repeat-argmax','--require-florence-single-frame']
 print('START',label,flush=True)
 with Path('/private/tmp/ocr-engine44-'+label+'-driver.txt').open('w')as log:
  r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('DONE',label,r.returncode,flush=True);assert r.returncode==0,(label,r.returncode)
 rp=dest/'report.json';d=json.loads(rp.read_text());d['cpu_preprocess_overlap']=enabled;d['driver_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 rp.write_text(json.dumps(d,indent=2)+'\n')
 r=d['results'][0];sample=r['policy_rounds'][0]
 assert r['status']=='ok' and r['serial_reference_parity'] and r['cross_runtime_content_parity'] and sample['completed']==n
 texts={x['image_index']:x['text']for x in r['references']}
 assert texts==old_texts, (label,'changed native full fixture strings')
 assert {k:''.join(t.split())for k,t in texts.items()}=={k:''.join(t.split())for k,t in proxy_texts.items()}
 if b>1:
  f=r['florence_single_frame'];assert f['steps']>0 and f['api_fallbacks']==0 and f['topology_mismatches']==0,f
 raw=(dest/r['log']).read_text();assert 'admission_pressure='not in raw
 records.append(dict(cpu_preprocess_overlap=enabled,concurrency=c,model_batch_size=b,completed=n,
  pages_per_second=sample['pages_per_second'],process_cpu_ms=sample['process_cpu_ms'],
  native_full_fixture_string_identity=True,all_native_pages_equal_native_serial=True,
  cross_runtime_full_fixture_string_identity=texts==proxy_texts,cross_runtime_whitespace_normalized_content=True,
  single_frame=r.get('florence_single_frame'),primary_throughput_eligible=mode=='primary',
  own_cpu_compile_or_sampling_overlap=False,report=str(rp.relative_to(out)),report_sha256=hashlib.sha256(rp.read_bytes()).hexdigest()))
 audit=out/f'engine44_florence_preprocess_{mode}_audit.json'
 audit.write_text(json.dumps(dict(status='running',records=records,scope='Florence native Q4_K/no-repeat-trigram policy vs MLX FP16/default greedy serial proxy; installed vLLM Metal has no Florence adapter. Own full raw text must remain exact; cross-runtime parity is whitespace normalized.'),indent=2)+'\n')
audit.write_text(json.dumps(dict(status='pass',records=records,scope='Native geometry and CPU overlap comparison, not a fresh proxy win.'),indent=2)+'\n')
