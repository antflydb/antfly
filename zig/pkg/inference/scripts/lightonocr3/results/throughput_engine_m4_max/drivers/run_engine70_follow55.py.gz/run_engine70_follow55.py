from pathlib import Path
import subprocess,sys,json,hashlib,time
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';o=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
while True:
 p=Path('/private/tmp/ocr-engine70-qualification-parent-attempt2.txt');s=p.read_text()if p.exists()else''
 if 'ENGINE70 QUALIFICATION DONE'in s:break
 if 'Traceback'in s:raise RuntimeError(s[-1500:])
 time.sleep(5)
# The checker rebuild and the second test controller briefly overlapped before
# the frame-policy check. Re-run the whole C suite from the finalized binary to
# bind every result to the manifest's exact checker hash.
a=o/'engine70_c_qualification_audit.json';a.rename(o/'engine70_c_qualification_before_final_identity_audit.json')
for p in Path('/private/tmp').glob('ocr-engine70-c-*.txt'):
 if 'attempt1'not in p.name and 'build'not in p.name and 'driver'not in p.name:p.rename(p.with_name(p.stem+'-before-final-identity'+p.suffix))
with Path('/private/tmp/ocr-engine70-c-final-identity-driver.txt').open('w')as f:subprocess.run([sys.executable,str(v/'run_engine70_c_qualification.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
m=json.loads((o/'engine70_c_build_manifest.json').read_text());assert sha(root/m['binary'])==m['binary_sha256'];assert all(sha(root/p)==h for p,h in m['input_sha256'].items())
d=json.loads(a.read_text());assert d['status']=='pass';d.update(input_sha256=m['input_sha256'],binary_sha256=m['binary_sha256'],all_checks_executed_after_final_checker_build=True);a.write_text(json.dumps(d,indent=2)+'\n')
print('FINAL C BINARY IDENTITY QUALIFIED',flush=True)
subprocess.run([sys.executable,str(v/'run_engine70_api_paired55.py')],check=True)
print('ENGINE70 PAIRED55 DONE',flush=True)
