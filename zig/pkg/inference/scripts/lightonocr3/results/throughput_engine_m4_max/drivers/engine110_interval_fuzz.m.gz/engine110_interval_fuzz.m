#include "../zig/pkg/inference/src/backends/metal_kernels.m"
static uint64_t interval_seed=UINT64_C(0x482e09261ad53b7f);
static uint32_t interval_random(void){interval_seed^=interval_seed<<13;interval_seed^=interval_seed>>7;interval_seed^=interval_seed<<17;return(uint32_t)interval_seed;}
int main(void){@autoreleasepool{
 termite_metal_decode_runtime*r=calloc(1,sizeof(*r));if(!r)return 1;
 void*prior[64][15];size_t old_offsets[64][15],old_counts[64][15];size_t accepted=0,rejected=0;
 const size_t writes[6]={7,8,9,10,11,14};
 for(size_t trial=0;trial<2400;trial++){
  memset(r->qwen35_core_batch_interval_heads,0,sizeof(r->qwen35_core_batch_interval_heads));r->qwen35_core_batch_interval_count=0;
  size_t rows=0;
  for(size_t row=0;row<64;row++){
   void*handles[15];size_t offsets[15],counts[15];
   for(size_t j=0;j<15;j++){
    size_t id,offset,count;
    if(trial%4==0){id=1+j;offset=row*1024+(interval_random()%16)*16;count=1+interval_random()%32;}
    else if(trial%4==1){id=1+interval_random()%12;offset=(interval_random()%512)*16;count=1+interval_random()%128;}
    else if(trial%4==2){id=1+(j%3);offset=row*2048+(interval_random()%32)*16;count=1+interval_random()%64;}
    else{id=1+row*15+j;offset=(interval_random()%32)*16;count=1+interval_random()%64;}
    handles[j]=(void*)(uintptr_t)(id*16);offsets[j]=offset;counts[j]=count;
   }
   // Exercise late conflicts, shared read-only aliases and partial overlap.
   if(row>0&&trial%4==3&&row==63){size_t peer=interval_random()%row;handles[8]=prior[peer][8];offsets[8]=old_offsets[peer][8]+(trial%2?4:0);counts[8]=old_counts[peer][8];}
   bool conflict=false;
   for(size_t peer=0;peer<rows;peer++)for(size_t w=0;w<6;w++)for(size_t k=0;k<15;k++){
    size_t j=writes[w];
    if(handles[j]==prior[peer][k]&&offsets[j]<old_offsets[peer][k]+old_counts[peer][k]*4&&old_offsets[peer][k]<offsets[j]+counts[j]*4)conflict=true;
    if(prior[peer][j]==handles[k]&&old_offsets[peer][j]<offsets[k]+counts[k]*4&&offsets[k]<old_offsets[peer][j]+old_counts[peer][j]*4)conflict=true;
   }
   int result=termite_metal_qwen35_core_collect_intervals(r,handles,offsets,counts);
   if(result!=(conflict?-11:0)){fprintf(stderr,"INTERVAL_FUZZ_FAIL trial=%zu row=%zu expected=%d actual=%d\n",trial,row,conflict?-11:0,result);return 2;}
   if(conflict){rejected++;break;}accepted++;
   memcpy(prior[rows],handles,sizeof(handles));memcpy(old_offsets[rows],offsets,sizeof(offsets));memcpy(old_counts[rows],counts,sizeof(counts));rows++;
  }
 }
 free(r);printf("INTERVAL_FUZZ_PASS trials=2400 accepted_rows=%zu rejected_rows=%zu legacy_oracle_exact=1 gpu_dispatches=0\n",accepted,rejected);return 0;
}}
