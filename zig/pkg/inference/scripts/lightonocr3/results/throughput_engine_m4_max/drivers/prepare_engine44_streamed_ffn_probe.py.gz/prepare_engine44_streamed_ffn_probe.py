from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal')
kernels=Path('zig/pkg/inference/src/backends/metal_kernels.m')
(v/'engine44_streamed_ffn_probe_kernels.m').write_bytes(kernels.read_bytes())
checker=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine44_streamed_ffn_probe_kernels.m"')
(v/'engine44_streamed_ffn_probe_checks.m').write_text(checker)
(v/'engine44_streamed_ffn_probe.metal').write_bytes((v/'engine42_wide_ffn_probe.metal').read_bytes())
(v/'engine44-streamed-ffn-probe-plan.json').write_text(json.dumps(dict(base_engine='engine43',base_c_sha256=hashlib.sha256(kernels.read_bytes()).hexdigest(),models=['4b'],rows=[64,48,33],variants=[0,3,4,5],layers=32,weight_slots=64,trials_per_leg=8,warm_frames_per_leg=2,checks='Full GPU output against old generic BF16 fused baseline, CPU corners, persistent nonzero-offset canaries, actual GPU input producer; validation only after each complete ABBA leg. 32 distinct pairs (~3 GiB weights), one planned decode frame with 32 gate/up matrices; no claim that this includes recurrent-state bandwidth.',status='prepared_only_not_compiled_or_run'),indent=2)+'\n')
