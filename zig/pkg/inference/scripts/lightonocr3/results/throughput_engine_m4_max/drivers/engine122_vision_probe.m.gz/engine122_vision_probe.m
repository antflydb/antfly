#define main engine122_unused_main
#include "engine122_vision_checks.m"
#undef main
static void select122(size_t mode,id<MTLComputePipelineState>p,size_t q,size_t threads){engine122_candidate=mode?p:nil;engine122_query_tile=mode?(unsigned)q:16;engine122_threads=mode?(unsigned)threads:128;}
int main(int argc,char**argv){@autoreleasepool{
 if(argc!=2)return 1;NSString*which=@(argv[1]);NSData*data=[NSData dataWithContentsOfFile:@".venv-lighton-vllm-metal/engine122_plans.json"];NSArray*plans=[NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 2;termite_metal_decode_runtime_set_lightonocr3_projections(r,1);
 for(NSDictionary*plan in plans){@autoreleasepool{
  NSString*ident=plan[@"id"];if(![which isEqual:@"all"]&&![ident isEqual:which])continue;
  size_t qb=[plan[@"q"]unsignedLongValue],threads=[plan[@"sg"]unsignedLongValue]*32;
  NSString*file=[NSString stringWithFormat:@".venv-lighton-vllm-metal/engine122_%@.metal",ident];NSString*src=[NSString stringWithContentsOfFile:file encoding:NSUTF8StringEncoding error:nil];MTLCompileOptions*opts=[MTLCompileOptions new];opts.languageVersion=MTLLanguageVersion4_0;opts.fastMathEnabled=NO;NSError*error=nil;
  id<MTLLibrary>lib=[r->device newLibraryWithSource:src options:opts error:&error];if(!lib){fprintf(stderr,"VISION122_COMPILE_FAIL %s %s\n",ident.UTF8String,error.description.UTF8String);return 3;}
  id<MTLComputePipelineState>p=[r->device newComputePipelineStateWithFunction:[lib newFunctionWithName:@"vision122"] error:&error];if(!p){fprintf(stderr,"VISION122_PIPELINE_FAIL %s %s\n",ident.UTF8String,error.description.UTF8String);return 4;}
  fprintf(stderr,"VISION122_PIPELINE id=%s threads=%zu max_threads=%zu smem=%zu\n",ident.UTF8String,threads,(size_t)p.maxTotalThreadsPerThreadgroup,(size_t)p.staticThreadgroupMemoryLength);
  if(p.maxTotalThreadsPerThreadgroup<threads||p.staticThreadgroupMemoryLength>r->device.maxThreadgroupMemoryLength){fprintf(stderr,"VISION122_UNSUPPORTED %s\n",ident.UTF8String);continue;}
  const size_t lengths[]={257,578,1672,2160,2592,4095};
  for(size_t h=12;h<=16;h+=4)for(size_t ci=0;ci<6;ci++){@autoreleasepool{
   size_t n=lengths[ci];VisionCheck*c=make_case_heads(r,1,n,h);select122(1,p,qb,threads);run_case(r,c,YES);
   const size_t bytes=c->count*4;NSMutableData*gold[2]={[NSMutableData dataWithLength:bytes],[NSMutableData dataWithLength:bytes]};
   for(size_t mode=0;mode<2;mode++){select122(mode,p,qb,threads);assert(!termite_metal_decode_runtime_begin_frame(r));assert(!encode_case(r,c,NO));assert(!termite_metal_decode_runtime_submit_frame(r));assert(!termite_metal_decode_runtime_wait_frame(r));memcpy(gold[mode].mutableBytes,(char*)c->out.contents+16,bytes);}
   if(![plan[@"fast"]boolValue]&&qb==16&&[plan[@"k"]unsignedLongValue]==128&&[plan[@"m"]unsignedLongValue]==16&&threads==128)assert(!memcmp(gold[0].bytes,gold[1].bytes,bytes));
   if(n>=1000&&n<=3000)for(size_t trial=0;trial<12;trial++)for(size_t order=0;order<2;order++){
    size_t mode=(trial+order)%2;select122(mode,p,qb,threads);assert(!termite_metal_decode_runtime_begin_frame(r));uint64_t start=clock_gettime_nsec_np(CLOCK_UPTIME_RAW);assert(!encode_case(r,c,NO));assert(!termite_metal_decode_runtime_submit_frame(r));assert(!termite_metal_decode_runtime_wait_frame(r));uint64_t elapsed=clock_gettime_nsec_np(CLOCK_UPTIME_RAW)-start;
    assert(!memcmp((char*)c->out.contents+16,gold[mode].bytes,bytes));for(size_t j=0;j<4;j++)assert(((float*)c->out.contents)[j]==12345.0f&&((float*)c->out.contents)[c->count+4+j]==12345.0f);
    printf("{\"id\":\"%s\",\"seq\":%zu,\"heads\":%zu,\"trial\":%zu,\"mode\":%zu,\"gpu_us\":%.4f,\"wall_us\":%.4f}\n",ident.UTF8String,n,h,trial,mode,r->last_frame_gpu_nanos/1000.0,elapsed/1000.0);
   }
  }}
  for(size_t h=12;h<=16;h+=4){VisionCheck*c=make_case_heads(r,1,578,h);((float*)c->q.contents)[4+3]=NAN;((float*)c->k.contents)[4+((578/2)*h+5)*64+31]=INFINITY;select122(1,p,qb,threads);run_case(r,c,YES);}
  fprintf(stderr,"VISION122 FULL OUTPUT CPU GUARDS PASS id=%s\n",ident.UTF8String);
 }}
 select122(0,nil,16,128);termite_metal_decode_runtime_destroy(r);return 0;
}}
