from pathlib import Path
import hashlib
import json
import sys

root = Path.cwd()
v = root / '.venv-lighton-vllm-metal'
out = root / 'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

freeze = json.loads((v / 'engine38-freeze.json').read_text())
for f, h in freeze.items():
    assert sha(root / f) == h, f
for model in sys.argv[1:]:
    assert model in ['4b', '08']
    oracle_path = out / ('vllm_4b_primary_reference16_r0_auto_c64_r128/report.json' if model == '4b' else 'vllm_08_primary_reference18_r0_auto_c64_r128/report.json')
    oracle = json.loads(oracle_path.read_text())
    strings = {x['image_index']: x['text'] for x in oracle['references']}
    records = []
    for p in sorted(out.glob(f'engine38_{model}_physical64*_r128/report.json')):
        d = json.loads(p.read_text())
        r = d['results'][0]
        assert r['status'] == 'ok' and r['serial_reference_parity'] and r['cross_runtime_content_parity']
        assert {x['image_index']: x['text'] for x in r['references']} == strings
        x = r['policy_rounds'][0]
        assert x['completed'] == 128 and not x['admission_pressures'] and not d['own_cpu_compile_overlap']
        assert max(x['packed_core_rows_observed']) > 32 and max(x['packed_core_rows_observed']) <= 64
        assert x['single_frame_topology_mismatches'] == 0 and x['host_recurrent_bytes_total'] == 0
        records.append(dict(report=str(p.relative_to(out)), report_sha256=sha(p),
                            completed=128, full_fixture_string_identity=True, all_native_pages_equal_serial_reference=True,
                            pages_per_second=x['pages_per_second'], process_cpu_ms=x['process_cpu_ms'],
                            average_decode_rows=x['average_decode_rows'], executor_steps=x['executor_steps'],
                            framed_runtime_totals=x['framed_runtime_totals'], admission_pressures=[]))
    assert len(records) == (5 if model == '4b' else 2), len(records)
    result = dict(status='pass', scope='Unpaired R128 candidate sweep; does not establish a fresh vLLM win.',
                  model=model, candidates=records, best=max(records, key=lambda x: x['pages_per_second'])['report'],
                  reference_report=str(oracle_path.relative_to(out)), reference_report_sha256=sha(oracle_path),
                  build_manifest_sha256=sha(out / 'engine38_build_manifest.json'))
    (out / f'engine38_{model}_comparison_audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(model, result['best'], flush=True)
    source = (v / 'archive_engine10_evidence.py').read_text()
    namespace = {}
    exec(source[:source.index("archive('qualification'")], namespace)
    namespace['archive']('qualification', [Path('/private/tmp') / ('ocr-' + Path(x['report']).parent.name.replace('engine38_', 'engine38-', 1).replace(model + '_', model + '-', 1) + '.txt') for x in records], 'logs_manifest.json')
    subprocess = __import__('subprocess')
    subprocess.run([sys.executable, str(v / 'archive_completed_engine_reports.py'), f'engine38_{model}_physical64*_r128'], check=True)
