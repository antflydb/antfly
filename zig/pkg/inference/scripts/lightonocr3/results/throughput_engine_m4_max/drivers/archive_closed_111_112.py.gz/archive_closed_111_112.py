from pathlib import Path
import hashlib,json,subprocess,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((o/'engine112_c_qualification_audit.json').read_text())['status']=='pass'
assert '335 selected; 329 passed; 6 skipped.'in Path('/private/tmp/ocr-engine112-verify3-gpu-build.txt').read_text()
assert '331 selected; 293 passed; 38 skipped.'in Path('/private/tmp/ocr-engine112-packed-cpu.txt').read_text()
assert json.loads((o/'engine112_small94_saved_revalidation113_audit.json').read_text())['status']=='saved_run_revalidation_pass'
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
logs=[*Path('/private/tmp').glob('ocr-engine111-*.txt'),*Path('/private/tmp').glob('ocr-engine112-*.txt')];ns['archive']('qualification',sorted(logs),'logs_manifest.json')
ps=[p for tag in [111,112]for p in v.glob(f'*engine{tag}*')if p.is_file()and p.suffix in ['.py','.json','.m','.inc','.metal']]
index=json.loads((o/'drivers/drivers_manifest.json').read_text());paths=[]
for p in ps:
 h=sha(p);entry=index.get(p.name+'.gz')
 if entry and entry['raw_sha256']!=h:
  q=v/(p.stem+'_closed112_'+h[:10]+p.suffix);assert not q.exists()or q.read_bytes()==p.read_bytes();q.write_bytes(p.read_bytes());paths.append(q)
 else:paths.append(p)
ns['archive']('drivers',sorted(set(paths)),'drivers_manifest.json')
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine112_08_cache94*'],check=True)
q=dict(status='runtime_and_saved_small_output_qualified',scope='Source112binary:329Metaltests/6skip,293CPU/38skip,23freshC/Metalsuitesincluding64MiBexactsizeprefillcacheand26MiBtwo-framecontents. PublicPythonparser113correctssame-linecounters;private113checkeraccepts64MiBonlyfornewflag. No native recompile for parser-only followup;46otherfrozeninputsandbinaryidentical. Originalsmall94failedreportpreserved;separatesaved-logrevalidationpassesall64outputsand114hits/580951168bytes/64MiBpeak. No new speed comparison or model reexecution for reporting correction. 4B screen94 remains in progress and is not archived here.',binary_manifest_sha256=sha(o/'engine112_build_manifest.json'),cpu_log_sha256=sha('/private/tmp/ocr-engine112-packed-cpu.txt'),metal_log_sha256=sha('/private/tmp/ocr-engine112-verify3-gpu-build.txt'),c_manifest_sha256=sha(o/'engine112_c_build_manifest.json'),c_qualification_sha256=sha(o/'engine112_c_qualification_audit.json'),parser_followup_manifest_sha256=sha(o/'engine113_build_manifest.json'),small_saved_revalidation_sha256=sha(o/'engine112_small94_saved_revalidation113_audit.json'))
(o/'engine112_qualification_audit.json').write_text(json.dumps(q,indent=2)+'\n');print('Closed111/112qualifiedinputsarchived;active113untouched.')
