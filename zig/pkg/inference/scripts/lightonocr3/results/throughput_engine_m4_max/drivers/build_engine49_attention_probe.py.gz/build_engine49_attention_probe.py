from pathlib import Path
import hashlib,json,os,subprocess
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=json.loads((out/'engine49_attention_probe_preparation_verify2.json').read_text())
for p,h in plan['inputs'].items():assert sha(p)==h,p
f=json.loads((v/'engine48-freeze.json').read_text())
for p,h in f.items():assert sha(p)==h,p
inputs=list(plan['inputs'])+[str(Path('zig/pkg/inference/src/backends')/n)for n in ['metal_buffer_observation.h','metal_mtp_head.h','metal_mtp_head_impl.h']]
binary=v/'engine49_attention_probe.dylib';assert not binary.exists()
cmd=['clang','-O3','-fobjc-arc','-shared','-dynamiclib','-I','zig/pkg/inference/src/backends',str(v/'engine49_attention_probe.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(binary)]
with Path('/private/tmp/ocr-engine49-attention-probe-build.txt').open('w')as log:r=subprocess.run(cmd,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')),stdout=log,stderr=subprocess.STDOUT)
record=dict(command=cmd,exit_code=r.returncode,inputs={p:sha(p)for p in inputs})
if r.returncode==0:record.update(binary=str(binary),binary_sha256=sha(binary))
(out/'engine49_attention_probe_build_manifest.json').write_text(json.dumps(record,indent=2)+'\n')
assert r.returncode==0,r.returncode
print('BUILD PASS',flush=True)
