from pathlib import Path
import subprocess,sys
v=Path('.venv-lighton-vllm-metal')
for name in ['preset_only_test','preset_physical32_test','default_gpu_test']:
 print('START',name,flush=True)
 with open('/private/tmp/ocr-engine29-functional-'+name+'-driver.txt','w')as out:r=subprocess.run([sys.executable,str(v/('engine29_verify_'+name+'.py'))],stdout=out,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
for scope in ['decode','vision']:
 with open('/private/tmp/ocr-engine29-c-'+scope+'-pack-abba.txt','w')as out:r=subprocess.run([str(v/'engine29_conformance'),'--benchmark-'+scope+'-pack-reuse'],stdout=out,stderr=subprocess.STDOUT)
 print('ABBA',scope,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
