#include "../zig/pkg/inference/src/backends/metal_kernels.m"
int main(void) {
 @autoreleasepool {
  termite_metal_decode_runtime *r=termite_metal_decode_runtime_create();if(!r)return 1;
  if(termite_metal_decode_runtime_set_lighton_activation_pool(r,65536)||termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_DECODE))return 2;
  void *first=termite_metal_buffer_alloc(r,4096,1);if(!first)return 2;
  void *alias=(__bridge_retained void *)((__bridge id<MTLBuffer>)first);
  termite_metal_decode_runtime_release_buffer(r,first);termite_metal_decode_runtime_release_buffer(r,alias);
  if(termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r))return 2;
  size_t occupied=0;for(size_t i=0;i<128;i++)if(r->lighton_activation_buffers[i]!=nil)occupied++;
  fprintf(stderr,"duplicate_ownerships cached_slots=%zu\n",occupied);
  if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_DECODE))return 2;
  void *a=termite_metal_buffer_alloc(r,4096,1),*b=termite_metal_buffer_alloc(r,4096,1);
  bool distinct=a!=b;fprintf(stderr,"simultaneous_allocations_distinct=%d\n",distinct);
  termite_metal_decode_runtime_release_buffer(r,a);termite_metal_decode_runtime_release_buffer(r,b);
  termite_metal_decode_runtime_cancel_frame(r);termite_metal_decode_runtime_destroy(r);
  return occupied==1&&distinct?0:3;
 }
}
