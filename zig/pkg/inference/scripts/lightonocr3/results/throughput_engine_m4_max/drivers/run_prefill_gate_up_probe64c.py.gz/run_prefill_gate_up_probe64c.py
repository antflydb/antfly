from pathlib import Path
import os,subprocess,json,hashlib
v=Path('.venv-lighton-vllm-metal')
cmd=['clang','-O3','-fobjc-arc',str(v/'prefill_gate_up_probe64c.m'),'-Izig/pkg/inference/src/backends','-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(v/'prefill_gate_up_probe64c')]
with Path('/private/tmp/ocr-prefill-gup64c-build.txt').open('w')as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')),check=True)
print('C BUILD PASS',flush=True)
with Path('/private/tmp/ocr-prefill-gup64c-run.txt').open('w')as f:r=subprocess.run([str(v/'prefill_gate_up_probe64c'),str(v/'prefill_gate_up_probe64c.metal')],stdout=f,stderr=subprocess.STDOUT)
print('GPU exit',r.returncode,flush=True);assert r.returncode==0
