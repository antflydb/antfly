from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine48_budget_policies_verify.py').read_text().replace('engine48','engine53')
s=s.replace("stream=int(os.environ.get('OCR_STREAM_FIRST','0'));", "chunks=int(os.environ.get('OCR_STREAM_CHUNK_LAYERS','0'));stream=chunks or int(os.environ.get('OCR_STREAM_FIRST','0'));")
s=s.replace("greedy_stream=os.environ.get('OCR_GPU_GREEDY_STREAM','0')=='1'", "greedy_stream=chunks>0 or os.environ.get('OCR_GPU_GREEDY_STREAM','0')=='1'")
s=s.replace(" if greedy_stream:cmd+=['--gpu-greedy-stream']", " if greedy_stream:cmd+=['--gpu-greedy-stream']\n if chunks:cmd+=['--stream-chunk-layers',str(chunks)]")
s=s.replace("report['full64_gate_up']=full64_gate_up;", "report['stream_chunk_layers']=chunks;report['full64_gate_up']=full64_gate_up;")
a=s.index("    assert sample['gpu_greedy_stream_two_frame_steps']==sample['stream_forward_splits']")
b=s.index("    gates=re.findall",a)
s=s[:a]+'''    for name in ['multi_frame_steps','frame_submits']:
     counters=re.findall(r'gpu_greedy_stream_'+name+r'=(\\d+)',section)
     assert counters,(name,section[-2000:])
     sample['gpu_greedy_stream_'+name]=sum(map(int,counters))
    if greedy_stream:
     assert not single,sample
     assert sample['gpu_greedy_stream_frame_submits']==sample['gpu_greedy_stream_steps']+sample['stream_forward_splits'],sample
     if chunks:
      splits_per_step=((24 if model=='08'else32)-1)//chunks
      assert sample['gpu_greedy_stream_multi_frame_steps']>0,sample
      assert sample['stream_forward_splits']==splits_per_step*sample['gpu_greedy_stream_multi_frame_steps'],sample
      assert sample['gpu_greedy_stream_two_frame_steps']==0,sample
     else:
      assert sample['gpu_greedy_stream_two_frame_steps']==sample['stream_forward_splits'] and sample['stream_forward_splits']>0,sample
    else:assert sample['gpu_greedy_stream_frame_submits']==0,sample
    if stream>0:
     assert sample['prepared_blocks']==(18 if model=='08'else24)*sample['executor_steps'],sample
     assert sample['stream_forward_splits']<=sample['executor_steps']*(((24 if model=='08'else32)-1)//chunks if chunks else1),sample
'''+s[b:]
s=s.replace("else32","else 32").replace("else24","else 24").replace("else1)","else 1)")
compile(s,'budget','exec');(v/'run_engine53_budget_policies.py').write_text(s)
