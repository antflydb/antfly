from pathlib import Path
import os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');binary=v/'engine29_conformance'
checks=[('full',[]),('wide-mpp',['--check-wide-mpp']),('attention',['--check-batch-attention']),('prefill-pack',['--check-prefill-pack-reuse']),('prefill-pack-large',['--check-prefill-pack-reuse-large']),('decode-pack',['--check-decode-pack-reuse']),('vision-pack',['--check-vision-pack-reuse'])]
for name,args in checks:
 print('START',name,flush=True)
 with open('/private/tmp/ocr-engine29-c-'+name+'.txt','w')as out:r=subprocess.run([str(binary),*args],env=os.environ.copy(),stdout=out,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
