from pathlib import Path
import hashlib,json,subprocess,sys
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
frozen=json.loads((v/'engine55-freeze.json').read_text());assert all(sha(Path(p))==s for p,s in frozen.items())
inputs=[Path('zig/pkg/inference/src/backends')/x for x in ['metal_kernels.m','metal_buffer_observation.h','metal_mtp_head.h','metal_mtp_head_impl.h']]+[Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m')]
binary=v/'engine55_conformance';manifest=dict(binary=str(binary),binary_sha256=sha(binary),input_sha256={str(p):sha(p)for p in inputs},compiler_driver_sha256=sha(v/'build_engine55_conformance.py'),qualification_driver_sha256=sha(v/'run_engine55_c_qualification.py'))
(out/'engine55_c_build_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('qualification',[Path('/private/tmp/ocr-engine55-c-build.txt'),Path('/private/tmp/ocr-engine55-c-build-driver.txt'),Path('/private/tmp/ocr-engine55-verify-gpu-build.txt'),Path('/private/tmp/ocr-engine55-verify-gpu-build-driver.txt')],'logs_manifest.json')
r=subprocess.run([sys.executable,str(v/'run_engine55_c_qualification.py')]);assert r.returncode==0
assert sha(binary)==manifest['binary_sha256'] and all(sha(Path(p))==s for p,s in manifest['input_sha256'].items())
audit=json.loads((out/'engine55_c_qualification_audit.json').read_text());assert audit['status']=='pass' and len(audit['checks'])==14
audit['build_manifest_sha256']=sha(out/'engine55_c_build_manifest.json');audit['binary_sha256']=manifest['binary_sha256'];audit['input_sha256']=manifest['input_sha256']
(out/'engine55_c_qualification_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
ns['archive']('qualification',[Path(x['log']) for x in audit['checks']],'logs_manifest.json')
print('ALL 14 C CHECKS PASS',flush=True)
