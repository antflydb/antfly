from pathlib import Path
s=Path('.venv-lighton-vllm-metal/run_engine14_policies.py').read_text().replace('engine14','engine15').replace("os.environ.get('OCR_STREAM_FIRST','4')", "os.environ.get('OCR_STREAM_FIRST','0')")
s=s.replace("stream=int(os.environ.get", "batched=os.environ.get('OCR_BATCH_ATTENTION','1')=='1';env['ANTFLY_LIGHTONOCR3_BATCH_ATTENTION']='1'if batched else'0';stream=int(os.environ.get",1)
s=s.replace("    stream_stats=re.findall(","    attn_stats=re.findall(r'attention_batch_calls=(\\d+) attention_batch_rows=(\\d+)',section);sample['attention_batch_calls']=sum(int(x)for x,_ in attn_stats);sample['attention_batch_rows']=sum(int(x)for _,x in attn_stats);assert attn_stats and (sample['attention_batch_calls']>0)==batched,sample\n    stream_stats=re.findall(",1)
s=s.replace("'executor_tail_steps','stream_forward_splits'", "'executor_tail_steps','attention_batch_calls','attention_batch_rows','stream_forward_splits'")
Path('.venv-lighton-vllm-metal/run_engine15_policies.py').write_text(s)
Path('.venv-lighton-vllm-metal/engine15_benchmark_concurrency.py').write_bytes(Path('.venv-lighton-vllm-metal/engine14_benchmark_concurrency.py').read_bytes())
s=Path('.venv-lighton-vllm-metal/engine14_default_gpu_test.py').read_text().replace('engine14','engine15').replace("['ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS'", "['ANTFLY_LIGHTONOCR3_BATCH_ATTENTION','ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS'")
Path('.venv-lighton-vllm-metal/engine15_default_gpu_test.py').write_text(s)
