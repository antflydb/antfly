from pathlib import Path
import subprocess,json,hashlib,os
v=Path('.venv-lighton-vllm-metal');p=json.loads((v/'engine54_argmax_plan.json').read_text());assert hashlib.sha256(Path(p['base_source']).read_bytes()).hexdigest()==p['base_sha256']
cmd=['clang','-O3','-fobjc-arc','-Izig/pkg/inference/src/backends',str(v/'engine54_argmax_probe_verify2.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(v/'engine54_argmax_probe_verify2')]
with Path('/private/tmp/ocr-engine54-argmax-build-verify2.txt').open('w')as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
assert r.returncode==0,r.returncode
paths=[v/'engine54_argmax_runtime.m',v/'engine54_argmax_source_verify2.inc',v/'engine54_argmax_verify2.metal',v/'engine54_argmax_probe_verify2.m',Path(__file__)]+[Path('zig/pkg/inference/src/backends')/x for x in ['metal_buffer_observation.h','metal_mtp_head.h','metal_mtp_head_impl.h']]
manifest=dict(binary=str(v/'engine54_argmax_probe_verify2'),binary_sha256=hashlib.sha256((v/'engine54_argmax_probe_verify2').read_bytes()).hexdigest(),input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in paths})
Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/engine54_argmax_probe_verify2_build_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('compiled private argmax prototype')
