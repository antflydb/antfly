// Copyright 2026 Antfly, Inc.
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

const std = @import("std");
pub const work_control = @import("engine84_work_control.zig");

pub const Resample = enum(u32) {
    nearest = 0,
    lanczos = 1,
    bilinear = 2,
    bicubic = 3,
    /// Pillow's antialiased, quantized two-pass BICUBIC implementation. This
    /// is distinct from the legacy bicubic sampler used by existing model
    /// configurations so parity-sensitive callers must opt in explicitly.
    pillow_bicubic = 4,
    /// Torchvision uint8 antialiased bicubic, with adaptive int16 coefficients.
    torchvision_bicubic = 5,
};

pub const PixelFormat = enum(u8) {
    rgb8 = 3,
    rgba8 = 4,
};

pub const ImageU8 = struct {
    data: []const u8,
    width: u32,
    height: u32,
    format: PixelFormat,
    /// Zero selects the tightly packed width*channels layout. A non-zero
    /// stride permits borrowing renderer-owned rows without repacking them.
    row_stride_bytes: usize = 0,

    pub fn channels(self: ImageU8) usize {
        return @backingInt(self.format);
    }

    pub fn rowStride(self: ImageU8) !usize {
        const packed_row = std.math.mul(usize, self.width, self.channels()) catch
            return error.InvalidImageBuffer;
        const stride = if (self.row_stride_bytes == 0) packed_row else self.row_stride_bytes;
        if (stride < packed_row) return error.InvalidImageBuffer;
        return stride;
    }

    pub fn validate(self: ImageU8) !void {
        if (self.width == 0 or self.height == 0) return error.InvalidImageBuffer;
        const stride = try self.rowStride();
        const last_row_offset = std.math.mul(usize, self.height - 1, stride) catch
            return error.InvalidImageBuffer;
        const packed_row = std.math.mul(usize, self.width, self.channels()) catch
            return error.InvalidImageBuffer;
        const required = std.math.add(usize, last_row_offset, packed_row) catch
            return error.InvalidImageBuffer;
        if (self.data.len < required) return error.InvalidImageBuffer;
    }
};

/// Convert a decoded RGB/RGBA image into normalized CHW f32 layout.
pub fn preprocessDecoded(
    allocator: std.mem.Allocator,
    img: ImageU8,
    target_size: u32,
    mean: [3]f32,
    std_dev: [3]f32,
) ![]f32 {
    return preprocessDecodedRectWithResample(allocator, img, target_size, target_size, mean, std_dev, .bilinear);
}

/// Convert a decoded RGB/RGBA image into normalized CHW f32 layout using the requested sampler.
pub fn preprocessDecodedWithResample(
    allocator: std.mem.Allocator,
    img: ImageU8,
    target_size: u32,
    mean: [3]f32,
    std_dev: [3]f32,
    resample: Resample,
) ![]f32 {
    return preprocessDecodedRectWithResample(allocator, img, target_size, target_size, mean, std_dev, resample);
}

/// Write normalized CHW pixels directly into caller-owned batch storage.
pub fn preprocessDecodedWithResampleInto(
    allocator: std.mem.Allocator,
    img: ImageU8,
    output: []f32,
    target_size: u32,
    mean: [3]f32,
    std_dev: [3]f32,
    resample: Resample,
) !void {
    return preprocessDecodedRectScaledWithResampleInto(
        allocator,
        img,
        output,
        target_size,
        target_size,
        mean,
        std_dev,
        1.0 / 255.0,
        resample,
    );
}

/// Convert a decoded RGB/RGBA image into normalized CHW f32 layout with explicit width and height.
pub fn preprocessDecodedRect(
    allocator: std.mem.Allocator,
    img: ImageU8,
    target_width: u32,
    target_height: u32,
    mean: [3]f32,
    std_dev: [3]f32,
) ![]f32 {
    return preprocessDecodedRectWithResample(allocator, img, target_width, target_height, mean, std_dev, .bilinear);
}

/// Convert a decoded RGB/RGBA image into normalized CHW f32 layout with explicit width and height using the requested sampler.
pub fn preprocessDecodedRectWithResample(
    allocator: std.mem.Allocator,
    img: ImageU8,
    target_width: u32,
    target_height: u32,
    mean: [3]f32,
    std_dev: [3]f32,
    resample: Resample,
) ![]f32 {
    return preprocessDecodedRectScaledWithResample(
        allocator,
        img,
        target_width,
        target_height,
        mean,
        std_dev,
        1.0 / 255.0,
        resample,
    );
}

/// Convert a decoded RGB/RGBA image into normalized CHW f32 layout with an explicit pixel rescale factor.
pub fn preprocessDecodedRectScaledWithResample(
    allocator: std.mem.Allocator,
    img: ImageU8,
    target_width: u32,
    target_height: u32,
    mean: [3]f32,
    std_dev: [3]f32,
    rescale_factor: f32,
    resample: Resample,
) ![]f32 {
    try img.validate();

    const tw: usize = target_width;
    const th: usize = target_height;
    if (tw == 0 or th == 0) return error.InvalidImageDimensions;
    const target_pixels = std.math.mul(usize, tw, th) catch return error.InvalidImageDimensions;
    const result_len = std.math.mul(usize, 3, target_pixels) catch return error.InvalidImageDimensions;
    const result = try allocator.alloc(f32, result_len);
    errdefer allocator.free(result);

    try preprocessDecodedRectScaledWithResampleInto(
        allocator,
        img,
        result,
        target_width,
        target_height,
        mean,
        std_dev,
        rescale_factor,
        resample,
    );
    return result;
}

pub fn preprocessDecodedRectScaledWithResampleInto(
    allocator: std.mem.Allocator,
    img: ImageU8,
    result: []f32,
    target_width: u32,
    target_height: u32,
    mean: [3]f32,
    std_dev: [3]f32,
    rescale_factor: f32,
    resample: Resample,
) !void {
    try img.validate();
    var resolved_img = img;
    resolved_img.row_stride_bytes = try img.rowStride();

    const tw: usize = target_width;
    const th: usize = target_height;
    const output_len = std.math.mul(usize, 3, std.math.mul(usize, tw, th) catch return error.InvalidImageBuffer) catch
        return error.InvalidImageBuffer;
    if (result.len != output_len) return error.InvalidImageBuffer;

    if (try solidRgb(resolved_img)) |rgb| {
        fillSolidChw(result, tw, th, rgb, mean, std_dev, rescale_factor);
        return;
    }

    const src_w: f32 = @floatFromInt(resolved_img.width);
    const src_h: f32 = @floatFromInt(resolved_img.height);
    const scale_x = src_w / @as(f32, @floatFromInt(tw));
    const scale_y = src_h / @as(f32, @floatFromInt(th));

    if (resample == .bilinear) {
        try preprocessDecodedRectBilinearInterleaved(resolved_img, result, tw, th, mean, std_dev, rescale_factor, scale_x, scale_y);
        return;
    }

    if (resample == .pillow_bicubic or resample == .torchvision_bicubic) {
        try preprocessDecodedRectPillowBicubic(
            allocator,
            resolved_img,
            result,
            tw,
            th,
            mean,
            std_dev,
            rescale_factor,
            resample == .torchvision_bicubic,
        );
        return;
    }

    for (0..th) |y| {
        try @import("engine84_work_control.zig").check();
        for (0..tw) |x| {
            for (0..3) |ch| {
                const val = sampleResized(resolved_img, x, y, ch, scale_x, scale_y, resample);
                result[ch * th * tw + y * tw + x] = normalizeSample(val, mean[ch], std_dev[ch], rescale_factor);
            }
        }
    }
}

pub fn computeAspectFitWidth(src_width: u32, src_height: u32, target_height: u32, max_width: u32) u32 {
    if (src_width == 0 or src_height == 0 or target_height == 0 or max_width == 0) return 1;

    const scaled = @max(
        @as(u32, @intCast(@divFloor(
            @as(u64, src_width) * @as(u64, target_height) + @as(u64, src_height) - 1,
            @as(u64, src_height),
        ))),
        1,
    );
    return @min(scaled, max_width);
}

/// Convert a decoded RGB/RGBA image into normalized CHW f32 layout while preserving aspect ratio.
/// The resized content is left-aligned and the remaining columns are padded with the provided RGB value.
pub fn preprocessDecodedRectKeepAspectPadRightWithResample(
    allocator: std.mem.Allocator,
    img: ImageU8,
    max_width: u32,
    target_height: u32,
    mean: [3]f32,
    std_dev: [3]f32,
    resample: Resample,
    pad_rgb: [3]f32,
) ![]f32 {
    return preprocessDecodedRectKeepAspectPadRightScaledWithResample(
        allocator,
        img,
        max_width,
        target_height,
        mean,
        std_dev,
        1.0 / 255.0,
        resample,
        pad_rgb,
    );
}

/// Convert a decoded RGB/RGBA image into normalized CHW f32 layout while preserving aspect ratio and using an explicit pixel rescale factor.
pub fn preprocessDecodedRectKeepAspectPadRightScaledWithResample(
    allocator: std.mem.Allocator,
    img: ImageU8,
    max_width: u32,
    target_height: u32,
    mean: [3]f32,
    std_dev: [3]f32,
    rescale_factor: f32,
    resample: Resample,
    pad_rgb: [3]f32,
) ![]f32 {
    try img.validate();
    var resolved_img = img;
    resolved_img.row_stride_bytes = try img.rowStride();

    const tw: usize = max_width;
    const th: usize = target_height;
    const result = try allocator.alloc(f32, 3 * tw * th);
    errdefer allocator.free(result);

    const content_width = computeAspectFitWidth(resolved_img.width, resolved_img.height, target_height, max_width);
    const cw: usize = content_width;

    for (0..3) |ch| {
        const pad_val = normalizeSample(pad_rgb[ch], mean[ch], std_dev[ch], rescale_factor);
        @memset(result[ch * th * tw .. (ch + 1) * th * tw], pad_val);
    }

    const src_w: f32 = @floatFromInt(resolved_img.width);
    const src_h: f32 = @floatFromInt(resolved_img.height);
    const scale_x = src_w / @as(f32, @floatFromInt(cw));
    const scale_y = src_h / @as(f32, @floatFromInt(th));

    if (resample == .bilinear) {
        try preprocessDecodedRectKeepAspectPadRightBilinearSimd(resolved_img, result, cw, tw, th, mean, std_dev, rescale_factor, scale_x, scale_y);
        return result;
    }

    for (0..th) |y| {
        try @import("engine84_work_control.zig").check();
        for (0..cw) |x| {
            for (0..3) |ch| {
                const val = sampleResized(resolved_img, x, y, ch, scale_x, scale_y, resample);
                result[ch * th * tw + y * tw + x] = normalizeSample(val, mean[ch], std_dev[ch], rescale_factor);
            }
        }
    }

    return result;
}

fn preprocessDecodedRectKeepAspectPadRightBilinearSimd(
    img: ImageU8,
    result: []f32,
    content_width: usize,
    tw: usize,
    th: usize,
    mean: [3]f32,
    std_dev: [3]f32,
    rescale_factor: f32,
    scale_x: f32,
    scale_y: f32,
) !void {
    const lanes = 4;
    const VecF = @Vector(lanes, f32);
    const rescale_v: VecF = @splat(rescale_factor);

    for (0..3) |ch| {
        const mean_v: VecF = @splat(mean[ch]);
        const std_v: VecF = @splat(std_dev[ch]);
        const plane = result[ch * th * tw .. (ch + 1) * th * tw];

        for (0..th) |y| {
            try @import("engine84_work_control.zig").check();
            const row_offset = y * tw;
            var x: usize = 0;
            while (x + lanes <= content_width) : (x += lanes) {
                const samples = sampleBilinear4(img, x, y, ch, scale_x, scale_y);
                const normalized = (samples * rescale_v - mean_v) / std_v;
                const out: [lanes]f32 = @bitCast(normalized);
                @memcpy(plane[row_offset + x .. row_offset + x + lanes], out[0..]);
            }
            while (x < content_width) : (x += 1) {
                const val = sampleBilinear(img, x, y, ch, scale_x, scale_y);
                plane[row_offset + x] = normalizeSample(val, mean[ch], std_dev[ch], rescale_factor);
            }
        }
    }
}

fn preprocessDecodedRectBilinearSimd(
    img: ImageU8,
    result: []f32,
    tw: usize,
    th: usize,
    mean: [3]f32,
    std_dev: [3]f32,
    rescale_factor: f32,
    scale_x: f32,
    scale_y: f32,
) void {
    const lanes = 4;
    const VecF = @Vector(lanes, f32);
    const one: VecF = @splat(1.0);
    const rescale_v: VecF = @splat(rescale_factor);

    for (0..3) |ch| {
        const mean_v: VecF = @splat(mean[ch]);
        const std_v: VecF = @splat(std_dev[ch]);
        const plane = result[ch * th * tw .. (ch + 1) * th * tw];

        for (0..th) |y| {
            try @import("engine84_work_control.zig").check();
            const row_offset = y * tw;
            var x: usize = 0;
            while (x + lanes <= tw) : (x += lanes) {
                const samples = sampleBilinear4(img, x, y, ch, scale_x, scale_y);
                const normalized = (samples * rescale_v - mean_v) / std_v;
                const out: [lanes]f32 = @bitCast(normalized);
                @memcpy(plane[row_offset + x .. row_offset + x + lanes], out[0..]);
            }
            while (x < tw) : (x += 1) {
                const val = sampleBilinear(img, x, y, ch, scale_x, scale_y);
                plane[row_offset + x] = normalizeSample(val, mean[ch], std_dev[ch], rescale_factor);
            }
        }
    }

    _ = one;
}

fn preprocessDecodedRectBilinearInterleaved(
    img: ImageU8,
    result: []f32,
    tw: usize,
    th: usize,
    mean: [3]f32,
    std_dev: [3]f32,
    rescale_factor: f32,
    scale_x: f32,
    scale_y: f32,
) !void {
    const channels = img.channels();
    const plane_size = tw * th;
    const norm_scale = [3]f32{
        rescale_factor / std_dev[0],
        rescale_factor / std_dev[1],
        rescale_factor / std_dev[2],
    };
    const norm_bias = [3]f32{
        -mean[0] / std_dev[0],
        -mean[1] / std_dev[1],
        -mean[2] / std_dev[2],
    };

    for (0..th) |y| {
        try @import("engine84_work_control.zig").check();
        const src_y = (@as(f32, @floatFromInt(y)) + 0.5) * scale_y - 0.5;
        const y0 = clampIndex(@intFromFloat(@floor(src_y)), img.height);
        const y1 = clampIndex(@as(i32, @intCast(y0)) + 1, img.height);
        const fy = src_y - @as(f32, @floatFromInt(y0));
        const wy0 = 1.0 - fy;
        std.debug.assert(img.row_stride_bytes > 0);
        const row0 = @as(usize, y0) * img.row_stride_bytes;
        const row1 = @as(usize, y1) * img.row_stride_bytes;
        const dst_row = y * tw;

        for (0..tw) |x| {
            const src_x = (@as(f32, @floatFromInt(x)) + 0.5) * scale_x - 0.5;
            const x0 = clampIndex(@intFromFloat(@floor(src_x)), img.width);
            const x1 = clampIndex(@as(i32, @intCast(x0)) + 1, img.width);
            const fx = src_x - @as(f32, @floatFromInt(x0));
            const wx0 = 1.0 - fx;

            const idx00 = row0 + @as(usize, x0) * channels;
            const idx10 = row0 + @as(usize, x1) * channels;
            const idx01 = row1 + @as(usize, x0) * channels;
            const idx11 = row1 + @as(usize, x1) * channels;
            const dst_idx = dst_row + x;

            inline for (0..3) |ch| {
                const p00: f32 = @floatFromInt(img.data[idx00 + ch]);
                const p10: f32 = @floatFromInt(img.data[idx10 + ch]);
                const p01: f32 = @floatFromInt(img.data[idx01 + ch]);
                const p11: f32 = @floatFromInt(img.data[idx11 + ch]);
                const top = p00 * wx0 + p10 * fx;
                const bot = p01 * wx0 + p11 * fx;
                result[ch * plane_size + dst_idx] = (top * wy0 + bot * fy) * norm_scale[ch] + norm_bias[ch];
            }
        }
    }
}

fn solidRgb(img: ImageU8) !?[3]u8 {
    const channels = img.channels();
    img.validate() catch return null;
    const stride = img.row_stride_bytes;
    if (stride == 0) return null;

    const rgb = [3]u8{ img.data[0], img.data[1], img.data[2] };
    for (0..@as(usize, img.height)) |y| {
        try @import("engine84_work_control.zig").check();
        for (0..@as(usize, img.width)) |x| {
            if (x == 0 and y == 0) continue;
            const idx = y * stride + x * channels;
            if (img.data[idx] != rgb[0] or img.data[idx + 1] != rgb[1] or img.data[idx + 2] != rgb[2]) return null;
        }
    }
    return rgb;
}

fn fillSolidChw(
    result: []f32,
    tw: usize,
    th: usize,
    rgb: [3]u8,
    mean: [3]f32,
    std_dev: [3]f32,
    rescale_factor: f32,
) void {
    const plane_size = tw * th;
    for (0..3) |ch| {
        const value = normalizeSample(@floatFromInt(rgb[ch]), mean[ch], std_dev[ch], rescale_factor);
        @memset(result[ch * plane_size .. (ch + 1) * plane_size], value);
    }
}

fn sampleBilinear4(
    img: ImageU8,
    dst_x: usize,
    dst_y: usize,
    ch: usize,
    scale_x: f32,
    scale_y: f32,
) @Vector(4, f32) {
    const lanes = 4;
    const VecF = @Vector(lanes, f32);
    const VecI = @Vector(lanes, i32);

    const base_x: f32 = @floatFromInt(dst_x);
    const dst_xs = VecF{ base_x, base_x + 1.0, base_x + 2.0, base_x + 3.0 };
    const half: VecF = @splat(0.5);
    const src_x = (dst_xs + half) * @as(VecF, @splat(scale_x)) - half;

    const src_y = (@as(f32, @floatFromInt(dst_y)) + 0.5) * scale_y - 0.5;
    const y0 = clampIndex(@intFromFloat(@floor(src_y)), img.height);
    const y1 = clampIndex(@as(i32, @intCast(y0)) + 1, img.height);
    const fy: VecF = @splat(src_y - @as(f32, @floatFromInt(y0)));

    const x0_unclamped: VecI = @intFromFloat(@floor(src_x));
    const x0 = clampIndexVec(x0_unclamped, img.width);
    const x1 = clampIndexVec(x0 + @as(VecI, @splat(1)), img.width);
    const fx = src_x - @as(VecF, @floatFromInt(x0));

    var p00_arr: [lanes]f32 = undefined;
    var p10_arr: [lanes]f32 = undefined;
    var p01_arr: [lanes]f32 = undefined;
    var p11_arr: [lanes]f32 = undefined;
    const x0_arr: [lanes]i32 = @bitCast(x0);
    const x1_arr: [lanes]i32 = @bitCast(x1);

    inline for (0..lanes) |lane| {
        p00_arr[lane] = pixelAt(img, @intCast(x0_arr[lane]), y0, ch);
        p10_arr[lane] = pixelAt(img, @intCast(x1_arr[lane]), y0, ch);
        p01_arr[lane] = pixelAt(img, @intCast(x0_arr[lane]), y1, ch);
        p11_arr[lane] = pixelAt(img, @intCast(x1_arr[lane]), y1, ch);
    }

    const p00: VecF = @bitCast(p00_arr);
    const p10: VecF = @bitCast(p10_arr);
    const p01: VecF = @bitCast(p01_arr);
    const p11: VecF = @bitCast(p11_arr);
    const one: VecF = @splat(1.0);

    const top = p00 * (one - fx) + p10 * fx;
    const bot = p01 * (one - fx) + p11 * fx;
    return top * (one - fy) + bot * fy;
}

fn clampIndexVec(idx: @Vector(4, i32), dim: u32) @Vector(4, i32) {
    const zero: @Vector(4, i32) = @splat(0);
    const max_idx: @Vector(4, i32) = @splat(@as(i32, @intCast(dim - 1)));
    return @min(@max(idx, zero), max_idx);
}

fn pixelAt(img: ImageU8, x: u32, y: u32, ch: usize) f32 {
    std.debug.assert(img.row_stride_bytes > 0);
    const idx = @as(usize, y) * img.row_stride_bytes +
        @as(usize, x) * img.channels() + ch;
    return @floatFromInt(img.data[idx]);
}

fn sampleResized(
    img: ImageU8,
    dst_x: usize,
    dst_y: usize,
    ch: usize,
    scale_x: f32,
    scale_y: f32,
    resample: Resample,
) f32 {
    return switch (resample) {
        .bicubic => sampleBicubic(img, dst_x, dst_y, ch, scale_x, scale_y),
        else => sampleBilinear(img, dst_x, dst_y, ch, scale_x, scale_y),
    };
}

fn sampleBilinear(
    img: ImageU8,
    dst_x: usize,
    dst_y: usize,
    ch: usize,
    scale_x: f32,
    scale_y: f32,
) f32 {
    const src_x = (@as(f32, @floatFromInt(dst_x)) + 0.5) * scale_x - 0.5;
    const src_y = (@as(f32, @floatFromInt(dst_y)) + 0.5) * scale_y - 0.5;
    const x0 = clampIndex(@intFromFloat(@floor(src_x)), img.width);
    const y0 = clampIndex(@intFromFloat(@floor(src_y)), img.height);
    const x1 = clampIndex(@as(i32, @intCast(x0)) + 1, img.width);
    const y1 = clampIndex(@as(i32, @intCast(y0)) + 1, img.height);
    const fx = src_x - @as(f32, @floatFromInt(x0));
    const fy = src_y - @as(f32, @floatFromInt(y0));

    const p00 = pixelAt(img, x0, y0, ch);
    const p10 = pixelAt(img, x1, y0, ch);
    const p01 = pixelAt(img, x0, y1, ch);
    const p11 = pixelAt(img, x1, y1, ch);

    const top = p00 * (1.0 - fx) + p10 * fx;
    const bot = p01 * (1.0 - fx) + p11 * fx;
    return top * (1.0 - fy) + bot * fy;
}

fn sampleBicubic(
    img: ImageU8,
    dst_x: usize,
    dst_y: usize,
    ch: usize,
    scale_x: f32,
    scale_y: f32,
) f32 {
    const src_x = (@as(f32, @floatFromInt(dst_x)) + 0.5) * scale_x - 0.5;
    const src_y = (@as(f32, @floatFromInt(dst_y)) + 0.5) * scale_y - 0.5;
    const base_x: i32 = @intFromFloat(@floor(src_x));
    const base_y: i32 = @intFromFloat(@floor(src_y));
    var accum: f32 = 0.0;
    for (0..4) |ky| {
        const sy = clampIndex(base_y + @as(i32, @intCast(ky)) - 1, img.height);
        const wy = cubicWeight(src_y - @as(f32, @floatFromInt(base_y + @as(i32, @intCast(ky)) - 1)));
        for (0..4) |kx| {
            const sx = clampIndex(base_x + @as(i32, @intCast(kx)) - 1, img.width);
            const wx = cubicWeight(src_x - @as(f32, @floatFromInt(base_x + @as(i32, @intCast(kx)) - 1)));
            accum += pixelAt(img, sx, sy, ch) * wx * wy;
        }
    }
    return std.math.clamp(accum, 0.0, 255.0);
}

pub const BicubicAxis = struct {
    allocator: std.mem.Allocator,
    starts: []usize,
    offsets: []usize,
    weights: []i32,
    precision_bits: u6,

    pub fn deinit(self: *@This()) void {
        self.allocator.free(self.starts);
        self.allocator.free(self.offsets);
        self.allocator.free(self.weights);
    }
};

/// Build Pillow-compatible antialiased bicubic coefficients. Downsampling
/// widens the cubic support by the reduction factor and renormalizes the
/// surviving in-bounds taps instead of clamping out-of-bounds samples.
pub fn buildPillowBicubicAxis(
    allocator: std.mem.Allocator,
    source_size: usize,
    target_size: usize,
    torchvision: bool,
) !BicubicAxis {
    if (source_size == 0 or target_size == 0) return error.InvalidImageDimensions;
    const starts = try allocator.alloc(usize, target_size);
    errdefer allocator.free(starts);
    const offsets = try allocator.alloc(usize, target_size + 1);
    errdefer allocator.free(offsets);
    var float_weights = std.ArrayListUnmanaged(f64).empty;
    defer float_weights.deinit(allocator);
    var weights = std.ArrayListUnmanaged(i32).empty;
    errdefer weights.deinit(allocator);

    const scale = @as(f64, @floatFromInt(source_size)) / @as(f64, @floatFromInt(target_size));
    const filter_scale = @max(scale, 1.0);
    const support = 2.0 * filter_scale;
    for (0..target_size) |target| {
        if (target & 63 == 0) try @import("engine84_work_control.zig").check();
        const center = (@as(f64, @floatFromInt(target)) + 0.5) * scale;
        var first: isize = @intFromFloat(center - support + 0.5);
        var last: isize = @intFromFloat(center + support + 0.5);
        first = @max(first, 0);
        last = @min(last, @as(isize, @intCast(source_size)));
        if (last <= first) return error.InvalidImageDimensions;
        starts[target] = @intCast(first);
        offsets[target] = float_weights.items.len;
        const float_start = float_weights.items.len;
        var total: f64 = 0.0;
        var source = first;
        while (source < last) : (source += 1) {
            const distance = (@as(f64, @floatFromInt(source)) - center + 0.5) / filter_scale;
            const weight = cubicWeightF64(distance);
            try float_weights.append(allocator, weight);
            total += weight;
        }
        if (total == 0.0 or !std.math.isFinite(total)) return error.InvalidImageDimensions;
        for (float_weights.items[float_start..]) |*weight| weight.* /= total;
    }
    offsets[target_size] = float_weights.items.len;
    var precision: u6 = pillow_precision_bits;
    if (torchvision) {
        // PyTorch 2.10 UpSampleKernel.cpp compute_index_ranges_int16_weights:
        // select the largest fixed-point scale whose coefficients fit int16.
        var maximum: f64 = 0;
        for (float_weights.items) |weight| maximum = @max(maximum, weight);
        precision = 0;
        while (precision < 22) : (precision += 1) {
            const next: i64 = @intFromFloat(0.5 + maximum * @as(f64, @floatFromInt(@as(u64, 1) << (precision + 1))));
            if (next >= 1 << 15) break;
        }
    }
    for (float_weights.items) |weight| {
        const scaled = weight * @as(f64, @floatFromInt(@as(u64, 1) << precision));
        const rounded = if (scaled < 0.0) scaled - 0.5 else scaled + 0.5;
        try weights.append(allocator, @intFromFloat(rounded));
    }
    return .{
        .allocator = allocator,
        .starts = starts,
        .offsets = offsets,
        .weights = try weights.toOwnedSlice(allocator),
        .precision_bits = precision,
    };
}

const pillow_precision_bits = 22;

fn clipPillowAccumulator(value: i64, precision_bits: u6) u8 {
    return @intCast(std.math.clamp(value >> precision_bits, 0, 255));
}

// Bound all partial sums, including negative lobes, before narrowing to SIMD.
fn pillowWeightsFitI32(weights: []const i32, precision_bits: u6) bool {
    if (precision_bits == 0 or precision_bits >= 32) return false;
    var magnitude: u64 = @as(u64, 1) << (precision_bits - 1);
    for (weights) |weight| {
        const term = @as(u64, @intCast(@abs(@as(i64, weight)))) * 255;
        magnitude = std.math.add(u64, magnitude, term) catch return false;
        if (magnitude > std.math.maxInt(i32)) return false;
    }
    return true;
}

fn pillowHorizontal(img: ImageU8, axis: BicubicAxis, horizontal: []u8, target_width: usize, comptime allow_simd: bool) !void {
    var vector_safe = allow_simd;
    if (allow_simd) for (0..target_width) |x| {
        if (!pillowWeightsFitI32(axis.weights[axis.offsets[x]..axis.offsets[x + 1]], axis.precision_bits)) {
            vector_safe = false;
            break;
        }
    };
    for (0..img.height) |source_y| {
        try @import("engine84_work_control.zig").check();
        for (0..target_width) |target_x| {
            const start = axis.starts[target_x];
            const begin = axis.offsets[target_x];
            const end = axis.offsets[target_x + 1];
            if (vector_safe) {
                const row = img.data[source_y * img.row_stride_bytes ..][0 .. @as(usize, img.width) * img.channels()];
                var accum: @Vector(4, i32) = @splat(@as(i32, 1) << @intCast(axis.precision_bits - 1));
                for (axis.weights[begin..end], 0..) |weight, offset| {
                    const source = (start + offset) * img.channels();
                    // Packed RGB has only three bytes at the last pixel.
                    // Never read row padding to fill the discarded fourth lane.
                    const bytes: @Vector(4, u8) = if (row.len - source >= 4)
                        row[source..][0..4].*
                    else
                        .{ row[source], row[source + 1], row[source + 2], 0 };
                    accum += @as(@Vector(4, i32), @intCast(bytes)) * @as(@Vector(4, i32), @splat(weight));
                }
                const clipped = @min(
                    @max(accum >> @as(@Vector(4, u5), @splat(@intCast(axis.precision_bits))), @as(@Vector(4, i32), @splat(0))),
                    @as(@Vector(4, i32), @splat(255)),
                );
                inline for (0..3) |channel| horizontal[(source_y * target_width + target_x) * 3 + channel] = @intCast(clipped[channel]);
                continue;
            }
            for (0..3) |channel| {
                var value: i64 = @as(i64, 1) << (axis.precision_bits - 1);
                for (axis.weights[begin..end], 0..) |weight, offset| {
                    value += @as(i64, @intFromFloat(pixelAt(img, @intCast(start + offset), @intCast(source_y), channel))) * weight;
                }
                horizontal[(source_y * target_width + target_x) * 3 + channel] = clipPillowAccumulator(value, axis.precision_bits);
            }
        }
    }
}

/// Pillow resizes 8-bit images in two passes, materializing an 8-bit
/// horizontal intermediate before the vertical pass. Preserving that
/// quantization boundary is required for Transformers pixel parity.
fn preprocessDecodedRectPillowBicubic(
    allocator: std.mem.Allocator,
    img: ImageU8,
    result: []f32,
    target_width: usize,
    target_height: usize,
    mean: [3]f32,
    std_dev: [3]f32,
    rescale_factor: f32,
    torchvision: bool,
) !void {
    var horizontal_axis = try buildPillowBicubicAxis(allocator, img.width, target_width, torchvision);
    defer horizontal_axis.deinit();
    var vertical_axis = try buildPillowBicubicAxis(allocator, img.height, target_height, torchvision);
    defer vertical_axis.deinit();

    const horizontal_pixels = std.math.mul(usize, target_width, img.height) catch
        return error.InvalidImageDimensions;
    const horizontal_len = std.math.mul(usize, horizontal_pixels, 3) catch
        return error.InvalidImageDimensions;
    const horizontal = try allocator.alloc(u8, horizontal_len);
    defer allocator.free(horizontal);
    try pillowHorizontal(img, horizontal_axis, horizontal, target_width, true);

    const row_bytes = target_width * 3;
    const Vec = @Vector(8, i32);
    for (0..target_height) |target_y| {
        try @import("engine84_work_control.zig").check();
        const start = vertical_axis.starts[target_y];
        const begin = vertical_axis.offsets[target_y];
        const end = vertical_axis.offsets[target_y + 1];
        const weights = vertical_axis.weights[begin..end];
        // Bound every partial accumulator before narrowing to SIMD i32.
        // The wider scalar path preserves the existing behavior when a
        // coefficient set cannot safely use the faster representation.
        var magnitude: u64 = @as(u64, 1) << (vertical_axis.precision_bits - 1);
        var vector_safe = vertical_axis.precision_bits < 32;
        for (weights) |weight| {
            const term = @as(u64, @intCast(@abs(@as(i64, weight)))) * 255;
            magnitude = std.math.add(u64, magnitude, term) catch {
                vector_safe = false;
                break;
            };
        }
        var byte_x: usize = 0;
        if (vector_safe and magnitude <= std.math.maxInt(i32)) {
            while (byte_x + 8 <= row_bytes) : (byte_x += 8) {
                var accum: Vec = @splat(@as(i32, 1) << @intCast(vertical_axis.precision_bits - 1));
                for (weights, 0..) |weight, offset| {
                    const source = (start + offset) * row_bytes + byte_x;
                    const bytes: @Vector(8, u8) = horizontal[source..][0..8].*;
                    const values: Vec = @intCast(bytes);
                    accum += values * @as(Vec, @splat(weight));
                }
                const clipped = @min(
                    @max(accum >> @as(@Vector(8, u5), @splat(@intCast(vertical_axis.precision_bits))), @as(Vec, @splat(0))),
                    @as(Vec, @splat(255)),
                );
                inline for (0..8) |lane| {
                    const channel = (byte_x + lane) % 3;
                    const x = (byte_x + lane) / 3;
                    const sample: f32 = @floatFromInt(clipped[lane]);
                    result[channel * target_height * target_width + target_y * target_width + x] =
                        normalizeSample(sample, mean[channel], std_dev[channel], rescale_factor);
                }
            }
        }
        while (byte_x < row_bytes) : (byte_x += 1) {
            var value: i64 = @as(i64, 1) << (vertical_axis.precision_bits - 1);
            for (weights, 0..) |weight, offset| value += @as(i64, horizontal[(start + offset) * row_bytes + byte_x]) * weight;
            const channel = byte_x % 3;
            const x = byte_x / 3;
            const sample: f32 = @floatFromInt(clipPillowAccumulator(value, vertical_axis.precision_bits));
            result[channel * target_height * target_width + target_y * target_width + x] =
                normalizeSample(sample, mean[channel], std_dev[channel], rescale_factor);
        }
    }
}

fn cubicWeight(x: f32) f32 {
    return @floatCast(cubicWeightF64(x));
}

fn cubicWeightF64(x: f64) f64 {
    const a: f64 = -0.5;
    const t = @abs(x);
    if (t <= 1.0) {
        return ((a + 2.0) * t - (a + 3.0)) * t * t + 1.0;
    }
    if (t < 2.0) {
        return (((a * t) - (5.0 * a)) * t + (8.0 * a)) * t - (4.0 * a);
    }
    return 0.0;
}

fn clampIndex(idx: i32, dim: u32) u32 {
    if (idx <= 0) return 0;
    const max: i32 = @intCast(dim - 1);
    if (idx >= max) return @intCast(max);
    return @intCast(idx);
}

fn normalizeSample(value: f32, mean: f32, std_dev: f32, rescale_factor: f32) f32 {
    return (value * rescale_factor - mean) / std_dev;
}

test "preprocess decoded rgb image returns chw output" {
    const alloc = std.testing.allocator;
    const rgb = [_]u8{
        255, 0,   0,
        0,   255, 0,
        0,   0,   255,
        255, 255, 255,
    };
    const out = try preprocessDecoded(alloc, .{
        .data = &rgb,
        .width = 2,
        .height = 2,
        .format = .rgb8,
    }, 2, .{ 0.0, 0.0, 0.0 }, .{ 1.0, 1.0, 1.0 });
    defer alloc.free(out);

    try std.testing.expectEqual(@as(usize, 12), out.len);
    try std.testing.expectEqual(@as(f32, 1.0), out[0]);
    try std.testing.expectEqual(@as(f32, 0.0), out[1]);
}

test "preprocess decoded rgba ignores alpha" {
    const alloc = std.testing.allocator;
    const rgba = [_]u8{ 10, 20, 30, 40 };
    const out = try preprocessDecoded(alloc, .{
        .data = &rgba,
        .width = 1,
        .height = 1,
        .format = .rgba8,
    }, 1, .{ 0.0, 0.0, 0.0 }, .{ 1.0, 1.0, 1.0 });
    defer alloc.free(out);

    try std.testing.expectEqual(@as(usize, 3), out.len);
    try std.testing.expectApproxEqAbs(@as(f32, 10.0 / 255.0), out[0], 1e-6);
    try std.testing.expectApproxEqAbs(@as(f32, 20.0 / 255.0), out[1], 1e-6);
    try std.testing.expectApproxEqAbs(@as(f32, 30.0 / 255.0), out[2], 1e-6);
}

test "packed and padded-stride RGBA preprocessing are equivalent" {
    const alloc = std.testing.allocator;
    const packed_rgba = [_]u8{
        255, 0, 0,   255, 0, 255, 0, 255,
        0,   0, 255, 255, 7, 8,   9, 255,
    };
    const padded_rgba = [_]u8{
        255, 0, 0,   255, 0, 255, 0, 255, 91, 92, 93, 94,
        0,   0, 255, 255, 7, 8,   9, 255, 81, 82, 83, 84,
    };
    const packed_result = try preprocessDecodedWithResample(
        alloc,
        .{ .data = &packed_rgba, .width = 2, .height = 2, .format = .rgba8 },
        5,
        .{ 0.1, 0.2, 0.3 },
        .{ 0.7, 0.8, 0.9 },
        .bilinear,
    );
    defer alloc.free(packed_result);
    const strided_result = try preprocessDecodedWithResample(
        alloc,
        .{
            .data = &padded_rgba,
            .width = 2,
            .height = 2,
            .format = .rgba8,
            .row_stride_bytes = 12,
        },
        5,
        .{ 0.1, 0.2, 0.3 },
        .{ 0.7, 0.8, 0.9 },
        .bilinear,
    );
    defer alloc.free(strided_result);
    try std.testing.expectEqualSlices(f32, packed_result, strided_result);
}

test "preprocess decoded into caller batch storage matches allocating path" {
    const alloc = std.testing.allocator;
    const rgba = [_]u8{
        255, 0,   0,   255,
        0,   255, 0,   128,
        0,   0,   255, 64,
        255, 255, 255, 0,
    };
    const image = ImageU8{ .data = &rgba, .width = 2, .height = 2, .format = .rgba8 };
    const expected = try preprocessDecodedWithResample(
        alloc,
        image,
        3,
        .{ 0.5, 0.5, 0.5 },
        .{ 0.5, 0.5, 0.5 },
        .bilinear,
    );
    defer alloc.free(expected);
    var actual: [27]f32 = undefined;
    try preprocessDecodedWithResampleInto(
        alloc,
        image,
        &actual,
        3,
        .{ 0.5, 0.5, 0.5 },
        .{ 0.5, 0.5, 0.5 },
        .bilinear,
    );
    try std.testing.expectEqualSlices(f32, expected, &actual);
    try std.testing.expectError(
        error.InvalidImageBuffer,
        preprocessDecodedWithResampleInto(
            alloc,
            image,
            actual[0..26],
            3,
            .{ 0.5, 0.5, 0.5 },
            .{ 0.5, 0.5, 0.5 },
            .bilinear,
        ),
    );
}

test "preprocess decoded rect returns non-square chw output" {
    const alloc = std.testing.allocator;
    const rgb = [_]u8{
        255, 0,   0,
        0,   255, 0,
    };
    const out = try preprocessDecodedRect(alloc, .{
        .data = &rgb,
        .width = 2,
        .height = 1,
        .format = .rgb8,
    }, 4, 2, .{ 0.0, 0.0, 0.0 }, .{ 1.0, 1.0, 1.0 });
    defer alloc.free(out);

    try std.testing.expectEqual(@as(usize, 3 * 4 * 2), out.len);
}

test "computeAspectFitWidth preserves ratio and caps width" {
    try std.testing.expectEqual(@as(u32, 100), computeAspectFitWidth(200, 96, 48, 320));
    try std.testing.expectEqual(@as(u32, 320), computeAspectFitWidth(2000, 48, 48, 320));
    try std.testing.expectEqual(@as(u32, 1), computeAspectFitWidth(0, 48, 48, 320));
}

test "preprocess decoded keep aspect pads remaining width" {
    const alloc = std.testing.allocator;
    const rgb = [_]u8{
        255, 0,   0,
        0,   255, 0,
    };
    const out = try preprocessDecodedRectKeepAspectPadRightWithResample(
        alloc,
        .{
            .data = &rgb,
            .width = 2,
            .height = 1,
            .format = .rgb8,
        },
        6,
        2,
        .{ 0.0, 0.0, 0.0 },
        .{ 1.0, 1.0, 1.0 },
        .nearest,
        .{ 255, 255, 255 },
    );
    defer alloc.free(out);

    try std.testing.expectEqual(@as(usize, 3 * 6 * 2), out.len);
    try std.testing.expectApproxEqAbs(@as(f32, 1.0), out[5], 1e-6);
}

test "preprocess decoded rect scaled applies explicit rescale factor" {
    const alloc = std.testing.allocator;
    const rgb = [_]u8{ 128, 64, 32 };
    const out = try preprocessDecodedRectScaledWithResample(
        alloc,
        .{
            .data = &rgb,
            .width = 1,
            .height = 1,
            .format = .rgb8,
        },
        1,
        1,
        .{ 0.0, 0.0, 0.0 },
        .{ 1.0, 1.0, 1.0 },
        1.0,
        .nearest,
    );
    defer alloc.free(out);

    try std.testing.expectApproxEqAbs(@as(f32, 128.0), out[0], 1e-6);
    try std.testing.expectApproxEqAbs(@as(f32, 64.0), out[1], 1e-6);
    try std.testing.expectApproxEqAbs(@as(f32, 32.0), out[2], 1e-6);
}

test "bicubic downsampling matches Pillow RGB pixels" {
    const alloc = std.testing.allocator;
    var rgb: [8 * 6 * 3]u8 = undefined;
    for (0..6) |y| {
        for (0..8) |x| {
            const offset = (y * 8 + x) * 3;
            rgb[offset] = @intCast((y * 8 + x) * 5);
            rgb[offset + 1] = @intCast(x * 30);
            rgb[offset + 2] = @intCast(y * 40);
        }
    }

    const out = try preprocessDecodedRectScaledWithResample(
        alloc,
        .{
            .data = &rgb,
            .width = 8,
            .height = 6,
            .format = .rgb8,
        },
        3,
        2,
        .{ 0.0, 0.0, 0.0 },
        .{ 1.0, 1.0, 1.0 },
        1.0,
        .pillow_bicubic,
    );
    defer alloc.free(out);

    // Pillow 12.1.0: Image.fromarray(rgb).resize((3, 2), Image.Resampling.BICUBIC).
    const expected = [_]f32{
        49, 62,  76,  159, 172, 186,
        27, 105, 183, 27,  105, 183,
        45, 45,  45,  155, 155, 155,
    };
    try std.testing.expectEqualSlices(f32, &expected, out);

    const legacy = try preprocessDecodedRectScaledWithResample(
        alloc,
        .{
            .data = &rgb,
            .width = 8,
            .height = 6,
            .format = .rgb8,
        },
        3,
        2,
        .{ 0.0, 0.0, 0.0 },
        .{ 1.0, 1.0, 1.0 },
        1.0,
        .bicubic,
    );
    defer alloc.free(legacy);
    try std.testing.expect(!std.mem.eql(f32, legacy, out));
}

test "embeddinggemma2 torchvision bicubic matches pinned uint8 pixels" {
    const a = std.testing.allocator;
    var pixels: [7 * 13 * 3]u8 = undefined;
    for (0..7) |y| for (0..13) |x| for (0..3) |c| {
        pixels[(y * 13 + x) * 3 + c] = @intCast((x * 37 + y * 83 + c * 59) % 256);
    };
    const actual = try preprocessDecodedRectScaledWithResample(a, .{ .data = &pixels, .width = 13, .height = 7, .format = .rgb8 }, 5, 3, .{ 0, 0, 0 }, .{ 1, 1, 1 }, 1, .torchvision_bicubic);
    defer a.free(actual);
    // PyTorch 2.10.0: F.interpolate(CHW uint8[None], size=(3, 5),
    // mode="bicubic", align_corners=False, antialias=True). Do not cast the
    // input to float: rounding only the final float output omits the uint8
    // horizontal intermediate and changes five pixels in this fixture.
    const expected = [_]f32{ 103, 140, 106, 122, 137, 141, 120, 135, 138, 120, 140, 106, 138, 132, 107, 128, 153, 120, 120, 123, 120, 140, 122, 121, 142, 145, 132, 124, 103, 144, 143, 109, 137, 140, 107, 126, 110, 133, 128, 110, 109, 151, 133, 122, 156 };
    try std.testing.expectEqualSlices(f32, &expected, actual);
}

test "torchvision bicubic upsampling preserves padded RGBA pixels and allocation cleanup" {
    const Case = struct {
        fn run(a: std.mem.Allocator) !void {
            var pixels: [2 * 16]u8 = @splat(255);
            for (0..2) |y| for (0..3) |x| for (0..3) |c| {
                pixels[y * 16 + x * 4 + c] = @intCast((x * 37 + y * 83 + c * 59) % 256);
            };
            const actual = try preprocessDecodedRectScaledWithResample(a, .{
                .data = &pixels,
                .width = 3,
                .height = 2,
                .format = .rgba8,
                .row_stride_bytes = 16,
            }, 5, 4, .{ 0, 0, 0 }, .{ 1, 1, 1 }, 1, .torchvision_bicubic);
            defer a.free(actual);
            // PyTorch 2.10.0 F.interpolate on the RGB uint8 channels, size=(4, 5),
            // bicubic, align_corners=False, antialias=True. Includes clipped
            // negative lobes, vector lanes crossing channels, and scalar tails.
            const expected = [_]f32{
                0,   4,   30,  56,  70,  17,  28,  54,  80,  94,  63,  77,  103, 129, 143,
                87,  101, 127, 153, 167, 49,  63,  89,  115, 129, 73,  87,  113, 139, 153,
                122, 136, 162, 188, 202, 146, 160, 186, 212, 226, 108, 121, 148, 188, 212,
                132, 149, 172, 164, 155, 181, 204, 221, 114, 42,  205, 232, 245, 90,  0,
            };
            try std.testing.expectEqualSlices(f32, &expected, actual);
        }
    };
    try std.testing.checkAllAllocationFailures(std.testing.allocator, Case.run, .{});
}

test "Pillow horizontal SIMD matches wide scalar for packed and padded RGB RGBA" {
    const a = std.testing.allocator;
    for ([_]PixelFormat{ .rgb8, .rgba8 }) |format| {
        for ([_]usize{ 1, 2, 3, 5, 8, 13, 17 }) |width| {
            for ([_]usize{ 1, 2, 4, 7, 23 }) |target| {
                for ([_]bool{ false, true }) |torchvision| {
                    const channels: usize = @backingInt(format);
                    const stride = width * channels + 5;
                    // No padding follows the final row.
                    const pixels = try a.alloc(u8, stride * 2 + width * channels);
                    defer a.free(pixels);
                    for (pixels, 0..) |*value, i| value.* = @intCast((i * 53 + i / 7 * 91) % 256);
                    const image = ImageU8{ .data = pixels, .width = @intCast(width), .height = 3, .format = format, .row_stride_bytes = stride };
                    try image.validate();
                    var axis = try buildPillowBicubicAxis(a, width, target, torchvision);
                    defer axis.deinit();
                    const scalar = try a.alloc(u8, target * 3 * 3);
                    defer a.free(scalar);
                    const vector = try a.alloc(u8, scalar.len);
                    defer a.free(vector);
                    try pillowHorizontal(image, axis, scalar, target, false);
                    try pillowHorizontal(image, axis, vector, target, true);
                    try std.testing.expectEqualSlices(u8, scalar, vector);
                }
            }
        }
    }
}

test "Pillow horizontal unsafe coefficients retain wide scalar accumulation" {
    var weights = [_]i32{ std.math.maxInt(i32), -std.math.maxInt(i32) };
    try std.testing.expect(!pillowWeightsFitI32(&weights, 22));
    try std.testing.expect(!pillowWeightsFitI32(&.{1}, 0));
    try std.testing.expect(!pillowWeightsFitI32(&.{1}, 32));
    const boundary = (std.math.maxInt(i32) - (@as(i32, 1) << 21)) / 255;
    try std.testing.expect(pillowWeightsFitI32(&.{boundary}, 22));
    try std.testing.expect(!pillowWeightsFitI32(&.{boundary + 1}, 22));
    var starts = [_]usize{0};
    var offsets = [_]usize{ 0, 2 };
    const axis = BicubicAxis{ .allocator = std.testing.allocator, .starts = &starts, .offsets = &offsets, .weights = &weights, .precision_bits = 22 };
    const image = ImageU8{ .data = &.{ 0, 255, 1, 255, 0, 2 }, .width = 2, .height = 1, .format = .rgb8, .row_stride_bytes = 6 };
    var scalar: [3]u8 = undefined;
    var vector: [3]u8 = undefined;
    try pillowHorizontal(image, axis, &scalar, 1, false);
    try pillowHorizontal(image, axis, &vector, 1, true);
    try std.testing.expectEqualSlices(u8, &.{ 0, 255, 0 }, &scalar);
    try std.testing.expectEqualSlices(u8, &scalar, &vector);
}


test "engine84 private horizontal ABBA benchmark" {
    const a = std.testing.allocator;
    const Case = struct { width: u32, height: u32, target: u32 };
    for ([_]Case{ .{ .width=1600, .height=2200, .target=896 }, .{ .width=2048, .height=1536, .target=672 }, .{ .width=512, .height=384, .target=1024 } }) |case| {
        for ([_]PixelFormat{ .rgb8, .rgba8 }) |format| {
            const channels: usize = @backingInt(format);
            const stride = @as(usize, case.width) * channels + 5;
            const bytes = try a.alloc(u8, (@as(usize, case.height)-1)*stride+@as(usize,case.width)*channels);
            defer a.free(bytes);
            for (bytes, 0..) |*value, i| value.* = @intCast((i*53+i/7*91)%256);
            const img = ImageU8{ .data=bytes, .width=case.width, .height=case.height, .format=format, .row_stride_bytes=stride };
            var axis = try buildPillowBicubicAxis(a,case.width,case.target,false);
            defer axis.deinit();
            const scalar = try a.alloc(u8,@as(usize,case.target)*case.height*3);
            defer a.free(scalar);
            const vector = try a.alloc(u8,scalar.len);
            defer a.free(vector);
            try pillowHorizontal(img,axis,scalar,case.target,false);
            try pillowHorizontal(img,axis,vector,case.target,true);
            try std.testing.expectEqualSlices(u8,scalar,vector);
            for (0..4) |leg| {
                const simd = leg==1 or leg==2;
                for (0..2) |_| {
                    if (simd) try pillowHorizontal(img,axis,vector,case.target,true) else try pillowHorizontal(img,axis,vector,case.target,false);
                }
                const start = std.Io.Clock.awake.now(std.testing.io).nanoseconds;
                for (0..6) |_| {
                    if (simd) try pillowHorizontal(img,axis,vector,case.target,true) else try pillowHorizontal(img,axis,vector,case.target,false);
                    std.mem.doNotOptimizeAway(vector);
                }
                const elapsed = std.Io.Clock.awake.now(std.testing.io).nanoseconds-start;
                try std.testing.expectEqualSlices(u8,scalar,vector);
                std.debug.print("HORIZONTAL84 width={d} height={d} target={d} channels={d} leg={d} simd={d} elapsed_ns={d} runs=6 exact=true\n",.{case.width,case.height,case.target,channels,leg,@intFromBool(simd),elapsed});
            }
        }
    }
}
