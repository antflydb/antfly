from pathlib import Path
import datetime, hashlib, json, subprocess, sys
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';out=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';binary=v/'engine23_conformance'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
freeze=json.loads((v/'engine23-freeze.json').read_text())
for f,h in freeze.items():assert sha(root/f)==h,f
record=dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),binary_sha256=sha(binary),kernel_sha256=sha(root/'zig/pkg/inference/src/backends/metal_kernels.m'),checker_sha256=sha(root/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m'),functional_only=True,own_cpu_compile_overlap=False,status='running',commands=[])
for flag in ['', '--check-wide-mpp', '--check-batch-attention', '--check-prefill-pack-reuse']:
 label=flag.removeprefix('--') or 'full-functional';log=Path('/private/tmp')/('ocr-engine23-c-'+label+'.txt')
 print('START',label,flush=True)
 with log.open('w') as f:r=subprocess.run([str(binary)]+([flag]if flag else[]),stdout=f,stderr=subprocess.STDOUT)
 record['commands'].append(dict(flag=flag or 'full-functional',exit_code=r.returncode,log=str(log),log_sha256=sha(log)))
 print('DONE',label,r.returncode,flush=True)
 if r.returncode:record['status']='failed';break
else:record['status']='ok'
(out/'engine23_c_qualification_manifest.json').write_text(json.dumps(record,indent=2)+'\n')
sys.exit(0 if record['status']=='ok' else 1)
