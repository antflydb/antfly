from pathlib import Path
import hashlib,json,struct
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=p.read_text();a=s.index('int antfly_metal_lighton_prefill_ffn_apply(');b=s.index('\nint termite_metal_decode_runtime_apply_bf16_gate_up_device',a);part=s[a:b]
old='const size_t variant = rows <= 512 ? 1 : 0, m = variant ? 64 : 32, n = variant ? 32 : 64;';new='const size_t variant = rows <= 512 ? 1 : 0, m = tile_m82 ? tile_m82 : (variant ? 64 : 32), n = tile_n82 ? tile_n82 : (variant ? 32 : 64);';assert part.count(old)==1;part=part.replace(old,new)
old='''threadsPerThreadgroup:MTLSizeMake(128, 1, 1)];
        [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
        params.in_dim''';new='''threadsPerThreadgroup:MTLSizeMake(tile_threads82 ? tile_threads82 : 128, 1, 1)];
        [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
        params.in_dim''';assert part.count(old)==1;part=part.replace(old,new)
(v/'engine82_probe_kernels.m').write_text('#include <stddef.h>\nstatic size_t tile_m82, tile_n82, tile_threads82;\n'+s[:a]+part+s[b:])
s=(r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text();old='#include "../../src/backends/metal_kernels.m"';assert s.count(old)==1;(v/'engine82_probe_checks.m').write_text(s.replace(old,'#include "engine82_probe_kernels.m"'))
s=(v/'engine78_packed_gate.metal').read_text();s+='\nkernel void engine82_gate2(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device ushort*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){engine78_gate<32,128,8>(x,g,u,gb,ub,y,p,group);}\n';assert 'inline void engine78_gate' in s;(v/'engine82_real_gate.metal').write_text(s)
# Reuse the qualified frame dispatcher and guarded-buffer helpers, with slot selection only.
s=(v/'engine80_c_prefill_ffn_check_verify2.m').read_text();s=s[:s.index('static int preflight79(')];s=s.replace('../zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m','engine82_probe_checks.m').replace('#include "engine78_source.inc"','#include <fcntl.h>\n#include <unistd.h>\nstatic size_t slot_base82;')
s=s.replace('apply_linear_multi_row_device(r,0,','apply_linear_multi_row_device(r,slot_base82,').replace('apply_linear_multi_row_device(r,1,','apply_linear_multi_row_device(r,slot_base82+1,').replace('apply_linear_multi_row_device(r,2,','apply_linear_multi_row_device(r,slot_base82+2,').replace('ffn_can_apply(r,0,1,2,','ffn_can_apply(r,slot_base82,slot_base82+1,slot_base82+2,').replace('ffn_apply(r,0,1,2,','ffn_apply(r,slot_base82,slot_base82+1,slot_base82+2,')
(v/'engine82_real_ffn_prefix.inc').write_text(s)
model=v/'ocr-models/lighton4b/model.safetensors'
with model.open('rb')as f:n=struct.unpack('<Q',f.read(8))[0];raw=f.read(n);h=json.loads(raw)
layers=[0,8,16,24];offsets=[]
for layer in layers:
 row=[]
 for kind in ['gate','up','down']:
  key=f'model.language_model.layers.{layer}.mlp.{kind}_proj.weight';t=h[key];expected=[2560,9216]if kind=='down'else[9216,2560];assert t['dtype']=='BF16'and t['shape']==expected
  assert t['data_offsets'][1]-t['data_offsets'][0]==2560*9216*2;row.append(n+8+t['data_offsets'][0])
 offsets.append(row)
(v/'engine82_weight_offsets.inc').write_text('static const char *model_path82='+json.dumps(str(model))+';\nstatic const off_t weight_offsets82[4][3]='+str(offsets).replace('[','{').replace(']','}')+';\n')
(v/'engine82_real_ffn_preparation.json').write_text(json.dumps(dict(scope='Private real-checkpoint FFN probe only: four distinct real BF16 layer weight triplets, >500MiB GPU weight working set, full packed/output parity against ordinary qualified projections and CPU corners. ABBA current fused FFN versus optional 32x128/SG8 gate tile. No source81 edits or full-model speed claim.',production_c_sha256=sha(p),model_path=str(model),model_size=model.stat().st_size,model_header_sha256=hashlib.sha256(raw).hexdigest(),layers=layers,offsets=offsets,working_estimate_bytes=2*1024**3,os_reserve_bytes=6*1024**3),indent=2)+'\n')
print('PREPARED REAL FFN82',flush=True)
