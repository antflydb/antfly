from pathlib import Path
import hashlib,json,re,subprocess,sys
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';p=root/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_engine_m4_max';manifest=out/'engine37_build_manifest.json';binary=json.loads(manifest.read_text())['binary_path'];oracle=out/'mlx_florence_engine37_paired19_r1_reference/report.json';records=[];fixtures=None
for c,rows in [(1,1),(2,2),(4,4),(8,4),(16,4),(16,8),(32,8)]:
 dest=out/f'engine37_florence_geometry_c{c}_rows{rows}_r128'
 assert not(dest/'report.json').exists(),dest
 cmd=[sys.executable,str(p/'benchmark_concurrency.py'),'--native-test',binary,'--model','florence=/Users/ajroetker/.antfly/inference/models/antflydb/florence-2-base','--images',str(root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(p/'corpus/receipt.png'),str(p/'corpus/shipping.png'),'--requests','128','--concurrency',str(c),'--max-tokens','256','--modes','batch','--native-read-batch-size',str(rows),'--batch-wait-us','5000','--florence-batch-wait-us','5000','--memory-gib','24','--shared-memory-gib','28','--backend-memory-gib','16','--kv-memory-gib','4','--scratch-memory-gib','8','--timeout','900','--reference-report',str(oracle),'--build-manifest',str(manifest),'--output-dir',str(dest),'--policy-rounds','current']
 if rows>1:cmd+=['--require-florence-no-repeat-argmax','--require-florence-single-frame']
 print('START',c,rows,flush=True)
 with open(f'/private/tmp/ocr-engine37-florence-geometry-c{c}-rows{rows}.txt','w')as stream:result=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
 assert result.returncode==0,(c,rows,result.returncode)
 rp=dest/'report.json';d=json.loads(rp.read_text());r=d['results'][0];sample=r['policy_rounds'][0]
 assert r['status']=='ok'and r['serial_reference_parity']and r['cross_runtime_content_parity']and sample['completed']==128
 text={x['image_index']:x['text']for x in r['references']}
 if fixtures is None:fixtures=text
 else:assert text==fixtures
 record=dict(concurrency=c,model_batch_size=rows,report=str(rp.relative_to(out)),report_sha256=hashlib.sha256(rp.read_bytes()).hexdigest(),all_128_native_pages_equal_native_serial=True,native_geometry_full_fixture_string_identity=True,cross_runtime_whitespace_normalized_content=True,pages_per_second=sample['pages_per_second'],process_cpu_ms=sample['process_cpu_ms'],single_frame=r.get('florence_single_frame'),primary_throughput_eligible=True)
 records.append(record);(out/'engine37_florence_geometry_comparison_audit.json').write_text(json.dumps(dict(scope='Successive native geometry candidates with scopes off. Available MLX serial proxy differs in precision/policy; no fresh proxy win established by this sweep.',records=records,status='running'),indent=2)+'\n')
 print('DONE',c,rows,sample['pages_per_second'],flush=True)
(out/'engine37_florence_geometry_comparison_audit.json').write_text(json.dumps(dict(scope='Complete successive native geometry candidates, not a fresh repeated MLX proxy comparison.',records=records,status='pass'),indent=2)+'\n')
print('BEST',max(records,key=lambda x:x['pages_per_second']),flush=True)
