from pathlib import Path
import datetime,hashlib,json,os,psutil,subprocess,time,shutil,re
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
audit=o/'engine76_fma_probe_audit.json';d=json.loads(audit.read_text());backup=o/'engine76_fma_probe_failed_parse_audit.json';assert not backup.exists();shutil.copyfile(audit,backup)
prep=json.loads((v/'engine76_preparation.json').read_text());assert all(sha(r/p)==h for p,h in prep['inputs'].items());binary=v/'engine76_fma_probe';assert sha(binary)==d['binary_sha256']
d.update(continuation_driver_sha256=sha(Path(__file__)),failed_parse_audit_sha256=sha(backup),failed_parse_log_sha256=sha('/private/tmp/ocr-engine76-fma1.txt'),output_correction='Original combined stdout/stderr interleaved case summaries into buffered JSON. Preserve that log and rerun both candidates using the identical binary with separate stdout/stderr. No kernel/input/check changes.')
def save():audit.write_text(json.dumps(d,indent=2)+'\n')
save()
for candidate in [1,2]:
 need=512*1024**2;reserve=6*1024**3
 while psutil.virtual_memory().available < need+reserve:time.sleep(5)
 available=psutil.virtual_memory().available;stdout=Path(f'/private/tmp/ocr-engine76-verify2-fma{candidate}-stdout.txt');stderr=Path(f'/private/tmp/ocr-engine76-verify2-fma{candidate}-stderr.txt');assert not stdout.exists()and not stderr.exists();print('START FMA VERIFY2',candidate,flush=True)
 with stdout.open('w')as so,stderr.open('w')as se:result=subprocess.run([str(binary),str(candidate)],stdout=so,stderr=se,env=dict(os.environ,ANTFLY_LIGHTONOCR3_THROUGHPUT='0'),timeout=900)
 records=[json.loads(x)for x in stdout.read_text().splitlines()if x.startswith('{"candidate":')];summaries=re.findall(r'prefill_core_check seq=(\d+) heads=(\d+) initialized=([01]) max_abs=([^\s]+)',stderr.read_text())
 row=dict(candidate=candidate,exit_code=result.returncode,records=records,summaries=[dict(seq=int(s),heads=int(h),initialized=int(i),max_abs=float(e))for s,h,i,e in summaries],stdout=str(stdout),stdout_sha256=sha(stdout),stderr=str(stderr),stderr_sha256=sha(stderr),available_bytes=available,working_estimate_bytes=need,os_reserve_bytes=reserve);d['checks'].append(row);save()
 assert result.returncode==0 and len(records)==1200 and len(summaries)==20 and all(float(x[3])<=2e-4 for x in summaries)
 keys={(x['seq'],x['heads'],x['initialized'],x['trial'],x['mode'])for x in records};assert len(keys)==1200 and all(x['candidate']==candidate for x in records)
 assert f'FMA PROBE PASS candidate={candidate}' in stderr.read_text();print('DONE FMA VERIFY2',candidate,len(records),flush=True)
d['status']='pass';save();Path('/private/tmp/ocr-engine76-fma-afterqual-parent.txt').open('a').write('\nOutput-reader failure recovered by separate immutable verify2 driver; identical binary reran both cases with separate stdout/stderr, full checks passed.\nENGINE76 FMA PROBE DONE\n');print('ENGINE76 FMA PROBE DONE',flush=True)
