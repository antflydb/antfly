from pathlib import Path
import datetime,hashlib,json,math,re,subprocess,sys
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';p=root/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_engine_m4_max';manifest=out/'engine37_build_manifest.json';binary=json.loads(manifest.read_text())['binary_path']
images=[root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png',p/'corpus/receipt.png',p/'corpus/shipping.png']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
audit=dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Available MLX-VLM serial proxy only; installed vLLM Metal has no Florence adapter. Native publisher Q4_K with F16 encoder mirrors and no-repeat trigrams vs original MLX FP16/default greedy. MLX batch2 failed earlier parity, so only valid batch1 is measured. R128 mixed pages. Shared machine uncontrolled, no own CPU compilation or sampling. Native scope off/on then on/off in reverse order.',required_ratio=1.05,comparisons=[],status='running')
def save():(out/'paired19_florence_comparison_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
def reference(round):
 dest=out/f'mlx_florence_engine37_paired19_r{round}_reference';assert not(dest/'report.json').exists()
 cmd=[sys.executable,str(p/'benchmark_mlx_florence.py'),'--model-dir',str(v/'ocr-models/florence-fp16'),'--images',*map(str,images),'--batch-sizes','1','--requests','128','--max-tokens','256','--output-dir',str(dest)]
 print('START MLX PROXY',round,flush=True)
 with open(f'/private/tmp/ocr-engine37-florence-paired19-reference{round}.txt','w')as stream:result=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
 assert result.returncode==0,result.returncode
 rp=dest/'report.json';d=json.loads(rp.read_text());assert d['status']=='ok'and d['results'][0]['serial_reference_parity']and len(d['references'])==3
 print('DONE MLX PROXY',round,d['results'][0]['pages_per_second'],flush=True);return rp,d
native_fixture=None
def native(round,enabled,oracle):
 global native_fixture
 dest=out/f'engine37_florence_paired19_r{round}_scopes{int(enabled)}_native';assert not(dest/'report.json').exists()
 cmd=[sys.executable,str(p/'benchmark_concurrency.py'),'--native-test',binary,'--model','florence=/Users/ajroetker/.antfly/inference/models/antflydb/florence-2-base','--images',*map(str,images),'--requests','128','--concurrency','8','--max-tokens','256','--modes','batch','--native-read-batch-size','8','--batch-wait-us','5000','--florence-batch-wait-us','5000','--memory-gib','24','--shared-memory-gib','28','--backend-memory-gib','16','--kv-memory-gib','4','--scratch-memory-gib','8','--timeout','600','--reference-report',str(oracle),'--build-manifest',str(manifest),'--output-dir',str(dest),'--require-florence-no-repeat-argmax','--require-florence-single-frame','--policy-rounds','current']
 if enabled:cmd+=['--ocr-encoder-scopes']
 print('START NATIVE',round,enabled,flush=True)
 with open(f'/private/tmp/ocr-engine37-florence-paired19-r{round}-scopes{int(enabled)}.txt','w')as stream:result=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT)
 assert result.returncode==0,(round,enabled,result.returncode)
 rp=dest/'report.json';d=json.loads(rp.read_text());r=d['results'][0];sample=r['policy_rounds'][0]
 assert r['status']=='ok'and r['serial_reference_parity']and r['cross_runtime_content_parity']and sample['completed']==128
 frame=r['florence_single_frame'];assert frame['steps']>0 and frame['api_fallbacks']==0 and frame['topology_mismatches']==0
 text={x['image_index']:x['text']for x in r['references']}
 if native_fixture is None:native_fixture=text
 else:assert text==native_fixture
 timed=(dest/r['log']).read_text().split('OCR_POLICY round=0')[1]
 scopes=list(map(int,re.findall(r'FLORENCE2 encoder_scope_opens=(\d+)',timed)));assert scopes and all((x>0)==enabled for x in scopes),scopes
 print('DONE NATIVE',round,enabled,sample['pages_per_second'],flush=True)
 return rp,d,scopes
def compare(round,enabled,n,ref,order):
 np,nd,scopes=n;rp,rd=ref;r=nd['results'][0];sample=r['policy_rounds'][0]
 native={x['image_index']:x['text']for x in r['references']};reference={i:x['text']for i,x in enumerate(rd['references'])}
 assert{k:''.join(t.split())for k,t in native.items()}=={k:''.join(t.split())for k,t in reference.items()}
 item=dict(round=round,ocr_encoder_scopes=enabled,order=order,native_report=str(np.relative_to(out)),native_report_sha256=sha(np),proxy_report=str(rp.relative_to(out)),proxy_report_sha256=sha(rp),native_pages_per_second=sample['pages_per_second'],proxy_pages_per_second=rd['results'][0]['pages_per_second'],native_to_proxy_ratio=sample['pages_per_second']/rd['results'][0]['pages_per_second'],all_128_native_pages_equal_native_serial=True,native_scope_modes_full_fixture_string_identity=True,cross_runtime_full_fixture_string_identity=native==reference,cross_runtime_whitespace_normalized_content=True,encoder_scope_opens=scopes,primary_throughput_eligible=True)
 audit['comparisons'].append(item);save();print('COMPARISON',json.dumps(item),flush=True)
save();r0=reference(0)
for enabled in [False,True]:compare(0,enabled,native(0,enabled,r0[0]),r0,'MLX proxy then native scopes off then on')
n1={enabled:native(1,enabled,r0[0])for enabled in [True,False]};r1=reference(1)
for enabled in [True,False]:compare(1,enabled,n1[enabled],r1,'native scopes on then off, then fresh MLX proxy')
candidates=[]
for enabled in [False,True]:
 checks=[x for x in audit['comparisons']if x['ocr_encoder_scopes']==enabled]
 candidates.append(dict(ocr_encoder_scopes=enabled,geometric_mean_ratio=math.prod(x['native_to_proxy_ratio']for x in checks)**0.5,minimum_ratio=min(x['native_to_proxy_ratio']for x in checks),clear_repeated_proxy_win=all(x['native_to_proxy_ratio']>=audit['required_ratio']for x in checks)))
audit['candidates']=candidates;audit['status']='clear_repeated_proxy_win'if any(x['clear_repeated_proxy_win']for x in candidates)else'small_repeated_proxy_lead'if any(x['minimum_ratio']>1 for x in candidates)else'native_behind_proxy';save();print('FINAL',audit['status'],flush=True);sys.exit(0 if audit['status']=='clear_repeated_proxy_win'else 2)
