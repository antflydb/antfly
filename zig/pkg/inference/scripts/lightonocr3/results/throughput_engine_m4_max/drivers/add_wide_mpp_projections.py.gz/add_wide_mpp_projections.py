from pathlib import Path
import re,json
r=Path.cwd();p=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=p.read_text();v=r/'.venv-lighton-vllm-metal'
a='    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_WIDE_PROJECTION_TILES,';assert s.count(a)==1;s=s.replace(a,a+'\n    TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_WIDE_MPP,',1)
a='    "TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_PROJECTION_TILES",';assert s.count(a)==1;s=s.replace(a,a+'\n    "TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_MPP",',1)
a='    uint64_t lightonocr3_wide_projection_tile_calls;';s=s.replace(a,a+'\n    uint64_t lightonocr3_wide_mpp_projection_calls;\n    uint64_t lightonocr3_wide_mpp_head_calls;',1)
a='    id<MTLComputePipelineState> lightonocr3_gate_up_wide16_pipeline;';s=s.replace(a,a+'\n    id<MTLComputePipelineState> lightonocr3_wide_mpp_pipelines[3];',1)
source=(v/'wide_mpp_probe.metal').read_text();parts=re.findall(r'kernel void wide_mpp_\d+\(.*?\n}\n',source,re.S);assert len(parts)==6;selected=''
for slot,index in enumerate([0,1,5]):selected+=parts[index].replace(f'wide_mpp_{index}',f'termite_lightonocr3_wide_mpp_{slot}')
a=s.index('static NSString *termite_metal_lightonocr3_tensor_source(void)');b=s.index('\n    ;\n}',a);s=s[:b]+''.join('\n        '+json.dumps(line+'\n')for line in selected.splitlines())+s[b:]
a='            runtime->lightonocr3_gate_up_wide16_pipeline = termite_metal_make_pipeline(device, tensor_library, @"termite_lightonocr3_gate_up_wide16");';assert s.count(a)==1;s=s.replace(a,a+'\n            for (size_t i = 0; i < 3; i++) runtime->lightonocr3_wide_mpp_pipelines[i] = termite_metal_make_pipeline(device, tensor_library, [NSString stringWithFormat:@"termite_lightonocr3_wide_mpp_%zu", i]);',1)
# Dispatch only the head initially; shape qualification is extended after the
# all-row probe, before freezing the build.
a='static int termite_metal_try_lightonocr3_local_projection(';idx=s.index(a)
helper='''// A vocabulary head at nine through sixteen rows underfills the scalar
// vector route. A sixteen-row matrix tile reuses its weights across the full
// batch. Keep the established small-row/unsupported routes available.
static int termite_metal_try_lightonocr3_wide_mpp(termite_metal_decode_runtime *r, size_t slot,
    id<MTLBuffer> input, size_t input_offset, size_t rows, size_t in, size_t out,
    id<MTLBuffer> output, size_t output_offset) {
    const bool head = (in == 1024 || in == 2560) && out == 248320;
    if (rows < 9 || rows > 16 || !head || !termite_metal_lightonocr3_fast_projections(r) ||
        !r->qwen35_ocr_vector_loads_enabled || input_offset % 16 || output_offset % 4 ||
        r->linear_weight_dtypes[slot] != TERMITE_METAL_DENSE_LINEAR_DTYPE_BF16 ||
        termite_metal_frame_env_enabled(r, TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_WIDE_MPP) ||
        termite_metal_frame_env_enabled(r, TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_MPP) ||
        termite_metal_frame_env_enabled(r, TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_BATCH_PROJECTIONS) ||
        termite_metal_frame_env_enabled(r, TERMITE_METAL_FRAME_LIGHTONOCR3_BF16_ACTIVATIONS)) return 0;
    const size_t variant = 2, columns = 64, threads = 128;
    id<MTLComputePipelineState> pipeline = r->lightonocr3_wide_mpp_pipelines[variant];
    if (!termite_metal_lightonocr3_local_pipeline_valid(r, pipeline, threads, 0)) return 0;
    if (input == output || output == r->linear_weight_buffers[slot] || output == r->linear_bias_buffers[slot]) return -3;
    const size_t ib = rows * in * sizeof(float), ob = rows * out * sizeof(float);
    if (input_offset > input.length || ib > input.length - input_offset || output_offset > output.length ||
        ob > output.length - output_offset || r->linear_weight_buffers[slot].length < in * out * 2 ||
        r->linear_bias_buffers[slot].length < out * sizeof(float)) return -7;
    bool owned = true;
    id<MTLCommandBuffer> cb = termite_metal_decode_runtime_command_buffer(r, __func__, &owned);
    if (cb == nil) return -10;
    if (!owned && (termite_metal_decode_runtime_retain_frame_resource(r, input) ||
        termite_metal_decode_runtime_retain_frame_resource(r, output))) return -10;
    termite_metal_planned_encoder_range accesses[4];
    if (termite_metal_planned_range_make(input, input_offset, ib, TERMITE_METAL_PLANNED_RANGE_READ, &accesses[0], -11) ||
        termite_metal_planned_range_make(r->linear_weight_buffers[slot], 0, in * out * 2, TERMITE_METAL_PLANNED_RANGE_READ, &accesses[1], -11) ||
        termite_metal_planned_range_make(r->linear_bias_buffers[slot], 0, out * sizeof(float), TERMITE_METAL_PLANNED_RANGE_READ, &accesses[2], -11) ||
        termite_metal_planned_range_make(output, output_offset, ob, TERMITE_METAL_PLANNED_RANGE_WRITE, &accesses[3], -11) ||
        termite_metal_decode_runtime_prepare_planned_compute_accesses(r, accesses, 4, -11)) return -11;
    id<MTLComputeCommandEncoder> encoder = r->active_planned_compute_encoder;
    const bool planned = encoder != nil;
    if (!planned) encoder = termite_metal_tracked_compute_command_encoder_for(cb, TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);
    if (encoder == nil) return -12;
    const termite_metal_linear_params params = {(uint32_t)rows, (uint32_t)in, (uint32_t)out, 0};
    [encoder setComputePipelineState:pipeline];
    [encoder setBuffer:input offset:input_offset atIndex:0];
    [encoder setBuffer:r->linear_weight_buffers[slot] offset:0 atIndex:1];
    [encoder setBuffer:r->linear_bias_buffers[slot] offset:0 atIndex:2];
    [encoder setBuffer:output offset:output_offset atIndex:3];
    [encoder setBytes:&params length:sizeof(params) atIndex:4];
    [encoder dispatchThreadgroups:MTLSizeMake(out / columns, 1, 1) threadsPerThreadgroup:MTLSizeMake(threads, 1, 1)];
    if (!planned) [encoder endEncoding];
    termite_metal_maybe_trace_dense_linear_dispatch("linear_multi_row_device", slot, rows, in, out,
        head ? "lightonocr3_wide_mpp_head" : "lightonocr3_wide_mpp_projection", !owned, planned, false, false, false);
    const int rc = termite_metal_decode_runtime_finish_command_buffer(cb, owned, -13);
    if (rc != 0) return rc;
    if (head) r->lightonocr3_wide_mpp_head_calls = termite_metal_u64_saturating_add(r->lightonocr3_wide_mpp_head_calls, 1);
    else r->lightonocr3_wide_mpp_projection_calls = termite_metal_u64_saturating_add(r->lightonocr3_wide_mpp_projection_calls, 1);
    return 1;
}

'''
s=s[:idx]+helper+s[idx:]
a=s.index('int termite_metal_decode_runtime_apply_linear_multi_row_device(');b=s.index('        const bool wide_shape =',a);s=s[:b]+'''        const int wide_mpp_rc = termite_metal_try_lightonocr3_wide_mpp(runtime,slot,input_buffer,input_offset,rows,in_dim,out_dim,output_buffer,output_offset);
        if (wide_mpp_rc != 0) return wide_mpp_rc == 1 ? 0 : wide_mpp_rc;
'''+s[b:]
s+='''\nvoid termite_metal_decode_runtime_lighton_wide_mpp_stats(termite_metal_decode_runtime *runtime, uint64_t *values) {
    if (values == NULL) return;
    values[0] = runtime != NULL ? runtime->lightonocr3_wide_mpp_projection_calls : 0;
    values[1] = runtime != NULL ? runtime->lightonocr3_wide_mpp_head_calls : 0;
}
''';p.write_text(s)
p=r/'zig/pkg/inference/src/backends/metal_runtime.zig';s=p.read_text();s+='\npub extern fn termite_metal_decode_runtime_lighton_wide_mpp_stats(runtime: ?*RawMetalDecodeRuntime, values: *[2]u64) void;\n';p.write_text(s)
p=r/'zig/pkg/inference/src/ops/metal_compute.zig';s=p.read_text().replace('    lighton_single_frame_stats: [2]u64 = @splat(0),','    lighton_single_frame_stats: [2]u64 = @splat(0),\n    lighton_wide_mpp_start: [2]u64 = @splat(0),',1).replace('        self.lighton_single_frame_stats = @splat(0);','        self.lighton_single_frame_stats = @splat(0);\n        metal_runtime_mod.termite_metal_decode_runtime_lighton_wide_mpp_stats(raw, &self.lighton_wide_mpp_start);',1);a='    pub fn lightOnPreparedBlockCount(cb: *const ops.ComputeBackend) usize {';s=s.replace(a,'''    pub fn lightOnWideMppStats(cb: *const ops.ComputeBackend) [2]u64 {
        if (cb.kind() != .metal) return @splat(0);
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        var values: [2]u64 = undefined;
        metal_runtime_mod.termite_metal_decode_runtime_lighton_wide_mpp_stats(self.provider_impl.raw_decode_runtime, &values);
        for (&values, self.lighton_wide_mpp_start) |*value, start| value.* -|= start;
        return values;
    }

'''+a,1);p.write_text(s)
p=r/'zig/pkg/inference/src/server/server.zig';s=p.read_text();a='                    std.debug.print("LIGHTONOCR3 wide_projection_tiles={d}\\n", .{wide_tiles});';s=s.replace(a,a+'''
                    const wide_mpp = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnWideMppStats(&cb) else @as([2]u64, @splat(0));
                    std.debug.print("LIGHTONOCR3 wide_mpp_projections={d} wide_mpp_heads={d}\\n", .{ wide_mpp[0], wide_mpp[1] });''',1);p.write_text(s)
