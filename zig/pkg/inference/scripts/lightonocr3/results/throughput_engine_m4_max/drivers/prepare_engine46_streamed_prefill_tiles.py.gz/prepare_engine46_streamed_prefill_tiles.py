from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal')
base=Path('zig/pkg/inference/src/backends/metal_kernels.m').read_text();s=base
variants=[(64,64,8),(64,64,4),(128,64,8),(64,128,8)]
needle='    id<MTLComputePipelineState> lightonocr3_mpp_bf16_n32_pipeline;'
assert s.count(needle)==1
s=s.replace(needle,needle+'''
    id<MTLComputePipelineState> prefill_larger_probe_pipelines[4];
    uint32_t prefill_larger_probe_variant;
    uint64_t prefill_larger_probe_calls;''')
a=s.index('        "kernel void termite_lightonocr3_mpp_bfloat_32_64(')
b=s.index('        "kernel void termite_lightonocr3_mpp_bfloat_64_32(',a)
template=s[a:b];extra=''
for i,(m,n,sg)in enumerate(variants):
 part=template.replace('mpp_bfloat_32_64',f'mpp_bfloat_larger_probe_{i}')
 part=part.replace('int(group.y)*32',f'int(group.y)*{m}').replace('int(group.x)*64',f'int(group.x)*{n}')
 part=part.replace('matmul2d_descriptor(32,64',f'matmul2d_descriptor({m},{n}')
 part=part.replace('execution_simdgroups<4>',f'execution_simdgroups<{sg}>')
 part=part.replace('coord[1]<32',f'coord[1]<{m}').replace('coord[0]<64',f'coord[0]<{n}')
 extra+=part
s=s[:b]+extra+s[b:]
needle='''            runtime->lightonocr3_mpp_bf16_n32_pipeline =
                termite_metal_make_pipeline(device, tensor_library, @"termite_lightonocr3_mpp_bfloat_64_32");'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''
            for (size_t i=0; i<4; i++) runtime->prefill_larger_probe_pipelines[i] =
                termite_metal_make_pipeline(device, tensor_library,
                    [NSString stringWithFormat:@"termite_lightonocr3_mpp_bfloat_larger_probe_%zu", i]);''')
needle='    runtime->lightonocr3_mpp_bf16_n32_pipeline = nil;';assert s.count(needle)==1
s=s.replace(needle,needle+'\n    for (size_t i=0; i<4; i++) runtime->prefill_larger_probe_pipelines[i] = nil;')
a=s.index('static int termite_metal_try_lightonocr3_mpp(');b=s.index('\n}\n',a)+2;part=s[a:b]
needle='''    id<MTLComputePipelineState> pipeline =
        segment4 ?'''
assert part.count(needle)==1
part=part.replace(needle,'''    const bool larger_probe = runtime->prefill_larger_probe_variant >= 1 &&
        runtime->prefill_larger_probe_variant <= 4 &&
        runtime->active_frame_cb != nil &&
        runtime->active_frame_regime == TERMITE_METAL_FRAME_REGIME_PREFILL &&
        rows >= 128 && rows <= 2048 &&
        ((in_dim == 2560 && out_dim == 9216) || (in_dim == 9216 && out_dim == 2560));
    const size_t probe_index = larger_probe ? runtime->prefill_larger_probe_variant - 1 : 0;
    static const size_t probe_m[4]={64,64,128,64}, probe_n[4]={64,64,64,128}, probe_sg[4]={8,4,8,8};
    id<MTLComputePipelineState> probe_pipeline = larger_probe ? runtime->prefill_larger_probe_pipelines[probe_index] : nil;
    if (larger_probe && (!bf16 || probe_pipeline == nil ||
        probe_pipeline.threadExecutionWidth != 32 ||
        probe_pipeline.maxTotalThreadsPerThreadgroup < probe_sg[probe_index]*32 ||
        probe_pipeline.staticThreadgroupMemoryLength > runtime->device.maxThreadgroupMemoryLength)) return 0;
    id<MTLComputePipelineState> pipeline =
        larger_probe ? probe_pipeline : segment4 ?''')
needle='''    size_t tm = (small_tile || segment4) ? 8 : (n32 ? 64 : 32), tn = segment4 ? 8 : small_tile ? (four_row_mpp ? 16 : 32) : (n32 ? 32 : 64);'''
assert part.count(needle)==1
part=part.replace(needle,'''    size_t tm = larger_probe ? probe_m[probe_index] : (small_tile || segment4) ? 8 : (n32 ? 64 : 32),
           tn = larger_probe ? probe_n[probe_index] : segment4 ? 8 : small_tile ? (four_row_mpp ? 16 : 32) : (n32 ? 32 : 64);''')
needle='threadsPerThreadgroup:MTLSizeMake((small_tile || segment4) ? 32 : 128, 1, 1)]'
assert part.count(needle)==1
part=part.replace(needle,'threadsPerThreadgroup:MTLSizeMake(larger_probe ? probe_sg[probe_index]*32 : (small_tile || segment4) ? 32 : 128, 1, 1)]')
needle='    return rc == 0 ? 1 : rc;'
assert part.count(needle)==1
part=part.replace(needle,'    if (rc == 0 && larger_probe) runtime->prefill_larger_probe_calls++;\n'+needle)
s=s[:a]+part+s[b:]
(v/'engine46_streamed_prefill_tiles_kernels.m').write_text(s)
checker=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine46_streamed_prefill_tiles_kernels.m"')
(v/'engine46_streamed_prefill_tiles_checks.m').write_text(checker)
wrapper=(v/'engine43_streamed_prefill_probe.m').read_text().replace('engine43_streamed_prefill_probe_checks.m','engine46_streamed_prefill_tiles_checks.m')
needle=' r->prefill_row64_probe=variant!=0;r->prefill_probe_variant=(uint32_t)variant;';assert wrapper.count(needle)==1
wrapper=wrapper.replace(needle,' r->prefill_larger_probe_variant=(uint32_t)variant;')
wrapper=wrapper.replace('prefill_row64_probe_calls','prefill_larger_probe_calls').replace('variant<=2','variant<=4')
wrapper=wrapper.replace('STREAM_PREFILL','LARGER_PREFILL')
(v/'engine46_streamed_prefill_tiles.m').write_text(wrapper)
plan=dict(status='prepared_only_not_compiled_or_run',base_engine='engine44',base_c_sha256=hashlib.sha256(base.encode()).hexdigest(),variants=variants,
 rows=[554,432,662],shapes=[[2560,9216],[9216,2560]],distinct_weight_slots=32,timed_frames_per_leg=8,warm_frames_per_leg=2,
 checks='One planned prefill frame per 32 matrices; full GPU gold + CPU corners + persistent canaries validated only after each ABBA leg; actual production BF16 pack count32 each frame and selected candidate count32 vs0baseline. These larger tiles have not been tested in the representative streamed setup.')
(v/'engine46-streamed-prefill-tiles-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
build=(v/'build_engine44_streamed_ffn_probe.py').read_text().replace('engine44_streamed_ffn_probe','engine46_streamed_prefill_tiles').replace('engine44-streamed-ffn-probe','engine46-streamed-prefill-tiles')
build=build.replace(", 'engine46_streamed_prefill_tiles.metal'",'')
(v/'build_engine46_streamed_prefill_tiles.py').write_text(build)
print('Prepared isolated larger-tile probe only. Do not compile or run until all primary jobs finish.')
