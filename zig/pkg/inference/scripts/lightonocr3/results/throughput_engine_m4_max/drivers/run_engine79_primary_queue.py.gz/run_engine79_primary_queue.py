from pathlib import Path
import subprocess,sys,time
v=Path('.venv-lighton-vllm-metal')
while True:
 p=Path('/private/tmp/ocr-engine79-finalqualification-parent.txt');s=p.read_text()if p.exists()else''
 if 'Traceback'in s:raise RuntimeError(s[-3000:])
 if 'ENGINE79 FINAL QUALIFICATION DONE'in s:break
 time.sleep(5)
for name in ['run_engine79_08_paired67.py','run_engine79_florence_paired67.py','run_engine79_api_paired66.py']:
 print('START PRIMARY79',name,flush=True)
 with Path('/private/tmp/ocr-'+name.removesuffix('.py')+'-parent.txt').open('w')as log:result=subprocess.run([sys.executable,str(v/name)],stdout=log,stderr=subprocess.STDOUT)
 print('DONE PRIMARY79',name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
print('ENGINE79 PRIMARY QUEUE DONE',flush=True)
