from pathlib import Path
import subprocess
import sys

v = Path('.venv-lighton-vllm-metal')
for name, extra in [('functional', []), ('physical64_units512_qualification', []), ('4b_profiles', ['--qualification'])]:
    print('START', name, flush=True)
    with Path(f'/private/tmp/ocr-engine38-{name}-driver.txt').open('w') as log:
        result = subprocess.run([sys.executable, str(v / f'run_engine38_{name}.py'), *extra], stdout=log, stderr=subprocess.STDOUT)
    print('DONE', name, result.returncode, flush=True)
    if result.returncode:
        sys.exit(result.returncode)
