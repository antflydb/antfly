from pathlib import Path
import subprocess,sys
v=Path('.venv-lighton-vllm-metal')
for name in ['run_engine27_c_checks.py','engine27_verify_preset_only_test.py','engine27_verify_preset_physical32_test.py','engine27_verify_default_gpu_test.py']:
 print('START',name,flush=True)
 with open('/private/tmp/ocr-engine27-qualify-'+name+'.txt','w')as f:r=subprocess.run([sys.executable,str(v/name)],stdout=f,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
print('START large pack benchmark',flush=True)
with open('/private/tmp/ocr-engine27-prefill-pack-large-benchmark.txt','w')as f:r=subprocess.run([str(v/'engine27_conformance'),'--benchmark-prefill-pack-reuse-large'],stdout=f,stderr=subprocess.STDOUT)
print('DONE large pack benchmark',r.returncode,flush=True);sys.exit(r.returncode)
