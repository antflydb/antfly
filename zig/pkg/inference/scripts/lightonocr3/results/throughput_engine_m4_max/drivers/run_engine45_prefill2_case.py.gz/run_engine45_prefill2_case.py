from pathlib import Path
import hashlib,json,os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
mode=sys.argv[1];c=int(sys.argv[2]);wide64=bool(int(sys.argv[3]));assert mode in ['qualification','primary'] and c in [60,64]
n=64 if mode=='qualification' else 128
label=f'vision1_prefill2_c{c}_vf2_wide64{int(wide64)}_r{n}_{mode}'
dest=out/f'engine45_4b_{label}';assert not(dest/'report.json').exists()
env=os.environ.copy()
env.update(OCR_REFERENCE_LABEL='_primary_reference20_r0_auto_c64_r128',OCR_PHYSICAL32='0',OCR_PHYSICAL64='1',
 OCR_CONCURRENCY=str(c),OCR_REQUESTS=str(n),OCR_WIDE='1',OCR_SCRATCH_GIB='10',OCR_BACKEND_GIB='17',OCR_KV_GIB='4',
 OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1',
 OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_VISION_BATCH='0',OCR_VISION_BATCH_ITEMS='1',OCR_PREFILL_BATCH='1',
 OCR_PREFILL_BATCH_ITEMS='2',OCR_PREFILL_WAIT_US='1000000',OCR_VISION_FRAME_BLOCKS='2',
 OCR_SINGLE_FRAME='1',OCR_STREAM_FIRST='0',OCR_GPU_GREEDY_STREAM='0',OCR_LOGICAL64='1',
 OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',
 OCR_ADMISSION_UNITS='512',OCR_DISABLE_64_ROW_TILE='0',OCR_DISABLE_WIDE_GATE_UP='0',
 OCR_WIDE64_GATE_UP=str(int(wide64)),ANTFLY_FLORENCE_CPU_PREPROCESS='0')
print('START',label,flush=True)
with Path('/private/tmp/ocr-engine45-4b-'+label+'-driver.txt').open('w')as log:
 r=subprocess.run([sys.executable,str(v/'run_engine45_budget_policies.py'),'4b:'+label],env=env,stdout=log,stderr=subprocess.STDOUT)
print('DONE',label,r.returncode,flush=True);assert r.returncode==0,(label,r.returncode)
rp=dest/'report.json';d=json.loads(rp.read_text());result=d['results'][0];sample=result['policy_rounds'][0]
assert result['status']=='ok' and result['serial_reference_parity'] and result['cross_runtime_content_parity']
assert sample['completed']==n and not sample['admission_pressures']
assert sample['host_recurrent_bytes_total']==0 and sample['single_frame_topology_mismatches']==0
assert any(b['items']==2 for b in sample['prefill_batches']), sample['prefill_batches']
assert (sample['wide_gate_up_calls']>0)==wide64
oracle=json.loads((out/'vllm_4b_primary_reference20_r0_auto_c64_r128/report.json').read_text())
assert {t['image_index']:t['text']for t in result['references']}=={t['image_index']:t['text']for t in oracle['references']}
record=dict(status='pass',concurrency=c,wide64_gate_up=wide64,vision_batch_items=1,prefill_batch_items=2,prefill_wait_us=1000000,
 vision_frame_blocks=2,completed=n,prefill_batches=sample['prefill_batches'],
 prefill_host_scratch_acquisitions=sample['prefill_host_scratch_acquisitions'],prefill_host_scratch_releases=sample['prefill_host_scratch_releases'],
 prefill_host_scratch_peak_bytes=sample['prefill_host_scratch_peak_bytes'],pages_per_second=sample['pages_per_second'],
 process_cpu_ms=sample['process_cpu_ms'],framed_runtime_totals=sample['framed_runtime_totals'],
 full_fixture_string_identity=True,all_native_pages_equal_serial_reference=True,primary_throughput_eligible=mode=='primary',
 own_cpu_compile_or_sampling_overlap=False,report=str(rp.relative_to(out)),report_sha256=hashlib.sha256(rp.read_bytes()).hexdigest())
(out/f'engine45_4b_{label}_audit.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
