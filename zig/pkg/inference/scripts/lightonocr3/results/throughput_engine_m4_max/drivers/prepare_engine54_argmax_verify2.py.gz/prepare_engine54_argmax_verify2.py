from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal')
s=(v/'engine54_argmax.metal').read_text().replace('ushort tg_size [[threads_per_threadgroup]], uint2 group [[threadgroup_position_in_grid]]','ushort3 tg_shape [[threads_per_threadgroup]], uint3 group [[threadgroup_position_in_grid]]').replace('    const uint block = group.x;','    const ushort tg_size = tg_shape.x;\n    const uint block = group.x;')
(v/'engine54_argmax_verify2.metal').write_text(s)
(v/'engine54_argmax_source_verify2.inc').write_text('static NSString *engine54_source(void) { return @'+json.dumps(s)+'; }\n')
(v/'engine54_argmax_probe_verify2.m').write_text((v/'engine54_argmax_probe.m').read_text().replace('engine54_argmax_source.inc','engine54_argmax_source_verify2.inc'))
(v/'build_engine54_argmax_probe_verify2.py').write_text((v/'build_engine54_argmax_probe.py').read_text().replace('engine54_argmax_source.inc','engine54_argmax_source_verify2.inc').replace('engine54_argmax.metal','engine54_argmax_verify2.metal').replace('engine54_argmax_probe.m','engine54_argmax_probe_verify2.m').replace("v/'engine54_argmax_probe'","v/'engine54_argmax_probe_verify2'").replace('ocr-engine54-argmax-build.txt','ocr-engine54-argmax-build-verify2.txt').replace('engine54_argmax_probe_build_manifest.json','engine54_argmax_probe_verify2_build_manifest.json'))
(v/'run_engine54_argmax_probe_verify2.py').write_text((v/'run_engine54_argmax_probe.py').read_text().replace('engine54_argmax_probe_build_manifest.json','engine54_argmax_probe_verify2_build_manifest.json').replace('ocr-engine54-argmax-probe.txt','ocr-engine54-argmax-probe-verify2.txt').replace('engine54_argmax_probe_audit.json','engine54_argmax_probe_verify2_audit.json'))
ns={};src=(v/'archive_engine10_evidence.py').read_text();exec(src[:src.index("archive('qualification'")],ns)
ns['archive']('drivers',list(v.glob('*engine54*verify2*')),'drivers_manifest.json')
ns['archive']('qualification',[Path('/private/tmp/ocr-engine54-argmax-probe-driver.txt')],'logs_manifest.json')
