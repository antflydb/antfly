from pathlib import Path

root = Path('zig/pkg/inference')
p = root / 'src/runtime/scheduler/native_generate.zig'
s = p.read_text()
start = s.index('test "LightOnOCR3 logical64 executor drains')
end = s.index('\ntest ', start + 6)
t = s[start:end].replace('logical64 executor drains two physical32 steps', 'physical64 executor drains one complete step')
t = t.replace('.max_step_items = 32', '.max_step_items = 64').replace('[32]StepItem', '[64]StepItem').replace('for (0..2)', 'for (0..1)').replace('@as(usize, 32), step.items.len', '@as(usize, 64), step.items.len').replace('@as(u64, 2), coordinator.schedulerStats()', '@as(u64, 1), coordinator.schedulerStats()')
p.write_text(s[:end] + '\n' + t + s[end:])
p = root / 'src/server/server.zig'
s = p.read_text()
start = s.index('test "LightOnOCR3 thirty-two-row workspace')
end = s.index('\ntest ', start + 6)
t = s[start:end].replace('thirty-two-row', 'sixty-four-row').replace('.prepared_rows = 32', '.prepared_rows = 64').replace('ordinary.backend_scratch_bytes + 4 *', 'ordinary.backend_scratch_bytes + 16 *').replace('8,536,064 bytes at thirty-two rows', '17,072,128 bytes at sixty-four rows').replace('twelve-MiB', 'twenty-four-MiB').replace('8_536_064', '17_072_128')
p.write_text(s[:end] + '\n' + t + s[end:])
p = root / 'scripts/lightonocr3/check_metal_projections.m'
s = p.read_text()
start = s.index('static int planned_mpp_check(')
end = s.index('\nint main(', start)
t = s[start:end].replace('planned_mpp_check', 'planned_wide64_check').replace('planned_mpp rows=', 'planned_wide64 rows=')
t = t.replace('results[4][6]', 'results[5][6]').replace('mode < 4', 'mode < 5').replace('encoders[4]', 'encoders[5]')
t = t.replace('uint64_t encoders[5] = {0};', 'uint64_t encoders[5] = {0};\n  const bool gate = out == 16 || out == 32;\n  double cross_tile_worst = 0;')
t = t.replace('uint64_t planned_before =', 'setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_64_ROW_TILE",\n           (mode == 0 || mode == 4) ? "1" : "0", 1);\n    uint64_t planned_before =')
t = t.replace('rows <= 32 ? TERMITE_METAL_FRAME_REGIME_DECODE\n                          : TERMITE_METAL_FRAME_REGIME_PREFILL', 'TERMITE_METAL_FRAME_REGIME_DECODE')
t = t.replace('mode == 1 || mode == 3', 'mode == 1 || mode == 3 || mode == 4')
t = t.replace('if (planned !=', 'if (!gate && (planned !=').replace('steps : 0))\n      return 13;', 'steps : 0)))\n      return 13;\n    if (gate && (planned != 0 || dedicated != 0))\n      return 20;')
old = '''      if (mode &&
          memcmp((float *)results[0][step].contents + 4, got, outputs * 4))
        return 15;'''
new = '''      const size_t reference = gate || mode == 4 ? 0 : 1;
      if (mode > 1 && memcmp((float *)results[reference][step].contents + 4,
                            got, outputs * 4))
        return 15;
      if (mode == 1) {
        const float *baseline = (float *)results[0][step].contents + 4;
        for (size_t j = 0; j < outputs; j++)
          cross_tile_worst = fmax(cross_tile_worst, fabs((double)baseline[j] - got[j]));
      }'''
assert old in t
t = t.replace(old, new)
t = t.replace('unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PLANNED_MPP");', 'unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_64_ROW_TILE");\n  unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PLANNED_MPP");')
t = t.replace('encoders=%llu/%llu/%llu/%llu cpu_max_abs=%g', 'encoders=%llu/%llu/%llu/%llu/%llu cpu_max_abs=%g cross_tile_max_abs=%g')
t = t.replace('(unsigned long long)encoders[3], worst);', '(unsigned long long)encoders[3], (unsigned long long)encoders[4], worst, cross_tile_worst);')
t = t.replace('return worst > 2e-4 ?', 'return worst > 2e-4 || cross_tile_worst > 2e-4 ?')
s = s[:end] + '\n' + t + s[end:]
marker = '        if (argc == 2 && strcmp(argv[1], "--check-planned-mpp") == 0) {'
suite = '''        if (argc == 2 && strcmp(argv[1], "--check-wide64") == 0) {
          const size_t rows[] = {33, 48, 56, 63, 64};
          const size_t shapes[][2] = {{1024, 6144}, {3584, 1024},
              {2560, 8192}, {9216, 2560}, {1024, 248320}, {2560, 248320},
              {1024, 16}, {2560, 32}};
          for (size_t pool = 0; pool < 2; pool++)
            for (size_t bf16 = 0; bf16 < 2; bf16++)
              for (size_t i = 0; i < sizeof(shapes) / sizeof(shapes[0]); i++) {
                if (bf16 && shapes[i][1] <= 32) continue;
                for (size_t j = 0; j < sizeof(rows) / sizeof(rows[0]); j++) {
                  @autoreleasepool {
                    int rc = planned_wide64_check(r, rows[j], shapes[i][0],
                                                  shapes[i][1], bf16 != 0, pool != 0);
                    if (rc) {
                      fprintf(stderr, "WIDE64_FAIL rows=%zu in=%zu out=%zu bf16=%zu pool=%zu rc=%d\\n",
                              rows[j], shapes[i][0], shapes[i][1], bf16, pool, rc);
                      return 136;
                    }
                  }
                }
              }
          termite_metal_decode_runtime_destroy(r);
          return 0;
        }
'''
assert marker in s
s = s.replace(marker, suite + marker)
start = s.index('static int decode_pack_reuse_check(')
end = s.index('\nstatic int ', start + 10)
s = s[:start] + s[start:end].replace('rows <= 32', 'rows <= 64') + s[end:]
s = s.replace('{33, 2560, 4096}, {32, 2560, 248320}', '{33, 2560, 4096}, {48, 2560, 4096}, {64, 2560, 4096},\n              {65, 2560, 4096}, {32, 2560, 248320}')
p.write_text(s)
