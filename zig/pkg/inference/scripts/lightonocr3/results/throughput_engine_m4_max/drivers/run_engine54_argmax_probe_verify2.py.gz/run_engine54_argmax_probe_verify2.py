from pathlib import Path
import hashlib,json,subprocess,re,os
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
p=o/'engine54_argmax_probe_verify2_build_manifest.json';m=json.loads(p.read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(m['binary'])==m['binary_sha256']
for name,h in m['input_sha256'].items():assert sha(name)==h,name
log=Path('/private/tmp/ocr-engine54-argmax-probe-verify2.txt');assert not log.exists()
with log.open('w')as out:r=subprocess.run([str(Path(m['binary']).resolve())],stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ))
s=log.read_text();checks=re.findall(r'^CHECK (.*)$',s,re.M)
records=[dict(zip(['rows','dim','trial','leg','mode','frames','gpu_ms','encode_ms','wall_ms'],map(float,x)))for x in re.findall(r'TIME rows=(\d+) dim=(\d+) trial=(\d+) leg=(\d+) mode=(\d+) frames=(\d+) gpu_ms=([\d.]+) encode_ms=([\d.]+) wall_ms=([\d.]+)',s)]
status='pass'if r.returncode==0 and'ENGINE54 PROBE PASS'in s and len(checks)==50 and len(records)==48 else'failed'
a=dict(status=status,exit_code=r.returncode,checks=checks,records=records,log_sha256=sha(log),build_manifest_sha256=sha(p),primary_full_model_result=False,ratios=[])
if status=='pass':
 for rows in [16,33,64]:
  q=[x for x in records if x['rows']==rows];entry=dict(rows=rows)
  for key in ['gpu_ms','encode_ms','wall_ms']:
   on=sum(x[key]for x in q if x['mode']==1)/8;off=sum(x[key]for x in q if x['mode']==0)/8;entry[key]=dict(candidate=on,baseline=off,candidate_over_baseline=on/off)
  a['ratios'].append(entry)
(o/'engine54_argmax_probe_verify2_audit.json').write_text(json.dumps(a,indent=2)+'\n')
ns={};src=(v/'archive_engine10_evidence.py').read_text();exec(src[:src.index("archive('qualification'")],ns);ns['archive']('qualification',[log],'logs_manifest.json')
print(json.dumps(dict(status=status,checks=len(checks),records=len(records),ratios=a['ratios']),indent=2),flush=True)
assert status=='pass',s[-4000:]
