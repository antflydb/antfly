from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py')
s=p.read_text()
needle='            "ANTFLY_FLORENCE_CPU_PREPROCESS",'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n            "ANTFLY_FLORENCE2_INCREMENTAL_ADMISSION",')
needle='    env["ANTFLY_FLORENCE_CPU_PREPROCESS"] = "1" if args.florence_cpu_preprocess else "0"'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n    env["ANTFLY_FLORENCE2_INCREMENTAL_ADMISSION"] = "0" if args.disable_florence_incremental_admission else "1"')
needle='    parser.add_argument("--florence-cpu-preprocess", action="store_true")'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n    parser.add_argument("--disable-florence-incremental-admission", action="store_true")')
dest=v/'engine46_benchmark_concurrency.proposal.py';assert not dest.exists();dest.write_text(s)
s=(v/'run_engine46_florence_case_verify.py').read_text()
s=s.replace("n=max(32,b) if mode=='qualification' else 128","n=max(32,b) if mode=='qualification' else 128\nincremental=int(sys.argv[5]) if len(sys.argv)>5 else 1\nassert incremental in [0,1]")
s=s.replace("label=f'florence_batch","label=f'florence_incremental{incremental}_batch")
s=s.replace("if enabled:cmd+=['--florence-cpu-preprocess']","if enabled:cmd+=['--florence-cpu-preprocess']\nif not incremental:cmd+=['--disable-florence-incremental-admission']")
s=s.replace("tuple(map(int,s))==(1,1,0,0)","tuple(map(int,s))==(incremental,1 if incremental else 256,0,0)")
s=s.replace("record=dict(status='pass',","record=dict(status='pass',incremental_admission=bool(incremental),incremental_admission_trace=stats,")
dest=v/'run_engine46_florence_admission_case.py';assert not dest.exists();dest.write_text(s)
