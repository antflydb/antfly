#include <metal_stdlib>
using namespace metal;
struct termite_qwen35_params { uint seq,key_heads,value_heads,dim,kernel_size,initialized; };
template<uint C>inline void engine76_body1(device float*state,device const float*conv,device const float*gates,device float*output,constant termite_qwen35_params&p,uint gid,uint lane){
 constexpr uint K=4*C;uint column=gid/32,h=column/(128/C),col=(column%(128/C))*C+lane%C,klane=lane/C;if(h>=p.value_heads)return;
 uint kh=h/(p.value_heads/p.key_heads),channels=(2*p.key_heads+p.value_heads)*128,base=h*128*128+klane*K*128+col;
 float s[K];
 #pragma unroll
 for(uint i=0;i<K;i++)s[i]=p.initialized?state[base+i*128]:0;
 for(uint t=0;t<p.seq;t++){
  uint qb=t*channels+kh*128+klane*K,kb=qb+p.key_heads*128;float decay=gates[(t*p.value_heads+h)*2],beta=gates[(t*p.value_heads+h)*2+1];float memory=0;
  #pragma unroll
  for(uint i=0;i<K;i++){s[i]*=decay;memory=fma(s[i],conv[kb+i],memory);}
  #pragma unroll
  for(uint step=16/C;step>0;step/=2)memory+=simd_shuffle_xor(memory,step*C);
  float delta=(conv[t*channels+2*p.key_heads*128+h*128+col]-memory)*beta,out=0;
  #pragma unroll
  for(uint i=0;i<K;i++){s[i]=fma(conv[kb+i],delta,s[i]);out=fma(s[i],conv[qb+i],out);}
  #pragma unroll
  for(uint step=16/C;step>0;step/=2)out+=simd_shuffle_xor(out,step*C);
  if(klane==0)output[(t*p.value_heads+h)*128+col]=out;
 }
 #pragma unroll
 for(uint i=0;i<K;i++)state[base+i*128]=s[i];
}
kernel void engine76_fma1(device float*s[[buffer(8)]],device const float*x[[buffer(9)]],device const float*g[[buffer(10)]],device float*y[[buffer(11)]],constant termite_qwen35_params&p[[buffer(15)]],uint gid[[thread_position_in_grid]],uint lane[[thread_index_in_simdgroup]]){engine76_body1<4>(s,x,g,y,p,gid,lane);}
