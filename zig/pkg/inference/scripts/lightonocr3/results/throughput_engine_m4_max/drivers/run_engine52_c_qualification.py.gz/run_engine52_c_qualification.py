from pathlib import Path
import subprocess,sys,json,datetime,os
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
flags=['--check-recurrent-resource-dedup','--check-wide-gate-up-full64','--check-wide-gate-up','--check-wide-gate-up-large64','--check-frame-metadata','--check-wide64','--check-planned-mpp','','--check-wide-mpp','--check-batch-attention','--check-prefill-pack-reuse','--check-prefill-pack-reuse-large','--check-decode-pack-reuse','--check-vision-pack-reuse']
records=[]
for flag in flags:
 name=flag.removeprefix('--check-') or 'full'
 logfile=Path('/private/tmp/ocr-engine52-c-'+name+'.txt');print('START',name,flush=True)
 with logfile.open('w')as f:r=subprocess.run([str((v/'engine52_conformance').resolve()),*([flag]if flag else[])],stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP='0',TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP='0',TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_RESOURCE_DEDUP='0'))
 print('DONE',name,r.returncode,flush=True);records.append(dict(check=flag or 'full',exit_code=r.returncode,log=str(logfile)))
 (out/'engine52_c_qualification_audit.json').write_text(json.dumps(dict(checks=records,status='pass'if len(records)==len(flags)and all(x['exit_code']==0 for x in records)else'running'if r.returncode==0 else'failed'),indent=2)+'\n')
 if r.returncode:sys.exit(r.returncode)
