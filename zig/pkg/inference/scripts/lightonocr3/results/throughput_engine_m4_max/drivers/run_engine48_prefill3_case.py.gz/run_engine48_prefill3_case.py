from pathlib import Path
import hashlib,json,os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
mode=sys.argv[1];assert mode in ['qualification','primary']
n=64 if mode=='qualification'else128
label=f'prefill3_c60_vf2_wide641_full640_r{n}_{mode}'
rp=out/f'engine48_4b_{label}/report.json';assert not rp.exists()
env=os.environ.copy()
env.update(OCR_REFERENCE_LABEL='_primary_reference20_r0_auto_c64_r128',OCR_PHYSICAL32='0',OCR_PHYSICAL64='1',
 OCR_CONCURRENCY='60',OCR_REQUESTS=str(n),OCR_WIDE='1',OCR_SCRATCH_GIB='10',OCR_BACKEND_GIB='17',OCR_KV_GIB='4',
 OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1',
 OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_VISION_BATCH='0',OCR_VISION_BATCH_ITEMS='1',OCR_PREFILL_BATCH='1',
 OCR_PREFILL_BATCH_ITEMS='3',OCR_PREFILL_WAIT_US='1000000',OCR_VISION_FRAME_BLOCKS='2',
 OCR_SINGLE_FRAME='1',OCR_STREAM_FIRST='0',OCR_GPU_GREEDY_STREAM='0',OCR_LOGICAL64='1',
 OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',
 OCR_ADMISSION_UNITS='512',OCR_DISABLE_64_ROW_TILE='0',OCR_DISABLE_WIDE_GATE_UP='0',
 OCR_WIDE64_GATE_UP='1',OCR_FULL64_GATE_UP='0',ANTFLY_FLORENCE_CPU_PREPROCESS='0')
print('START',label,flush=True)
with Path(f'/private/tmp/ocr-engine48-4b-{label}-driver.txt').open('w')as log:r=subprocess.run([sys.executable,str(v/'run_engine48_budget_policies_verify.py'),'4b:'+label],env=env,stdout=log,stderr=subprocess.STDOUT)
print('DONE',label,r.returncode,flush=True);assert r.returncode==0,r.returncode
d=json.loads(rp.read_text());rs=d['results'][0];s=rs['policy_rounds'][0]
assert rs['status']=='ok'and rs['serial_reference_parity']and rs['cross_runtime_content_parity']
assert s['completed']==n and not s['admission_pressures']
assert s['host_recurrent_bytes_total']==0 and s['single_frame_topology_mismatches']==0
assert any(x['items']==3 for x in s['prefill_batches'])
assert s['full64_gate_up_calls']==0 and s['wide_gate_up_calls']>0
audit=dict(status='pass',concurrency=60,prefill_batch_items=3,vision_frame_blocks=2,completed=n,pages_per_second=s['pages_per_second'],framed_runtime_totals=s['framed_runtime_totals'],process_cpu_ms=s['process_cpu_ms'],prefill_batches=s['prefill_batches'],prefill_host_scratch_peak_bytes=s['prefill_host_scratch_peak_bytes'],all_native_pages_equal_serial_reference=True,primary_throughput_eligible=mode=='primary',report=str(rp.relative_to(out)),report_sha256=hashlib.sha256(rp.read_bytes()).hexdigest())
(out/f'engine48_4b_prefill3_{mode}_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps(audit),flush=True)
