from pathlib import Path
import subprocess,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal'
assert 'ENGINE91 QUALIFICATION DONE'in Path('/private/tmp/ocr-engine91-qualification-parent.txt').read_text()
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine90_*','engine91_*'],check=True)
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
logs=[];drivers=[]
for tag in [90,91]:
 logs += [p for p in Path('/private/tmp').glob(f'ocr-engine{tag}-*.txt')if not p.name.startswith(('ocr-engine91-checkpoint','ocr-engine91-archive'))]
 drivers += [p for p in v.glob(f'*engine{tag}*')if p.is_file()and p.suffix in ['.py','.m','.metal','.inc','.json','.patch','.zig']]
ns['archive']('qualification',sorted(set(logs)),'logs_manifest.json')
ns['archive']('drivers',sorted(set(drivers)),'drivers_manifest.json')
print('Archived completed90/91 qualification and lifetime proof; completed model diagnostic included.',flush=True)
