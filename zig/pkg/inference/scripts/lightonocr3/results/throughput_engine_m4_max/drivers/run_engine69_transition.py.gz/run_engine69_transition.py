from pathlib import Path
import json,subprocess,sys,time
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');a=o/'engine68_prefill_stream49_4b_r128_audit.json'
while True:
 if a.exists() and json.loads(a.read_text())['status']=='pass':break
 p=Path('/private/tmp/ocr-engine68-prefill49-parent.txt')
 if p.exists() and 'Traceback' in p.read_text():raise RuntimeError('profiles failed; no source transition')
 time.sleep(5)
for key,script in [('prepare','prepare_engine69.py'),('qualification','run_engine69_qualification.py')]:
 print('START',key,flush=True)
 with Path('/private/tmp/ocr-engine69-'+key+'-parent.txt').open('w')as f:subprocess.run([sys.executable,str(v/script)],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',key,flush=True)
print('ENGINE69 TRANSITION DONE',flush=True)
