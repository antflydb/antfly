from pathlib import Path
import hashlib,json,difflib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';base=r/'zig/pkg/inference/src/backends/metal_kernels.m';original=base.read_text();assert hashlib.sha256(original.encode()).hexdigest()=='ab7db0fab1cab774c127bf2a32560a4879980a29b4405f19ac75f4d70012ef83';s=(v/'engine108_wide_core_kernels.m').read_text()
# New option is snapshotted with the other frame policy values and stays off.
needle='    TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL,';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_WIDE_RECURRENT,')
needle='    "TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL",';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    "TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE_RECURRENT",')
needle='    uint64_t lightonocr3_recurrent_parallel_dispatches;';assert s.count(needle)==1;s=s.replace(needle,needle+'''
    uint64_t lightonocr3_wide_recurrent_dispatches;
    uint64_t lightonocr3_wide_recurrent_max_rows;
    uint64_t lightonocr3_wide_recurrent_staged_bytes;''')
needle='int termite_metal_decode_runtime_qwen35_core_batch_begin(';assert s.count(needle)==1
s=s.replace(needle,'''// Keep the qualified narrow path unless a wide parallel core is available.
// Shared side-weight identity is checked separately at the prepared caller.
size_t termite_metal_decode_runtime_lighton_recurrent_group_rows(termite_metal_decode_runtime *runtime) {
    if (runtime == NULL || !runtime->qwen35_ocr_vector_loads_enabled || !runtime->lightonocr3_projections_enabled ||
        !termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_WIDE_RECURRENT) ||
        !termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL) ||
        termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_RECURRENT_PARALLEL) ||
        termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_DISABLE_QWEN35_FUSED_DECODE) ||
        runtime->lightonocr3_recurrent_parallel_pipeline == nil ||
        runtime->lightonocr3_recurrent_parallel_pipeline.threadExecutionWidth != 32 ||
        runtime->lightonocr3_recurrent_parallel_pipeline.maxTotalThreadsPerThreadgroup < 512) return 16;
    return 64;
}
void termite_metal_decode_runtime_lighton_wide_recurrent_stats(termite_metal_decode_runtime *runtime, uint64_t *out) {
    if (out == NULL) return;
    out[0] = runtime == NULL ? 0 : runtime->lightonocr3_wide_recurrent_dispatches;
    out[1] = runtime == NULL ? 0 : runtime->lightonocr3_wide_recurrent_max_rows;
    out[2] = runtime == NULL ? 0 : runtime->lightonocr3_wide_recurrent_staged_bytes;
}
'''+needle)
a=s.index(needle);b=s.index('void termite_metal_decode_runtime_qwen35_core_batch_abort(',a);part=s[a:b];needle2='rows < 2 || rows > 64 ||';assert needle2 in part;part=part.replace(needle2,needle2+'\n        (rows > 16 && !termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_WIDE_RECURRENT)) ||');s=s[:a]+part+s[b:]
a=s.index('static int termite_metal_lightonocr3_encode_recurrent_parallel(');b=s.index('int termite_metal_decode_runtime_qwen35_core_batch_end(',a);part=s[a:b]
needle2='    id<MTLComputePipelineState> pipeline =';assert part.count(needle2)==1;part=part.replace(needle2,'    if (!termite_metal_frame_env_enabled(runtime, TERMITE_METAL_FRAME_ENABLE_LIGHTONOCR3_WIDE_RECURRENT)) return 0;\n'+needle2)
needle2='    runtime->lightonocr3_recurrent_parallel_dispatches++;';assert part.count(needle2)==1;part=part.replace(needle2,needle2+'''
    runtime->lightonocr3_wide_recurrent_dispatches++;
    runtime->lightonocr3_wide_recurrent_max_rows = MAX(runtime->lightonocr3_wide_recurrent_max_rows, rows);
    if (staged.buffer != nil) runtime->lightonocr3_wide_recurrent_staged_bytes += rows * sizeof(table[0]);''');s=s[:a]+part+s[b:]
# Only prepared callers with truly shared immutable side weights collect64.
a=s.index('    for (size_t row = 0; row < rows; row++) {\n        // Keep the qualified sixteen-row recurrent argument table intact.');b=s.index('    LIGHTON_LINEAR(4,',a);part=s[a:b]
part=part.replace('''        // Keep the qualified sixteen-row recurrent argument table intact.
        // Matrix projections span the full cohort; histories remain disjoint.
''','').replace('row % 16 == 0','row % core_group_rows == 0').replace('(size_t)16','core_group_rows').replace('(row + 1) % 16 == 0','(row + 1) % core_group_rows == 0')
part='''    size_t core_group_rows = termite_metal_decode_runtime_lighton_recurrent_group_rows(runtime);
    for (size_t row = 1; core_group_rows > 16 && row < rows; row++)
        for (size_t weight = 3; weight < 7; weight++)
            if (states[row * 7 + weight] != states[weight] || state_offsets[row * 7 + weight] != state_offsets[weight])
                core_group_rows = 16;
'''+part;s=s[:a]+part+s[b:]
# C metadata is plain host storage; keep failure count within its bound.
s=s.replace('''            const size_t index=runtime->qwen35_core_batch_interval_count++;
            if(index>=64*15)return -11;''','''            const size_t index=runtime->qwen35_core_batch_interval_count;
            if(index>=64*15)return -11;
            runtime->qwen35_core_batch_interval_count++;''')
# Write a reviewable patch before modifying canonical inputs.
diff=''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/'+str(base.relative_to(r)),tofile='b/'+str(base.relative_to(r))));(v/'engine109_wide_runtime.patch').write_text(diff);(v/'engine109_wide_runtime_kernels.m').write_text(s)
print('Prepared canonical C replacement; not applied')
