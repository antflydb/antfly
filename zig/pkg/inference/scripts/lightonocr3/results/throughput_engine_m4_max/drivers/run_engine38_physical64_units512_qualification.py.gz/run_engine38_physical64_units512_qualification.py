from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

root = Path.cwd()
v = root / ".venv-lighton-vllm-metal"
p = root / "zig/pkg/inference/scripts/lightonocr3"
out = p / "results/throughput_engine_m4_max"
manifest = out / "engine38_build_manifest.json"
binary = json.loads(manifest.read_text())["binary_path"]
oracle = out / "vllm_08_primary_reference11_r0_auto_c32_r128/report.json"
images = [root / "zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png", p / "corpus/receipt.png", p / "corpus/shipping.png"]
env = os.environ.copy()
env.update(
    ANTFLY_LIGHTONOCR3_THROUGHPUT="1",
    ANTFLY_LIGHTONOCR3_CPU_PREPROCESS="1",
    ANTFLY_LIGHTONOCR3_VISION_FRAME_BLOCKS="4",
    ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS="0",
    ANTFLY_LIGHTONOCR3_SINGLE_FRAME="1",
    ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS="0",
    ANTFLY_LIGHTONOCR3_PREFILL_BATCH="0",
    ANTFLY_LIGHTONOCR3_VISION_BATCH="0",
    ANTFLY_LIGHTONOCR3_PREFILL_DECODE_STREAK="0",
    ANTFLY_LIGHTONOCR3_EXTENDED_EPOCH="1",
    ANTFLY_LIGHTONOCR3_COMPACT_KV="1",
)
records = []
for kind, concurrency, requests, pages in [("external64", 64, 64, 1), ("public32", 1, 1, 32), ("reject_public64", 1, 1, 64)]:
    dest = out / f"engine38_08_physical64_units512_qualification_{kind}"
    assert not (dest / "report.json").exists(), dest
    command = [
        sys.executable, str(p / "benchmark_concurrency.py"), "--native-test", binary,
        "--model", "lighton08=" + str(v / "ocr-models/lighton08"), "--images",
        *map(str, images), "--concurrency", str(concurrency), "--requests", str(requests),
        "--pages-per-request", str(pages), "--max-tokens", "256", "--modes", "batch",
        "--admission-units", "512", "--continuous", "--physical64", "--logical64", "--batch-rows", "64",
        "--batch-window", "64", "--batch-wait-us", "20000", "--memory-gib", "24",
        "--shared-memory-gib", "28", "--backend-memory-gib", "16", "--kv-memory-gib", "4",
        "--scratch-memory-gib", "8", "--timeout", "900", "--build-manifest", str(manifest),
        "--reference-report", str(oracle), "--output-dir", str(dest), "--weight-residency",
        "--frame-policy", "--weight-handles", "--trace-packed-core", "--require-packed-core",
        "--recurrent-parallel", "--prefill-attention-mpp", "--prefill-core-norm",
        "--policy-rounds", "engineepoch",
    ]
    command += ["--device-recurrent-state", "--share-decoder-scratch", "--ocr-encoder-scopes"]
    print("START", kind, flush=True)
    logfile = Path(f"/private/tmp/ocr-engine38-logical64-units512-{kind}-qualification.txt")
    with logfile.open("w") as stream:
        result = subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT)
    print("DONE", kind, result.returncode, flush=True)
    report_path = dest / "report.json"
    report = json.loads(report_path.read_text())
    r = report["results"][0]
    if kind == "reject_public64":
        assert result.returncode == 1 and r["exit_code"] == 1
        raw = (dest / r["log"]).read_text()
        assert "FAIL (ImageBatchTooLarge)" in raw, raw[-1500:]
        records.append(dict(kind=kind, expected_rejection="ImageBatchTooLarge", no_process_crash=True, primary_throughput_eligible=False, report=str(report_path.relative_to(out)), report_sha256=hashlib.sha256(report_path.read_bytes()).hexdigest()))
        (out / "engine38_physical64_units512_qualification_audit.json").write_text(json.dumps(dict(checks=records, status="pass"), indent=2) + "\n")
        print("QUALIFIED expected contract rejection", flush=True)
        continue
    assert result.returncode == 0
    sample = r["policy_rounds"][0]
    assert r["status"] == "ok" and r["serial_reference_parity"] and r["cross_runtime_content_parity"]
    assert sample["completed"] == requests * pages
    reference = json.loads(oracle.read_text())
    assert {x["image_index"]: x["text"] for x in r["references"]} == {x["image_index"]: x["text"] for x in reference["references"]}
    text = (dest / r["log"]).read_text()
    timed = text.split("OCR_POLICY round=0")[1]
    windows = [(int(a), int(b)) for a, b in re.findall(r"registered_window_peak=(\d+) physical_rows_limit=(\d+)", timed)]
    assert windows and all(a <= 64 and b == 64 for a, b in windows), windows
    assert max(a for a, b in windows) > (32 if kind == "external64" else 16), windows
    scopes = sum(map(int, re.findall(r"token_encoder_scope_steps=(\d+)", timed)))
    recurrent = [(int(a),int(b),int(c))for a,b,c in re.findall(r"device_recurrent_state=(\d+) recurrent_cache_pages=(\d+) host_recurrent_bytes_total=(\d+)",timed)]
    assert recurrent and all(a==1 and c==0 for a,b,c in recurrent) and sum(b for a,b,c in recurrent)==requests*pages,recurrent
    shared = [(int(a),int(b),int(c))for a,b,c in re.findall(r"shared_decoder_scratch=(\d+) shared_decoder_peak_bytes=(\d+) peak_segments=(\d+)",timed)]
    assert shared and all(a==1 and b>0 and c>0 for a,b,c in shared),shared
    assert timed.count("decoder_scratch_release_after_backend=1")==len(shared),shared
    encoder_stats=[(int(a),int(b))for a,b in re.findall(r"vision_encoder_scope_opens=(\d+) prefill_encoder_scope_opens=(\d+)",timed)]
    assert encoder_stats and all(a>0 and b>0 for a,b in encoder_stats),encoder_stats
    frames = [(int(a), int(b)) for a, b in re.findall(r"single_frame_steps=(\d+) single_frame_topology_mismatches=(\d+)", timed)]
    assert scopes > 0 and scopes == sum(a for a, b in frames) and all(b == 0 for a, b in frames)
    packed = list(map(int, re.findall(r"lightonocr3_packed_core: rows=(\d+)", text)))
    assert packed and (32 if kind == "external64" else 16) < max(packed) <= 64, packed
    records.append(dict(kind=kind, completed=requests * pages, full_fixture_string_identity=True,
                        registered_windows=windows, largest_physical_core_rows=max(packed),
                        token_encoder_scope_steps=scopes, single_frame_topology_mismatches=0, device_recurrent_state=True, host_recurrent_bytes_total=0,
                        report=str(report_path.relative_to(out)),
                        report_sha256=hashlib.sha256(report_path.read_bytes()).hexdigest()))
    (out / "engine38_physical64_units512_qualification_audit.json").write_text(json.dumps(dict(checks=records, status="running"), indent=2) + "\n")
    print("QUALIFIED", kind, windows, scopes, flush=True)
