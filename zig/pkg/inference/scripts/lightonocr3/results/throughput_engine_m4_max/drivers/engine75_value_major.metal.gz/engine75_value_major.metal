#include <metal_stdlib>
using namespace metal;
kernel void termite_lightonocr3_copy16(device const uint4 *x [[buffer(0)]], device uint4 *y [[buffer(1)]], constant uint &n [[buffer(2)]], uint i [[thread_position_in_grid]]) { if (i < n) y[i] = x[i]; }
struct CoreParams {
    uint seq, key_heads, value_heads, dim, kernel_size, initialized;
};
struct CoreRow {
    device float *buffers[15];
    CoreParams params;
};
kernel void engine75_value_major(constant CoreRow *rows [[buffer(0)]],
                                                   uint2 group [[threadgroup_position_in_grid]],
                                                   uint d [[thread_index_in_threadgroup]],
                                                   ushort lane [[thread_index_in_simdgroup]],
                                                   ushort simd [[simdgroup_index_in_threadgroup]]) {
    constant CoreRow &r = rows[group.y];
    constant CoreParams &p = r.params;
    uint h = group.x;
    device const float *mixed = r.buffers[0];
    device const float *weight = r.buffers[1];
    device const float *beta = r.buffers[2];
    device const float *a = r.buffers[3];
    device const float *alog = r.buffers[4];
    device const float *dt = r.buffers[5];
    device const float *history = r.buffers[6];
    device float *next = r.buffers[7];
    device float *state = r.buffers[8];
    device float *conv = r.buffers[9];
    device float *gates = r.buffers[10];
    device float *core = r.buffers[11];
    device const float *z = r.buffers[12];
    device const float *norm = r.buffers[13];
    device float *output = r.buffers[14];

    threadgroup float q[128], k[128], values[128], reduction[64], scales[4];
    const uint TM = 8, SG = 128 / TM;
    uint ratio = p.value_heads / p.key_heads, kh = h / ratio;
    if (d < 128) {
        uint indices[3] = {kh * 128 + d, (p.key_heads + kh) * 128 + d, 2 * p.key_heads * 128 + h * 128 + d};
        float v[3];
        for (uint j = 0; j < 3; j++) {
            uint c = indices[j];
            float sum = 0;
            for (uint t = 0; t < 4; t++) {
                float x = t == 3 ? mixed[c] : (p.initialized ? history[c * 4 + t + 1] : 0.0f);
                sum += x * weight[c * 4 + t];
                if (j == 2 || h % ratio == 0)
                    next[c * 4 + t] = x;
            }
            v[j] = sum / (1.0f + exp(-sum));
        }
        float qs = simd_sum(v[0] * v[0]), ks = simd_sum(v[1] * v[1]);
        if (lane == 0) {
            reduction[simd] = qs;
            reduction[4 + simd] = ks;
        }
        q[d] = v[0];
        k[d] = v[1];
        values[d] = v[2];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (d == 0) {
        float qs = 0, ks = 0;
        for (uint s = 0; s < 4; s++) {
            qs += reduction[s];
            ks += reduction[4 + s];
        }
        scales[0] = 1.0f / sqrt(qs + 1e-6f) / sqrt(128.0f);
        scales[1] = 1.0f / sqrt(ks + 1e-6f);
        float x = a[h] + dt[h], sp = x > 20.0f ? x : (x < -20.0f ? exp(x) : log(1.0f + exp(x)));
        scales[2] = exp(-exp(alog[h]) * sp);
        scales[3] = 1.0f / (1.0f + exp(-beta[h]));
        gates[h * 2] = scales[2];
        gates[h * 2 + 1] = scales[3];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (d < 128) {
        q[d] *= scales[0];
        k[d] *= scales[1];
        if (h % ratio == 0) {
            conv[kh * 128 + d] = q[d];
            conv[(p.key_heads + kh) * 128 + d] = k[d];
        }
        conv[2 * p.key_heads * 128 + h * 128 + d] = values[d];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    uint col = simd * TM;
    float4 memories[TM / 4], previous[4][TM / 4], outputs[TM / 4];
#pragma unroll
    for (uint t = 0; t < TM / 4; t++)
        memories[t] = 0;
#pragma unroll
    for (uint t = 0; t < TM / 4; t++) {
#pragma unroll
        for (uint c = 0; c < 4; c++) {
            float4 raw = p.initialized ? *((device const float4 *)(state + h*128*128 + (col+t*4+c)*128 + uint(lane)*4)) : float4(0);
#pragma unroll
            for (uint i = 0; i < 4; i++) previous[i][t][c] = raw[i] * scales[2];
        }
#pragma unroll
        for (uint i = 0; i < 4; i++) memories[t] += previous[i][t] * k[uint(lane)*4+i];
    }
#pragma unroll
    for (uint t = 0; t < TM / 4; t++) {
        float4 memory = float4(simd_sum(memories[t].x), simd_sum(memories[t].y), simd_sum(memories[t].z),
                               simd_sum(memories[t].w));
        float4 delta = (float4(values[col + t * 4], values[col + t * 4 + 1], values[col + t * 4 + 2],
                               values[col + t * 4 + 3]) -
                        memory) *
                       scales[3];
        outputs[t] = 0;
#pragma unroll
        for (uint i = 0; i < 4; i++) {
            uint key = lane * 4 + i;
            float4 v = previous[i][t] + k[key] * delta;
            previous[i][t] = v;
            outputs[t] += v * q[key];
        }
#pragma unroll
        for (uint c = 0; c < 4; c++) {
            float4 value = float4(previous[0][t][c], previous[1][t][c], previous[2][t][c], previous[3][t][c]);
            *((device float4 *)(state + h*128*128 + (col+t*4+c)*128 + uint(lane)*4)) = value;
        }
        outputs[t] = float4(simd_sum(outputs[t].x), simd_sum(outputs[t].y), simd_sum(outputs[t].z),
                            simd_sum(outputs[t].w));
    }
    if (lane == 0) {
        float sum = 0;
#pragma unroll
        for (uint t = 0; t < TM / 4; t++) {
            float4 v = outputs[t];
            sum += dot(v, v);
            *((device float4 *)(core + h * 128 + col + t * 4)) = v;
        }
        reduction[simd] = sum;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (d == 0) {
        float sum = 0;
        for (uint s = 0; s < SG; s++)
            sum += reduction[s];
        scales[0] = 1.0f / sqrt(sum / 128.0f + 1e-6f);
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (lane == 0) {
#pragma unroll
        for (uint t = 0; t < TM / 4; t++) {
            float4 gate = *((device const float4 *)(z + h * 128 + col + t * 4)),
                   n = *((device const float4 *)(norm + col + t * 4));
            *((device float4 *)(output + h * 128 + col + t * 4)) =
                outputs[t] * scales[0] * n * (gate / (1.0f + exp(-gate)));
        }
    }
}
