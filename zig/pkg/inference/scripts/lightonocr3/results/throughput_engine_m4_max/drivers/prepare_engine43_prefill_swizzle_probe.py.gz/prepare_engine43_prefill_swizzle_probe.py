from pathlib import Path
import json,re,collections,statistics
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
raw=Path('/private/tmp/ocr-engine43-prefill64x64-probe.txt').read_text()
pat=r'PREFILL64X64 rows=(\d+) in=(\d+) out=(\d+) on=(\d+) leg=(\d+) gpu_us=([\d.]+) max_abs=([\deE.+-]+) cpu_error=([\deE.+-]+)'
records=[dict(zip(['rows','hidden','output','on','leg','gpu_us','max_abs','cpu_error'],[int(x)for x in m[:5]]+[float(x)for x in m[5:]]))for m in re.findall(pat,raw)]
assert len(records)==40 and 'FAIL'not in raw
groups=collections.defaultdict(list)
for x in records:groups[(x['rows'],x['hidden'],x['output'])].append(x)
comparisons=[]
for (r,h,n),xs in groups.items():
 off=[x['gpu_us']for x in xs if not x['on']];on=[x['gpu_us']for x in xs if x['on']]
 comparisons.append(dict(rows=r,hidden=h,output=n,candidate_to_baseline_ratio=statistics.mean(on)/statistics.mean(off),both_candidate_legs_faster_than_both_controls=max(on)<min(off)))
(o/'engine43_prefill64x64_probe_audit.json').write_text(json.dumps(dict(status='pass',scope='Numerical identity; no consistent speed win. Not promoted.',records=records,comparisons=comparisons),indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('qualification',[Path('/private/tmp/ocr-engine43-prefill64x64-probe.txt')],'logs_manifest.json')
s=(v/'engine43_prefill_tile_probe_verify_kernels.m').read_text()
needle='    bool prefill_row64_probe;';assert s.count(needle)==1
s=s.replace(needle,needle+'\n    id<MTLComputePipelineState> prefill_swizzle_probe_pipeline;')
a=s.index('        "kernel void termite_lightonocr3_mpp_bfloat_32_64(');b=s.index('        "kernel void termite_lightonocr3_mpp_bfloat_64_32(',a)
part=s[a:b].replace('mpp_bfloat_32_64','mpp_bfloat_32_64_swizzle_probe')
line=part.index('\n')+1
part=part[:line]+r'        " const uint mtiles=(p.rows+31u)/32u; group=uint2(group.x/mtiles,group.x%mtiles);\n"'+'\n'+part[line:]
s=s[:b]+part+s[b:]
needle='''            runtime->lightonocr3_mpp_bf16_n32_pipeline =
                termite_metal_make_pipeline(device, tensor_library, @"termite_lightonocr3_mpp_bfloat_64_32");'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''
            runtime->prefill_swizzle_probe_pipeline =
                termite_metal_make_pipeline(device, tensor_library, @"termite_lightonocr3_mpp_bfloat_32_64_swizzle_probe");''')
needle='    runtime->lightonocr3_mpp_bf16_n32_pipeline = nil;';assert s.count(needle)==1
s=s.replace(needle,needle+'\n    runtime->prefill_swizzle_probe_pipeline = nil;')
a=s.index('static int termite_metal_try_lightonocr3_mpp(');b=s.index('\n}\n',a)+2
part=s[a:b].replace('const bool n32 = probe_prefill64 ||','const bool n32 =')
needle='''    id<MTLComputePipelineState> pipeline =
        segment4 ?''';assert part.count(needle)==1
part=part.replace(needle,'''    if (probe_prefill64 && (!bf16 || runtime->prefill_swizzle_probe_pipeline == nil ||
        runtime->prefill_swizzle_probe_pipeline.maxTotalThreadsPerThreadgroup < 128 ||
        runtime->prefill_swizzle_probe_pipeline.threadExecutionWidth != 32 ||
        runtime->prefill_swizzle_probe_pipeline.staticThreadgroupMemoryLength > runtime->device.maxThreadgroupMemoryLength)) return 0;
    id<MTLComputePipelineState> pipeline =
        probe_prefill64 ? runtime->prefill_swizzle_probe_pipeline : segment4 ?''')
needle='''    [enc dispatchThreadgroups:MTLSizeMake((out_dim + tn - 1) / tn, (rows + tm - 1) / tm, 1)
        threadsPerThreadgroup:MTLSizeMake((small_tile || segment4) ? 32 : 128, 1, 1)];'''
assert part.count(needle)==1
part=part.replace(needle,'''    [enc dispatchThreadgroups:(probe_prefill64
        ? MTLSizeMake(((out_dim + tn - 1) / tn) * ((rows + tm - 1) / tm), 1, 1)
        : MTLSizeMake((out_dim + tn - 1) / tn, (rows + tm - 1) / tm, 1))
        threadsPerThreadgroup:MTLSizeMake((small_tile || segment4) ? 32 : 128, 1, 1)];''')
s=s[:a]+part+s[b:]
(v/'engine43_prefill_swizzle_probe_kernels.m').write_text(s)
s=(v/'engine43_prefill_tile_probe_verify_checks.m').read_text().replace('engine43_prefill_tile_probe_verify_kernels.m','engine43_prefill_swizzle_probe_kernels.m')
(v/'engine43_prefill_swizzle_probe_checks.m').write_text(s)
s=(v/'engine43_prefill_tile_probe_verify.m').read_text().replace('engine43_prefill_tile_probe_verify_checks.m','engine43_prefill_swizzle_probe_checks.m').replace('PREFILL_ROW64','PREFILL_SWIZZLE')
(v/'engine43_prefill_swizzle_probe.m').write_text(s)
s=(v/'build_engine43_prefill_tile_probe_verify.py').read_text().replace('engine43_prefill_tile_probe_verify','engine43_prefill_swizzle_probe').replace('ocr-engine43-prefill-tile-probe-verify-build.txt','ocr-engine43-prefill-swizzle-probe-build.txt')
(v/'build_engine43_prefill_swizzle_probe.py').write_text(s)
ns['archive']('drivers',[v/n for n in ['prepare_engine43_prefill_swizzle_probe.py','engine43_prefill_swizzle_probe_kernels.m','engine43_prefill_swizzle_probe_checks.m','engine43_prefill_swizzle_probe.m','build_engine43_prefill_swizzle_probe.py']],'drivers_manifest.json')
with(v/'engine_progress.md').open('a')as f:f.write("\n43M64N64PROBEALLPASS93667exit0 40legsmaxabs0butNOconsistentwin:gateup432ratio1.054/554.894/6621.223,down432.824/554.842/662.885butALLoverlapexceptgate128tiny. Fullaudit/rawarchivedNOTpromoted. NEXTIGNOREDPROBEprepared+archivedSWIZZLE usingEXACToldBF16M32N64SG4 math but1DgridmappingMtilefast: shadergroup=uint2(linear/mtiles,linear%mtiles), hostdispatch1D(mtiles*ntiles). HypothesiscacheweightreusewhenKxNlarge vsoldcolumnfast2D. No cacheFACTclaimed, actualmatrixprecision/accumulationidentical; fullGPU/CPU/canary/producer/counterABBA40same10cases. SourceCcopyaddsPSOshaderdecl/init/cleanup+probeONLYselection notproduction. Filenamesengine43_prefill_swizzle_probe{_kernels.m,_checks.m,.m}/build_engine43_prefill_swizzle_probe.py/prepare_engine43_prefill_swizzle_probe.py. NOTcompiledyet, nextrunbuildthenGPU. ActualruntimeSTILL42frozen19; failed4BdecodeMPPdefaultmustrollbackNEXTqualifiedrevision (large1.0282vs1.0877control); 08on+2%unpairedonly. makegcENDunrunPRstaleHEAD1289,Florencepatchunapplied.\n")
