from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

root = Path.cwd()
v = root / '.venv-lighton-vllm-metal'
scripts = root / 'zig/pkg/inference/scripts/lightonocr3'
out = scripts / 'results/throughput_engine_m4_max'
images = [root / 'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png', scripts / 'corpus/receipt.png', scripts / 'corpus/shipping.png']
models = sys.argv[1:] or ['4b', '08']
assert all(m in ['4b', '08'] for m in models)
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

record = dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              scope='Fresh vLLM C64 automatic-cache controls in both orders against the fastest completed engine40 R128 candidate. C64 was the winning concurrency in prior C16/C32/C48/C64 searches (paired16/18). Shared machine uncontrolled; no own compilation or sampling during timings.',
              comparisons=[], selected_profiles={}, status='running')
audit = out / ('paired21_' + '_'.join(models) + '_comparison_audit.json')
assert not audit.exists()

def save():
    audit.write_text(json.dumps(record, indent=2) + '\n')

def reference(model, round_index):
    label = f'_primary_reference21_r{round_index}_auto_c64_r128'
    dest = out / ('vllm_' + model + label)
    assert not (dest / 'report.json').exists()
    cmd = [sys.executable, str(scripts / 'benchmark_vllm_metal.py'), '--python', sys.executable,
           '--model-dir', str(v / 'ocr-models' / ('lighton' + model)), '--images', *map(str, images),
           '--concurrency', '64', '--requests', '128', '--max-tokens', '256', '--startup-timeout', '600',
           '--output-dir', str(dest)]
    print('START VLLM', model, round_index, flush=True)
    with Path(f'/private/tmp/ocr-engine40-vllm-{model}-paired21-r{round_index}.txt').open('w') as log:
        subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=True)
    p = dest / 'report.json'
    d = json.loads(p.read_text())
    assert d['status'] == 'ok' and d['kv_cache_block_override'] is None and d['results'][0]['serial_reference_parity']
    print('DONE VLLM', model, round_index, d['results'][0]['pages_per_second'], flush=True)
    return label, d, p

def native(model, round_index, oracle):
    profile = record['selected_profiles'][model]
    c, vf, vision, prefill = profile['settings']
    old_tile, bf16 = int(model == '08'), 0
    label = f'paired21_r{round_index}_physical64_c{c}_vf{vf}_v{vision}_p{prefill}_r128'
    env = os.environ.copy()
    env.update(OCR_REFERENCE_LABEL=oracle, OCR_PHYSICAL32='0', OCR_PHYSICAL64='1',
               OCR_CONCURRENCY=str(c), OCR_REQUESTS='128', OCR_WIDE='1', OCR_KV_GIB='4',
               OCR_BACKEND_GIB='17' if model == '4b' else '16', OCR_SCRATCH_GIB='10' if model == '4b' else '8',
               OCR_CPU_PREPROCESS='1', OCR_PREFILL_DECODE_STREAK='0', OCR_POLICIES='engineepoch',
               OCR_SHARED_CORE='1' if model == '4b' else '0', OCR_BF16_PREFILL='1' if model == '4b' else '0',
               OCR_BF16=str(bf16), OCR_DISABLE_64_ROW_TILE=str(old_tile), OCR_VISION_BATCH=str(int(vision>1)),
               OCR_VISION_BATCH_ITEMS=str(vision), OCR_VISION_WAIT_US='20000',
               OCR_PREFILL_BATCH=str(int(prefill>1)), OCR_PREFILL_BATCH_ITEMS=str(prefill), OCR_PREFILL_WAIT_US='100000',
               OCR_VISION_FRAME_BLOCKS=str(vf), OCR_SINGLE_FRAME='1', OCR_STREAM_FIRST='0',
               OCR_LOGICAL64='1', OCR_SHARED_DECODER_SCRATCH='1', OCR_DEVICE_RECURRENT_STATE='1',
               OCR_ENCODER_SCOPES='1', OCR_ADMISSION_UNITS='512')
    dest = out / f'engine40_{model}_{label}'
    assert not (dest / 'report.json').exists()
    print('START NATIVE', model, round_index, profile['settings'], flush=True)
    subprocess.run([sys.executable, str(v / 'run_engine40_budget_policies_verify.py'), model + ':' + label], env=env, check=True)
    p = dest / 'report.json'
    d = json.loads(p.read_text())
    assert not d['own_cpu_compile_overlap']
    return d, p

def compare(model, round_index, n, ref, order):
    nd, np = n
    label, rd, rp = ref
    r = nd['results'][0]
    sample = r['policy_rounds'][0]
    assert r['status'] == 'ok' and r['serial_reference_parity'] and r['cross_runtime_content_parity']
    assert sample['completed'] == 128 and not sample['admission_pressures']
    assert {x['image_index']: x['text'] for x in r['references']} == {x['image_index']: x['text'] for x in rd['references']}
    a, b = sample['pages_per_second'], rd['results'][0]['pages_per_second']
    item = dict(model=model, round=round_index, order=order, native_report=str(np.relative_to(out)),
                native_report_sha256=sha(np), reference_report=str(rp.relative_to(out)), reference_report_sha256=sha(rp),
                native_pages_per_second=a, reference_pages_per_second=b, native_to_vllm_ratio=a / b,
                full_fixture_string_identity=True, all_128_native_pages_equal_serial_reference=True,
                primary_throughput_eligible=True)
    record['comparisons'].append(item)
    save()
    print('COMPARISON', json.dumps(item), flush=True)

for model in models:
    source_audit = out / f'engine40_{model}_batch_comparison_audit.json'
    candidate_audit = json.loads(source_audit.read_text())
    assert candidate_audit['status'] == 'pass'
    best = max(candidate_audit['candidates'], key=lambda x: x['pages_per_second'])
    p = out / best['report']
    assert sha(p) == best['report_sha256']
    settings = [best['concurrency'], best['vision_frame_blocks'], best['vision_batch_items'], best['prefill_batch_items']]
    record['selected_profiles'][model] = dict(settings=settings, report=best['report'], report_sha256=sha(p), candidate_pages_per_second=best['pages_per_second'])

save()
for model in models:
    ref0 = reference(model, 0)
    compare(model, 0, native(model, 0, ref0[0]), ref0, 'fresh vLLM C64 then native')
    n1 = native(model, 1, ref0[0])
    ref1 = reference(model, 1)
    compare(model, 1, n1, ref1, 'native then fresh vLLM C64')
ratios = [x['native_to_vllm_ratio'] for x in record['comparisons']]
record['status'] = 'native_behind' if any(x <= 1 for x in ratios) else 'clear_repeated_win' if all(x >= 1.05 for x in ratios) else 'small_repeated_lead'
save()
print('FINAL', record['status'], flush=True)
