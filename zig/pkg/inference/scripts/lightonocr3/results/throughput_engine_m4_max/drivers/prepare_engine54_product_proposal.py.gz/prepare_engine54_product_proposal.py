from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');dest=v/'engine54-product-proposal';dest.mkdir(exist_ok=True)
paths=['zig/pkg/inference/src/backends/metal_kernels.m','zig/pkg/inference/src/backends/metal_runtime.zig','zig/pkg/inference/src/ops/metal_compute.zig','zig/pkg/inference/src/server/server.zig','zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py']
frozen=json.loads((v/'engine53-freeze.json').read_text())
for p,h in frozen.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
c=Path(paths[0]).read_text()
c=c.replace('    uint64_t lightonocr3_full64_gate_up_calls;','    uint64_t lightonocr3_full64_gate_up_calls;\n    uint64_t lighton_batch_argmax_calls;\n    uint64_t lighton_batch_argmax_rows;')
c=c.replace('    id<MTLComputePipelineState> argmax_logits_reduce_pipeline;','    id<MTLComputePipelineState> argmax_logits_reduce_pipeline;\n    id<MTLComputePipelineState> lighton_batch_argmax_partials_pipeline;\n    id<MTLComputePipelineState> lighton_batch_argmax_reduce_pipeline;')
msl=(v/'engine54_argmax_verify2.metal').read_text();msl=msl[msl.index('kernel void engine54_partials'):].replace('engine54_partials','termite_lighton_batch_argmax_partials').replace('engine54_reduce','termite_lighton_batch_argmax_reduce')
strings=''.join('           '+json.dumps(line+'\n')+'\n'for line in msl.splitlines())
needle='           "inline void termite_whisper_lse_push';assert c.count(needle)==1;c=c.replace(needle,strings+needle)
needle='        runtime->argmax_logits_reduce_pipeline = termite_metal_make_pipeline(device, library, @"termite_argmax_logits_reduce");'
assert c.count(needle)==1
c=c.replace(needle,needle+'\n        runtime->lighton_batch_argmax_partials_pipeline = termite_metal_make_pipeline(device, library, @"termite_lighton_batch_argmax_partials");\n        runtime->lighton_batch_argmax_reduce_pipeline = termite_metal_make_pipeline(device, library, @"termite_lighton_batch_argmax_reduce");')
needle='    runtime->argmax_logits_reduce_pipeline = nil;';assert c.count(needle)==1
c=c.replace(needle,needle+'\n    runtime->lighton_batch_argmax_partials_pipeline = nil;\n    runtime->lighton_batch_argmax_reduce_pipeline = nil;')
needle='int termite_metal_decode_runtime_argmax_from_logits_rows_suppress_device(';assert c.count(needle)==1
c=c.replace(needle,(v/'engine54_batch_argmax_helper.inc').read_text()+needle)
a=c.index('        int encode_rc = 0;',c.index(needle));b=c.index('        if (encode_on_active_frame)',a)
old=c[a:b]
assert 'for (size_t row = 0;'in old
elig='''        const bool batch_argmax = rows >= 2 && rows <= 64 && out_dim == 248320u &&
            runtime->lightonocr3_projections_enabled && termite_metal_qualified_m4_device_default() != 0 &&
            termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_BATCH_ARGMAX")) &&
            runtime->lighton_batch_argmax_partials_pipeline != nil &&
            runtime->lighton_batch_argmax_reduce_pipeline != nil &&
            runtime->lighton_batch_argmax_partials_pipeline.maxTotalThreadsPerThreadgroup >= 256u;
        int encode_rc = 0;
        if (batch_argmax) {
            encode_rc = termite_metal_encode_lighton_batch_argmax(runtime, encoder, logits_buffer, logits_offset,
                rows, out_dim, suppress_buffer, suppress_count, -13);
        } else {
'''
c=c[:a]+elig+'\n'.join('    '+line for line in old.splitlines()[1:])+'\n        }\n'+c[b:]
c+='''
void termite_metal_decode_runtime_lighton_batch_argmax_stats(termite_metal_decode_runtime *runtime, uint64_t *out) {
    if (out == NULL) return;
    out[0] = runtime != NULL ? runtime->lighton_batch_argmax_calls : 0;
    out[1] = runtime != NULL ? runtime->lighton_batch_argmax_rows : 0;
}
'''
rt=Path(paths[1]).read_text()+'\npub extern fn termite_metal_decode_runtime_lighton_batch_argmax_stats(runtime: ?*RawMetalDecodeRuntime, out: *[2]u64) void;\n'
mc=Path(paths[2]).read_text()
needle='    lighton_full64_gate_up_start: u64 = 0,';assert needle in mc;mc=mc.replace(needle,needle+'\n    lighton_batch_argmax_start: [2]u64 = @splat(0),')
needle='        self.lighton_full64_gate_up_start = metal_runtime_mod.termite_metal_decode_runtime_lighton_full64_gate_up_calls(raw);';assert needle in mc;mc=mc.replace(needle,needle+'\n        metal_runtime_mod.termite_metal_decode_runtime_lighton_batch_argmax_stats(raw, &self.lighton_batch_argmax_start);')
needle='    pub fn lightOnStandaloneWideHeads('
func='''    pub fn lightOnBatchedArgmaxStats(cb: *const ops.ComputeBackend) [2]u64 {
        if (cb.kind() != .metal or cb.vtable.decoderRuntimeArgmaxRowsSuppress != &decoderRuntimeArgmaxRowsSuppressOp) return @splat(0);
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        var stats: [2]u64 = @splat(0);
        metal_runtime_mod.termite_metal_decode_runtime_lighton_batch_argmax_stats(self.provider_impl.raw_decode_runtime, &stats);
        for (&stats, self.lighton_batch_argmax_start) |*value, baseline| value.* -|= baseline;
        return stats;
    }

'''
assert needle in mc;mc=mc.replace(needle,func+needle)
server=Path(paths[3]).read_text();needle='                    const full64_gate_up = '
a=server.index(needle);b=server.index('\n',server.index('std.debug.print("LIGHTONOCR3 full64_gate_up_calls=',a))+1
server=server[:b]+'''                    const batch_argmax = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnBatchedArgmaxStats(&cb) else @as([2]u64, @splat(0));
                    std.debug.print("LIGHTONOCR3 batch_argmax_calls={d}\\nLIGHTONOCR3 batch_argmax_rows={d}\\n", .{ batch_argmax[0], batch_argmax[1] });
'''+server[b:]
bench=Path(paths[4]).read_text();needle='    env["ANTFLY_LIGHTONOCR3_STREAM_CHUNKS"]'
a=bench.index(needle);bench=bench[:a]+'''    env["TERMITE_METAL_ENABLE_LIGHTONOCR3_BATCH_ARGMAX"] = "1" if args.batch_argmax else "0"
'''+bench[a:]
bench=bench.replace('                        "full64_gate_up_calls",','                        "full64_gate_up_calls",\n                        "batch_argmax_calls",\n                        "batch_argmax_rows",')
needle='    args = parser.parse_args()';assert bench.count(needle)==1
bench=bench.replace(needle,'''    parser.add_argument("--batch-argmax", action="store_true", help="Use two dispatches for qualified M4 LightOnOCR3 batched token selection")
'''+needle)
bench=bench.replace('        "stream_chunk_layers": args.stream_chunk_layers,','        "stream_chunk_layers": args.stream_chunk_layers,\n        "batch_argmax": args.batch_argmax,')
for p,data in zip(paths,[c,rt,mc,server,bench]):
 target=dest/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(data)
(v/'engine54_product_proposal.json').write_text(json.dumps(dict(status='proposal_only_not_applied',files={p:hashlib.sha256((dest/p).read_bytes()).hexdigest()for p in paths},base_engine53_files=frozen),indent=2)+'\n')
print('prepared',len(paths),'files; actual source remains engine53')
