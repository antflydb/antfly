from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine43_budget_policies.py').read_text().replace('engine43','engine44')
needle=" greedy_stream=os.environ.get('OCR_GPU_GREEDY_STREAM','0')=='1'"
assert s.count(needle)==1;s=s.replace(needle," wide64_gate_up=os.environ.get('OCR_WIDE64_GATE_UP','0')=='1'\n if wide64_gate_up:cmd+=['--wide64-gate-up']\n"+needle)
s=s.replace("report['gpu_greedy_stream']=greedy_stream;","report['wide64_gate_up']=wide64_gate_up;report['gpu_greedy_stream']=greedy_stream;")
needle="    if model=='4b' or wide_gate_disabled or bf16:assert sample['wide_gate_up_calls']==0,sample"
assert s.count(needle)==1;s=s.replace(needle,"    if (model=='4b' and not wide64_gate_up) or wide_gate_disabled or bf16:assert sample['wide_gate_up_calls']==0,sample")
(v/'run_engine44_budget_policies.py').write_text(s)
(v/'engine44_benchmark_concurrency.py').write_bytes(Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
for name in ['run_engine43_functional.py','engine43_verify_preset_only_test.py','engine43_verify_preset_physical32_test.py','engine43_verify_default_gpu_test.py']:
 s=(v/name).read_text().replace('engine43','engine44')
 s=s.replace('env=os.environ.copy()',"""env=os.environ.copy()
env['TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP']='0'
env['ANTFLY_FLORENCE_CPU_PREPROCESS']='0'""")
 (v/name.replace('engine43','engine44')).write_text(s)
