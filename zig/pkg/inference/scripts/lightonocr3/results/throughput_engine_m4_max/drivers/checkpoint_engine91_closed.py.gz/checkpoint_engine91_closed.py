from pathlib import Path
import hashlib,json,subprocess,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();f=json.loads((v/'engine91-freeze.json').read_text());assert all(sha(r/p)==h for p,h in f.items())
assert json.loads((o/'engine91_precision_memory_screen74_audit.json').read_text())['status']=='hold_no_clear_bf16_screen_win'
assert json.loads((o/'engine92_prefill_geometry_audit.json').read_text())['status']=='prototype_pass'
assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='feat/lightonocr3-08b'
for script in ['archive_completed_engine90_91.py','archive_completed_engine92.py']:
 subprocess.run([sys.executable,str(v/script)],check=True)
paths=['zig/lib/image/src/processing.zig','zig/pkg/inference/src/backends/metal_runtime.zig','zig/pkg/inference/src/backends/metal_kernels.m','zig/pkg/inference/src/server/server.zig','zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py','zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m']
others=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z','--',str(o.relative_to(r))]).decode().split('\0');changed=subprocess.check_output(['git','diff','--name-only','-z','--',str(o.relative_to(r))]).decode().split('\0');paths+=sorted({p for p in others+changed if p})
subprocess.run(['git','add','--',*paths],check=True);subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','Fix Metal runtime resource retention and accelerate OCR preprocessing'],check=True)
assert all(sha(r/p)==h for p,h in f.items()),'Commit hooks changed frozen inputs.'
subprocess.run(['git','push','origin','HEAD'],check=True)
print('CHECKPOINT91 CLOSED PUSHED',subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),flush=True)
