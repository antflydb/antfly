from pathlib import Path
import struct,subprocess,json,sys,bisect
root=Path.cwd();p=root/'zig/.zig-cache/o'/sys.argv[1];obj=(p/'test_zcu.o').read_bytes();binary=(p/'test').read_bytes()
def text_section(data):
 ncmds=struct.unpack_from('<I',data,16)[0];offset=32
 for _ in range(ncmds):
  cmd,size=struct.unpack_from('<II',data,offset)
  if cmd==0x19:
   nsects=struct.unpack_from('<I',data,offset+64)[0]
   for i in range(nsects):
    fields=struct.unpack_from('<16s16sQQIIIIIIII',data,offset+72+80*i)
    if fields[0].rstrip(b'\0')==b'__text':return fields[2:]
  offset+=size
 raise ValueError('no text')
a=text_section(obj);b=text_section(binary)
def symbols(path):
 vals=[]
 for row in subprocess.check_output(['nm','-n',str(path)],text=True).splitlines():
  parts=row.split(None,2)
  if len(parts)==3 and parts[1]in ['t','T']:vals.append((int(parts[0],16),parts[2]))
 return vals
osym=symbols(p/'test_zcu.o');bsym=symbols(p/'test');delta=dict((name,addr)for addr,name in bsym)['_main']-dict((name,addr)for addr,name in osym)['_main'];relocs={struct.unpack_from('<i',obj,a[4]+8*i)[0]for i in range(a[5])}
checks=[]
for address,name in osym:
 if not name.startswith('l_'):continue
 start_o=a[2]+address-a[0];start_b=b[2]+address+delta-b[0]
 if start_b<0 or start_b+32>len(binary):continue
 kept=[i for i in range(0,32,4)if address+i not in relocs];matched=all(obj[start_o+i:start_o+i+4]==binary[start_b+i:start_b+i+4]for i in kept)
 checks.append(dict(name=name,object_address=address,binary_address=address+delta,matched=matched,checked_words=len(kept)))
result=dict(binary_sha256=__import__('hashlib').sha256(binary).hexdigest(),text_delta=delta,checked=len(checks),matches=sum(x['matched']for x in checks),symbols=checks)
(v:=root/'.venv-lighton-vllm-metal'/('symbols_'+sys.argv[1]+'.json')).write_text(json.dumps(result))
print(json.dumps({k:x for k,x in result.items()if k!='symbols'}));print('table',v)
