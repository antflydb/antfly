from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal');source=(v/'ocr-models/lighton4b').resolve();target=v/'ocr-models/lighton4b-aligned64'
records=[]
for original in source.iterdir():
 if original.name=='model.safetensors':continue
 child=target/original.name
 if original.is_dir():
  assert original.name=='.cache',original
  if child.is_symlink():
   assert child.resolve()==original.resolve()
   child.unlink()
  continue
 assert original.is_file()
 data=original.read_bytes();digest=hashlib.sha256(data).hexdigest()
 if child.is_symlink():
  assert child.resolve()==original.resolve()
  child.unlink()
 if child.exists():assert child.read_bytes()==data
 else:child.write_bytes(data)
 assert hashlib.sha256(child.read_bytes()).hexdigest()==digest
 records.append(dict(file=child.name,sha256=digest,bytes=len(data)))
assert not any(x.is_symlink()for x in target.iterdir())
o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
(o/'engine45_4b_aligned_checkpoint_materialization_manifest.json').write_text(json.dumps(dict(status='pass',metadata_files=records,metadata_identical_to_source=True,all_metadata_within_checkpoint_root=True,excluded_download_cache=True,source_unchanged=True),indent=2)+'\n')
print('Materialized and verified',len(records),'unchanged metadata files; excluded download-cache symlink')
