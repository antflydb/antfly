from pathlib import Path
import subprocess
v=Path('.venv-lighton-vllm-metal');p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text();method=(v/'engine31_planned_mpp_check.inc').read_text();method=subprocess.check_output(['/opt/homebrew/opt/llvm/bin/clang-format','--assume-filename=check.m'],input=method,text=True);a=s.index('\nint main(');s=s[:a]+'\n'+method+s[a:]
anchor='''        if (argc == 2 && (strcmp(argv[1], "--check-decode-pack-reuse")''';assert anchor in s
block='''if (argc == 2 && strcmp(argv[1], "--check-planned-mpp") == 0) {
 const size_t shapes[][3]={{17,1024,4096},{24,2560,4096},{32,2560,8192},{32,2560,9216},{32,9216,2560},{128,768,3072},{2304,1024,4096},{432,2560,4096},{2648,9216,2560},{32,2560,248320}};
 for(size_t pool=0;pool<2;pool++)for(size_t bf16=0;bf16<2;bf16++)for(size_t i=0;i<sizeof(shapes)/sizeof(shapes[0]);i++) { @autoreleasepool {
  int rc=planned_mpp_check(r,shapes[i][0],shapes[i][1],shapes[i][2],bf16!=0,pool!=0);
  if(rc){fprintf(stderr,"PLANNED_MPP_FAIL rows=%zu in=%zu out=%zu bf16=%zu pool=%zu rc=%d\\n",shapes[i][0],shapes[i][1],shapes[i][2],bf16,pool,rc);return 135;}
 }}
 termite_metal_decode_runtime_destroy(r);return 0;
}
''';block=subprocess.check_output(['/opt/homebrew/opt/llvm/bin/clang-format','--assume-filename=check.m'],input=block,text=True);block=''.join('        '+line if line.strip()else line for line in block.splitlines(keepends=True));s=s.replace(anchor,block+anchor,1);p.write_text(s);print('31 planned MPP checker:40 shape/precision/pool cases, four modes each')
