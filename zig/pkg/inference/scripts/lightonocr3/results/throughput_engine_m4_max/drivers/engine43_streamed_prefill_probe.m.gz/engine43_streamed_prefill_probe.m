#define main production_checks_main
#include "engine43_streamed_prefill_probe_checks.m"
#undef main
#define STREAM_LAYERS 32

static int stream_frame(termite_metal_decode_runtime*r,size_t variant,size_t rows,size_t in,size_t out,
 id<MTLBuffer>source,id<MTLBuffer>zero,id<MTLBuffer>x,id<MTLBuffer> __strong y[STREAM_LAYERS],double*us){
 r->prefill_row64_probe=variant!=0;r->prefill_probe_variant=(uint32_t)variant;
 uint64_t before=r->frame_gpu_nanos,calls=r->prefill_row64_probe_calls,packs=r->lighton_prefill_pack_calls;
 if(termite_metal_decode_runtime_begin_frame(r)||
    termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_PREFILL)||
    termite_metal_decode_runtime_apply_add_device(r,(__bridge void*)source,16,(__bridge void*)zero,0,rows*in,(__bridge void*)x,16)||
    termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_FFN,TERMITE_METAL_COMPUTE_REGION_FFN))return 1;
 for(size_t layer=0;layer<STREAM_LAYERS;layer++)
  if(termite_metal_decode_runtime_apply_linear_multi_row_device(r,layer,(__bridge void*)x,16,rows,in,out,(__bridge void*)y[layer],16))return 2;
 if(termite_metal_decode_runtime_end_planned_compute_scope(r)||
    termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r))return 3;
 if(r->prefill_row64_probe_calls-calls!=(variant?STREAM_LAYERS:0))return 4;
 if(r->lighton_prefill_pack_calls-packs!=STREAM_LAYERS)return 5;
 *us=(r->frame_gpu_nanos-before)/1000.0;return 0;
}
static int stream_case(termite_metal_decode_runtime*r,size_t rows,size_t in,size_t out){
 @autoreleasepool{
 const size_t n=rows*out;
 id<MTLBuffer>source=[r->device newBufferWithLength:(rows*in+8)*4 options:MTLResourceStorageModeShared],
 zero=[r->device newBufferWithLength:rows*in*4 options:MTLResourceStorageModeShared],
 x=[r->device newBufferWithLength:(rows*in+8)*4 options:MTLResourceStorageModePrivate];
 id<MTLBuffer>y[STREAM_LAYERS];
 float*gold[STREAM_LAYERS]={0};double cpu[STREAM_LAYERS][4];
 uint16_t*w=malloc(in*out*2);float*b=malloc(out*4);
 if(!source||!zero||!x||!w||!b)return 6;
 memset(zero.contents,0,zero.length);
 float*input=(float*)source.contents+4;
 for(size_t i=0;i<rows*in;i++)input[i]=sinf(i*.013f)*.7f;
 uint32_t rng=123;
 for(size_t layer=0;layer<STREAM_LAYERS;layer++){
  y[layer]=[r->device newBufferWithLength:(n+12)*4 options:MTLResourceStorageModeShared];
  gold[layer]=malloc(n*4);if(!y[layer]||!gold[layer])return 7;
  for(size_t i=0;i<in*out;i++){rng=rng*1664525u+1013904223u;w[i]=round_bf16(((int)(rng>>16)-32768)*.000001f);}
  for(size_t i=0;i<out;i++)b[i]=cosf(i*.019f+layer)*.2f;
  for(size_t c=0;c<4;c++){
   size_t row=c/2?rows-1:0,col=c%2?out-1:0;double sum=b[col];
   for(size_t k=0;k<in;k++)sum+=(double)expand_bf16(round_bf16(input[row*in+k]))*expand_bf16(w[col*in+k]);
   cpu[layer][c]=sum;
  }
  if(termite_metal_decode_runtime_prepare_linear_bf16(r,layer,(uint8_t*)w,in*out*2,b,in,out))return 8;
 }
 free(w);free(b);
 double us;for(size_t warm=0;warm<2;warm++)if(stream_frame(r,0,rows,in,out,source,zero,x,y,&us))return 9;
 for(size_t layer=0;layer<STREAM_LAYERS;layer++)memcpy(gold[layer],(float*)y[layer].contents+4,n*4);
 for(size_t variant=1;variant<=2;variant++)for(size_t leg=0;leg<4;leg++){
  size_t mode=(leg==1||leg==2)?variant:0;
  for(size_t layer=0;layer<STREAM_LAYERS;layer++){
   uint32_t*raw=y[layer].contents;
   for(size_t i=0;i<4;i++)raw[i]=0xdeadbeef;
   for(size_t i=n+4;i<n+12;i++)raw[i]=0xcafebabe;
  }
  for(size_t warm=0;warm<2;warm++)if(stream_frame(r,mode,rows,in,out,source,zero,x,y,&us))return 10;
  double total=0;
  for(size_t trial=0;trial<8;trial++){
   if(stream_frame(r,mode,rows,in,out,source,zero,x,y,&us))return 11;total+=us;
  }
  float worst=0;double corner_error=0;
  for(size_t layer=0;layer<STREAM_LAYERS;layer++){
   float*got=(float*)y[layer].contents+4;uint32_t*raw=y[layer].contents;
   for(size_t i=0;i<n;i++){if(!isfinite(got[i]))return 12;worst=fmaxf(worst,fabsf(got[i]-gold[layer][i]));}
   for(size_t c=0;c<4;c++){size_t row=c/2?rows-1:0,col=c%2?out-1:0;corner_error=fmax(corner_error,fabs(cpu[layer][c]-got[row*out+col]));}
   for(size_t i=0;i<4;i++)if(raw[i]!=0xdeadbeef)return 13;
   for(size_t i=n+4;i<n+12;i++)if(raw[i]!=0xcafebabe)return 14;
  }
  if(worst>2e-4||corner_error>2e-4)return 15;
  fprintf(stderr,"STREAM_PREFILL rows=%zu in=%zu out=%zu layers=%d variant=%zu on=%d leg=%zu frame_gpu_us=%.3f projection_gpu_us=%.3f max_abs=%g cpu_error=%g\n",
   rows,in,out,STREAM_LAYERS,variant,mode!=0,leg,total/8,total/8/STREAM_LAYERS,worst,corner_error);
 }
 for(size_t layer=0;layer<STREAM_LAYERS;layer++)free(gold[layer]);
 return 0;
 }
}
int main(void){@autoreleasepool{
 setenv("TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS","1",1);
 unsetenv("TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS");
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 if(termite_metal_decode_runtime_set_lighton_activation_pool(r,8*1024*1024))return 2;
 const size_t rows[]={554,432,662};
 for(size_t i=0;i<3;i++)for(size_t shape=0;shape<2;shape++){
  int rc=stream_case(r,rows[i],shape?9216:2560,shape?2560:9216);
  if(rc){fprintf(stderr,"STREAM_PREFILL_FAIL rows=%zu shape=%zu rc=%d\n",rows[i],shape,rc);return 20+rc;}
 }
 termite_metal_decode_runtime_destroy(r);
}return 0;}
