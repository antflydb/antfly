from pathlib import Path
import subprocess,sys,os
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_engine_m4_max';label='_primary_reference9_loadcheck_auto_c32_r128';dest=out/('vllm_4b'+label);assert not(dest/'report.json').exists()
cmd=[sys.executable,str(p/'benchmark_vllm_metal.py'),'--python',sys.executable,'--model-dir',str(v/'ocr-models/lighton4b'),'--images',str(r/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(p/'corpus/receipt.png'),str(p/'corpus/shipping.png'),'--concurrency','32','--requests','128','--max-tokens','256','--startup-timeout','600','--output-dir',str(dest)]
print('START VLLM C32 load check',flush=True)
with open('/private/tmp/ocr-engine-vllm-4b-primary9-loadcheck-auto-c32-r128.txt','w')as f:res=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
print('DONE VLLM',res.returncode,flush=True)
if res.returncode:sys.exit(res.returncode)
env=os.environ.copy();env.update(OCR_REFERENCE_LABEL=label,OCR_PHYSICAL32='1',OCR_CONCURRENCY='32',OCR_REQUESTS='128',OCR_WIDE='1',OCR_SCRATCH_GIB='8',OCR_STREAM_FIRST='0',OCR_SINGLE_FRAME='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1',OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_VISION_BATCH='0')
print('START native original prefill path',flush=True)
res=subprocess.run([sys.executable,str(v/'run_engine27_no_prefill_policies.py'),'4b:loadcheck_no_prefill_f32_c32_r128_0'],env=env)
print('DONE native original',res.returncode,flush=True);sys.exit(res.returncode)
