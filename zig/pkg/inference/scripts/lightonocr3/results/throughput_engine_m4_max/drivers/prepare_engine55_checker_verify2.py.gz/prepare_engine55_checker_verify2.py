from pathlib import Path
import hashlib
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine55_budget_policies.py').read_text()
needle=" with open('/private/tmp/ocr-engine55-'+model+'-'+label+'.txt','w')as log:res=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)"
assert needle in s
s=s.replace(needle,""" if os.environ.get('OCR_VERIFY_SAVED_RUN','0')=='1':
  from types import SimpleNamespace
  assert (target/'report.json').exists()
  res=SimpleNamespace(returncode=0)
 else:
"""+' '+needle)
needle="report['driver_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();"
assert needle in s
s=s.replace(needle,"report['driver_sha256']=os.environ.get('OCR_ORIGINAL_EXECUTION_DRIVER_SHA',hashlib.sha256(Path(__file__).read_bytes()).hexdigest());report['verification_driver_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();report['verified_existing_run']=os.environ.get('OCR_VERIFY_SAVED_RUN','0')=='1';")
s=s.replace("(sample['wide_mpp_projections']>0)==(wide and not disable_mpp)","(sample['wide_mpp_projections']>0)==(wide and not disable_mpp and int(c)>8)")
compile(s,'budget_verify2','exec');(v/'run_engine55_budget_policies_verify2.py').write_text(s)
s=(v/'run_engine55_stage_smoke.py').read_text().replace('run_engine55_budget_policies.py','run_engine55_budget_policies_verify2.py').replace("p=o/f'engine55_08_{label}';assert not p.exists()", "p=o/f'engine55_08_{label}';assert p.exists()\nenv['OCR_VERIFY_SAVED_RUN']='1';env['OCR_ORIGINAL_EXECUTION_DRIVER_SHA']='"+hashlib.sha256((v/'run_engine55_budget_policies.py').read_bytes()).hexdigest()+"'")
s=s.replace("'/private/tmp/ocr-engine55-stage-smoke.txt'","'/private/tmp/ocr-engine55-stage-smoke-verify2.txt'")
(v/'run_engine55_verify_existing_smoke.py').write_text(s)
for old in ['run_engine55_vision4_profile.py','run_engine55_large_chunk_profiles.py','run_engine55_chunk_cases.py']:
 (v/old.replace('.py','_verify2.py')).write_text((v/old).read_text().replace('run_engine55_budget_policies.py','run_engine55_budget_policies_verify2.py'))
for old in ['run_engine55_stage_profiles.py','run_engine55_primary_controls.py']:
 (v/old.replace('.py','_verify2.py')).write_text((v/old).read_text().replace('run_engine55_vision4_profile.py','run_engine55_vision4_profile_verify2.py'))
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
paths=list(v.glob('*engine55*verify2*.py'))+[v/'run_engine55_verify_existing_smoke.py']
for p in paths:compile(p.read_text(),str(p),'exec')
ns['archive']('drivers',paths,'drivers_manifest.json')
ns['archive']('qualification',[Path('/private/tmp/ocr-engine55-stage-smoke.txt'),Path('/private/tmp/ocr-engine55-stage-smoke-driver.txt'),Path('/private/tmp/ocr-engine55-finalize-qualify-parent.txt')],'logs_manifest.json')
print('prepared corrected checker; saved runtime is not rerun')
