from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.ocr-shared-frame';p=r/'zig/pkg/inference/src/pipelines/generation.zig';s=(v/'engine152_generation_proposal.zig').read_text()
s=s.replace('        const shared_frame = self.packed_shared_frame and gpu_choices;', '''        const shared_frame = self.packed_shared_frame and gpu_choices;
        const trace_frame = platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3");
        const before_submits = if (trace_frame) cb.debugTimingSnapshot().provider.decoder_runtime_frame_submits else 0;''')
s=s.replace('''        // them in one bounded producer frame rather than submitting and
        // waiting once per page. The decoder still owns its established frame.''','''        // them in one bounded producer frame. The qualified shared-frame path
        // lends that frame to the model and closes it after the F32 head.''')
s=s.replace('''        // The model has closed its frame. One gather selects every page's
        // final row without issuing an owned blit/submit/wait per page.''','''        // One gather selects every page's final row. In the shared-frame path
        // the model borrows the producer frame, which is still active here.''')
s=s.replace('''        // A separate decode frame preserves the established F32 head inputs,
        // even when the preceding mixed model frame permits BF16 projections.''','''        // Decode regime preserves the established F32 head inputs. The shared
        // path transfers ownership instead of opening a separate head frame.''')
s=s.replace('''        if (platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3")) std.debug.print("LIGHTONOCR3 packed_shared_frame={d}\\n", .{@intFromBool(shared_frame)});''','''        if (trace_frame) std.debug.print("LIGHTONOCR3 packed_shared_frame={d} packed_forward_submissions={d}\\n", .{ @intFromBool(shared_frame), cb.debugTimingSnapshot().provider.decoder_runtime_frame_submits -| before_submits });''')
p.write_text(s)
p=r/'zig/pkg/inference/src/server/server.zig';s=p.read_text();needle='            prepared_prefill_chunk_rows: u16 = 0,';assert s.count(needle)==1;s=s.replace(needle,needle+'\n            packed_shared_frame: bool = false,')
needle='''                return features;
            }
            fn visionRetainedBlocks''';assert s.count(needle)==1;s=s.replace(needle,'''                features.packed_shared_frame = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_PACKED_SHARED_FRAME") and
                    features.packedSharedFrameEligible(cfg) and
                    !platform.env.getenvBool("TERMITE_QWEN3VL_PROFILE") and
                    platform.env.getenv("ANTFLY_QWEN3VL_QUALIFICATION_TRACE_LAYER") == null and
                    !platform.env.getenvBool("TERMITE_METAL_ENABLE_CONCURRENT_PLANNED_DISPATCH");
                return features;
            }
            fn packedSharedFrameEligible(features: @This(), cfg: gpt_model_mod.Config) bool {
                return features.packed_mixed and features.single_frame and
                    features.shared_decoder_scratch and cfg.qwen35_device_only_state and
                    cfg.hasQwen35VisionArchitectureContract() and
                    features.prefill_stream_layers == 0 and features.stream_first_layers == 0 and
                    !features.prefill_activation_pool and !features.gpu_greedy_stream;
            }
            fn visionRetainedBlocks''')
needle='                .prepared_qwen_prefill_chunk_rows = ctx.features.prepared_prefill_chunk_rows,';assert s.count(needle)==1;s=s.replace(needle,needle+'\n                .packed_shared_frame = ctx.features.packed_shared_frame,')
needle='            .prepared_qwen_prefill_chunk_rows = ctx.features.prepared_prefill_chunk_rows,';# matches nested now also! use exactline
lines=s.splitlines(); hits=0
for i,x in enumerate(lines):
 if x==needle: lines.insert(i+1,'            .packed_shared_frame = ctx.features.packed_shared_frame,');hits+=1
assert hits==1;s='\n'.join(lines)+'\n'
s+='''
test "LightOnOCR3 packed shared frame excludes split and retained-prefill lifetimes" {
    const Features = Node.LightOnStreamContext.ExecutionFeatures;
    const cfg = gpt_model_mod.Config{ .family = .qwen3_5, .hidden_size = 2560, .vocab_size = 248320, .num_hidden_layers = 32, .qwen35_has_linear_attention = true, .qwen35_full_attention_interval = 4, .qwen35_linear_num_key_heads = 16, .qwen35_linear_num_value_heads = 32, .qwen35_linear_key_head_dim = 128, .qwen35_linear_value_head_dim = 128, .qwen35_linear_conv_kernel_dim = 4, .qwen35_device_only_state = true };
    const eligible = Features{ .packed_mixed = true, .single_frame = true, .shared_decoder_scratch = true };
    try std.testing.expect(eligible.packedSharedFrameEligible(cfg));
    var changed = eligible;
    changed.prefill_stream_layers = 1;
    try std.testing.expect(!changed.packedSharedFrameEligible(cfg));
    changed = eligible;
    changed.stream_first_layers = 1;
    try std.testing.expect(!changed.packedSharedFrameEligible(cfg));
    changed = eligible;
    changed.prefill_activation_pool = true;
    try std.testing.expect(!changed.packedSharedFrameEligible(cfg));
    changed = eligible;
    changed.gpu_greedy_stream = true;
    try std.testing.expect(!changed.packedSharedFrameEligible(cfg));
    changed = eligible;
    changed.shared_decoder_scratch = false;
    try std.testing.expect(!changed.packedSharedFrameEligible(cfg));
    changed = eligible;
    changed.single_frame = false;
    try std.testing.expect(!changed.packedSharedFrameEligible(cfg));
    var host_state = cfg;
    host_state.qwen35_device_only_state = false;
    try std.testing.expect(!eligible.packedSharedFrameEligible(host_state));
    try std.testing.expect(!eligible.packedSharedFrameEligible(.{}));
    changed = eligible;
    changed.packed_shared_frame = true;
    try std.testing.expect(!std.meta.eql(eligible, changed));
    try std.testing.expectEqualDeep(eligible.auxiliaryAmounts(), changed.auxiliaryAmounts());
}
''';p.write_text(s)
print('174 shared-frame candidate integrated in isolated worktree only')
