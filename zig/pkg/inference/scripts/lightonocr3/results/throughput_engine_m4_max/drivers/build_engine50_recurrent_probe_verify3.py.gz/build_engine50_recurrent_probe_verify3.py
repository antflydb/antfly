from pathlib import Path
import hashlib,json,os,subprocess
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
plan=json.loads((out/'engine50_recurrent_probe_preparation.json').read_text())
for p,h in plan['inputs'].items():assert sha(p)==h,p
assert sha('zig/pkg/inference/src/backends/metal_kernels.m')==plan['base_c_sha256']
inputs=list(plan['inputs'])+[str(v/'engine50_recurrent_probe_verify3.m')]+[str(Path('zig/pkg/inference/src/backends')/n)for n in ['metal_buffer_observation.h','metal_mtp_head.h','metal_mtp_head_impl.h']]
binary=v/'engine50_recurrent_probe_verify3';assert not binary.exists()
cmd=['clang','-O3','-fobjc-arc','-I','zig/pkg/inference/src/backends',str(v/'engine50_recurrent_probe_verify3.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(binary)]
with Path('/private/tmp/ocr-engine50-recurrent-probe-build-verify3.txt').open('w')as log:r=subprocess.run(cmd,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')),stdout=log,stderr=subprocess.STDOUT)
record=dict(command=cmd,exit_code=r.returncode,inputs={p:sha(p)for p in inputs})
if r.returncode==0:record.update(binary=str(binary),binary_sha256=sha(binary))
(out/'engine50_recurrent_probe_build_verify3_manifest.json').write_text(json.dumps(record,indent=2)+'\n')
assert r.returncode==0,r.returncode
print('BUILD PASS',flush=True)
