from pathlib import Path
import subprocess,hashlib,json
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');m=json.loads((o/'engine56_proposal_c_build_manifest.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(m['binary'])==m['binary_sha256'];assert all(sha(p)==h for p,h in m['input_sha256'].items())
checks=[]
for flag in ['--check-vision-workspace-cache','--check-large-vision-pack-reuse']:
 p=Path('/private/tmp/ocr-engine56-proposal-'+flag.removeprefix('--check-')+'.txt');assert not p.exists();print('START',flag,flush=True)
 with p.open('w')as log:r=subprocess.run([str(Path(m['binary']).resolve()),flag],stdout=log,stderr=subprocess.STDOUT)
 checks.append(dict(flag=flag,exit_code=r.returncode,log=str(p),log_sha256=sha(p)));print('DONE',flag,r.returncode,flush=True)
 (o/'engine56_proposal_c_checks_audit.json').write_text(json.dumps(dict(status='pass'if len(checks)==2 and all(x['exit_code']==0 for x in checks)else'failed'if r.returncode else'running',checks=checks,build_manifest_sha256=sha(o/'engine56_proposal_c_build_manifest.json')),indent=2)+'\n')
 ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns);ns['archive']('qualification',[p],'logs_manifest.json')
 assert r.returncode==0,(flag,r.returncode)
print('both new C suites PASS',flush=True)
