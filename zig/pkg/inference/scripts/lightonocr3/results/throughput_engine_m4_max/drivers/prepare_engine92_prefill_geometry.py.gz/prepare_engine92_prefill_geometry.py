from pathlib import Path
import hashlib,json,re
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=(r/'zig/pkg/inference/src/backends/metal_kernels.m').read_text();needle='typedef struct termite_metal_decode_runtime {';assert s.count(needle)==1
s=s.replace(needle,'static NSUInteger engine92_recurrent_width, engine92_norm_width;\nstatic uint64_t engine92_columns_calls;\n'+needle)
needle='if (stage == 3 && pipelines[stage] == runtime->qwen35_recurrent_columns4_pipeline) width = 32;';assert s.count(needle)==1
s=s.replace(needle,'''if (stage == 3 && pipelines[stage] == runtime->qwen35_recurrent_columns4_pipeline) {
                ++engine92_columns_calls;
                width = engine92_recurrent_width ? engine92_recurrent_width : 32;
            }
            if (parallel_norm && (stage == 2 || stage == 4) && engine92_norm_width) width = engine92_norm_width;
            if (width > pipelines[stage].maxTotalThreadsPerThreadgroup || width % 32 != 0) return -92;''')
p=v/'engine92_geometry_kernels.m';assert not p.exists();p.write_text(s)
s=(r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine92_geometry_kernels.m"')
a=s.index('static int prefill_core_check(');b=s.index('\nstatic int compute_copy_check',a)
old=(v/'engine76_probe_checks.m').read_text();x=old.index('static int prefill_core_check(');y=old.index('\nstatic int compute_copy_check',x);helper=old[x:y]
helper=helper.replace('r->qwen35_recurrent_columns4_pipeline = variant == 0 ? engine76_base : engine76_candidate;','engine92_recurrent_width = variant && engine92_kind != 2 ? engine92_width : 0;\n            engine92_norm_width = variant && engine92_kind != 1 ? engine92_width : 0;')
helper=helper.replace('r->engine76_columns_calls','engine92_columns_calls').replace('engine76_variant','engine92_kind')
helper=helper.replace('"{\\"candidate\\":%u,','"{\\"width\\":%u,\\"kind\\":%u,').replace('engine92_kind, seq, vh, initialized, trial, variant','engine92_width, engine92_kind, seq, vh, initialized, trial, variant')
helper=helper.replace('for (size_t i = 0; i < counts[j]; i++) {\n                        if (!isfinite(got[i])','if (memcmp(gold, got, counts[j]*sizeof(float)) != 0) return 92;\n                    for (size_t i = 0; i < counts[j]; i++) {\n                        if (!isfinite(got[i])')
s=s[:a]+helper+s[b:];s=s.replace('static uint16_t round_bf16(', 'static unsigned engine92_kind,engine92_width;\nstatic uint16_t round_bf16(',1)
p=v/'engine92_geometry_checks.m';assert not p.exists();p.write_text(s)
p=v/'engine92_geometry_probe.m';assert not p.exists();p.write_text('''#define main engine92_unused_main
#include "engine92_geometry_checks.m"
#undef main
int main(int argc,char**argv){@autoreleasepool{
 if(argc!=3)return 1;engine92_kind=(unsigned)strtoul(argv[1],NULL,10);engine92_width=(unsigned)strtoul(argv[2],NULL,10);
 if(engine92_kind<1||engine92_kind>3||engine92_width<32||engine92_width>512||engine92_width%32)return 2;
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 3;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 unsetenv("TERMITE_METAL_DISABLE_QWEN35_PREFILL_COLUMNS");setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY","1",1);
 if((engine92_kind!=2&&engine92_width>r->qwen35_recurrent_columns4_pipeline.maxTotalThreadsPerThreadgroup)||(engine92_kind!=1&&(engine92_width>r->lightonocr3_prefill_prepare_pipeline.maxTotalThreadsPerThreadgroup||engine92_width>r->lightonocr3_prefill_norm_pipeline.maxTotalThreadsPerThreadgroup))){termite_metal_decode_runtime_destroy(r);return 77;}
 const size_t lengths[]={128,432,554,662,2048};
 for(size_t h=16;h<=32;h+=16)for(size_t i=0;i<5;i++)for(size_t initialized=0;initialized<2;initialized++)if(prefill_core_check(r,lengths[i],h,initialized,true))return 6;
 fprintf(stderr,"GEOMETRY92 EXACT FULL OUTPUT/STATE/CANARY PASS kind=%u width=%u\\n",engine92_kind,engine92_width);termite_metal_decode_runtime_destroy(r);return 0;
}}
''')
inputs={str(p.relative_to(r)):sha(p)for p in [v/'engine92_geometry_kernels.m',v/'engine92_geometry_checks.m',v/'engine92_geometry_probe.m']}
(v/'engine92_geometry_preparation.json').write_text(json.dumps(dict(status='prepared_only',scope='Change only dispatch threadgroup size for existing prefill C4 recurrence and SIMD normalization; shader functions byte-identical. All full output/state bits and canaries checked over alternating30-pair trials. No production changes or model throughput claim.',input_sha256=inputs,production_c_sha256=sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')),indent=2)+'\n')
print('Prepared private prefill geometry experiment; frozen production inputs unchanged.')
