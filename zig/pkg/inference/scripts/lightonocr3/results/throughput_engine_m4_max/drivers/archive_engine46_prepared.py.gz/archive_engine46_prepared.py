from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
ns={}
s=(v/'archive_engine10_evidence.py').read_text()
exec(s[:s.index("archive('qualification'")],ns)
paths=[p for p in v.glob('*engine46*') if p.is_file()]
paths += list((v/'engine46_source_snapshot').rglob('*.zig'))
ns['archive']('drivers',paths,'drivers_manifest.json')
print('archived',len(paths))
