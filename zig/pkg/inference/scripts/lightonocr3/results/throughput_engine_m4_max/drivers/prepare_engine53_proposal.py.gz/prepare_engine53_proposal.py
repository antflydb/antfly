from pathlib import Path
import hashlib,json,re
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');proposal=v/'engine53-proposal';proposal.mkdir(exist_ok=True)
freeze=json.loads((v/'engine52-freeze.json').read_text())
for p,h in freeze.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
edits={}
# Discard the non-winning host declaration experiment, retaining all evidence.
p=Path('zig/pkg/inference/src/backends/metal_kernels.m')
s=(v/'engine48_c_canonical_from_probe50.m').read_text()
assert hashlib.sha256(s.encode()).hexdigest()==json.loads((v/'engine48-freeze.json').read_text())[str(p)]
edits[p]=s
p=Path('zig/pkg/inference/src/backends/metal_runtime.zig');s=p.read_text()
s=s.replace('pub extern fn termite_metal_decode_runtime_lighton_resource_declaration_stats(runtime: ?*RawMetalDecodeRuntime, out: *[4]u64) void;\n','')
assert hashlib.sha256(s.encode()).hexdigest()==json.loads((v/'engine48-freeze.json').read_text())[str(p)]
edits[p]=s
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text()
s=s.replace('    lighton_resource_declaration_start: [4]u64 = @splat(0),\n','')
s=s.replace('        metal_runtime_mod.termite_metal_decode_runtime_lighton_resource_declaration_stats(raw, &self.lighton_resource_declaration_start);\n','')
a=s.index('    pub fn lightOnResourceDeclarationStats(');b=s.index('    pub fn lightOnFull64GateUpCalls(',a);s=s[:a]+s[b:]
assert hashlib.sha256(s.encode()).hexdigest()==json.loads((v/'engine48-freeze.json').read_text())[str(p)]
s=s.replace('    lighton_gpu_greedy_stream: bool = false,','''    lighton_gpu_greedy_stream: bool = false,
    lighton_stream_chunks: bool = false,
    lighton_stream_expected_frames: u64 = 1,
    lighton_stream_frame_stats: [2]u64 = @splat(0),''')
needle='        self.lighton_gpu_greedy_stream_stats = @splat(0);';assert s.count(needle)==1
s=s.replace(needle,needle+'\n        self.lighton_stream_frame_stats = @splat(0);\n        self.lighton_stream_expected_frames = 1;')
needle='    pub fn lightOnHasSubmittedFrame(';idx=s.index(needle)
s=s[:idx]+'''    pub fn setLightOnStreamChunks(cb: *const ops.ComputeBackend, enabled: bool) !void {
        if (!lightOnGpuGreedyStreamEnabled(cb)) {
            if (enabled) return error.UnsupportedGpuGreedyStream;
            return;
        }
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        self.lighton_stream_chunks = enabled;
    }

    pub fn lightOnStreamChunksEnabled(cb: *const ops.ComputeBackend) bool {
        if (!lightOnGpuGreedyStreamEnabled(cb)) return false;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return self.lighton_stream_chunks;
    }

    pub fn setLightOnExpectedStreamFrames(cb: *const ops.ComputeBackend, frames: u64) void {
        if (!lightOnGpuGreedyStreamEnabled(cb)) return;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        self.lighton_stream_expected_frames = frames;
    }

    /// Multi-frame steps and total submits; legacy two-frame count stays exact.
    pub fn lightOnStreamFrameStats(cb: *const ops.ComputeBackend) [2]u64 {
        if (!lightOnGpuGreedyStreamEnabled(cb)) return @splat(0);
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return self.lighton_stream_frame_stats;
    }

'''+s[idx:]
a=s.index('        self.lighton_gpu_greedy_stream_stats[0] += 1;',s.index('    pub fn noteLightOnGpuGreedyStream('));b=s.index('\n    }',a)
s=s[:a]+'''        recordLightOnStreamTopology(&self.lighton_gpu_greedy_stream_stats, &self.lighton_stream_frame_stats, self.lighton_stream_expected_frames, submits, argmaxes);'''+s[b:]
s+='\n'+(v/'engine53_stream_topology_helpers.inc').read_text();edits[p]=s
p=Path('zig/pkg/inference/src/architectures/gpt.zig');s=p.read_text()
needle='    // At most one submitted prefix and one active suffix exist. Drain the';assert needle in s
s=s.replace(needle,'''    const stream_chunks = if (comptime build_options.enable_metal) metal_compute_mod.MetalCompute.lightOnStreamChunksEnabled(cb) else false;
    if (comptime build_options.enable_metal) metal_compute_mod.MetalCompute.setLightOnExpectedStreamFrames(cb, @intCast(lightOnStreamFrameCount(config.num_hidden_layers, stream_first_layers, stream_chunks)));
    // At most one submitted prefix and one active suffix exist. Drain the''')
needle='''        if (stream_first_layers != 0 and layer + 1 == stream_first_layers) {
            try cb.checkExecutionControl();
            try cb.decoderRuntimeSubmitFrame();'''
assert needle in s
s=s.replace(needle,'''        if (lightOnStreamBoundary(layer + 1, config.num_hidden_layers, stream_first_layers, stream_chunks)) {
            try cb.checkExecutionControl();
            // Finish the prior submitted group before promoting this active
            // group. Only the existing two storage banks can be in flight.
            try cb.decoderRuntimeWaitSubmittedFrame();
            try cb.decoderRuntimeSubmitFrame();''')
idx=s.index('pub const DenseQwen3PrefillOptions')
s=s[:idx]+(v/'engine53_gpt_stream_helpers.inc').read_text()+'\n'+s[idx:];edits[p]=s
p=Path('zig/pkg/inference/src/pipelines/generation.zig');s=p.read_text()
needle='                        const before_frames = self.cb.debugTimingSnapshot().provider.decoder_runtime_frame_submits;'
assert s.count(needle)==1
s=s.replace(needle,'                        M.setLightOnExpectedStreamFrames(&self.cb, 1);\n'+needle);edits[p]=s
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text()
s=re.sub(r'                    const declarations: \[4\]u64 = .*?\n                    std.debug.print\("LIGHTONOCR3 recurrent_resource_calls=.*?\n','',s)
assert hashlib.sha256(s.encode()).hexdigest()==json.loads((v/'engine48-freeze.json').read_text())[str(p)]
s=s.replace('            gpu_greedy_stream: bool = false,','            gpu_greedy_stream: bool = false,\n            stream_chunks: bool = false,')
needle='                features.shared_core_weights = features.epoch_auxiliary';idx=s.index(needle,s.index('fn fromEnvironmentForModel'))
s=s[:idx]+'                features.stream_chunks = features.gpu_greedy_stream and platform.env.getenvBool("ANTFLY_LIGHTONOCR3_STREAM_CHUNKS");\n'+s[idx:]
needle='                    try M.setLightOnGpuGreedyStream(&cb, ctx.features.gpu_greedy_stream);';assert s.count(needle)==1
s=s.replace(needle,needle+'\n                    try M.setLightOnStreamChunks(&cb, ctx.features.stream_chunks);')
needle='                    const token_scopes = if (comptime build_options.enable_metal)';idx=s.index(needle)
s=s[:idx]+'''                    const stream_frames: [2]u64 = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnStreamFrameStats(&cb) else @splat(0);
                    std.debug.print("LIGHTONOCR3 gpu_greedy_stream_multi_frame_steps={d}\\nLIGHTONOCR3 gpu_greedy_stream_frame_submits={d}\\n", .{ stream_frames[0], stream_frames[1] });
'''+s[idx:]
s=s.replace('"ANTFLY_LIGHTONOCR3_GPU_GREEDY_STREAM",','"ANTFLY_LIGHTONOCR3_GPU_GREEDY_STREAM", "ANTFLY_LIGHTONOCR3_STREAM_CHUNKS",')
edits[p]=s
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m')
s=(v/'engine50_recurrent_checks.m').read_text().replace('#include "engine50_recurrent_runtime.m"','#include "../../src/backends/metal_kernels.m"').replace('int engine50_original_main(int argc, const char **argv)','int main(int argc, const char **argv)')
assert hashlib.sha256(s.encode()).hexdigest()==json.loads((v/'engine48-freeze.json').read_text())[str(p)]
idx=s.index('static int frame_metadata_check(');s=s[:idx]+(v/'engine53_rolling_frame_check.inc').read_text()+'\n'+s[idx:]
s=s.replace('          int rc = frame_metadata_check(r);','          int rc = frame_metadata_check(r);\n          if (rc == 0) rc = rolled_frame_check(r);')
edits[p]=s
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text()
s=s.replace('    parser.add_argument("--dedup-recurrent-resources", action="store_true")\n','')
s=re.sub(r'    env\["TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_RESOURCE_DEDUP"\] = \(\n.*?\n    \)\n','',s)
assert hashlib.sha256(s.encode()).hexdigest()==json.loads((v/'engine48-freeze.json').read_text())[str(p)]
needle='    parser.add_argument("--gpu-greedy-stream", action="store_true")';assert needle in s
s=s.replace(needle,needle+'\n    parser.add_argument("--stream-chunk-layers", type=int, choices=[0, 1, 2, 4, 8, 16], default=0)')
needle='    args = parser.parse_args()';assert needle in s
s=s.replace(needle,needle+'''\n    if args.stream_chunk_layers:
        if args.single_frame:
            parser.error("--stream-chunk-layers conflicts with --single-frame")
        args.gpu_greedy_stream = True''')
needle='    env["ANTFLY_LIGHTONOCR3_GPU_GREEDY_STREAM"] =';idx=s.index(needle)
s=s[:idx]+'''    env["ANTFLY_LIGHTONOCR3_STREAM_CHUNKS"] = "1" if args.stream_chunk_layers else "0"
    if args.stream_chunk_layers:
        env["ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS"] = str(args.stream_chunk_layers)
'''+s[idx:]
needle='                        "gpu_greedy_stream_two_frame_steps",';assert needle in s
s=s.replace(needle,needle+'\n                        "gpu_greedy_stream_multi_frame_steps",\n                        "gpu_greedy_stream_frame_submits",')
# Per-result configuration is bound alongside the recorded command/limits.
needle='        "scope":';idx=s.find(needle)
if idx>=0:s=s[:idx]+'        "stream_chunk_layers": args.stream_chunk_layers,\n'+s[idx:]
edits[p]=s
manifest={}
for p,s in edits.items():
 dest=proposal/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(s)
 manifest[str(p)]=hashlib.sha256(s.encode()).hexdigest()
(v/'engine53-proposal.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Prepared proposals only:',len(edits),'files. Do not apply during engine52 timings.')
