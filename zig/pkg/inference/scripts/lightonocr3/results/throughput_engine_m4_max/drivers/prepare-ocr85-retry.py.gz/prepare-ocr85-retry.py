from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine85_verify_gpu_build.py').read_text().replace('verify2-gpu-build','verify3-gpu-build');p=v/'run_engine85_verify3_gpu_build.py';assert not p.exists();p.write_text(s)
s=(v/'run_engine85_qualification.py').read_text().replace('run_engine85_verify_gpu_build.py','run_engine85_verify3_gpu_build.py').replace('verify2-gpu-build','verify3-gpu-build').replace("'parent.txt'","'verify3-parent.txt'").replace("+'-parent.txt'","+'-verify3-parent.txt'")
p=v/'run_engine85_qualification_verify3.py';assert not p.exists();p.write_text(s)
s=(v/'run_engine85_primary_queue.py').read_text().replace('ocr-engine85-qualification-parent.txt','ocr-engine85-qualification-verify3-parent.txt')
p=v/'run_engine85_primary_queue_verify3.py';assert not p.exists();p.write_text(s)
s=(v/'run_engine85_primary71.py').read_text().replace('ocr-engine85-qualification-parent.txt','ocr-engine85-qualification-verify3-parent.txt');(v/'run_engine85_primary71.py').write_text(s)
