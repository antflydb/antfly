from pathlib import Path
import ast
v=Path('.venv-lighton-vllm-metal');src=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');(v/'engine64_benchmark_concurrency.py').write_bytes(src.read_bytes())
s=(v/'run_engine63_budget_policies.py').read_text().replace('engine63','engine64')
a=" c=os.environ.get('OCR_CONCURRENCY','8');";assert s.count(a)==1;s=s.replace(a," burst=os.environ.get('OCR_GPU_TOKEN_BURST','0')=='1'\n"+a)
a=" logical64=os.environ.get('OCR_LOGICAL64','0')=='1'";assert s.count(a)==1;s=s.replace(a," if burst:cmd+=['--gpu-token-burst']\n"+a)
a="    frame_stats=re.findall";assert s.count(a)==1;s=s.replace(a,"""    bursts=re.findall(r'gpu_token_burst_enabled=(\\d+) gpu_token_burst_steps=(\\d+) gpu_token_burst_topology_mismatches=(\\d+)',section)
    assert bursts and all((int(e)==1)==(burst and expected_aux)and int(m)==0 for e,n,m in bursts),bursts
    sample['gpu_token_burst_steps']=sum(int(n)for e,n,m in bursts)
    sample['gpu_token_burst_topology_mismatches']=sum(int(m)for e,n,m in bursts)
    assert (sample['gpu_token_burst_steps']>0)==(burst and expected_aux),bursts
    report['gpu_token_burst']=burst
"""+a)
s=s.replace("sample['token_encoder_scope_steps']==(sample['executor_steps']if", "sample['token_encoder_scope_steps']==(sample['executor_steps']+sample['gpu_token_burst_steps']if")
s=s.replace("if single:assert sample['single_frame_steps']==sample['executor_steps']", "if single:assert sample['single_frame_steps']+sample['gpu_token_burst_steps']==sample['executor_steps']")
s=s.replace("<=sum(int(x) for x,_ in cohorts)*(6", "<=sum(int(x) for x,_ in cohorts)*(2 if burst else 1)*(6")
s=s.replace("<=sum(int(x) for _,x in cohorts)*(6", "<=sum(int(x) for _,x in cohorts)*(2 if burst else 1)*(6")
s=s.replace("==(p in ['enginetail','enginetailfair','enginetailepoch'])", "==(burst or p in ['enginetail','enginetailfair','enginetailepoch'])")
ast.parse(s);(v/'run_engine64_budget_policies.py').write_text(s)
s=(v/'run_engine63_prefill8_profile.py').read_text().replace('engine63','engine64');ast.parse(s);(v/'run_engine64_prefill8_profile.py').write_text(s)
print('prepared64 immutable benchmark copy and explicit burst accounting')
