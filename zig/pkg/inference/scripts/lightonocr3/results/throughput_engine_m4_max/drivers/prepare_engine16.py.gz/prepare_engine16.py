from pathlib import Path
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text()
# Generate batch kernels from the qualified per-page shader bodies without
# changing their arithmetic or address-space contracts.
start=s.index('           "kernel void termite_lightonocr3_gqa_split_stage(')
end=s.index('           "kernel void termite_polar4_attention_span(',start)
original=s[start:end]
import re,json
lines=[]
for line in original.splitlines():
    m=re.match(r'\s*(".*")$',line)
    if m:lines.append(json.loads(m.group(1)))
shader=''.join(lines)
def body(name):
    a=shader.index('kernel void '+name);a=shader.index('{',a)+1
    depth=1;b=a
    while depth:
        if shader[b]=='{':depth+=1
        if shader[b]=='}':depth-=1
        b+=1
    return shader[a:b-1]
struct='''struct termite_lighton_batch_row {
    device const float *q;
    device const uchar *k;
    device const uchar *v;
    device const uint *blocks;
    device float4 *partial_o;
    device float4 *output;
    termite_metal_paged_attention_params params;
    termite_metal_decode_gqa_split_params schedule;
};
'''
stage='''kernel void termite_lightonocr3_gqa_batch_stage(constant termite_lighton_batch_row *rows [[buffer(0)]], threadgroup char *shmem [[threadgroup(0)]], ushort tid [[thread_index_in_threadgroup]], ushort lane [[thread_index_in_simdgroup]], ushort sgitg [[simdgroup_index_in_threadgroup]], uint3 tg [[threadgroup_position_in_grid]]) {
    constant termite_lighton_batch_row &row=rows[tg.x];
    constant termite_metal_paged_attention_params &p=row.params;
    constant termite_metal_decode_gqa_split_params &schedule=row.schedule;
    device const float *q=row.q; device const uchar *encoded_key=row.k; device const uchar *v_bytes=row.v;
    device const uint *block_table=row.blocks; device float4 *partial_o=row.partial_o;
'''+body('termite_lightonocr3_gqa_split_stage').replace('const uint qi = tg.x;', 'const uint qi = 0u;')+'}\n'
reduce='''kernel void termite_lightonocr3_gqa_batch_reduce(constant termite_lighton_batch_row *rows [[buffer(0)]], ushort lane [[thread_index_in_simdgroup]], ushort sgitg [[simdgroup_index_in_threadgroup]], uint2 tg [[threadgroup_position_in_grid]]) {
    constant termite_lighton_batch_row &row=rows[tg.x];
    constant termite_metal_paged_attention_params &p=row.params;
    constant termite_metal_decode_gqa_split_params &schedule=row.schedule;
    device const float4 *partial_o=row.partial_o; device float4 *output=row.output;
'''+body('termite_lightonocr3_gqa_split_reduce').replace('const uint qi = tg.x;', 'const uint qi = 0u;')+'}\n'
code=''.join('           '+json.dumps(line)+'\n'for line in (struct+stage+reduce).splitlines(keepends=True))
s=s[:end]+code+s[end:]
s=s.replace('    id<MTLComputePipelineState> lightonocr3_gqa_split_stage_pipeline;', '''    id<MTLComputePipelineState> lightonocr3_gqa_batch_stage_pipeline;
    id<MTLComputePipelineState> lightonocr3_gqa_batch_reduce_pipeline;
    id<MTLComputePipelineState> lightonocr3_gqa_split_stage_pipeline;''',1)
needle='            runtime->lightonocr3_gqa_split_stage_pipeline = termite_metal_make_pipeline'
idx=s.index(needle);s=s[:idx]+'''            runtime->lightonocr3_gqa_batch_stage_pipeline = termite_metal_make_pipeline(device, precise_library, @"termite_lightonocr3_gqa_batch_stage");
            runtime->lightonocr3_gqa_batch_reduce_pipeline = termite_metal_make_pipeline(device, precise_library, @"termite_lightonocr3_gqa_batch_reduce");
'''+s[idx:]
idx=s.index('void termite_metal_decode_runtime_destroy(');a=s[:idx];b=s[idx:];b=b.replace('    runtime->lightonocr3_gqa_split_stage_pipeline = nil;', '''    runtime->lightonocr3_gqa_batch_stage_pipeline = nil;
    runtime->lightonocr3_gqa_batch_reduce_pipeline = nil;
    runtime->lightonocr3_gqa_split_stage_pipeline = nil;''',1);s=a+b
idx=s.index('int termite_metal_decode_runtime_lighton_attention_batch_end(')
code='''typedef struct termite_metal_lighton_batch_row {
    uint64_t q, k, v, blocks, partial_o, output;
    termite_metal_paged_attention_params params;
    termite_metal_decode_gqa_split_params schedule;
} termite_metal_lighton_batch_row;
_Static_assert(sizeof(termite_metal_lighton_batch_row) == 144, "OCR batch row ABI drift");
_Static_assert(offsetof(termite_metal_lighton_batch_row, params) == 48, "OCR batch params ABI drift");
_Static_assert(offsetof(termite_metal_lighton_batch_row, schedule) == 128, "OCR batch schedule ABI drift");

// Return zero only before any GPU command is encoded. Fallback never replays
// a stage, reduction, KV seed, or recurrent state update.
static int termite_metal_lighton_attention_encode_batch_kernel(
    termite_metal_decode_runtime *runtime, termite_metal_lighton_attention_batch *batch
) {
    if (runtime->lightonocr3_gqa_batch_stage_pipeline == nil || runtime->lightonocr3_gqa_batch_reduce_pipeline == nil ||
        termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_BATCHED_GQA_KERNEL"))) return 0;
    const uint32_t heads=batch->rows[0].params.num_heads, kv_heads=batch->rows[0].params.num_kv_heads;
    uint32_t max_splits=0;
    uint32_t blocks[TERMITE_METAL_LIGHTON_BATCH_ROWS][256];
    memset(blocks,0,sizeof(blocks));
    for(size_t i=0;i<batch->count;i++) {
        termite_metal_lighton_attention_record *r=&batch->rows[i];
        if(r->params.num_heads!=heads || r->params.num_kv_heads!=kv_heads ||
            r->q.gpuAddress==0 || r->k.gpuAddress==0 || r->v.gpuAddress==0 || r->output.gpuAddress==0) return 0;
        memcpy(blocks[i],r->blocks,r->params.block_count*sizeof(uint32_t));
        if(r->launch.params.split_count>max_splits)max_splits=r->launch.params.split_count;
    }
    id<MTLBuffer> table=antfly_observe_metal_buffer([runtime->device newBufferWithBytes:blocks length:batch->count*sizeof(blocks[0]) options:MTLResourceStorageModeShared],ANTFLY_BUFFER_INITIALIZED);
    if(table==nil || table.gpuAddress==0 || batch->scratch.gpuAddress==0) return 0;
    termite_metal_lighton_batch_row rows[TERMITE_METAL_LIGHTON_BATCH_ROWS];
    id<MTLResource> resources[TERMITE_METAL_LIGHTON_BATCH_ROWS*4+2];
    size_t resource_count=0;
    resources[resource_count++]=table;
    resources[resource_count++]=batch->scratch;
    for(size_t i=0;i<batch->count;i++) {
        termite_metal_lighton_attention_record *r=&batch->rows[i];
        rows[i]=(termite_metal_lighton_batch_row){.q=r->q.gpuAddress+r->q_offset,.k=r->k.gpuAddress,.v=r->v.gpuAddress,
            .blocks=table.gpuAddress+i*sizeof(blocks[0]),.partial_o=batch->scratch.gpuAddress+r->scratch_offset,
            .output=r->output.gpuAddress+r->output_offset,.params=r->params,.schedule=r->launch.params};
        resources[resource_count++]=r->q;resources[resource_count++]=r->k;
        resources[resource_count++]=r->v;resources[resource_count++]=r->output;
    }
    // Ending the producer encoder orders all KV seeds and Q writes before the
    // two dispatches. Their indirect buffers are explicitly declared resident.
    termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(runtime);
    id<MTLComputeCommandEncoder> encoder=[runtime->active_frame_cb computeCommandEncoderWithDispatchType:MTLDispatchTypeConcurrent];
    if(encoder==nil)return -1;
    [encoder useResources:resources count:resource_count usage:MTLResourceUsageRead|MTLResourceUsageWrite];
    [encoder setBytes:rows length:batch->count*sizeof(rows[0]) atIndex:0];
    [encoder setComputePipelineState:runtime->lightonocr3_gqa_batch_stage_pipeline];
    [encoder setThreadgroupMemoryLength:TERMITE_METAL_DECODE_GQA_SPLIT_STAGE_MEMORY_BYTES(256) atIndex:0];
    [encoder dispatchThreadgroups:MTLSizeMake(batch->count,kv_heads,max_splits) threadsPerThreadgroup:MTLSizeMake(256,1,1)];
    [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
    [encoder setComputePipelineState:runtime->lightonocr3_gqa_batch_reduce_pipeline];
    [encoder dispatchThreadgroups:MTLSizeMake(batch->count,heads,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];
    [encoder endEncoding];
    for(size_t i=0;i<batch->count;i++)batch->rows[i].owner->lightonocr3_gqa_split_calls+=1;
    return 1;
}

'''
s=s[:idx]+code+s[idx:]
idx=s.index('int termite_metal_decode_runtime_lighton_attention_batch_end(');a=s[:idx];b=s[idx:]
needle='    // Finish all Q producers and KV seeds before concurrent read-only attention.'
idx=b.index(needle);b=b[:idx]+'''    const int batch_kernel = termite_metal_lighton_attention_encode_batch_kernel(runtime, batch);
    if (batch_kernel < 0) return -2;
    if (batch_kernel > 0) {
        runtime->lighton_attention_batch_calls += 1;
        runtime->lighton_attention_batch_rows += batch->count;
        termite_metal_lighton_attention_batch_abort(runtime);
        return 0;
    }
'''+b[idx:];s=a+b
p.write_text(s)
