from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';old=json.loads((v/'engine66-freeze.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p,h in old.items():assert sha(root/p)==h,p
changes={}
def edit(path,a,b):
 p=root/path;s=changes.get(p,p.read_text());assert s.count(a)==1,(path,a[:100],s.count(a));changes[p]=s.replace(a,b)
g='zig/pkg/inference/src/architectures/gpt.zig';m='zig/pkg/inference/src/ops/metal_compute.zig';n='zig/pkg/inference/src/server/server.zig';p='zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py'
edit(m,'    lighton_stream_first_layers: u8 = 0,','    lighton_stream_first_layers: u8 = 0,\n    lighton_prefill_stream_layers: u8 = 0,\n    lighton_prefill_stream_ready: bool = false,\n    lighton_prefill_stream_splits: usize = 0,')
edit(m,'    pub fn setLightOnStreamFirstLayers(cb: *const ops.ComputeBackend, layers: u8) !void {','''    /// The epoch has already admitted two complete prefill working sets.
    /// Warm one full synchronous prompt before lending any later prefix.
    pub fn setLightOnPrefillStreamLayers(cb: *const ops.ComputeBackend, layers: u8) !void {
        if (cb.kind() != .metal or cb.vtable.decoderRuntimeBeginFrame != &decoderRuntimeBeginFrameOp) {
            if (layers != 0) return error.UnsupportedPrefillStream;
            return;
        }
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        if (layers > 16) return error.UnsupportedPrefillStream;
        if (layers != 0 and (!self.lightonocr3_projections or !self.lighton_shared_core_weights_enabled or
            !self.lighton_activation_pool_enabled or !metal_runtime_mod.qualifiedM4DeviceDefault() or
            metal_runtime_mod.termite_metal_decode_runtime_stream_frames_available(self.provider_impl.raw_decode_runtime) == 0))
            return error.UnsupportedPrefillStream;
        self.lighton_prefill_stream_layers = layers;
    }

    pub fn lightOnPrefillStreamLayers(cb: *const ops.ComputeBackend) u8 {
        if (cb.kind() != .metal or cb.vtable.decoderRuntimeBeginFrame != &decoderRuntimeBeginFrameOp) return 0;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return if (self.lighton_prefill_stream_ready) self.lighton_prefill_stream_layers else 0;
    }

    pub fn noteLightOnPrefillComplete(cb: *const ops.ComputeBackend) void {
        if (cb.kind() != .metal or cb.vtable.decoderRuntimeBeginFrame != &decoderRuntimeBeginFrameOp) return;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        // This is called only after the complete owned prompt frame drains.
        self.lighton_prefill_stream_ready = true;
    }

    pub fn noteLightOnPrefillStreamSplit(cb: *const ops.ComputeBackend) void {
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        self.lighton_prefill_stream_splits += 1;
    }

    pub fn lightOnPrefillStreamSplits(cb: *const ops.ComputeBackend) usize {
        if (cb.kind() != .metal) return 0;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return self.lighton_prefill_stream_splits;
    }

    pub fn setLightOnStreamFirstLayers(cb: *const ops.ComputeBackend, layers: u8) !void {''')
edit(g,'    const stream_first_layers: usize = if (comptime build_options.enable_metal) blk: {','''    const prefill_stream_layers: usize = if (comptime build_options.enable_metal) blk: {
        const layers = metal_compute_mod.MetalCompute.lightOnPrefillStreamLayers(cb);
        break :blk if (lightOnPrefillSplitEligible(config, batch, query_seq_len,
            decode_context != null and decode_context.?.attention_mode == .paged_prefill,
            owns_qwen3vl_forward_frame, layers) and trace_sink == null and
            !prefillTraceEnabled() and !forceLayerCloneDebug() and !debugLastRowEnabled() and
            !debugTensorStatsEnabled()) layers else 0;
    } else 0;
    const stream_first_layers: usize = if (prefill_stream_layers != 0) prefill_stream_layers else if (comptime build_options.enable_metal) blk: {''')
edit(g,'    const stream_chunks = if (comptime build_options.enable_metal) metal_compute_mod.MetalCompute.lightOnStreamChunksEnabled(cb) else false;','    const stream_chunks = prefill_stream_layers != 0 or (if (comptime build_options.enable_metal) metal_compute_mod.MetalCompute.lightOnStreamChunksEnabled(cb) else false);')
edit(g,'''            try cb.decoderRuntimeSetActiveFrameRegime(.decode);
            if (comptime build_options.enable_metal) {
                if (metal_compute_mod.MetalCompute.lightOnGpuGreedyStreamEnabled(cb) and
                    @import("antfly_platform").env.getenvBoolDefault("ANTFLY_LIGHTONOCR3_TOKEN_ENCODER", true))
                    _ = try cb.decoderRuntimeBeginPlannedComputeScope();
                metal_compute_mod.MetalCompute.noteLightOnStreamSplit(cb);
            }''','''            // Preserve the prefill BF16 input policy across every new group.
            try cb.decoderRuntimeSetActiveFrameRegime(if (prefill_stream_layers != 0) .prefill else .decode);
            if (comptime build_options.enable_metal) {
                if (prefill_stream_layers != 0) {
                    metal_compute_mod.MetalCompute.noteLightOnPrefillStreamSplit(cb);
                } else {
                    if (metal_compute_mod.MetalCompute.lightOnGpuGreedyStreamEnabled(cb) and
                        @import("antfly_platform").env.getenvBoolDefault("ANTFLY_LIGHTONOCR3_TOKEN_ENCODER", true))
                        _ = try cb.decoderRuntimeBeginPlannedComputeScope();
                    metal_compute_mod.MetalCompute.noteLightOnStreamSplit(cb);
                }
            }''')
edit(g,'''        try cb.decoderRuntimeSubmitAndWaitFrame();
        owns_qwen3vl_forward_frame = false;
    }
    if (!is_freestanding and prefillTraceEnabled()''','''        try cb.decoderRuntimeSubmitAndWaitFrame();
        owns_qwen3vl_forward_frame = false;
        if (comptime build_options.enable_metal) {
            if (lightOnPrefillSplitEligible(config, batch, query_seq_len,
                decode_context != null and decode_context.?.attention_mode == .paged_prefill, true, 1))
                metal_compute_mod.MetalCompute.noteLightOnPrefillComplete(cb);
        }
    }
    if (!is_freestanding and prefillTraceEnabled()''')
edit(g,'fn lightOnStreamFrameCount(total_layers: usize, first_layers: usize, chunks: bool) usize {','''fn lightOnPrefillSplitEligible(config: Config, batch: usize, query: usize, paged_prefill: bool, owns_frame: bool, layers: usize) bool {
    return paged_prefill and owns_frame and batch == 1 and query > 1 and query <= 1024 and
        config.qwen35_device_only_state and layers >= 1 and layers <= 16 and
        layers < config.num_hidden_layers and config.hasQwen35VisionArchitectureContract() and
        ((config.hidden_size == 1024 and config.num_hidden_layers == 24) or
            (config.hidden_size == 2560 and config.num_hidden_layers == 32));
}

 test "LightOnOCR3 prefill streaming preserves prompt and frame eligibility" {
    inline for (.{ "../models/testdata/lightonocr3/config.json", "../models/testdata/lightonocr3/config-4b.json" }) |path| {
        var config = try gpt_config.parseConfig(std.testing.allocator, @embedFile(path));
        try std.testing.expect(!lightOnPrefillSplitEligible(config, 1, 512, true, true, 8));
        config.qwen35_device_only_state = true;
        for ([_]usize{ 2, 432, 554, 662, 1024 }) |query| {
            for ([_]usize{ 1, 2, 4, 8, 16 }) |layers| {
                try std.testing.expect(lightOnPrefillSplitEligible(config, 1, query, true, true, layers));
                try std.testing.expectEqual(1 + (config.num_hidden_layers - 1) / layers, lightOnStreamFrameCount(config.num_hidden_layers, layers, true));
            }
        }
        try std.testing.expect(!lightOnPrefillSplitEligible(config, 2, 512, true, true, 8));
        try std.testing.expect(!lightOnPrefillSplitEligible(config, 1, 1, true, true, 8));
        try std.testing.expect(!lightOnPrefillSplitEligible(config, 1, 1025, true, true, 8));
        try std.testing.expect(!lightOnPrefillSplitEligible(config, 1, 512, false, true, 8));
        try std.testing.expect(!lightOnPrefillSplitEligible(config, 1, 512, true, false, 8));
        try std.testing.expect(!lightOnPrefillSplitEligible(config, 1, 512, true, true, 0));
        try std.testing.expect(!lightOnPrefillSplitEligible(config, 1, 512, true, true, 17));
        config.family = .qwen3;
        try std.testing.expect(!lightOnPrefillSplitEligible(config, 1, 512, true, true, 8));
    }
}

fn lightOnStreamFrameCount(total_layers: usize, first_layers: usize, chunks: bool) usize {''')
edit(n,'            pipeline_vision: bool = false,','            pipeline_vision: bool = false,\n            prefill_stream_layers: u8 = 0,')
edit(n,'''                features.shared_core_weights = features.epoch_auxiliary and platform.env.getenvBoolDefault("ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS", metal_runtime.lightOnThroughputProfileEnabled() and cfg.hidden_size == 2560);
                return features;''','''                features.shared_core_weights = features.epoch_auxiliary and platform.env.getenvBoolDefault("ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS", metal_runtime.lightOnThroughputProfileEnabled() and cfg.hidden_size == 2560);
                if (metal_runtime.qualifiedM4DeviceDefault() and cfg.hasQwen35VisionArchitectureContract() and
                    cfg.qwen35_device_only_state and features.shared_decoder_scratch and features.shared_core_weights and
                    features.epoch_auxiliary and features.prepared and features.worker and features.activation_pool and
                    features.prefill_batch_items == 1 and
                    !platform.env.getenvBool("TERMITE_METAL_DISABLE_PIPELINED_DECODE_FRAME"))
                    features.prefill_stream_layers = @intCast(@min(platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_PREFILL_STREAM_LAYERS") orelse 0, 16));
                return features;''')
edit(n,'                    try M.setLightOnStreamChunks(&cb, ctx.features.stream_chunks);','                    try M.setLightOnStreamChunks(&cb, ctx.features.stream_chunks);\n                    try M.setLightOnPrefillStreamLayers(&cb, ctx.features.prefill_stream_layers);')
edit(n,'''                    std.debug.print("LIGHTONOCR3 stream_forward_splits={d} stream_first_layers={d}\\n", .{ stream_splits, ctx.features.stream_first_layers });''','''                    std.debug.print("LIGHTONOCR3 stream_forward_splits={d} stream_first_layers={d}\\n", .{ stream_splits, ctx.features.stream_first_layers });
                    const prefill_splits = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnPrefillStreamSplits(&cb) else 0;
                    std.debug.print("LIGHTONOCR3 prefill_stream_layers={d} prefill_stream_splits={d}\\n", .{ ctx.features.prefill_stream_layers, prefill_splits });''')
edit(p,'    args = parser.parse_args()','''    parser.add_argument(
        "--prefill-stream-layers", type=int, choices=(0, 1, 2, 4, 8, 16), default=0,
        help="Overlap admitted single-page prefill layer groups after one complete warm prompt",
    )
    args = parser.parse_args()
    if args.prefill_stream_layers and (
        not args.continuous or not args.device_recurrent_state
        or not args.share_decoder_scratch or args.prefill_batch
    ):
        parser.error("--prefill-stream-layers requires continuous GPU recurrent state, shared scratch and single-page prefill")''')
edit(p,'    env["ANTFLY_LIGHTONOCR3_PIPELINE_VISION"] = "1" if args.pipeline_vision else "0"','    env["ANTFLY_LIGHTONOCR3_PREFILL_STREAM_LAYERS"] = str(args.prefill_stream_layers)\n    env["ANTFLY_LIGHTONOCR3_PIPELINE_VISION"] = "1" if args.pipeline_vision else "0"')
edit(p,'        "pipeline_vision": args.pipeline_vision,','        "pipeline_vision": args.pipeline_vision,\n        "prefill_stream_layers": args.prefill_stream_layers,')
for path,s in changes.items():
 (v/('engine66-before67-'+path.name)).write_bytes(path.read_bytes());path.write_text(s)
subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt',*[str(p)for p in changes if p.suffix=='.zig']],check=True)
subprocess.run(['/Users/ajroetker/.local/bin/ruff','format',str(root/p)],check=True)
(v/'engine67-freeze.json').write_text(json.dumps({p:sha(root/p)for p in old},indent=2)+'\n')
print('engine67 applied and frozen',len(old))
