from pathlib import Path
import subprocess,sys
s=Path('.venv-lighton-vllm-metal/engine5_gpu_tests.py').read_text();exec(s[:s.index('cmd=[str(')])
root=Path.cwd();env['ANTFLY_LIGHTONOCR3_PHASE_PARK']='1'
env['ANTFLY_LIGHTONOCR3_EXECUTOR_TAIL']='1'
env['ANTFLY_LIGHTONOCR3_COMPACT_KV']='1'
env['ZIG_GLOBAL_CACHE_DIR']=str(root/'zig/.zig-cache/global')
filters=['LightOnOCR3','Qwen3-VL','batch decode context','execution lane','projector residency','executor batch','coalesc','Florence','shared native provider','dynamic linear slot','decode GQA split','argmax','video buffer survives producer destruction','video Metal gather fences']
command=['/Users/ajroetker/bin/zig-0.17.0/zig','build','inference-test','-Doptimize=ReleaseFast','-Dstrip=true',*[f'-Dtest-filter={x}'for x in filters]]
with open('/private/tmp/ocr-engine8b-gpu-build.txt','w')as out:r=subprocess.run(command,cwd=root/'zig',env=env,stdout=out,stderr=subprocess.STDOUT)
print('exit',r.returncode);sys.exit(r.returncode)
