from pathlib import Path
import subprocess,sys,time
v=Path('.venv-lighton-vllm-metal');p=Path('/private/tmp/ocr-engine68-qualification-parent.txt')
while True:
 s=p.read_text()
 if 'ENGINE68 QUALIFICATION DONE' in s:break
 if 'Traceback' in s:raise RuntimeError('qualification failed; no performance run')
 time.sleep(5)
with Path('/private/tmp/ocr-engine68-prefill49-parent.txt').open('w')as log:
 subprocess.run([sys.executable,str(v/'run_engine68_prefill_stream49.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
print('ENGINE68 PREFILL SCREEN DONE',flush=True)
