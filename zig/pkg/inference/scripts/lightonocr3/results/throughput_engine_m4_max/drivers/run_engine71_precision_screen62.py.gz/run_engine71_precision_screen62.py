from pathlib import Path
import ast,datetime,hashlib,json,os,subprocess,sys
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p,h in json.loads((v/'engine71-freeze.json').read_text()).items():assert sha(root/p)==h,p
assert 'ENGINE71 FOLLOW60 DONE' in Path('/private/tmp/ocr-engine71-follow60-parent.txt').read_text()
assert 'ENGINE72 ISOLATED PROBE DONE pass' in Path('/private/tmp/ocr-engine72-probe-parent.txt').read_text()
primary=json.loads((out/'paired59_4b_comparison_audit.json').read_text()); profiles=primary['profiles']
source=(v/'run_engine71_api_paired59.py').read_text();node=next(x for x in ast.parse(source).body if isinstance(x,ast.FunctionDef) and x.name=='native');base=ast.get_source_segment(source,node)
audit=out/'engine71_precision_screen62_audit.json';assert not audit.exists()
record=dict(status='running',scope='Current qualified runtime, BF16 decode-input packing versus existing F32 decode. Same original BF16 weights and F32 recurrent state, caps, R128 and exact string checks. ABBA policy screen only; not a vLLM win.',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),cases=[])
def save():audit.write_text(json.dumps(record,indent=2)+'\n')
save();oracle=Path(primary['comparisons'][-1]['reference_report']).parent.name.removeprefix('vllm_4b')
for leg,bf16 in enumerate([False,True,True,False]):
 label='precision_screen62_'+('bf16' if bf16 else 'f32')
 fn=base.replace('paired59',label).replace("OCR_BF16='0'",f"OCR_BF16='{int(bf16)}'")
 exec(compile(fn,'precision_screen62_'+str(leg),'exec'),globals())
 print('START PRECISION',leg,bf16,flush=True)
 try:
  d,p=native('wide',leg,oracle); s=d['results'][0]['policy_rounds'][0]
  record['cases'].append(dict(leg=leg,bf16_decode_inputs=bf16,status='pass',pages_per_second=s['pages_per_second'],report=str(p.relative_to(out)),report_sha256=sha(p)))
 except Exception as e:
  record['cases'].append(dict(leg=leg,bf16_decode_inputs=bf16,status='failed',error=repr(e)));save();raise
 save();print('DONE PRECISION',record['cases'][-1],flush=True)
record['status']='pass';save();print('ENGINE71 PRECISION62 DONE',flush=True)
