from pathlib import Path
import subprocess,sys,time,json,hashlib,os
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');audit=o/'engine57_batching_verify3_audit.json'
while not audit.exists() or json.loads(audit.read_text())['status']!='pass':time.sleep(5)
d=json.loads(audit.read_text());best=max((x for x in d['candidates']if x['eligible']),key=lambda x:x['pages_per_second']);print('SCREENS DONE',best,flush=True)
if best['pages_per_second']>1.05:
 print('PROMISING ENGINE57 PROFILE; primary comparison before source changes',flush=True);sys.exit(0)
def run(name,cmd,env=None):
 p=Path('/private/tmp/ocr-engine58-'+name+'-driver.txt');assert not p.exists(),p
 print('START',name,flush=True)
 with p.open('w')as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True);assert r.returncode==0,(name,r.returncode)
run('apply',[sys.executable,str(v/'apply_engine58_prefill8.py')])
env=os.environ.copy();env['ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY']='1'
run('verify-gpu-build',[sys.executable,str(v/'run_engine58_verify_gpu_build.py')],env)
run('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine58','/private/tmp/ocr-engine58-verify-gpu-build.txt'])
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=json.loads((o/'engine56_c_build_manifest.json').read_text());assert all(sha(p)==h for p,h in m['input_sha256'].items())
(o/'engine58_c_qualification_reuse_audit.json').write_text(json.dumps(dict(status='pass',c_suites=16,source='engine56',input_sha256=m['input_sha256'],reason='All C, header and checker inputs byte-identical; engine58 only changes uniform prefill bounds and optionally queued scheduler phase priority.'),indent=2)+'\n')
p=v/'run_engine58_metal_disabled.py';assert not p.exists();p.write_text((v/'run_engine57_metal_disabled.py').read_text().replace('engine57','engine58'))
run('metal-disabled',[sys.executable,str(p)])
print('ENGINE58 BUILD QUALIFICATION DONE',flush=True)
