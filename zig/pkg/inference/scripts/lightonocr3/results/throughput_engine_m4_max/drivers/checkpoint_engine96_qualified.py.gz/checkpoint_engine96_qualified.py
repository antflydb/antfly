from pathlib import Path
import datetime,gzip,hashlib,json,os,psutil,signal,subprocess,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();a=o/'engine96_checkpoint_audit.json';assert not a.exists();d=dict(status='checking_own_waiter',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)))
def save():a.write_text(json.dumps(d,indent=2)+'\n')
f=json.loads((v/'engine96-freeze.json').read_text());assert all(sha(r/p)==h for p,h in f.items());assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='feat/lightonocr3-08b'
waiters=[]
for p in psutil.process_iter(['cmdline']):
 try:
  c=p.info['cmdline']or[]
  if len(c)==2 and Path(p.cwd(),c[1]).resolve()==v/'run_engine96_mixed_screen76.py':waiters.append(p)
 except(psutil.NoSuchProcess,psutil.AccessDenied):pass
assert len(waiters)==1;p=waiters[0];d['waiter_pid']=p.pid
if p.children(recursive=True):d['status']='declined_primary_child_active';save();print(d);sys.exit(0)
os.kill(p.pid,signal.SIGSTOP)
try:
 if p.children(recursive=True):d['status']='declined_child_raced_stop';save();sys.exit(0)
 d['status']='paused_own_child_free_waiter';save();print('PAUSED',p.pid,flush=True)
 # Only closed model logs are archived; the4Bscreen/audit/parentremainactive.
 subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine96_08_*'],check=True)
 ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
 logs=[Path('/private/tmp')/n for n in ['ocr-engine96-packed-cpu.txt','ocr-engine96-verify3-gpu-build.txt','ocr-engine96-gpu-qualification-parent.txt','ocr-engine96-archive93-95.txt','ocr-engine96-mixed76-08-driver.txt','ocr-engine96-08-mixed_screen76_c16_r32.txt']]
 ns['archive']('qualification',logs,'logs_manifest.json')
 drivers=[p for p in v.glob('*engine96*')if p.is_file()and p.suffix in ['.py','.json','.m','.inc','.metal']and p.name!=Path(__file__).name]
 ns['archive']('drivers',drivers,'drivers_manifest.json')
 c=json.loads((o/'engine91_c_build_manifest.json').read_text());assert all(sha(r/p)==h for p,h in c['input_sha256'].items());assert sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')=='ab7db0fab1cab774c127bf2a32560a4879980a29b4405f19ac75f4d70012ef83'
 q=dict(scope='Source96 defaultOFF Metal/CPU regression and exact0.8B packedmixed screen. C91 arithmetic/checker/headers unchanged, reuse20C suites onlyafter exactinputhashverification. 4Bpackedmodel and actualvLLMwin stillpending.',cpu=dict(passed=204,skipped=28),metal=dict(passed=324,skipped=6),source_inputs_sha256=sha(v/'engine96-freeze.json'),c_qualification_manifest_sha256=sha(o/'engine91_c_build_manifest.json'),small_report_sha256=sha(o/'engine96_08_mixed_screen76_c16_r32/report.json'))
 (o/'engine96_qualification_audit.json').write_text(json.dumps(q,indent=2)+'\n')
 readme=o/'README.md';s=readme.read_text();s=s.replace("Source96 is\nunder qualification and has no performance result yet. Defaults remain off.","Source96 collects contiguous decode recurrent cores into the existing\n16-page argument tables, preserving page boundaries and frame ownership.\nIt passes 324 Metal-enabled tests (six skips) and 204 CPU tests (28 skips),\nincluding packed-position and mixed-working-set admission checks. Its0.8B\nC16/R32 screen completes all32 exact outputs with30mixedsteps,540recurrent\ngroups and5796recurrentrows. The3.6213pages/s diagnostic is not a new matched\nspeed claim. Eligible mixed projections use the existing BF16-prefill input\npolicy for attached decode tokens too; accumulators/state and pure decode\nremain F32. The4B screen waits for the original model estimate plus six-GiB\nreserve; no4B packed throughput result exists yet. Defaults remain off.")
 readme.write_text(s)
 assert all(sha(r/p)==h for p,h in f.items());d['status']='committing';save()
 production=['zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py','zig/pkg/inference/src/architectures/gpt.zig','zig/pkg/inference/src/pipelines/generation.zig','zig/pkg/inference/src/runtime/scheduler/native_generate.zig','zig/pkg/inference/src/server/server.zig']
 subprocess.run(['git','add','--',*production,str(o.relative_to(r))],check=True)
 for name in ['engine96_mixed_screen76_audit.json','engine96_checkpoint_audit.json']:
  subprocess.run(['git','restore','--staged','--',str((o/name).relative_to(r))],check=True)
 subprocess.run(['git','diff','--cached','--check'],check=True)
 subprocess.run(['git','commit','-m','Add opt-in packed OCR prefill and decode execution'],check=True)
 assert all(sha(r/p)==h for p,h in f.items());d['commit']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();d['status']='pushing';save();subprocess.run(['git','push','origin','HEAD'],check=True)
 d['status']='pushed';save();print('PUSHED96',d['commit'],flush=True)
finally:
 if all(sha(r/p)==h for p,h in f.items()):os.kill(p.pid,signal.SIGCONT);d['waiter_resumed']=True;print('RESUMED',p.pid,flush=True)
 else:os.kill(p.pid,signal.SIGTERM);os.kill(p.pid,signal.SIGCONT);d['waiter_retired_source_changed']=True
 save()
