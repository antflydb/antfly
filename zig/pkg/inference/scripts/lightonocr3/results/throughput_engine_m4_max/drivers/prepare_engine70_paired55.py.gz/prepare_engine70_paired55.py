from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
(v/'run_engine70_budget_policies.py').write_text((v/'run_engine69_budget_policies.py').read_text().replace('engine69','engine70'))
(v/'engine70_benchmark_concurrency.py').write_bytes(Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
s=(v/'run_engine69_api_paired52.py').read_text().replace('engine69','engine70').replace('paired52','paired55').replace('reference52','reference55').replace('gpu_memory_utilization0.65','gpu_memory_utilization0.7').replace("'0.65'","'0.7'")
a=s.index("source = out /");b=s.index('sha = lambda',a)
s=s[:a]+'''source = out / 'engine69_prefill_screen51_4b_r128_audit.json'
while True:
    pp=Path('/private/tmp/ocr-engine70-qualification-parent-attempt2.txt')
    text=pp.read_text() if pp.exists() else ''
    if 'ENGINE70 QUALIFICATION DONE' in text: break
    if 'Traceback' in text or 'DONE c-qualification 2' in text: raise RuntimeError('qualification failed')
    time.sleep(5)
'''+s[b:]
s=s.replace('Balanced A32/A64/B/B/A64/A32 controls','Balanced A16/A32/A64/guarded-full64/B/B/guarded-full64/A64/A32/A16 controls')
s=s.replace('Corrected trace-mask build, fixed fastest independently qualified prompt policy','Frame-cached recurrent/norm/gate-up controls with unchanged shader arithmetic, fixed prior independently qualified prompt policy')
s=s.replace('API vLLM reference search at C32 and C64','API vLLM reference search at C16, C32 and C64, plus explicit 320-block C64 only when within EVERY automatic capacity')
s=s.replace("def reference(index, concurrency):","def reference(index, concurrency, blocks=None):")
s=s.replace("label = f'_primary_reference55_r{index}_auto_c{concurrency}_r128_ctx1024'","label = f'_primary_reference55_r{index}_{\"auto\" if blocks is None else \"b\"+str(blocks)}_c{concurrency}_r128_ctx1024'")
s=s.replace("    print('START VLLM', index, concurrency, flush=True)","    if blocks is not None: cmd += ['--kv-cache-blocks', str(blocks)]\n    print('START VLLM', index, concurrency, blocks, flush=True)")
s=s.replace("f'/private/tmp/ocr-engine70-vllm-paired55-r{index}-c{concurrency}.txt'","f'/private/tmp/ocr-engine70-vllm-paired55-r{index}-c{concurrency}-b{blocks}.txt'")
s=s.replace('subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, check=True)','result = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT)')
anchor="    assert d['status'] == 'ok' and d['kv_cache_block_override'] is None and d['cache_override_admission']['admitted'] and d['results'][0]['serial_reference_parity']"
assert anchor in s
s=s.replace(anchor,"""    if result.returncode:
        if blocks is not None and not d.get('cache_override_admission', {}).get('admitted', True):
            assert not d.get('results') and not d.get('references')
            record.setdefault('excluded_reference_attempts', []).append(dict(round=index, concurrency=concurrency, blocks=blocks, reason=d['cache_override_admission'], report=str(p.relative_to(out)), report_sha256=sha(p)))
            save(); print('EXCLUDED UNSAFE CACHE OVERRIDE', blocks, flush=True); return None
        raise RuntimeError(('reference failed', p, result.returncode))
    assert d['status'] == 'ok' and d['kv_cache_block_override'] == blocks and d['cache_override_admission']['admitted'] and d['results'][0]['serial_reference_parity']""")
s=s.replace("reference_automatic_cache=True","reference_automatic_cache=rd['kv_cache_block_override'] is None")
s=s.replace("refs=[reference(0,c) for c in [32,64]]","refs=[reference(0,c) for c in [16,32,64]]\nfull=reference(0,64,320)\nif full is not None:refs.append(full)")
s=s.replace("reverse_refs=[reference(1,c)for c in [64,32]]","reverse_refs=[]\nif full is not None:\n closing_full=reference(1,64,320)\n if closing_full is not None:reverse_refs.append(closing_full)\nreverse_refs.extend(reference(1,c)for c in [64,32,16])")
# Keep block-policy identity in all candidate records.
s=s.replace("dict(concurrency=d['results'][0]['concurrency'],pages_per_second", "dict(blocks=d['kv_cache_block_override'],concurrency=d['results'][0]['concurrency'],pages_per_second")
s=s.replace("dict(round=1,concurrency=d['results'][0]['concurrency'],pages_per_second", "dict(round=1,blocks=d['kv_cache_block_override'],concurrency=d['results'][0]['concurrency'],pages_per_second")
compile(s,'run_engine70_api_paired55.py','exec');(v/'run_engine70_api_paired55.py').write_text(s)
print('prepared stronger default-memory matched API comparison; not started')
