from pathlib import Path
import datetime,hashlib,json,os,psutil,re,statistics,subprocess,sys,time
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';scripts=root/'zig/pkg/inference/scripts/lightonocr3';out=scripts/'results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
while True:
 p=Path('/private/tmp/ocr-engine81-finalqualification-verify2-parent.txt');s=p.read_text()if p.exists()else''
 if 'Traceback'in s:raise RuntimeError(s[-3000:])
 if 'ENGINE81 FINAL QUALIFICATION DONE'in s:break
 time.sleep(5)
for p,h in json.loads((v/'engine81-freeze.json').read_text()).items():assert sha(root/p)==h,p
profiles=json.loads((out/'paired59_4b_comparison_audit.json').read_text())['profiles']
audit=out/'paired70_4b_comparison_audit.json';assert not audit.exists()
record=dict(status='running',scope='Strong independent vLLM API C16/C32/C64 model/cache admissions before and after one resident native 4B model with R128 OFF/ON/ON/OFF FFN policy rounds. Native ON serial warm references compile the optional PSOs before timing and must equal all full cross-runtime fixture strings. All timed OFF and ON outputs must equal these same serial references. Compare first ON round to strongest opening API control and second ON to strongest closing API control. Original caps/reserve/F32 decode/BF16 prefill; no own compilation or sampling during measurements. Temporal comparisons bracket the complete four-round native block, not individual adjacent native rounds. Different API/native concurrency/cache capacity and HTTP/native boundary retained explicitly.',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),profiles=profiles,comparisons=[],reference_candidates=[])
def save():audit.write_text(json.dumps(record,indent=2)+'\n')
def wait_model_headroom():
 while psutil.virtual_memory().available<11348275670+6*1024**3+512*1024**2:
  print('WAIT original 4B admission',psutil.virtual_memory().available,flush=True);time.sleep(30)
def reference(index, concurrency, blocks=None):
    wait_model_headroom()
    label = f'_primary_reference70_r{index}_{"auto" if blocks is None else "b"+str(blocks)}_c{concurrency}_r128_ctx1024'
    dest = out / ('vllm_4b' + label)
    assert not dest.exists()
    images = [root / 'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png', scripts / 'corpus/receipt.png', scripts / 'corpus/shipping.png']
    cmd = [sys.executable, str(scripts / 'benchmark_vllm_metal.py'), '--python', sys.executable,
           '--model-dir', str(v / 'ocr-models/lighton4b'), '--images', *map(str, images),
           '--concurrency', str(concurrency), '--requests', '128', '--max-tokens', '256', '--startup-timeout', '600', '--max-model-len', '1024', '--gpu-memory-utilization', '0.7', '--output-dir', str(dest)]
    if blocks is not None: cmd += ['--kv-cache-blocks', str(blocks)]
    print('START VLLM', index, concurrency, blocks, flush=True)
    with Path(f'/private/tmp/ocr-engine81-vllm-paired70-r{index}-c{concurrency}-b{blocks}.txt').open('w') as log:
        result = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT)
    p = dest / 'report.json'
    d = json.loads(p.read_text())
    if result.returncode:
        if blocks is not None and not d.get('cache_override_admission', {}).get('admitted', True):
            assert not d.get('results') and not d.get('references')
            record.setdefault('excluded_reference_attempts', []).append(dict(round=index, concurrency=concurrency, blocks=blocks, reason=d['cache_override_admission'], report=str(p.relative_to(out)), report_sha256=sha(p)))
            save(); print('EXCLUDED UNSAFE CACHE OVERRIDE', blocks, flush=True); return None
        raise RuntimeError(('reference failed', p, result.returncode))
    assert d['status'] == 'ok' and d['kv_cache_block_override'] == blocks and d['cache_override_admission']['admitted'] and d['results'][0]['serial_reference_parity']
    assert max(x['usage']['prompt_tokens'] for x in d['references'])+256<=1024
    print('DONE VLLM', index, concurrency, d['results'][0]['pages_per_second'], flush=True)
    return label, d, p

def native(key, index, oracle):
    wait_model_headroom()
    c, pref, vis, vf, sv, sp, q = profiles[key]['settings']
    label = f'paired70_resident_{key}_r{index}_c{c}_p{pref}_v{vis}_vf{vf}_r128'
    dest = out / ('engine81_4b_' + label)
    assert not dest.exists()
    env = os.environ.copy()
    env.update(OCR_REFERENCE_LABEL=oracle, OCR_PHYSICAL32='0', OCR_PHYSICAL64='1', OCR_CONCURRENCY=str(c),
               OCR_REQUESTS='128', OCR_WIDE='1', OCR_KV_GIB='4', OCR_BACKEND_GIB='17', OCR_SCRATCH_GIB='10',
               OCR_CPU_PREPROCESS='1', OCR_PREFILL_DECODE_STREAK='0', OCR_POLICIES='engineepoch,engineepoch,engineepoch,engineepoch', OCR_SHARED_CORE='1',
               OCR_BF16_PREFILL='1', OCR_BF16='0', OCR_DISABLE_64_ROW_TILE='0', OCR_DISABLE_WIDE_GATE_UP='0',
               OCR_WIDE64_GATE_UP='1', OCR_FULL64_GATE_UP='1', OCR_GPU_GREEDY_STREAM='0', OCR_STREAM_CHUNK_LAYERS='0',
               OCR_VISION_BATCH=str(int(vis > 1)), OCR_VISION_BATCH_ITEMS=str(vis), OCR_VISION_WAIT_US='2000',
               OCR_PREFILL_BATCH=str(int(pref > 1)), OCR_PREFILL_BATCH_ITEMS=str(pref), OCR_PREFILL_WAIT_US=str(profiles[key].get('prefill_wait_us', 100000)),
               OCR_VISION_FRAME_BLOCKS=str(vf), OCR_SINGLE_FRAME='1', OCR_STREAM_FIRST='0', OCR_LOGICAL64='1',
               OCR_SHARED_DECODER_SCRATCH='1', OCR_DEVICE_RECURRENT_STATE='1', OCR_ENCODER_SCOPES='1', OCR_ADMISSION_UNITS='512',
               OCR_BATCH_ARGMAX='1', OCR_DEFER_VISION_SEAL=str(sv), OCR_DEFER_PREFILL_SEAL=str(sp),
               OCR_CACHE_VISION_WORKSPACE='1', OCR_LARGE_VISION_PACK_REUSE=str(int(vis > 1)),
               ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY=str(q), OCR_TIMEOUT='900')
    env['OCR_PREFILL_FUSED_FFN']='1'
    env['OCR_PREFILL_FFN_ROUNDS']='off,on,on,off'
    env['OCR_RESIDENT_VISION_BUDGET']='1'
    env['OCR_GPU_TOKEN_BURST']='1'
    env['OCR_GPU_TOKEN_BURST_WIDTH']='4'
    env['OCR_PIPELINE_VISION']=str(int(profiles[key]['pipeline_vision']))
    env['OCR_PREFILL_STREAM_LAYERS']=str(profiles[key]['prefill_stream_layers'])
    print('START NATIVE', key, index, profiles[key]['settings'], flush=True)
    with Path(f'/private/tmp/ocr-engine81-native-paired70_resident-{key}-r{index}-driver.txt').open('w') as log:
        subprocess.run([sys.executable, str(v / 'run_engine81_budget_policies.py'), '4b:' + label], env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    p = dest / 'report.json'
    d = json.loads(p.read_text())
    result = d['results'][0]
    samples=result['policy_rounds']
    assert len(samples)==4 and [s['prefill_fused_ffn_enabled']for s in samples]==[False,True,True,False]
    for s in samples:
        assert result['status'] == 'ok' and result['serial_reference_parity'] and result['cross_runtime_content_parity']
        assert (s['prefill_fused_ffn_calls'] > 0)==s['prefill_fused_ffn_enabled']
        assert s['completed'] == 128 and not s['admission_pressures'] and not d['own_cpu_compile_overlap']
        assert s['host_recurrent_bytes_total'] == s['single_frame_topology_mismatches'] == s['gpu_greedy_stream_topology_mismatches'] == 0
        assert s['vision_workspace_reuses'] > 0 and s['batch_argmax_calls'] > 0
        assert d['queued_phase_priority'] == bool(q) and d['resident_vision_budget'] and d['gpu_token_burst']
        assert s['gpu_token_burst_steps']>0 and s['gpu_token_burst_topology_mismatches']==0
        assert s['gpu_token_burst_max_width']==4 and s['gpu_token_burst_extra_steps']>s['gpu_token_burst_steps']
        assert (s['vision_pipeline_images']==128 and s['vision_pipeline_overlaps']>0)==profiles[key]['pipeline_vision']
        assert d['pipeline_vision']==profiles[key]['pipeline_vision'] and ((s['prefill_stream_splits']>0)==(profiles[key]['prefill_stream_layers']>0))
        assert d['prefill_stream_layers']==profiles[key]['prefill_stream_layers']
    print('DONE NATIVE', key, index, s['pages_per_second'], flush=True)
    return d, p
save()
def reference_sweep(index,concurrencies):
 refs=[reference(index,c)for c in concurrencies]
 capacities=[]
 for _,_,rp in refs:
  values=[int(n)for n in re.findall(r'Hybrid shared cache: (\d+) blocks',(rp.parent/'server.txt').read_text())]
  assert values,rp;capacities.extend(values)
 if min(capacities)>=320:
  full=reference(index,64,320)
  if full is not None:refs.append(full)
 else:
  record.setdefault('full_capacity_candidates_skipped',[]).append(dict(round=index,requested_blocks=320,observed_automatic_blocks=capacities,reason='Skip override: outside at least one fresh automatic admission.'));save()
 for label,d,p in refs:
  record['reference_candidates'].append(dict(round=index,blocks=d['kv_cache_block_override'],concurrency=d['results'][0]['concurrency'],pages_per_second=d['results'][0]['pages_per_second'],report=str(p.relative_to(out)),report_sha256=sha(p)))
 save();return max(refs,key=lambda x:x[1]['results'][0]['pages_per_second'])
r0=reference_sweep(0,[16,32,64])
nd,np=native('wide',0,r0[0]);samples=nd['results'][0]['policy_rounds']
record['native_control']=dict(report=str(np.relative_to(out)),report_sha256=sha(np),rounds=[{k:s.get(k)for k in ['round','prefill_fused_ffn_enabled','prefill_fused_ffn_calls','completed','pages_per_second','process_cpu_ms']}for s in samples],packed_to_ordinary_mean_ratio=statistics.mean(s['pages_per_second']for s in samples if s['prefill_fused_ffn_enabled'])/statistics.mean(s['pages_per_second']for s in samples if not s['prefill_fused_ffn_enabled']));save()
r1=reference_sweep(1,[64,32,16])
for index,(sample,ref)in enumerate([(samples[1],r0),(samples[2],r1)]):
 _,rd,rp=ref
 assert {x['image_index']:x['text']for x in nd['results'][0]['references']}=={x['image_index']:x['text']for x in rd['references']}
 a=sample['pages_per_second'];b=rd['results'][0]['pages_per_second']
 record['comparisons'].append(dict(round=index,native_policy_round=sample['round'],native_pages_per_second=a,reference_pages_per_second=b,native_to_vllm_ratio=a/b,reference_concurrency=rd['results'][0]['concurrency'],reference_blocks=rd['kv_cache_block_override'],all_128_native_pages_equal_serial=True,full_cross_runtime_fixture_string_identity=True,primary_throughput_eligible=True,native_report=str(np.relative_to(out)),native_report_sha256=sha(np),reference_report=str(rp.relative_to(out)),reference_report_sha256=sha(rp)));save()
ratios=[x['native_to_vllm_ratio']for x in record['comparisons']];record['status']='repeated_win'if min(ratios)>1 else'native_behind';save();print('ENGINE81 PRIMARY70 DONE',record['status'],ratios,flush=True)
