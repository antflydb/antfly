from pathlib import Path
import json
import os
import re
import subprocess
import sys

root = Path.cwd()
v = root / '.venv-lighton-vllm-metal'
p = root / 'zig/pkg/inference/scripts/lightonocr3'
out = p / 'results/throughput_engine_m4_max'
manifest = out / 'engine38_build_manifest.json'
binary = json.loads(manifest.read_text())['binary_path']
dest = out / 'engine38_08_public64_invoice_qualification'
assert not (dest / 'report.json').exists()
env = os.environ.copy()
env.update(ANTFLY_LIGHTONOCR3_THROUGHPUT='1', ANTFLY_LIGHTONOCR3_CPU_PREPROCESS='1',
           ANTFLY_LIGHTONOCR3_VISION_FRAME_BLOCKS='4', ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS='0',
           ANTFLY_LIGHTONOCR3_SINGLE_FRAME='1', ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS='0',
           ANTFLY_LIGHTONOCR3_PREFILL_BATCH='0', ANTFLY_LIGHTONOCR3_VISION_BATCH='0',
           ANTFLY_LIGHTONOCR3_PREFILL_DECODE_STREAK='0', ANTFLY_LIGHTONOCR3_EXTENDED_EPOCH='1',
           ANTFLY_LIGHTONOCR3_COMPACT_KV='1')
command = [sys.executable, str(p / 'benchmark_concurrency.py'), '--native-test', binary,
           '--model', 'lighton08=' + str(v / 'ocr-models/lighton08'), '--images',
           str(root / 'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),
           '--concurrency', '1', '--requests', '1', '--pages-per-request', '64',
           '--max-tokens', '256', '--modes', 'batch', '--admission-units', '512',
           '--continuous', '--physical64', '--batch-rows', '64', '--batch-window', '64',
           '--batch-wait-us', '20000', '--memory-gib', '24', '--shared-memory-gib', '28',
           '--backend-memory-gib', '16', '--kv-memory-gib', '4', '--scratch-memory-gib', '8',
           '--timeout', '900', '--build-manifest', str(manifest),
           '--output-dir', str(dest), '--weight-residency', '--frame-policy', '--weight-handles',
           '--trace-packed-core', '--require-packed-core', '--recurrent-parallel',
           '--prefill-attention-mpp', '--prefill-core-norm', '--policy-rounds', 'engineepoch',
           '--device-recurrent-state', '--share-decoder-scratch', '--ocr-encoder-scopes']
with Path('/private/tmp/ocr-engine38-public64-invoice-qualification-verify.txt').open('w') as log:
    result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
assert result.returncode == 0, result.returncode
report = json.loads((dest / 'report.json').read_text())
r = report['results'][0]
assert r['status'] == 'ok' and r['serial_reference_parity']
oracle = json.loads((out / 'vllm_08_primary_reference18_r0_auto_c64_r128/report.json').read_text())
assert len(r['references']) == 1 and r['references'][0]['text'] == oracle['references'][0]['text']
assert r['policy_rounds'][0]['completed'] == 64
raw = (dest / r['log']).read_text().split('OCR_POLICY round=0')[1]
rows = list(map(int, re.findall(r'lightonocr3_packed_core: rows=(\d+)', raw)))
assert rows and max(rows) > 32 and max(rows) <= 64, rows
assert all(int(b) == 64 for a, b in re.findall(r'registered_window_peak=(\d+) physical_rows_limit=(\d+)', raw))
print('PASS public64 exact invoice output, largest physical rows', max(rows), flush=True)
