from pathlib import Path
import re
v=Path('.venv-lighton-vllm-metal');s=(v/'run_engine85_budget_policies.py').read_text().replace('engine85','engine90')
needle=" if os.environ.get('OCR_PREFILL_FFN_ROUNDS'):";assert s.count(needle)==1
s=s.replace(needle," if os.environ.get('OCR_BF16_ROUNDS'):\n  cmd+=['--bf16-projection-rounds',*os.environ['OCR_BF16_ROUNDS'].split(',')]\n if os.environ.get('OCR_REQUIRE_MEMORY_ROUNDS','0')=='1':cmd+=['--require-memory-rounds']\n"+needle)
a=s.index("   for sample in (result.get('policy_rounds') or []):");b=s.index("  (target/'report.json').write_text",a);part=s[a:b]
part=re.sub(r'\bbf16\b','round_bf16',part)
part=part.replace("    section=sections[sample['round']]","    round_bf16=sample.get('bf16_projection_enabled',bf16)\n    section=sections[sample['round']]",1)
s=s[:a]+part+s[b:];p=v/'run_engine90_budget_policies.py';assert not p.exists();p.write_text(s)
print('Prepared per-round precision-aware90 validator; historical85 validator unchanged.')
