from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');freeze=json.loads((v/'engine27-freeze.json').read_text())
for f,h in freeze.items():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h,f
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text()
anchor='        prefill_broker: executor_microbatch.Broker,';assert anchor in s;s=s.replace(anchor,anchor+'\n        prefill_await_groups: usize = 0,\n        prefill_await_events: bool = false,',1)
anchor='            vision_frame_blocks: u8 = 1,';assert anchor in s;s=s.replace(anchor,anchor+'\n            prefill_decode_streak: u8 = 4,',1)
anchor='                    .single_frame = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_SINGLE_FRAME"),';assert anchor in s;s=s.replace(anchor,anchor+'\n                    .prefill_decode_streak = @intCast(@min(platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_PREFILL_DECODE_STREAK") orelse 4, 16)),',1)
old='''            // New prefill must progress, while already decoding pages retain
            // a bounded streak instead of losing every turn to new arrivals.
            ctx.coordinator.max_decode_streak_before_prefill = 4;'''
new='''            // Keep the latency-oriented default; bulk-throughput profiles can
            // prioritize runnable prefills to fill the physical decode batch.
            ctx.coordinator.max_decode_streak_before_prefill = factory.features.prefill_decode_streak;'''
assert old in s;s=s.replace(old,new)
a=s.index('        // Publishing before broker collection finishes lets fairness select',s.index('fn executeLightOnPrefillBatch'))
b=s.index('        ctx.lockStep(control) catch |err| {',a)
new='''        // Only the sealed group's leader is a runnable manual turn. Its
        // followers remain waiting until their shared prefill completes, so
        // the existing event waiter cannot deadlock on a follower's turn.
        // This also avoids polling every group member at 100-us intervals.
        const leader = batch[0].pipeline.scheduler_lease orelse {
            for (items) |item| item.slot.fail(error.InvalidBatchDecodeState);
            return;
        };
        const io = batch[0].pipeline.io orelse {
            for (items) |item| item.slot.fail(error.MissingIo);
            return;
        };
        ctx.coordinator.notePrefillProgress(leader, 0, batch[0].seq_len);
        ctx.coordinator.awaitTurnControlled(leader, .prefill, io, @as(?InferenceExecutionControl, control)) catch |err| {
            for (items) |item| item.slot.fail(err);
            return;
        };
        // Published results may let a follower retire before our defers run.
        var completed_turn = leader.*;
        defer ctx.coordinator.finishTurn(&completed_turn, .prefill);
'''
s=s[:a]+new+s[b:]
s=s.replace('        defer batch[0].pipeline.allocator.free(output);', '        defer output_allocator.free(output);',1)
s=s.replace('        // Only the sealed group\'s leader is a runnable manual turn.', '        const output_allocator = batch[0].pipeline.allocator;\n        // Only the sealed group\'s leader is a runnable manual turn.',1)
anchor='''        defer ctx.unlockStep();
        const output = generation.NativeGenerationPipeline.forwardPreparedQwenPrefillBatch'''
new='''        defer ctx.unlockStep();
        ctx.prefill_await_groups += 1;
        ctx.prefill_await_events = ctx.coordinator.usesStepEvents();
        const output = generation.NativeGenerationPipeline.forwardPreparedQwenPrefillBatch'''
assert anchor in s;s=s.replace(anchor,new,1)
anchor='''                std.debug.print("LIGHTONOCR3 cpu_preprocess={d}'''
i=s.index(anchor)
s=s[:i]+'''                std.debug.print("LIGHTONOCR3 prefill_await_groups={d} prefill_await_events={d} prefill_decode_streak={d}\\n", .{ ctx.prefill_await_groups, @intFromBool(ctx.prefill_await_events), ctx.features.prefill_decode_streak });
'''+s[i:]
old='        request.ctx.coordinator.notePrefillProgress(lease, seq, seq);';assert old in s;s=s.replace(old,'        // No manual prefill work remains while the caller samples its first token.\n        request.ctx.coordinator.beginDecode(lease, seq);',1)
p.write_text(s)
p=Path('zig/pkg/inference/src/runtime/scheduler/native_generate.zig');s=p.read_text();old='''    try std.testing.expect(coordinator.tryAcquireTurn(&sealed, .prefill));
    coordinator.finishTurn(&sealed, .prefill);''';new='''    // A sealed group's leader can use the event-aware waiter even when its
    // older follower is still waiting. No all-member polling is necessary.
    coordinator.setPolicy(.{ .event_waits = true });
    try coordinator.awaitTurnControlled(&sealed, .prefill, std.testing.io, null);
    try std.testing.expect(coordinator.waiters == null);
    coordinator.finishTurn(&sealed, .prefill);''';assert old in s;s=s.replace(old,new,1);s=s.replace('    coordinator.beginDecode(&sealed, 4);\n    var resumed', '    coordinator.beginDecode(&sealed, 4);\n    coordinator.beginDecode(&waiting, 4);\n    var resumed',1);p.write_text(s)
print('28 event-driven prefill groups and tunable decode streak prepared')
