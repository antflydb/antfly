from pathlib import Path
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text()
old='''    // Keep the measured small-model tile. The larger replacement remains
    // explicit until a full-model run qualifies it; preserve generic fusion.
    if (rows >= 32 && in_dim == 2560 && out_dim == 9216 &&
        termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP")) &&
        !termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP"))) {
        id<MTLComputePipelineState> wide = runtime->lightonocr3_gate_up_wide64_pipeline;
        if (wide != nil && wide.threadExecutionWidth == 32 &&
            wide.maxTotalThreadsPerThreadgroup >= 128 &&'''
new='''    // The fully occupied 4B cohort retains its vectorized generic kernel.
    // Use the smaller tile for intermediate tails and a 64-row tile for
    // partial wide cohorts. Keep this measured replacement explicit.
    if (rows >= 17 && rows < 64 && in_dim == 2560 && out_dim == 9216 &&
        termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP")) &&
        !termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP"))) {
        id<MTLComputePipelineState> wide = rows < 32
            ? runtime->lightonocr3_gate_up_wide32_pipeline : runtime->lightonocr3_gate_up_wide64_pipeline;
        if (wide != nil && wide.threadExecutionWidth == 32 &&
            wide.maxTotalThreadsPerThreadgroup >= (rows < 32 ? 64u : 128u) &&'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
p=Path('zig/pkg/inference/src/architectures/gpt.zig');s=p.read_text()
old='''            if ((total >= 1 and total <= 8) and config.hasQwen35VisionArchitectureContract() and'''
new='''            if (total >= 1 and (total <= 8 or
                (isDecodeStep(decode_context) and total <= 64 and (hidden_size != 2560 or total < 64))) and
                config.hasQwen35VisionArchitectureContract() and'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text()
old='const lighton = self.lightonocr3_projections and request.rows >= 1 and request.rows <= 16 and'
assert s.count(old)==1;s=s.replace(old,old.replace('<= 16','<= 64'));p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text()
old='const preferred_items = @min(if (lighton_reader) effectiveLightOnReadWindow() else @as(usize, 8), max_items);'
new='''const preferred_items = @min(if (lighton_reader) effectiveLightOnReadWindow() else if (native_reader) effectiveNativeReadBatchSize() else @as(usize, 8), max_items);'''
assert s.count(old)==1;s=s.replace(old,new)
a=s.index('test "standalone inference model catalog publishes resolved native reader batching"')
b=s.index('\ntest ',a+10);part=s[a:b]
needle='    try std.testing.expectEqual(@as(i64, 32 * 1024 * 1024), resolved.object.get("batch").?.object.get("max_encoded_media_bytes").?.integer);'
assert part.count(needle)==1
part=part.replace(needle,'''    if (expected_native) try std.testing.expectEqual(
        resolved.object.get("batch").?.object.get("max_items").?.integer,
        resolved.object.get("batch").?.object.get("preferred_items").?.integer,
    );
'''+needle);s=s[:a]+part+s[b:]
needle='    try Node.benchmarkConcurrentOcr(&node, model_dir, fixture, @intCast(request.max_tokens.?));'
assert s.count(needle)==1
s=s.replace(needle,(Path('.venv-lighton-vllm-metal/engine45_real_raster_parity.inc').read_text())+needle)
p.write_text(s)
p=Path('zig/pkg/inference/src/pipelines/reading.zig');s=p.read_text()
needle='''    fn readBatchNativeFlorencePixels(
        self: *ReadingPipeline,
        pixel_values: []const f32,
        batch: usize,
        florence_cfg: florence_arch.Config,
        debug_cuda_session: bool,
    ) ![]ReadResult {'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''
        defer if (platform.env.getenvBool("ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX"))
            std.debug.print("FLORENCE2 batch_items={d}\\n", .{batch});''')
p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text()
s=s.replace('if not 1 <= args.native_read_batch_size <= 8:', 'if not 1 <= args.native_read_batch_size <= 64:')
s=s.replace('parser.error("native read batch size must be 1..8")','parser.error("native read batch size must be 1..64")')
needle='            "ANTFLY_OCR_ENCODER_SCOPES",'
assert s.count(needle)==1;s=s.replace(needle,needle+'\n            "ANTFLY_FLORENCE_CPU_PREPROCESS",')
needle='    env["ANTFLY_OCR_ENCODER_SCOPES"] = "1" if args.ocr_encoder_scopes else "0"'
assert s.count(needle)==1;s=s.replace(needle,needle+'''
    env["ANTFLY_FLORENCE_CPU_PREPROCESS"] = "1" if args.florence_cpu_preprocess else "0"''')
needle='    parser.add_argument("--gpu-greedy-stream", action="store_true")'
assert s.count(needle)==1;s=s.replace(needle,needle+'\n    parser.add_argument("--florence-cpu-preprocess", action="store_true")')
p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text()
a=s.index('static int wide_gate_up_check(');b=s.index('\nstatic ',a+10);part=s[a:b]
old='''bool qualified = rows >= 32 && rows <= 64 && (in == 1024 ||
            (in == 2560 && termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP"))));'''
new='''bool qualified = (rows >= 32 && rows <= 64 && in == 1024) ||
            (rows >= 17 && rows < 64 && in == 2560 &&
                termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP")));'''
assert part.count(old)==1;part=part.replace(old,new)
old='''        if (!qualified) {
            free(gold);
            return 0;
        }
''';assert part.count(old)==1;part=part.replace(old,'')
a2=part.index('                if (mode == 0) {');b2=part.index('                if (termite_metal_decode_runtime_submit_frame(r)',a2)
part=part[:a2]+'''                if (mode == 1) {
                    memset(x.contents, 0, x.length);
                    if (termite_metal_decode_runtime_begin_planned_compute_scope(
                            r, TERMITE_METAL_COMPUTE_SOURCE_FFN, TERMITE_METAL_COMPUTE_REGION_FFN) ||
                        termite_metal_decode_runtime_apply_add_device(r, (__bridge void *)source, 16,
                                                                      (__bridge void *)zero, 16,
                                                                      rows * in, (__bridge void *)x, 16))
                        return 72;
                } else if (mode == 2)
                    setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP", "1", 1);
                // Intermediate rows have no generic fused kernel. Its rollback
                // must use the actual separate-projection production route.
                const bool separate = mode == 0 || (rows < 32 && (mode == 2 || !qualified));
                if (separate) {
                    if (termite_metal_decode_runtime_apply_linear_multi_row_device(
                            r, 0, (__bridge void *)x, 16, rows, in, out, (__bridge void *)g, 0) ||
                        termite_metal_decode_runtime_apply_linear_multi_row_device(
                            r, 1, (__bridge void *)x, 16, rows, in, out, (__bridge void *)u, 0) ||
                        termite_metal_decode_runtime_apply_activation_multiply_device(
                            r, 2, (__bridge void *)g, 0, (__bridge void *)u, 0, rows, out, (__bridge void *)y, 16))
                        return 9;
                } else if (termite_metal_decode_runtime_apply_bf16_gate_up_device(
                            r, 0, 1, (__bridge void *)x, 16, rows, in, out, (__bridge void *)y, 16))
                    return 10;
                if (mode == 1 && termite_metal_decode_runtime_end_planned_compute_scope(r)) return 73;
                if (mode == 2) unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_WIDE_GATE_UP");
'''+part[b2:]
old='(mode == 1 ? 1u : 0u)';assert part.count(old)==1;part=part.replace(old,'(mode == 1 && qualified ? 1u : 0u)')
s=s[:a]+part+s[b:]
old='''            const size_t rows[] = {32, 33, 48, 56, 63, 64};
            if (termite_metal_lightonocr3_batch_gate_up_pipeline(r, 31, 2560, 9216) != nil ||
                termite_metal_lightonocr3_batch_gate_up_pipeline(r, 65, 2560, 9216) != nil ||'''
new='''            const size_t rows[] = {17, 19, 24, 31, 32, 33, 48, 56, 63, 64};
            const bool hybrid = termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP"));
            if ((termite_metal_lightonocr3_batch_gate_up_pipeline(r, 31, 2560, 9216) != nil) != hybrid ||
                termite_metal_lightonocr3_batch_gate_up_pipeline(r, 64, 2560, 9216) != nil ||
                termite_metal_lightonocr3_batch_gate_up_pipeline(r, 65, 2560, 9216) != nil ||'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s)
