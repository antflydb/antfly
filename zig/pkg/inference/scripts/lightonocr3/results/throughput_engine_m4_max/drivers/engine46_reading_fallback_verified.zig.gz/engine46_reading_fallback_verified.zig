// Copyright 2026 Antfly, Inc.
// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Vision2Seq document reading pipeline.
//
// Architecture: image preprocessing → vision encoder → text decoder.
// Processes document images and extracts text/structured content.
//
// Supported model layouts:
//   - vision_encoder.onnx (or encoder_model.onnx)
//   - decoder_model.onnx
//   - or a native Florence safetensors/GGUF directory
//   - preprocessor_config.json (image size, normalization)
//   - tokenizer.json
//   - config.json (model_type: florence2, etc.)

const std = @import("std");
const build_options = @import("build_options");
const platform = @import("antfly_platform");
const reader_config = @import("antfly_reader_config");
const session_factory = @import("../architectures/session_factory.zig");
const florence_arch = @import("../architectures/florence.zig");
const backends = @import("../backends/backends.zig");
const session_mod = @import("../backends/session.zig");
const ops = @import("../ops/ops.zig");
const tokenizer_mod = @import("inference_tokenizer");
const image = @import("image.zig");
const antfly_image = @import("antfly_image");

const CT = ops.CT;
const ComputeBackend = ops.ComputeBackend;

pub const ReadTelemetry = struct {
    resident_decoder: bool = false,
    kv_cache: bool = false,
    kv_cache_mode: ?[]const u8 = null,
    lm_head_path: ?[]const u8 = null,
    cuda_graph_replay: bool = false,
    cuda_graph_fallback_reason: ?[]const u8 = null,
    cuda_graph_capture_steps: usize = 0,
    cuda_graph_replay_steps: usize = 0,
    generated_tokens: ?usize = null,
};

threadlocal var last_read_telemetry: ReadTelemetry = .{};
threadlocal var active_read_profile_source_fingerprint: ?[]const u8 = null;

pub fn resetLastReadTelemetry() void {
    last_read_telemetry = .{};
}

pub fn lastReadTelemetry() ReadTelemetry {
    return last_read_telemetry;
}

pub const ReadConfig = struct {
    max_length: usize = 1024,
    image_size: usize = 384,
    image_seq_length: usize = 0,
    resample: image.Resample = .bilinear,
    decoder_start_token_id: i32 = 2,
    eos_token_id: i32 = 2,
    pad_token_id: i32 = 1,
    forced_bos_token_id: ?i32 = null,
    no_repeat_ngram_size: usize = 0,
    image_mean: [3]f32 = .{ 0.5, 0.5, 0.5 },
    image_std: [3]f32 = .{ 0.5, 0.5, 0.5 },
    pix2struct_max_patches: usize = 0,
    pix2struct_patch_height: usize = 0,
    pix2struct_patch_width: usize = 0,
    pix2struct_do_normalize: bool = false,
    prompt: ?[]const u8 = null,
    source_fingerprint: ?[]const u8 = null,
    preprocess_io: ?std.Io = null,
};

pub const ReadResult = struct {
    text: []const u8,
    allocator: std.mem.Allocator,

    pub fn deinit(self: *ReadResult) void {
        self.allocator.free(self.text);
    }
};

pub const BatchExecutionMode = enum { native, serial, fallback };

pub const ReadBatchResult = struct {
    results: []ReadResult,
    mode: BatchExecutionMode,
    native_batches: usize = 0,
    fallback_reason: ?[]const u8 = null,
};

/// Only the loaded native Metal reader can transfer GPU-lane ownership into
/// the pipeline. Standalone readers retain the existing serialized contract.
pub fn nativeFlorencePreprocessOverlapEnabled(session: backends.Session) bool {
    if (comptime !build_options.enable_metal) return false;
    return session.backend() == .metal and
        session_factory.getFlorenceConfig(session) != null and
        @import("../backends/metal_runtime.zig").qualifiedM4DeviceDefault() and
        platform.env.getenvBool("ANTFLY_FLORENCE_CPU_PREPROCESS");
}

const PreprocessScratchAdmission = struct {
    allocator: std.mem.Allocator,
    session: backends.Session,
    permits: std.ArrayListUnmanaged(session_mod.RunPermit) = .empty,

    fn descriptor(self: *@This()) image.ScratchAdmission {
        return .{ .context = self, .grow = growOpaque };
    }

    fn growOpaque(context: *anyopaque, current_bytes: usize, target_bytes: usize) anyerror!void {
        const self: *@This() = @ptrCast(@alignCast(context));
        if (target_bytes < current_bytes) return error.InvalidBatchPreprocessOptions;
        const additional = target_bytes - current_bytes;
        if (additional == 0) return;
        var permit = try self.session.admitHostPreprocess(additional);
        errdefer permit.deinit();
        try self.permits.append(self.allocator, permit);
    }

    pub fn deinit(self: *@This()) void {
        for (self.permits.items) |*permit| permit.deinit();
        self.permits.deinit(self.allocator);
        self.permits = .empty;
    }
};

pub const ReadingPipeline = struct {
    allocator: std.mem.Allocator,
    vision_encoder: backends.Session,
    decoder: backends.Session,
    tokenizer: tokenizer_mod.Tokenizer,
    config: ReadConfig,
    /// Immutable capability resolved for the loaded model generation.
    florence_final_logits_bias_zero: ?bool = null,
    execution_control: ?@import("../execution_control.zig").InferenceExecutionControl = null,
    /// Borrowed from the pinned model generation for the complete read.
    native_execution_lane: ?*@import("../execution_control.zig").ExecutionLane = null,

    fn admitPreprocessPixels(self: *ReadingPipeline, count: usize) !?session_mod.RunPermit {
        if (self.native_execution_lane == null) return null;
        return try self.vision_encoder.admitHostPreprocess(std.math.mul(usize, count, @sizeOf(f32)) catch return error.InvalidInputShape);
    }

    fn preprocessOptions(self: *ReadingPipeline, scratch: *PreprocessScratchAdmission) image.BatchPreprocessOptions {
        return .{
            .io = self.config.preprocess_io,
            .control = self.imageWorkControl(),
            .scratch_admission = if (self.native_execution_lane != null) scratch.descriptor() else null,
        };
    }

    fn preprocessEncodedBatchInto(self: *ReadingPipeline, pixels: []f32, images: []const []const u8) !void {
        var scratch = PreprocessScratchAdmission{ .allocator = self.allocator, .session = self.vision_encoder };
        defer scratch.deinit();
        try image.preprocessBatchIntoBounded(pixels, images, @intCast(self.config.image_size), self.config.image_mean, self.config.image_std, self.config.resample, self.preprocessOptions(&scratch));
    }

    fn preprocessRasterBatchInto(self: *ReadingPipeline, pixels: []f32, rasters: []const antfly_image.BorrowedRasterAttachment) !void {
        var scratch = PreprocessScratchAdmission{ .allocator = self.allocator, .session = self.vision_encoder };
        defer scratch.deinit();
        try image.preprocessBorrowedRasterBatchIntoWithOptions(self.allocator, pixels, rasters, @intCast(self.config.image_size), self.config.image_mean, self.config.image_std, self.config.resample, self.preprocessOptions(&scratch));
    }

    fn readBoundedNativeImage(self: *ReadingPipeline, bytes: []const u8) !ReadResult {
        const side = std.math.mul(usize, self.config.image_size, self.config.image_size) catch return error.InvalidInputShape;
        const count = std.math.mul(usize, side, 3) catch return error.InvalidInputShape;
        var permit = try self.admitPreprocessPixels(count);
        defer if (permit) |*owned| owned.deinit();
        const pixels = try self.allocator.alloc(f32, count);
        defer self.allocator.free(pixels);
        try self.preprocessEncodedBatchInto(pixels, &.{bytes});
        if (self.execution_control) |control| try control.check();
        return self.readPixelValues(pixels);
    }

    fn imageWorkControl(self: *ReadingPipeline) antfly_image.work_control.Control {
        return if (self.execution_control) |*control| control.imageWorkControl() else .{};
    }

    fn preprocessDecoded(self: *ReadingPipeline, decoded: image.Image) ![]f32 {
        const scope = antfly_image.work_control.Scope.enter(self.imageWorkControl());
        defer scope.deinit();
        return image.preprocessDecodedWithResample(self.allocator, decoded, @intCast(self.config.image_size), self.config.image_mean, self.config.image_std, self.config.resample);
    }

    pub fn init(
        allocator: std.mem.Allocator,
        vision_encoder: backends.Session,
        decoder: backends.Session,
        tokenizer: tokenizer_mod.Tokenizer,
        config: ReadConfig,
        florence_final_logits_bias_zero: ?bool,
    ) ReadingPipeline {
        return .{
            .allocator = allocator,
            .vision_encoder = vision_encoder,
            .decoder = decoder,
            .tokenizer = tokenizer,
            .config = config,
            .florence_final_logits_bias_zero = florence_final_logits_bias_zero,
        };
    }

    /// Count the exact textual tokens consumed by the reader encoder. Models
    /// without a textual reader input return zero; Florence uses the same
    /// normalization and BOS/EOS construction as every execution path below.
    pub fn inputTokenCount(self: *ReadingPipeline) !usize {
        if (expectsFlattenedPatches(self.vision_encoder)) return 0;
        const florence_cfg = session_factory.getFlorenceConfig(self.vision_encoder) orelse return 0;
        const prompt_text = self.config.prompt orelse "<OCR>";
        const prompt_ids = try buildFlorencePromptIds(
            self.allocator,
            self.tokenizer,
            florence_cfg,
            prompt_text,
        );
        defer self.allocator.free(prompt_ids);
        return prompt_ids.len;
    }

    fn florenceFinalLogitsBiasIsZero(
        self: *ReadingPipeline,
        cb: *const ComputeBackend,
        vocab_size: usize,
    ) !bool {
        if (self.florence_final_logits_bias_zero) |value| return value;
        return florence_arch.decoderFinalLogitsBiasIsZero(cb, self.allocator, vocab_size);
    }

    /// Read text from an image. image_data is raw JPEG/PNG bytes.
    pub fn read(self: *ReadingPipeline, image_data: []const u8) !ReadResult {
        var result = try self.readImageImpl(image_data);
        errdefer result.deinit();
        if (self.execution_control) |control| try control.check();
        return result;
    }

    fn readImageImpl(self: *ReadingPipeline, image_data: []const u8) !ReadResult {
        if (self.execution_control) |control| try control.update(.tokenizing, 0, 1);
        const previous_source_fingerprint = active_read_profile_source_fingerprint;
        active_read_profile_source_fingerprint = self.config.source_fingerprint;
        defer active_read_profile_source_fingerprint = previous_source_fingerprint;
        resetLastReadTelemetry();
        if (self.native_execution_lane != null) return self.readBoundedNativeImage(image_data);
        const allocator = self.allocator;
        const debug_cuda_session = platform.env.getenvBool("ANTFLY_INFERENCE_DEBUG_CUDA_SESSION");
        if (debug_cuda_session) std.log.info("reading: decode start bytes={d}", .{image_data.len});
        const decode_start = nowNs();
        const decoded = blk: {
            const scope = antfly_image.work_control.Scope.enter(self.imageWorkControl());
            defer scope.deinit();
            break :blk try image.decode(allocator, image_data);
        };
        logReadProfile("decode", decode_start);
        if (debug_cuda_session) std.log.info("reading: decode done", .{});
        defer decoded.deinit(allocator);

        if (expectsFlattenedPatches(self.vision_encoder)) {
            if (debug_cuda_session) std.log.info("reading: pix2struct path", .{});
            return self.readPix2StructDecoded(decoded);
        }

        const img_size: u32 = @intCast(self.config.image_size);
        if (debug_cuda_session) std.log.info("reading: preprocess start image_size={d}", .{img_size});
        const preprocess_start = nowNs();
        const pixel_values = try self.preprocessDecoded(decoded);
        logReadProfile("preprocess", preprocess_start);
        if (debug_cuda_session) std.log.info("reading: preprocess done pixels={d}", .{pixel_values.len});
        defer allocator.free(pixel_values);
        return self.readPixelValues(pixel_values);
    }

    /// Read text from a homogeneous image batch. Unsupported model families fall
    /// back to the existing serial path; native Florence uses a batched encoder
    /// and KV-decoder path where the selected backend supports it.
    pub fn readBatch(self: *ReadingPipeline, image_datas: []const []const u8) ![]ReadResult {
        var batch = try self.readBatchReportedImpl(image_datas);
        errdefer self.deinitBatchResult(&batch);
        if (self.execution_control) |control| try control.check();
        return batch.results;
    }

    /// Execute a read batch and report the path that actually completed. This
    /// deliberately reports after fallback, rather than repeating capability
    /// prediction at the caller.
    pub fn readBatchReported(self: *ReadingPipeline, image_datas: []const []const u8) !ReadBatchResult {
        var batch = try self.readBatchReportedImpl(image_datas);
        errdefer self.deinitBatchResult(&batch);
        if (self.execution_control) |control| try control.check();
        return batch;
    }

    fn readBatchReportedImpl(self: *ReadingPipeline, image_datas: []const []const u8) !ReadBatchResult {
        if (self.execution_control) |control| try control.check();
        const previous_source_fingerprint = active_read_profile_source_fingerprint;
        active_read_profile_source_fingerprint = self.config.source_fingerprint;
        defer active_read_profile_source_fingerprint = previous_source_fingerprint;
        const allocator = self.allocator;
        if (image_datas.len == 0) return .{ .results = try allocator.alloc(ReadResult, 0), .mode = .serial };
        if (image_datas.len == 1) {
            logReadBatchMode("single", image_datas, null);
            const out = try allocator.alloc(ReadResult, 1);
            errdefer allocator.free(out);
            out[0] = try self.read(image_datas[0]);
            return .{ .results = out, .mode = .serial };
        }
        if (expectsFlattenedPatches(self.vision_encoder)) {
            logReadBatchMode("serial", image_datas, "flattened_patches_model");
            return .{ .results = try self.readBatchSerial(image_datas), .mode = .serial };
        }

        if (session_factory.getFlorenceConfig(self.vision_encoder) != null) {
            const max_batch = nativeFlorenceReadBatchSize();
            if (max_batch <= 1) {
                logReadBatchMode("serial", image_datas, "configured_batch_size_one");
                return .{ .results = try self.readBatchSerial(image_datas), .mode = .serial };
            }
            const backend = self.vision_encoder.backend();
            const results = self.readBatchNativeFlorenceChunked(image_datas) catch |err| {
                if (!shouldFallbackFlorenceBatchToSerial(backend, err)) return err;
                logReadBatchMode("serial_fallback", image_datas, @errorName(err));
                return .{
                    .results = try self.readBatchSerial(image_datas),
                    .mode = .fallback,
                    .fallback_reason = @errorName(err),
                };
            };
            return .{
                .results = results,
                .mode = .native,
                .native_batches = std.math.divCeil(usize, image_datas.len, max_batch) catch unreachable,
            };
        }

        logReadBatchMode("serial", image_datas, "non_florence_model");
        return .{ .results = try self.readBatchSerial(image_datas), .mode = .serial };
    }

    /// Execute directly from renderer-owned RGBA views. Only the qualified
    /// native Florence reader exposes this contract; callers must retain an
    /// encoded fallback for every other model family or remote executor.
    pub fn readBorrowedRasterBatchReported(
        self: *ReadingPipeline,
        rasters: []const antfly_image.BorrowedRasterAttachment,
    ) !ReadBatchResult {
        var batch = try self.readBorrowedRasterBatchReportedImpl(rasters);
        errdefer self.deinitBatchResult(&batch);
        if (self.execution_control) |control| try control.check();
        return batch;
    }

    fn readBorrowedRasterBatchReportedImpl(
        self: *ReadingPipeline,
        rasters: []const antfly_image.BorrowedRasterAttachment,
    ) !ReadBatchResult {
        if (self.execution_control) |control| try control.check();
        const previous_source_fingerprint = active_read_profile_source_fingerprint;
        active_read_profile_source_fingerprint = self.config.source_fingerprint;
        defer active_read_profile_source_fingerprint = previous_source_fingerprint;
        const allocator = self.allocator;
        if (session_factory.getFlorenceConfig(self.vision_encoder) == null or
            expectsFlattenedPatches(self.vision_encoder))
            return error.BorrowedRasterUnsupported;
        if (rasters.len == 0)
            return .{ .results = try allocator.alloc(ReadResult, 0), .mode = .serial };
        for (rasters) |raster| try raster.validate();
        if (rasters.len == 1) {
            logBorrowedRasterBatchMode("single", rasters, null);
            return .{
                .results = try self.readBorrowedRasterSerial(rasters),
                .mode = .serial,
            };
        }

        const max_batch = nativeFlorenceReadBatchSize();
        if (max_batch <= 1) {
            logBorrowedRasterBatchMode("serial", rasters, "configured_batch_size_one");
            return .{
                .results = try self.readBorrowedRasterSerial(rasters),
                .mode = .serial,
            };
        }
        const backend = self.vision_encoder.backend();
        const results = self.readBorrowedRasterBatchNativeChunked(rasters) catch |err| {
            if (!shouldFallbackFlorenceBatchToSerial(backend, err)) return err;
            logBorrowedRasterBatchMode("serial_fallback", rasters, @errorName(err));
            return .{
                .results = try self.readBorrowedRasterSerial(rasters),
                .mode = .fallback,
                .fallback_reason = @errorName(err),
            };
        };
        return .{
            .results = results,
            .mode = .native,
            .native_batches = std.math.divCeil(usize, rasters.len, max_batch) catch unreachable,
        };
    }

    fn deinitBatchResult(self: *ReadingPipeline, batch: *ReadBatchResult) void {
        for (batch.results) |*result| result.deinit();
        self.allocator.free(batch.results);
    }

    fn readBorrowedRasterSerial(
        self: *ReadingPipeline,
        rasters: []const antfly_image.BorrowedRasterAttachment,
    ) ![]ReadResult {
        const out = try self.allocator.alloc(ReadResult, rasters.len);
        var filled: usize = 0;
        errdefer {
            for (out[0..filled]) |*result| result.deinit();
            self.allocator.free(out);
        }
        for (rasters, out) |raster, *result| {
            result.* = try self.readBorrowedRaster(raster);
            filled += 1;
        }
        return out;
    }

    fn readBorrowedRaster(
        self: *ReadingPipeline,
        raster: antfly_image.BorrowedRasterAttachment,
    ) !ReadResult {
        resetLastReadTelemetry();
        const img_size: u32 = @intCast(self.config.image_size);
        const per_image_side = std.math.mul(usize, img_size, img_size) catch
            return error.InvalidInputShape;
        const count = std.math.mul(usize, per_image_side, 3) catch return error.InvalidInputShape;
        var host_pixels = try self.admitPreprocessPixels(count);
        defer if (host_pixels) |*permit| permit.deinit();
        const pixel_values = try self.allocator.alloc(f32, count);
        defer self.allocator.free(pixel_values);
        try self.preprocessRasterBatchInto(pixel_values, &.{raster});
        return self.readPixelValues(pixel_values);
    }

    fn readBorrowedRasterBatchNativeChunked(
        self: *ReadingPipeline,
        rasters: []const antfly_image.BorrowedRasterAttachment,
    ) ![]ReadResult {
        const max_batch = nativeFlorenceReadBatchSize();
        logBorrowedRasterBatchMode(
            if (rasters.len > max_batch) "native_florence_chunked" else "native_florence",
            rasters,
            null,
        );
        const out = try self.allocator.alloc(ReadResult, rasters.len);
        var filled: usize = 0;
        errdefer {
            for (out[0..filled]) |*result| result.deinit();
            self.allocator.free(out);
        }
        var offset: usize = 0;
        while (offset < rasters.len) {
            const chunk_len = @min(max_batch, rasters.len - offset);
            const chunk_results = try self.readBorrowedRasterBatchNative(
                rasters[offset..][0..chunk_len],
            );
            if (chunk_results.len != chunk_len) {
                for (chunk_results) |*result| result.deinit();
                self.allocator.free(chunk_results);
                return error.InvalidReadResultCount;
            }
            {
                defer self.allocator.free(chunk_results);
                for (chunk_results, 0..) |result, i| out[offset + i] = result;
            }
            filled += chunk_results.len;
            offset += chunk_len;
        }
        return out;
    }

    fn readBorrowedRasterBatchNative(
        self: *ReadingPipeline,
        rasters: []const antfly_image.BorrowedRasterAttachment,
    ) ![]ReadResult {
        const florence_cfg = session_factory.getFlorenceConfig(self.vision_encoder) orelse
            return error.BorrowedRasterUnsupported;
        const batch = rasters.len;
        const img_size: u32 = @intCast(self.config.image_size);
        const ts: usize = img_size;
        const per_image_side = std.math.mul(usize, ts, ts) catch return error.InvalidInputShape;
        const per_image = std.math.mul(usize, 3, per_image_side) catch return error.InvalidInputShape;
        const pixel_count = std.math.mul(usize, batch, per_image) catch return error.InvalidInputShape;
        var host_pixels = try self.admitPreprocessPixels(pixel_count);
        defer if (host_pixels) |*permit| permit.deinit();
        const pixel_values = try self.allocator.alloc(f32, pixel_count);
        defer self.allocator.free(pixel_values);
        resetLastReadTelemetry();
        try self.preprocessRasterBatchInto(pixel_values, rasters);
        return self.readBatchNativeFlorencePixels(
            pixel_values,
            batch,
            florence_cfg,
            platform.env.getenvBool("ANTFLY_INFERENCE_DEBUG_CUDA_SESSION"),
        );
    }

    fn readBatchSerial(self: *ReadingPipeline, image_datas: []const []const u8) ![]ReadResult {
        const allocator = self.allocator;
        const out = try allocator.alloc(ReadResult, image_datas.len);
        var filled: usize = 0;
        errdefer {
            for (out[0..filled]) |*result| result.deinit();
            allocator.free(out);
        }

        for (image_datas, 0..) |image_data, i| {
            out[i] = try self.read(image_data);
            filled += 1;
        }
        return out;
    }

    fn readBatchNativeFlorenceChunked(self: *ReadingPipeline, image_datas: []const []const u8) ![]ReadResult {
        const allocator = self.allocator;
        const max_batch = nativeFlorenceReadBatchSize();
        if (max_batch <= 1) {
            logReadBatchMode("serial", image_datas, "configured_batch_size_one");
            return self.readBatchSerial(image_datas);
        }
        logReadBatchMode(if (image_datas.len > max_batch) "native_florence_chunked" else "native_florence", image_datas, null);

        const out = try allocator.alloc(ReadResult, image_datas.len);
        var filled: usize = 0;
        errdefer {
            for (out[0..filled]) |*result| result.deinit();
            allocator.free(out);
        }

        var offset: usize = 0;
        while (offset < image_datas.len) {
            if (self.execution_control) |control| try control.update(.executing, offset, image_datas.len);
            const chunk_len = @min(max_batch, image_datas.len - offset);
            const chunk = image_datas[offset .. offset + chunk_len];
            const chunk_results = try self.readBatchNativeFlorence(chunk);
            if (chunk_results.len != chunk_len) {
                for (chunk_results) |*result| result.deinit();
                allocator.free(chunk_results);
                return error.InvalidReadResultCount;
            }
            {
                defer allocator.free(chunk_results);
                for (chunk_results, 0..) |result, i| {
                    out[offset + i] = result;
                }
            }
            filled += chunk_results.len;
            offset += chunk_len;
        }

        return out;
    }

    fn readBatchNativeFlorence(self: *ReadingPipeline, image_datas: []const []const u8) ![]ReadResult {
        const allocator = self.allocator;
        const florence_cfg = session_factory.getFlorenceConfig(self.vision_encoder) orelse return error.InvalidModelForReading;
        const batch = image_datas.len;
        if (batch == 0) return try allocator.alloc(ReadResult, 0);

        resetLastReadTelemetry();
        const debug_cuda_session = platform.env.getenvBool("ANTFLY_INFERENCE_DEBUG_CUDA_SESSION");
        const img_size: u32 = @intCast(self.config.image_size);
        const ts: usize = @intCast(img_size);
        const per_image_side = std.math.mul(usize, ts, ts) catch return error.InvalidInputShape;
        const per_image = std.math.mul(usize, 3, per_image_side) catch return error.InvalidInputShape;
        const pixel_count = std.math.mul(usize, batch, per_image) catch return error.InvalidInputShape;
        var host_pixels = try self.admitPreprocessPixels(pixel_count);
        defer if (host_pixels) |*permit| permit.deinit();
        const pixel_values = try allocator.alloc(f32, pixel_count);
        defer allocator.free(pixel_values);

        if (self.execution_control) |control| try control.check();
        try self.preprocessEncodedBatchInto(pixel_values, image_datas);
        if (self.execution_control) |control| try control.check();

        return self.readBatchNativeFlorencePixels(
            pixel_values,
            batch,
            florence_cfg,
            debug_cuda_session,
        );
    }

    fn readBatchNativeFlorencePixels(
        self: *ReadingPipeline,
        pixel_values: []const f32,
        batch: usize,
        florence_cfg: florence_arch.Config,
        debug_cuda_session: bool,
    ) ![]ReadResult {
        defer if (platform.env.getenvBool("ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX"))
            std.debug.print("FLORENCE2 batch_items={d}\n", .{batch});
        const lane: ?@import("../execution_control.zig").ExecutionLane.Lease =
            if (self.native_execution_lane) |owner|
                try owner.acquire(self.execution_control orelse .{ .io = self.config.preprocess_io })
            else
                null;
        defer if (lane) |lease| lease.release();
        const allocator = self.allocator;
        var run_permit: ?session_mod.RunPermit = null;
        defer if (run_permit) |*permit| permit.deinit();
        var fallback_permit: ?session_mod.RunPermit = null;
        defer if (fallback_permit) |*permit| permit.deinit();

        const prompt_text = self.config.prompt orelse "<OCR>";
        const prompt_i32 = try buildFlorencePromptIds(
            allocator,
            self.tokenizer,
            florence_cfg,
            prompt_text,
        );
        defer allocator.free(prompt_i32);

        const prompt_len = prompt_i32.len;
        const prompt_total = std.math.mul(usize, batch, prompt_len) catch return error.InvalidInputShape;
        const prompt_i64 = try allocator.alloc(i64, prompt_total);
        defer allocator.free(prompt_i64);
        for (0..batch) |b| {
            for (prompt_i32, 0..) |id, i| prompt_i64[b * prompt_len + i] = id;
        }

        // Direct compute bypasses Session.run, so retain its admission permit
        // through both encoder/decoder execution and backend cleanup.
        const backend = self.vision_encoder.backend();
        const use_cached_decode = (backend == .native or backend == .cuda or backend == .metal) and
            !florenceKvCacheDisabled();
        const incremental_admission = if (comptime build_options.enable_metal)
            use_cached_decode and backend == .metal and
                @import("../backends/metal_runtime.zig").qualifiedM4DeviceDefault() and
                platform.env.getenvBoolDefault("ANTFLY_FLORENCE2_INCREMENTAL_ADMISSION", true)
        else
            false;
        const full_request = try nativeFlorenceRunRequest(florence_cfg, batch, pixel_values.len, prompt_i32.len, self.config.max_length);
        const request = if (incremental_admission)
            try nativeFlorenceIncrementalRunRequest(florence_cfg, batch, pixel_values.len, prompt_i32.len, self.config.max_length)
        else
            full_request;
        var fallback_attempts: usize = 0;
        var fallback_acquisitions: usize = 0;
        defer if (platform.env.getenvBool("ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX"))
            std.debug.print("FLORENCE2 incremental_admission={d} logits_rows={d} fallback_supplement_attempts={d} fallback_supplements_acquired={d}\n", .{ @intFromBool(incremental_admission), if (incremental_admission) @as(usize, 1) else @max(self.config.max_length, 1), fallback_attempts, fallback_acquisitions });
        run_permit = try self.vision_encoder.admit(request);

        var managed = try session_factory.getComputeBackendWithControl(self.vision_encoder, allocator, self.execution_control);
        defer managed.deinit();
        const cb = &managed.backend;

        if (debug_cuda_session) std.log.info("reading: native florence batch encoder start batch={d}", .{batch});
        const encoder_start = nowNs();
        const encoder = try florence_arch.encoderForwardTensor(
            cb,
            allocator,
            florence_cfg,
            pixel_values,
            batch,
            prompt_i64,
            prompt_len,
        );
        logReadProfile("batch_encoder", encoder_start);
        defer cb.free(encoder.hidden);

        const decode_start = nowNs();
        if (use_cached_decode) {
            last_read_telemetry.resident_decoder = true;
            last_read_telemetry.kv_cache = true;
            last_read_telemetry.cuda_graph_replay = false;
            last_read_telemetry.cuda_graph_fallback_reason = "batched_florence_kv_decode";
            const kv_result = self.decodeNativeFlorenceBatchIncrementalFromEncoder(cb, florence_cfg, encoder.hidden, batch, encoder.seq_len) catch |err| fallback: {
                if (!shouldFallbackFlorenceIncremental(backend, err)) return err;
                markFlorenceIncrementalFallback();
                break :fallback null;
            };
            if (kv_result) |result| {
                logReadProfile("batch_kv_decode_from_encoder", decode_start);
                return result;
            }
        }
        if (incremental_admission) {
            // No full-prefix decoder or logits allocation may start until its
            // additional peak is admitted. Keep both permits through backend
            // teardown; the existing KV reservation is never reduced.
            fallback_attempts += 1;
            fallback_permit = try admitFlorenceFullPrefixFallback(self.vision_encoder, &run_permit.?, full_request);
            fallback_acquisitions += 1;
        }
        if (platform.env.getenvBool("ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX"))
            std.debug.print("FLORENCE2 full_prefix_decode_started=1\n", .{});
        const result = try self.decodeNativeFlorenceBatchFromEncoder(cb, florence_cfg, encoder.hidden, batch, encoder.seq_len);
        logReadProfile("batch_decode_from_encoder", decode_start);
        return result;
    }

    fn decodeNativeFlorenceBatchIncrementalFromEncoder(
        self: *ReadingPipeline,
        cb: *const ComputeBackend,
        florence_cfg: florence_arch.Config,
        encoder_hidden: CT,
        batch: usize,
        enc_seq_len: usize,
    ) ![]ReadResult {
        const allocator = self.allocator;
        const max_len = self.config.max_length;
        const out = try allocator.alloc(ReadResult, batch);
        var filled: usize = 0;
        errdefer {
            for (out[0..filled]) |*result| result.deinit();
            allocator.free(out);
        }
        if (max_len == 0) {
            for (out) |*result| {
                result.* = .{ .text = try allocator.dupe(u8, ""), .allocator = allocator };
                filled += 1;
            }
            return out;
        }

        const dec_id_count = std.math.mul(usize, batch, max_len) catch return error.InvalidInputShape;
        const dec_ids = try allocator.alloc(i64, dec_id_count);
        defer allocator.free(dec_ids);
        @memset(dec_ids, @as(i64, self.config.pad_token_id));

        var lengths = try allocator.alloc(usize, batch);
        defer allocator.free(lengths);
        const finished = try allocator.alloc(bool, batch);
        defer allocator.free(finished);
        @memset(finished, false);

        var dec_len: usize = 1;
        for (0..batch) |b| {
            dec_ids[b * max_len] = @as(i64, self.config.decoder_start_token_id);
            lengths[b] = 1;
            if (self.config.forced_bos_token_id) |forced_bos| {
                if (max_len > 1) {
                    dec_ids[b * max_len + 1] = @as(i64, forced_bos);
                    lengths[b] = 2;
                    dec_len = 2;
                }
            }
        }

        const cache_start = nowNs();
        var cache = try florence_arch.buildDecoderIncrementalCache(cb, allocator, florence_cfg, encoder_hidden, batch, enc_seq_len, max_len);
        defer cache.deinit(cb, allocator);
        last_read_telemetry.kv_cache_mode = if (cache.self.preallocated) "batched_preallocated" else "batched_concat";
        logReadProfile("batch_florence_decoder_kv_cache_build", cache_start);

        var hidden_opt: ?CT = null;
        defer if (hidden_opt) |hidden| cb.free(hidden);

        const step_tokens = try allocator.alloc(i64, batch);
        defer allocator.free(step_tokens);
        const active_rows = try allocator.alloc(usize, batch);
        defer allocator.free(active_rows);
        const next_active_rows = try allocator.alloc(usize, batch);
        defer allocator.free(next_active_rows);
        const next_step_tokens = try allocator.alloc(i64, batch);
        defer allocator.free(next_step_tokens);
        const retained_cache_rows = try allocator.alloc(u32, batch);
        defer allocator.free(retained_cache_rows);
        for (active_rows, 0..) |*row, index| row.* = index;
        var active_count = batch;
        var row_compaction_supported = true;
        // An unmasked device winner is also the masked winner when the
        // page's no-repeat policy allows that token. Only rejected winners
        // need the existing full-logits host selection path.
        const checked_no_repeat_argmax = cb.kind() == .metal and
            !platform.env.getenvBool("ANTFLY_FLORENCE2_DISABLE_NO_REPEAT_ARGMAX");
        // The caller admits incremental or full-prefix logits and full KV.
        // A larger fallback peak is admitted before entering that decoder.
        // Token publication and row compaction follow frame completion.
        const single_frame = if (comptime build_options.enable_metal)
            checked_no_repeat_argmax and self.config.no_repeat_ngram_size > 0 and
                @import("../backends/metal_runtime.zig").qualifiedM4DeviceDefault() and
                platform.env.getenvBoolDefault("ANTFLY_FLORENCE2_SINGLE_FRAME", true) and
                !platform.env.getenvBool("TERMITE_FLORENCE2_METAL_DISABLE_FRAMES") and
                !platform.env.getenvBool("TERMITE_METAL_ENABLE_CONCURRENT_PLANNED_DISPATCH") and
                !readProfileEnabled() and !florenceDebugStats()
        else
            false;
        var owns_step_frame = false;
        defer if (owns_step_frame) cb.decoderRuntimeCancelFrame() catch {};
        var step_frame_start: u64 = 0;
        var frame_topology_mismatches: usize = 0;
        var single_frame_steps: usize = 0;
        var frame_api_fallbacks: usize = 0;
        defer if (self.config.no_repeat_ngram_size > 0 and platform.env.getenvBool("ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX")) {
            std.debug.print("FLORENCE2 single_frame_enabled={d} single_frame_steps={d} frame_api_fallbacks={d} frame_topology_mismatches={d}\n", .{ @intFromBool(single_frame), single_frame_steps, frame_api_fallbacks, frame_topology_mismatches });
        };
        var no_repeat_device_accepts: usize = 0;
        var no_repeat_cpu_fallbacks: usize = 0;
        defer if (self.config.no_repeat_ngram_size > 0 and platform.env.getenvBool("ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX")) {
            std.debug.print("FLORENCE2 no_repeat_argmax_enabled={d} device_accepts={d} cpu_fallbacks={d}\n", .{ @intFromBool(checked_no_repeat_argmax), no_repeat_device_accepts, no_repeat_cpu_fallbacks });
        };
        const fused_lm_head_allowed = if (self.config.no_repeat_ngram_size == 0)
            try self.florenceFinalLogitsBiasIsZero(cb, florence_cfg.vocab_size)
        else
            false;
        if (!fused_lm_head_allowed and last_read_telemetry.lm_head_path == null)
            last_read_telemetry.lm_head_path = if (self.config.no_repeat_ngram_size == 0)
                "batch_full_logits_bias"
            else if (checked_no_repeat_argmax)
                "batch_logits_checked_no_repeat"
            else
                "batch_full_logits_no_repeat";
        for (0..dec_len) |idx| {
            if (self.execution_control) |control| try control.update(.executing, idx, max_len);
            for (0..batch) |b| step_tokens[b] = dec_ids[b * max_len + idx];
            const prefix_step_start = nowNs();
            // Warm the first decoder step normally. A final forced prefix
            // token can then share a frame with its first generated token.
            if (idx > 0 and idx + 1 == dec_len) {
                owns_step_frame = try beginFlorenceStepFrame(cb, single_frame);
                if (owns_step_frame) step_frame_start = cb.debugTimingSnapshot().provider.decoder_runtime_frame_submits;
            }
            const hidden = try florence_arch.decoderForwardIncrementalBatchStepFinalHiddenTensor(
                cb,
                allocator,
                florence_cfg,
                step_tokens,
                &cache,
            );
            if (idx + 1 == dec_len) {
                hidden_opt = hidden;
            } else {
                cb.free(hidden);
            }
            logReadProfileStep("batch_florence_decoder_kv_prefix_step", idx + 1, idx + 1, nowNs() - prefix_step_start);
        }

        // Exercise cache/frame cleanup and the caller's supplemental admission
        // with real checkpoint tensors; this hook is absent from production.
        if (comptime @import("builtin").is_test) {
            if (platform.env.getenvBool("ANTFLY_TEST_FLORENCE2_INCREMENTAL_FALLBACK"))
                return error.UnsupportedOperation;
        }

        var finished_count: usize = 0;
        var decoder_run_total_ns: u64 = 0;
        var decoder_steps: usize = 0;
        while (dec_len < max_len and finished_count < batch) {
            if (self.execution_control) |control| try control.update(.executing, dec_len, max_len);
            {
                const hidden = hidden_opt orelse return error.InvalidInputShape;
                hidden_opt = null;
                var hidden_live = true;
                errdefer if (hidden_live) cb.free(hidden);

                var selected_on_device = false;
                if (fused_lm_head_allowed) {
                    if (try florence_arch.decoderFusedTokensFromFinalHiddenTensor(
                        cb,
                        allocator,
                        florence_cfg,
                        hidden,
                        active_count,
                        &.{},
                    )) |selected_tokens| {
                        defer allocator.free(selected_tokens);
                        cb.free(hidden);
                        hidden_live = false;
                        finished_count += try applyFlorenceBatchSelectedTokensActive(
                            dec_ids,
                            max_len,
                            dec_len,
                            finished,
                            lengths,
                            selected_tokens,
                            active_rows[0..active_count],
                            self.config.eos_token_id,
                            self.config.pad_token_id,
                            step_tokens[0..active_count],
                        );
                        selected_on_device = true;
                        if (last_read_telemetry.lm_head_path == null) {
                            // CUDA implements a true fused projection/reduction
                            // kernel. Metal currently keeps the operation on
                            // device but projects rows before argmax; report
                            // that distinction so telemetry never overstates
                            // the backend capability.
                            last_read_telemetry.lm_head_path = if (cb.kind() == .cuda)
                                "batch_fused_argmax"
                            else
                                "batch_projected_argmax";
                        }
                    }
                }
                if (!selected_on_device) {
                    const logits_tensor = try florence_arch.decoderLmHeadLogitsRowsFromFinalHiddenTensor(
                        cb,
                        allocator,
                        florence_cfg,
                        hidden,
                        active_count,
                    );
                    hidden_live = false;
                    defer cb.free(logits_tensor);
                    if (self.config.no_repeat_ngram_size == 0 or checked_no_repeat_argmax) {
                        const prior_frame_steps = single_frame_steps;
                        const selected = try florenceStepArgmaxRows(
                            cb,
                            logits_tensor,
                            active_count,
                            florence_cfg.vocab_size,
                            allocator,
                            &owns_step_frame,
                            &single_frame_steps,
                            &frame_api_fallbacks,
                        );
                        if (single_frame_steps > prior_frame_steps and
                            cb.debugTimingSnapshot().provider.decoder_runtime_frame_submits -| step_frame_start != 1)
                            frame_topology_mismatches += 1;
                        if (selected) |selected_tokens| {
                            defer allocator.free(selected_tokens);
                            if (florenceBatchArgmaxAllowedByNoRepeat(dec_ids, max_len, dec_len, active_rows[0..active_count], selected_tokens, self.config.no_repeat_ngram_size)) {
                                if (self.config.no_repeat_ngram_size > 0) no_repeat_device_accepts += 1;
                                finished_count += try applyFlorenceBatchSelectedTokensActive(
                                    dec_ids,
                                    max_len,
                                    dec_len,
                                    finished,
                                    lengths,
                                    selected_tokens,
                                    active_rows[0..active_count],
                                    self.config.eos_token_id,
                                    self.config.pad_token_id,
                                    step_tokens[0..active_count],
                                );
                                selected_on_device = true;
                                if (last_read_telemetry.lm_head_path == null)
                                    last_read_telemetry.lm_head_path = "batch_logits_argmax";
                            }
                        }
                    }
                    if (!selected_on_device) {
                        if (self.config.no_repeat_ngram_size > 0) no_repeat_cpu_fallbacks += 1;
                        const logits = try cb.toFloat32(logits_tensor, allocator);
                        defer allocator.free(logits);

                        finished_count += try applyFlorenceBatchGreedyStepActive(
                            dec_ids,
                            max_len,
                            dec_len,
                            finished,
                            lengths,
                            logits,
                            florence_cfg.vocab_size,
                            0,
                            florence_cfg.vocab_size,
                            active_rows[0..active_count],
                            self.config.eos_token_id,
                            self.config.pad_token_id,
                            self.config.no_repeat_ngram_size,
                            step_tokens[0..active_count],
                        );
                        if (last_read_telemetry.lm_head_path == null)
                            last_read_telemetry.lm_head_path = "batch_full_logits";
                    }
                }
            }

            dec_len += 1;
            decoder_steps += 1;
            if (dec_len < max_len and finished_count < batch) {
                if (row_compaction_supported) {
                    var next_active_count: usize = 0;
                    for (active_rows[0..active_count], 0..) |original_row, cache_row| {
                        if (finished[original_row]) continue;
                        retained_cache_rows[next_active_count] = @intCast(cache_row);
                        next_active_rows[next_active_count] = original_row;
                        next_step_tokens[next_active_count] = step_tokens[cache_row];
                        next_active_count += 1;
                    }
                    if (next_active_count < active_count) {
                        if (try florence_arch.compactDecoderIncrementalCache(
                            cb,
                            allocator,
                            florence_cfg,
                            &cache,
                            retained_cache_rows[0..next_active_count],
                        )) {
                            @memcpy(active_rows[0..next_active_count], next_active_rows[0..next_active_count]);
                            @memcpy(step_tokens[0..next_active_count], next_step_tokens[0..next_active_count]);
                            active_count = next_active_count;
                        } else {
                            row_compaction_supported = false;
                        }
                    }
                }
                const decoder_run_start = nowNs();
                owns_step_frame = try beginFlorenceStepFrame(cb, single_frame);
                if (owns_step_frame) step_frame_start = cb.debugTimingSnapshot().provider.decoder_runtime_frame_submits;
                hidden_opt = try florence_arch.decoderForwardIncrementalBatchStepFinalHiddenTensor(
                    cb,
                    allocator,
                    florence_cfg,
                    step_tokens[0..active_count],
                    &cache,
                );
                const decoder_run_ns = nowNs() - decoder_run_start;
                decoder_run_total_ns += decoder_run_ns;
                logReadProfileStep("batch_florence_decoder_kv_step", decoder_steps, dec_len, decoder_run_ns);
            }
        }
        logReadProfileStep("batch_florence_decoder_kv_run_total", decoder_steps, dec_len, decoder_run_total_ns);

        for (0..batch) |b| {
            const row = dec_ids[b * max_len ..][0..max_len];
            out[b] = try self.decodeGeneratedIds(row[0..lengths[b]], lengths[b]);
            filled += 1;
        }
        return out;
    }

    fn decodeNativeFlorenceBatchFromEncoder(
        self: *ReadingPipeline,
        cb: *const ComputeBackend,
        florence_cfg: florence_arch.Config,
        encoder_hidden: CT,
        batch: usize,
        enc_seq_len: usize,
    ) ![]ReadResult {
        const allocator = self.allocator;
        const max_len = self.config.max_length;
        const out = try allocator.alloc(ReadResult, batch);
        var filled: usize = 0;
        errdefer {
            for (out[0..filled]) |*result| result.deinit();
            allocator.free(out);
        }
        if (max_len == 0) {
            for (out, 0..) |*result, i| {
                _ = i;
                result.* = .{ .text = try allocator.dupe(u8, ""), .allocator = allocator };
                filled += 1;
            }
            return out;
        }

        const encoder_mask_len = std.math.mul(usize, batch, enc_seq_len) catch return error.InvalidInputShape;
        const encoder_attention_mask = try allocator.alloc(i64, encoder_mask_len);
        defer allocator.free(encoder_attention_mask);
        @memset(encoder_attention_mask, 1);

        const dec_id_count = std.math.mul(usize, batch, max_len) catch return error.InvalidInputShape;
        const dec_ids = try allocator.alloc(i64, dec_id_count);
        defer allocator.free(dec_ids);
        @memset(dec_ids, @as(i64, self.config.pad_token_id));

        var lengths = try allocator.alloc(usize, batch);
        defer allocator.free(lengths);
        const finished = try allocator.alloc(bool, batch);
        defer allocator.free(finished);
        @memset(finished, false);

        var dec_len: usize = 1;
        for (0..batch) |b| {
            dec_ids[b * max_len] = @as(i64, self.config.decoder_start_token_id);
            lengths[b] = 1;
            if (self.config.forced_bos_token_id) |forced_bos| {
                if (max_len > 1) {
                    dec_ids[b * max_len + 1] = @as(i64, forced_bos);
                    lengths[b] = 2;
                    dec_len = 2;
                }
            }
        }

        const decode_loop_start = nowNs();
        var decoder_run_total_ns: u64 = 0;
        var decoder_steps: usize = 0;
        var finished_count: usize = 0;
        while (dec_len < max_len and finished_count < batch) {
            if (self.execution_control) |control| try control.update(.executing, dec_len, max_len);
            {
                const decoder_input_ids = try compactDecoderInputIds(allocator, dec_ids, batch, max_len, dec_len);
                defer allocator.free(decoder_input_ids);

                const decoder_run_start = nowNs();
                const logits = try florence_arch.decoderForward(
                    cb,
                    allocator,
                    florence_cfg,
                    decoder_input_ids,
                    encoder_hidden,
                    encoder_attention_mask,
                    batch,
                    dec_len,
                    enc_seq_len,
                );
                const decoder_run_ns = nowNs() - decoder_run_start;
                decoder_run_total_ns += decoder_run_ns;
                decoder_steps += 1;
                logReadProfileStep("batch_decoder_run", decoder_steps, dec_len, decoder_run_ns);
                defer allocator.free(logits);

                const logits_row_stride = std.math.mul(usize, dec_len, florence_cfg.vocab_size) catch return error.InvalidInputShape;
                const logits_tail_offset = std.math.mul(usize, dec_len - 1, florence_cfg.vocab_size) catch return error.InvalidInputShape;
                finished_count += try applyFlorenceBatchGreedyStep(
                    dec_ids,
                    batch,
                    max_len,
                    dec_len,
                    finished,
                    lengths,
                    logits,
                    logits_row_stride,
                    logits_tail_offset,
                    florence_cfg.vocab_size,
                    self.config.eos_token_id,
                    self.config.pad_token_id,
                    self.config.no_repeat_ngram_size,
                    null,
                );
            }
            dec_len += 1;
        }
        logReadProfileStep("batch_decoder_total", decoder_steps, dec_len, nowNs() - decode_loop_start);
        logReadProfileStep("batch_decoder_run_total", decoder_steps, dec_len, decoder_run_total_ns);

        for (0..batch) |b| {
            const row = dec_ids[b * max_len ..][0..max_len];
            out[b] = try self.decodeGeneratedIds(row[0..lengths[b]], lengths[b]);
            filled += 1;
        }
        return out;
    }

    /// Read text from an already-decoded image crop.
    pub fn readDecoded(self: *ReadingPipeline, img: image.Image) !ReadResult {
        if (self.execution_control) |control| try control.update(.tokenizing, 0, 1);
        var result = try self.readDecodedImpl(img);
        errdefer result.deinit();
        if (self.execution_control) |control| try control.check();
        return result;
    }

    fn readDecodedImpl(self: *ReadingPipeline, img: image.Image) !ReadResult {
        resetLastReadTelemetry();
        if (expectsFlattenedPatches(self.vision_encoder)) {
            return self.readPix2StructDecoded(img);
        }

        const allocator = self.allocator;
        if (self.native_execution_lane != null) {
            const side = std.math.mul(usize, self.config.image_size, self.config.image_size) catch return error.InvalidInputShape;
            const count = std.math.mul(usize, side, 3) catch return error.InvalidInputShape;
            var permit = try self.admitPreprocessPixels(count);
            defer if (permit) |*owned| owned.deinit();
            const pixels = try allocator.alloc(f32, count);
            defer allocator.free(pixels);
            {
                var scratch = PreprocessScratchAdmission{ .allocator = allocator, .session = self.vision_encoder };
                defer scratch.deinit();
                try image.preprocessDecodedWithResampleIntoBounded(allocator, img, pixels, @intCast(self.config.image_size), self.config.image_mean, self.config.image_std, self.config.resample, self.preprocessOptions(&scratch));
            }
            return self.readPixelValues(pixels);
        }
        const pixel_values = try self.preprocessDecoded(img);
        defer allocator.free(pixel_values);
        return self.readPixelValues(pixel_values);
    }

    fn readPixelValues(self: *ReadingPipeline, pixel_values: []const f32) !ReadResult {
        const lane: ?@import("../execution_control.zig").ExecutionLane.Lease =
            if (self.native_execution_lane) |owner|
                try owner.acquire(self.execution_control orelse .{ .io = self.config.preprocess_io })
            else
                null;
        defer if (lane) |lease| lease.release();
        const allocator = self.allocator;
        const debug_cuda_session = platform.env.getenvBool("ANTFLY_INFERENCE_DEBUG_CUDA_SESSION");
        const img_size: u32 = @intCast(self.config.image_size);

        // 1. Preprocess image: decode/resize/normalize → [1, 3, H, W] f32
        // 2. Run vision encoder
        const img_sz: i64 = @intCast(img_size);
        if (try self.readPixelValuesFlorenceResident(pixel_values)) |result| return result;

        const pv_shape = [_]i64{ 1, 3, img_sz, img_sz };
        if (debug_cuda_session) std.log.info("reading: pixel tensor init start", .{});
        var pv_tensor = try backends.Tensor.initFloat32(allocator, "pixel_values", &pv_shape, pixel_values);
        if (debug_cuda_session) std.log.info("reading: pixel tensor init done", .{});
        defer pv_tensor.deinit();

        const encoder_outputs = if (session_factory.getFlorenceConfig(self.vision_encoder)) |florence_cfg| blk: {
            const prompt_text = self.config.prompt orelse "<OCR>";
            const prompt_i32 = try buildFlorencePromptIds(
                allocator,
                self.tokenizer,
                florence_cfg,
                prompt_text,
            );
            defer allocator.free(prompt_i32);

            break :blk try runFlorenceVisionEncoder(
                self.vision_encoder,
                allocator,
                pv_tensor,
                prompt_i32,
                self.execution_control,
            );
        } else blk: {
            if (self.execution_control) |control| try control.update(.executing, 0, 1);
            const outputs = try self.vision_encoder.runWithControl(&.{pv_tensor}, allocator, self.execution_control);
            break :blk outputs;
        };
        if (debug_cuda_session) std.log.info("reading: vision encoder run done outputs={d}", .{encoder_outputs.len});
        defer {
            for (encoder_outputs) |*t| {
                var mt = t.*;
                mt.deinit();
            }
            allocator.free(encoder_outputs);
        }

        if (encoder_outputs.len == 0) return error.NoEncoderOutput;
        logTensorStatsF32("encoder_hidden(session)", encoder_outputs[0].asFloat32());
        if (debug_cuda_session) std.log.info("reading: decode from encoder outputs start", .{});
        const decode_start = nowNs();
        const result = try self.decodeFromEncoderOutputs(encoder_outputs, null);
        logReadProfile("decode_from_encoder", decode_start);
        return result;
    }

    fn runFlorenceVisionEncoder(
        vision_encoder: backends.Session,
        allocator: std.mem.Allocator,
        pixel_tensor: backends.Tensor,
        prompt_ids: []const i32,
        execution_control: ?@import("../execution_control.zig").InferenceExecutionControl,
    ) ![]backends.Tensor {
        const prompt_i64 = try allocator.alloc(i64, prompt_ids.len);
        defer allocator.free(prompt_i64);
        for (prompt_ids, 0..) |id, i| prompt_i64[i] = id;

        const prompt_shape = [_]i64{ 1, @intCast(prompt_ids.len) };
        var prompt_tensor = try backends.Tensor.initInt64(
            allocator,
            "input_ids",
            &prompt_shape,
            prompt_i64,
        );
        defer prompt_tensor.deinit();

        return vision_encoder.runWithControl(&.{ pixel_tensor, prompt_tensor }, allocator, execution_control);
    }

    fn readNativeFlorencePixelValues(self: *ReadingPipeline, pixel_values: []const f32, florence_cfg: florence_arch.Config) !ReadResult {
        const allocator = self.allocator;
        var run_permit: ?session_mod.RunPermit = null;
        defer if (run_permit) |*permit| permit.deinit();
        const debug_cuda_session = platform.env.getenvBool("ANTFLY_INFERENCE_DEBUG_CUDA_SESSION");
        const prompt_text = self.config.prompt orelse "<OCR>";
        if (debug_cuda_session) std.log.info("reading: native florence prompt ids start prompt={s}", .{prompt_text});
        const prompt_i32 = try buildFlorencePromptIds(
            allocator,
            self.tokenizer,
            florence_cfg,
            prompt_text,
        );
        if (debug_cuda_session) std.log.info("reading: native florence prompt ids done len={d}", .{prompt_i32.len});
        defer allocator.free(prompt_i32);

        const prompt_i64 = try allocator.alloc(i64, prompt_i32.len);
        defer allocator.free(prompt_i64);
        for (prompt_i32, 0..) |id, i| prompt_i64[i] = id;

        // Direct compute bypasses Session.run, so retain its admission permit
        // through both encoder/decoder execution and backend cleanup.
        run_permit = try self.vision_encoder.admit(try nativeFlorenceRunRequest(
            florence_cfg,
            1,
            pixel_values.len,
            prompt_i32.len,
            self.config.max_length,
        ));

        var managed = try session_factory.getComputeBackendWithControl(self.vision_encoder, allocator, self.execution_control);
        defer managed.deinit();
        const cb = &managed.backend;

        if (debug_cuda_session) std.log.info("reading: native florence encoder tensor run start", .{});
        const encoder_start = nowNs();
        const encoder = try florence_arch.encoderForwardTensor(
            cb,
            allocator,
            florence_cfg,
            pixel_values,
            1,
            prompt_i64,
            prompt_i64.len,
        );
        logReadProfile("encoder", encoder_start);
        if (debug_cuda_session) std.log.info("reading: native florence encoder tensor run done seq={d}", .{encoder.seq_len});
        defer cb.free(encoder.hidden);

        const decode_start = nowNs();
        const result = try self.decodeNativeFlorenceFromEncoder(cb, florence_cfg, encoder.hidden, encoder.seq_len);
        logReadProfile("decode_from_encoder", decode_start);
        return result;
    }

    fn decodeNativeFlorenceFromEncoder(
        self: *ReadingPipeline,
        cb: *const ComputeBackend,
        florence_cfg: florence_arch.Config,
        encoder_hidden: CT,
        enc_seq_len: usize,
    ) !ReadResult {
        const allocator = self.allocator;
        const encoder_attention_mask = try allocator.alloc(i64, enc_seq_len);
        defer allocator.free(encoder_attention_mask);
        @memset(encoder_attention_mask, 1);

        const max_len = self.config.max_length;
        if (max_len == 0) return .{ .text = try allocator.dupe(u8, ""), .allocator = allocator };
        var dec_ids = try allocator.alloc(i64, max_len);
        defer allocator.free(dec_ids);
        dec_ids[0] = self.config.decoder_start_token_id;
        var dec_len: usize = 1;
        if (self.config.forced_bos_token_id) |forced_bos| {
            if (max_len > 1) {
                dec_ids[1] = forced_bos;
                dec_len = 2;
            }
        }

        var cross_cache: ?florence_arch.DecoderCrossCache = null;
        defer {
            if (cross_cache) |*cache| cache.deinit(cb, allocator);
        }
        if (platform.env.getenvBool("ANTFLY_INFERENCE_FLORENCE_CROSS_KV_CACHE")) {
            const cache_start = nowNs();
            cross_cache = try florence_arch.buildDecoderCrossCache(cb, allocator, florence_cfg, encoder_hidden, 1, enc_seq_len);
            logReadProfile("decoder_cross_cache", cache_start);
        }

        const decode_loop_start = nowNs();
        var decoder_run_total_ns: u64 = 0;
        var decoder_steps: usize = 0;
        while (dec_len < max_len) {
            if (self.execution_control) |control| try control.update(.executing, dec_len, max_len);
            const decoder_run_start = nowNs();
            const logits = if (cross_cache) |*cache|
                try florence_arch.decoderForwardCached(
                    cb,
                    allocator,
                    florence_cfg,
                    dec_ids[0..dec_len],
                    encoder_attention_mask,
                    1,
                    dec_len,
                    enc_seq_len,
                    cache,
                )
            else
                try florence_arch.decoderForward(
                    cb,
                    allocator,
                    florence_cfg,
                    dec_ids[0..dec_len],
                    encoder_hidden,
                    encoder_attention_mask,
                    1,
                    dec_len,
                    enc_seq_len,
                );
            const decoder_run_ns = nowNs() - decoder_run_start;
            decoder_run_total_ns += decoder_run_ns;
            decoder_steps += 1;
            logReadProfileStep("decoder_run", decoder_steps, dec_len, decoder_run_ns);
            defer allocator.free(logits);

            const vocab_size = florence_cfg.vocab_size;
            const last_logits = logits[(dec_len - 1) * vocab_size ..][0..vocab_size];
            const best_id = selectGreedyToken(last_logits, dec_ids[0..dec_len], self.config.no_repeat_ngram_size);
            if (@as(i32, @intCast(best_id)) == self.config.eos_token_id) break;

            dec_ids[dec_len] = @intCast(best_id);
            dec_len += 1;
        }
        logReadProfileStep("decoder_total", decoder_steps, dec_len, nowNs() - decode_loop_start);
        logReadProfileStep("decoder_run_total", decoder_steps, dec_len, decoder_run_total_ns);

        const prefix_len: usize = if (self.config.forced_bos_token_id != null and dec_len > 1) 2 else 1;
        const text_len = if (dec_len > prefix_len) dec_len - prefix_len else 0;
        const token_ids = try allocator.alloc(i32, text_len);
        defer allocator.free(token_ids);
        for (0..text_len) |i| token_ids[i] = @intCast(dec_ids[prefix_len + i]);

        const text = try self.tokenizer.decode(allocator, token_ids);
        const cleaned = try cleanupPureText(allocator, text);
        allocator.free(text);
        return .{ .text = cleaned, .allocator = allocator };
    }

    fn readPixelValuesFlorenceResident(self: *ReadingPipeline, pixel_values: []const f32) !?ReadResult {
        const backend = self.vision_encoder.backend();
        if (backend != .native and backend != .metal and backend != .cuda) return null;
        if (self.vision_encoder.vtable != self.decoder.vtable or self.vision_encoder.ptr != self.decoder.ptr) return null;

        const florence_cfg = session_factory.getFlorenceConfig(self.vision_encoder) orelse return null;
        last_read_telemetry.resident_decoder = true;
        const allocator = self.allocator;
        var run_permit: ?session_mod.RunPermit = null;
        defer if (run_permit) |*permit| permit.deinit();

        const prompt_text = self.config.prompt orelse "<OCR>";
        const prompt_i32 = try buildFlorencePromptIds(
            allocator,
            self.tokenizer,
            florence_cfg,
            prompt_text,
        );
        defer allocator.free(prompt_i32);

        const prompt_i64 = try allocator.alloc(i64, prompt_i32.len);
        defer allocator.free(prompt_i64);
        for (prompt_i32, 0..) |id, i| prompt_i64[i] = id;

        // Direct compute bypasses Session.run, so retain its admission permit
        // through both encoder/decoder execution and backend cleanup.
        run_permit = try self.vision_encoder.admit(try nativeFlorenceRunRequest(
            florence_cfg,
            1,
            pixel_values.len,
            prompt_i32.len,
            self.config.max_length,
        ));

        var managed = try session_factory.getComputeBackendWithControl(self.vision_encoder, allocator, self.execution_control);
        defer managed.deinit();
        const cb = &managed.backend;

        const encoder = (try session_factory.runFlorenceEncoderResident(
            self.vision_encoder,
            cb,
            allocator,
            pixel_values,
            1,
            prompt_i64,
            prompt_i64.len,
        )) orelse return null;
        defer cb.free(encoder.hidden);

        if (florenceDebugStats()) {
            const hidden_host = try cb.toFloat32(encoder.hidden, allocator);
            defer allocator.free(hidden_host);
            logTensorStatsF32("encoder_hidden(resident)", hidden_host);
        }

        const encoder_attention_mask = try allocator.alloc(i64, encoder.seq_len);
        defer allocator.free(encoder_attention_mask);
        @memset(encoder_attention_mask, 1);

        const max_len = self.config.max_length;
        if (max_len == 0) return .{ .text = try allocator.dupe(u8, ""), .allocator = allocator };
        var dec_ids = try allocator.alloc(i64, max_len);
        defer allocator.free(dec_ids);
        dec_ids[0] = self.config.decoder_start_token_id;
        var dec_len: usize = 1;
        if (self.config.forced_bos_token_id) |forced_bos| {
            if (max_len > 1) {
                dec_ids[1] = forced_bos;
                dec_len = 2;
            }
        }

        // Incremental KV-cache decode is default-on for every native Florence
        // compute backend; ANTFLY_INFERENCE_FLORENCE_DISABLE_KV_CACHE is the
        // explicit full-prefix kill switch.
        if (!florenceKvCacheDisabled()) {
            last_read_telemetry.kv_cache = true;
            last_read_telemetry.cuda_graph_replay = false;
            last_read_telemetry.cuda_graph_fallback_reason = if (florenceCudaGraphEnabled()) null else "florence_graph_disabled";
            const decode_start = nowNs();
            const result = self.decodeFlorenceResidentIncremental(
                cb,
                florence_cfg,
                encoder.hidden,
                encoder.seq_len,
                dec_ids,
                dec_len,
            ) catch |err| fallback: {
                if (!shouldFallbackFlorenceIncremental(backend, err)) return err;
                markFlorenceIncrementalFallback();
                break :fallback null;
            };
            if (result) |decoded| {
                logMetalStageTimingProfile(cb);
                logReadProfile("florence_resident_kv_decode", decode_start);
                return decoded;
            }
        }

        while (dec_len < max_len) {
            if (self.execution_control) |control| try control.update(.executing, dec_len, max_len);
            const logits = (try session_factory.runFlorenceDecoderResident(
                self.decoder,
                cb,
                allocator,
                dec_ids[0..dec_len],
                encoder.hidden,
                encoder_attention_mask,
                1,
                dec_len,
                encoder.seq_len,
            )) orelse return null;
            defer cb.free(logits);

            if (florenceDebugStats() and dec_len <= 5) {
                const logits_host = try cb.toFloat32(logits, allocator);
                defer allocator.free(logits_host);
                const last_row = logits_host[(dec_len - 1) * florence_cfg.vocab_size ..][0..florence_cfg.vocab_size];
                logTopLogits("logits(resident)", dec_len, last_row);
            }

            const suppress_tokens = try buildNoRepeatSuppressTokens(
                allocator,
                dec_ids[0..dec_len],
                self.config.no_repeat_ngram_size,
            );
            defer allocator.free(suppress_tokens);

            const best_id = if (suppress_tokens.len == 0) blk: {
                break :blk (try cb.argmaxLastRow(logits, dec_len, florence_cfg.vocab_size)) orelse return error.UnsupportedOperation;
            } else blk: {
                if (try cb.argmaxRowsSuppress(logits, dec_len - 1, 1, florence_cfg.vocab_size, suppress_tokens, allocator)) |tokens| {
                    defer allocator.free(tokens);
                    if (tokens.len != 1) return error.InvalidTensorShape;
                    break :blk tokens[0];
                }

                if (try cb.argmaxLastRowSuppressTensor(logits, dec_len, florence_cfg.vocab_size, suppress_tokens)) |token_tensor| {
                    defer cb.free(token_tensor);
                    const token_ids = try cb.toFloat32(token_tensor, allocator);
                    defer allocator.free(token_ids);
                    if (token_ids.len != 1 or token_ids[0] < 0) return error.InvalidTensorShape;
                    break :blk @as(u32, @intFromFloat(token_ids[0]));
                }

                return error.UnsupportedFlorence2NoRepeatMetal;
            };
            if (@as(i32, @intCast(best_id)) == self.config.eos_token_id) break;

            dec_ids[dec_len] = @intCast(best_id);
            dec_len += 1;
        }

        return try self.decodeGeneratedIds(dec_ids[0..dec_len], dec_len);
    }

    fn decodeFlorenceResidentIncremental(
        self: *ReadingPipeline,
        cb: *const ComputeBackend,
        florence_cfg: florence_arch.Config,
        encoder_hidden: CT,
        enc_seq_len: usize,
        dec_ids: []i64,
        initial_len: usize,
    ) !ReadResult {
        const allocator = self.allocator;
        const max_len = self.config.max_length;
        if (initial_len == 0 or initial_len > max_len or dec_ids.len < max_len) return error.InvalidInputShape;

        const cache_start = nowNs();
        var cache = try florence_arch.buildDecoderIncrementalCache(cb, allocator, florence_cfg, encoder_hidden, 1, enc_seq_len, max_len);
        defer cache.deinit(cb, allocator);
        last_read_telemetry.kv_cache_mode = if (cache.self.preallocated) "preallocated" else "concat";
        logReadProfile("florence_decoder_kv_cache_build", cache_start);

        const bias_check_start = nowNs();
        const fused_lm_head_allowed = try self.florenceFinalLogitsBiasIsZero(cb, florence_cfg.vocab_size);
        logReadProfile("florence_decoder_final_logits_bias_check", bias_check_start);
        if (!fused_lm_head_allowed and last_read_telemetry.lm_head_path == null) {
            last_read_telemetry.lm_head_path = "full_logits_bias";
        }

        var hidden_opt: ?CT = null;
        defer if (hidden_opt) |hidden| cb.free(hidden);

        var dec_len = initial_len;
        for (0..dec_len) |idx| {
            if (self.execution_control) |control| try control.update(.executing, idx, max_len);
            const prefix_step_start = nowNs();
            const hidden = try florence_arch.decoderForwardIncrementalStepFinalHiddenTensor(
                cb,
                allocator,
                florence_cfg,
                dec_ids[idx],
                &cache,
            );
            if (idx + 1 == dec_len) {
                hidden_opt = hidden;
            } else {
                cb.free(hidden);
            }
            logReadProfileStep("florence_decoder_kv_prefix_step", idx + 1, idx + 1, nowNs() - prefix_step_start);
        }

        var decoder_run_total_ns: u64 = 0;
        var decoder_steps: usize = 0;
        while (dec_len < max_len) {
            if (self.execution_control) |control| try control.update(.executing, dec_len, max_len);
            var hidden = hidden_opt orelse return error.InvalidInputShape;
            hidden_opt = null;
            var hidden_live = true;
            errdefer if (hidden_live) cb.free(hidden);
            decoder_steps += 1;

            const suppress_tokens = try buildNoRepeatSuppressTokens(
                allocator,
                dec_ids[0..dec_len],
                self.config.no_repeat_ngram_size,
            );
            var suppress_tokens_live = true;
            errdefer if (suppress_tokens_live) allocator.free(suppress_tokens);

            const best_id = try self.selectFlorenceTokenFromFinalHidden(
                cb,
                florence_cfg,
                &hidden,
                &hidden_live,
                suppress_tokens,
                fused_lm_head_allowed,
            );
            allocator.free(suppress_tokens);
            suppress_tokens_live = false;

            if (@as(i32, @intCast(best_id)) == self.config.eos_token_id) break;

            dec_ids[dec_len] = @intCast(best_id);
            dec_len += 1;
            if (dec_len < max_len) {
                const decoder_run_start = nowNs();
                hidden_opt = try florence_arch.decoderForwardIncrementalStepFinalHiddenTensor(
                    cb,
                    allocator,
                    florence_cfg,
                    dec_ids[dec_len - 1],
                    &cache,
                );
                const decoder_run_ns = nowNs() - decoder_run_start;
                decoder_run_total_ns += decoder_run_ns;
                logReadProfileStep("florence_decoder_kv_step", decoder_steps, dec_len, decoder_run_ns);
            }
        }
        logReadProfileStep("florence_decoder_kv_run_total", decoder_steps, dec_len, decoder_run_total_ns);

        const decode_ids_start = nowNs();
        const result = try self.decodeGeneratedIds(dec_ids[0..dec_len], dec_len);
        logReadProfile("florence_decoder_decode_ids", decode_ids_start);
        return result;
    }

    fn selectFlorenceTokenFromFinalHidden(
        self: *ReadingPipeline,
        cb: *const ComputeBackend,
        florence_cfg: florence_arch.Config,
        hidden: *CT,
        hidden_live: *bool,
        suppress_tokens: []const i32,
        fused_lm_head_allowed: bool,
    ) !u32 {
        const allocator = self.allocator;

        if (fused_lm_head_allowed) {
            var capture_graph = false;
            errdefer if (capture_graph) cb.debugCudaGraphCaptureEnd(false) catch {};
            if (florenceCudaGraphEnabled()) {
                if (suppress_tokens.len == 0) {
                    if (try cb.debugCudaGraphPrepareGreedyTokenReplayInput("florence.lm_head_argmax", hidden.*, 0)) |prepared| {
                        cb.free(hidden.*);
                        hidden.* = prepared;
                        hidden_live.* = true;
                        _ = try cb.debugCudaGraphPrepareDecodeScalars(0, 0, 0, 0, 0);
                        if (try cb.debugCudaGraphReplayFinalHidden(hidden.*)) |token_tensor| {
                            defer cb.free(token_tensor);
                            cb.free(hidden.*);
                            hidden_live.* = false;
                            last_read_telemetry.cuda_graph_replay = true;
                            last_read_telemetry.cuda_graph_replay_steps += 1;
                            last_read_telemetry.lm_head_path = "fused_argmax_graph";
                            return try tokenTensorToU32(cb, allocator, token_tensor);
                        }
                        capture_graph = try cb.debugCudaGraphCaptureBegin("florence.lm_head_argmax");
                        if (capture_graph) {
                            try cb.debugCudaTraceTensor("florence.lm_head_input", hidden.*);
                            try cb.debugCudaGraphRegisterFinalHiddenReplayInput(hidden.*);
                        } else if (last_read_telemetry.cuda_graph_fallback_reason == null) {
                            last_read_telemetry.cuda_graph_fallback_reason = "florence_graph_capture_unavailable";
                        }
                    } else if (last_read_telemetry.cuda_graph_fallback_reason == null) {
                        last_read_telemetry.cuda_graph_fallback_reason = "florence_graph_prepare_unavailable";
                    }
                } else if (last_read_telemetry.cuda_graph_fallback_reason == null) {
                    last_read_telemetry.cuda_graph_fallback_reason = "florence_graph_suppress_tokens_dynamic";
                }
            }
            const fused_start = nowNs();
            if (try florence_arch.decoderFusedTokenFromFinalHiddenTensor(cb, florence_cfg, hidden.*, suppress_tokens)) |token_tensor| {
                logReadProfile("florence_decoder_lm_head_fused_argmax", fused_start);
                defer cb.free(token_tensor);
                if (capture_graph) {
                    try cb.debugCudaGraphRegisterFinalHiddenReplayBoundary(hidden.*, token_tensor);
                    try cb.debugCudaGraphCaptureEnd(true);
                    last_read_telemetry.cuda_graph_capture_steps += 1;
                    capture_graph = false;
                }
                cb.free(hidden.*);
                hidden_live.* = false;
                if (last_read_telemetry.lm_head_path == null) last_read_telemetry.lm_head_path = "fused_argmax";
                return try tokenTensorToU32(cb, allocator, token_tensor);
            }
            logReadProfile("florence_decoder_lm_head_fused_unavailable", fused_start);
            if (capture_graph) {
                try cb.debugCudaGraphCaptureEnd(false);
                capture_graph = false;
            }
            if (last_read_telemetry.lm_head_path == null) last_read_telemetry.lm_head_path = "full_logits_fused_unavailable";
        }

        const logits = try florence_arch.decoderLmHeadLogitsFromFinalHiddenTensor(cb, allocator, florence_cfg, hidden.*);
        hidden_live.* = false;
        defer cb.free(logits);

        if (suppress_tokens.len == 0) {
            if (last_read_telemetry.lm_head_path == null) last_read_telemetry.lm_head_path = "full_logits";
            const token = (try cb.argmaxLastRow(logits, 1, florence_cfg.vocab_size)) orelse return error.UnsupportedOperation;
            return token;
        }

        if (try cb.argmaxRowsSuppress(logits, 0, 1, florence_cfg.vocab_size, suppress_tokens, allocator)) |tokens| {
            defer allocator.free(tokens);
            if (tokens.len != 1) return error.InvalidTensorShape;
            if (last_read_telemetry.lm_head_path == null) last_read_telemetry.lm_head_path = "full_logits";
            return tokens[0];
        }

        if (try cb.argmaxLastRowSuppressTensor(logits, 1, florence_cfg.vocab_size, suppress_tokens)) |token_tensor| {
            defer cb.free(token_tensor);
            if (last_read_telemetry.lm_head_path == null) last_read_telemetry.lm_head_path = "full_logits";
            return try tokenTensorToU32(cb, allocator, token_tensor);
        }

        return error.UnsupportedFlorence2NoRepeatMetal;
    }

    fn readPix2StructDecoded(self: *ReadingPipeline, img: image.Image) !ReadResult {
        const allocator = self.allocator;
        const patch_height = if (self.config.pix2struct_patch_height > 0) self.config.pix2struct_patch_height else 16;
        const patch_width = if (self.config.pix2struct_patch_width > 0) self.config.pix2struct_patch_width else 16;
        const max_patches = if (self.config.pix2struct_max_patches > 0) self.config.pix2struct_max_patches else 2048;

        var patches = blk: {
            const scope = antfly_image.work_control.Scope.enter(self.imageWorkControl());
            defer scope.deinit();
            break :blk try image.preprocessDecodedPix2Struct(
                allocator,
                img,
                patch_height,
                patch_width,
                max_patches,
                self.config.pix2struct_do_normalize,
                self.config.resample,
            );
        };
        defer patches.deinit();

        const feature_depth = 2 + patch_height * patch_width * 3;
        const patch_shape = [_]i64{ 1, @intCast(max_patches), @intCast(feature_depth) };
        var patch_tensor = try backends.Tensor.initFloat32(allocator, "flattened_patches", &patch_shape, patches.flattened_patches);
        defer patch_tensor.deinit();

        const mask_shape = [_]i64{ 1, @intCast(max_patches) };
        var mask_tensor = try backends.Tensor.initInt64(allocator, "attention_mask", &mask_shape, patches.attention_mask);
        defer mask_tensor.deinit();

        const inputs = if (hasInput(self.vision_encoder, "attention_mask"))
            &[_]backends.Tensor{ patch_tensor, mask_tensor }
        else
            &[_]backends.Tensor{patch_tensor};

        const encoder_outputs = try self.vision_encoder.runWithControl(inputs, allocator, self.execution_control);
        defer {
            for (encoder_outputs) |*t| {
                var mt = t.*;
                mt.deinit();
            }
            allocator.free(encoder_outputs);
        }
        if (encoder_outputs.len == 0) return error.NoEncoderOutput;

        return self.decodeFromEncoderOutputs(encoder_outputs, patches.attention_mask);
    }

    fn decodeFromEncoderOutputs(
        self: *ReadingPipeline,
        encoder_outputs: []const backends.Tensor,
        encoder_attention_mask_opt: ?[]const i64,
    ) !ReadResult {
        const allocator = self.allocator;
        const encoder_hidden = &encoder_outputs[0];

        const enc_seq_len: usize = if (encoder_hidden.shape.len >= 2) @intCast(encoder_hidden.shape[1]) else 1;
        const encoder_attention_mask = if (encoder_attention_mask_opt) |mask|
            mask
        else blk: {
            const all_ones = try allocator.alloc(i64, enc_seq_len);
            @memset(all_ones, 1);
            break :blk all_ones;
        };
        defer if (encoder_attention_mask_opt == null) allocator.free(encoder_attention_mask);

        // 3. Autoregressive decode
        const max_len = self.config.max_length;
        if (max_len == 0) return .{ .text = try allocator.dupe(u8, ""), .allocator = allocator };
        var dec_ids = try allocator.alloc(i64, max_len);
        defer allocator.free(dec_ids);
        dec_ids[0] = self.config.decoder_start_token_id;
        var dec_len: usize = 1;
        if (self.config.forced_bos_token_id) |forced_bos| {
            if (max_len > 1) {
                dec_ids[1] = forced_bos;
                dec_len = 2;
            }
        }

        const decode_loop_start = nowNs();
        var decoder_run_total_ns: u64 = 0;
        var decoder_steps: usize = 0;
        while (dec_len < max_len) {
            // Build decoder input tensors
            const dec_seq: i64 = @intCast(dec_len);
            const dec_shape = [_]i64{ 1, dec_seq };

            var decoder_inputs = std.ArrayListUnmanaged(backends.Tensor).empty;
            defer {
                for (decoder_inputs.items) |*tensor| tensor.deinit();
                decoder_inputs.deinit(allocator);
            }

            try decoder_inputs.append(
                allocator,
                try backends.Tensor.initInt64(allocator, "input_ids", &dec_shape, dec_ids[0..dec_len]),
            );

            if (hasInput(self.decoder, "encoder_attention_mask")) {
                const enc_mask_shape = [_]i64{ 1, @intCast(enc_seq_len) };
                try decoder_inputs.append(
                    allocator,
                    try backends.Tensor.initInt64(allocator, "encoder_attention_mask", &enc_mask_shape, encoder_attention_mask),
                );
            }
            if (hasInput(self.decoder, "decoder_attention_mask")) {
                const dec_mask = try allocator.alloc(i64, dec_len);
                defer allocator.free(dec_mask);
                @memset(dec_mask, 1);
                try decoder_inputs.append(
                    allocator,
                    try backends.Tensor.initInt64(allocator, "decoder_attention_mask", &dec_shape, dec_mask),
                );
            }

            const enc_hidden = encoder_outputs[0].borrowedView("encoder_hidden_states");
            try decoder_inputs.append(allocator, enc_hidden);

            const decoder_run_start = nowNs();
            if (self.execution_control) |control| try control.update(.executing, @intCast(dec_len), @intCast(max_len));
            const dec_outputs = try self.decoder.runWithControl(
                decoder_inputs.items,
                allocator,
                self.execution_control,
            );
            const decoder_run_ns = nowNs() - decoder_run_start;
            decoder_run_total_ns += decoder_run_ns;
            decoder_steps += 1;
            logReadProfileStep("decoder_run", decoder_steps, dec_len, decoder_run_ns);
            defer {
                for (dec_outputs) |*t| {
                    var mt = t.*;
                    mt.deinit();
                }
                allocator.free(dec_outputs);
            }

            if (dec_outputs.len == 0) return error.NoDecoderOutput;

            // Get logits for last position
            const logits = dec_outputs[0].asFloat32();
            const vocab_size = if (dec_outputs[0].shape.len >= 3)
                @as(usize, @intCast(dec_outputs[0].shape[2]))
            else
                return error.InvalidLogitsShape;

            // Last position logits
            const last_logits = logits[(dec_len - 1) * vocab_size ..][0..vocab_size];
            if (decoder_steps <= 4) logTopLogits("logits(session)", decoder_steps, last_logits);

            // Greedy: argmax
            const best_id = selectGreedyToken(last_logits, dec_ids[0..dec_len], self.config.no_repeat_ngram_size);

            // Check for EOS
            if (@as(i32, @intCast(best_id)) == self.config.eos_token_id) break;

            dec_ids[dec_len] = @intCast(best_id);
            dec_len += 1;
        }
        logReadProfileStep("decoder_total", decoder_steps, dec_len, nowNs() - decode_loop_start);
        logReadProfileStep("decoder_run_total", decoder_steps, dec_len, decoder_run_total_ns);

        return try self.decodeGeneratedIds(dec_ids[0..dec_len], dec_len);
    }

    fn decodeGeneratedIds(self: *ReadingPipeline, dec_ids: []const i64, dec_len: usize) !ReadResult {
        const allocator = self.allocator;
        const prefix_len: usize = if (self.config.forced_bos_token_id != null and dec_len > 1) 2 else 1;
        const text_len = if (dec_len > prefix_len) dec_len - prefix_len else 0;
        last_read_telemetry.generated_tokens = text_len;
        if (readProfileEnabled()) {
            if (active_read_profile_source_fingerprint) |source_fingerprint| {
                std.log.info("read-profile source_fingerprint={s} phase=output output_tokens={d} model_max_tokens={d}", .{ source_fingerprint, text_len, self.config.max_length });
            } else {
                std.log.info("read-profile phase=output output_tokens={d} model_max_tokens={d}", .{ text_len, self.config.max_length });
            }
        }
        const token_ids = try allocator.alloc(i32, text_len);
        defer allocator.free(token_ids);
        for (0..text_len) |i| token_ids[i] = @intCast(dec_ids[prefix_len + i]);

        const text = try self.tokenizer.decode(allocator, token_ids);
        const cleaned = try cleanupPureText(allocator, text);
        allocator.free(text);
        return .{ .text = cleaned, .allocator = allocator };
    }

    pub fn deinit(_: *ReadingPipeline) void {
        // Sessions and tokenizer are borrowed — caller manages their lifetime.
    }
};

/// Reserve the complete native reader invocation, including the encoder
/// output, full-prefix decoder fallback, and self/cross KV retained across steps.
/// Use checked scalar geometry before constructing any compute backend.
fn nativeFlorenceRunRequest(
    cfg: florence_arch.Config,
    batch: usize,
    pixel_count: usize,
    prompt_length: usize,
    max_length: usize,
) !session_mod.RunRequest {
    return nativeFlorenceRunRequestForLogits(cfg, batch, pixel_count, prompt_length, max_length, @max(max_length, 1));
}

fn nativeFlorenceIncrementalRunRequest(
    cfg: florence_arch.Config,
    batch: usize,
    pixel_count: usize,
    prompt_length: usize,
    max_length: usize,
) !session_mod.RunRequest {
    const Checked = struct {
        fn add(x: usize, y: usize) !usize {
            return std.math.add(usize, x, y) catch error.ResourceLimitExceeded;
        }
        fn mul(x: usize, y: usize) !usize {
            return std.math.mul(usize, x, y) catch error.ResourceLimitExceeded;
        }
    };
    var request = try nativeFlorenceRunRequestForLogits(cfg, batch, pixel_count, prompt_length, max_length, 1);
    // decoder IDs, encoder/self masks, per-row state, and retained/compacting
    // cache descriptors are host-owned independently of the GPU logits/KV.
    const history_and_masks = Checked.add(try Checked.mul(max_length, 2), request.sequence) catch
        return error.ResourceLimitExceeded;
    const ids_and_masks = try Checked.mul(try Checked.mul(batch, history_and_masks), @sizeOf(i64));
    const per_row = @sizeOf(ReadResult) + 3 * @sizeOf(usize) + 2 * @sizeOf(i64) +
        3 * @sizeOf(u32) + @sizeOf(bool);
    const row_metadata = try Checked.mul(batch, per_row);
    // Bound the CT/cache/view descriptors across active-row compaction, plus
    // a small invocation envelope. Full backing KV stays charged separately.
    const cache_metadata = try Checked.mul(cfg.decoder_layers, 4096);
    request.host_preprocess_bytes = Checked.add(try Checked.add(ids_and_masks, row_metadata), try Checked.add(cache_metadata, 64 * 1024)) catch
        return error.ResourceLimitExceeded;
    return request;
}

fn admitFlorenceFullPrefixFallback(
    session: backends.Session,
    base: *const session_mod.RunPermit,
    full_request: session_mod.RunRequest,
) !session_mod.RunPermit {
    var request = full_request;
    if (base.request) |owned|
        request.host_preprocess_bytes = @max(request.host_preprocess_bytes, owned.host_preprocess_bytes);
    const target = if (session.run_admission) |admission|
        try admission.estimateRequest(request, &.{})
    else
        @import("../runtime/tier/memory.zig").AdmissionAmounts{};
    return session.admitSupplement(base, target);
}

fn nativeFlorenceRunRequestForLogits(
    cfg: florence_arch.Config,
    batch: usize,
    pixel_count: usize,
    prompt_length: usize,
    max_length: usize,
    logits_rows: usize,
) !session_mod.RunRequest {
    const Checked = struct {
        fn add(a: usize, b: usize) !usize {
            return std.math.add(usize, a, b) catch error.ResourceLimitExceeded;
        }
        fn mul(a: usize, b: usize) !usize {
            return std.math.mul(usize, a, b) catch error.ResourceLimitExceeded;
        }
    };
    if (batch == 0) return error.InvalidInputShape;
    var side: usize = cfg.image_size;
    for (cfg.patch_size, cfg.patch_stride, cfg.patch_padding) |patch, stride, padding| {
        if (stride == 0) return error.InvalidInputShape;
        const padded = try Checked.add(side, try Checked.mul(padding, 2));
        if (padded < patch) return error.InvalidInputShape;
        side = try Checked.add((padded - patch) / stride, 1);
    }
    if (cfg.image_feature_source_count > cfg.image_feature_sources.len) return error.InvalidInputShape;
    const spatial_tokens = try Checked.mul(side, side);
    var image_tokens: usize = 0;
    for (cfg.image_feature_sources[0..cfg.image_feature_source_count]) |source| {
        image_tokens = try Checked.add(image_tokens, switch (source) {
            .spatial_avg_pool => 1,
            .temporal_avg_pool, .last_frame => spatial_tokens,
        });
    }
    const encoder_length = try Checked.add(image_tokens, prompt_length);
    const decoder_length = @max(max_length, 1);
    if (logits_rows == 0 or logits_rows > decoder_length) return error.InvalidInputShape;
    const encoder_bytes = try Checked.mul(try Checked.mul(batch, encoder_length), try Checked.mul(cfg.d_model, @sizeOf(f32)));
    const logits_bytes = try Checked.mul(try Checked.mul(batch, logits_rows), try Checked.mul(cfg.vocab_size, @sizeOf(f32)));
    const cache_length = try Checked.add(encoder_length, decoder_length);
    const kv_bytes = try Checked.mul(try Checked.mul(batch, cache_length), try Checked.mul(cfg.decoder_layers, try Checked.mul(cfg.d_model, 2 * @sizeOf(f32))));
    const prompt_bytes = try Checked.mul(prompt_length, try Checked.add(try Checked.mul(batch, @sizeOf(i64)), @sizeOf(i32)));
    return .{
        .batch = batch,
        .sequence = @max(encoder_length, decoder_length),
        .input_bytes = try Checked.add(try Checked.mul(pixel_count, @sizeOf(f32)), prompt_bytes),
        .output_bytes = try Checked.add(try Checked.add(encoder_bytes, logits_bytes), kv_bytes),
        .output_kv_bytes = kv_bytes,
    };
}

fn compactDecoderInputIds(
    allocator: std.mem.Allocator,
    dec_ids: []const i64,
    batch: usize,
    max_len: usize,
    dec_len: usize,
) ![]i64 {
    const total = std.math.mul(usize, batch, dec_len) catch return error.InvalidInputShape;
    const out = try allocator.alloc(i64, total);
    errdefer allocator.free(out);
    for (0..batch) |b| {
        const dst = std.math.mul(usize, b, dec_len) catch return error.InvalidInputShape;
        const src = std.math.mul(usize, b, max_len) catch return error.InvalidInputShape;
        @memcpy(out[dst..][0..dec_len], dec_ids[src..][0..dec_len]);
    }
    return out;
}

/// Effective native reader microbatch ceiling for this process. Capability
/// publication and execution must call this same authority so a node never
/// advertises native batching that its configured executor will serialize.
pub fn nativeFlorenceReadBatchSize() usize {
    return reader_config.nativeBatchSize(platform.env.getenvUsize("ANTFLY_INFERENCE_READ_BATCH_SIZE"));
}

fn shouldFallbackFlorenceBatchToSerial(backend: backends.BackendType, err: anyerror) bool {
    return switch (err) {
        error.UnsupportedOperation, error.UnsupportedShape => backend != .native,
        error.UnsupportedFlorence2ResidentMetal => backend == .metal,
        else => false,
    };
}

fn shouldFallbackFlorenceIncremental(backend: backends.BackendType, err: anyerror) bool {
    // Native CPU implements the portable incremental path. Do not conceal a
    // missing CPU primitive or cache-shape bug behind quadratic full-prefix
    // decoding; those failures must remain explicit.
    if (backend == .native) return false;
    return switch (err) {
        error.InvalidInputShape, error.UnsupportedOperation, error.UnsupportedShape => true,
        else => false,
    };
}

fn markFlorenceIncrementalFallback() void {
    last_read_telemetry.kv_cache = false;
    last_read_telemetry.kv_cache_mode = null;
    last_read_telemetry.lm_head_path = null;
    last_read_telemetry.cuda_graph_replay = false;
    last_read_telemetry.cuda_graph_capture_steps = 0;
    last_read_telemetry.cuda_graph_replay_steps = 0;
    last_read_telemetry.cuda_graph_fallback_reason = "florence_incremental_decode_unsupported";
}

fn readProfileEnabled() bool {
    return platform.env.getenvBool("ANTFLY_INFERENCE_READ_PROFILE");
}

fn florenceKvCacheDisabled() bool {
    return platform.env.getenvBool("ANTFLY_INFERENCE_FLORENCE_DISABLE_KV_CACHE");
}

fn florenceDebugStats() bool {
    return platform.env.getenvBool("ANTFLY_INFERENCE_FLORENCE_DEBUG_STATS");
}

fn logTensorStatsF32(label: []const u8, values: []const f32) void {
    if (!florenceDebugStats()) return;
    if (values.len == 0) {
        std.log.info("florence-debug {s}: empty", .{label});
        return;
    }
    var sum: f64 = 0;
    var absmax: f32 = 0;
    for (values) |v| {
        sum += v;
        const a = @abs(v);
        if (a > absmax) absmax = a;
    }
    const mean = sum / @as(f64, @floatFromInt(values.len));
    const n_first = @min(values.len, 4);
    std.log.info("florence-debug {s}: n={d} mean={d:.6} absmax={d:.4} first={any}", .{
        label, values.len, mean, absmax, values[0..n_first],
    });
}

fn logTopLogits(label: []const u8, step: usize, logits: []const f32) void {
    if (!florenceDebugStats()) return;
    var top_ids: [3]usize = .{ 0, 0, 0 };
    var top_vals: [3]f32 = .{ -std.math.inf(f32), -std.math.inf(f32), -std.math.inf(f32) };
    for (logits, 0..) |v, i| {
        if (v > top_vals[0]) {
            top_vals[2] = top_vals[1];
            top_ids[2] = top_ids[1];
            top_vals[1] = top_vals[0];
            top_ids[1] = top_ids[0];
            top_vals[0] = v;
            top_ids[0] = i;
        } else if (v > top_vals[1]) {
            top_vals[2] = top_vals[1];
            top_ids[2] = top_ids[1];
            top_vals[1] = v;
            top_ids[1] = i;
        } else if (v > top_vals[2]) {
            top_vals[2] = v;
            top_ids[2] = i;
        }
    }
    std.log.info("florence-debug {s} step={d}: top=[{d}:{d:.4}, {d}:{d:.4}, {d}:{d:.4}]", .{
        label, step, top_ids[0], top_vals[0], top_ids[1], top_vals[1], top_ids[2], top_vals[2],
    });
}

fn florenceCudaGraphEnabled() bool {
    return platform.env.getenvBool("ANTFLY_INFERENCE_FLORENCE_CUDA_GRAPH");
}

fn tokenTensorToU32(cb: *const ComputeBackend, allocator: std.mem.Allocator, token_tensor: CT) !u32 {
    const download_start = nowNs();
    const token_ids = try cb.toFloat32(token_tensor, allocator);
    logReadProfile("florence_decoder_token_download", download_start);
    defer allocator.free(token_ids);
    if (token_ids.len != 1 or token_ids[0] < 0) return error.InvalidTensorShape;
    return @as(u32, @intFromFloat(token_ids[0]));
}

fn logReadProfile(phase: []const u8, start_ns: u64) void {
    if (!readProfileEnabled()) return;
    if (active_read_profile_source_fingerprint) |source_fingerprint| {
        std.log.info("read-profile source_fingerprint={s} phase={s} elapsed_ms={d:.3}", .{ source_fingerprint, phase, nsToMs(nowNs() - start_ns) });
    } else {
        std.log.info("read-profile phase={s} elapsed_ms={d:.3}", .{ phase, nsToMs(nowNs() - start_ns) });
    }
}

fn logReadProfileStep(phase: []const u8, step: usize, seq_len: usize, elapsed_ns: u64) void {
    if (!readProfileEnabled()) return;
    if (active_read_profile_source_fingerprint) |source_fingerprint| {
        std.log.info("read-profile source_fingerprint={s} phase={s} step={d} seq_len={d} elapsed_ms={d:.3}", .{ source_fingerprint, phase, step, seq_len, nsToMs(elapsed_ns) });
    } else {
        std.log.info("read-profile phase={s} step={d} seq_len={d} elapsed_ms={d:.3}", .{ phase, step, seq_len, nsToMs(elapsed_ns) });
    }
}

fn logMetalStageTimingProfile(cb: *const ComputeBackend) void {
    if (!readProfileEnabled()) return;
    const stage = cb.debugTimingSnapshot().provider.metal_stage_timing;
    if (stage.enabled == 0) return;
    std.log.info(
        "read-profile phase=metal_stage_timing supported={d} complete={d} decode_frames={d} decode_gpu_ms={d:.3} attention_ms={d:.3} ffn_ms={d:.3} ple_ms={d:.3} tail_ms={d:.3} embedding_ms={d:.3} other_ms={d:.3} samples={d} dropped={d}",
        .{
            stage.supported,
            stage.complete,
            stage.decode.sampled_frames,
            nsToMs(stage.decode.whole_frame_gpu_nanos),
            nsToMs(stage.decode.attention_nanos),
            nsToMs(stage.decode.ffn_nanos),
            nsToMs(stage.decode.ple_nanos),
            nsToMs(stage.decode.tail_nanos),
            nsToMs(stage.decode.embedding_nanos),
            nsToMs(stage.decode.other_nanos),
            stage.barrier_sample_count,
            stage.dropped_frames,
        },
    );
}

fn logReadBatchMode(mode: []const u8, image_datas: []const []const u8, fallback_reason: ?[]const u8) void {
    var encoded_bytes: usize = 0;
    for (image_datas) |data| encoded_bytes +|= data.len;
    logReadBatchModeSize(mode, image_datas.len, encoded_bytes, fallback_reason);
}

fn logBorrowedRasterBatchMode(
    mode: []const u8,
    rasters: []const antfly_image.BorrowedRasterAttachment,
    fallback_reason: ?[]const u8,
) void {
    var raster_bytes: usize = 0;
    for (rasters) |raster| raster_bytes +|= raster.bytes.len;
    logReadBatchModeSize(mode, rasters.len, raster_bytes, fallback_reason);
}

fn logReadBatchModeSize(
    mode: []const u8,
    count: usize,
    input_bytes: usize,
    fallback_reason: ?[]const u8,
) void {
    if (!readProfileEnabled()) return;
    if (active_read_profile_source_fingerprint) |source_fingerprint| {
        if (fallback_reason) |reason| {
            std.log.info("read-profile source_fingerprint={s} phase=batch mode={s} count={d} encoded_bytes={d} serial_fallback_reason={s}", .{ source_fingerprint, mode, count, input_bytes, reason });
        } else {
            std.log.info("read-profile source_fingerprint={s} phase=batch mode={s} count={d} encoded_bytes={d}", .{ source_fingerprint, mode, count, input_bytes });
        }
    } else if (fallback_reason) |reason| {
        std.log.info("read-profile phase=batch mode={s} count={d} encoded_bytes={d} serial_fallback_reason={s}", .{ mode, count, input_bytes, reason });
    } else {
        std.log.info("read-profile phase=batch mode={s} count={d} encoded_bytes={d}", .{ mode, count, input_bytes });
    }
}

fn nowNs() u64 {
    var ts: std.posix.timespec = undefined;
    switch (std.posix.errno(std.posix.system.clock_gettime(std.posix.CLOCK.MONOTONIC, &ts))) {
        .SUCCESS => return @intCast(@as(i128, ts.sec) * std.time.ns_per_s + ts.nsec),
        else => return 0,
    }
}

fn nsToMs(ns: u64) f64 {
    return @as(f64, @floatFromInt(ns)) / 1.0e6;
}

fn hasInput(session: backends.Session, name: []const u8) bool {
    for (session.inputInfo()) |info| {
        if (std.mem.eql(u8, info.name, name)) return true;
    }
    return false;
}

fn expectsFlattenedPatches(session: backends.Session) bool {
    return hasInput(session, "flattened_patches");
}

fn buildFlorencePromptIds(
    allocator: std.mem.Allocator,
    tokenizer: tokenizer_mod.Tokenizer,
    cfg: anytype,
    prompt: []const u8,
) ![]i32 {
    const normalized = normalizeFlorencePrompt(prompt);
    const prompt_ids = try tokenizer.encode(allocator, normalized);
    defer allocator.free(prompt_ids);

    const total = 2 + prompt_ids.len;
    const ids = try allocator.alloc(i32, total);
    ids[0] = cfg.bos_token_id;
    @memcpy(ids[1..][0..prompt_ids.len], prompt_ids);
    ids[1 + prompt_ids.len] = cfg.eos_token_id;
    return ids;
}

fn normalizeFlorencePrompt(prompt: []const u8) []const u8 {
    // /read is an OCR endpoint, so an explicitly empty prompt follows the same
    // OCR default as an omitted prompt (which the caller represents as <OCR>).
    if (prompt.len == 0 or std.mem.eql(u8, prompt, "<OCR>")) return "What is the text in the image?";
    if (std.mem.eql(u8, prompt, "<OCR_WITH_REGION>")) return "What is the text in the image, with regions?";
    if (std.mem.eql(u8, prompt, "<CAPTION>")) return "What does the image describe?";
    if (std.mem.eql(u8, prompt, "<DETAILED_CAPTION>")) return "Describe in detail what is shown in the image.";
    if (std.mem.eql(u8, prompt, "<MORE_DETAILED_CAPTION>")) return "Describe with a paragraph what is shown in the image.";
    if (std.mem.eql(u8, prompt, "<OD>")) return "Locate the objects with category name in the image.";
    if (std.mem.eql(u8, prompt, "<DENSE_REGION_CAPTION>")) return "Locate the objects in the image, with their descriptions.";
    if (std.mem.eql(u8, prompt, "<REGION_PROPOSAL>")) return "Locate the region proposals in the image.";
    return prompt;
}

test "Florence defaults an empty read prompt to OCR" {
    try std.testing.expectEqualStrings("What is the text in the image?", normalizeFlorencePrompt(""));
    try std.testing.expectEqualStrings("What is the text in the image?", normalizeFlorencePrompt("<OCR>"));
}

fn cleanupPureText(allocator: std.mem.Allocator, text: []const u8) ![]u8 {
    var cleaned = std.ArrayListUnmanaged(u8).empty;
    defer cleaned.deinit(allocator);

    var i: usize = 0;
    while (i < text.len) {
        if (std.mem.startsWith(u8, text[i..], "<s>")) {
            i += 3;
            continue;
        }
        if (std.mem.startsWith(u8, text[i..], "</s>")) {
            i += 4;
            continue;
        }
        try cleaned.append(allocator, text[i]);
        i += 1;
    }

    return allocator.dupe(u8, std.mem.trim(u8, cleaned.items, " \t\r\n"));
}

fn applyFlorenceBatchGreedyStep(
    decoder_ids: []i64,
    batch: usize,
    max_len: usize,
    decoder_len: usize,
    finished: []bool,
    lengths: []usize,
    logits: []const f32,
    logits_row_stride: usize,
    logits_tail_offset: usize,
    vocab_size: usize,
    eos_token_id: i32,
    pad_token_id: i32,
    no_repeat_ngram_size: usize,
    step_tokens: ?[]i64,
) !usize {
    if (decoder_len >= max_len or finished.len != batch or lengths.len != batch or vocab_size == 0)
        return error.InvalidInputShape;
    if (step_tokens) |tokens| if (tokens.len != batch) return error.InvalidInputShape;

    var newly_finished: usize = 0;
    for (0..batch) |b| {
        const row_offset = std.math.mul(usize, b, max_len) catch return error.InvalidInputShape;
        if (row_offset > decoder_ids.len or max_len > decoder_ids.len - row_offset) return error.InvalidInputShape;
        const row = decoder_ids[row_offset..][0..max_len];
        if (finished[b]) {
            row[decoder_len] = @as(i64, pad_token_id);
            if (step_tokens) |tokens| tokens[b] = @as(i64, pad_token_id);
            continue;
        }

        const batch_logits_offset = std.math.mul(usize, b, logits_row_stride) catch return error.InvalidInputShape;
        const logits_offset = std.math.add(usize, batch_logits_offset, logits_tail_offset) catch return error.InvalidInputShape;
        if (logits_offset > logits.len or vocab_size > logits.len - logits_offset) return error.InvalidInputShape;
        const best_id = selectGreedyToken(logits[logits_offset..][0..vocab_size], row[0..decoder_len], no_repeat_ngram_size);
        if (eos_token_id >= 0 and best_id == @as(usize, @intCast(eos_token_id))) {
            finished[b] = true;
            newly_finished += 1;
            lengths[b] = decoder_len;
            row[decoder_len] = @as(i64, pad_token_id);
            if (step_tokens) |tokens| tokens[b] = @as(i64, pad_token_id);
        } else {
            const token: i64 = @intCast(best_id);
            row[decoder_len] = token;
            lengths[b] = decoder_len + 1;
            if (step_tokens) |tokens| tokens[b] = token;
        }
    }
    return newly_finished;
}

fn applyFlorenceBatchGreedyStepActive(
    decoder_ids: []i64,
    max_len: usize,
    decoder_len: usize,
    finished: []bool,
    lengths: []usize,
    logits: []const f32,
    logits_row_stride: usize,
    logits_tail_offset: usize,
    vocab_size: usize,
    active_rows: []const usize,
    eos_token_id: i32,
    pad_token_id: i32,
    no_repeat_ngram_size: usize,
    step_tokens: []i64,
) !usize {
    if (decoder_len >= max_len or finished.len != lengths.len or active_rows.len != step_tokens.len or vocab_size == 0)
        return error.InvalidInputShape;
    var newly_finished: usize = 0;
    for (active_rows, 0..) |original_row, active_row| {
        if (original_row >= finished.len) return error.InvalidInputShape;
        const row_offset = std.math.mul(usize, original_row, max_len) catch return error.InvalidInputShape;
        if (row_offset > decoder_ids.len or max_len > decoder_ids.len - row_offset) return error.InvalidInputShape;
        const row = decoder_ids[row_offset..][0..max_len];
        if (finished[original_row]) {
            row[decoder_len] = @as(i64, pad_token_id);
            step_tokens[active_row] = @as(i64, pad_token_id);
            continue;
        }
        const batch_logits_offset = std.math.mul(usize, active_row, logits_row_stride) catch return error.InvalidInputShape;
        const logits_offset = std.math.add(usize, batch_logits_offset, logits_tail_offset) catch return error.InvalidInputShape;
        if (logits_offset > logits.len or vocab_size > logits.len - logits_offset) return error.InvalidInputShape;
        const best_id = selectGreedyToken(logits[logits_offset..][0..vocab_size], row[0..decoder_len], no_repeat_ngram_size);
        if (eos_token_id >= 0 and best_id == @as(usize, @intCast(eos_token_id))) {
            finished[original_row] = true;
            newly_finished += 1;
            lengths[original_row] = decoder_len;
            row[decoder_len] = @as(i64, pad_token_id);
            step_tokens[active_row] = @as(i64, pad_token_id);
        } else {
            const token: i64 = @intCast(best_id);
            row[decoder_len] = token;
            lengths[original_row] = decoder_len + 1;
            step_tokens[active_row] = token;
        }
    }
    return newly_finished;
}

fn applyFlorenceBatchSelectedTokens(
    decoder_ids: []i64,
    batch: usize,
    max_len: usize,
    decoder_len: usize,
    finished: []bool,
    lengths: []usize,
    selected_tokens: []const u32,
    eos_token_id: i32,
    pad_token_id: i32,
    step_tokens: ?[]i64,
) !usize {
    if (decoder_len >= max_len or finished.len != batch or lengths.len != batch or selected_tokens.len != batch)
        return error.InvalidInputShape;
    if (step_tokens) |tokens| if (tokens.len != batch) return error.InvalidInputShape;

    var newly_finished: usize = 0;
    for (selected_tokens, 0..) |best_id, b| {
        const row_offset = std.math.mul(usize, b, max_len) catch return error.InvalidInputShape;
        if (row_offset > decoder_ids.len or max_len > decoder_ids.len - row_offset) return error.InvalidInputShape;
        const row = decoder_ids[row_offset..][0..max_len];
        if (finished[b]) {
            row[decoder_len] = @as(i64, pad_token_id);
            if (step_tokens) |tokens| tokens[b] = @as(i64, pad_token_id);
            continue;
        }
        if (eos_token_id >= 0 and best_id == @as(u32, @intCast(eos_token_id))) {
            finished[b] = true;
            newly_finished += 1;
            lengths[b] = decoder_len;
            row[decoder_len] = @as(i64, pad_token_id);
            if (step_tokens) |tokens| tokens[b] = @as(i64, pad_token_id);
        } else {
            const token: i64 = @intCast(best_id);
            row[decoder_len] = token;
            lengths[b] = decoder_len + 1;
            if (step_tokens) |tokens| tokens[b] = token;
        }
    }
    return newly_finished;
}

fn applyFlorenceBatchSelectedTokensActive(
    decoder_ids: []i64,
    max_len: usize,
    decoder_len: usize,
    finished: []bool,
    lengths: []usize,
    selected_tokens: []const u32,
    active_rows: []const usize,
    eos_token_id: i32,
    pad_token_id: i32,
    step_tokens: []i64,
) !usize {
    if (decoder_len >= max_len or finished.len != lengths.len or
        selected_tokens.len != active_rows.len or step_tokens.len != active_rows.len)
        return error.InvalidInputShape;
    var newly_finished: usize = 0;
    for (selected_tokens, active_rows, 0..) |best_id, original_row, active_row| {
        if (original_row >= finished.len) return error.InvalidInputShape;
        const row_offset = std.math.mul(usize, original_row, max_len) catch return error.InvalidInputShape;
        if (row_offset > decoder_ids.len or max_len > decoder_ids.len - row_offset) return error.InvalidInputShape;
        const row = decoder_ids[row_offset..][0..max_len];
        if (finished[original_row]) {
            row[decoder_len] = @as(i64, pad_token_id);
            step_tokens[active_row] = @as(i64, pad_token_id);
            continue;
        }
        if (eos_token_id >= 0 and best_id == @as(u32, @intCast(eos_token_id))) {
            finished[original_row] = true;
            newly_finished += 1;
            lengths[original_row] = decoder_len;
            row[decoder_len] = @as(i64, pad_token_id);
            step_tokens[active_row] = @as(i64, pad_token_id);
        } else {
            const token: i64 = @intCast(best_id);
            row[decoder_len] = token;
            lengths[original_row] = decoder_len + 1;
            step_tokens[active_row] = token;
        }
    }
    return newly_finished;
}

test "Florence batch decode preserves row lengths across mixed EOS" {
    const batch: usize = 2;
    const max_len: usize = 4;
    const vocab_size: usize = 4;
    const eos_token_id: i32 = 2;
    const pad_token_id: i32 = 0;
    var decoder_ids = [_]i64{ 1, 0, 0, 0, 1, 0, 0, 0 };
    var finished = [_]bool{ false, false };
    var lengths = [_]usize{ 1, 1 };
    var step_tokens = [_]i64{ 0, 0 };

    // Row zero reaches EOS immediately while row one emits token 3.
    const first_logits = [_]f32{
        0, 1, 9, 2,
        0, 1, 2, 9,
    };
    try std.testing.expectEqual(@as(usize, 1), try applyFlorenceBatchGreedyStep(
        &decoder_ids,
        batch,
        max_len,
        1,
        &finished,
        &lengths,
        &first_logits,
        vocab_size,
        0,
        vocab_size,
        eos_token_id,
        pad_token_id,
        0,
        &step_tokens,
    ));
    try std.testing.expectEqualSlices(bool, &.{ true, false }, &finished);
    try std.testing.expectEqualSlices(usize, &.{ 1, 2 }, &lengths);
    try std.testing.expectEqualSlices(i64, &.{ 0, 3 }, &step_tokens);

    // The finished row stays padded and length-stable while row one reaches
    // EOS on its own next step.
    const second_logits = [_]f32{
        9, 0, 0, 0,
        0, 1, 9, 2,
    };
    try std.testing.expectEqual(@as(usize, 1), try applyFlorenceBatchGreedyStep(
        &decoder_ids,
        batch,
        max_len,
        2,
        &finished,
        &lengths,
        &second_logits,
        vocab_size,
        0,
        vocab_size,
        eos_token_id,
        pad_token_id,
        0,
        &step_tokens,
    ));
    try std.testing.expectEqualSlices(bool, &.{ true, true }, &finished);
    try std.testing.expectEqualSlices(usize, &.{ 1, 2 }, &lengths);
    try std.testing.expectEqualSlices(i64, &.{ 0, 0 }, &step_tokens);
    try std.testing.expectEqualSlices(i64, &.{ 1, 0, 0, 0 }, decoder_ids[0..max_len]);
    try std.testing.expectEqualSlices(i64, &.{ 1, 3, 0, 0 }, decoder_ids[max_len..]);
}

test "Florence device-selected batch tokens preserve mixed EOS state" {
    const batch: usize = 3;
    const max_len: usize = 4;
    var decoder_ids = [_]i64{ 1, 0, 0, 0, 1, 7, 0, 0, 1, 0, 0, 0 };
    var finished = [_]bool{ false, false, true };
    var lengths = [_]usize{ 1, 2, 1 };
    var step_tokens = [_]i64{ 0, 0, 0 };

    try std.testing.expectEqual(@as(usize, 1), try applyFlorenceBatchSelectedTokens(
        &decoder_ids,
        batch,
        max_len,
        2,
        &finished,
        &lengths,
        &.{ 9, 2, 8 },
        2,
        0,
        &step_tokens,
    ));
    try std.testing.expectEqualSlices(bool, &.{ false, true, true }, &finished);
    try std.testing.expectEqualSlices(usize, &.{ 3, 2, 1 }, &lengths);
    try std.testing.expectEqualSlices(i64, &.{ 9, 0, 0 }, &step_tokens);
    try std.testing.expectEqualSlices(i64, &.{ 1, 0, 9, 0 }, decoder_ids[0..max_len]);
    try std.testing.expectEqualSlices(i64, &.{ 1, 7, 0, 0 }, decoder_ids[max_len .. max_len * 2]);
    try std.testing.expectEqualSlices(i64, &.{ 1, 0, 0, 0 }, decoder_ids[max_len * 2 ..]);
}

test "Florence compacted active rows preserve original result identity" {
    const max_len: usize = 4;
    var decoder_ids = [_]i64{
        1, 4, 0, 0,
        1, 5, 0, 0,
        1, 6, 0, 0,
        1, 7, 0, 0,
    };
    var finished = [_]bool{ true, false, true, false };
    var lengths = [_]usize{ 2, 2, 2, 2 };
    var step_tokens = [_]i64{ 0, 0 };

    try std.testing.expectEqual(@as(usize, 1), try applyFlorenceBatchSelectedTokensActive(
        &decoder_ids,
        max_len,
        2,
        &finished,
        &lengths,
        &.{ 2, 9 },
        &.{ 1, 3 },
        2,
        0,
        &step_tokens,
    ));
    try std.testing.expectEqualSlices(bool, &.{ true, true, true, false }, &finished);
    try std.testing.expectEqualSlices(usize, &.{ 2, 2, 2, 3 }, &lengths);
    try std.testing.expectEqualSlices(i64, &.{ 0, 9 }, &step_tokens);
    try std.testing.expectEqualSlices(i64, &.{ 1, 4, 0, 0 }, decoder_ids[0..max_len]);
    try std.testing.expectEqualSlices(i64, &.{ 1, 5, 0, 0 }, decoder_ids[max_len .. max_len * 2]);
    try std.testing.expectEqualSlices(i64, &.{ 1, 6, 0, 0 }, decoder_ids[max_len * 2 .. max_len * 3]);
    try std.testing.expectEqualSlices(i64, &.{ 1, 7, 9, 0 }, decoder_ids[max_len * 3 ..]);
}

/// The caller cancels an owned frame on every exit before its page/cache
/// storage retires. Existing outer frames retain their original ownership.
fn beginFlorenceStepFrame(cb: *const ComputeBackend, enabled: bool) !bool {
    if (!enabled or cb.kind() != .metal or cb.decoderRuntimeHasActiveFrame()) return false;
    if (!try cb.decoderRuntimeBeginFrame()) return false;
    errdefer cb.decoderRuntimeCancelFrame() catch {};
    try cb.decoderRuntimeSetActiveFrameRegime(.decode);
    if (!try cb.decoderRuntimeBeginPlannedComputeScope()) {
        try cb.decoderRuntimeCancelFrame();
        return false;
    }
    return true;
}

fn florenceStepArgmaxRows(
    cb: *const ComputeBackend,
    logits: CT,
    rows: usize,
    vocab: usize,
    allocator: std.mem.Allocator,
    owns_frame: *bool,
    steps: *usize,
    fallbacks: *usize,
) !?[]u32 {
    if (owns_frame.*) {
        // A dense implementation may close its encoder while retaining the
        // frame. Reopen the scope so argmax consumes this same command buffer.
        _ = try cb.decoderRuntimeBeginPlannedComputeScope();
        if (try cb.decoderRuntimeArgmaxRowsSuppress(logits, 0, rows, vocab, &.{}, allocator)) |selected| {
            // This API completes the frame before returning CPU token ids.
            if (cb.decoderRuntimeHasActiveFrame()) {
                allocator.free(selected);
                return error.FlorenceArgmaxFrameNotConsumed;
            }
            owns_frame.* = false;
            steps.* += 1;
            return selected;
        }
        // Missing/unsupported consuming APIs keep the regular selection path.
        // Drain the producer before that path can inspect or download logits.
        if (!cb.decoderRuntimeHasActiveFrame()) {
            owns_frame.* = false;
            return error.FlorenceArgmaxFrameFailed;
        }
        try cb.decoderRuntimeSubmitAndWaitFrame();
        owns_frame.* = false;
        fallbacks.* += 1;
    }
    return cb.argmaxRows(logits, 0, rows, vocab, allocator);
}

/// Validate each device winner against its original page history. Active
/// decoder/cache rows may have been compacted or reordered after earlier EOS.
/// A rejected winner leaves the existing full-logits policy in control.
fn florenceBatchArgmaxAllowedByNoRepeat(
    decoder_ids: []const i64,
    max_len: usize,
    decoder_len: usize,
    active_rows: []const usize,
    selected_tokens: []const u32,
    no_repeat_ngram_size: usize,
) bool {
    if (max_len == 0 or decoder_len > max_len or decoder_ids.len % max_len != 0 or
        selected_tokens.len != active_rows.len) return false;
    const total_rows = decoder_ids.len / max_len;
    for (selected_tokens, active_rows) |token, original_row| {
        if (original_row >= total_rows) return false;
        const prefix = decoder_ids[original_row * max_len ..][0..decoder_len];
        if (wouldRepeatNgram(prefix, @intCast(token), no_repeat_ngram_size)) return false;
    }
    return true;
}

test "Florence device winners preserve per-page no-repeat after active row compaction" {
    const ids = [_]i64{
        1, 2, 3, 1, 2, 0,
        7, 8, 9, 7, 8, 0,
        4, 5, 6, 4, 5, 0,
    };
    const active = [_]usize{ 2, 0 };
    try std.testing.expect(florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &active, &.{ 3, 6 }, 3));
    try std.testing.expect(!florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &active, &.{ 6, 3 }, 3));
    try std.testing.expect(!florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &active, &.{ 3, 3 }, 3));
    try std.testing.expect(florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &active, &.{ 6, 3 }, 0));
    try std.testing.expect(florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &active, &.{ 6, 3 }, 1));
    try std.testing.expect(!florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &.{3}, &.{3}, 3));
    try std.testing.expect(!florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &active, &.{3}, 3));
    try std.testing.expect(!florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 7, &active, &.{ 3, 6 }, 3));
    try std.testing.expect(!florenceBatchArgmaxAllowedByNoRepeat(&ids, 0, 0, &active, &.{ 3, 6 }, 3));

    // If a global maximum is allowed, it remains the masked maximum. A
    // rejected maximum must use the established host policy instead. Cover
    // tied maxima and every candidate for both independent page histories.
    for ([_]usize{ 0, 2 }) |row| {
        for (0..10) |candidate| {
            var logits: [10]f32 = @splat(-1);
            logits[candidate] = 4;
            logits[(candidate + 1) % logits.len] = 4;
            const unmasked = selectGreedyToken(&logits, ids[row * 6 ..][0..5], 0);
            const masked = selectGreedyToken(&logits, ids[row * 6 ..][0..5], 3);
            const allowed = florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &.{row}, &.{@intCast(unmasked)}, 3);
            if (allowed) try std.testing.expectEqual(masked, unmasked) else try std.testing.expect(masked != unmasked);
        }
    }
}

test "Florence checked no-repeat argmax keeps logits on Metal and preserves fallback" {
    const Check = struct {
        fn run(cb: ComputeBackend, _: ComputeBackend) !void {
            const allocator = std.testing.allocator;
            const ids = [_]i64{ 1, 2, 3, 1, 2, 0, 7, 8, 9, 7, 8, 0, 4, 5, 6, 4, 5, 0 };
            const active = [_]usize{ 2, 0 };
            for ([_]usize{ 16, 2051 }) |vocab| {
                for ([_]bool{ false, true }) |frame_mode| {
                    for (0..5) |scenario| {
                        const logits = try allocator.alloc(f32, vocab * 2);
                        defer allocator.free(logits);
                        @memset(logits, -2);
                        logits[3] = 4;
                        logits[vocab + 6] = 4;
                        if (scenario == 1) {
                            logits[6] = 5;
                            logits[vocab + 3] = 5;
                        } else if (scenario == 2) {
                            logits[6] = 4;
                            logits[vocab + 3] = 4;
                        } else if (scenario == 3) {
                            logits[0] = std.math.nan(f32);
                            logits[vocab] = std.math.nan(f32);
                            logits[3] = std.math.inf(f32);
                            logits[vocab + 6] = std.math.inf(f32);
                        } else if (scenario == 4) {
                            @memset(logits, -std.math.inf(f32));
                            logits[0] = std.math.nan(f32);
                            logits[vocab] = std.math.nan(f32);
                        }
                        const host = try cb.fromFloat32Shape(logits, &.{ 2, @as(i32, @intCast(vocab)) });
                        defer cb.free(host);
                        const device = (try cb.ensureDeviceResident(host)) orelse return error.DeviceLogitsUnavailable;
                        defer cb.free(device);
                        const zeros = try allocator.alloc(f32, vocab * 2);
                        defer allocator.free(zeros);
                        @memset(zeros, 0);
                        const zero_host = try cb.fromFloat32Shape(zeros, &.{ 2, @as(i32, @intCast(vocab)) });
                        defer cb.free(zero_host);
                        const zero_device = (try cb.ensureDeviceResident(zero_host)) orelse return error.DeviceLogitsUnavailable;
                        defer cb.free(zero_device);
                        var owns_frame = try beginFlorenceStepFrame(&cb, frame_mode);
                        defer if (owns_frame) cb.decoderRuntimeCancelFrame() catch {};
                        try std.testing.expectEqual(frame_mode, owns_frame);
                        const produced = if (frame_mode) blk: {
                            const intermediate = try cb.add(device, zero_device);
                            defer cb.free(intermediate);
                            break :blk try cb.add(intermediate, zero_device);
                        } else device;
                        defer if (frame_mode) cb.free(produced);
                        const transfers = @import("../ops/media_residency_test.zig").Transfers.snapshot(cb);
                        var frame_steps: usize = 0;
                        var frame_fallbacks: usize = 0;
                        const selected = (try florenceStepArgmaxRows(&cb, produced, 2, vocab, allocator, &owns_frame, &frame_steps, &frame_fallbacks)) orelse return error.DeviceArgmaxUnavailable;
                        try std.testing.expect(!owns_frame and !cb.decoderRuntimeHasActiveFrame());
                        try std.testing.expectEqual(@as(usize, @intFromBool(frame_mode)), frame_steps);
                        try std.testing.expectEqual(@as(usize, 0), frame_fallbacks);
                        defer allocator.free(selected);
                        try transfers.expectUnchanged(cb);
                        const allowed = florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &active, selected, 3);
                        try std.testing.expectEqual(scenario == 0 or scenario == 3 or scenario == 4, allowed);
                        if (allowed) {
                            for (selected, active, 0..) |token, original_row, row| {
                                try std.testing.expectEqual(@as(u32, @intCast(selectGreedyToken(logits[row * vocab ..][0..vocab], ids[original_row * 6 ..][0..5], 3))), token);
                            }
                        } else {
                            // A prior device reduction must leave the source logits
                            // available for the unchanged masked host fallback.
                            const downloaded = try cb.toFloat32(produced, allocator);
                            defer allocator.free(downloaded);
                            for (active, 0..) |original_row, row| {
                                try std.testing.expectEqual(selectGreedyToken(logits[row * vocab ..][0..vocab], ids[original_row * 6 ..][0..5], 3), selectGreedyToken(downloaded[row * vocab ..][0..vocab], ids[original_row * 6 ..][0..5], 3));
                            }
                        }
                    }
                }
            }
        }
    };
    const fixture = @import("../ops/media_residency_test.zig");
    try fixture.onMetal(fixture.noWeights, Check.run);
}

test "Florence step frame drains unsupported consumers and cancels failed token allocation" {
    const Check = struct {
        fn run(cb: ComputeBackend, _: ComputeBackend) !void {
            const allocator = std.testing.allocator;
            const values = [_]f32{ 1, 4, 2, 0, 8, 2, 1, 0 };
            const host = try cb.fromFloat32Shape(&values, &.{ 2, 4 });
            defer cb.free(host);
            const device = (try cb.ensureDeviceResident(host)) orelse return error.DeviceLogitsUnavailable;
            defer cb.free(device);
            const LostResult = struct {
                base: ComputeBackend,
                fn consume(raw: *anyopaque, _: CT, _: usize, _: usize, _: usize, _: []const i32, _: std.mem.Allocator) anyerror!?[]u32 {
                    const self: *@This() = @ptrCast(@alignCast(raw));
                    try self.base.decoderRuntimeSubmitAndWaitFrame();
                    return null;
                }
                fn scope(raw: *anyopaque) anyerror!bool {
                    const self: *@This() = @ptrCast(@alignCast(raw));
                    return self.base.decoderRuntimeBeginPlannedComputeScope();
                }
                fn active(raw: *anyopaque) bool {
                    const self: *@This() = @ptrCast(@alignCast(raw));
                    return self.base.decoderRuntimeHasActiveFrame();
                }
            };
            var fallback_table = cb.vtable.*;
            fallback_table.decoderRuntimeArgmaxRowsSuppress = null;
            var fallback_cb = cb;
            fallback_cb.vtable = &fallback_table;
            var owns = try beginFlorenceStepFrame(&fallback_cb, true);
            defer if (owns) cb.decoderRuntimeCancelFrame() catch {};
            const produced = try cb.add(device, device);
            defer cb.free(produced);
            var steps: usize = 0;
            var fallbacks: usize = 0;
            const selected = (try florenceStepArgmaxRows(&fallback_cb, produced, 2, 4, allocator, &owns, &steps, &fallbacks)).?;
            defer allocator.free(selected);
            try std.testing.expectEqualSlices(u32, &.{ 1, 0 }, selected);
            try std.testing.expect(!owns and !cb.decoderRuntimeHasActiveFrame());
            try std.testing.expectEqual(@as(usize, 0), steps);
            try std.testing.expectEqual(@as(usize, 1), fallbacks);
            {
                var failed_frame = try beginFlorenceStepFrame(&cb, true);
                defer if (failed_frame) cb.decoderRuntimeCancelFrame() catch {};
                const pending = try cb.add(device, device);
                defer cb.free(pending);
                try std.testing.expectError(error.OutOfMemory, florenceStepArgmaxRows(&cb, pending, 2, 4, std.testing.failing_allocator, &failed_frame, &steps, &fallbacks));
                try std.testing.expect(failed_frame and cb.decoderRuntimeHasActiveFrame());
            }
            try std.testing.expect(!cb.decoderRuntimeHasActiveFrame());
            var lost_context = LostResult{ .base = cb };
            var lost_table = cb.vtable.*;
            lost_table.decoderRuntimeArgmaxRowsSuppress = LostResult.consume;
            lost_table.decoderRuntimeHasActiveFrame = LostResult.active;
            lost_table.decoderRuntimeBeginPlannedComputeScope = LostResult.scope;
            const lost_cb = ComputeBackend{ .ptr = &lost_context, .vtable = &lost_table };
            var lost_frame = try beginFlorenceStepFrame(&cb, true);
            defer if (lost_frame) cb.decoderRuntimeCancelFrame() catch {};
            const lost_logits = try cb.add(device, device);
            defer cb.free(lost_logits);
            try std.testing.expectError(error.FlorenceArgmaxFrameFailed, florenceStepArgmaxRows(&lost_cb, lost_logits, 2, 4, allocator, &lost_frame, &steps, &fallbacks));
            try std.testing.expect(!lost_frame and !cb.decoderRuntimeHasActiveFrame());
        }
    };
    const fixture = @import("../ops/media_residency_test.zig");
    try fixture.onMetal(fixture.noWeights, Check.run);
}

fn selectGreedyToken(logits: []const f32, prefix: []const i64, no_repeat_ngram_size: usize) usize {
    var best_id: usize = 0;
    var best_val: f32 = -std.math.inf(f32);

    for (0..logits.len) |i| {
        if (logits[i] > best_val) {
            if (no_repeat_ngram_size > 0 and wouldRepeatNgram(prefix, @intCast(i), no_repeat_ngram_size)) continue;
            best_val = logits[i];
            best_id = i;
        }
    }

    if (best_val != -std.math.inf(f32)) return best_id;

    best_id = 0;
    best_val = logits[0];
    for (1..logits.len) |i| {
        if (logits[i] > best_val) {
            best_val = logits[i];
            best_id = i;
        }
    }
    return best_id;
}

fn buildNoRepeatSuppressTokens(
    allocator: std.mem.Allocator,
    prefix: []const i64,
    no_repeat_ngram_size: usize,
) ![]i32 {
    if (no_repeat_ngram_size <= 1 or prefix.len < no_repeat_ngram_size) {
        return allocator.alloc(i32, 0);
    }

    const context_len = no_repeat_ngram_size - 1;
    const context_start = prefix.len - context_len;
    const context = prefix[context_start..];
    const search_end = prefix.len - no_repeat_ngram_size + 1;

    var suppress_tokens = std.ArrayListUnmanaged(i32).empty;
    errdefer suppress_tokens.deinit(allocator);

    for (0..search_end) |start| {
        if (!std.mem.eql(i64, prefix[start .. start + context_len], context)) continue;
        const candidate = prefix[start + context_len];
        if (candidate < 0 or candidate > std.math.maxInt(i32)) continue;
        try appendUniqueSuppressToken(allocator, &suppress_tokens, @intCast(candidate));
    }

    return suppress_tokens.toOwnedSlice(allocator);
}

fn appendUniqueSuppressToken(
    allocator: std.mem.Allocator,
    suppress_tokens: *std.ArrayListUnmanaged(i32),
    token_id: i32,
) !void {
    for (suppress_tokens.items) |existing| {
        if (existing == token_id) return;
    }
    try suppress_tokens.append(allocator, token_id);
}

fn wouldRepeatNgram(prefix: []const i64, candidate: i64, no_repeat_ngram_size: usize) bool {
    if (no_repeat_ngram_size <= 1) return false;
    if (prefix.len < no_repeat_ngram_size) return false;

    const context_len = no_repeat_ngram_size - 1;
    const context_start = prefix.len - context_len;
    const context = prefix[context_start..];
    const search_end = prefix.len - no_repeat_ngram_size + 1;

    for (0..search_end) |start| {
        if (!std.mem.eql(i64, prefix[start .. start + context_len], context)) continue;
        if (prefix[start + context_len] == candidate) return true;
    }
    return false;
}

const AdmissionDenyingFlorenceSession = struct {
    run_called: bool = false,

    fn session(self: *AdmissionDenyingFlorenceSession) backends.Session {
        return .{
            .ptr = self,
            .vtable = &.{
                .run = run,
                .inputInfo = inputInfo,
                .outputInfo = outputInfo,
                .backend = backend,
                .close = close,
            },
        };
    }

    fn run(
        ptr: *anyopaque,
        inputs: []const backends.Tensor,
        _: std.mem.Allocator,
    ) anyerror![]backends.Tensor {
        const self: *AdmissionDenyingFlorenceSession = @ptrCast(@alignCast(ptr));
        self.run_called = true;
        try std.testing.expectEqual(@as(usize, 2), inputs.len);
        try std.testing.expectEqualStrings("pixel_values", inputs[0].name);
        try std.testing.expectEqualStrings("input_ids", inputs[1].name);
        try std.testing.expectEqual(backends.DType.i64, inputs[1].dtype);
        try std.testing.expectEqualSlices(i64, &.{ 11, 22, 33 }, inputs[1].asInt64());
        return error.ResourceTemporarilyUnavailable;
    }

    fn inputInfo(_: *anyopaque) []const backends.TensorInfo {
        return &.{
            .{ .name = "pixel_values", .dtype = .f32, .shape = &.{ -1, 3, -1, -1 } },
            .{ .name = "input_ids", .dtype = .i64, .shape = &.{ -1, -1 } },
        };
    }

    fn outputInfo(_: *anyopaque) []const backends.TensorInfo {
        return &.{.{ .name = "last_hidden_state", .dtype = .f32, .shape = &.{ -1, -1, -1 } }};
    }

    fn backend(_: *anyopaque) backends.BackendType {
        return .native;
    }

    fn close(_: *anyopaque) void {}
};

test "reading entry points and batch publication honor execution control" {
    var pipeline: ReadingPipeline = undefined;
    pipeline.native_execution_lane = null;
    pipeline.allocator = std.testing.allocator;
    pipeline.execution_control = .{ .deadline_ns = 0 };
    try std.testing.expectError(error.Timeout, pipeline.read("unused"));
    try std.testing.expectError(error.Timeout, pipeline.readBatch(&.{"unused"}));
    try std.testing.expectError(error.Timeout, pipeline.readDecoded(undefined));

    const CancelAtPublication = struct {
        checks: usize = 0,
        fn check(raw: ?*anyopaque) !void {
            const self: *@This() = @ptrCast(@alignCast(raw.?));
            self.checks += 1;
            if (self.checks == 2) return error.Cancelled;
        }
    };
    var cancellation = CancelAtPublication{};
    pipeline.config = .{};
    pipeline.execution_control = .{ .ptr = &cancellation, .check_fn = CancelAtPublication.check };
    try std.testing.expectError(error.Cancelled, pipeline.readBatch(&.{}));
    try std.testing.expectEqual(@as(usize, 2), cancellation.checks);
}

test "reading cancellation interrupts encoded decode and borrowed raster preprocessing" {
    const Probe = struct {
        checks: usize = 0,
        fn check(raw: ?*anyopaque) !void {
            const self: *@This() = @ptrCast(@alignCast(raw.?));
            self.checks += 1;
            if (self.checks >= 3) return error.Cancelled;
        }
    };
    var probe = Probe{};
    var pipeline: ReadingPipeline = undefined;
    pipeline.native_execution_lane = null;
    pipeline.allocator = std.testing.allocator;
    pipeline.config = .{ .image_size = 16 };
    pipeline.execution_control = .{ .ptr = &probe, .check_fn = Probe.check };
    const rgba = @as([(32 * 32 * 4)]u8, @splat(127));
    const png = try antfly_image.png.encodeRgba(std.testing.allocator, 32, 32, &rgba);
    defer std.testing.allocator.free(png);
    // Backend fields intentionally remain undefined: cancellation must stop
    // inside preprocessing, before any model/session is consulted.
    try std.testing.expectError(error.Cancelled, pipeline.read(png));
    try std.testing.expectEqual(@as(usize, 3), probe.checks);
    probe.checks = 0;
    try std.testing.expectError(error.Cancelled, pipeline.readBorrowedRaster(.{ .bytes = &rgba, .width = 32, .height = 32, .stride_bytes = 128, .format = .rgba8 }));
    try std.testing.expectEqual(@as(usize, 3), probe.checks);
    try antfly_image.work_control.check();
}

test "Florence prompt tensor cleanup survives encoder admission denial" {
    const allocator = std.testing.allocator;
    var fake = AdmissionDenyingFlorenceSession{};
    var pixel_tensor = try backends.Tensor.initFloat32(
        allocator,
        "pixel_values",
        &.{ 1, 3, 1, 1 },
        &.{ 0.0, 0.0, 0.0 },
    );
    defer pixel_tensor.deinit();

    try std.testing.expectError(
        error.ResourceTemporarilyUnavailable,
        ReadingPipeline.runFlorenceVisionEncoder(
            fake.session(),
            allocator,
            pixel_tensor,
            &.{ 11, 22, 33 },
            null,
        ),
    );
    try std.testing.expect(fake.run_called);
}

test "wouldRepeatNgram detects repeated trigram continuation" {
    const prefix = [_]i64{ 2, 0, 42, 77, 9, 42, 77 };
    try std.testing.expect(wouldRepeatNgram(&prefix, 9, 3));
    try std.testing.expect(!wouldRepeatNgram(&prefix, 10, 3));
}

test "selectGreedyToken skips repeated ngrams when configured" {
    const logits = [_]f32{ 0.1, 0.2, 0.3, 0.7, 0.9 };
    const prefix = [_]i64{ 2, 0, 1, 3, 4, 1, 3 };
    try std.testing.expectEqual(@as(usize, 3), selectGreedyToken(&logits, &prefix, 3));
    try std.testing.expectEqual(@as(usize, 4), selectGreedyToken(&logits, &prefix, 0));
}

test "buildNoRepeatSuppressTokens returns repeated continuations" {
    const allocator = std.testing.allocator;
    const prefix = [_]i64{ 2, 0, 42, 77, 9, 42, 77 };
    const suppress_tokens = try buildNoRepeatSuppressTokens(allocator, &prefix, 3);
    defer allocator.free(suppress_tokens);
    try std.testing.expectEqualSlices(i32, &.{9}, suppress_tokens);
}

test "buildNoRepeatSuppressTokens deduplicates continuations" {
    const allocator = std.testing.allocator;
    const prefix = [_]i64{ 2, 4, 5, 9, 4, 5, 9, 4, 5 };
    const suppress_tokens = try buildNoRepeatSuppressTokens(allocator, &prefix, 3);
    defer allocator.free(suppress_tokens);
    try std.testing.expectEqualSlices(i32, &.{9}, suppress_tokens);
}

test "Florence fallback policy exposes unsupported native CPU paths" {
    try std.testing.expect(!shouldFallbackFlorenceBatchToSerial(.native, error.InvalidInputShape));
    try std.testing.expect(!shouldFallbackFlorenceBatchToSerial(.native, error.UnsupportedOperation));
    try std.testing.expect(!shouldFallbackFlorenceBatchToSerial(.native, error.UnsupportedShape));
    try std.testing.expect(shouldFallbackFlorenceBatchToSerial(.metal, error.UnsupportedShape));
    try std.testing.expect(shouldFallbackFlorenceBatchToSerial(.metal, error.UnsupportedFlorence2ResidentMetal));
    try std.testing.expect(shouldFallbackFlorenceIncremental(.metal, error.InvalidInputShape));
    try std.testing.expect(shouldFallbackFlorenceIncremental(.cuda, error.UnsupportedOperation));
    try std.testing.expect(shouldFallbackFlorenceIncremental(.metal, error.UnsupportedShape));
    try std.testing.expect(!shouldFallbackFlorenceIncremental(.native, error.UnsupportedOperation));
    try std.testing.expect(!shouldFallbackFlorenceIncremental(.native, error.UnsupportedShape));
    try std.testing.expect(!shouldFallbackFlorenceIncremental(.cuda, error.OutOfMemory));

    last_read_telemetry = .{
        .resident_decoder = true,
        .kv_cache = true,
        .kv_cache_mode = "preallocated",
        .lm_head_path = "fused_argmax",
        .cuda_graph_replay = true,
        .cuda_graph_capture_steps = 2,
        .cuda_graph_replay_steps = 1,
    };
    defer resetLastReadTelemetry();
    markFlorenceIncrementalFallback();
    try std.testing.expect(last_read_telemetry.resident_decoder);
    try std.testing.expect(!last_read_telemetry.kv_cache);
    try std.testing.expectEqual(@as(?[]const u8, null), last_read_telemetry.kv_cache_mode);
    try std.testing.expectEqual(@as(?[]const u8, null), last_read_telemetry.lm_head_path);
    try std.testing.expect(!last_read_telemetry.cuda_graph_replay);
    try std.testing.expectEqual(@as(usize, 0), last_read_telemetry.cuda_graph_capture_steps);
    try std.testing.expectEqual(@as(usize, 0), last_read_telemetry.cuda_graph_replay_steps);
    try std.testing.expectEqualStrings("florence_incremental_decode_unsupported", last_read_telemetry.cuda_graph_fallback_reason.?);
}

test "native Florence admission covers batched encoder logits and retained KV" {
    const cfg = florence_arch.Config{
        .image_size = 8,
        .patch_size = .{ 1, 1, 1, 1 },
        .patch_stride = .{ 2, 2, 1, 1 },
        .patch_padding = .{ 0, 0, 0, 0 },
        .d_model = 4,
        .vocab_size = 8,
        .decoder_layers = 2,
    };
    const request = try nativeFlorenceRunRequest(cfg, 2, 384, 3, 6);
    try std.testing.expectEqual(@as(usize, 8), request.sequence);
    try std.testing.expectEqual(@as(usize, 1596), request.input_bytes);
    try std.testing.expectEqual(@as(usize, 1792), request.output_kv_bytes);
    try std.testing.expectEqual(@as(usize, 2432), request.output_bytes.?);
    try std.testing.expectError(error.ResourceLimitExceeded, nativeFlorenceRunRequest(cfg, 2, std.math.maxInt(usize), 3, 6));
    try std.testing.expectError(error.ResourceLimitExceeded, nativeFlorenceRunRequest(cfg, 2, 384, 3, std.math.maxInt(usize)));
    var invalid = cfg;
    invalid.patch_stride[1] = 0;
    try std.testing.expectError(error.InvalidInputShape, nativeFlorenceRunRequest(invalid, 2, 384, 3, 6));
}

test "native Florence direct admission denies before execution and recovers without leaked leases" {
    const memory = @import("../runtime/tier/memory.zig");
    for ([_]memory.BackendClass{ .cpu, .gpu }) |backend_class| {
        var controller = memory.AdmissionController{};
        defer controller.deinit();
        controller.configureForcedRunDenialsForTesting(3);
        var fake = AdmissionDenyingFlorenceSession{};
        var session = fake.session();
        session.run_admission = .{
            .controller = &controller,
            .backend_class = backend_class,
            .limits = .{},
            .static_workspace_bytes = 4096,
            .check_live_memory = false,
        };
        const request = try nativeFlorenceRunRequest(.{}, 1, 3 * 768 * 768, 3, 1);
        for (0..3) |_| {
            try std.testing.expectError(error.ResourceTemporarilyUnavailable, session.admit(request));
            try std.testing.expect(std.meta.eql(memory.AdmissionAmounts{}, controller.admitted));
        }
        var permit = try session.admit(request);
        defer permit.deinit();
        try std.testing.expect(!std.meta.eql(memory.AdmissionAmounts{}, controller.admitted));
        try std.testing.expect(!fake.run_called);
        permit.deinit();
        try std.testing.expect(std.meta.eql(memory.AdmissionAmounts{}, controller.admitted));
    }
}

test "Florence preprocess output admission precedes allocation and unwinds allocator failure" {
    const memory = @import("../runtime/tier/memory.zig");
    var controller = memory.AdmissionController{};
    defer controller.deinit();
    controller.configureForcedRunDenialsForTesting(1);
    var fake = AdmissionDenyingFlorenceSession{};
    var session = fake.session();
    session.run_admission = .{ .controller = &controller, .backend_class = .cpu, .limits = .{}, .static_workspace_bytes = 0, .check_live_memory = false };
    var failing = std.testing.FailingAllocator.init(std.testing.allocator, .{ .fail_index = 0 });
    var lane = @import("../execution_control.zig").ExecutionLane{};
    var pipeline: ReadingPipeline = undefined;
    pipeline.allocator = failing.allocator();
    pipeline.vision_encoder = session;
    pipeline.config = .{ .image_size = 8 };
    pipeline.native_execution_lane = &lane;
    pipeline.execution_control = null;
    try std.testing.expectError(error.ResourceTemporarilyUnavailable, pipeline.readBoundedNativeImage("unused"));
    try std.testing.expect(!failing.has_induced_failure);
    try std.testing.expect(std.meta.eql(memory.AdmissionAmounts{}, controller.admitted));
    try std.testing.expectError(error.OutOfMemory, pipeline.readBoundedNativeImage("unused"));
    try std.testing.expect(failing.has_induced_failure);
    try std.testing.expect(std.meta.eql(memory.AdmissionAmounts{}, controller.admitted));
    try std.testing.expect(!fake.run_called);
}

test "Florence queued prepared encoded raster and decoded pixels release admission on cancellation" {
    const execution = @import("../execution_control.zig");
    const memory = @import("../runtime/tier/memory.zig");
    const Kind = enum { encoded, raster, decoded };
    const Worker = struct {
        fn check(raw: ?*anyopaque) !void {
            const cancelled: *std.atomic.Value(bool) = @ptrCast(@alignCast(raw.?));
            if (cancelled.load(.acquire)) return error.Cancelled;
        }
        fn run(pipeline: *ReadingPipeline, png: []const u8, rgba: []u8, kind: Kind) !void {
            var result = switch (kind) {
                .encoded => try pipeline.readBoundedNativeImage(png),
                .raster => try pipeline.readBorrowedRaster(.{ .bytes = rgba, .width = 8, .height = 8, .stride_bytes = 32 }),
                .decoded => try pipeline.readDecoded(.{ .data = rgba, .width = 8, .height = 8, .channels = 4 }),
            };
            defer result.deinit();
            return error.UnexpectedBackendExecution;
        }
        fn awaitParked(lane: *execution.ExecutionLane) !void {
            const deadline = platform.time.monotonicNs() + 5 * std.time.ns_per_s;
            while (true) {
                platform.sync.lockYielding(&lane.mutex);
                const parked = lane.event_waits > 0;
                lane.mutex.unlock();
                if (parked) return;
                if (platform.time.monotonicNs() >= deadline) return error.Timeout;
                try std.testing.io.sleep(.fromMilliseconds(1), .awake);
            }
        }
    };
    var rgba = @as([8 * 8 * 4]u8, @splat(255));
    const png = try antfly_image.png.encodeRgba(std.testing.allocator, 8, 8, &rgba);
    defer std.testing.allocator.free(png);
    for ([_]Kind{ .encoded, .raster, .decoded }) |kind| {
        var controller = memory.AdmissionController{};
        defer controller.deinit();
        var fake = AdmissionDenyingFlorenceSession{};
        var session = fake.session();
        session.run_admission = .{ .controller = &controller, .backend_class = .cpu, .limits = .{}, .static_workspace_bytes = 0, .check_live_memory = false };
        var lane = execution.ExecutionLane{};
        const owner = try lane.acquire(.{ .io = std.testing.io });
        defer owner.release();
        var cancelled = std.atomic.Value(bool).init(false);
        var pipeline: ReadingPipeline = undefined;
        pipeline.allocator = std.testing.allocator;
        pipeline.vision_encoder = session;
        pipeline.config = .{ .image_size = 4, .resample = .pillow_bicubic };
        pipeline.native_execution_lane = &lane;
        pipeline.execution_control = .{ .io = std.testing.io, .ptr = &cancelled, .check_fn = Worker.check };
        var waiting = try std.testing.io.concurrent(Worker.run, .{ &pipeline, png, &rgba, kind });
        defer _ = waiting.cancel(std.testing.io) catch {};
        defer cancelled.store(true, .release);
        try Worker.awaitParked(&lane);
        // Codec/resampler slabs have retired; only the queued output remains.
        try std.testing.expectEqual(@as(usize, 3 * 4 * 4 * @sizeOf(f32)), controller.admitted.host_scratch_bytes);
        try std.testing.expect(!fake.run_called);
        cancelled.store(true, .release);
        try std.testing.expectError(error.Cancelled, waiting.await(std.testing.io));
        try std.testing.expect(std.meta.eql(memory.AdmissionAmounts{}, controller.admitted));
        try std.testing.expect(lane.head == null and lane.tail == null and lane.owned);
    }
}

test "Florence telemetry belongs to the calling thread during concurrent preprocessing" {
    const previous = last_read_telemetry;
    defer last_read_telemetry = previous;
    last_read_telemetry = .{ .generated_tokens = 999 };
    const Worker = struct {
        fn run(id: usize, ready: *std.atomic.Value(usize), go: *std.atomic.Value(bool), passed: *std.atomic.Value(usize)) void {
            last_read_telemetry = .{ .resident_decoder = true, .generated_tokens = id };
            _ = ready.fetchAdd(1, .acq_rel);
            while (!go.load(.acquire)) std.Thread.yield() catch {};
            const value = lastReadTelemetry();
            if (value.resident_decoder and value.generated_tokens == id)
                _ = passed.fetchAdd(1, .acq_rel);
        }
    };
    var ready = std.atomic.Value(usize).init(0);
    var go = std.atomic.Value(bool).init(false);
    var passed = std.atomic.Value(usize).init(0);
    const first = try std.Thread.spawn(.{}, Worker.run, .{ 11, &ready, &go, &passed });
    var first_joined = false;
    defer {
        go.store(true, .release);
        if (!first_joined) first.join();
    }
    const second = try std.Thread.spawn(.{}, Worker.run, .{ 22, &ready, &go, &passed });
    var second_joined = false;
    defer {
        go.store(true, .release);
        if (!second_joined) second.join();
    }
    const deadline = platform.time.monotonicNs() + 5 * std.time.ns_per_s;
    while (ready.load(.acquire) != 2) {
        if (platform.time.monotonicNs() >= deadline) return error.Timeout;
        std.Thread.yield() catch {};
    }
    try std.testing.expectEqual(@as(?usize, 999), lastReadTelemetry().generated_tokens);
    go.store(true, .release);
    first.join();
    first_joined = true;
    second.join();
    second_joined = true;
    try std.testing.expectEqual(@as(usize, 2), passed.load(.acquire));
}

const FlorenceAdmissionTests = struct {
    const memory = @import("../runtime/tier/memory.zig");
    fn config() florence_arch.Config {
        return .{
            .image_size = 8,
            .patch_size = .{ 1, 1, 1, 1 },
            .patch_stride = .{ 2, 2, 1, 1 },
            .patch_padding = .{ 0, 0, 0, 0 },
            .d_model = 4,
            .vocab_size = 8,
            .decoder_layers = 2,
        };
    }
    fn limits(amounts: memory.AdmissionAmounts) memory.Limits {
        return .{
            .host_limit_bytes = amounts.hostTotalBytes(),
            .backend_limit_bytes = amounts.backendTotalBytes(),
            .combined_limit_bytes = amounts.hostTotalBytes() + amounts.backendTotalBytes(),
            .kv_limit_bytes = amounts.kvTotalBytes(),
            .scratch_limit_bytes = amounts.scratchTotalBytes(),
        };
    }
    fn session(fake: *AdmissionDenyingFlorenceSession, controller: *memory.AdmissionController) backends.Session {
        var result = fake.session();
        result.run_admission = .{
            .controller = controller,
            .backend_class = .gpu,
            .limits = .{},
            .static_workspace_bytes = 0,
            .check_live_memory = false,
        };
        return result;
    }
};

test "Florence incremental admission keeps full backing KV while reserving one-step logits" {
    const cfg = FlorenceAdmissionTests.config();
    const full = try nativeFlorenceRunRequest(cfg, 2, 384, 3, 6);
    const incremental = try nativeFlorenceIncrementalRunRequest(cfg, 2, 384, 3, 6);
    try std.testing.expectEqual(full.input_bytes, incremental.input_bytes);
    try std.testing.expectEqual(full.sequence, incremental.sequence);
    try std.testing.expectEqual(@as(usize, 1792), incremental.output_kv_bytes);
    try std.testing.expectEqual(full.output_kv_bytes, incremental.output_kv_bytes);
    try std.testing.expectEqual(@as(usize, 2112), incremental.output_bytes.?);
    try std.testing.expectEqual(@as(usize, 320), full.output_bytes.? - incremental.output_bytes.?);
    try std.testing.expect(incremental.host_preprocess_bytes >= 2 * 6 * 2 * @sizeOf(i64));
    try std.testing.expectError(error.ResourceLimitExceeded, nativeFlorenceIncrementalRunRequest(cfg, 2, 384, 3, std.math.maxInt(usize)));
    try std.testing.expectError(error.InvalidInputShape, nativeFlorenceRunRequestForLogits(cfg, 2, 384, 3, 6, 0));
    try std.testing.expectError(error.InvalidInputShape, nativeFlorenceRunRequestForLogits(cfg, 2, 384, 3, 6, 7));
}

test "Florence incremental admission denies below its exact cap without executing the backend" {
    const memory = FlorenceAdmissionTests.memory;
    var controller = memory.AdmissionController{};
    defer controller.deinit();
    var fake = AdmissionDenyingFlorenceSession{};
    var session = FlorenceAdmissionTests.session(&fake, &controller);
    const cfg = FlorenceAdmissionTests.config();
    const request = try nativeFlorenceIncrementalRunRequest(cfg, 16, 3072, 3, 64);
    var full = try nativeFlorenceRunRequest(cfg, 16, 3072, 3, 64);
    full.host_preprocess_bytes = request.host_preprocess_bytes;
    const amounts = try session.run_admission.?.estimateRequest(request, &.{});
    session.run_admission.?.limits = FlorenceAdmissionTests.limits(amounts);
    session.run_admission.?.limits.backend_limit_bytes -= 1;
    try std.testing.expectError(error.ResourceLimitExceeded, session.admit(request));
    try std.testing.expectEqualDeep(memory.AdmissionAmounts{}, controller.snapshot());
    session.run_admission.?.limits.backend_limit_bytes += 1;
    try std.testing.expectError(error.ResourceLimitExceeded, session.admit(full));
    try std.testing.expectEqualDeep(memory.AdmissionAmounts{}, controller.snapshot());
    var permit = try session.admit(request);
    defer permit.deinit();
    try std.testing.expectEqualDeep(amounts, controller.snapshot());
    try std.testing.expect(!fake.run_called);
    permit.deinit();
    try std.testing.expectEqualDeep(memory.AdmissionAmounts{}, controller.snapshot());
}

test "Florence full-prefix supplement preserves the base on denial and owns only the additional peak" {
    const memory = FlorenceAdmissionTests.memory;
    var controller = memory.AdmissionController{};
    defer controller.deinit();
    var fake = AdmissionDenyingFlorenceSession{};
    var session = FlorenceAdmissionTests.session(&fake, &controller);
    const cfg = FlorenceAdmissionTests.config();
    const request = try nativeFlorenceIncrementalRunRequest(cfg, 16, 3072, 3, 64);
    const full = try nativeFlorenceRunRequest(cfg, 16, 3072, 3, 64);
    var full_with_metadata = full;
    full_with_metadata.host_preprocess_bytes = request.host_preprocess_bytes;
    const amounts = try session.run_admission.?.estimateRequest(request, &.{});
    const target = try session.run_admission.?.estimateRequest(full_with_metadata, &.{});
    try std.testing.expectEqual(amounts.host_kv_bytes, target.host_kv_bytes);
    try std.testing.expectEqual(amounts.backend_kv_bytes, target.backend_kv_bytes);
    session.run_admission.?.limits = FlorenceAdmissionTests.limits(amounts);
    var base = try session.admit(request);
    defer base.deinit();
    try std.testing.expectError(error.ResourceLimitExceeded, admitFlorenceFullPrefixFallback(session, &base, full));
    try std.testing.expectEqualDeep(amounts, controller.snapshot());
    try std.testing.expectEqualDeep(amounts, base.lease.?.amounts);
    try std.testing.expect(!fake.run_called);
    session.run_admission.?.limits = FlorenceAdmissionTests.limits(target);
    var supplement = try admitFlorenceFullPrefixFallback(session, &base, full);
    defer supplement.deinit();
    try std.testing.expectEqualDeep(target, controller.snapshot());
    try std.testing.expectEqualDeep(amounts, base.lease.?.amounts);
    inline for (@typeInfo(memory.AdmissionAmounts).@"struct".field_names) |name|
        try std.testing.expectEqual(@field(target, name) - @field(amounts, name), @field(supplement.lease.?.amounts, name));
    supplement.deinit();
    try std.testing.expectEqualDeep(amounts, controller.snapshot());
    base.deinit();
    try std.testing.expectEqualDeep(memory.AdmissionAmounts{}, controller.snapshot());
}

test "Florence full-prefix supplement preserves unmanaged standalone sessions" {
    var fake = AdmissionDenyingFlorenceSession{};
    const session = fake.session();
    const cfg = FlorenceAdmissionTests.config();
    const request = try nativeFlorenceIncrementalRunRequest(cfg, 2, 384, 3, 6);
    const full = try nativeFlorenceRunRequest(cfg, 2, 384, 3, 6);
    var base = try session.admit(request);
    defer base.deinit();
    var extra = try admitFlorenceFullPrefixFallback(session, &base, full);
    defer extra.deinit();
    try std.testing.expect(base.lease == null and extra.lease == null);
    try std.testing.expect(!fake.run_called);
}
