from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
s=(v/'run_engine52_resource_cases.py').read_text().replace("import hashlib,json,os,subprocess,sys","import hashlib,json,os,subprocess,sys,time")
s=s.replace("_r{n}_{mode}'","_r{n}_{mode}_retry2'")
s=s.replace(" for trial,on in enumerate(schedule):"," for trial,on in enumerate(schedule):\n  time.sleep(3)")
compile(s,'run_engine52_resource_cases_verify2.py','exec');(v/'run_engine52_resource_cases_verify2.py').write_text(s)
record=dict(status='initial_load_denied_before_execution',requested_bytes=11348275670,available_bytes=16621523435,reserve_bytes=6442450944,admissible_capacity_bytes=10179072491,initial_feature_enabled=False,scope='No timed round or kernel failure. Live OS reserve remains enforced. Existing native unit/C14/functional qualifications already pass; retry only remaining model qualification, small first then large, preserving original failure artifacts.')
(o/'engine52_initial_live_load_denial_audit.json').write_text(json.dumps(record,indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('qualification',list(Path('/private/tmp').glob('ocr-engine52-4b-*resource_dedup*.txt'))+[Path('/private/tmp/ocr-engine52-finalize-qualify-driver.txt')],'logs_manifest.json')
ns['archive']('drivers',[v/'prepare_engine52_resource_retry.py',v/'run_engine52_resource_cases_verify2.py'],'drivers_manifest.json')
