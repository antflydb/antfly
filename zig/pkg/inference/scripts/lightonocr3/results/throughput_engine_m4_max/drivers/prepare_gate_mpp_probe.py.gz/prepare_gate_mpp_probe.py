from pathlib import Path
v=Path('.venv-lighton-vllm-metal');variants=[(16,8,1),(16,16,1),(16,32,1),(16,32,2),(16,64,2),(16,64,4)]
msl='#include <metal_stdlib>\n#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\nusing namespace metal;using namespace mpp::tensor_ops;\nstruct Params{uint rows,in_dim,out_dim,pad;};\n'
for i,(m,n,sg)in enumerate(variants):
 msl+=f'''kernel void gate_mpp_{i}(device float*x[[buffer(0)]],device bfloat*gw[[buffer(1)]],device bfloat*uw[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){{
 tensor<device float,dextents<int,2>,tensor_inline>a(x,dextents<int,2>(p.in_dim,p.rows),array<int,2>{{1,int(p.in_dim)}});
 tensor<device bfloat,dextents<int,2>,tensor_inline>gmat(gw,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{{1,int(p.in_dim)}}),umat(uw,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{{1,int(p.in_dim)}});
 tensor<device float,dextents<int,2>,tensor_inline>c(y,dextents<int,2>(p.out_dim,p.rows),array<int,2>{{1,int(p.out_dim)}});
 auto left=a.slice(0,int(group.y)*{m});auto rightg=gmat.slice(0,int(group.x)*{n});auto rightu=umat.slice(0,int(group.x)*{n});auto dest=c.slice(int(group.x)*{n},int(group.y)*{m});
 constexpr auto desc=matmul2d_descriptor({m},{n},dynamic_length_v<int>,false,true,false);matmul2d<desc,execution_simdgroups<{sg}>>op;
 auto g=op.get_destination_cooperative_tensor<decltype(left),decltype(rightg),float>();auto u=op.get_destination_cooperative_tensor<decltype(left),decltype(rightu),float>();op.run(left,rightg,g);op.run(left,rightu,u);
 for(ushort i=0;i<g.get_capacity();i++){{auto coord=g.get_multidimensional_index(i);int col=int(group.x)*{n}+coord[0],row=int(group.y)*{m}+coord[1];if(coord[0]>=0&&coord[0]<{n}&&coord[1]>=0&&coord[1]<{m}&&col<int(p.out_dim)&&row<int(p.rows)){{float gs=g[i]+gb[col],us=u[i]+ub[col];g[i]=(gs/(1.0f+exp(-gs)))*us;}}}}
 g.store(dest);
}}\n'''
(v/'gate_mpp_probe.metal').write_text(msl)
