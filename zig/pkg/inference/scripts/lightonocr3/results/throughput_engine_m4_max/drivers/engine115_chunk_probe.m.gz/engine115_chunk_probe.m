#define main engine115_unused_main
#include "engine115_chunk_checks.m"
#undef main
int main(void){@autoreleasepool{
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 NSString*source=[NSString stringWithContentsOfFile:@".venv-lighton-vllm-metal/engine115_chunk.metal" encoding:NSUTF8StringEncoding error:nil];if(!source)return 2;
 MTLCompileOptions*options=[MTLCompileOptions new];options.fastMathEnabled=NO;
 NSError*error=nil;id<MTLLibrary>lib=[r->device newLibraryWithSource:source options:options error:&error];if(!lib){fprintf(stderr,"CHUNK115 compile %s\n",error.description.UTF8String);return 3;}
 private_chunk115_coeff=[r->device newComputePipelineStateWithFunction:[lib newFunctionWithName:@"chunk_coeff115"] error:&error];
 private_chunk115_state=[r->device newComputePipelineStateWithFunction:[lib newFunctionWithName:@"chunk_state115"] error:&error];
 if(!private_chunk115_coeff||!private_chunk115_state){fprintf(stderr,"CHUNK115 pipeline %s\n",error.description.UTF8String);return 4;}
 fprintf(stderr,"CHUNK115 pipelines coeff_tg=%zu state_tg=%zu state_smem=%zu\n",(size_t)private_chunk115_coeff.maxTotalThreadsPerThreadgroup,(size_t)private_chunk115_state.maxTotalThreadsPerThreadgroup,(size_t)private_chunk115_state.staticThreadgroupMemoryLength);
 private_chunk115_workspace=[r->device newBufferWithLength:(2048/16)*32*544*4 options:MTLResourceStorageModePrivate];if(!private_chunk115_workspace)return 5;
 const size_t lengths[]={17,31,32,128,432,554,662,2048};
 for(size_t h=16;h<=32;h+=16)for(size_t i=0;i<8;i++)for(size_t init=0;init<2;init++)if(prefill_core_check(r,lengths[i],h,init,true)){fprintf(stderr,"CHUNK115 FAIL seq=%zu heads=%zu init=%zu\n",lengths[i],h,init);return 6;}
 private_chunk115_workspace=nil;private_chunk115_coeff=nil;private_chunk115_state=nil;termite_metal_decode_runtime_destroy(r);fprintf(stderr,"CHUNK115 ALL FULL OUTPUT STATE GUARDS PASS\n");return 0;
}}
