from pathlib import Path
# Do not retain the measured 4B wide gate/up regression as a default.
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text()
needle='''    if (rows >= 32 &&
        ((in_dim == 1024 && out_dim == 3584) || (in_dim == 2560 && out_dim == 9216)) &&'''
assert s.count(needle)==1
s=s.replace(needle,'''    if (rows >= 32 && in_dim == 1024 && out_dim == 3584 &&''')
p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text()
needle='bool qualified = rows >= 32 && rows <= 64 && (in == 1024 || in == 2560);'
assert s.count(needle)==1
s=s.replace(needle,'bool qualified = rows >= 32 && rows <= 64 && in == 1024;')
p.write_text(s)
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text()
needle='    lighton_single_frame_stats: [2]u64 = @splat(0),';assert s.count(needle)==1
s=s.replace(needle,needle+'''
    lighton_gpu_greedy_stream: bool = false,
    lighton_gpu_greedy_stream_stats: [3]u64 = @splat(0),''')
needle='        self.lighton_single_frame_stats = @splat(0);';assert s.count(needle)==1
s=s.replace(needle,needle+'\n        self.lighton_gpu_greedy_stream_stats = @splat(0);')
needle='    pub fn noteLightOnStreamSplit(cb: *const ops.ComputeBackend) void {';assert s.count(needle)==1
s=s.replace(needle,'''    /// Explicit permission to stream a caller-owned greedy-token frame.
    /// The caller still owns tail submission, cancellation and token readback.
    pub fn setLightOnGpuGreedyStream(cb: *const ops.ComputeBackend, enabled: bool) !void {
        if (cb.kind() != .metal or
            cb.vtable.decoderRuntimeBeginFrame != &decoderRuntimeBeginFrameOp or
            cb.vtable.decoderRuntimeBeginPlannedComputeScope != &decoderRuntimeBeginPlannedComputeScopeOp)
        {
            if (enabled) return error.UnsupportedGpuGreedyStream;
            return;
        }
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        if (enabled and (!self.lightonocr3_projections or !metal_runtime_mod.qualifiedM4DeviceDefault() or
            self.lighton_stream_first_layers == 0 or !self.lighton_batch_attention))
            return error.UnsupportedGpuGreedyStream;
        self.lighton_gpu_greedy_stream = enabled;
    }

    pub fn lightOnGpuGreedyStreamEnabled(cb: *const ops.ComputeBackend) bool {
        if (cb.kind() != .metal or
            cb.vtable.decoderRuntimeBeginFrame != &decoderRuntimeBeginFrameOp or
            cb.vtable.decoderRuntimeBeginPlannedComputeScope != &decoderRuntimeBeginPlannedComputeScopeOp)
            return false;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return self.lighton_gpu_greedy_stream;
    }

    pub fn noteLightOnGpuGreedyStream(cb: *const ops.ComputeBackend, submits: u64, argmaxes: u64) void {
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        self.lighton_gpu_greedy_stream_stats[0] += 1;
        if (submits == 2) self.lighton_gpu_greedy_stream_stats[1] += 1;
        if ((submits != 1 and submits != 2) or argmaxes != 1) self.lighton_gpu_greedy_stream_stats[2] += 1;
    }

    pub fn lightOnGpuGreedyStreamStats(cb: *const ops.ComputeBackend) [3]u64 {
        if (!lightOnGpuGreedyStreamEnabled(cb)) return @splat(0);
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return self.lighton_gpu_greedy_stream_stats;
    }

'''+needle)
# Extend the existing poisoned-wrapper safety test, without touching raw provider fields.
needle='    probe.ocr_encoder_scope_opens = .{ 91, 92, 93 };';assert s.count(needle)==1
s=s.replace(needle,needle+'''
    probe.lighton_gpu_greedy_stream = true;
    probe.lighton_gpu_greedy_stream_stats = .{ 71, 72, 73 };''')
needle='    try std.testing.expect(!try MetalCompute.beginOcrEncoderScope(&cb, .vision));';assert s.count(needle)==1
s=s.replace(needle,'''    try std.testing.expectError(error.UnsupportedGpuGreedyStream, MetalCompute.setLightOnGpuGreedyStream(&cb, true));
    try std.testing.expect(!MetalCompute.lightOnGpuGreedyStreamEnabled(&cb));
    try std.testing.expectEqualDeep([3]u64{ 0, 0, 0 }, MetalCompute.lightOnGpuGreedyStreamStats(&cb));
    try std.testing.expectEqualDeep([3]u64{ 71, 72, 73 }, probe.lighton_gpu_greedy_stream_stats);
'''+needle)
p.write_text(s)
p=Path('zig/pkg/inference/src/architectures/gpt.zig');s=p.read_text()
needle='''        break :blk if (lightOnForwardSplitEligible(config, batch, isDecodeStep(decode_context), owns_qwen3vl_forward_frame, layers) and'''
assert s.count(needle)==1
s=s.replace(needle,'''        // Only the explicit native greedy-stream owner may lend its frame.
        // Ordinary borrowed frames retain the existing no-submit contract.
        const can_stream_frame = owns_qwen3vl_forward_frame or
            (metal_compute_mod.MetalCompute.lightOnGpuGreedyStreamEnabled(cb) and
                cb.decoderRuntimeHasActiveFrame() and !metal_compute_mod.MetalCompute.hasSubmittedFrame(cb));
        break :blk if (lightOnForwardSplitEligible(config, batch, isDecodeStep(decode_context), can_stream_frame, layers) and''')
# hasSubmittedFrame is not an MC public method: use a guarded helper added below.
s=s.replace('!metal_compute_mod.MetalCompute.hasSubmittedFrame(cb)','!metal_compute_mod.MetalCompute.lightOnHasSubmittedFrame(cb)')
needle='''            try cb.decoderRuntimeSetActiveFrameRegime(.decode);
            if (comptime build_options.enable_metal) metal_compute_mod.MetalCompute.noteLightOnStreamSplit(cb);'''
assert s.count(needle)==1
s=s.replace(needle,'''            try cb.decoderRuntimeSetActiveFrameRegime(.decode);
            if (comptime build_options.enable_metal) {
                if (metal_compute_mod.MetalCompute.lightOnGpuGreedyStreamEnabled(cb) and
                    getenvBoolDefault("ANTFLY_LIGHTONOCR3_TOKEN_ENCODER", true))
                    _ = try cb.decoderRuntimeBeginPlannedComputeScope();
                metal_compute_mod.MetalCompute.noteLightOnStreamSplit(cb);
            }''')
# Existing gpt utility only has getenvBool; use the shared platform helper explicitly.
s=s.replace('getenvBoolDefault("ANTFLY_LIGHTONOCR3_TOKEN_ENCODER", true)','@import("antfly_platform").env.getenvBoolDefault("ANTFLY_LIGHTONOCR3_TOKEN_ENCODER", true)')
p.write_text(s)
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text()
needle='    pub fn lightOnGpuGreedyStreamEnabled(cb: *const ops.ComputeBackend) bool {'
assert s.count(needle)==1
s=s.replace(needle,'''    pub fn lightOnHasSubmittedFrame(cb: *const ops.ComputeBackend) bool {
        if (!lightOnGpuGreedyStreamEnabled(cb)) return false;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return metal_runtime_mod.hasSubmittedFrame(self.provider_impl.raw_decode_runtime);
    }

'''+needle)
p.write_text(s)
p=Path('zig/pkg/inference/src/pipelines/generation.zig');s=p.read_text()
needle='    single_frame_lighton_decode: bool = false,';assert s.count(needle)==1
s=s.replace(needle,needle+'\n    gpu_greedy_stream_lighton_decode: bool = false,')
needle='''                if (self.single_frame_lighton_decode and self.gpt_config.hasQwen35VisionArchitectureContract()'''
assert s.count(needle)==1
s=s.replace(needle,'''                if ((self.single_frame_lighton_decode or self.gpu_greedy_stream_lighton_decode) and self.gpt_config.hasQwen35VisionArchitectureContract()''')
needle='                        M.noteLightOnSingleFrame(&self.cb, frames, on_frame);';assert s.count(needle)==1
s=s.replace(needle,'''                        if (self.gpu_greedy_stream_lighton_decode)
                            M.noteLightOnGpuGreedyStream(&self.cb, frames, on_frame)
                        else
                            M.noteLightOnSingleFrame(&self.cb, frames, on_frame);''')
p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text()
needle='            single_frame: bool = false,';assert s.count(needle)==1
s=s.replace(needle,needle+'\n            gpu_greedy_stream: bool = false,')
needle='''                features.shared_decoder_scratch = features.shared_decoder_scratch and cfg.qwen35_device_only_state;'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''
                features.gpu_greedy_stream = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_GPU_GREEDY_STREAM") and
                    metal_runtime.qualifiedM4DeviceDefault() and cfg.hasQwen35VisionArchitectureContract() and
                    cfg.qwen35_device_only_state and features.epoch_auxiliary and features.prepared and
                    features.activation_pool and features.batch_attention and features.stream_first_layers != 0 and
                    !features.single_frame;''')
needle='                    try M.setLightOnBatchAttention(&cb, ctx.features.batch_attention);';assert s.count(needle)==1
s=s.replace(needle,needle+'\n                    try M.setLightOnGpuGreedyStream(&cb, ctx.features.gpu_greedy_stream);')
needle='                .single_frame_lighton_decode = ctx.features.single_frame,';assert s.count(needle)==1
s=s.replace(needle,needle+'\n                .gpu_greedy_stream_lighton_decode = ctx.features.gpu_greedy_stream,')
needle='            .single_frame_lighton_decode = ctx.features.single_frame,';assert s.count(needle)==2 # includes the indented occurrence above
# Avoid the first initializer already extended.
s=s.replace(needle+'\n            .executor_sequence_control',needle+'\n            .gpu_greedy_stream_lighton_decode = ctx.features.gpu_greedy_stream,\n            .executor_sequence_control')
needle='''                    const token_scopes = if (comptime build_options.enable_metal)'''
assert s.count(needle)==1
s=s.replace(needle,'''                    const greedy_stream = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnGpuGreedyStreamStats(&cb) else @as([3]u64, @splat(0));
                    std.debug.print("LIGHTONOCR3 gpu_greedy_stream_steps={d}\\nLIGHTONOCR3 gpu_greedy_stream_two_frame_steps={d}\\nLIGHTONOCR3 gpu_greedy_stream_topology_mismatches={d}\\n", .{ greedy_stream[0], greedy_stream[1], greedy_stream[2] });
'''+needle)
needle='''    factory.features.vision_batch_items = 2;
    try std.testing.expectError(error.InvalidBatchDecodeState, ctx.admitPage(&factory, null, 0, page));
    factory.features = features;'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''
    factory.features.gpu_greedy_stream = true;
    try std.testing.expectError(error.InvalidBatchDecodeState, ctx.admitPage(&factory, null, 0, page));
    factory.features = features;''')
needle='''        "ANTFLY_LIGHTONOCR3_PREFILL_BATCH_ITEMS",    "ANTFLY_LIGHTONOCR3_VISION_BATCH_ITEMS",'''
assert s.count(needle)==1
s=s.replace(needle,needle+'\n        "ANTFLY_LIGHTONOCR3_GPU_GREEDY_STREAM",')
s+='''
test "LightOnOCR3 GPU greedy streaming reserves both physical64 frame envelopes" {
    const memory = runtime.tier.memory;
    const features = Node.LightOnStreamContext.ExecutionFeatures{
        .epoch_auxiliary = true, .prepared = true, .prepared_rows = 64,
        .stream_first_layers = 8, .batch_attention = true, .gpu_greedy_stream = true,
    };
    const amounts = features.auxiliaryAmounts();
    try std.testing.expectEqual(@as(usize, 66 * 1024 * 1024), amounts.backend_scratch_bytes);
    try std.testing.expectEqual(@as(usize, 3 * 1024 * 1024), amounts.host_scratch_bytes);
    var controller = memory.AdmissionController{};
    defer controller.deinit();
    var limits = memory.Limits{ .backend_limit_bytes = amounts.backend_scratch_bytes - 1,
        .host_limit_bytes = amounts.host_scratch_bytes,
        .scratch_limit_bytes = amounts.backend_scratch_bytes + amounts.host_scratch_bytes,
        .combined_limit_bytes = amounts.backend_scratch_bytes + amounts.host_scratch_bytes };
    try std.testing.expectError(error.ResourceLimitExceeded, controller.tryAcquire(.gpu, limits, amounts, false));
    try std.testing.expectEqualDeep(memory.AdmissionAmounts{}, controller.snapshot());
    limits.backend_limit_bytes += 1;
    var lease = try controller.tryAcquire(.gpu, limits, amounts, false);
    defer lease.release();
    try std.testing.expectEqualDeep(amounts, controller.snapshot());
    lease.release();
    try std.testing.expectEqualDeep(memory.AdmissionAmounts{}, controller.snapshot());
}
'''
p.write_text(s)
print('Added explicit GPU-greedy borrowed-frame streaming; 4B regressing gate/up tile rolled back.')
