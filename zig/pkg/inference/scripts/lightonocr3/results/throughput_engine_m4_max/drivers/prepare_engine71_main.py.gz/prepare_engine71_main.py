from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';o=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
# Prepared only. Run after the isolated main merge is committed and fast-forwarded
# into this original worktree, after every engine70 job has finished.
subprocess.run(['git','merge-base','--is-ancestor','730999bf2d','HEAD'],check=True)
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','zig/pkg/inference/src'])
old=json.loads((v/'engine70-freeze.json').read_text());main_paths=subprocess.check_output(['git','diff','--name-only','c3a2c534cf6b66db24d444144196074986092eb6','HEAD','--','zig/pkg/inference/src'],text=True).splitlines()
paths=set(old)|{p for p in main_paths if (root/p).is_file()};assert len(paths)>len(old)
(v/'engine71-freeze.json').write_text(json.dumps({p:sha(root/p)for p in sorted(paths)},indent=2)+'\n')
c=json.loads((o/'engine70_c_build_manifest.json').read_text());assert sha(root/c['binary'])==c['binary_sha256'];assert all(sha(root/p)==h for p,h in c['input_sha256'].items())
d=json.loads((o/'engine70_c_qualification_audit.json').read_text());assert d['status']=='pass'and d['all_checks_executed_after_final_checker_build'];d.update(reused_unchanged_c_qualification=True,source_audit_sha256=sha(o/'engine70_c_qualification_audit.json'),scope='Main integration changes no C runtime, shader, C headers or C checker input. Exact C70 inputs and binary verified; new Zig suites cover merged model manager, runtime lifecycle and Florence persistent cross cache.')
(o/'engine71_c_qualification_audit.json').write_text(json.dumps(d,indent=2)+'\n')
(v/'run_engine71_budget_policies.py').write_text((v/'run_engine70_budget_policies.py').read_text().replace('engine70','engine71'))
(v/'engine71_benchmark_concurrency.py').write_bytes((root/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
new_filters=['runtime snapshots','runtime identifiers','runtime snapshot','exact Whisper','instance identifiers','runtime unload','runtime model instances','composite decoder selection','startup split Whisper']
s=(v/'run_engine70_verify2_gpu_build.py').read_text().replace('engine70','engine71');a="filters=['microbatch broker'";assert a in s;s=s.replace(a,'filters='+repr(new_filters)+'+'+a.removeprefix('filters='),1);(v/'run_engine71_verify2_gpu_build.py').write_text(s)
s=(v/'run_engine70_metal_disabled.py').read_text().replace('engine70','engine71');s=s.replace("'-Dtest-filter=argmax']","'-Dtest-filter=argmax',"+','.join(repr('-Dtest-filter='+x)for x in new_filters)+']');(v/'run_engine71_metal_disabled.py').write_text(s)
print('prepared merged engine71 qualification, frozen inputs',len(paths))
