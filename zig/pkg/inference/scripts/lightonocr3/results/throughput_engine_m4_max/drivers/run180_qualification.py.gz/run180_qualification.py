from pathlib import Path
import datetime,json,os,psutil,signal,subprocess,sys,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'.ocr-shared-frame';origin=r.parent/'lightonocr3-08b';audit=o/'qualification180.json';assert not audit.exists()
parents=[]
for p in psutil.process_iter(['cmdline']):
 try:
  if any(x.endswith('/run_engine158_short161_screen.py') for x in p.info['cmdline']or[]) and Path(p.cwd())==origin:parents.append(p)
 except psutil.Error:pass
assert len(parents)==1;parent=parents[0];identity=dict(pid=parent.pid,create_time=parent.create_time(),cwd=parent.cwd(),cmdline=parent.cmdline());d=dict(status='hold_own_waiter',own_waiter=identity,runs=[])
def save():audit.write_text(json.dumps(d,indent=2)+'\n')
save();held=False
try:
 parent.send_signal(signal.SIGSTOP);held=True
 for _ in range(100):
  if parent.status()==psutil.STATUS_STOPPED:break
  time.sleep(.01)
 assert parent.status()==psutil.STATUS_STOPPED
 children=parent.children(recursive=True);assert not children,[(p.pid,p.cmdline())for p in children]
 while psutil.virtual_memory().available<8*1024**3:
  d.update(status='waiting_build_headroom',available_bytes=psutil.virtual_memory().available);save();print('WAIT180',d['available_bytes'],flush=True);time.sleep(15)
 for phase in ['cpu','gpu']:
  d['status']=phase+'_qualification';save();print('START180',phase,flush=True)
  log=Path('/private/tmp')/('ocr-engine180-'+phase+'-parent.txt');assert not log.exists()
  with log.open('w')as out:p=subprocess.run([sys.executable,str(v/('run_engine180_'+phase+'_build.py'))],stdout=out,stderr=subprocess.STDOUT)
  d['runs'].append(dict(phase=phase,exit_code=p.returncode));save();assert p.returncode==0
 d['status']='cpu_gpu_qualification_pass_real_shared_model_pending';save()
except BaseException as e:d.update(status='failed_or_excluded',error=repr(e));save();raise
finally:
 if held:
  p=psutil.Process(identity['pid']);assert p.create_time()==identity['create_time'] and p.cwd()==identity['cwd'] and p.cmdline()==identity['cmdline'];p.send_signal(signal.SIGCONT);d['own_waiter_resumed']=True;save();print('180 own waiter resumed',flush=True)
