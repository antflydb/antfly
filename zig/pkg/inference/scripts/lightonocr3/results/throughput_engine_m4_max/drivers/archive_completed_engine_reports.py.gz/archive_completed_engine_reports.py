from pathlib import Path
import gzip,hashlib,json,sys
root=Path.cwd();out=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
sha=lambda b:hashlib.sha256(b).hexdigest()
for pattern in sys.argv[1:]:
 for dest in sorted(out.glob(pattern)):
  rp=dest/'report.json'
  if not rp.exists():continue
  mf=dest/'raw_logs_manifest.json';index=json.loads(mf.read_text())if mf.exists()else{}
  for p in dest.rglob('*.txt'):
   raw=p.read_bytes();compressed=gzip.compress(raw,mtime=0);gz=p.with_suffix(p.suffix+'.gz');key=str(p.relative_to(dest))
   entry=dict(compressed_path=str(gz.relative_to(dest)),raw_sha256=sha(raw),raw_bytes=len(raw),compressed_sha256=sha(compressed))
   if key in index:assert index[key]==entry,(key,index[key],entry)
   gz.write_bytes(compressed);assert gzip.decompress(gz.read_bytes())==raw;index[key]=entry;p.unlink()
  mf.write_text(json.dumps(index,indent=2)+'\n')
  print('archived',dest.name)
