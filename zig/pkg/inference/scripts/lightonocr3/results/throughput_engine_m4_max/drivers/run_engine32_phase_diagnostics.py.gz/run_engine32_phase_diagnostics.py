from pathlib import Path
import json,os,subprocess,sys
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';p=root/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_engine_m4_max';manifest=out/'engine32_build_manifest.json';binary=json.loads(manifest.read_text())['binary_path']
images=[str(root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(p/'corpus/receipt.png'),str(p/'corpus/shipping.png')]
for model in ['4b','florence']:
 env=os.environ.copy();env.update(ANTFLY_LIGHTONOCR3_CPU_PREPROCESS='1',ANTFLY_LIGHTONOCR3_VISION_FRAME_BLOCKS='4',ANTFLY_LIGHTONOCR3_SINGLE_FRAME='1',ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS='1',ANTFLY_LIGHTONOCR3_PREFILL_DECODE_STREAK='0',TERMITE_METAL_TRACE_FRAME='all')
 dest=out/f'engine32_{model}_phase_diagnostic';cmd=[sys.executable,str(p/'benchmark_concurrency.py'),'--native-test',binary,'--model',('lighton4b='+str(v/'ocr-models/lighton4b')if model=='4b'else'florence=/Users/ajroetker/.antfly/inference/models/antflydb/florence-2-base'),'--images',*images,'--requests',('3'if model=='4b'else'8'),'--concurrency',('1'if model=='4b'else'8'),'--max-tokens','256','--modes','batch','--memory-gib','24','--shared-memory-gib','28','--backend-memory-gib','17','--kv-memory-gib','4','--scratch-memory-gib','10','--timeout','600','--build-manifest',str(manifest),'--output-dir',str(dest),'--profile-reader','--policy-rounds',('engineepoch'if model=='4b'else'current')]
 if model=='4b':cmd+=['--physical32','--batch-rows','32','--batch-window','32','--weight-residency','--continuous','--frame-policy','--weight-handles','--recurrent-parallel','--prefill-attention-mpp','--prefill-core-norm','--bf16-prefill-inputs']
 else:cmd+=['--native-read-batch-size','8','--disable-florence-single-frame']
 print('START',model,flush=True)
 with open(f'/private/tmp/ocr-engine32-{model}-phase-diagnostic.txt','w')as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 print('DONE',model,r.returncode,flush=True)
 if(dest/'report.json').exists():
  d=json.loads((dest/'report.json').read_text());d.update(primary_throughput_eligible=False,diagnostic_reason='Phase and frame tracing enabled; serial LightOn separates phase waits, Florence profiles baseline with single-frame disabled. Not a primary speed comparison.');(dest/'report.json').write_text(json.dumps(d,indent=2)+'\n')
 if r.returncode:sys.exit(r.returncode)
