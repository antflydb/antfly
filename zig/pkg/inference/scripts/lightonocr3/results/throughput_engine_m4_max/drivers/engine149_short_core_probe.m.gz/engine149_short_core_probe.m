#define main unused_short149_main
#include "engine149_short_core_checks.m"
#undef main
int main(int argc,const char**argv){@autoreleasepool{
 if(argc<2)return 1;engine149_pick=atoi(argv[1]);if(engine149_pick<1||engine149_pick>3)return 2;
 const bool benchmark=argc==3&&strcmp(argv[2],"--benchmark")==0;
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 3;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 const size_t qs[]={1,2,4,8,16,17,22,31,32,42,48,63,64,65,96,127,128};
 for(size_t h=16;h<=32;h+=16)for(size_t i=0;i<sizeof(qs)/sizeof(qs[0]);i++)for(size_t init=0;init<2;init++){
 int rc=prefill_core_check(r,qs[i],h,init,benchmark);if(rc){fprintf(stderr,"SHORT149 FAIL pick=%d h=%zu seq=%zu init=%zu rc=%d\n",engine149_pick,h,qs[i],init,rc);return rc+10;}
 }
 fprintf(stderr,"SHORT149 FULL CORE STATE INTERMEDIATE CANARY CHECKS PASS pick=%d benchmark=%d\n",engine149_pick,benchmark);
 termite_metal_decode_runtime_destroy(r);return 0;
}}
