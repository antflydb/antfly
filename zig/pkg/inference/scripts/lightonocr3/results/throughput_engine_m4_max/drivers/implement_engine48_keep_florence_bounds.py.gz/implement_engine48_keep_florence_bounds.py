from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((v/'engine46-freeze_retry.json').read_text());assert all(sha(Path(p))==s for p,s in old.items())
assert (out/'engine46_build_manifest.json').exists()
q=json.loads((out/'engine46_c_qualification_audit.json').read_text());assert q['status']=='pass' and len(q['checks'])==13
p=Path('zig/pkg/inference/src/pipelines/reading.zig');p.write_bytes((v/'engine48_reading_restoration.zig').read_bytes())
expected=json.loads((v/'engine45-freeze.json').read_text())[str(p)];assert sha(p)==expected
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text()
for text in [
 '            "ANTFLY_FLORENCE2_INCREMENTAL_ADMISSION",\n',
 '    parser.add_argument("--disable-florence-incremental-admission", action="store_true")\n',
]:
 assert s.count(text)==1,text;s=s.replace(text,'')
needle='''    env["ANTFLY_FLORENCE2_INCREMENTAL_ADMISSION"] = (
        "0" if args.disable_florence_incremental_admission else "1"
    )
'''
assert s.count(needle)==1;s=s.replace(needle,'');p.write_text(s)
audit=dict(status='not_promoted',scope='Review decision, not an observed OOM or a failed numerical test. Engine46 admission helpers and boundary tests pass, but shrinking decoder logits is insufficient proof of the separate vision encoder/host temporary peak, especially with alternate buffer reuse or fallback paths. Restore the exact qualified engine45 Florence reading source; retain the F32 full64 LightOn experiment. No caps are raised and no unknown encoder peak is credited.',restored_reading_sha256=expected,validated_experiment_manifest_sha256=sha(out/'engine46_build_manifest.json'))
(out/'engine46_florence_admission_review_decision.json').write_text(json.dumps(audit,indent=2)+'\n')
# New build/benchmark helpers; all previously executed helper bytes stay intact.
s=(v/'run_engine46_verify_gpu_build_retry.py').read_text().replace('ocr-engine46-verify-gpu-build-retry','ocr-engine48-verify-gpu-build')
s=s.replace("env['ANTFLY_TEST_FLORENCE2_INCREMENTAL_FALLBACK']='0'\n",'').replace("env['ANTFLY_FLORENCE2_INCREMENTAL_ADMISSION']='1'\n",'')
(v/'run_engine48_verify_gpu_build.py').write_text(s)
for name in ['run_engine46_budget_policies_verify.py','run_engine46_full64_cases.py','run_engine46_functional.py']:
 dest=v/name.replace('engine46','engine48');assert not dest.exists();dest.write_text((v/name).read_text().replace('engine46','engine48'))
(v/'engine48_benchmark_concurrency.py').write_bytes(p.read_bytes())
frozen={p:sha(Path(p))for p in old};(v/'engine48-freeze.json').write_text(json.dumps(frozen,indent=2)+'\n')
# Reuse only the C suites whose entire inputs and executed binary are identical.
assert all(sha(Path(p))==s for p,s in q['input_sha256'].items())
reuse=dict(status='pass',source_qualification='engine46_c_qualification_audit.json',source_qualification_sha256=sha(out/'engine46_c_qualification_audit.json'),checks=13,input_sha256=q['input_sha256'],binary_sha256=q['binary_sha256'],reason='Engine48 changes only Florence Zig restoration and its unused benchmark switch. C kernels, checker and all observed headers are byte-identical to the fresh 13-suite engine46 pass.')
(out/'engine48_c_qualification_reuse_audit.json').write_text(json.dumps(reuse,indent=2)+'\n')
ns={};a=(v/'archive_engine10_evidence.py').read_text();exec(a[:a.index("archive('qualification'")],ns)
ns['archive']('drivers',[v/x for x in ['implement_engine48_keep_florence_bounds.py','run_engine48_verify_gpu_build.py','run_engine48_budget_policies_verify.py','run_engine48_full64_cases.py','run_engine48_functional.py','engine48_benchmark_concurrency.py','engine48-freeze.json']],'drivers_manifest.json')
ns['archive']('qualification',[Path('/private/tmp/ocr-engine46-c-qualification-driver.txt')],'logs_manifest.json')
print('Restored SHA-verified Florence45; kept F32 full64 opt-in and frozen engine48.')
