from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=(v/'engine115_chunk_checks.m').read_text();pos=s.index('static int prefill_core_check(')
helper=r'''
static void split116(termite_metal_decode_runtime*r,id<MTLBuffer> __strong *buffers,const size_t*offsets,size_t seq,size_t vh){
 struct{uint32_t seq,kh,vh,dim,kernel,init;}p={(uint32_t)seq,16,(uint32_t)vh,128,4,0};
 for(size_t trial=0;trial<4;trial++)for(size_t order=0;order<2;order++){
  size_t mode=(trial+order)%2;id<MTLComputePipelineState>pipe=mode?private_chunk115_state:private_chunk115_coeff;
  id<MTLCommandBuffer>cb=[r->queue commandBuffer];id<MTLComputeCommandEncoder>e=[cb computeCommandEncoder];
  [e setComputePipelineState:pipe];for(size_t i=0;i<15;i++)[e setBuffer:buffers[i] offset:offsets[i] atIndex:i];[e setBytes:&p length:sizeof(p) atIndex:15];[e setBuffer:private_chunk115_workspace offset:0 atIndex:16];
  for(size_t repeat=0;repeat<20;repeat++){[e dispatchThreadgroups:MTLSizeMake(mode?vh*8:(seq/16)*vh,1,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];[e memoryBarrierWithScope:MTLBarrierScopeBuffers];}
  [e endEncoding];[cb commit];[cb waitUntilCompleted];if(cb.status!=MTLCommandBufferStatusCompleted)abort();
  printf("{\"scope\":\"pipeline_only\",\"seq\":%zu,\"heads\":%zu,\"trial\":%zu,\"pipeline\":%zu,\"gpu_us\":%.5f}\n",seq,vh,trial,mode,(cb.GPUEndTime-cb.GPUStartTime)*1e6/20.0);
 }
}
'''
s=s[:pos]+helper+s[pos:];needle='    free(state_seed);';pos=s.index(needle,s.index('static int prefill_core_check('));s=s[:pos]+'    split116(r,buffers[1],offsets,seq,vh);\n'+s[pos:];(v/'engine116_split_checks.m').write_text(s)
s=(v/'engine115_chunk_probe.m').read_text().replace('engine115_chunk_checks.m','engine116_split_checks.m');s=s.replace('const size_t lengths[]={17,31,32,128,432,554,662,2048};','const size_t lengths[]={128,432,554,662,2048};').replace('i<8','i<5').replace('init<2','init<1').replace('init,true)','init,false)');(v/'engine116_split_probe.m').write_text(s)
