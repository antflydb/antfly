from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal')
base=Path('zig/pkg/inference/src/backends/metal_kernels.m').read_text();s=base
needle='    id<MTLComputePipelineState> qwen35_recurrent_columns4_pipeline;';assert s.count(needle)==1
s=s.replace(needle,needle+'''
    id<MTLComputePipelineState> prefill_columns_probe8_pipeline, prefill_columns_probe16_pipeline;
    uint32_t prefill_columns_probe_variant, prefill_columns_probe_pick;
    uint64_t prefill_columns_probe_calls;''')
line=next(x for x in s.splitlines(True) if '"kernel void termite_qwen35_recurrent_columns4(' in x)
assert s.count(line)==1
s=s.replace(line,line+''.join(line.replace('recurrent_columns4',f'recurrent_columns{c}_probe').replace('columns_body<4>',f'columns_body<{c}>')for c in [8,16]))
line=next(x for x in s.splitlines(True) if 'runtime->qwen35_recurrent_columns4_pipeline = termite_metal_make_pipeline' in x)
s=s.replace(line,line+''.join(line.replace('qwen35_recurrent_columns4_pipeline',f'prefill_columns_probe{c}_pipeline').replace('termite_qwen35_recurrent_columns4',f'termite_qwen35_recurrent_columns{c}_probe')for c in [8,16]))
line='    runtime->qwen35_recurrent_columns4_pipeline = nil;';assert s.count(line)==1
s=s.replace(line,line+'\n    runtime->prefill_columns_probe8_pipeline = nil;\n    runtime->prefill_columns_probe16_pipeline = nil;')
needle='''            pipelines[3] = runtime->qwen35_recurrent_columns4_pipeline;
            grids[3] /= 4;'''
assert s.count(needle)==1
s=s.replace(needle,'''            const size_t columns = runtime->prefill_columns_probe_variant == 8 ? 8 :
                                   runtime->prefill_columns_probe_variant == 16 ? 16 : 4;
            id<MTLComputePipelineState> chosen = columns == 8 ? runtime->prefill_columns_probe8_pipeline :
                columns == 16 ? runtime->prefill_columns_probe16_pipeline : runtime->qwen35_recurrent_columns4_pipeline;
            if (chosen == nil || chosen.threadExecutionWidth != 32 ||
                chosen.maxTotalThreadsPerThreadgroup < 32 ||
                chosen.staticThreadgroupMemoryLength > runtime->device.maxThreadgroupMemoryLength) return -8;
            pipelines[3] = chosen;
            grids[3] /= columns;
            if (columns != 4) runtime->prefill_columns_probe_calls++;''')
needle='if (stage == 3 && pipelines[stage] == runtime->qwen35_recurrent_columns4_pipeline) width = 32;'
assert s.count(needle)==1
s=s.replace(needle,'''if (stage == 3 && (pipelines[stage] == runtime->qwen35_recurrent_columns4_pipeline ||
                pipelines[stage] == runtime->prefill_columns_probe8_pipeline ||
                pipelines[stage] == runtime->prefill_columns_probe16_pipeline)) width = 32;''')
(v/'engine46_prefill_columns_probe_kernels.m').write_text(s)
checker=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine46_prefill_columns_probe_kernels.m"')
a=checker.index('static int prefill_core_check(');b=checker.index('\nstatic ',a+10);part=checker[a:b]
needle='''            if (variant == 0 || variant == 3)
                setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_CORE_NORM", "1", 1);
            else
                unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_CORE_NORM");'''
assert part.count(needle)==1
part=part.replace(needle,'''            r->prefill_columns_probe_variant = variant == 0 ? 4 : r->prefill_columns_probe_pick;
            const uint64_t before_columns = r->prefill_columns_probe_calls;
            unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_CORE_NORM");''')
part=part.replace('(variant == 1 && seq >= 128 ? 1 : 0)','(seq >= 128 ? 1 : 0)')
needle='''            if (benchmark)
                printf'''
assert part.count(needle)==1
part=part.replace(needle,'''            if (r->prefill_columns_probe_calls - before_columns != (variant == 1 ? 1u : 0u)) return 9;
            if (benchmark)
                printf''')
needle=r'printf("{\"seq\":%zu,';assert part.count(needle)==1
part=part.replace(needle,r'printf("{\"columns\":%zu,\"seq\":%zu,')
needle='                       seq, vh, initialized, trial, variant, elapsed / 1000.0,'
assert part.count(needle)==1
part=part.replace(needle,'                       (size_t)r->prefill_columns_probe_variant, seq, vh, initialized, trial, variant, elapsed / 1000.0,')
checker=checker[:a]+part+checker[b:]
(v/'engine46_prefill_columns_probe_checks.m').write_text(checker)
wrapper='''#define main production_checks_main
#include "engine46_prefill_columns_probe_checks.m"
#undef main
int main(int argc,char**argv){@autoreleasepool{
 if(argc!=2)return 1;
 size_t columns=(size_t)strtoul(argv[1],NULL,10);if(columns!=8&&columns!=16)return 2;
 unsetenv("TERMITE_METAL_DISABLE_QWEN35_PREFILL_COLUMNS");
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 3;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);
 termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 r->prefill_columns_probe_pick=(uint32_t)columns;
 const size_t lengths[]={128,432,554,662,2048};
 for(size_t h=16;h<=32;h+=16)for(size_t i=0;i<5;i++){
  int rc=prefill_core_check(r,lengths[i],h,true,true);
  if(rc){fprintf(stderr,"PREFILL_COLUMNS_FAIL columns=%zu heads=%zu seq=%zu rc=%d\\n",columns,h,lengths[i],rc);return 20+rc;}
 }
 termite_metal_decode_runtime_destroy(r);
}return 0;}
'''
(v/'engine46_prefill_columns_probe.m').write_text(wrapper)
plan=dict(status='prepared_only_not_compiled_or_run',base_engine='engine44',base_c_sha256=hashlib.sha256(base.encode()).hexdigest(),
 candidates=[8,16],baseline_columns=4,heads=[16,32],seq=[128,432,554,662,2048],trials_per_case=30,
 checks='Both routes use parallel prefill norm; alternating order each trial. Same seeded recurrent state restored before every run. All GPU outputs/state compared to C4, canaries on every buffer, nonzero offsets, actual GPU conv/normalization producers, actual candidate-selection counter required. Original C4 arithmetic remains unchanged.')
(v/'engine46-prefill-columns-probe-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
build=(v/'build_engine46_streamed_prefill_tiles.py').read_text().replace('engine46_streamed_prefill_tiles','engine46_prefill_columns_probe').replace('engine46-streamed-prefill-tiles','engine46-prefill-columns-probe')
(v/'build_engine46_prefill_columns_probe.py').write_text(build)
print('Prepared ignored C8/C16 prefill core probes only; no runtime changes, compilation, or GPU work.')
