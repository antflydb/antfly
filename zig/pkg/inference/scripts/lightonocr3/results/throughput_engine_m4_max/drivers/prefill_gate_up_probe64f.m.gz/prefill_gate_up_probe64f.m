#include "../zig/pkg/inference/src/backends/metal_kernels.m"
static uint16_t bf(float x){uint32_t v;memcpy(&v,&x,4);return(uint16_t)((v+0x7fff+((v>>16)&1))>>16);}
static float fp(uint16_t x){uint32_t v=(uint32_t)x<<16;float f;memcpy(&f,&v,4);return f;}
static int encode(termite_metal_decode_runtime*r,id<MTLComputePipelineState>pso,size_t variant,size_t rows,size_t in,size_t out,id<MTLBuffer>x,id<MTLBuffer>packed,id<MTLBuffer>g,id<MTLBuffer>u,id<MTLBuffer>y){
 if(!pso){
  if(termite_metal_decode_runtime_apply_linear_multi_row_device(r,0,(__bridge void*)x,16,rows,in,out,(__bridge void*)g,0)||
     termite_metal_decode_runtime_apply_linear_multi_row_device(r,1,(__bridge void*)x,16,rows,in,out,(__bridge void*)u,0)||
     termite_metal_decode_runtime_apply_activation_multiply_device(r,2,(__bridge void*)g,0,(__bridge void*)u,0,rows,out,(__bridge void*)y,16))return 1;
  return 0;
 }
 id<MTLComputeCommandEncoder>e=r->active_planned_compute_encoder;
 if(!e)return 2;
 [e memoryBarrierWithScope:MTLBarrierScopeBuffers];
 uint32_t count=(uint32_t)(rows*in);
 [e setComputePipelineState:r->lightonocr3_pack_bf16_pipeline];[e setBuffer:x offset:16 atIndex:0];[e setBuffer:packed offset:0 atIndex:1];[e setBytes:&count length:4 atIndex:2];
 [e dispatchThreads:MTLSizeMake(count,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];
 [e memoryBarrierWithScope:MTLBarrierScopeBuffers];
 const uint32_t params[4]={(uint32_t)rows,(uint32_t)in,(uint32_t)out,0};
 [e setComputePipelineState:pso];[e setBuffer:packed offset:0 atIndex:0];
 [e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_weight_buffers[1] offset:0 atIndex:2];
 [e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:3];[e setBuffer:r->linear_bias_buffers[1] offset:0 atIndex:4];[e setBuffer:y offset:16 atIndex:5];[e setBytes:params length:sizeof(params) atIndex:6];
 size_t m=variant<6?32:64,n=variant<6?64:32;
 [e dispatchThreadgroups:MTLSizeMake((out+n-1)/n,(rows+m-1)/m,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];
 [e memoryBarrierWithScope:MTLBarrierScopeBuffers];return 0;
}
static int check(termite_metal_decode_runtime*r,id<MTLComputePipelineState> __strong *psos,size_t rows,size_t in,size_t out){
 @autoreleasepool{
 const size_t count=rows*out,wn=in*out;
 uint16_t*weights[2]={malloc(wn*2),malloc(wn*2)};float*bias[2]={malloc(out*4),malloc(out*4)},*gold=malloc(count*4);
 id<MTLBuffer>x=[r->device newBufferWithLength:(rows*in+8)*4 options:MTLResourceStorageModeShared];
 id<MTLBuffer>packed=[r->device newBufferWithLength:rows*in*2 options:MTLResourceStorageModePrivate];
 id<MTLBuffer>g=[r->device newBufferWithLength:count*4 options:MTLResourceStorageModePrivate],u=[r->device newBufferWithLength:count*4 options:MTLResourceStorageModePrivate],y=[r->device newBufferWithLength:(count+8)*4 options:MTLResourceStorageModeShared];
 if(!x||!packed||!g||!u||!y||!weights[0]||!weights[1]||!bias[0]||!bias[1]||!gold)return 3;
 uint32_t rng=87;
 for(size_t s=0;s<2;s++){
  for(size_t i=0;i<wn;i++){rng=rng*1664525u+1013904223u;weights[s][i]=bf(((int)(rng>>16)-32768)*.000001f);}
  for(size_t i=0;i<out;i++)bias[s][i]=cosf((float)i*.01f+(float)s)*.1f;
  if(termite_metal_decode_runtime_prepare_linear_bf16(r,s,(uint8_t*)weights[s],wn*2,bias[s],in,out))return 4;
 }
 float*xs=(float*)x.contents+4;for(size_t i=0;i<rows*in;i++)xs[i]=sinf((float)i*.01f);
 for(size_t variant=0;variant<8;variant++){
  double gpu[2]={0},wall[2]={0};float worst=0;size_t bitdiff=0;
  for(size_t trial=0;trial<18;trial++){
   int mode=trial<2?(int)trial:((trial-2)%4==1||(trial-2)%4==2);
   uint32_t*raw=y.contents;for(size_t i=0;i<count+8;i++)raw[i]=0xdeadbeef;
   uint64_t t=termite_metal_clock_monotonic_nanos();
   if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_set_active_frame_regime(r,TERMITE_METAL_FRAME_REGIME_PREFILL)||termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_FFN,TERMITE_METAL_COMPUTE_REGION_FFN))return 5;
   if(encode(r,mode?psos[variant]:nil,variant,rows,in,out,x,packed,g,u,y)||termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r))return 6;
   uint64_t dt=termite_metal_clock_monotonic_nanos()-t;
   if(trial>=2){gpu[mode]+=r->last_frame_gpu_nanos/1000.0;wall[mode]+=dt/1000.0;}
   float*got=(float*)y.contents+4;
   if(trial==0)memcpy(gold,got,count*4);
   if(mode&&trial==1){
    for(size_t i=0;i<count;i++){
     float diff=fabsf(got[i]-gold[i]);worst=fmaxf(worst,diff);if(got[i]!=gold[i])bitdiff++;
     if(!isfinite(got[i])||diff>2e-4f*(1+fabsf(gold[i]))){fprintf(stderr,"FAIL variant=%zu rows=%zu at=%zu gold=%g got=%g\n",variant,rows,i,gold[i],got[i]);return 7;}
    }
   }
   for(size_t i=0;i<4;i++)if(raw[i]!=0xdeadbeef||raw[count+4+i]!=0xdeadbeef)return 8;
  }
  for(size_t ri=0;ri<3;ri++)for(size_t ci=0;ci<3;ci++){
   size_t row=ri==0?0:ri==1?rows/2:rows-1,col=ci==0?0:ci==1?out/2:out-1;double sums[2]={bias[0][col],bias[1][col]};
   for(size_t k=0;k<in;k++)for(size_t s=0;s<2;s++)sums[s]+=(double)fp(bf(xs[row*in+k]))*fp(weights[s][col*in+k]);
   double want=(sums[0]/(1+exp(-sums[0])))*sums[1];if(fabs(gold[row*out+col]-want)>2e-4*(1+fabs(want)))return 9;
  }
  fprintf(stderr,"GUP_PREFILL rows=%zu in=%zu out=%zu variant=%zu cpu=pass full_output=pass canaries=pass max_abs=%g differing_elements_warm=%zu baseline_gpu_us=%.3f fused_gpu_us=%.3f ratio=%.5f baseline_wall_us=%.3f fused_wall_us=%.3f\n",rows,in,out,variant,worst,bitdiff,gpu[0]/8,gpu[1]/8,gpu[1]/gpu[0],wall[0]/8,wall[1]/8);
 }
 for(size_t s=0;s<2;s++){termite_metal_decode_runtime_clear_linear_slot(r,s);free(weights[s]);free(bias[s]);}free(gold);return 0;
 }
}
int main(int argc,const char**argv){@autoreleasepool{
 if(argc!=2)return 10;setenv("TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS","1",1);
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 11;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);
 NSError*err=nil;NSString*src=[NSString stringWithContentsOfFile:[NSString stringWithUTF8String:argv[1]] encoding:NSUTF8StringEncoding error:&err];
 MTLCompileOptions*opts=[MTLCompileOptions new];opts.languageVersion=MTLLanguageVersion4_0;opts.fastMathEnabled=NO;
 id<MTLLibrary>lib=[r->device newLibraryWithSource:src options:opts error:&err];if(!lib){fprintf(stderr,"%s\n",err.description.UTF8String);return 12;}
 id<MTLComputePipelineState>psos[8];for(size_t i=0;i<8;i++){psos[i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"candidate%zu",i]);if(!psos[i])return 13;}
 const size_t cases[][3]={{432,2560,9216},{662,2560,9216},{1324,2560,9216},{432,1024,3584},{662,1024,3584}};
 for(size_t i=0;i<5;i++){int rc=check(r,psos,cases[i][0],cases[i][1],cases[i][2]);if(rc){fprintf(stderr,"CHECK FAILED %d\n",rc);return rc;}}
 termite_metal_decode_runtime_destroy(r);return 0;
}}
