from pathlib import Path
import subprocess,os,hashlib,json
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');proposal=json.loads((v/'engine54_product_proposal_formatted.json').read_text())
for p,h in proposal['files'].items():assert hashlib.sha256((v/'engine54-product-proposal'/p).read_bytes()).hexdigest()==h,p
cmd=['clang','-O3','-fobjc-arc','-Izig/pkg/inference/src/backends',str(v/'engine54_product_checks.m'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-o',str(v/'engine54_product_conformance')]
with Path('/private/tmp/ocr-engine54-product-c-build.txt').open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')))
assert r.returncode==0,r.returncode
inputs=[v/'engine54_product_checks.m',Path(__file__),v/'engine54_product_proposal_formatted.json']+[v/'engine54-product-proposal'/p for p in proposal['files']]+[Path('zig/pkg/inference/src/backends')/x for x in ['metal_buffer_observation.h','metal_mtp_head.h','metal_mtp_head_impl.h']]
b=v/'engine54_product_conformance';m=dict(binary=str(b),binary_sha256=hashlib.sha256(b.read_bytes()).hexdigest(),input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in inputs})
(o/'engine54_product_c_build_manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('product proposal C compiled')
