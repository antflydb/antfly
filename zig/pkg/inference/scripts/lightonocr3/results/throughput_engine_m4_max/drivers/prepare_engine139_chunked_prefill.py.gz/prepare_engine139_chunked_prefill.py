from pathlib import Path
import difflib,hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';paths=['zig/pkg/inference/src/pipelines/generation.zig','zig/pkg/inference/src/server/server.zig','zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py'];original={p:(r/p).read_text()for p in paths};changed={}
s=original[paths[0]]
s=s.replace('    packed_prefill_items: u8 = 1,','    packed_prefill_items: u8 = 1,\n    /// Zero retains whole-prefix prefill; captured by the owning reader epoch.\n    prepared_qwen_prefill_chunk_rows: u16 = 0,',1)
a=s.index('        var work = PendingPrefillBatchWork{',s.index('    pub fn runScheduledPreparedQwenPrefill('));b=s.index('\n    }',a)
s=s[:a]+'''        const chunk_rows = if (self.prepared_qwen_prefill_chunk_rows == 0) seq else @min(seq, self.prepared_qwen_prefill_chunk_rows);
        var processed: usize = 0;
        scheduler.notePrefillProgress(lease, 0, seq);
        while (processed < seq) {
            const query = @min(chunk_rows, seq - processed);
            const end = processed + query;
            const final = end == seq;
            var decode_runtime = BorrowedDecodeStateRuntime.init(state);
            const context = decode_runtime.makeDecodeContext(end, query);
            var work = PendingPrefillBatchWork{ .allocator = self.allocator, .decode_state = state, .token_ids = &.{}, .seq_len = end, .query_seq_len = query, .wants_last_logits = final, .prepared_prompt = prepared };
            defer if (work.logits) |logits| work.allocator.free(logits);
            try scheduler.enqueuePrefillWork(lease.*, @ptrCast(&work), end, query, context.kv_sequence_len, context.kv_position_offset, pendingWorkOptionsFromState(state, query));
            defer if (!work.ready.load(.acquire)) scheduler.cancelPrefillWork(@ptrCast(&work));
            var driver = PrefillStepDriver{ .pipeline = self, .scheduler = scheduler, .work = &work, .decode_state = state };
            try runStepLoop(self.allocator, scheduler, lease, @ptrCast(&work), .prefill, io, null, &driver);
            if (work.failure) |err| return err;
            // The forward reserved exactly this prefix before mutating its KV
            // and recurrent histories. Never restart a partially consumed prefix.
            if (state.total_tokens != end) return error.InvalidBatchDecodeState;
            scheduler.notePrefillProgress(lease, end, seq);
            if (final) {
                const logits = work.logits orelse return error.InvalidBatchDecodeState;
                work.logits = null;
                return logits;
            }
            processed = end;
        }
        return error.InvalidPreparedPrompt;'''+s[b:]
needle='    fn forwardPackedScheduledQwenStep(self: *NativeGenerationPipeline, claimed:';assert s.count(needle)==1
helper='''    /// Validate every chunk against its original immutable visual prompt before
    /// reserving any peer KV or modifying any recurrent history.
    fn preparedQwenPrefillStart(work: *const PendingPrefillBatchWork, item: runtime.scheduler.native_generate.StepItem) !usize {
        const prompt = work.prepared_prompt orelse return error.InvalidPreparedPrompt;
        const full = prompt.plan.tokenCount();
        const positions = std.math.mul(usize, full, 3) catch return error.InvalidPreparedPrompt;
        if (item.phase != .prefill or work.query_seq_len == 0 or work.query_seq_len > work.seq_len or
            work.seq_len > full or work.seq_len != item.total_sequence_len or
            work.query_seq_len != item.query_sequence_len or prompt.plan.mrope_positions.len != positions or
            prompt.deepstack_layer_count != 0 or prompt.input_embeddings == null)
            return error.InvalidPreparedPrompt;
        const start = work.seq_len - work.query_seq_len;
        if (work.decode_state.total_tokens != start) return error.InvalidPreparedPrompt;
        return start;
    }

'''
s=s.replace(needle,helper+needle)
needle='        var offsets: [64]usize = undefined;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n        var prefill_starts: [64]usize = @splat(0);\n        var prefix_starts: usize = 0;\n        var prefix_finishes: usize = 0;')
needle='''                    if (work.decode_state.total_tokens != 0 or work.seq_len != item.query_sequence_len or prompt.plan.tokenCount() != item.query_sequence_len or prompt.plan.mrope_positions.len != 3 * item.query_sequence_len or prompt.deepstack_layer_count != 0 or prompt.input_embeddings == null) return error.InvalidPreparedPrompt;''';assert s.count(needle)==1;s=s.replace(needle,'''                    prefill_starts[index] = try preparedQwenPrefillStart(work, item);
                    prefix_starts += @intFromBool(prefill_starts[index] == 0);
                    prefix_finishes += @intFromBool(work.seq_len == prompt.plan.tokenCount());''')
needle='work.prepared_prompt.?.plan.mrope_positions[axis * lengths[index] ..][0..lengths[index]]';assert s.count(needle)==1;s=s.replace(needle,'work.prepared_prompt.?.plan.mrope_positions[axis * work.prepared_prompt.?.plan.tokenCount() + prefill_starts[index] ..][0..lengths[index]]')
needle='work.prepared_prompt.?.input_embeddings.?, 0, lengths[input_index]';assert s.count(needle)==1;s=s.replace(needle,'work.prepared_prompt.?.input_embeddings.?, prefill_starts[input_index], lengths[input_index]')
needle='        if (platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3")) std.debug.print("LIGHTONOCR3 packed_recurrent_groups=';assert s.count(needle)==1;s=s.replace(needle,'        if (platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3")) std.debug.print("LIGHTONOCR3 packed_step_prefill_starts={d} packed_step_prefill_finishes={d} prepared_prefill_chunk_rows={d}\\n", .{ prefix_starts, prefix_finishes, self.prepared_qwen_prefill_chunk_rows });\n'+needle)
changed[paths[0]]=s
s=original[paths[1]];needle='            packed_prefill_items: u8 = 1,';assert s.count(needle)==1;s=s.replace(needle,needle+'\n            prepared_prefill_chunk_rows: u16 = 0,')
needle='                if (features.packed_mixed) features.packed_prefill_items = @intCast(@min(@max(platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_PACKED_PREFILL_ITEMS") orelse 1, 1), generation.NativeGenerationPipeline.max_prepared_qwen_prefill_items));';assert s.count(needle)==1;s=s.replace(needle,needle+'''
                if (features.packed_mixed) {
                    const rows = platform.env.getenvUsize("ANTFLY_LIGHTONOCR3_PREFILL_QUERY_CHUNK_ROWS") orelse 0;
                    features.prepared_prefill_chunk_rows = if (rows == 0) 0 else @intCast(@min(@max(rows, 64), 1024));
                }''')
needle='.packed_prefill_items = ctx.features.packed_prefill_items,';assert s.count(needle)==2;s=s.replace(needle,needle+'\n                .prepared_qwen_prefill_chunk_rows = ctx.features.prepared_prefill_chunk_rows,')
changed[paths[1]]=s
s=original[paths[2]];needle='    env["ANTFLY_LIGHTONOCR3_PACKED_PREFILL_ITEMS"] = str(args.packed_prefill_items)';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    env["ANTFLY_LIGHTONOCR3_PREFILL_QUERY_CHUNK_ROWS"] = str(args.prepared_prefill_chunk_rows)')
needle='        "packed_prefill_items": args.packed_prefill_items,';s=s.replace(needle,needle+'\n        "prepared_prefill_chunk_rows": args.prepared_prefill_chunk_rows,')
needle='''                    sample["packed_prefill_pages"] = sum(
                        int(prefill) for prefill, _, _ in packed_steps
                    )''';assert s.count(needle)==1;s=s.replace(needle,'''                    sample["packed_prefill_chunks"] = sum(
                        int(prefill) for prefill, _, _ in packed_steps
                    )
                    chunk_progress = [tuple(map(int, values)) for values in re.findall(
                        r"LIGHTONOCR3 packed_step_prefill_starts=(\\d+) packed_step_prefill_finishes=(\\d+) prepared_prefill_chunk_rows=(\\d+)", section
                    )]
                    sample["packed_prefill_pages"] = (
                        sum(finishes for _, finishes, _ in chunk_progress)
                        if chunk_progress else sample["packed_prefill_chunks"]
                    )
                    sample["packed_prefill_starts"] = (
                        sum(starts for starts, _, _ in chunk_progress)
                        if chunk_progress else sample["packed_prefill_chunks"]
                    )
                    sample["prepared_prefill_chunk_rows"] = args.prepared_prefill_chunk_rows
                    if chunk_progress and (len(chunk_progress) != len(packed_steps) or any(
                        rows != args.prepared_prefill_chunk_rows for _, _, rows in chunk_progress
                    )):
                        result["status"] = "inconsistent_prepared_prefill_chunk_progress"
                    if args.require_prepared_prefill_chunks and (
                        not chunk_progress
                        or sample["packed_prefill_pages"] != args.requests
                        or sample["packed_prefill_starts"] != args.requests
                        or sample["packed_prefill_chunks"] <= sample["packed_prefill_pages"]
                    ):
                        result["status"] = "missing_actual_prepared_prefill_chunks"''')
needle='    parser.add_argument(\n        "--packed-mixed",';assert s.count(needle)==1;s=s.replace(needle,'''    parser.add_argument("--prepared-prefill-chunk-rows", type=int, default=0,
                        help="Split scheduled visual prefixes into bounded query chunks; 0 retains whole-prefix prefill")
    parser.add_argument("--require-prepared-prefill-chunks", action="store_true")
'''+needle)
needle='    if not 1 <= args.packed_prefill_items <= 8 or (';assert s.count(needle)==1;s=s.replace(needle,'''    if args.prepared_prefill_chunk_rows and (
        not args.packed_mixed or not 64 <= args.prepared_prefill_chunk_rows <= 1024
    ):
        parser.error("--prepared-prefill-chunk-rows must be64..1024 and requires --packed-mixed")
    if args.require_prepared_prefill_chunks and not args.prepared_prefill_chunk_rows:
        parser.error("--require-prepared-prefill-chunks requires --prepared-prefill-chunk-rows")
'''+needle)
changed[paths[2]]=s
for p,z in changed.items():(v/('engine139_'+Path(p).name)).write_text(z)
patch=''.join(''.join(difflib.unified_diff(original[p].splitlines(True),changed[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p))for p in paths);(v/'engine139_chunked_prefill_proposal.patch').write_text(patch);(v/'engine139_preparation.json').write_text(json.dumps(dict(status='private_proposal_not_applied_or_compiled',scope='Prepared-Qwen prefix chunk scheduling only. Original caps/whole-prefix admission unchanged. No C or Metal shader change. Tests and runtime qualification still required.',original_sha256={p:hashlib.sha256((r/p).read_bytes()).hexdigest()for p in paths},proposed_sha256={p:hashlib.sha256(changed[p].encode()).hexdigest()for p in paths}),indent=2)+'\n');print('Private proposal prepared; canonical source unchanged')
