from pathlib import Path
import subprocess,sys
s=Path('.venv-lighton-vllm-metal/engine5_gpu_tests.py').read_text();exec(s[:s.index('cmd=[str(')])
root=Path.cwd();env['ANTFLY_LIGHTONOCR3_EPOCH_AUX']='1'
env['ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS']='0'
env['ANTFLY_LIGHTONOCR3_BATCH_ATTENTION']='1'
env['ANTFLY_LIGHTONOCR3_EXTENDED_EPOCH']='1'
env['ANTFLY_LIGHTONOCR3_CONTENTION_WAIT_US']='1000'
env['TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS']='1'
env['ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS']='4'
env['ANTFLY_LIGHTONOCR3_SINGLE_FRAME']='0'
env['ANTFLY_LIGHTONOCR3_PHASE_FAIR']='1'
env['ANTFLY_LIGHTONOCR3_PHASE_PARK']='1'
env['ANTFLY_LIGHTONOCR3_EXECUTOR_TAIL']='1'
env['ANTFLY_LIGHTONOCR3_COMPACT_KV']='1'
env['ZIG_GLOBAL_CACHE_DIR']=str(root/'zig/.zig-cache/global')
import json
binary=json.loads((root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/engine21_build_manifest.json').read_text())['binary_path']
env['ANTFLY_LIGHTONOCR3_GATE_EVENTS']='0'
with open('/private/tmp/ocr-engine21-gate-events-rollback.txt','w')as out:r=subprocess.run([binary,'--test-filter','LightOnOCR3 real checkpoint transcribes'],cwd=root/'zig/pkg/inference',env=env,stdout=out,stderr=subprocess.STDOUT)
if r.returncode==0:
 text=Path('/private/tmp/ocr-engine21-gate-events-rollback.txt').read_text();assert 'gate_events=1'not in text and 'gate_events=0'in text
sys.exit(r.returncode)
