from pathlib import Path
import json,subprocess,sys,time
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');audit=o/'engine64_primary_controller_audit.json';assert not audit.exists()
parent=Path('/private/tmp/ocr-engine64-verify2-qualification-parent.txt')
record=dict(status='waiting_for_qualification',stages=[])
def save():audit.write_text(json.dumps(record,indent=2)+'\n')
save()
while True:
 s=parent.read_text()
 if 'ENGINE64 VERIFY2 QUALIFICATION DONE'in s:break
 if 'Traceback'in s:raise RuntimeError('qualification failed; no GPU throughput run launched')
 time.sleep(5)
for name,script,log in [('screen','run_engine64_screen1.py','/private/tmp/ocr-engine64-screen1-parent.txt'),('paired31','run_engine64_paired31.py','/private/tmp/ocr-engine64-paired31-parent.txt')]:
 record['status']=name;save();print('START',name,flush=True)
 with Path(log).open('w')as f:r=subprocess.run([sys.executable,str(v/script)],stdout=f,stderr=subprocess.STDOUT)
 record['stages'].append(dict(stage=name,exit_code=r.returncode,log=log));save();print('DONE',name,r.returncode,flush=True);assert r.returncode==0,(name,r.returncode)
record['status']='complete';save();print('ENGINE64 COMPARISON COMPLETE',flush=True)
