from pathlib import Path
import subprocess,os,json,hashlib
v=Path('.venv-lighton-vllm-metal');root=Path.cwd();f=json.loads((v/'engine65-freeze.json').read_text());assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in f.items())
env=os.environ.copy();env['ZIG_GLOBAL_CACHE_DIR']=str(root/'zig/.zig-cache/global')
cmd=['/Users/ajroetker/bin/zig-0.17.0/zig','build','inference-test','-Dmetal=false','-Doptimize=ReleaseFast','-Dstrip=true','-Dtest-filter=LightOnOCR3','-Dtest-filter=Qwen3-VL','-Dtest-filter=microbatch broker','-Dtest-filter=Florence','-Dtest-filter=execution lane','-Dtest-filter=argmax']
with Path('/private/tmp/ocr-engine65-metal-disabled.txt').open('w')as out:r=subprocess.run(cmd,cwd=root/'zig',env=env,stdout=out,stderr=subprocess.STDOUT)
print('Metal-disabled exit',r.returncode,flush=True);raise SystemExit(r.returncode)
