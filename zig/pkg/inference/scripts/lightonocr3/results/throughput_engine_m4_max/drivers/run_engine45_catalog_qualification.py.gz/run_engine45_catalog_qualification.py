from pathlib import Path
import hashlib,json,os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
binary=json.loads((out/'engine45_build_manifest.json').read_text())['binary_path'];records=[]
for b in [8,16,32,64]:
 env=os.environ.copy();env['ANTFLY_INFERENCE_READ_BATCH_SIZE']=str(b)
 log=Path(f'/private/tmp/ocr-engine45-catalog-batch{b}.txt');assert not log.exists()
 with log.open('w')as stream:r=subprocess.run([binary,'--test-filter','standalone inference model catalog publishes resolved native reader batching'],env=env,stdout=stream,stderr=subprocess.STDOUT)
 assert r.returncode==0,(b,r.returncode)
 raw=log.read_text();assert '1 selected; 1 passed;' in raw,raw
 records.append(dict(configured_batch_size=b,preferred_equals_max_published=True,log=str(log),raw_sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
(out/'engine45_catalog_qualification_audit.json').write_text(json.dumps(dict(status='pass',records=records),indent=2)+'\n')
