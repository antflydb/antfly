#define main projection_checks_main
#include "../zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m"
#undef main
int main(void) {
 @autoreleasepool {
  termite_metal_decode_runtime *r=termite_metal_decode_runtime_create();
  if(!r)return 1;
  termite_metal_decode_runtime_set_lightonocr3_projections(r,1);
  termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
  if(!r->lightonocr3_batch16_pipeline||!r->lightonocr3_recurrent_parallel_pipeline)return 2;
  setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_PARALLEL","1",1);
  const size_t batches[]={9,12,16};
  for(size_t i=0;i<3;i++){
   size_t rows=batches[i];
   if(batch_gate_up_check(r,rows,1024,3584,false)||batch_gate_up_check(r,rows,2560,9216,false)||projection(r,rows,1024,512,4)||projection(r,rows,2560,1024,4)||projection(r,rows,1024,257,4))return 3;
   for(size_t heads=16;heads<=32;heads+=16){
    int rc=fused_batch_core_check(r,16,heads,rows,false);
    if(rc){fprintf(stderr,"FAIL rows=%zu heads=%zu rc=%d\n",rows,heads,rc);return 10+rc;}
   }
  }
  termite_metal_decode_runtime_destroy(r);
 }
 puts("wide projection and independent recurrent state conformance passed");
 return 0;
}
