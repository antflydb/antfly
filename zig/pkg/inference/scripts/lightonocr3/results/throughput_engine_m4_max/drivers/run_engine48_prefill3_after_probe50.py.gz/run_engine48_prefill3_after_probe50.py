from pathlib import Path
import hashlib,json,subprocess,sys,time
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
p=out/'engine50_recurrent_probe_build_verify3_manifest.json'
print('WAIT completed probe50 continuation',flush=True)
marker=Path('/private/tmp/ocr-engine50-recurrent-probe-verify3-complete.json')
while not marker.exists():time.sleep(5)
for name,h in json.loads((v/'engine48-freeze.json').read_text()).items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h,name
for mode in ['qualification','primary']:
 print('START',mode,flush=True)
 with Path('/private/tmp/ocr-engine48-prefill3-'+mode+'-driver.txt').open('w')as log:r=subprocess.run([sys.executable,str(v/'run_engine48_prefill3_case.py'),mode],stdout=log,stderr=subprocess.STDOUT)
 print('DONE',mode,r.returncode,flush=True)
 ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
 ns['archive']('qualification',list(Path('/private/tmp').glob('ocr-engine48-*prefill3*'+mode+'*.txt')),'logs_manifest.json')
 assert r.returncode==0,(mode,r.returncode)
 subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine48_4b_prefill3*'+mode+'*'],check=True)
print('COMPLETE',flush=True)
