from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine69_prefill_screen51.py').read_text().replace('engine69','engine71').replace('prefill_screen51','prefill_batch_screen58').replace('prefill51','prefill_batch58')
a=s.index('profiles={');b=s.index('\n\naudit=',a)
s=s[:a]+'''profiles={
 'p1_c64_vf3':dict(settings=[64,1,1,3,0,0,0],prefill_stream_layers=0,pipeline_vision=False),
 'p2_c64_vf3':dict(settings=[64,2,1,3,0,0,0],prefill_stream_layers=0,pipeline_vision=False,prefill_wait_us=1000000),
 'p2_c60_vf3':dict(settings=[60,2,1,3,0,0,0],prefill_stream_layers=0,pipeline_vision=False,prefill_wait_us=1000000),
 'p4_c56_vf3':dict(settings=[56,4,1,3,0,0,0],prefill_stream_layers=0,pipeline_vision=False,prefill_wait_us=1000000),
}'''+s[b:]
s=s.replace('Corrected 64-row trace mask and observed counters. C64/P1/V1 four-step decode; compare coarser 16-layer prompt groups against a same-build nonstreamed prompt control, both synchronous VF3 vision. Two complete prompt working sets remain admitted under original caps. Full R128 text and pressure checks. Saved vLLM strings are a quality oracle only, never a fresh speed claim.','Merged main candidate: four-step decode with one, two or four-page prefill at bounded C64/C60/C56 and synchronous VF3 vision, zero prompt/vision streaming. Prior grouped-prefill candidates predate the four-step path. Existing additive admission charges two complete group working sets and original caps. Full R128 text and no-pressure eligibility. Freshly saved paired55 strings are a quality oracle only; this is an unpaired policy screen, not a speed claim against vLLM.')
s=s.replace("'_primary_reference47_r0_auto_c32_r128_ctx1024'","'_primary_reference55_r0_auto_c16_r128_ctx1024'")
# Expected exclusion path must reflect each candidate's actual concurrency/prefill.
s=s.replace("p=out/f'engine71_4b_prefill_batch_screen58_{key}_r0_c64_p1_v1_vf{vf}_r128/report.json'","c,pref=profiles[key]['settings'][:2]\n  p=out/f'engine71_4b_prefill_batch_screen58_{key}_r0_c{c}_p{pref}_v1_vf{vf}_r128/report.json'")
s=s.replace("raw=(p.parent/'lighton4b-batch-c64.txt').read_text()","raw=(p.parent/f'lighton4b-batch-c{c}.txt').read_text()")
compile(s,'run_engine71_prefill_batch_screen58.py','exec');(v/'run_engine71_prefill_batch_screen58.py').write_text(s)
print('prepared only: merged four-step decode plus grouped-prefill policy screen')
