from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine46_budget_policies.py').read_text()
needle=" wide64_gate_up=os.environ.get('OCR_WIDE64_GATE_UP','0')=='1'"
assert s.count(needle)==1
s=s.replace(needle," full64_gate_up=os.environ.get('OCR_FULL64_GATE_UP','0')=='1'\n if full64_gate_up:cmd+=['--full64-gate-up']\n"+needle)
needle="report['wide64_gate_up']=wide64_gate_up;"
assert s.count(needle)==1
s=s.replace(needle,"report['full64_gate_up']=full64_gate_up;"+needle)
needle="    assert 'wide_gate_up_calls' in sample,sample"
assert s.count(needle)==1
s=s.replace(needle,needle+"\n    assert (sample['full64_gate_up_calls']>0)==(model=='4b' and full64_gate_up and int(c)==64),sample")
s=s.replace("'standalone_wide_heads','single_frame_steps'","'standalone_wide_heads','full64_gate_up_calls','single_frame_steps'")
p=v/'run_engine46_budget_policies_verify.py';assert not p.exists();p.write_text(s)
# Pair the full cohort tile with the preceding generic-F32 baseline,
# rather than infer a candidate from an isolated microbenchmark.
s=(v/'run_engine45_wide64_cases.py').read_text().replace('engine45','engine46')
s=s.replace("for enabled in [False,True]:","schedule=[False,True] if mode=='qualification' else [True,False,False,True]\nfor trial,enabled in enumerate(schedule):")
s=s.replace("label=f'wide64_gate_up_enabled{int(enabled)}_physical64_c64_vf2_r{requests}_{mode}'","label=f'full64_gate_up_enabled{int(enabled)}_trial{trial}_physical64_c64_vf2_r{requests}_{mode}'")
s=s.replace("OCR_WIDE64_GATE_UP=str(int(enabled)),","OCR_WIDE64_GATE_UP=str(int(enabled)),OCR_FULL64_GATE_UP=str(int(enabled)),")
s=s.replace("v/'run_engine46_budget_policies.py'","v/'run_engine46_budget_policies_verify.py'")
s=s.replace(" assert (sample['wide_gate_up_calls']>0)==enabled"," assert (sample['wide_gate_up_calls']>0)==enabled\n assert (sample['full64_gate_up_calls']>0)==enabled\n if enabled:assert sample['full64_gate_up_calls']%32==0,sample['full64_gate_up_calls']")
s=s.replace("records.append(dict(wide64_gate_up=enabled,","records.append(dict(trial=trial,full64_gate_up=enabled,full64_gate_up_calls=sample['full64_gate_up_calls'],wide64_gate_up=enabled,")
s=s.replace("f'engine46_4b_wide64_gate_up_{mode}_audit.json'","f'engine46_4b_full64_gate_up_{mode}_audit.json'")
p=v/'run_engine46_full64_cases.py';assert not p.exists();p.write_text(s)
ns={};a=(v/'archive_engine10_evidence.py').read_text();exec(a[:a.index("archive('qualification'")],ns)
ns['archive']('drivers',[v/'prepare_engine46_full64_benchmarks.py',v/'run_engine46_budget_policies_verify.py',p],'drivers_manifest.json')
print('Prepared full64 qualification and four-run ON/OFF/OFF/ON primary controls.')
