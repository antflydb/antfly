from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=Path('zig/pkg/inference/src/backends/metal_kernels.m').read_text()
a=s.index('        "template<uint N, uint M=8> inline void termite_lightonocr3_gate_up_small_body(');b=s.index('        "kernel void termite_lightonocr3_gate_up_small16',a)
body=s[a:b].replace('template<uint N, uint M=8>','template<uint N, uint M, uint H>').replace('termite_lightonocr3_gate_up_small_body','termite_lightonocr3_gate_up_static_body').replace('a.slice(0,int(group.y)*M)','a.template slice<H,M>(0,int(group.y)*M)').replace('gmat.slice(0,int(group.x)*N)','gmat.template slice<H,N>(0,int(group.x)*N)').replace('umat.slice(0,int(group.x)*N)','umat.template slice<H,N>(0,int(group.x)*N)').replace('dest.slice(int(group.x)*N,int(group.y)*M)','dest.template slice<N,M>(int(group.x)*N,int(group.y)*M)')
wrapper=s[b:s.index('\n',b)];wrappers=[]
for i,(h,m,n)in enumerate([(1024,8,16),(2560,8,32),(1024,16,16),(2560,16,16)]):
 wrappers.append(wrapper.replace('termite_lightonocr3_gate_up_small16',f'termite_lightonocr3_gate_up_static{i}').replace('small_body<16>',f'static_body<{n},{m},{h}>'))
s=s[:b]+body+'\n'.join(wrappers)+'\n'+s[b:]
needle='    id<MTLComputePipelineState> lightonocr3_gate_up_wide16_pipeline;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    id<MTLComputePipelineState> static_extent_gate[4];\n    bool static_extent_gate_enabled;')
needle='            runtime->lightonocr3_gate_up_wide16_pipeline = termite_metal_make_pipeline(device, tensor_library, @"termite_lightonocr3_gate_up_wide16");';assert s.count(needle)==1;s=s.replace(needle,needle+'\n'+ '\n'.join(f'            runtime->static_extent_gate[{i}] = termite_metal_make_pipeline(device,tensor_library,@"termite_lightonocr3_gate_up_static{i}");'for i in range(4)))
needle='''    if (in_dim == 1024 && out_dim == 3584 && rows >= 2) {''';assert s.count(needle)==1;s=s.replace(needle,'''    if (runtime->static_extent_gate_enabled && (rows == 8 || rows == 16) &&
        ((in_dim == 1024 && out_dim == 3584) || (in_dim == 2560 && out_dim == 9216))) {
        const size_t index = (rows == 16 ? 2 : 0) + (in_dim == 2560 ? 1 : 0);
        if (runtime->static_extent_gate[index] != nil) return runtime->static_extent_gate[index];
    }
'''+needle,1)
# Selection for the existing wide pipeline precedes the original shape branches.
needle='''    if (rows >= 9 && in_dim == 2560 && out_dim == 9216 &&'''
if needle in s:
 start=s.index('    if (runtime->static_extent_gate_enabled');end=s.index('    if (in_dim == 1024',start);block=s[start:end];s=s[:start]+s[end:];i=s.index(needle);s=s[:i]+block+s[i:]
else:
 # Actual integrated wide condition can be written in the alternate order.
 start=s.index('    if (runtime->static_extent_gate_enabled');end=s.index('    if (in_dim == 1024',start);block=s[start:end];s=s[:start]+s[end:]
 at=s.rfind('    if (',0,s.index('    if (in_dim == 1024 && out_dim == 3584 && rows >= 2) {'))
 s=s[:at]+block+s[at:]
needle='''else if (small == runtime->lightonocr3_gate_up_wide16_pipeline && small != nil)''';assert s.count(needle)==1;s=s.replace(needle,'''else if (small != nil && runtime->static_extent_gate_enabled &&
            (small == runtime->static_extent_gate[0] || small == runtime->static_extent_gate[1] ||
             small == runtime->static_extent_gate[2] || small == runtime->static_extent_gate[3]))
            [encoder dispatchThreadgroups:MTLSizeMake(out_dim / ((in_dim == 2560 && rows == 8) ? 32 : 16), 1, 1) threadsPerThreadgroup:MTLSizeMake(32,1,1)];
        else if (small == runtime->lightonocr3_gate_up_wide16_pipeline && small != nil)''',1)
needle='''    if (rows < 2 || rows > 8 || !((in == 1024 && out == 3584) || (in == 2560 && out == 9216)) ||''';assert s.count(needle)==1;s=s.replace(needle,'''    if (r->static_extent_gate_enabled && rows == 8 &&
        ((in == 1024 && out == 3584) || (in == 2560 && out == 9216))) return nil;
'''+needle,1)
(v/'static_extent2_candidate_kernels.m').write_text(s)
s=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "static_extent2_candidate_kernels.m"')
a='''        r->lightonocr3_gate_up_small16_pipeline = nil;''';assert s.count(a)==1;s=s.replace(a,'''        bool static_enabled = r->static_extent_gate_enabled;
        r->static_extent_gate_enabled = false;
'''+a,1)
a='''        r->lightonocr3_gate_up_small16_pipeline = p16;''';assert s.count(a)==1;s=s.replace(a,'''        r->static_extent_gate_enabled = static_enabled;
'''+a,1);(v/'static_extent2_candidate_checks.m').write_text(s)
(v/'static_extent2_candidate.m').write_text('''#define main production_checks_main
#include "static_extent2_candidate_checks.m"
#undef main
int main(void) {
 @autoreleasepool {
  termite_metal_decode_runtime *r=termite_metal_decode_runtime_create();if(!r)return 1;
  termite_metal_decode_runtime_set_lightonocr3_projections(r,1);
  for(size_t i=0;i<4;i++)if(!r->static_extent_gate[i])return 2;
  for(size_t rows=8;rows<=16;rows+=8)for(size_t model=0;model<2;model++){
   size_t in=model?2560:1024,out=model?9216:3584;
   for(size_t trial=0;trial<4;trial++){
    bool enabled=trial==1||trial==2;r->static_extent_gate_enabled=enabled;
    fprintf(stderr,"STATIC_EXTENT rows=%zu model=%zu enabled=%d trial=%zu\\n",rows,model,enabled,trial);
    size_t index=(rows==16?2:0)+model;
    id<MTLComputePipelineState> chosen=termite_metal_lightonocr3_batch_gate_up_pipeline(r,rows,in,out);
    if(enabled!=(chosen==r->static_extent_gate[index]))return 3;
    int rc=batch_gate_up_check(r,rows,in,out,true);if(rc){fprintf(stderr,"FAIL rc=%d\\n",rc);return rc+10;}
   }
  }
  for(size_t i=0;i<4;i++)r->static_extent_gate[i]=nil;
  termite_metal_decode_runtime_destroy(r);
 }
 return 0;
}
''')
