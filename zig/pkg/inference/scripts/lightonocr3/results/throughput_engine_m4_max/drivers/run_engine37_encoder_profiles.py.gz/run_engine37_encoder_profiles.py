from pathlib import Path
import subprocess,sys
v=Path('.venv-lighton-vllm-metal')
for model in ['4b','small']:
 print('START',model,flush=True)
 r=subprocess.run([sys.executable,str(v/('run_engine37_'+model+'_encoder_profile.py'))])
 print('DONE',model,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
