from pathlib import Path
import json,sys,subprocess,time,os
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
(v/'engine66-follow48.pid').write_text(str(os.getpid()))
p=o/'paired47_4b_comparison_audit.json'
while True:
 d=json.loads(p.read_text())
 if d['status']!='running':break
 time.sleep(5)
if d['status']!='repeated_win':
 print('SKIPPED smaller-model repeats: 4B primary did not win both orders', d['status'],flush=True);sys.exit(0)
for name in ['08','florence']:
 print('START',name,flush=True)
 with Path('/private/tmp/ocr-engine66-'+name+'-paired48-parent.txt').open('w')as log:
  subprocess.run([sys.executable,str(v/('run_engine66_'+name+'_paired48.py'))],stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
print('ENGINE66 FOLLOWTHROUGH DONE',flush=True)
