from pathlib import Path
import json,hashlib,subprocess,re,gzip,os
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();f=json.loads((v/'engine111-freeze.json').read_text());assert all(sha(p)==h for p,h in f.items())
log=Path('/private/tmp/ocr-engine111-verify3-gpu-build.txt').read_text();hits=re.findall(r'\.zig-cache/o/([0-9a-f]{32})/test(?:\s|$)',log);assert hits;binary=r/'zig/.zig-cache/o'/hits[-1]/'test';assert binary.exists()
base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();diff=subprocess.check_output(['git','diff',base,'--',*f]);patch=o/'engine111_runtime.patch.gz';assert not patch.exists();patch.write_bytes(gzip.compress(diff,mtime=0))
d=dict(benchmark_script_sha256=f['zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py'],runtime_commit=base,runtime_source_diff_sha256=hashlib.sha256(diff).hexdigest(),runtime_files_sha256=f,binary_sha256=sha(binary),binary_path=str(binary))
p=o/'engine111_build_manifest.json';assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n');hard=v/'qualified-binaries/engine111-test';assert not hard.exists();os.link(binary,hard);print('MANIFEST',binary,d['binary_sha256'])
