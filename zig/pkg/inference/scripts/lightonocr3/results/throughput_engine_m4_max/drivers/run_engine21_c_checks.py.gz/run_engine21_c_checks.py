from pathlib import Path
import datetime,hashlib,json,subprocess,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';out=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();binary=v/'engine21_conformance'
record={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary_sha256':digest(binary),'kernel_sha256':digest(r/'zig/pkg/inference/src/backends/metal_kernels.m'),'checker_sha256':digest(r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m'),'functional_only':True,'own_cpu_compile_overlap':True,'commands':[{'flag':'full-functional','exit_code':0,'log':'/private/tmp/ocr-engine21-c-full-functional.txt','log_sha256':digest(Path('/private/tmp/ocr-engine21-c-full-functional.txt'))}],'preset_probe':{'binary_sha256':digest(v/'engine21_profile_check'),'source_sha256':digest(v/'engine21_profile_check.m'),'log_sha256':digest(Path('/private/tmp/ocr-engine21-profile-c-functional.txt'))}}
for flag in ['--check-batch-attention','--check-prefill-pack-reuse']:
 log=Path('/private/tmp')/('ocr-engine21-c-'+flag.removeprefix('--')+'.txt')
 with log.open('w')as f:res=subprocess.run([str(binary),flag],stdout=f,stderr=subprocess.STDOUT)
 record['commands'].append({'flag':flag,'exit_code':res.returncode,'log':str(log),'log_sha256':digest(log)})
 print(flag,res.returncode,flush=True)
 if res.returncode:break
(out/'engine21_c_qualification_manifest.json').write_text(json.dumps(record,indent=2)+'\n');sys.exit(res.returncode)
