from pathlib import Path
import hashlib,json
v=Path('.venv-lighton-vllm-metal')
for f,h in json.loads((v/'engine29-freeze.json').read_text()).items():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==h,f
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text()
a=s.index('    pub fn lightOnPreparedBlockCount(')
method="""    /// Stream only after a complete ordinary forward has prepared every
    /// linear layer and the persistent workspace. A submitted prefix must
    /// never trigger weight upload or workspace allocation in its suffix.
    pub fn lightOnPreparedStreamReady(cb: *const ops.ComputeBackend, config: anytype, rows: usize) bool {
        if (cb.kind() != .metal or rows < 2 or rows > 32 or !lightOnPreparedConfigEligible(config)) return false;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        if (!self.lightonocr3_projections or !self.lightonocr3_policy.packed_core or
            rows > self.lighton_prepared_rows or self.lighton_prepared_hidden != config.hidden_size or
            platform.env.getenvBool("TERMITE_METAL_DISABLE_QWEN35_RECURRENT_CORE") or
            platform.env.getenvBool("TERMITE_METAL_DISABLE_QWEN35_CORE_BATCH") or
            config.num_hidden_layers > self.lighton_prepared_layers.len) return false;
        for (0..config.num_hidden_layers) |layer| {
            if (config.layerUsesQwen35LinearAttention(layer)) {
                const plan = self.lighton_prepared_layers[layer] orelse return false;
                for (plan.norms) |norm| if (norm == null) return false;
            }
        }
        for (self.lighton_prepared_workspace) |tensor| if (tensor == null) return false;
        return true;
    }

"""
s=s[:a]+method+s[a:]
s=s.replace('!metal_runtime.hasActiveFrame(raw) or cb.decoderRuntimeHasSubmittedFrame() or','!metal_runtime.hasActiveFrame(raw) or\n            (cb.decoderRuntimeHasSubmittedFrame() and !lightOnPreparedStreamReady(cb, config, states.len)) or',1)
p.write_text(s)
p=Path('zig/pkg/inference/src/architectures/gpt.zig');s=p.read_text();old='break :blk if (lightOnForwardSplitEligible(config, batch, isDecodeStep(decode_context), owns_qwen3vl_forward_frame, layers)) layers else 0;';assert old in s;s=s.replace(old,'break :blk if (lightOnForwardSplitEligible(config, batch, isDecodeStep(decode_context), owns_qwen3vl_forward_frame, layers) and\n            metal_compute_mod.MetalCompute.lightOnPreparedStreamReady(cb, config, batch)) layers else 0;',1)
s=s.replace('return decode and owns_frame and batch >= 2 and batch <= 16 and layers >= 1','return decode and owns_frame and batch >= 2 and batch <= 32 and layers >= 1',1)
s=s.replace('try std.testing.expect(!lightOnForwardSplitEligible(config, 17, true, true, 4));','try std.testing.expect(lightOnForwardSplitEligible(config, 17, true, true, 4));\n        try std.testing.expect(lightOnForwardSplitEligible(config, 32, true, true, 4));\n        try std.testing.expect(!lightOnForwardSplitEligible(config, 33, true, true, 4));',1)
p.write_text(s)
print('30 drafted bounded32 streaming after all prepared plans are ready')

p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text();old="""                if (features.stream_first_layers != 0) {
                    // Bound a prefix in flight while the suffix is encoded.
                    amounts.backend_scratch_bytes += 8 * 1024 * 1024;""";new="""                if (features.stream_first_layers != 0) {
                    // Bound a prefix in flight while the suffix is encoded.
                    amounts.backend_scratch_bytes += (if (features.prepared_rows > 16) @as(usize, 12) else 8) * 1024 * 1024;""";assert old in s;s=s.replace(old,new,1)
anchor='test "LightOnOCR3 batched attention reserves two disjoint frame scratch banks" {'
assert anchor in s;s=s.replace(anchor,"""test "LightOnOCR3 physical32 streaming admits prepared and overlap envelopes together" {
    const features = Node.LightOnStreamContext.ExecutionFeatures{ .epoch_auxiliary = true, .prepared = true, .prepared_rows = 32, .stream_first_layers = 4, .batch_attention = true };
    const amounts = features.auxiliaryAmounts();
    try std.testing.expect(features.needsAuxiliary());
    try std.testing.expectEqual(@as(usize, 42 * 1024 * 1024), amounts.backend_scratch_bytes);
    try std.testing.expectEqual(@as(usize, 3 * 1024 * 1024), amounts.host_scratch_bytes);
}

"""+anchor,1);p.write_text(s)

# Publish the explicit new rollback CLI flags in the tracked benchmark.
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');p.write_text((v/'engine29_benchmark_concurrency.py').read_text())
