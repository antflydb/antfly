from pathlib import Path
import hashlib,json,subprocess
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert json.loads((o/'paired73_4b_comparison_audit.json').read_text())['status']=='native_behind';assert json.loads((o/'engine89_real_tiles_audit.json').read_text())['status']=='prototype_pass'
p=json.loads((v/'engine90_proposal.json').read_text());assert all(sha(r/f)==h for f,h in p['original_sha256'].items())
for f in p['original_sha256']:
 source=v/('engine90_proposed_'+Path(f).name);assert sha(source)==p['proposed_sha256'][f];(r/f).write_bytes(source.read_bytes())
print('Applied harness-only precision rounds and untimed lifetime gauges. C/runtime kernels unchanged.',flush=True)
