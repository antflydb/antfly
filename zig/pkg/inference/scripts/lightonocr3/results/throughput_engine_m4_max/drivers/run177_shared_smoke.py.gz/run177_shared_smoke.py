from pathlib import Path
import datetime,hashlib,json,os,psutil,signal,subprocess,sys,time,re
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';origin=r.parent/'lightonocr3-08b';audit=o/'engine174_shared177_audit.json';assert not audit.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();freeze=json.loads((v/'engine174-freeze.json').read_text());assert all(sha(r/p)==h for p,h in freeze.items())
parents=[]
for p in psutil.process_iter(['cmdline']):
 try:
  if any(x.endswith('/run_engine158_short161_screen.py')for x in p.info['cmdline']or[]) and Path(p.cwd())==origin:parents.append(p)
 except psutil.Error:pass
assert len(parents)==1;parent=parents[0];identity=dict(pid=parent.pid,create_time=parent.create_time(),cwd=parent.cwd(),cmdline=parent.cmdline());d=dict(status='hold_own_waiter',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),own_waiter=identity,primary_throughput_eligible=False,driver_sha256=sha(Path(__file__)),scope='Candidate174 shared-frame exact-output/topology smoke using0.8Bcheckpoint C8R16; not a speed claim. Source158 C24 code identical, CPU298/38 and Metal334/6 passed. Original caps/reserve unchanged. Verified own admissionwaiter held only to avoid overlap and resumed in finally.')
def save():audit.write_text(json.dumps(d,indent=2)+'\n')
save();held=False
try:
 parent.send_signal(signal.SIGSTOP);held=True
 for _ in range(100):
  if parent.status()==psutil.STATUS_STOPPED:break
  time.sleep(.01)
 assert parent.status()==psutil.STATUS_STOPPED
 assert not parent.children(recursive=True)
 while psutil.virtual_memory().available<3000000000+6*1024**3+512*1024**2:
  d.update(status='waiting_original_reserve',available_bytes=psutil.virtual_memory().available);save();print('WAIT177',d['available_bytes'],flush=True);time.sleep(15)
 env=dict(os.environ);env.update(json.loads((v/'shared177_environment.json').read_text()));d['status']='running';save();print('START177 shared frame real0.8B',flush=True)
 log=Path('/private/tmp/ocr-engine174-shared177-driver.txt');assert not log.exists()
 with log.open('w')as out:p=subprocess.run([sys.executable,str(v/'run_engine174_budget_policies.py'),'08:shared177_c8_r16'],env=env,stdout=out,stderr=subprocess.STDOUT,timeout=1800)
 d['exit_code']=p.returncode;d['driver_log_sha256']=sha(log);save();assert p.returncode==0
 dest=o/'engine174_08_shared177_c8_r16';rp=dest/'report.json';report=json.loads(rp.read_text());res=report['results'][0];sample=res['policy_rounds'][0];assert res['status']=='ok'and res['serial_reference_parity']and res['cross_runtime_full_fixture_string_identity'];assert sample['completed']==16 and not sample['admission_pressures']and sample['host_recurrent_bytes_total']==0
 raw=(dest/res['log']).read_text();rows=[(int(a),int(b))for a,b in re.findall(r'packed_shared_frame=(\d+) packed_forward_submissions=(\d+)',raw)];shared=[b for a,b in rows if a];assert shared and all(b==1 for b in shared),rows
 assert all(sha(r/p)==h for p,h in freeze.items())
 d.update(status='all16_outputs_exact_shared_forward_one_submission',report_sha256=sha(rp),report=str(rp.relative_to(o)),actual_shared_forward_steps=len(shared),submissions_per_shared_forward=sorted(set(shared)),all_outputs_exact=True);save();print('PASS177',len(shared),'actual shared frames',flush=True)
except BaseException as e:d.update(status='failed_or_excluded',error=repr(e));save();raise
finally:
 if held:
  p=psutil.Process(identity['pid']);assert p.create_time()==identity['create_time']and p.cwd()==identity['cwd']and p.cmdline()==identity['cmdline'];p.send_signal(signal.SIGCONT);d['own_waiter_resumed']=True;save();print('177 own waiter resumed',flush=True)
