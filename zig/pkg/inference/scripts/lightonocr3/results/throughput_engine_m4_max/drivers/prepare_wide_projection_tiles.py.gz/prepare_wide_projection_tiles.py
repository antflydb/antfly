from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=Path('zig/pkg/inference/src/backends/metal_kernels.m').read_text()
a='    id<MTLComputePipelineState> lightonocr3_gate_up_wide16_pipeline;';assert s.count(a)==1;s=s.replace(a,a+'\n    bool wide_tile_probe;\n    size_t wide_tile_probe_calls;',1)
a=s.index('int termite_metal_decode_runtime_apply_linear_multi_row_device(');i=s.index('        const int local_rc=',a)
body=(v/'wide_projection_tiles.inc').read_text().replace('WIDE_TILE_ENABLED','runtime->wide_tile_probe').replace('WIDE_TILE_COUNT','runtime->wide_tile_probe_calls += 1')
s=s[:i]+body+s[i:];(v/'wide_projection_tiles_kernels.m').write_text(s)
s=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "wide_projection_tiles_kernels.m"')
a='''    const int rc = rows == 1 ? termite_metal_decode_runtime_apply_linear_device''';assert s.count(a)==1;s=s.replace(a,'''    const bool owns_frame = !r->active_frame_cb;
    if (owns_frame && (termite_metal_decode_runtime_begin_frame(r) || termite_metal_decode_runtime_set_active_frame_regime(r, TERMITE_METAL_FRAME_REGIME_DECODE))) return -200;
    const int rc = rows == 1 ? termite_metal_decode_runtime_apply_linear_device''',1)
a='''    if (rc)
        return rc;
    for (size_t i = 0; i < 4; i++)''';assert s.count(a)==1;s=s.replace(a,'''    if (rc) {
        if (owns_frame) termite_metal_decode_runtime_cancel_frame(r);
        return rc;
    }
    if (owns_frame && (termite_metal_decode_runtime_submit_frame(r) || termite_metal_decode_runtime_wait_frame(r))) return -201;
    for (size_t i = 0; i < 4; i++)''',1);(v/'wide_projection_tiles_checks.m').write_text(s)
