from pathlib import Path
import hashlib,json,os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
mode=sys.argv[1];assert mode in ['qualification','primary']
models=sys.argv[2:]or(['4b','08']if mode=='qualification'else['4b'])
n=64 if mode=='qualification'else 128
for model in models:
 assert model in ['4b','08'];records=[]
 schedule=[False,True]if mode=='qualification'else[True,False,False,True]
 for trial,on in enumerate(schedule):
  large=model=='4b';prefix=0 if large else 16
  label=f'resource_dedup_enabled{int(on)}_trial{trial}_physical64_c64_vf{2 if large else 4}_prefix{prefix}_full64{int(large)}_r{n}_{mode}'
  dest=o/f'engine52_{model}_{label}';assert not(dest/'report.json').exists()
  env=os.environ.copy()
  env.update(OCR_REFERENCE_LABEL='_primary_reference20_r0_auto_c64_r128',OCR_PHYSICAL32='0',OCR_PHYSICAL64='1',
   OCR_CONCURRENCY='64',OCR_REQUESTS=str(n),OCR_WIDE='1',OCR_SCRATCH_GIB='10'if large else'8',
   OCR_BACKEND_GIB='17'if large else'16',OCR_KV_GIB='4',OCR_CPU_PREPROCESS='1',
   OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1'if large else'0',
   OCR_BF16_PREFILL='1'if large else'0',OCR_BF16='0',OCR_VISION_BATCH='0',OCR_VISION_BATCH_ITEMS='1',
   OCR_PREFILL_BATCH='0',OCR_PREFILL_BATCH_ITEMS='1',OCR_VISION_FRAME_BLOCKS='2'if large else'4',
   OCR_SINGLE_FRAME='1'if not prefix else'0',OCR_STREAM_FIRST=str(prefix),OCR_GPU_GREEDY_STREAM='1'if prefix else'0',
   OCR_LOGICAL64='1',OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',
   OCR_ADMISSION_UNITS='512',OCR_DISABLE_64_ROW_TILE='0'if large else'1',OCR_DISABLE_WIDE_GATE_UP='0',
   OCR_WIDE64_GATE_UP='1'if large else'0',OCR_FULL64_GATE_UP='1'if large else'0',
   OCR_RESOURCE_DEDUP=str(int(on)),ANTFLY_FLORENCE_CPU_PREPROCESS='0')
  print('START',model,label,flush=True)
  with Path(f'/private/tmp/ocr-engine52-{model}-{label}-driver.txt').open('w')as log:
   r=subprocess.run([sys.executable,str(v/'run_engine52_budget_policies.py'),model+':'+label],env=env,stdout=log,stderr=subprocess.STDOUT)
  print('DONE',model,label,r.returncode,flush=True);assert r.returncode==0,(label,r.returncode)
  rp=dest/'report.json';d=json.loads(rp.read_text());rs=d['results'][0];s=rs['policy_rounds'][0]
  assert rs['status']=='ok'and rs['serial_reference_parity']and rs['cross_runtime_content_parity']
  assert s['completed']==n and not s['admission_pressures']
  assert not d['own_cpu_compile_overlap']
  assert s['host_recurrent_bytes_total']==0 and s['single_frame_topology_mismatches']==s['gpu_greedy_stream_topology_mismatches']==0
  assert s['recurrent_resource_calls']>0 and (s['recurrent_resource_skipped']>0)==on
  assert s['recurrent_resource_requested']-s['recurrent_resource_emitted']==s['recurrent_resource_skipped']
  assert s['gpu_greedy_stream_steps']==(s['executor_steps']if prefix else 0)
  assert s['full64_gate_up_calls']>0 if large else s['full64_gate_up_calls']==0
  records.append(dict(trial=trial,resource_dedup=on,pages_per_second=s['pages_per_second'],process_cpu_ms=s['process_cpu_ms'],
   framed_runtime_totals=s['framed_runtime_totals'],average_decode_rows=s['average_decode_rows'],
   recurrent_resource_calls=s['recurrent_resource_calls'],recurrent_resource_requested=s['recurrent_resource_requested'],
   recurrent_resource_emitted=s['recurrent_resource_emitted'],recurrent_resource_skipped=s['recurrent_resource_skipped'],
   completed=n,all_native_pages_equal_serial_reference=True,full_fixture_string_identity=True,primary_throughput_eligible=mode=='primary',
   report=str(rp.relative_to(o)),report_sha256=hashlib.sha256(rp.read_bytes()).hexdigest()))
  p=o/f'engine52_{model}_resource_dedup_{mode}_audit.json'
  p.write_text(json.dumps(dict(status='running',candidates=records),indent=2)+'\n')
 p.write_text(json.dumps(dict(status='pass',candidates=records),indent=2)+'\n')
