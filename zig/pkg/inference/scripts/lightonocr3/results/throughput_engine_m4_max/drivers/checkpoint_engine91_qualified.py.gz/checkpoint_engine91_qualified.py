from pathlib import Path
import hashlib,json,psutil,subprocess,sys,datetime
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();f=json.loads((v/'engine91-freeze.json').read_text());assert all(sha(r/p)==h for p,h in f.items())
waiters=[p for p in psutil.process_iter(['pid','cmdline'])if p.info['cmdline']and p.info['cmdline'][-1].endswith('/run_engine91_precision_memory_screen74.py')];assert len(waiters)==1;waiter=waiters[0];assert not waiter.children(recursive=True);waiter.suspend()
if waiter.children(recursive=True):waiter.resume();raise RuntimeError('Model child already active; do not checkpoint during timings.')
a=o/'engine91_checkpoint_waiter_audit.json';assert not a.exists();d=dict(status='paused_own_child_free_waiter',pid=waiter.pid,exact_command=waiter.cmdline(),created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Pause only own child-free memory waiter for normal-hook git checkpoint; qualification complete, no model timing overlaps. Resume on every outcome.')
def save():a.write_text(json.dumps(d,indent=2)+'\n')
save()
try:
 assert subprocess.check_output(['git','branch','--show-current'],text=True).strip()=='feat/lightonocr3-08b'
 with Path('/private/tmp/ocr-engine91-archive-closed.txt').open('w')as log:subprocess.run([sys.executable,str(v/'archive_completed_engine90_91.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
 paths=['zig/lib/image/src/processing.zig','zig/pkg/inference/src/backends/metal_runtime.zig','zig/pkg/inference/src/backends/metal_kernels.m','zig/pkg/inference/src/server/server.zig','zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py','zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m']
 others=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z','--',str(o.relative_to(r))]).decode().split('\0')
 changed=subprocess.check_output(['git','diff','--name-only','-z','--',str(o.relative_to(r))]).decode().split('\0')
 excluded={'engine91_precision_memory_screen74_audit.json',a.name}
 paths+=sorted({p for p in others+changed if p and Path(p).name not in excluded})
 subprocess.run(['git','add','--',*paths],check=True);subprocess.run(['git','diff','--cached','--check'],check=True)
 subprocess.run(['git','commit','-m','Fix Metal runtime resource retention and accelerate OCR preprocessing'],check=True)
 assert all(sha(r/p)==h for p,h in f.items()),'Commit hooks changed frozen inputs.'
 d['commit']=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();save()
 subprocess.run(['git','push','origin','HEAD'],check=True);d['status']='checkpoint_pushed';save()
finally:
 d['frozen_inputs_unchanged']=all(sha(r/p)==h for p,h in f.items());waiter.resume();d['own_waiter_resumed']=True;save();print('CHECKPOINT91',d['status'],'waiter resumed',flush=True)
