from pathlib import Path
import hashlib,json,subprocess,os,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();f={p:sha(p)for p in json.loads((v/'engine102-freeze.json').read_text())};(v/'engine109-freeze.json').write_text(json.dumps(f,indent=2)+'\n')
for old,new in [('run_engine102_gpu_build.py','run_engine109_gpu_build.py'),('run_engine102_budget_policies.py','run_engine109_budget_policies.py')]:
 s=(v/old).read_text().replace('engine102','engine109')
 if 'gpu_build' in old:s=s.replace("env['ANTFLY_LIGHTONOCR3_PACKED_MIXED']='0'","env['ANTFLY_LIGHTONOCR3_PACKED_MIXED']='0'\nenv['TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE_RECURRENT']='0'")
 if 'budget' in old:
  needle=" if os.environ.get('OCR_PACKED_MIXED','0')=='1':cmd+=";a=s.index(needle);s=s[:a]+" if os.environ.get('OCR_WIDE_RECURRENT','0')=='1':cmd+=['--wide-recurrent','--require-wide-recurrent']\n"+s[a:]
  s=s.replace("<=16*sample['packed_recurrent_groups']","<=(64 if os.environ.get('OCR_WIDE_RECURRENT','0')=='1'else 16)*sample['packed_recurrent_groups']")
  s=s.replace("heads=re.findall(r'standalone_wide_heads=(\\d+)',section)","heads=re.findall(r'LIGHTONOCR3 standalone_wide_heads=(\\d+)',section)")
  needle="    round_bf16=sample.get('bf16_projection_enabled',bf16)";assert s.count(needle)==1;s=s.replace(needle,needle+"\n    if os.environ.get('OCR_WIDE_RECURRENT','0')=='1':assert sample['wide_recurrent_dispatches']>0 and 16<sample['wide_recurrent_max_rows']<=64 and sample['wide_recurrent_staged_bytes']>0,sample\n    else:assert sample['wide_recurrent_dispatches']==sample['wide_recurrent_max_rows']==sample['wide_recurrent_staged_bytes']==0,sample")
 (v/new).write_text(s)
(v/'engine109_benchmark_concurrency.py').write_bytes((r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
s=(v/'run_engine109_gpu_build.py').read_text();start=s.index('filters=');scope={};exec(s[start:s.index('command=',start)],scope);filters=scope['filters'];env=dict(os.environ,ZIG_GLOBAL_CACHE_DIR=str(r/'zig/.zig-cache/global'));cmd=['/Users/ajroetker/bin/zig-0.17.0/zig','build','inference-test','-Dmetal=false','-Doptimize=ReleaseFast','-Dstrip=true','--summary','all',*[f'-Dtest-filter={x}'for x in filters]]
with open('/private/tmp/ocr-engine109-packed-cpu.txt','w')as out:p=subprocess.run(cmd,cwd=r/'zig',env=env,stdout=out,stderr=subprocess.STDOUT)
print('CPU_EXIT',p.returncode,flush=True);assert p.returncode==0;assert all(sha(p)==h for p,h in f.items())
