from pathlib import Path
import json,re,collections,statistics
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
raw=Path('/private/tmp/ocr-engine43-prefill-tile-probe-verify.txt').read_text()
pat=r'PREFILL_ROW64 rows=(\d+) in=(\d+) out=(\d+) on=(\d+) leg=(\d+) gpu_us=([\d.]+) max_abs=([\deE.+-]+) cpu_error=([\deE.+-]+)'
records=[dict(zip(['rows','hidden','output','on','leg','gpu_us','max_abs','cpu_error'],[int(x)for x in m[:5]]+[float(x)for x in m[5:]]))for m in re.findall(pat,raw)]
assert len(records)==40 and 'FAIL'not in raw
groups=collections.defaultdict(list)
for x in records:groups[(x['rows'],x['hidden'],x['output'])].append(x)
comparisons=[]
for (r,h,n),xs in groups.items():
 off=[x['gpu_us']for x in xs if not x['on']];on=[x['gpu_us']for x in xs if x['on']]
 comparisons.append(dict(rows=r,hidden=h,output=n,candidate_to_baseline_ratio=statistics.mean(on)/statistics.mean(off),both_candidate_legs_faster_than_both_controls=max(on)<min(off)))
(o/'engine43_prefill_tile_probe_verify_audit.json').write_text(json.dumps(dict(status='pass',scope='Isolated existing64x32 vs32x64; not end-to-end. Numerical identity, mixed performance. Gate/up often slower; down432/554/662 improves but only554/662 clear in both legs.',records=records,comparisons=comparisons),indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('qualification',[Path('/private/tmp/ocr-engine43-prefill-tile-probe-verify.txt')],'logs_manifest.json')
s=(v/'engine43_prefill_tile_probe_verify_kernels.m').read_text()
needle='    bool prefill_row64_probe;'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n    id<MTLComputePipelineState> prefill64x64_probe_pipeline;')
a=s.index('        "kernel void termite_lightonocr3_mpp_bfloat_32_64(')
b=s.index('        "kernel void termite_lightonocr3_mpp_bfloat_64_32(',a)
part=s[a:b]
part=part.replace('mpp_bfloat_32_64','mpp_bfloat_64_64_probe').replace('int(group.y)*32','int(group.y)*64').replace('matmul2d_descriptor(32,64','matmul2d_descriptor(64,64').replace('execution_simdgroups<4>','execution_simdgroups<8>').replace('coord[1]<32','coord[1]<64')
s=s[:b]+part+s[b:]
needle='''            runtime->lightonocr3_mpp_bf16_n32_pipeline =
                termite_metal_make_pipeline(device, tensor_library, @"termite_lightonocr3_mpp_bfloat_64_32");'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''
            runtime->prefill64x64_probe_pipeline =
                termite_metal_make_pipeline(device, tensor_library, @"termite_lightonocr3_mpp_bfloat_64_64_probe");''')
needle='    runtime->lightonocr3_mpp_bf16_n32_pipeline = nil;'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n    runtime->prefill64x64_probe_pipeline = nil;')
a=s.index('static int termite_metal_try_lightonocr3_mpp(');b=s.index('\n}\n',a)+2
part=s[a:b]
part=part.replace('const bool n32 = probe_prefill64 ||','const bool n32 =')
needle='''    id<MTLComputePipelineState> pipeline =
        segment4 ?'''
assert part.count(needle)==1
part=part.replace(needle,'''    if (probe_prefill64 && (!bf16 || runtime->prefill64x64_probe_pipeline == nil ||
        runtime->prefill64x64_probe_pipeline.maxTotalThreadsPerThreadgroup < 256 ||
        runtime->prefill64x64_probe_pipeline.threadExecutionWidth != 32 ||
        runtime->prefill64x64_probe_pipeline.staticThreadgroupMemoryLength > runtime->device.maxThreadgroupMemoryLength)) return 0;
    id<MTLComputePipelineState> pipeline =
        probe_prefill64 ? runtime->prefill64x64_probe_pipeline : segment4 ?''')
needle='''    size_t tm = (small_tile || segment4) ? 8 : (n32 ? 64 : 32), tn = segment4 ? 8 : small_tile ? (four_row_mpp ? 16 : 32) : (n32 ? 32 : 64);'''
assert part.count(needle)==1
part=part.replace(needle,'''    size_t tm = probe_prefill64 ? 64 : (small_tile || segment4) ? 8 : (n32 ? 64 : 32), tn = probe_prefill64 ? 64 : segment4 ? 8 : small_tile ? (four_row_mpp ? 16 : 32) : (n32 ? 32 : 64);''')
needle='threadsPerThreadgroup:MTLSizeMake((small_tile || segment4) ? 32 : 128, 1, 1)]'
assert part.count(needle)==1
part=part.replace(needle,'threadsPerThreadgroup:MTLSizeMake(probe_prefill64 ? 256 : (small_tile || segment4) ? 32 : 128, 1, 1)]')
s=s[:a]+part+s[b:]
(v/'engine43_prefill64x64_probe_kernels.m').write_text(s)
s=(v/'engine43_prefill_tile_probe_verify_checks.m').read_text().replace('engine43_prefill_tile_probe_verify_kernels.m','engine43_prefill64x64_probe_kernels.m')
(v/'engine43_prefill64x64_probe_checks.m').write_text(s)
s=(v/'engine43_prefill_tile_probe_verify.m').read_text().replace('engine43_prefill_tile_probe_verify_checks.m','engine43_prefill64x64_probe_checks.m').replace('PREFILL_ROW64','PREFILL64X64')
(v/'engine43_prefill64x64_probe.m').write_text(s)
s=(v/'build_engine43_prefill_tile_probe_verify.py').read_text().replace('engine43_prefill_tile_probe_verify','engine43_prefill64x64_probe').replace('ocr-engine43-prefill-tile-probe-verify-build.txt','ocr-engine43-prefill64x64-probe-build.txt')
(v/'build_engine43_prefill64x64_probe.py').write_text(s)
ns['archive']('drivers',[v/n for n in ['prepare_engine43_prefill64x64_probe.py','engine43_prefill64x64_probe_kernels.m','engine43_prefill64x64_probe_checks.m','engine43_prefill64x64_probe.m','build_engine43_prefill64x64_probe.py']],'drivers_manifest.json')
with(v/'engine_progress.md').open('a')as f:f.write("\n43EXISTINGROW64PROBE ALLPASS95015exit0 40legrecords10casesmaxabsZERO/allCPUerrors<5e-7. PerformanceM64N32mixed:gate/up432ratio1.128,5541.087,662.987; down432.858/554.858/662.829(only554/662bothON<bothOFF),128/1024overlap. DoNOTpromotewholescalerow64orclaimbigwin. Fullaudit+rawarchived. PreparedNEXTignored64x64BF16probe sources/driver/archive: engine43_prefill64x64_probe_{kernels,checks}.m +wrapper.m/build_engine43_prefill64x64_probe.py +prepare_engine43_prefill64x64_probe.py. BuildsnewMSL64x64SG8kernel clonedEXACToldBF16M32N64 withrow64/SG8only; CprobePSOfield+initializer/cleanup, candidateonlyPREFILLknown4BFFN128..2048, boundthreads>=256/TG. SameGPUproducer/pack/nativeCroute/BF16precisions/ABBA40/CPU/gold/canaries/counter. NeedclangcompilethenGPU; runtimeactualSTILL42frozenno43changes. Sourcecopybasehashstill42verifiedbybuildhelper. New64x64addressesgate/upM64N32regressionkeepingN64. IfunsupportedPSOnilcandidatecounterfails(safe). NoactiveGPUafter95015done. makegcENDunrunPRstaleHEAD1289.\n")
