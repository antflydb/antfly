from pathlib import Path
import subprocess,sys
v=Path.cwd()/".venv-lighton-vllm-metal"
print("START REGISTER K32",flush=True)
subprocess.run([sys.executable,str(v/"run_engine88_register_k32.py")],check=True)
print("START REGISTER K64",flush=True)
subprocess.run([sys.executable,str(v/"run_engine88_register_k64.py")],check=True)
print("START FRESH 4B PRIMARY73",flush=True)
subprocess.run([sys.executable,str(v/"run_engine85_primary73.py")],check=True)
