#define main production_checks_main
#include "wide_projection_tiles_checks.m"
#undef main
static int pair(termite_metal_decode_runtime *r,size_t rows,size_t in,size_t out) {
  id<MTLBuffer> x=[r->device newBufferWithLength:(rows*in+4)*4 options:MTLResourceStorageModeShared];
  id<MTLBuffer> y=[r->device newBufferWithLength:(rows*out+12)*4 options:MTLResourceStorageModeShared];
  float *v=(float*)x.contents+4,*got=(float*)y.contents+4;
  uint16_t *w=malloc(in*out*2);float *b=malloc(out*4),*gold=malloc(rows*out*4);
  if(!x||!y||!w||!b||!gold)return 1;
  uint32_t state=123;for(size_t i=0;i<in*out;i++){state=state*1664525u+1013904223u;w[i]=round_bf16(((int)(state>>16)-32768)*0.000001f);}
  for(size_t i=0;i<rows*in;i++)v[i]=sinf(i*.013f)*.7f;
  for(size_t i=0;i<out;i++)b[i]=cosf(i*.019f)*.2f;
  if(termite_metal_decode_runtime_prepare_linear_bf16(r,0,(uint8_t*)w,in*out*2,b,in,out))return 2;
  r->wide_tile_probe=false;
  if(apply_projection(r,rows,in,out,x,4,y))return 3;
  memcpy(gold,got,rows*out*4);
  for(size_t round=0;round<4;round++){
    bool on=round==1||round==2;r->wide_tile_probe=on;
    uint64_t before=r->frame_gpu_nanos;size_t calls=r->wide_tile_probe_calls;
    float worst=0;
    for(size_t trial=0;trial<20;trial++){
      if(apply_projection(r,rows,in,out,x,4,y))return 4;
      for(size_t i=0;i<rows*out;i++){if(!isfinite(got[i]))return 5;worst=fmaxf(worst,fabsf(got[i]-gold[i]));}
    }
    if(worst>2e-4f || ((r->wide_tile_probe_calls>calls)!=on))return 6;
    fprintf(stderr,"WIDE_PROJECTION_TILES rows=%zu in=%zu out=%zu on=%d round=%zu gpu_us=%.2f max_abs=%g calls=%zu\n",rows,in,out,on,round,(r->frame_gpu_nanos-before)/20000.0,worst,r->wide_tile_probe_calls-calls);
  }
  r->wide_tile_probe=false;free(w);free(b);free(gold);return 0;
}
int main(void){@autoreleasepool{
 termite_metal_decode_runtime*r=termite_metal_decode_runtime_create();if(!r)return 1;
 termite_metal_decode_runtime_set_lightonocr3_projections(r,1);termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(r,1);
 const size_t shapes[][2]={{1024,6144},{1024,2048},{2048,1024},{1024,512},{1024,4096},{2560,8192},{2560,4096},{4096,2560},{2560,1024},{3584,1024},{9216,2560},{1024,16},{2560,32},{1024,3584},{2560,9216}};
 for(size_t rows=9;rows<=16;rows+=rows==9?3:4)for(size_t i=0;i<sizeof(shapes)/sizeof(shapes[0]);i++){
  r->wide_tile_probe=true;int rc=projection(r,rows,shapes[i][0],shapes[i][1],4);if(rc){fprintf(stderr,"QUAL_FAIL rows=%zu shape=%zu rc=%d\n",rows,i,rc);return 10+rc;}
  rc=pair(r,rows,shapes[i][0],shapes[i][1]);if(rc){fprintf(stderr,"PAIR_FAIL rows=%zu shape=%zu rc=%d\n",rows,i,rc);return 100+rc;}
 }
 termite_metal_decode_runtime_destroy(r);
}return 0;}
