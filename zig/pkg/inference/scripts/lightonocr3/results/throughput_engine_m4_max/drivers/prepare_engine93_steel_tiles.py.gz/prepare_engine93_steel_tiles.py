from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=(r/'zig/pkg/inference/src/backends/metal_kernels.m').read_text();s=s.replace('typedef struct termite_metal_decode_runtime {','static size_t engine93_m,engine93_n,engine93_threads;\ntypedef struct termite_metal_decode_runtime {',1)
needle='    [enc dispatchThreadgroups:MTLSizeMake((out_dim + tn - 1) / tn, (rows + tm - 1) / tm, 1)\n        threadsPerThreadgroup:MTLSizeMake((small_tile || segment4) ? 32 : 128, 1, 1)];';assert s.count(needle)==1
s=s.replace(needle,'''    size_t dispatch_threads = (small_tile || segment4) ? 32 : 128;
    if (engine93_m && bf16 && !small_tile && !segment4 && !n32 && runtime->active_frame_regime == TERMITE_METAL_FRAME_REGIME_PREFILL) {
        tm=engine93_m;tn=engine93_n;dispatch_threads=engine93_threads;
        if (dispatch_threads > pipeline.maxTotalThreadsPerThreadgroup) return -93;
    }
    [enc dispatchThreadgroups:MTLSizeMake((out_dim + tn - 1) / tn, (rows + tm - 1) / tm, 1)
        threadsPerThreadgroup:MTLSizeMake(dispatch_threads, 1, 1)];''')
p=v/'engine93_steel_kernels.m';assert not p.exists();p.write_text(s)
s=(r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine93_steel_kernels.m"');p=v/'engine93_steel_checks.m';assert not p.exists();p.write_text(s)
p=v/'engine93_ffn_prefix.inc';assert not p.exists();p.write_text((v/'engine82_real_ffn_prefix.inc').read_text().replace('engine82_probe_checks.m','engine93_steel_checks.m'))
s=(v/'engine86_real_ffn_probe.m').read_text().replace('engine82_real_ffn_prefix.inc','engine93_ffn_prefix.inc').replace('fused','candidate_enabled')
s=s.replace('r->lightonocr3_mpp_bf16_pipeline=candidate_enabled?candidate:original;','r->lightonocr3_mpp_bf16_pipeline=candidate_enabled?candidate:original;\n        engine93_m=candidate_enabled?strtoul(getenv("ENGINE93_M"),NULL,10):0;engine93_n=candidate_enabled?strtoul(getenv("ENGINE93_N"),NULL,10):0;engine93_threads=candidate_enabled?strtoul(getenv("ENGINE93_THREADS"),NULL,10):0;')
s=s.replace('maxTotalThreadsPerThreadgroup<128','maxTotalThreadsPerThreadgroup<strtoul(getenv("ENGINE93_THREADS"),NULL,10)')
s=s.replace('r->lightonocr3_mpp_bf16_pipeline=original;tile_m82=tile_n82=tile_threads82=0;','r->lightonocr3_mpp_bf16_pipeline=original;engine93_m=engine93_n=engine93_threads=0;tile_m82=tile_n82=tile_threads82=0;')
# The old helper's private gate-dispatch globals are no longer referenced by this current-C snapshot.
s=s.replace('tile_m82=tile_n82=tile_threads82=0;','')
s=s.replace('REAL86','REAL93');p=v/'engine93_real_ffn_probe.m';assert not p.exists();p.write_text(s)
base=(v/'engine86_steel_verify2.metal').read_text().split('struct Engine86Params')[0]
shapes=[(64,64,16,2,2),(64,64,32,2,2),(64,64,64,2,2),(64,64,32,2,4),(64,128,16,2,4),(64,128,32,2,4),(128,64,16,4,2),(128,64,32,4,2),(32,128,16,2,4),(32,128,32,2,4)]
for bm,bn,bk,wm,wn in shapes:
 s=base+f'''
struct Engine93Params {{uint rows,in_dim,out_dim,pad;}};
kernel void engine86_steel(device const bfloat*x[[buffer(0)]],device const bfloat*w[[buffer(1)]],device const float*bias[[buffer(2)]],device float*y[[buffer(3)]],constant Engine93Params&p[[buffer(4)]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]],uint3 tid[[threadgroup_position_in_grid]],uint3 lid[[thread_position_in_threadgroup]]) {{
 using K=mlx::steel::GEMMKernel<bfloat,float,{bm},{bn},{bk},{wm},{wn},false,true,false,true>;
 threadgroup bfloat As[K::tgp_mem_size_a];threadgroup bfloat Bs[K::tgp_mem_size_b];
 thread mlx::steel::GEMMParams gp={{int(p.rows),int(p.out_dim),int(p.in_dim),int(p.in_dim),int(p.in_dim),int(p.out_dim),int((p.out_dim+{bn-1})/{bn}),int((p.rows+{bm-1})/{bm}),0,0,0,0,int(p.in_dim/{bk}),0}};
 K::run(x,w,y,&gp,As,Bs,lane,sg,tid,lid);
}}
'''
 p=v/f'engine93_steel_m{bm}n{bn}k{bk}w{wm}x{wn}.metal';assert not p.exists();p.write_text(s)
files=[v/'engine93_steel_kernels.m',v/'engine93_steel_checks.m',v/'engine93_ffn_prefix.inc',v/'engine93_real_ffn_probe.m',v/'engine82_weight_offsets.inc',v/'engine86_MLX_LICENSE',*v.glob('engine93_steel_*.metal')]
(v/'engine93_steel_preparation.json').write_text(json.dumps(dict(scope='Private larger MLX Steel GEMM geometry search on4real FFN layer triplets. SameBF16 operands/F32 accumulators. No production change. Full output tolerance/packed differences/CPU/canary checks; zero biases only. ComparecompleteFFN to originalproductionMPP ABBA.',shapes=shapes,input_sha256={str(p.relative_to(r)):sha(p)for p in files},production_c_sha256=sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')),indent=2)+'\n')
print('Prepared10Steel geometries against current qualified cleanup source.')
