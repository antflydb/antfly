from pathlib import Path
import json,hashlib,re
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=(r/'zig/pkg/inference/src/backends/metal_kernels.m').read_text();a=s.index('static NSString *termite_metal_lightonocr3_recurrent_source(void) {');b=s.index('\n}',a);parts=re.findall(r'"((?:[^"\\]|\\.)*)"',s[a:b]);source=''.join(json.loads('"'+x+'"')for x in parts)
source=source[:source.index('kernel void termite_lightonocr3_prefill_prepare_parallel')]
source=source.replace('termite_lightonocr3_recurrent_parallel','engine75_value_major')
a=source.index('    for (uint i = 0; i < 4; i++) {',source.index('float4 memories'));b=source.index('#pragma unroll\n    for (uint t = 0;',a)
# Preserve each value column's exact four-key accumulation order.
source=source[:a]+'''    for (uint t = 0; t < TM / 4; t++) {
#pragma unroll
        for (uint c = 0; c < 4; c++) {
            float4 raw = p.initialized ? *((device const float4 *)(state + h*128*128 + (col+t*4+c)*128 + uint(lane)*4)) : float4(0);
#pragma unroll
            for (uint i = 0; i < 4; i++) previous[i][t][c] = raw[i] * scales[2];
        }
#pragma unroll
        for (uint i = 0; i < 4; i++) memories[t] += previous[i][t] * k[uint(lane)*4+i];
    }
'''+source[b:]
old='            *((device float4 *)(state + h * 128 * 128 + key * 128 + col + t * 4)) = v;'
assert old in source;source=source.replace(old,'            previous[i][t] = v;')
needle='        outputs[t] = float4(simd_sum(outputs[t].x)'
a=source.index(needle);source=source[:a]+'''#pragma unroll
        for (uint c = 0; c < 4; c++) {
            float4 value = float4(previous[0][t][c], previous[1][t][c], previous[2][t][c], previous[3][t][c]);
            *((device float4 *)(state + h*128*128 + (col+t*4+c)*128 + uint(lane)*4)) = value;
        }
'''+source[a:]
(v/'engine75_value_major.metal').write_text(source)
(v/'engine75_recurrent_source.inc').write_text('static NSString *engine75_source = @'+json.dumps(source)+';\n')
(v/'engine75_probe_kernels.m').write_bytes((v/'engine72_probe_kernels.m').read_bytes())
(v/'engine75_probe_checks.m').write_text((v/'engine72_probe_checks.m').read_text().replace('engine72_probe_kernels.m','engine75_probe_kernels.m'))
h=(v/'engine72_recurrent_probe.m').read_text().replace('engine72_probe_checks.m','engine75_probe_checks.m').replace('engine72_recurrent_sources.inc','engine75_recurrent_source.inc').replace('engine72_unused_main','engine75_unused_main')
h=h.replace('engine72_threads=mode==1?256:512;','engine72_threads=512;')
h=h.replace('fill72(w,pages,counts);double us;','''fill72(w,pages,counts);
  if(mode)for(size_t l=0;l<LAYERS72;l++)for(size_t p=0;p<pages;p++){
   float*state=(float*)w->buffers[l][p][8].contents+4;
   float temporary[128*128];
   for(size_t h=0;h<vh;h++){
    memcpy(temporary,state+h*128*128,sizeof(temporary));
    for(size_t k=0;k<128;k++)for(size_t c=0;c<128;c++)state[h*128*128+c*128+k]=temporary[k*128+c];
   }
  }
  double us;''')
h=h.replace('candidate<=2','candidate<=1').replace('i<=2','i<=1').replace('engine72_sources[i-1]','engine75_source').replace('i == 1 ? @"engine72_recurrent_value_lanes4" : @"engine72_recurrent_value_lanes2"','@"engine75_value_major"')
a=h.index('  if(fused_core_check');b=h.index(' }\n const char *requested',a)
h=h[:a]+'''  // Layout prototype: staged canonical-state conformance cannot qualify this PSO.
  // The ABBA harness below transposes initial state and compares every logical
  // output/state element after ten continued steps, plus all buffer canaries.
  // Full runtime layout interop is required separately before any promotion.
  fprintf(stderr,"LAYOUT PROTOTYPE READY mode=%d\\n",i);
'''+h[b:]
h=h.replace('ENGINE72_PAGES','ENGINE75_PAGES')
h=h.replace('if(!isfinite(got[i])||!isfinite(w->gold[l][p][a][i]))return 42;\n     error=fmaxf(error,fabsf(got[i]-w->gold[l][p][a][i]));','''size_t physical=(mode && j==8)?(i/(128*128))*(128*128)+(i%128)*128+(i/128)%128:i;
     if(!isfinite(got[physical])||!isfinite(w->gold[l][p][a][i]))return 42;
     error=fmaxf(error,fabsf(got[physical]-w->gold[l][p][a][i]));''')
assert 'size_t physical=' in h
(v/'engine75_recurrent_probe.m').write_text(h)
inputs={str(p.relative_to(r)):sha(p)for p in [v/'engine75_value_major.metal',v/'engine75_recurrent_source.inc',v/'engine75_probe_kernels.m',v/'engine75_probe_checks.m',v/'engine75_recurrent_probe.m']}
(v/'engine75_recurrent_probe_preparation.json').write_text(json.dumps(dict(production_c_sha256=sha(r/'zig/pkg/inference/src/backends/metal_kernels.m'),inputs=inputs,scope='Private value-major persistent-state layout prototype only. F32 data/math unchanged. ABBA canonical-vs-transposed full logical state/output parity over ten steps. No runtime layout interoperability or full staged conformance claim; cannot be promoted from this prototype.'),indent=2)+'\n')
bs=(v/'build_engine72_recurrent_probe.py').read_text().replace('engine72','engine75');(v/'build_engine75_recurrent_probe.py').write_text(bs)
rs=(v/'run_engine72_recurrent_probe.py').read_text();a=rs.index('while True:');b=rs.index("print('START ISOLATED",a)
rs=rs[:a]+'''while 'ENGINE73D CPU DIAGNOSTIC DONE' not in Path('/private/tmp/ocr-engine73d-queue-parent.txt').read_text():time.sleep(5)
'''+rs[b:]
rs=rs.replace('engine72','engine75').replace('ENGINE72','ENGINE75').replace("text.count('CONFORMANCE PASS mode=')==2","text.count('LAYOUT PROTOTYPE READY mode=')==1").replace('len(records)==8','len(records)==4').replace("status='pass'if any(x.get('pages')==0 and x['status']=='pass'for x in d['checks'])else'insufficient_memory'","status='prototype_pass'if any(x.get('pages')in[33,48,64] and x['status']=='pass'for x in d['checks'])else'insufficient_memory'")
rs=rs.replace("scope='Isolated F32 recurrent lane-layout diagnostic only, never primary throughput evidence. Full staged checks precede separate 24-layer ABBA working sets with full output/state comparisons and canaries. Same state layout/dtype; altered reduction tree. No promotion inferred from microbenchmarks.'","scope='Value-major F32 persistent-state layout prototype only; no runtime interop qualification. Full logical state/output comparisons after ten continued steps and all canaries. ABBA 24-layer working sets; not primary throughput evidence and not promotable without full layout interoperability qualification.'")
(v/'run_engine75_recurrent_probe.py').write_text(rs)
print('prepared value-major layout prototype only; no production edits')
