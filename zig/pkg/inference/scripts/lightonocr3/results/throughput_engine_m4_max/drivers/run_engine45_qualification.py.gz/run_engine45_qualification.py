from pathlib import Path
import subprocess,sys
v=Path('.venv-lighton-vllm-metal')
for helper,args,label in [
 ('run_engine45_catalog_qualification.py',[],'catalog-qualification'),
 ('run_engine45_functional.py',[],'functional'),
 ('run_engine45_wide64_cases.py',['qualification'],'hybrid-qualification'),
 ('run_engine45_stream_cases.py',['qualification','08'],'small-stream-qualification'),
 ('run_engine45_florence_raster_qualification_verify.py',[],'florence-raster-qualification'),
 ('run_engine45_florence_case.py',['qualification','16','16','0'],'florence-batch16-qualification'),
 ('run_engine45_florence_case.py',['qualification','32','32','1'],'florence-batch32-qualification')]:
 print('START',helper,args,flush=True)
 with Path('/private/tmp/ocr-engine45-'+label+'-driver.txt').open('w')as log:
  r=subprocess.run([sys.executable,str(v/helper),*args],stdout=log,stderr=subprocess.STDOUT)
 print('DONE',helper,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
