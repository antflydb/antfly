#include <metal_stdlib>
#include <metal_tensor>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;
using namespace mpp::tensor_ops;
struct Engine88Params {uint rows,in_dim,out_dim,pad;};
kernel void engine86_steel(device const bfloat*x[[buffer(0)]],device const bfloat*w[[buffer(1)]],device const float*bias[[buffer(2)]],device float*y[[buffer(3)]],constant Engine88Params&p[[buffer(4)]],uint sg[[simdgroup_index_in_threadgroup]],uint2 group[[threadgroup_position_in_grid]]) {
 const uint m=group.y*32+(sg/2)*16,n=group.x*64+(sg%2)*32;
 constexpr auto desc=matmul2d_descriptor(16,32,64,false,true,false,matmul2d_descriptor::mode::multiply_accumulate);
 matmul2d<desc,execution_simdgroup> op;
 auto a=op.get_left_input_cooperative_tensor<bfloat,bfloat,float>();
 auto b=op.get_right_input_cooperative_tensor<bfloat,bfloat,float>();
 auto c=op.get_destination_cooperative_tensor<decltype(a),decltype(b),float>();
 #pragma unroll
 for(ushort i=0;i<c.get_capacity();i++)c[i]=0.0f;
 #pragma clang loop unroll(disable)
 for(uint kk=0;kk<p.in_dim;kk+=64){
  #pragma unroll
  for(ushort i=0;i<a.get_capacity();i++){
   auto z=a.get_multidimensional_index(i);int col=int(kk)+z[0],row=int(m)+z[1];
   a[i]=(z[0]>=0&&z[0]<64&&z[1]>=0&&z[1]<16&&row<int(p.rows)&&col<int(p.in_dim))?x[size_t(row)*p.in_dim+col]:bfloat(0);
  }
  #pragma unroll
  for(ushort i=0;i<b.get_capacity();i++){
   auto z=b.get_multidimensional_index(i);int col=int(kk)+z[0],row=int(n)+z[1];
   b[i]=(z[0]>=0&&z[0]<64&&z[1]>=0&&z[1]<32&&row<int(p.out_dim)&&col<int(p.in_dim))?w[size_t(row)*p.in_dim+col]:bfloat(0);
  }
  op.run(a,b,c);
 }
 #pragma unroll
 for(ushort i=0;i<c.get_capacity();i++){
  auto z=c.get_multidimensional_index(i);int col=int(n)+z[0],row=int(m)+z[1];
  if(z[0]>=0&&z[0]<32&&z[1]>=0&&z[1]<16&&row<int(p.rows)&&col<int(p.out_dim))y[size_t(row)*p.out_dim+col]=c[i]+bias[col];
 }
}
