from pathlib import Path
import ctypes as c,hashlib,json,time,statistics
import numpy as np
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
build=json.loads((out/'engine49_attention_probe_build_manifest.json').read_text())
assert build['exit_code']==0 and sha(build['binary'])==build['binary_sha256']
for p,h in build['inputs'].items():assert sha(p)==h,p
for p,h in json.loads((v/'engine48-freeze.json').read_text()).items():assert sha(p)==h,p
lib=c.CDLL(str(Path(build['binary']).resolve()))
lib.probe49_create.argtypes=[c.c_size_t,c.c_size_t,c.c_void_p,c.c_void_p,c.c_void_p];lib.probe49_create.restype=c.c_void_p
lib.probe49_run.argtypes=[c.c_void_p,c.c_int,c.POINTER(c.c_double)];lib.probe49_run.restype=c.c_int
lib.probe49_output.argtypes=[c.c_void_p,c.c_int];lib.probe49_output.restype=c.POINTER(c.c_float)
lib.probe49_destroy.argtypes=[c.c_void_p]
lib.probe49_conformance.argtypes=[c.c_void_p,c.c_int];lib.probe49_conformance.restype=c.c_int
record=dict(status='running',scope='Eight distinct layer input/KV/output sets per frame; same F32 Q/probabilities/accumulation/output and F16 KV. Baseline current engine48 PSO. ABBA controls per candidate, each two warm and eight timed frames; full-output checks after each leg plus independent CPU corners. Private-only, no full model or vLLM speed claim.',build_manifest_sha256=sha(out/'engine49_attention_probe_build_manifest.json'),cases=[],conformance=[])
report=out/'engine49_attention_probe_audit.json';assert not report.exists()
save=lambda:report.write_text(json.dumps(record,indent=2)+'\n')
for heads in [16,8]:
 for n in [432,554,662]:
  rng=np.random.default_rng(4900+n+heads)
  q=rng.uniform(-.7,.7,(8,n,heads,256)).astype('f4')
  k=rng.uniform(-.6,.6,(8,n,heads//4,256)).astype('f2')
  vv=rng.uniform(-.6,.6,k.shape).astype('f2')
  ptr=lib.probe49_create(n,heads,q.ctypes.data,k.ctypes.data,vv.ctypes.data);assert ptr
  try:
   gpu=c.c_double()
   def run(mode):
    t=time.perf_counter_ns();rc=lib.probe49_run(ptr,mode,c.byref(gpu));assert rc==0,(mode,rc)
    return gpu.value,(time.perf_counter_ns()-t)/1000
   def read():
    return np.stack([np.ctypeslib.as_array(lib.probe49_output(ptr,z),shape=(n*heads*256,)).copy().reshape(n,heads,256)for z in range(8)])
   run(0);gold=read()
   cpuerr=0.
   for z in [0,7]:
    for row in [0,n-1]:
     for h in [0,heads-1]:
      kk=k[z,:row+1,h//4].astype('f8')
      scores=kk@q[z,row,h].astype('f8')*.0625
      probs=np.exp(scores-scores.max());probs/=probs.sum()
      expected=probs@vv[z,:row+1,h//4].astype('f8')
      cpuerr=max(cpuerr,float(np.max(np.abs(gold[z,row,h]-expected))))
   assert cpuerr<2e-4,cpuerr
   for mode in [1,2,3,4,5]:
    case=dict(heads=heads,seq=n,mode=mode,cpu_max_abs=cpuerr,legs=[])
    for m in [0,mode,mode,0]:
     for _ in range(2):run(m)
     times=[run(m)for _ in range(8)]
     actual=read();error=float(np.max(np.abs(actual-gold)))
     assert np.isfinite(actual).all() and error<2e-4,(n,heads,m,error)
     leg=dict(mode=m,gpu_us=[t[0]for t in times],wall_us=[t[1]for t in times],full_output_max_abs=error,checked_elements=int(actual.size))
     case['legs'].append(leg)
    base=[t for x in case['legs']if x['mode']==0 for t in x['gpu_us']]
    cand=[t for x in case['legs']if x['mode']==mode for t in x['gpu_us']]
    case.update(baseline_median_gpu_us=statistics.median(base),candidate_median_gpu_us=statistics.median(cand),candidate_to_baseline=statistics.median(cand)/statistics.median(base))
    record['cases'].append(case);save();print('CASE',heads,n,mode,case['candidate_to_baseline'],flush=True)
   if heads==16 and n==662:
    for mode in [1,2,3,4,5]:
     print('CONFORMANCE START',mode,flush=True)
     rc=lib.probe49_conformance(ptr,mode)
     record['conformance'].append(dict(mode=mode,exit_code=rc));save();assert rc==0,(mode,rc)
     print('CONFORMANCE PASS',mode,flush=True)
  finally:lib.probe49_destroy(ptr)
record['status']='pass';save()
print('ALL PASS',flush=True)
