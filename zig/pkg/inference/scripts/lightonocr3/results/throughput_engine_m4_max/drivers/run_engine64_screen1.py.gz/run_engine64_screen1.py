from pathlib import Path
import subprocess,sys,os,json,hashlib,ctypes,time
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');audit=o/'engine64_gpu_token_screen1_audit.json';assert not audit.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p,h in json.loads((v/'engine64-freeze.json').read_text()).items():assert sha(p)==h,p
lib=ctypes.CDLL(None);fn=lib.memorystatus_get_level;fn.argtypes=[ctypes.POINTER(ctypes.c_int)];fn.restype=ctypes.c_int
records=[]
record=dict(status='running',scope='Two-step GPU-token OCR screen. Prefer the predeclared C64/VF4 resident-vision profile; VF2 is a fallback only if VF4 cannot be admitted. Original checkpoint, max_tokens256 and original caps. No primary speed comparison in this screen.',candidates=records)
def save():audit.write_text(json.dumps(record,indent=2)+'\n')
save()
for vf in [4,2]:
 attempt=0
 while True:
  level=ctypes.c_int();assert fn(ctypes.byref(level))==0
  if level.value<47:print('WAIT LIVE AVAILABILITY',level.value,flush=True);time.sleep(10);continue
  attempt+=1;tag=f'gpu_tokens2_screen1_a{attempt}'
  env=os.environ.copy();env.update(OCR_CASE_CONCURRENCY='64',OCR_CASE_PREFILL_ITEMS='1',OCR_CASE_VISION_FRAME_BLOCKS=str(vf),OCR_CASE_VISION_BATCH_ITEMS='1',OCR_CASE_TAG=tag,OCR_BATCH_ARGMAX='1',OCR_CACHE_VISION_WORKSPACE='1',OCR_LARGE_VISION_PACK_REUSE='0',OCR_DEFER_VISION_SEAL='0',OCR_DEFER_PREFILL_SEAL='0',ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY='0',OCR_TIMEOUT='600',OCR_RESIDENT_VISION_BUDGET='1',OCR_GPU_TOKEN_BURST='1')
  print('START C64 VF',vf,'burst2','availability',level.value,flush=True)
  p=o/f'engine64_4b_rolling_chunks0_trial0_c64_p1_vf{vf}_r64_{tag}/report.json'
  result=subprocess.run([sys.executable,str(v/'run_engine64_prefill8_profile.py'),'4b','0'],env=env)
  assert p.exists(),p
  d=json.loads(p.read_text());r=d['results'][0];raw=(p.parent/'lighton4b-batch-c64.txt').read_text()
  if result.returncode:
   reason='live_load_admission'if'live-memory admission denied'in raw and'OCR_POLICY round=0'not in raw else'admission_pressure'if'admission_pressure='in raw else'unexpected_runtime_or_check_failure'
   records.append(dict(settings=[64,1,1,vf,0,0,0],eligible=False,reason=reason,report=str(p.relative_to(o)),report_sha256=sha(p)));save()
   if reason=='live_load_admission':time.sleep(10);continue
   if reason=='admission_pressure':break
   raise RuntimeError(reason)
  s=r['policy_rounds'][0]
  assert r['status']=='ok'and r['serial_reference_parity']and r['cross_runtime_content_parity']and s['completed']==64 and not s['admission_pressures']
  assert d['gpu_token_burst']and d['resident_vision_budget']and s['gpu_token_burst_steps']>0 and s['gpu_token_burst_topology_mismatches']==0
  item=dict(settings=[64,1,1,vf,0,0,0],eligible=True,pages_per_second=s['pages_per_second'],process_cpu_ms=s['process_cpu_ms'],gpu_token_burst_steps=s['gpu_token_burst_steps'],report=str(p.relative_to(o)),report_sha256=sha(p))
  records.append(item);record['selected']=item;record['status']='pass';save();print('SCREEN PASS',json.dumps(item),flush=True);sys.exit(0)
record['status']='no_admitted_candidate';save();raise RuntimeError(record['status'])
