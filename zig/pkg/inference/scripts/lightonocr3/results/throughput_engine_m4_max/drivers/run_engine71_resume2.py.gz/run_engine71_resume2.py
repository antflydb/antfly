from pathlib import Path
import subprocess,sys,json,hashlib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p,h in json.loads((v/'engine71-freeze.json').read_text()).items():assert sha(r/p)==h,p
c=json.loads((o/'engine70_c_build_manifest.json').read_text());assert sha(r/c['binary'])==c['binary_sha256'];assert all(sha(r/p)==h for p,h in c['input_sha256'].items())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='ba6b60598261743febd5fdefc77aad30032609ed'
for name,cmd in [('gpu-build',[sys.executable,str(v/'run_engine71_verify2_gpu_build.py')]),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine71','/private/tmp/ocr-engine71-verify2-gpu-build.txt']),('metal-disabled',[sys.executable,str(v/'run_engine71_metal_disabled.py')])]:
 print('START',name,flush=True)
 with Path('/private/tmp/ocr-engine71-'+name+'-driver.txt').open('w')as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
print('ENGINE71 QUALIFICATION DONE',flush=True)
subprocess.run([sys.executable,str(v/'run_engine71_prefill_batch_screen58.py')],check=True);print('ENGINE71 PREFILL58 DONE',flush=True)
subprocess.run([sys.executable,str(v/'run_engine71_api_paired59.py')],check=True);print('ENGINE71 PAIRED59 DONE',flush=True)
