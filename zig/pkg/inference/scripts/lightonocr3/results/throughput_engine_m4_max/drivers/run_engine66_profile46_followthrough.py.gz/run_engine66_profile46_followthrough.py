from pathlib import Path
import time,subprocess,sys,psutil,os
v=Path('.venv-lighton-vllm-metal');log=Path('/private/tmp/ocr-engine66-qualification-parent.txt');(v/'engine66-profile46-followthrough.pid').write_text(str(os.getpid()));start=time.monotonic()
while 'ENGINE66 QUALIFICATION DONE' not in log.read_text():
 if time.monotonic()-start>1500:raise TimeoutError('engine66 qualification')
 active=False
 for p in psutil.process_iter(['cmdline']):
  try:
   if any(str(x).endswith('/run_engine66_qualification.py') for x in (p.info['cmdline']or[])):active=True
  except(psutil.NoSuchProcess,psutil.AccessDenied):pass
 if not active:raise RuntimeError('Qualification exited before PASS marker')
 time.sleep(2)
print('START ENGINE66 VISION PROFILE46 after all qualification jobs exit',flush=True)
subprocess.run([sys.executable,str(v/'run_engine66_vision_pipeline46.py')],check=True)
