from pathlib import Path
import difflib,hashlib,json
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';inputs={};pieces=[]
def edit(name,fn):
 p=root/name;old=p.read_text();new=fn(old);assert new!=old,name
 inputs[name]=hashlib.sha256(p.read_bytes()).hexdigest();pieces.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
def gen(s):
 s=s.replace('pub const NativeGenerationPipeline = struct {','pub const NativeGenerationPipeline = struct {\n    /// Token publication is bounded; GPU steps reuse two frame/logit banks.\n    pub const max_gpu_token_burst_width: usize = 8;')
 for a,b in [('tokens.len > 4','tokens.len > max_gpu_token_burst_width'),('steps > 4','steps > max_gpu_token_burst_width'),('self.gpu_token_burst_width), 2, 4)','self.gpu_token_burst_width), 2, max_gpu_token_burst_width)'),('count > 4','count > max_gpu_token_burst_width'),('var choices: [4]u32','var choices: [max_gpu_token_burst_width]u32'),('publishes widths two through four','publishes widths two through eight'),('for (2..5) |width|','for (2..NativeGenerationPipeline.max_gpu_token_burst_width + 1) |width|'),('.max_tokens = 8 });\n            defer scheduler.release(lease);','.max_tokens = 16 });\n            defer scheduler.release(lease);'),('.max_tokens = if (scenario == 2) 1 + width else 8,','.max_tokens = if (scenario == 2) 1 + width else 16,'),('var second: [3]u32 = .{ 12, 13, 14 };','var second: [NativeGenerationPipeline.max_gpu_token_burst_width - 1]u32 = undefined;\n            for (&second, 0..) |*token, i| token.* = @intCast(12 + i);')]:
  assert a in s,a;s=s.replace(a,b)
 return s
edit('zig/pkg/inference/src/pipelines/generation.zig',gen)
edit('zig/pkg/inference/src/server/server.zig',lambda s:s.replace('"ANTFLY_LIGHTONOCR3_GPU_TOKEN_BURST_WIDTH") orelse 2, 2, 4)','"ANTFLY_LIGHTONOCR3_GPU_TOKEN_BURST_WIDTH") orelse 2, 2, generation.NativeGenerationPipeline.max_gpu_token_burst_width)'))
edit('zig/pkg/inference/src/ops/metal_compute.zig',lambda s:s.replace('width < 2 or width > 4 or frames != width','width < 2 or width > 8 or frames != width'))
edit('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py',lambda s:s.replace('choices=(2, 3, 4),','choices=tuple(range(2, 9)),'))
edit('docs/guides/lightonocr3.mdx',lambda s:s.replace('Bound each burst to 2–4 steps','Bound each burst to 2–8 steps').replace('EOS and cancellation discard unused results after producers drain.','Larger bursts reduce scheduler handoffs and can delay token publication. EOS and cancellation discard unused results after producers drain.'))
(v/'engine74-burst8.patch').write_text(''.join(pieces));(v/'engine74-burst8-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n');print('prepared only: bounded width8 patch, no production edits')
