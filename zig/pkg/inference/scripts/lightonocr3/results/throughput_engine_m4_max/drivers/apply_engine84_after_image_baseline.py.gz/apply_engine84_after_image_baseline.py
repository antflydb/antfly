from pathlib import Path
import time,subprocess,sys
log=Path('/private/tmp/ocr-engine84-image-tests.txt')
# The baseline compiler must finish before changing its inputs.
import psutil
while any(p.info['cmdline']and 'lib-image-test'in p.info['cmdline'] for p in psutil.process_iter(['cmdline'])):time.sleep(2)
assert log.exists()
subprocess.run([sys.executable,'.venv-lighton-vllm-metal/prepare_engine84_horizontal.py'],check=True)
subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt','zig/lib/image/src/processing.zig'],check=True)
