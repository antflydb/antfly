from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal')
for p,h in json.loads((v/'engine63-freeze.json').read_text()).items():
 assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
changes={}
def read(p):return changes.get(p,Path(p).read_text())
def replace(p,a,b,n=1):
 s=read(p);assert s.count(a)==n,(p,s.count(a),a[:100]);changes[p]=s.replace(a,b)
c='zig/pkg/inference/src/backends/metal_kernels.m'
replace(c,'        const bool restore_active_frame = runtime->active_frame_cb != nil && !encode_on_active_frame;', '        if (consume_active_frame == 2 && !encode_on_active_frame) return -18;\n        const bool restore_active_frame = runtime->active_frame_cb != nil && !encode_on_active_frame;')
replace(c,'        if (encode_on_active_frame) {\n            // The logits producer, row argmaxes, and token writeback now share', '''        if (encode_on_active_frame && consume_active_frame == 2) {
            // Encode-only OCR pipeline mode. No CPU result is exposed until
            // the caller drains this submitted producer. Keep buffer ownership
            // and the existing reduction order unchanged.
            if (encode_rc != 0) return encode_rc;
            runtime->argmax_on_frame_calls = termite_metal_u64_saturating_add(runtime->argmax_on_frame_calls, 1);
            return 0;
        }
        if (encode_on_active_frame) {
            // The logits producer, row argmaxes, and token writeback now share''')
changes[c]=read(c)+'\n'+(v/'engine64_c_additions.txt').read_text()
r='zig/pkg/inference/src/backends/metal_runtime.zig'
changes[r]=read(r)+'''
// Narrow helpers for two-step Qwen OCR decode. No new shader arithmetic.
pub extern fn antfly_metal_lighton_embed_tokens(runtime: ?*anyopaque, slot: usize, rows: usize, dim: usize, output: ?*anyopaque, output_offset: usize) c_int;
pub extern fn antfly_metal_lighton_read_tokens(runtime: ?*anyopaque, output: [*]u32, rows: usize) c_int;
'''
m='zig/pkg/inference/src/ops/metal_compute.zig'
replace(m,'    lighton_single_frame_stats: [2]u64 = @splat(0),','    lighton_single_frame_stats: [2]u64 = @splat(0),\n    lighton_gpu_token_bursts: u64 = 0,\n    lighton_gpu_token_burst_mismatches: u64 = 0,')
replace(m,'    pub fn lightOnSingleFrameStats(cb: *const ops.ComputeBackend) [2]u64 {',(v/'engine64_m_additions.txt').read_text()+'    pub fn lightOnSingleFrameStats(cb: *const ops.ComputeBackend) [2]u64 {')
p='zig/pkg/inference/src/pipelines/generation.zig'
replace(p,'    single_frame_lighton_decode: bool = false,','    single_frame_lighton_decode: bool = false,\n    gpu_token_burst_lighton_decode: bool = false,')
replace(p,'    const StepForwardResult = struct {\n        greedy_tokens: ?[]u32 = null,','    const StepForwardResult = struct {\n        greedy_tokens: ?[]u32 = null,\n        second_greedy_tokens: ?[]u32 = null,')
a='''        fn acceptToken(self: *@This(), token: u32) !void {
            try self.control.check();'''
b='''        fn acceptToken(self: *@This(), token: u32) !void {
            return self.acceptTokens(&.{token}, false);
        }

        fn acceptTokens(self: *@This(), tokens: []const u32, first_reserved: bool) !void {
            // Publish both accepted outputs while the work is still borrowed;
            // enqueue exactly once, after the last accepted output. Enqueue
            // may transfer this stack continuation to an idle canceller.
            for (tokens, 0..) |token, index| {
            try self.control.check();'''
replace(p,a,b)
replace(p,'            try self.work.decode_state.appendGeneratedToken();\n            self.scheduler.noteDecodeProgress', '            if (!first_reserved or index != 0) try self.work.decode_state.appendGeneratedToken();\n            self.scheduler.noteDecodeProgress')
replace(p,'            var decode_runtime = BorrowedDecodeStateRuntime.init(self.work.decode_state);\n            const context = decode_runtime.makeDecodeContext(self.seq_len.*, 1);','            }\n            var decode_runtime = BorrowedDecodeStateRuntime.init(self.work.decode_state);\n            const context = decode_runtime.makeDecodeContext(self.seq_len.*, 1);')
replace(p,'    fn forwardScheduledStep(\n',(v/'engine64_pipeline_helper.txt').read_text()+'    fn forwardScheduledStep(\n')
a='''                    const head = try self.graphWeight("lm_head.weight");
                    defer self.cb.free(head);
                    if (try self.cb.decoderRuntimeBeginFrame()) {'''
b='''                    const head = try self.graphWeight("lm_head.weight");
                    defer self.cb.free(head);
                    var burst_slot: ?usize = null;
                    if (self.gpu_token_burst_lighton_decode and self.single_frame_lighton_decode and
                        !self.gpu_greedy_stream_lighton_decode and self.execution_lock != null and
                        M.lightOnPreparedStreamReady(&self.cb, self.gpt_config, claimed.len) and eligible: {
                        for (claimed) |item| {
                            const work: *PendingDecodeBatchWork = @ptrCast(@alignCast(item.work_ptr));
                            const sequence = work.sequence orelse break :eligible false;
                            if (sequence.generated >= sequence.max_tokens or sequence.max_tokens - sequence.generated < 2 or
                                sequence.seq_len.* > sequence.token_ids.len or sequence.token_ids.len - sequence.seq_len.* < 2) break :eligible false;
                        }
                        break :eligible true;
                    }) {
                        const embedding = try self.graphWeight("model.embed_tokens.weight");
                        defer self.cb.free(embedding);
                        burst_slot = try M.lightOnBurstEmbeddingSlot(&self.cb, embedding, self.gpt_config.hidden_size, self.gpt_config.vocab_size);
                    }
                    if (try self.cb.decoderRuntimeBeginFrame()) {'''
replace(p,a,b)
a='''                        try M.ensureFrameArgmaxScope(&self.cb);
                        // Never replay a forward after it has updated recurrent/KV'''
b='''                        if (burst_slot) |slot| return self.finishLightOnGpuTokenBurst(claimed, items, logits, head, slot, before_frames, before_argmax);
                        try M.ensureFrameArgmaxScope(&self.cb);
                        // Never replay a forward after it has updated recurrent/KV'''
replace(p,a,b)
replace(p,'        greedy_tokens: ?[]const u32 = null,\n        logits: ?[]const f32,','        greedy_tokens: ?[]const u32 = null,\n        second_greedy_tokens: ?[]const u32 = null,\n        logits: ?[]const f32,')
replace(p,'                    publishGreedyToken(work, token);\n                }\n                return;','''                    if (self.second_greedy_tokens) |second| {
                        const sequence = work.sequence orelse {
                            work.failure = error.InvalidBatchDecodeState;
                            work.ready.store(true, .release);
                            continue;
                        };
                        const row = (@intFromPtr(&token) - @intFromPtr(&token));
                        _ = row;
                        sequence.acceptTokens(&.{ token, second[@intCast(item.total_sequence_len - item.total_sequence_len)] }, true) catch |err| {
                            work.failure = err;
                            work.ready.store(true, .release);
                        };
                    } else publishGreedyToken(work, token);
                }
                return;''')
# Use a real row index for the zipped publication loop.
replace(p,'                for (claimed, tokens) |item, token| {','                for (claimed, tokens, 0..) |item, token, row| {')
replace(p,'                        const row = (@intFromPtr(&token) - @intFromPtr(&token));\n                        _ = row;\n','')
replace(p,'second[@intCast(item.total_sequence_len - item.total_sequence_len)]','second[row]')
replace(p,'        defer if (result.greedy_tokens) |tokens| self.allocator.free(tokens);','        defer if (result.greedy_tokens) |tokens| self.allocator.free(tokens);\n        defer if (result.second_greedy_tokens) |tokens| self.allocator.free(tokens);')
replace(p,'            .greedy_tokens = result.greedy_tokens,\n            .max_query_seq_len', '            .greedy_tokens = result.greedy_tokens,\n            .second_greedy_tokens = result.second_greedy_tokens,\n            .max_query_seq_len')
s='zig/pkg/inference/src/server/server.zig'
replace(s,'            single_frame: bool = false,','            single_frame: bool = false,\n            gpu_token_burst: bool = false,')
replace(s,'                features.stream_chunks = features.gpu_greedy_stream', '''                features.gpu_token_burst = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_GPU_TOKEN_BURST") and
                    metal_runtime.qualifiedM4DeviceDefault() and cfg.hasQwen35VisionArchitectureContract() and
                    cfg.qwen35_device_only_state and features.shared_decoder_scratch and features.epoch_auxiliary and
                    features.prepared and features.worker and features.activation_pool and features.batch_attention and
                    features.single_frame and features.stream_first_layers == 0 and
                    !platform.env.getenvBool("TERMITE_METAL_DISABLE_PIPELINED_DECODE_FRAME");
                features.stream_chunks = features.gpu_greedy_stream''')
replace(s,'                if (features.stream_first_layers != 0) {','                if (features.stream_first_layers != 0 or features.gpu_token_burst) {')
replace(s,'\n                .single_frame_lighton_decode = ctx.features.single_frame,','\n                .single_frame_lighton_decode = ctx.features.single_frame,\n                .gpu_token_burst_lighton_decode = ctx.features.gpu_token_burst,')
replace(s,'\n            .single_frame_lighton_decode = ctx.features.single_frame,','\n            .single_frame_lighton_decode = ctx.features.single_frame,\n            .gpu_token_burst_lighton_decode = ctx.features.gpu_token_burst,')
a='''                    const single_frame = if (comptime build_options.enable_metal)'''
b='''                    const burst = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnBurstStats(&cb) else @as([2]u64, @splat(0));
                    std.debug.print("LIGHTONOCR3 gpu_token_burst_enabled={d} gpu_token_burst_steps={d} gpu_token_burst_topology_mismatches={d}\\n", .{ @intFromBool(ctx.features.gpu_token_burst), burst[0], burst[1] });
                    const single_frame = if (comptime build_options.enable_metal)'''
replace(s,a,b)
(v/'engine64_prepared_changes.json').write_text(json.dumps(changes))
print('Prepared',len(changes),'files; source remains engine63')
