from pathlib import Path

v = Path('.venv-lighton-vllm-metal')
s = (v / 'run_engine38_budget_no_prefill_policies.py').read_text().replace('engine38', 'engine39')
s = s.replace("planned_disabled=os.environ.get('OCR_DISABLE_PLANNED_MPP','0')=='1'", "planned_disabled=os.environ.get('OCR_DISABLE_PLANNED_MPP','0')=='1';vision_stream=os.environ.get('OCR_VISION_STREAM','0')=='1'")
s = s.replace("if planned_disabled:cmd+=['--disable-planned-mpp']", "if planned_disabled:cmd+=['--disable-planned-mpp']\n if vision_stream:cmd+=['--vision-stream']")
s = s.replace("report['ocr_encoder_scopes']=encoder_scopes", "report['vision_stream']=vision_stream;report['ocr_encoder_scopes']=encoder_scopes")
s = s.replace("if vf>1:assert", "if vf>1 or vision_stream:assert")
s = s.replace("(int(x)>0)==(vf>1)", "(int(x)>0)==(vf>1 or vision_stream)")
marker = "    prefill_batches=re.findall("
extra = """    vision_stream_stats=re.findall(r'vision_stream=1 vision_stream_pending_blocks_peak=(\d+) vision_stream_retained_blocks=(\d+) vision_stream_images=(\d+)',section)
    sample['vision_stream_stats']=[list(map(int,x))for x in vision_stream_stats]
    if vision_stream:assert vision_stream_stats and all(int(a)==vf and int(b)==2*vf for a,b,n in vision_stream_stats) and sum(int(n)for a,b,n in vision_stream_stats)==int(requests),vision_stream_stats
    else:assert not vision_stream_stats,vision_stream_stats
"""
assert marker in s
s = s.replace(marker, extra + marker)
(v / 'run_engine39_budget_no_prefill_policies.py').write_text(s)
(v / 'engine39_benchmark_concurrency.py').write_bytes(Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
for p in v.glob('engine38_verify_*test.py'):
    (v / p.name.replace('engine38', 'engine39')).write_text(p.read_text().replace('engine38', 'engine39'))
(v / 'run_engine39_functional.py').write_text((v / 'run_engine38_functional.py').read_text().replace('engine38', 'engine39'))
