#include <metal_stdlib>
#include <metal_simdgroup_matrix>
using namespace metal;
struct Params {uint seq,key_heads,value_heads,dim,kernel_size,initialized;};
// A strict lower triangular interaction matrix and inclusive Q/K weights.
// Direct products preserve exactly-zero decay without log clamps/division.
kernel void chunk_coeff115(device const float*x[[buffer(9)]],device const float*g[[buffer(10)]],constant Params&p[[buffer(15)]],device float*coef[[buffer(16)]],uint tid[[thread_index_in_threadgroup]],uint sg[[simdgroup_index_in_threadgroup]],uint group[[threadgroup_position_in_grid]]){
 const uint h=group%p.value_heads,chunk=group/p.value_heads,start=chunk*16,kh=h/(p.value_heads/p.key_heads),channels=(2*p.key_heads+p.value_heads)*128;
 const uint rb=(sg/2)*8,cb=(sg%2)*8;
 threadgroup float kk[256],qk[256];
 auto accK=make_filled_simdgroup_matrix<float,8>(0.0f),accQ=make_filled_simdgroup_matrix<float,8>(0.0f);
 for(uint d=0;d<128;d+=8){
  simdgroup_float8x8 ki,kj,qi;
  simdgroup_load(ki,x+(start+rb)*channels+(p.key_heads+kh)*128+d,channels);
  simdgroup_load(qi,x+(start+rb)*channels+kh*128+d,channels);
  simdgroup_load(kj,x+(start+cb)*channels+(p.key_heads+kh)*128+d,channels,0,true);
  simdgroup_multiply_accumulate(accK,ki,kj,accK);simdgroup_multiply_accumulate(accQ,qi,kj,accQ);
 }
 simdgroup_store(accK,kk+rb*16+cb,16);simdgroup_store(accQ,qk+rb*16+cb,16);
 threadgroup_barrier(mem_flags::mem_threadgroup);
 device float*out=coef+group*544;
 for(uint z=tid;z<256;z+=128){
  uint i=z/16,j=z%16;float ratio=1.0f;
  if(j<=i)for(uint t=j+1;t<=i;t++)ratio*=g[((start+t)*p.value_heads+h)*2];
  float beta=g[((start+i)*p.value_heads+h)*2+1];
  out[z]=j<i?beta*ratio*kk[z]:0.0f;out[256+z]=j<=i?ratio*qk[z]:0.0f;
 }
 if(tid<16){float prefix=1.0f,tail=1.0f;for(uint t=0;t<=tid;t++)prefix*=g[((start+t)*p.value_heads+h)*2];for(uint t=tid+1;t<16;t++)tail*=g[((start+t)*p.value_heads+h)*2];out[512+tid]=prefix;out[528+tid]=tail;}
}
// One group owns sixteen value columns for the complete prompt. Its state
// and all intermediates remain F32; only the small triangular solve is serial.
kernel void chunk_state115(device float*state[[buffer(8)]],device const float*x[[buffer(9)]],device const float*g[[buffer(10)]],device float*y[[buffer(11)]],constant Params&p[[buffer(15)]],device const float*coef[[buffer(16)]],uint tid[[thread_index_in_threadgroup]],uint sg[[simdgroup_index_in_threadgroup]],uint group[[threadgroup_position_in_grid]]){
 const uint h=group/8,v0=(group%8)*16,kh=h/(p.value_heads/p.key_heads),channels=(2*p.key_heads+p.value_heads)*128;
 const uint rb=(sg/2)*8,vb=(sg%2)*8;
 threadgroup float s[128*16],qm[256],km[256],delta[256];
 for(uint z=tid;z<128*16;z+=128)s[z]=p.initialized?state[(h*128+z/16)*128+v0+z%16]:0.0f;
 threadgroup_barrier(mem_flags::mem_threadgroup);
 for(uint start=0;start+16<=p.seq;start+=16){
  device const float*c=coef+((start/16)*p.value_heads+h)*544;
  auto aq=make_filled_simdgroup_matrix<float,8>(0.0f),ak=make_filled_simdgroup_matrix<float,8>(0.0f);
  for(uint d=0;d<128;d+=8){
   simdgroup_float8x8 q,k,ss;
   simdgroup_load(q,x+(start+rb)*channels+kh*128+d,channels);
   simdgroup_load(k,x+(start+rb)*channels+(p.key_heads+kh)*128+d,channels);
   simdgroup_load(ss,s+d*16+vb,16);
   simdgroup_multiply_accumulate(aq,q,ss,aq);simdgroup_multiply_accumulate(ak,k,ss,ak);
  }
  simdgroup_store(aq,qm+rb*16+vb,16);simdgroup_store(ak,km+rb*16+vb,16);
  threadgroup_barrier(mem_flags::mem_threadgroup);
  if(tid<16)for(uint i=0;i<16;i++){
   const float beta=g[((start+i)*p.value_heads+h)*2+1];
   float d=beta*(x[(start+i)*channels+2*p.key_heads*128+h*128+v0+tid]-c[512+i]*km[i*16+tid]);
   for(uint j=0;j<i;j++)d-=c[i*16+j]*delta[j*16+tid];
   delta[i*16+tid]=d;
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);
  auto out=make_filled_simdgroup_matrix<float,8>(0.0f);
  for(uint d=0;d<16;d+=8){simdgroup_float8x8 m,dd;simdgroup_load(m,c+256+rb*16+d,16);simdgroup_load(dd,delta+d*16+vb,16);simdgroup_multiply_accumulate(out,m,dd,out);}
  simdgroup_store(out,km+rb*16+vb,16);
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint z=tid;z<256;z+=128){uint i=z/16,v=z%16;y[((start+i)*p.value_heads+h)*128+v0+v]=c[512+i]*qm[z]+km[z];delta[z]*=c[528+i];}
  for(uint z=tid;z<128*16;z+=128)s[z]*=c[527];
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint tile=sg;tile<32;tile+=4){
   uint kb=(tile/2)*8,vc=(tile%2)*8;simdgroup_float8x8 next;
   simdgroup_load(next,s+kb*16+vc,16);
   for(uint d=0;d<16;d+=8){simdgroup_float8x8 k,dd;simdgroup_load(k,x+(start+d)*channels+(p.key_heads+kh)*128+kb,channels,0,true);simdgroup_load(dd,delta+d*16+vc,16);simdgroup_multiply_accumulate(next,k,dd,next);}
   simdgroup_store(next,s+kb*16+vc,16);
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);
 }
 for(uint z=tid;z<128*16;z+=128)state[(h*128+z/16)*128+v0+z%16]=s[z];
}
