from pathlib import Path
import json,hashlib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=json.loads((v/'engine139-freeze.json').read_text());(v/'engine145-freeze.json').write_text(json.dumps({p:sha(p)for p in f},indent=2)+'\n')
for old,new in [('run_engine139_gpu_build.py','run_engine145_gpu_build.py'),('run_engine139_budget_policies.py','run_engine145_budget_policies.py')]:
 s=(v/old).read_text().replace('engine139','engine145');(v/new).write_text(s)
# The private benchmark is byte-identical to the public benchmark. Only the
# manifest, binary and output namespace are rebound in the verification driver.
(v/'engine145_benchmark_concurrency.py').write_bytes((r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
print('source145 frozen',len(f),'files')
