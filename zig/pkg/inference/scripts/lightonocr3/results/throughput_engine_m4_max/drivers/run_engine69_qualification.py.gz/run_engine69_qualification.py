from pathlib import Path
import json,hashlib,subprocess,sys,datetime,re,importlib.util
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';o=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=json.loads((o/'engine68_c_qualification_audit.json').read_text());assert d['status']=='pass' and len(d['checks'])==19
for p,h in d['input_sha256'].items():assert sha(p)==h,p
m=json.loads((o/'engine68_c_build_manifest.json').read_text());assert sha(m['binary'])==m['binary_sha256']
d.update(reused_unchanged_c_qualification=True,source_audit_sha256=sha(o/'engine68_c_qualification_audit.json'),scope='All C runtime, shader, header and conformance input hashes and tested C binary are identical to68. Fresh Zig suites cover the corrected row mask and unchanged packing callback integration.',verified_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(o/'engine69_c_qualification_audit.json').write_text(json.dumps(d,indent=2)+'\n')
def fragment(source,marker):
 start=source.index(marker);brace=source.index('{',start);depth=1;end=brace+1
 while depth:
  if source[end]=='{':depth+=1
  elif source[end]=='}':depth-=1
  end+=1
 return source[start:end]+'\n'
s=(root/'zig/pkg/inference/src/ops/metal_compute.zig').read_text();debug_source='const std = @import("std");\n'+fragment(s,'fn lightOnReportedRowBit(')+'\n'+fragment(s,'test "LightOnOCR3 row reporting covers sixty-four cohorts without shift overflow"')
p=v/'engine69_trace_mask_debug_check.zig';p.write_text(debug_source)
with Path('/private/tmp/ocr-engine69-trace-mask-debug.txt').open('w')as f:
 subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','test',str(p),'--cache-dir',str(root/'zig/.zig-cache'),'--global-cache-dir',str(root/'zig/.zig-cache/global')],cwd=root/'zig',stdout=f,stderr=subprocess.STDOUT,check=True)
(o/'engine69_trace_mask_debug_audit.json').write_text(json.dumps(dict(status='pass',scope='Debug safety checks enabled, exact helper and boundary-test fragments extracted from frozen production source. Covers all 64 row bits, no overlap, complete u64 mask and invalid dimensions.',production_source_sha256=sha(root/'zig/pkg/inference/src/ops/metal_compute.zig'),extracted_debug_source_sha256=sha(p)),indent=2)+'\n')
sys.path.insert(0,str(root/'zig/pkg/inference/scripts/lightonocr3'));import benchmark_concurrency as b
parser_checks=[]
eligible=json.loads((o/'engine68_prefill_stream49_4b_r128_audit.json').read_text())['candidates']
for rp in [o/x['report']for x in eligible if x['eligible']]:
 report=json.loads(rp.read_text());sample=report['results'][0]['policy_rounds'][0];raw=(rp.parent/report['results'][0]['log']).read_text().split('OCR_POLICY round=0',1)[1]
 actual=b.prefill_stream_observation(raw);assert actual['prefill_stream_splits']==sample['prefill_stream_splits'] and actual['prefill_stream_layers_observed']==[report['prefill_stream_layers']],(rp,actual)
 parser_checks.append(dict(report=str(rp.relative_to(o)),actual=actual))
assert len(parser_checks)==sum(x['eligible']for x in eligible) and parser_checks
(o/'engine69_observed_prefill_counter_audit.json').write_text(json.dumps(dict(status='pass',scope='Public parser checked against each completed eligible real R128 log and their independently verified private counters.',benchmark_source_sha256=sha(root/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py'),checks=parser_checks),indent=2)+'\n')
for name,cmd in [('gpu-build',[sys.executable,str(v/'run_engine69_verify2_gpu_build.py')]),('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine69','/private/tmp/ocr-engine69-verify2-gpu-build.txt']),('metal-disabled',[sys.executable,str(v/'run_engine69_metal_disabled.py')])]:
 print('START',name,flush=True)
 with Path('/private/tmp/ocr-engine69-'+name+'-driver.txt').open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 print('DONE',name,r.returncode,flush=True);assert r.returncode==0,(name,r.returncode)
print('ENGINE69 QUALIFICATION DONE',flush=True)
