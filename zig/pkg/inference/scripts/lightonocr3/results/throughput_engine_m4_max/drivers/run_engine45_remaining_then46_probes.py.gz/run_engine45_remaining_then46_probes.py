from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';out=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def freeze():
 d=json.loads((v/'engine45-freeze.json').read_text())
 assert all(sha(root/p)==s for p,s in d.items())
 m=json.loads((out/'engine45_build_manifest.json').read_text())
 assert sha(Path(m['binary_path']))==m['binary_sha256']
def archive(paths):
 ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
 ns['archive']('qualification',paths,'logs_manifest.json')
def run(name,cmd):
 print('START',name,flush=True)
 log=Path('/private/tmp/ocr-'+name+'.txt');assert not log.exists()
 with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 archive([log]);print('DONE',name,r.returncode,flush=True)
 assert r.returncode==0,(name,r.returncode)
def compress(patterns):
 subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),*patterns],check=True)
while True:
 a=out/'paired26_4b_08_comparison_audit.json'
 if a.exists() and json.loads(a.read_text())['status']!='running':break
 time.sleep(5)
time.sleep(2)
freeze()
compress(['engine45_*paired26*','vllm_*reference26*'])
archive(list(Path('/private/tmp').glob('ocr-engine45-*paired26*.txt')))
run('engine45-florence-paired26-driver',[sys.executable,str(v/'run_engine45_florence_paired26.py')])
freeze();compress(['*florence*paired26*'])
archive(list(Path('/private/tmp').glob('ocr-engine45-florence-paired26-*.txt')))
run('engine45-prefill2-old64-primary',[sys.executable,str(v/'run_engine45_prefill2_case.py'),'primary','64','0'])
freeze();compress(['engine45_4b_vision1_prefill2_c64_vf2_wide640_r128_primary'])
archive(list(Path('/private/tmp').glob('ocr-engine45-4b-*vision1_prefill2_c64_vf2_wide640*r128*txt')))
run('engine45-prefill2-new60-primary',[sys.executable,str(v/'run_engine45_prefill2_case.py'),'primary','60','1'])
freeze();compress(['engine45_4b_vision1_prefill2_c60_vf2_wide641_r128_primary'])
archive(list(Path('/private/tmp').glob('ocr-engine45-4b-*vision1_prefill2_c60_vf2_wide641*r128*txt')))
run('engine46-streamed-prefill-tiles-compile-driver',[sys.executable,str(v/'build_engine46_streamed_prefill_tiles.py')])
archive([Path('/private/tmp/ocr-engine46-streamed-prefill-tiles-build.txt')])
run('engine46-streamed-prefill-tiles-probe',[str(v/'engine46_streamed_prefill_tiles')])
freeze()
run('engine46-prefill-columns-compile-driver',[sys.executable,str(v/'build_engine46_prefill_columns_probe.py')])
archive([Path('/private/tmp/ocr-engine46-prefill-columns-probe-build.txt')])
for c in [8,16]:
 run(f'engine46-prefill-columns{c}-probe',[str(v/'engine46_prefill_columns_probe'),str(c)])
freeze()
print('ALL COMPLETE',flush=True)
