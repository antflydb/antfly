from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
s=(v/'run_engine53_large_chunk_profiles.py').read_text().replace("c=int(os.environ.get('OCR_CASE_CONCURRENCY','60'));prefill=int(os.environ.get('OCR_CASE_PREFILL_ITEMS','2'));vf=int(os.environ.get('OCR_CASE_VISION_FRAME_BLOCKS','2'));tag=os.environ.get('OCR_CASE_TAG','profile2')", "c=int(os.environ.get('OCR_CASE_CONCURRENCY','48'));prefill=int(os.environ.get('OCR_CASE_PREFILL_ITEMS','1'));vf=int(os.environ.get('OCR_CASE_VISION_FRAME_BLOCKS','1'));tag=os.environ.get('OCR_CASE_TAG','vision4');vision_items=int(os.environ.get('OCR_CASE_VISION_BATCH_ITEMS','4'))")
s=s.replace("OCR_VISION_BATCH='0',OCR_VISION_BATCH_ITEMS='1'", "OCR_VISION_BATCH='1'if vision_items>1 else'0',OCR_VISION_BATCH_ITEMS=str(vision_items)")
compile(s,'vision4','exec');(v/'run_engine53_vision4_profile.py').write_text(s)
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns);ns['archive']('drivers',[v/'prepare_engine53_vision4_profile.py',v/'run_engine53_vision4_profile.py'],'drivers_manifest.json')
