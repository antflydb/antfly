from pathlib import Path
import datetime, importlib.metadata, json, statistics, time
import mlx.core as mx
out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/engine24_mlx_gemm_matched_probe.json')
report=dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),mlx_version=importlib.metadata.version('mlx'),scope='Isolated hot-weight GEMM wall time, synchronized each iteration; A/B resident on GPU, F32 result required, loading/random generation/warmup excluded. BF16 input is prepared before timing; native pack probe includes GPU input packing and a producer add. No own CPU compilation.',results=[])
mx.random.seed(20261024)
for rows,in_dim,out_dim in [(128,1024,4096),(432,1024,4096),(864,1024,4096),(128,2560,4096),(432,2560,4096),(864,2560,4096)]:
 a=mx.random.uniform(-.7,.7,shape=(rows,in_dim));w=mx.random.uniform(-.03,.03,shape=(out_dim,in_dim)).astype(mx.bfloat16);mx.eval(a,w)
 for dtype in [mx.float32,mx.bfloat16]:
  x=a.astype(dtype);mx.eval(x)
  for i in range(5): y=(x@w.T).astype(mx.float32);mx.eval(y);mx.synchronize()
  durations=[]
  for i in range(20):
   begin=time.perf_counter_ns();y=(x@w.T).astype(mx.float32);mx.eval(y);mx.synchronize();durations.append((time.perf_counter_ns()-begin)/1000)
  row=dict(rows=rows,in_dim=in_dim,out_dim=out_dim,input_dtype=str(dtype),weight_dtype=str(w.dtype),output_dtype=str(y.dtype),iterations=len(durations),median_wall_us=statistics.median(durations),min_wall_us=min(durations),max_wall_us=max(durations))
  report['results'].append(row);out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(row),flush=True)
