from pathlib import Path
import json
import os
import subprocess
import sys

v = Path('.venv-lighton-vllm-metal')
out = Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
env = os.environ.copy()
env.update(OCR_REFERENCE_LABEL='_primary_reference18_r0_auto_c64_r128', OCR_PHYSICAL32='0',
           OCR_PHYSICAL64='1', OCR_REQUESTS='128', OCR_WIDE='1', OCR_SCRATCH_GIB='8',
           OCR_BACKEND_GIB='16', OCR_KV_GIB='4', OCR_CPU_PREPROCESS='1',
           OCR_PREFILL_DECODE_STREAK='0', OCR_POLICIES='engineepoch', OCR_SHARED_CORE='0',
           OCR_BF16_PREFILL='0', OCR_BF16='0', OCR_VISION_BATCH='0', OCR_SINGLE_FRAME='1',
           OCR_STREAM_FIRST='0', OCR_LOGICAL64='1', OCR_SHARED_DECODER_SCRATCH='1',
           OCR_DEVICE_RECURRENT_STATE='1', OCR_ENCODER_SCOPES='1', OCR_ADMISSION_UNITS='512')
cases = [(64, 4, False, False), (64, 4, True, False)]
if '--qualification' in sys.argv:
    cases = [(64, 2, False, False)]
    env['OCR_REQUESTS'] = '64'
for concurrency, blocks, old_tile, bf16 in cases:
    env.update(OCR_CONCURRENCY=str(concurrency), OCR_VISION_FRAME_BLOCKS=str(blocks),
               OCR_DISABLE_64_ROW_TILE=str(int(old_tile)), OCR_BF16=str(int(bf16)))
    label = f'physical64_c{concurrency}_vf{blocks}_oldtile{int(old_tile)}_bf16{int(bf16)}_r{env["OCR_REQUESTS"]}'
    if '--qualification' in sys.argv:
        label += '_qualification'
    assert not (out / f'engine38_08_{label}/report.json').exists()
    print('START', label, flush=True)
    result = subprocess.run([sys.executable, str(v / 'run_engine38_budget_no_prefill_policies.py'), '08:' + label], env=env)
    print('DONE', label, result.returncode, flush=True)
    if result.returncode:
        sys.exit(result.returncode)
    report = json.loads((out / f'engine38_08_{label}/report.json').read_text())
    r = report['results'][0]
    assert r['serial_reference_parity'] and r['cross_runtime_content_parity']
    oracle = json.loads((out / 'vllm_08_primary_reference18_r0_auto_c64_r128/report.json').read_text())
    assert {x['image_index']: x['text'] for x in r['references']} == {x['image_index']: x['text'] for x in oracle['references']}
    assert r['policy_rounds'][0]['completed'] == int(env['OCR_REQUESTS'])
