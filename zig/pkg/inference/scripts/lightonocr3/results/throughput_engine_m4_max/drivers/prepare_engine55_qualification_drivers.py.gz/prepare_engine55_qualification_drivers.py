from pathlib import Path
v=Path('.venv-lighton-vllm-metal')
for old,new in [('build_engine53_conformance.py','build_engine55_conformance.py'),('run_engine53_c_qualification.py','run_engine55_c_qualification.py'),('run_engine53_c_and_bind.py','run_engine55_c_and_bind.py'),('run_engine53_functional.py','run_engine55_functional.py'),('engine53_verify_preset_only_test.py','engine55_verify_preset_only_test.py'),('engine53_verify_preset_physical32_test.py','engine55_verify_preset_physical32_test.py'),('engine53_verify_default_gpu_test.py','engine55_verify_default_gpu_test.py')]:
 s=(v/old).read_text().replace('engine53','engine55')
 if new=='run_engine55_c_qualification.py':s=s.replace("flags=['--check-wide-gate-up-full64'","flags=['--check-batch-argmax','--check-wide-gate-up-full64'")
 if new=='run_engine55_c_and_bind.py':s=s.replace('==13','==14').replace('ALL 13 C','ALL 14 C')
 (v/new).write_text(s)
s=(v/'run_engine53_budget_policies.py').read_text().replace('engine53','engine55')
needle=" full64_gate_up=os.environ.get('OCR_FULL64_GATE_UP','0')=='1'"
s=s.replace(needle,""" batch_argmax=os.environ.get('OCR_BATCH_ARGMAX','0')=='1'
 defer_vision=os.environ.get('OCR_DEFER_VISION_SEAL','0')=='1'
 defer_prefill=os.environ.get('OCR_DEFER_PREFILL_SEAL','0')=='1'
 if batch_argmax:cmd+=['--batch-argmax']
 if defer_vision:cmd+=['--defer-vision-seal']
 if defer_prefill:cmd+=['--defer-prefill-seal']
"""+needle)
s=s.replace("report['stream_chunk_layers']=chunks;","report['batch_argmax']=batch_argmax;report['defer_vision_seal']=defer_vision;report['defer_prefill_seal']=defer_prefill;report['stream_chunk_layers']=chunks;")
needle="    assert 'wide_gate_up_calls' in sample,sample"
s=s.replace(needle,"""    for name,enabled in [('vision_late_seal',defer_vision),('prefill_late_seal',defer_prefill)]:
     values=re.findall(r'LIGHTONOCR3 '+name+r'=(\\d+)',section)
     assert values and all((int(x)==1)==(enabled and expected_aux)for x in values),(name,values,enabled,expected_aux)
    assert 'batch_argmax_calls'in sample and 'batch_argmax_rows'in sample,sample
    if batch_argmax and int(c)>1:assert sample['batch_argmax_calls']>0 and 2*sample['batch_argmax_calls']<=sample['batch_argmax_rows']<=64*sample['batch_argmax_calls'],sample
    else:assert sample['batch_argmax_calls']==sample['batch_argmax_rows']==0,sample
"""+needle)
s=s.replace("'--timeout','900'","'--timeout',os.environ.get('OCR_TIMEOUT','900')")
compile(s,'budget55','exec');(v/'run_engine55_budget_policies.py').write_text(s)
for old in ['run_engine53_large_chunk_profiles.py','run_engine53_vision4_profile.py','run_engine53_chunk_cases.py']:
 s=(v/old).read_text().replace('engine53','engine55')
 (v/old.replace('engine53','engine55')).write_text(s)
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('drivers',list(v.glob('*engine55*.py')),'drivers_manifest.json')
print('prepared engine55 C14, functional3, budget/case drivers')
