from pathlib import Path
import time,subprocess,sys,hashlib,json
v=Path('.venv-lighton-vllm-metal');p=Path('/private/tmp/ocr-engine55-verify-gpu-build-driver.txt')
print('WAIT engine55 native build',flush=True)
while True:
 s=p.read_text()if p.exists()else''
 if 'qualified actual two-dispatch batch argmax counters'in s:break
 if 'exit 1'in s or'Traceback'in s:raise RuntimeError('native build failure; preserve source and logs')
 time.sleep(5)
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
def run(name,cmd):
 log=Path('/private/tmp/ocr-engine55-'+name+'-driver.txt');assert not log.exists(),log
 print('START',name,flush=True)
 with log.open('w')as out:r=subprocess.run(cmd,stdout=out,stderr=subprocess.STDOUT)
 ns['archive']('qualification',[log],'logs_manifest.json');print('DONE',name,r.returncode,flush=True);assert r.returncode==0,(name,r.returncode)
run('finalize',[sys.executable,str(v/'finalize_engine_build.py'),'engine55','/private/tmp/ocr-engine55-verify-gpu-build.txt'])
run('c-checks',[sys.executable,str(v/'run_engine55_c_and_bind.py')])
run('functional',[sys.executable,str(v/'run_engine55_functional.py')])
run('stage-smoke',[sys.executable,str(v/'run_engine55_stage_smoke.py')])
run('stage-profiles',[sys.executable,str(v/'run_engine55_stage_profiles.py')])
for name,h in json.loads((v/'engine55-freeze.json').read_text()).items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h,name
print('ALL ENGINE55 QUALIFICATION PASS',flush=True)
