from pathlib import Path
import os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');env=os.environ.copy();env.update(OCR_REFERENCE_LABEL='_primary_reference18_r0_auto_c64_r128',OCR_PHYSICAL32='1',OCR_CONCURRENCY='32',OCR_REQUESTS='128',OCR_WIDE='1',OCR_SCRATCH_GIB='8',OCR_BACKEND_GIB='16',OCR_KV_GIB='4',OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='0',OCR_BF16_PREFILL='0',OCR_BF16='0',OCR_VISION_BATCH='0',OCR_VISION_FRAME_BLOCKS='4',OCR_SINGLE_FRAME='1',OCR_STREAM_FIRST='0',OCR_LOGICAL64='1',OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',OCR_ADMISSION_UNITS='512')

for concurrency,blocks in [(64,4)]:
 env.update(OCR_CONCURRENCY=str(concurrency),OCR_VISION_FRAME_BLOCKS=str(blocks))
 label=f'encoder_scopes_c{concurrency}_vf{blocks}_physical32_device16_scratch8_sf1_f32_r128_0'
 print('START',label,flush=True)
 r=subprocess.run([sys.executable,str(v/'run_engine37_budget_no_prefill_policies.py'),'08:'+label],env=env)
 print('DONE',label,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
