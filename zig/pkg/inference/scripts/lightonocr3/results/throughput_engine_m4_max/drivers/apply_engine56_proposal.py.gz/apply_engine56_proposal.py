from pathlib import Path
import json,hashlib,shutil,subprocess
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
frozen=json.loads((v/'engine55-freeze.json').read_text());assert all(sha(p)==h for p,h in frozen.items())
assert json.loads((o/'engine55_full_qualification_audit.json').read_text())['status']=='pass'
assert json.loads((o/'engine56_proposal_c_checks_audit.json').read_text())['status']=='pass'
manifest=json.loads((o/'engine56_proposal_c_build_manifest.json').read_text());assert all(sha(p)==h for p,h in manifest['input_sha256'].items())
proposal=v/'engine56-proposal';files={str(p.relative_to(proposal)):sha(p)for p in proposal.rglob('*')if p.is_file()}
(v/'engine56-proposal-reviewed.json').write_text(json.dumps(files,indent=2)+'\n')
ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
ns['archive']('drivers',[Path(__file__),v/'refine_engine56_broker_callbacks.py',v/'engine56_executor_microbatch_verify2.zig',v/'engine56-proposal-reviewed.json'],'drivers_manifest.json')
ns['archive']('qualification',[Path('/private/tmp/ocr-engine56-proposal-checks-driver.txt')],'logs_manifest.json')
for p in files:shutil.copyfile(proposal/p,p)
for p in files:
 if p.endswith('.zig'):subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','ast-check',p],check=True)
(v/'engine56-freeze.json').write_text(json.dumps({p:sha(p)for p in frozen},indent=2)+'\n')
shutil.copyfile('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py',v/'engine56_benchmark_concurrency.py')
s=(v/'run_engine55_verify_gpu_build.py').read_text().replace('engine55','engine56')
needle="env['TERMITE_METAL_ENABLE_LIGHTONOCR3_BATCH_ARGMAX']='1'";assert needle in s
s=s.replace(needle,needle+"\nenv['ANTFLY_LIGHTONOCR3_KEEP_VISION_WORKSPACE']='1'\nenv['TERMITE_METAL_ENABLE_LIGHTONOCR3_LARGE_VISION_PACK_REUSE']='1'")
s=s.replace('sys.exit(r.returncode)', '''if r.returncode==0:
 allocations=re.findall(r'LIGHTONOCR3 vision_workspace_allocations=(\\d+)',log)
 reuses=re.findall(r'LIGHTONOCR3 vision_workspace_reuses=(\\d+)',log)
 capacities=re.findall(r'LIGHTONOCR3 vision_workspace_bytes=(\\d+)',log)
 assert allocations and reuses and capacities and sum(map(int,reuses))>0 and sum(map(int,capacities))>0,(allocations,reuses,capacities)
 print('qualified retained vision packing workspace counters',allocations,reuses,capacities)
sys.exit(r.returncode)''')
(v/'run_engine56_verify_gpu_build.py').write_text(s);compile(s,'build56','exec')
ns['archive']('drivers',[v/'engine56-freeze.json',v/'engine56_benchmark_concurrency.py',v/'run_engine56_verify_gpu_build.py'],'drivers_manifest.json')
print('applied engine56; frozen',len(frozen),'files; cache admitted by existing epoch vision peak')
