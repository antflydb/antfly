from pathlib import Path
import subprocess,sys
v=Path('.venv-lighton-vllm-metal')
for args in [['refresh_engine30_florence_reference.py','florence'],['run_engine30_florence.py']]:
 print('START',args,flush=True)
 r=subprocess.run([sys.executable,str(v/args[0]),*args[1:]])
 print('DONE',args,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
