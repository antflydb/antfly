from pathlib import Path
import os, subprocess, sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';s=r/'zig/pkg/inference/scripts/lightonocr3';out=s/'results/throughput_engine_m4_max'
images=[r/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png',s/'corpus/receipt.png',s/'corpus/shipping.png']
for model in sys.argv[1:]:
 for concurrency in [16,32]:
  label=f'_primary_reference7_auto_c{concurrency}_r128';target=out/f'vllm_{model}{label}'
  command=[sys.executable,str(s/'benchmark_vllm_metal.py'),'--python',sys.executable,'--model-dir',str(v/'ocr-models'/('lighton'+model)),'--images',*[str(x)for x in images],'--concurrency',str(concurrency),'--requests','128','--max-tokens','256','--startup-timeout','600','--output-dir',str(target)]
  print('START VLLM',model,concurrency,flush=True)
  with open(f'/private/tmp/ocr-engine-vllm-{model}-primary7-auto-c{concurrency}-r128.txt','w')as log:res=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
  print('DONE VLLM',model,concurrency,res.returncode,flush=True)
  if res.returncode:sys.exit(res.returncode)
  shared='0'if model=='08'else'1';prefill='0'if model=='08'else'1'
  env=os.environ.copy();env.update(OCR_CONCURRENCY='16',OCR_REQUESTS='128',OCR_WIDE='1',OCR_SCRATCH_GIB='8',OCR_STREAM_FIRST='0',OCR_SINGLE_FRAME='0',OCR_SHARED_CORE=shared,OCR_BF16_PREFILL=prefill,OCR_REFERENCE_LABEL=label,OCR_POLICIES=os.environ.get('OCR_PAIRED7_POLICY_'+model.upper(),'engineepoch'))
  key=model+f':paired7_after_vllm_c{concurrency}_native_c16_cache{shared}_prefill{prefill}_0'
  print('START NATIVE',key,flush=True)
  res=subprocess.run([sys.executable,str(v/'run_engine21_policies.py'),key],env=env)
  print('DONE NATIVE',key,res.returncode,flush=True)
  if res.returncode:sys.exit(res.returncode)
