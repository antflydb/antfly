from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';out=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';manifest=out/'engine24debug_build_manifest.json';binary=json.loads(manifest.read_text())['binary_path'];label='cpu_sample_c32_r64_0';target=out/('engine24debug_4b_'+label)
assert not(target/'report.json').exists()
env=os.environ.copy();env.update(OCR_CONCURRENCY='32',OCR_REQUESTS='64',OCR_WIDE='1',OCR_PHYSICAL32='1',OCR_BF16='1',OCR_SCRATCH_GIB='8',OCR_STREAM_FIRST='0',OCR_SINGLE_FRAME='0',OCR_SHARED_CORE='1',OCR_BF16_PREFILL='1',OCR_POLICIES='engineepoch',OCR_REFERENCE_LABEL='_primary_reference8_r0_auto_c32_r128',OCR_VISION_BATCH='0')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();samples=[]
with open('/private/tmp/ocr-engine24debug-cpu-sample-driver.txt','w')as log:
 process=subprocess.Popen([sys.executable,str(v/'run_engine24debug_policies.py'),'4b:'+label],env=env,stdout=log,stderr=subprocess.STDOUT)
 start=time.monotonic();trigger=None;pid=None
 while process.poll()is None:
  raw=target/'lighton4b-batch-c32.txt'
  if trigger is None and raw.exists()and 'OCR_POLICY round=0' in raw.read_text():
   entries={}
   for line in subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines():
    fields=line.strip().split(None,2)
    if len(fields)==3:entries[int(fields[0])]=(int(fields[1]),fields[2])
   candidates=[]
   for candidate,(parent,command)in entries.items():
    if not command.startswith(binary+' '):continue
    ancestors=set();current=candidate
    while current in entries and current not in ancestors:ancestors.add(current);current=entries[current][0]
    if process.pid in ancestors:candidates.append(candidate)
   assert len(candidates)==1,candidates;pid=candidates[0];trigger=time.monotonic();print('verified own OCR descendant',pid,flush=True)
  if trigger is not None:
   for index,(stage,delay)in enumerate([('early',2),('middle',25),('late',50)]):
    if len(samples)!=index or time.monotonic()-trigger<delay:continue
    dest=Path('/private/tmp')/('ocr-engine24debug-cpu-'+stage+'-sample.txt');stamp=datetime.datetime.now(datetime.timezone.utc).isoformat();print('sample',stage,pid,flush=True)
    r=subprocess.run(['sample',str(pid),'3','1','-file',str(dest)],stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT)
    samples.append(dict(stage=stage,pid=pid,started_at=stamp,exit_code=r.returncode,path=str(dest),sha256=sha(dest)if dest.exists()else None))
  if time.monotonic()-start>600:raise RuntimeError('diagnostic exceeded expected duration')
  time.sleep(.2)
 rc=process.wait();print('exit',rc,'samples',len(samples),flush=True)
 if(target/'report.json').exists():
  p=target/'report.json';d=json.loads(p.read_text());d.update(primary_throughput=False,instrumented_cpu_sample=True,own_cpu_compile_overlap=False);p.write_text(json.dumps(d,indent=2)+'\n')
  (target/'instrumentation_audit.json').write_text(json.dumps(dict(report_sha256=sha(p),binary_sha256=sha(Path(binary)),build_manifest_sha256=sha(manifest),primary_throughput_eligible=False,reason='Three three-second Mac CPU stack samples of this benchmark descendant only; no own CPU compilation. Debug symbols retained in ReleaseFast binary.',samples=samples),indent=2)+'\n')
 sys.exit(rc)
