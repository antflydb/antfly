from pathlib import Path
import json,hashlib
v=Path('.venv-lighton-vllm-metal');dest=v/'engine56-proposal';p='zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m';s=Path(p).read_text();needle='int main(int argc, const char **argv) {';assert s.count(needle)==1
s=s.replace(needle,(v/'engine56_vision_workspace_checks.inc').read_text()+needle)
needle='        if (argc == 2 && strcmp(argv[1], "--check-batch-argmax") == 0) {'
s=s.replace(needle,'''        if (argc == 2 && strcmp(argv[1], "--check-vision-workspace-cache") == 0) {
            int rc = vision_workspace_cache_check(r);
            termite_metal_decode_runtime_destroy(r);
            return rc;
        }
        if (argc == 2 && strcmp(argv[1], "--check-large-vision-pack-reuse") == 0) {
            setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_LARGE_VISION_PACK_REUSE", "1", 1);
            const size_t shapes[][3] = {{4097,1024,1024},{8192,4096,1024},{16384,768,768}};
            for (size_t i = 0; i < 3; ++i) {
                @autoreleasepool {
                    int rc = vision_pack_reuse_check(r, shapes[i][0], shapes[i][1], shapes[i][2], false);
                    if (rc) { fprintf(stderr,"LARGE_VISION_PACK_FAIL rows=%zu rc=%d\\n",shapes[i][0],rc); return rc; }
                }
            }
            unsetenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_LARGE_VISION_PACK_REUSE");
            termite_metal_decode_runtime_destroy(r);
            return 0;
        }
'''+needle)
a=s.index('static int vision_pack_reuse_check(');b=s.index('static ',a+12);part=s[a:b]
needle='  const size_t steps = 6, count = rows * in, outputs = rows * out,';assert needle in part
part=part.replace(needle,'''  const bool large_scope = rows > 4096 && rows <= 16384 && termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_LARGE_VISION_PACK_REUSE"));
  const bool scope_eligible = rows <= 4096 || large_scope;
  const size_t steps = large_scope ? 2 : 6, count = rows * in, outputs = rows * out,''')
part=part.replace('&& rows <= 4096)', '&& scope_eligible)')
s=s[:a]+part+s[b:]
t=dest/p;t.parent.mkdir(parents=True,exist_ok=True);t.write_text(s)
(v/'engine56_product_checks.m').write_text(s.replace('#include "../../src/backends/metal_kernels.m"','#include "engine56-proposal/zig/pkg/inference/src/backends/metal_kernels.m"'))
paths=[str(p.relative_to(dest)) for p in dest.rglob('*') if p.is_file()]
(v/'engine56-proposal.json').write_text(json.dumps(dict(status='prepared_not_applied',files={p:hashlib.sha256((dest/p).read_bytes()).hexdigest()for p in paths}),indent=2)+'\n')
print('prepared two additional C suites and bounded large-row fixtures')
