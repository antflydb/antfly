from pathlib import Path
import hashlib,json,subprocess,sys,time
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
def freeze():
 for p,h in json.loads((v/'engine52-freeze.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
def archive(paths):
 ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns);ns['archive']('qualification',paths,'logs_manifest.json')
def run(name,cmd):
 print('START',name,flush=True);p=Path('/private/tmp/ocr-'+name+'.txt');assert not p.exists()
 with p.open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 archive([p]);print('DONE',name,r.returncode,flush=True);assert r.returncode==0,(name,r.returncode)
freeze()
run('engine52-resource-qualification-verify2-driver',[sys.executable,str(v/'run_engine52_resource_cases_verify2.py'),'qualification','08','4b'])
freeze()
checks=[o/'engine52_c_qualification_audit.json',o/'engine52_4b_resource_dedup_qualification_audit.json',o/'engine52_08_resource_dedup_qualification_audit.json']
assert all(json.loads(p.read_text())['status']=='pass'for p in checks)
(o/'engine52_full_qualification_audit.json').write_text(json.dumps(dict(status='pass',checks={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in checks},functional_three_pass=True,runtime_files_sha256=json.loads((v/'engine52-freeze.json').read_text())),indent=2)+'\n')
archive(list(Path('/private/tmp').glob('ocr-engine52-*resource_dedup*qualification*.txt')))
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine52_*resource_dedup*qualification*'],check=True)
run('engine52-resource-primary-verify2-driver',[sys.executable,str(v/'run_engine52_resource_cases_verify2.py'),'primary'])
freeze()
archive(list(Path('/private/tmp').glob('ocr-engine52-*resource_dedup*primary*.txt')))
subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),'engine52_*resource_dedup*primary*'],check=True)
print('COMPLETE',flush=True)
