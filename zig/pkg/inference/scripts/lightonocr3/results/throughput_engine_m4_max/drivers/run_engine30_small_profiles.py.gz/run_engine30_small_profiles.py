from pathlib import Path
import os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');base=os.environ.copy();base.update(OCR_REFERENCE_LABEL='_primary_reference7_auto_c32_r128',OCR_REQUESTS='128',OCR_WIDE='1',OCR_SCRATCH_GIB='8',OCR_BACKEND_GIB='16',OCR_SINGLE_FRAME='0',OCR_POLICIES='engineepoch',OCR_BF16='0',OCR_BF16_PREFILL='0',OCR_VISION_BATCH='0',OCR_PREFILL_DECODE_STREAK='0')
# Restore the historical 0.8B cache-off/ordinary-vision baseline, then vary
# stream overlap, CPU/vision grouping, shared core cache, and physical rows.
for c,cpu,vf,cache,stream in [(16,0,1,0,0),(16,0,1,0,8),(16,1,4,0,8),(16,1,4,1,8),(32,1,4,0,8)]:
 env=base.copy();env.update(OCR_CONCURRENCY=str(c),OCR_PHYSICAL32='1'if c==32 else'0',OCR_CPU_PREPROCESS=str(cpu),OCR_VISION_FRAME_BLOCKS=str(vf),OCR_SHARED_CORE=str(cache),OCR_STREAM_FIRST=str(stream));label=f'nohook_c{c}_cpu{cpu}_vision{vf}_cache{cache}_stream{stream}_f32_r128_0';print('START',label,flush=True)
 r=subprocess.run([sys.executable,str(v/'run_engine30_budget_no_prefill_policies.py'),'08:'+label],env=env);print('DONE',label,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
