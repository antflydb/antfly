#include <metal_stdlib>
#include <metal_tensor>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;using namespace mpp::tensor_ops;
struct Params {uint rows,in_dim,out_dim,pad;};
template<bool REUSE,uint M,uint N,uint SG,uint K> inline void candidate_gate(device bfloat*x,device bfloat*gw,device bfloat*uw,device float*gb,device float*ub,device float*y,constant Params&p,uint2 group){
 tensor<device bfloat,dextents<int,2>,tensor_inline>a0(x,dextents<int,2>(K,p.rows),array<int,2>{1,int(p.in_dim)});
 tensor<device bfloat,dextents<int,2>,tensor_inline>g0(gw,dextents<int,2>(K,p.out_dim),array<int,2>{1,int(p.in_dim)});
 tensor<device float,dextents<int,2>,tensor_inline>dest(y,dextents<int,2>(p.out_dim,p.rows),array<int,2>{1,int(p.out_dim)});
 auto left0=a0.slice(0,int(group.y)*M);auto right0=g0.slice(0,int(group.x)*N);auto out=dest.slice(int(group.x)*N,int(group.y)*M);
 constexpr auto desc=matmul2d_descriptor(M,N,K,false,true,false,matmul2d_descriptor::mode::multiply_accumulate);matmul2d<desc,execution_simdgroups<SG>>op;
 auto cached_left=op.template get_left_input_cooperative_tensor<bfloat,bfloat,float>();
 auto g=op.template get_destination_cooperative_tensor<decltype(left0),decltype(right0),float>();auto u=op.template get_destination_cooperative_tensor<decltype(left0),decltype(right0),float>();
 for(ushort i=0;i<g.get_capacity();i++){g[i]=0;u[i]=0;}
 for(uint k=0;k<p.in_dim;k+=K){
  tensor<device bfloat,dextents<int,2>,tensor_inline>a(x+k,dextents<int,2>(K,p.rows),array<int,2>{1,int(p.in_dim)});
  tensor<device bfloat,dextents<int,2>,tensor_inline>gm(gw+k,dextents<int,2>(K,p.out_dim),array<int,2>{1,int(p.in_dim)}),um(uw+k,dextents<int,2>(K,p.out_dim),array<int,2>{1,int(p.in_dim)});
  auto left=a.slice(0,int(group.y)*M);auto rightG=gm.slice(0,int(group.x)*N);auto rightU=um.slice(0,int(group.x)*N);
  if constexpr(REUSE){cached_left.load(left);op.run(cached_left,rightG,g);op.run(cached_left,rightU,u);}else{op.run(left,rightG,g);op.run(left,rightU,u);}
 }
 for(ushort i=0;i<g.get_capacity();i++){auto c=g.get_multidimensional_index(i);int col=int(group.x)*N+c[0],row=int(group.y)*M+c[1];if(c[0]>=0&&c[0]<N&&c[1]>=0&&c[1]<M&&col<int(p.out_dim)&&row<int(p.rows)){float gs=g[i]+gb[col],us=u[i]+ub[col];g[i]=(gs/(1.0f+exp(-gs)))*us;}}
 g.store(out);
}
kernel void candidate0(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<false,32,64,4,64>(x,g,u,gb,ub,y,p,group);}
kernel void candidate1(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<false,32,64,4,128>(x,g,u,gb,ub,y,p,group);}
kernel void candidate2(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<false,32,64,4,256>(x,g,u,gb,ub,y,p,group);}
kernel void candidate3(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<false,32,64,4,512>(x,g,u,gb,ub,y,p,group);}
kernel void candidate4(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<false,64,32,4,64>(x,g,u,gb,ub,y,p,group);}
kernel void candidate5(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<false,64,32,4,128>(x,g,u,gb,ub,y,p,group);}
kernel void candidate6(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<false,64,32,4,256>(x,g,u,gb,ub,y,p,group);}
kernel void candidate7(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<false,64,32,4,512>(x,g,u,gb,ub,y,p,group);}
kernel void candidate8(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<true,32,64,4,64>(x,g,u,gb,ub,y,p,group);}
kernel void candidate9(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<true,32,64,4,128>(x,g,u,gb,ub,y,p,group);}
kernel void candidate10(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<true,32,64,4,256>(x,g,u,gb,ub,y,p,group);}
kernel void candidate11(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<true,32,64,4,512>(x,g,u,gb,ub,y,p,group);}
kernel void candidate12(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<true,64,32,4,64>(x,g,u,gb,ub,y,p,group);}
kernel void candidate13(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<true,64,32,4,128>(x,g,u,gb,ub,y,p,group);}
kernel void candidate14(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<true,64,32,4,256>(x,g,u,gb,ub,y,p,group);}
kernel void candidate15(device bfloat*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]]){candidate_gate<true,64,32,4,512>(x,g,u,gb,ub,y,p,group);}
