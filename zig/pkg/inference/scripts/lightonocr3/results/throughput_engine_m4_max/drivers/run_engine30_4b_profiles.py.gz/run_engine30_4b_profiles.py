from pathlib import Path
import os,subprocess,sys
v=Path('.venv-lighton-vllm-metal');base=os.environ.copy();base.update(OCR_REFERENCE_LABEL='_primary_reference9_loadcheck_auto_c32_r128',OCR_PHYSICAL32='1',OCR_CONCURRENCY='32',OCR_REQUESTS='128',OCR_WIDE='1',OCR_SCRATCH_GIB='10',OCR_BACKEND_GIB='17',OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_PREFILL_WAIT_US='100000',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1',OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_VISION_BATCH='0',OCR_VISION_FRAME_BLOCKS='4')
for single,stream,hook in [(1,0,0),(0,16,0),(0,8,0),(1,0,1)]:
 env=base.copy();env.update(OCR_SINGLE_FRAME=str(single),OCR_STREAM_FIRST=str(stream));label=f'vision4_c32_device17_scratch10_sf{single}_stream{stream}_hook{hook}_f32_r128_0';print('START',label,flush=True)
 driver='run_engine30_budget_policies.py'if hook else'run_engine30_budget_no_prefill_policies.py'
 r=subprocess.run([sys.executable,str(v/driver),'4b:'+label],env=env);print('DONE',label,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
