from pathlib import Path
import subprocess,sys
s=Path('.venv-lighton-vllm-metal/engine5_gpu_tests.py').read_text();exec(s[:s.index('cmd=[str(')])
root=Path.cwd();env['ANTFLY_LIGHTONOCR3_EPOCH_AUX']='1'
env['ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS']='0'
env['ANTFLY_LIGHTONOCR3_BATCH_ATTENTION']='1'
env['ANTFLY_LIGHTONOCR3_EXTENDED_EPOCH']='1'
env['ANTFLY_LIGHTONOCR3_CONTENTION_WAIT_US']='1000'
env['TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS']='1'
env['ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS']='4'
env['ANTFLY_LIGHTONOCR3_SINGLE_FRAME']='0'
env['ANTFLY_LIGHTONOCR3_PHASE_FAIR']='1'
env['ANTFLY_LIGHTONOCR3_PHASE_PARK']='1'
env['ANTFLY_LIGHTONOCR3_EXECUTOR_TAIL']='1'
env['ANTFLY_LIGHTONOCR3_COMPACT_KV']='1'
env['ZIG_GLOBAL_CACHE_DIR']=str(root/'zig/.zig-cache/global')
filters=['LightOnOCR3','Qwen3-VL','batch decode context','execution lane','execution gate','projector residency','executor batch','coalesc','Florence','shared native provider','dynamic linear slot','decode GQA split','argmax','video buffer survives producer destruction','video Metal gather fences']
command=['/Users/ajroetker/bin/zig-0.17.0/zig','build','inference-test','-Doptimize=ReleaseFast','-Dstrip=true',*[f'-Dtest-filter={x}'for x in filters]]
with open('/private/tmp/ocr-engine21-gpu-build.txt','w')as out:r=subprocess.run(command,cwd=root/'zig',env=env,stdout=out,stderr=subprocess.STDOUT)
print('exit',r.returncode)
if r.returncode==0:
 import re
 log=Path('/private/tmp/ocr-engine21-gpu-build.txt').read_text()
 matches=re.findall(r'attention_batch_calls=(\d+) attention_batch_rows=(\d+)',log)
 kernels=re.findall(r'attention_batch_kernel_calls=(\d+)',log)
 assert matches and any(int(x)>0 and int(y)>=2*int(x) for x,y in matches),matches
 assert kernels and any(int(x)>0 for x in kernels),kernels
 print('qualified production batch attention counters',matches,kernels)
 pack=re.findall(r'prefill_pack_calls=(\d+) prefill_pack_reuse_hits=(\d+)',log)
 assert pack and any(int(x)>0 for x,y in pack),pack
 print('qualified prefill pack acquisitions and hits',pack)
sys.exit(r.returncode)
