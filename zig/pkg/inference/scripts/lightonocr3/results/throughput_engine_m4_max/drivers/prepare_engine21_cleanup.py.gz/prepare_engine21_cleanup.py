from pathlib import Path
p=Path('zig/pkg/inference/src/execution_control.zig');s=p.read_text();needle='''    pub fn acquireWithPriority(self: *ExecutionLane, control: InferenceExecutionControl, interactive: bool) !Lease {
        try control.check();''';replacement='''    pub fn acquireWithPriority(self: *ExecutionLane, control: InferenceExecutionControl, interactive: bool) !Lease {
        return self.acquireInternal(control, interactive, true);
    }

    /// Cleanup retains borrowed native state even when its owning Io task is
    /// already cancelled. Owner release still wakes this waiter immediately.
    pub fn acquireForCleanup(self: *ExecutionLane, io: ?std.Io, interactive: bool) Lease {
        return self.acquireInternal(.{ .io = io }, interactive, false) catch unreachable;
    }

    fn acquireInternal(self: *ExecutionLane, control: InferenceExecutionControl, interactive: bool, comptime cancelable: bool) !Lease {
        if (cancelable) try control.check();''';assert needle in s;s=s.replace(needle,replacement,1)
a=s.index('    fn acquireInternal(');b=s.index('\n};',a);chunk=s[a:b].replace('            try control.check();','            if (cancelable) try control.check();',1)
needle='''            if (control.io) |io| {
                // Release signals''';replacement='''            if (control.io) |io| {
                if (!cancelable) {
                    waiter.ready.waitUncancelable(io);
                    continue;
                }
                // Release signals''';assert needle in chunk;chunk=chunk.replace(needle,replacement,1);s=s[:a]+chunk+s[b:];p.write_text(s)
p=Path('zig/pkg/inference/src/pipelines/generation.zig');s=p.read_text().replace('_ = lane.acquireWithPriority(.{ .io = self.io }, waiters != null) catch unreachable;','_ = lane.acquireForCleanup(self.io, waiters != null);');s=s.replace('            if (scheduler.usesStepEvents()) {\n                self.lockExecution(mutex)', '            if (scheduler.usesStepEvents() or self.execution_gate != null) {\n                self.lockExecution(mutex)',1);p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text().replace('_ = ctx.step_gate.acquireWithPriority(.{ .io = if (ctx.worker_io) |*owner| owner.io() else null }, true) catch unreachable;','_ = ctx.step_gate.acquireForCleanup(if (ctx.worker_io) |*owner| owner.io() else null, true);');p.write_text(s)
