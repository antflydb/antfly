from pathlib import Path
p=Path('zig/pkg/inference/src/pipelines/generation.zig');s=p.read_text();s=s.replace('    execution_phase_waiters: ?*std.atomic.Value(usize) = null,','''    execution_phase_waiters: ?*std.atomic.Value(usize) = null,
    execution_phase_wake: ?*std.Io.Event = null,
    execution_phase_wake_io: ?std.Io = null,''',1)
needle='''            _ = count.fetchSub(1, .acq_rel);
        };''';replacement='''            self.finishExecutionPhaseWait(count);
        };'''
a=s.index('    fn lockExecution(');b=s.index('    fn shouldStopOnEos(',a);chunk=s[a:b];assert chunk.count(needle)==2;chunk=chunk.replace(needle,replacement)
chunk='''    fn finishExecutionPhaseWait(self: *const NativeGenerationPipeline, count: *std.atomic.Value(usize)) void {
        if (count.fetchSub(1, .acq_rel) == 1) if (self.execution_phase_wake) |event| {
            if (self.execution_phase_wake_io) |io| event.set(io);
        };
    }

'''+chunk
s=s[:a]+chunk+s[b:]
# Both partial fixtures initialize the optional notification carrier.
s=s.replace('    pipeline.execution_gate = null;','    pipeline.execution_gate = null;\n    pipeline.execution_phase_wake = null;\n    pipeline.execution_phase_wake_io = null;')
s=s.replace('    pipeline.execution_gate = &gate;','    pipeline.execution_gate = &gate;\n    pipeline.execution_phase_wake = null;\n    pipeline.execution_phase_wake_io = null;')
# Strengthen the existing phase cancellation test: the worker observes the
# transition to zero for both failed acquisition and uncancellable cleanup.
a=s.index('test "LightOnOCR3 phase priority releases');b=s.index('\ntest ',a+8);chunk=s[a:b]
chunk=chunk.replace('    var pipeline: NativeGenerationPipeline = undefined;','    var wake: std.Io.Event = .unset;\n    var pipeline: NativeGenerationPipeline = undefined;')
chunk=chunk.replace('pipeline.execution_phase_wake = null;','pipeline.execution_phase_wake = &wake;').replace('pipeline.execution_phase_wake_io = null;','pipeline.execution_phase_wake_io = std.testing.io;')
chunk=chunk.replace('        if (busy) try std.testing.expect(mutex.tryLock());','        wake.reset();\n        if (busy) try std.testing.expect(mutex.tryLock());')
chunk=chunk.replace('        try std.testing.expectEqual(@as(usize, 0), waiters.load(.acquire));','        try std.testing.expectEqual(@as(usize, 0), waiters.load(.acquire));\n        try std.testing.expect(wake.isSet());')
chunk=chunk.replace('    pipeline.lockExecutionForCleanup(&mutex);','    wake.reset();\n    pipeline.lockExecutionForCleanup(&mutex);\n    try std.testing.expect(wake.isSet());')
s=s[:a]+chunk+s[b:];p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text();a=s.index('        fn lockStep(ctx: *LightOnStreamContext,');b=s.index('        fn unlockStep(',a);chunk=s[a:b].replace('_ = ctx.phase_waiters.fetchSub(1, .acq_rel);','ctx.finishPhaseWait();')
chunk='''        fn finishPhaseWait(ctx: *LightOnStreamContext) void {
            if (ctx.phase_waiters.fetchSub(1, .acq_rel) == 1) if (ctx.worker_io) |*owner| {
                ctx.worker_wake.set(owner.io());
            };
        }
'''+chunk;s=s[:a]+chunk+s[b:]
needle='''                if (ctx.phase_fair and !ctx.gate_events and ctx.phase_waiters.load(.acquire) != 0) {
                    ctx.phase_priority_yields += 1;'''
replacement='''                // Reset before observing phase/queue predicates. A phase
                // releasing its last waiter always signals this same event.
                ctx.worker_wake.reset();
                if (ctx.phase_fair and ctx.phase_waiters.load(.acquire) != 0) {
                    ctx.phase_priority_yields += 1;
                    if (ctx.gate_events) {
                        if (!ctx.worker_stop.load(.acquire)) ctx.worker_wake.waitTimeout(io, .{ .duration = .{ .raw = .fromMilliseconds(10), .clock = .awake } }) catch {};
                        continue;
                    }'''
assert needle in s;s=s.replace(needle,replacement,1)
needle='''                // Reset only after the previous wait returned, then inspect
                // the queue. An enqueue on either side cannot lose its wake.
                ctx.worker_wake.reset();''';assert needle in s;s=s.replace(needle,'                // Both predicates have now been observed after the reset.',1)
needle='''            .execution_phase_waiters = if (ctx.phase_fair) &ctx.phase_waiters else null,'''
replacement=needle+'''
            .execution_phase_wake = if (ctx.gate_events and ctx.worker != null) &ctx.worker_wake else null,
            .execution_phase_wake_io = if (ctx.gate_events) if (ctx.worker_io) |*owner| owner.io() else null else null,'''
assert needle in s;s=s.replace(needle,replacement,1);p.write_text(s)
