from pathlib import Path
v=Path('.venv-lighton-vllm-metal');s=(v/'run_engine13_policies.py').read_text().replace('engine13','engine14')
s=s.replace("shared=os.environ.get('OCR_SHARED_CORE','1')=='1';","stream=int(os.environ.get('OCR_STREAM_FIRST','4'));env['ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS']=str(stream);shared=os.environ.get('OCR_SHARED_CORE','1')=='1';")
s=s.replace("report['shared_core_weights']=shared;","report['stream_first_layers']=stream;report['shared_core_weights']=shared;")
a="frame_stats=re.findall(r'single_frame_steps=";i=s.index(a);s=s[:i]+"stream_stats=re.findall(r'stream_forward_splits=(\\d+) stream_first_layers=(\\d+)',section);sample['stream_forward_splits']=sum(int(x)for x,_ in stream_stats);assert stream_stats and (sample['stream_forward_splits']>0)==(stream>0),sample\n    "+s[i:]
s=s.replace("'shared_core_weight_hits','shared_core_weight_misses'","'stream_forward_splits','shared_core_weight_hits','shared_core_weight_misses'")
(v/'run_engine14_policies.py').write_text(s)
(v/'engine14_benchmark_concurrency.py').write_bytes(Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
s=(v/'engine13_default_gpu_test.py').read_text().replace('engine13','engine14').replace("'ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS',","'ANTFLY_LIGHTONOCR3_STREAM_FIRST_LAYERS','ANTFLY_LIGHTONOCR3_SHARED_CORE_WEIGHTS',");(v/'engine14_default_gpu_test.py').write_text(s)
