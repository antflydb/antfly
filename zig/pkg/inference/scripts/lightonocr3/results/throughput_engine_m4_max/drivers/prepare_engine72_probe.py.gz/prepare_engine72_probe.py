from pathlib import Path
import ast,hashlib,json,re
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';src=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=src.read_text();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
m=re.search(r'static NSString \*termite_metal_lightonocr3_recurrent_source\(void\)\s*\{',s);assert m;e=s.index('\n}',m.end())+2;ms=''.join(ast.literal_eval(x.removeprefix('@'))for x in re.findall(r'@?"(?:\\.|[^"\\])*"',s[m.end():e]))
a=ms.index('kernel void termite_lightonocr3_recurrent_parallel(');brace=ms.index('{',a);depth=1;b=brace+1
while depth:
 if ms[b]=='{':depth+=1
 elif ms[b]=='}':depth-=1
 b+=1
base=ms[a:b];cut=base.index('    uint col = simd * TM;');head=base[:cut].replace('    const uint TM = 8, SG = 128 / TM;\n','')
shaders={}
for width in [4,2]:
 vec=f'float{width}';name=f'engine72_recurrent_value_lanes{width}';prefix=head.replace('termite_lightonocr3_recurrent_parallel',name);vals=', '.join('values[col'+(f' + {j}'if j else'')+']'for j in range(width));reduce='    partial += simd_shuffle_xor(partial, 1);\n'
 if width==2:reduce+='    partial += simd_shuffle_xor(partial, 2);\n'
 normwrite='if (key_lane == 0 && (uint(lane) & 1) == 0) reduction[uint(simd) * 2 + ((uint(lane) & 3) >> 1)] = partial;'if width==4 else'if (lane == 0) reduction[simd] = partial;'
 tail=f'''    // Four value-vector lanes and eight key lanes share a SIMD group.
    // Canonical F32 state is unchanged; key reductions use SIMD shuffles.
    uint key_lane = uint(lane) >> 2;
    uint col = uint(simd) * {4*width} + (uint(lane) & 3) * {width};
    {vec} previous[16], memory = 0;
#pragma unroll
    for (uint i = 0; i < 16; ++i) {{
        uint key = i * 8 + key_lane;
        {vec} value = p.initialized ? *((device const {vec} *)(state + h * 128 * 128 + key * 128 + col)) : {vec}(0);
        previous[i] = value * scales[2];
        memory += previous[i] * k[key];
    }}
    memory += simd_shuffle_xor(memory, 4);
    memory += simd_shuffle_xor(memory, 8);
    memory += simd_shuffle_xor(memory, 16);
    {vec} delta = ({vec}({vals}) - memory) * scales[3];
    {vec} result = 0;
#pragma unroll
    for (uint i = 0; i < 16; ++i) {{
        uint key = i * 8 + key_lane;
        {vec} value = previous[i] + k[key] * delta;
        *((device {vec} *)(state + h * 128 * 128 + key * 128 + col)) = value;
        result += value * q[key];
    }}
    result += simd_shuffle_xor(result, 4);
    result += simd_shuffle_xor(result, 8);
    result += simd_shuffle_xor(result, 16);
    if (key_lane == 0) *((device {vec} *)(core + h * 128 + col)) = result;
    float partial = dot(result, result);
{reduce}    {normwrite}
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (d == 0) {{
        float sum = 0;
        for (uint i = 0; i < 16; ++i) sum += reduction[i];
        scales[0] = 1.0f / sqrt(sum / 128.0f + 1e-6f);
    }}
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (key_lane == 0) {{
        {vec} gate = *((device const {vec} *)(z + h * 128 + col));
        {vec} n = *((device const {vec} *)(norm + col));
        *((device {vec} *)(output + h * 128 + col)) = result * scales[0] * n * (gate / (1.0f + exp(-gate)));
    }}
}}
'''
 text='// Unqualified isolated proposal. Exact group size: '+str(1024//width)+' threads.\n'+ms[:a]+prefix+tail;path=v/f'engine72_recurrent_value_lanes{width}.metal';path.write_text(text);shaders[name]=dict(path=str(path.relative_to(r)),sha256=sha(path),threads=1024//width)
# Patch only the isolated copy's parallel-core dispatch width; production stays frozen.
c=s;m=re.search(r'static int termite_metal_lightonocr3_encode_recurrent_parallel\([^;]*?\)\s*\{',c,re.S);assert m;end=c.index('\n}',m.end())+2;part=c[m.start():end];assert part.count('pipeline.maxTotalThreadsPerThreadgroup < 512')==1 and part.count('MTLSizeMake(512, 1, 1)')==1
part=part.replace('pipeline.maxTotalThreadsPerThreadgroup < 512','pipeline.maxTotalThreadsPerThreadgroup < engine72_threads').replace('MTLSizeMake(512, 1, 1)','MTLSizeMake(engine72_threads, 1, 1)');c=c[:m.start()]+'static NSUInteger engine72_threads = 512;\n'+part+c[end:];(v/'engine72_probe_kernels.m').write_text(c)
p=r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m';c=p.read_text();anchor='"../../src/backends/metal_kernels.m"';assert c.count(anchor)==1;c=c.replace(anchor,'"engine72_probe_kernels.m"');(v/'engine72_probe_checks.m').write_text(c)
# Adapt the already qualified 24-layer ABBA/state-check harness to new sources.
c=(v/'engine50_recurrent_probe_verify3.m').read_text().replace('engine50','engine72').replace('LAYERS50','LAYERS72').replace('PAGES50','PAGES72').replace('Working50','Working72').replace('select50','select72').replace('fill50','fill72').replace('frame50','frame72').replace('working50','working72').replace('writes50','writes72')
c=c.replace('engine72_recurrent_checks.m','engine72_probe_checks.m').replace('engine72_recurrent_sources.inc','engine72_recurrent_sources.inc')
c=c.replace('mode==0?512:mode==2?256:128','mode==1?256:512').replace('candidate<=3','candidate<=2').replace('psos[4]','psos[3]').replace('i<=3','i<=2')
c=c.replace('[NSString stringWithFormat:@"engine72_recurrent_v%d",i]','i == 1 ? @"engine72_recurrent_value_lanes4" : @"engine72_recurrent_value_lanes2"')
c=c.replace('opt.mathMode=MTLMathModeSafe;','opt.languageVersion=MTLLanguageVersion3_1;opt.fastMathEnabled=NO;opt.mathMode=MTLMathModeSafe;')
c=c.replace('const size_t pages[]={33};','const char *requested = getenv("ENGINE72_PAGES"); const size_t pages[]={requested ? (size_t)strtoul(requested,NULL,10) : 0};')
c=c.replace('for(int i=0;i<1;i++){int rc=working72(r,psos,pages[i]);if(rc)return rc;}','for(int i=0;i<1;i++){if(!pages[i])continue;if(pages[i]!=33 && pages[i]!=48 && pages[i]!=64)return 90;int rc=working72(r,psos,pages[i]);if(rc)return rc;}')
(v/'engine72_recurrent_probe.m').write_text(c)
strings=[]
for width in [4,2]:
 text=(v/f'engine72_recurrent_value_lanes{width}.metal').read_text();strings.append('@'+json.dumps(text))
(v/'engine72_recurrent_sources.inc').write_text('static NSString *engine72_sources[2] = {\n'+',\n'.join(strings)+'\n};\n')
inputs=[v/'engine72_probe_kernels.m',v/'engine72_probe_checks.m',v/'engine72_recurrent_probe.m',v/'engine72_recurrent_sources.inc',*[v/f'engine72_recurrent_value_lanes{w}.metal'for w in [4,2]]]
plan=dict(status='prepared_not_compiled_or_executed',production_modified=False,production_c_sha256=sha(src),production_checker_sha256=sha(p),inputs={str(p.relative_to(r)):sha(p)for p in inputs},shaders=shaders,scope='Two-dimensional key/value SIMD mapping uses within-SIMD shuffles, unlike engine50 full-value lanes and threadgroup partial tables. Same canonical F32 state, same epsilon and safe math; reduction trees can differ.',requirements='Wait for engine71 primary/follow60 jobs to finish. Run conformance before 24-layer ABBA working sets; all outputs/states/canaries checked. Require actual available memory for working+gold buffers plus unchanged six-GiB OS reserve. No production or throughput claim until validated.')
(v/'engine72_recurrent_probe_preparation.json').write_text(json.dumps(plan,indent=2)+'\n');print('prepared isolated 256/512-thread shuffle probes and copied current conformance harness; no compilation/GPU/production edits')
