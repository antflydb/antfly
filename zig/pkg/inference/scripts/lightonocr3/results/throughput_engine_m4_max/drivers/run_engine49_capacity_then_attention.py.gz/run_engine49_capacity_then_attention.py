from pathlib import Path
import hashlib,json,subprocess,sys,time
v=Path('.venv-lighton-vllm-metal');out=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max')
def freeze():
 for p,h in json.loads((v/'engine48-freeze.json').read_text()).items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
def archive(paths):
 ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns);ns['archive']('qualification',paths,'logs_manifest.json')
def run(label,script):
 print('START',label,flush=True)
 log=Path('/private/tmp/ocr-'+label+'.txt');assert not log.exists()
 with log.open('w')as f:r=subprocess.run([sys.executable,str(v/script)],stdout=f,stderr=subprocess.STDOUT)
 archive([log]);print('DONE',label,r.returncode,flush=True);assert r.returncode==0,(label,r.returncode)
def compress(patterns):subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),*patterns],check=True)
p=out/'paired28_4b_comparison_audit.json'
print('WAIT paired28',flush=True)
while not p.exists()or json.loads(p.read_text())['status']=='running':time.sleep(5)
d=json.loads(p.read_text());assert len(d['comparisons'])==2 and all(x['primary_throughput_eligible']for x in d['comparisons'])
while 'FINAL 'not in Path('/private/tmp/ocr-engine48-paired28-driver.txt').read_text():time.sleep(1)
freeze();archive(list(Path('/private/tmp').glob('ocr-engine48-*paired28*.txt')))
compress(['engine48_4b_paired28*','vllm_4b_primary_reference28*'])
run('engine48-capacity-profiles-driver','run_engine48_capacity_profiles.py')
freeze();archive(list(Path('/private/tmp').glob('ocr-engine48-4b-capacity*.txt')));compress(['engine48_4b_capacity*'])
run('engine49-attention-probe-build-driver','build_engine49_attention_probe_verify3.py')
run('engine49-attention-probe-gpu-driver','run_engine49_attention_probe_verify3.py')
freeze();archive([Path('/private/tmp/ocr-engine49-attention-probe-build.txt')])
print('COMPLETE',flush=True)
