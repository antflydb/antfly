from pathlib import Path
import subprocess,sys
v=Path('.venv-lighton-vllm-metal')
for script,log in [('run_engine108_wide_core_suppressed.py','/private/tmp/ocr-engine108-wide-parent.txt'),('run_engine102_mixed_stream_screen88.py','/private/tmp/ocr-engine102-stream88-parent.txt')]:
 assert not Path(log).exists();print('START',script,flush=True)
 with Path(log).open('w')as out:p=subprocess.run([sys.executable,str(v/script)],stdout=out,stderr=subprocess.STDOUT)
 print('DONE',script,p.returncode,flush=True)
