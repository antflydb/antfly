from pathlib import Path
import hashlib,json,subprocess
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
f=json.loads((v/'engine79-freeze.json').read_text());assert all(sha(r/p)==h for p,h in f.items())
p=r/'zig/pkg/inference/src/architectures/gpt.zig';s=p.read_text();old='''            if (total >= 1 and (total <= 8 or
                (isDecodeStep(decode_context) and total <= 64 and
                    (hidden_size != 2560 or total < 64 or platform.env.getenvBool("TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP")))) and
''';new='''            // Long-prompt FFNs also reach the backend's optional packed-prefill
            // selector. The backend owns feature flags and frame/capability guards.
            const packed_prefill_candidate = !isDecodeStep(decode_context) and
                total >= 128 and total <= 1024 and hidden_size == 2560;
            if (total >= 1 and (packed_prefill_candidate or total <= 8 or
                (isDecodeStep(decode_context) and total <= 64 and
                    (hidden_size != 2560 or total < 64 or platform.env.getenvBool("TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP")))) and
''';assert s.count(old)==1;p.write_text(s.replace(old,new))
subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt',str(p)],check=True)
subprocess.run(['/Users/ajroetker/.local/bin/ruff','format',str(r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py')],check=True)
f={p:sha(r/p)for p in f};(v/'engine80-freeze.json').write_text(json.dumps(f,indent=2)+'\n')
for old,new in [('run_engine79_verify_gpu_build.py','run_engine80_verify_gpu_build.py'),('run_engine79_metal_disabled.py','run_engine80_metal_disabled.py'),('run_engine79_budget_policies.py','run_engine80_budget_policies.py'),('run_engine79_api_paired66.py','run_engine80_api_paired66.py'),('run_engine79_08_paired67.py','run_engine80_08_paired67.py'),('run_engine79_florence_paired67.py','run_engine80_florence_paired67.py')]:
 s=(v/old).read_text().replace('engine79','engine80').replace('ENGINE79','ENGINE80')
 if new=='run_engine80_api_paired66.py':s=s.replace('record = dict(', "subprocess.run([sys.executable,str(v/'run_engine80_ffn_screen68.py')],check=True)\n\nrecord = dict(",1)
 (v/new).write_text(s)
(v/'engine80_benchmark_concurrency.py').write_bytes((r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
print('ENGINE80 DISPATCH FIX PREPARED',flush=True)
