from pathlib import Path
import json,hashlib,subprocess
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();old=json.loads((v/'engine67-freeze.json').read_text())
assert 'DONE metal-disabled 0' in Path('/private/tmp/ocr-engine67-qualification-parent.txt').read_text() and 'DONE finalize 0' in Path('/private/tmp/ocr-engine67-qualification-parent.txt').read_text()
for p,h in old.items():assert sha(root/p)==h,p
changes={}
def edit(path,a,b):
 p=root/path;s=changes.get(p,p.read_text())
 if path.endswith('check_metal_projections.m'):
  lo=s.index('static int prefill_pack_reuse_check(');hi=s.index('static int decode_pack_reuse_check(',lo)
  prefix,body,suffix=s[:lo],s[lo:hi],s[hi:]
  assert body.count(a)==1,(path,a[:100],body.count(a));changes[p]=prefix+body.replace(a,b)+suffix
 else:
  assert s.count(a)==1,(path,a[:100],s.count(a));changes[p]=s.replace(a,b)
c='zig/pkg/inference/src/backends/metal_kernels.m';m='zig/pkg/inference/src/ops/metal_compute.zig';r='zig/pkg/inference/src/backends/metal_runtime.zig';n='zig/pkg/inference/src/server/server.zig';t='zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m'
edit(c,'    uint64_t lighton_prefill_pack_calls;','    bool lighton_prefill_stream_pack_reuse;\n    uint64_t lighton_prefill_pack_calls;')
edit(c,'''    // The packed input has exactly one consumer. Recycle only after that
    // projection, in a serial frame with no submitted prefix. Explicit BF16
    // decode uses the same lifetime; F32 decoder inputs remain unchanged.''','''    // The packed input has exactly one consumer. Recycle only after its
    // projection in this serial frame. Admitted prompt streaming also permits
    // a submitted prefix: submit_frame drains its pool into retained resources,
    // so this active group starts with independent packing storage. No private
    // pack is rewritten by the host or borrowed across the two frame pools.
    // All other callers keep the existing no-submitted-prefix gate.''')
edit(c,'''        runtime->active_frame_cb == cb && runtime->submitted_frame_cb == nil &&
        !termite_metal_concurrent_planned_dispatch_enabled(runtime);''','''        runtime->active_frame_cb == cb &&
        (runtime->submitted_frame_cb == nil ||
         (prefill_pack_scope && runtime->lighton_prefill_stream_pack_reuse)) &&
        !termite_metal_concurrent_planned_dispatch_enabled(runtime);''')
edit(c,'int antfly_metal_lighton_read_tokens(termite_metal_decode_runtime *r, uint32_t *out, size_t rows) {','''// Configure only between complete forwards. This is never a permission to
// reuse a submitted prefix's buffers: those remain frame-retained until drain.
int antfly_metal_lighton_prefill_pack_streaming(termite_metal_decode_runtime *r, int enabled) {
    if (!r || r->active_frame_cb || r->submitted_frame_cb) return -1;
    if (enabled && (!r->lightonocr3_projections_enabled ||
        termite_metal_concurrent_planned_dispatch_enabled(r))) return -2;
    r->lighton_prefill_stream_pack_reuse = enabled != 0;
    return 0;
}

int antfly_metal_lighton_read_tokens(termite_metal_decode_runtime *r, uint32_t *out, size_t rows) {''')
edit(r,'pub extern fn antfly_metal_lighton_read_tokens(runtime: ?*RawMetalDecodeRuntime, output: [*]u32, rows: usize) c_int;','pub extern fn antfly_metal_lighton_read_tokens(runtime: ?*RawMetalDecodeRuntime, output: [*]u32, rows: usize) c_int;\npub extern fn antfly_metal_lighton_prefill_pack_streaming(runtime: ?*RawMetalDecodeRuntime, enabled: c_int) c_int;')
edit(m,'''        self.lighton_prefill_stream_layers = layers;
    }

    pub fn lightOnPrefillStreamLayers''','''        if ((layers != 0 or self.lighton_prefill_stream_layers != 0) and
            metal_runtime_mod.antfly_metal_lighton_prefill_pack_streaming(self.provider_impl.raw_decode_runtime, @intFromBool(layers != 0)) != 0)
            return error.UnsupportedPrefillStream;
        self.lighton_prefill_stream_layers = layers;
    }

    pub fn lightOnPrefillStreamLayers''')
edit(n,'''                    features.prefill_batch_items == 1 and
                    !platform.env.getenvBool("TERMITE_METAL_DISABLE_PIPELINED_DECODE_FRAME"))''','''                    features.prefill_batch_items == 1 and
                    !platform.env.getenvBool("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PACK_REUSE") and
                    !platform.env.getenvBool("TERMITE_METAL_ENABLE_CONCURRENT_PLANNED_DISPATCH") and
                    !platform.env.getenvBool("TERMITE_METAL_DISABLE_PIPELINED_DECODE_FRAME"))''')
# Preserve the existing pending-prefix fallback mode and add a separate opt-in
# prefix containing a real BF16 projection, with guarded independent outputs.
edit(t,'modes = benchmark ? 2 : 5;','modes = benchmark ? 2 : 6;')
edit(t,'id<MTLBuffer> results[5][6] = {{nil}};','id<MTLBuffer> results[6][6] = {{nil}};\n  id<MTLBuffer> prefix_result = [r->device newBufferWithLength:(outputs + 8) * 4 options:MTLResourceStorageModeShared];\n  if (!prefix_result) return 1;')
edit(t,'''      const int old_reuse = r->buffer_reuse_enabled;
      if (mode == 2)''','''      if (antfly_metal_lighton_prefill_pack_streaming(r, mode == 5)) return 15;
      if (mode == 5) {
        uint32_t *ys = prefix_result.contents;
        for (size_t j = 0; j < outputs + 8; j++) ys[j] = 0xdeadbeef;
      }
      const int old_reuse = r->buffer_reuse_enabled;
      if (mode == 2)''')
edit(t,'''        if (mode == 4) {
          if (termite_metal_decode_runtime_apply_add_device(''','''        if (mode == 4 || mode == 5) {
          if (termite_metal_decode_runtime_apply_add_device(''')
edit(t,'''          termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(
              r);
          if (termite_metal_decode_runtime_submit_frame(r) ||
              termite_metal_decode_runtime_begin_frame(r) ||
              termite_metal_decode_runtime_set_active_frame_regime(
                  r, TERMITE_METAL_FRAME_REGIME_PREFILL))
            return 5;''','''          termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
          if (mode == 5) {
            if (termite_metal_try_lightonocr3_mpp(r, 0, input, 0, rows, in, out, prefix_result, 16) != 1) return 16;
            if (antfly_metal_lighton_prefill_pack_streaming(r, 0) == 0 || !r->lighton_prefill_stream_pack_reuse) return 17;
          }
          if (termite_metal_decode_runtime_submit_frame(r) ||
              termite_metal_decode_runtime_begin_frame(r) ||
              termite_metal_decode_runtime_set_active_frame_regime(
                  r, TERMITE_METAL_FRAME_REGIME_PREFILL))
            return 5;
          if (mode == 5 && (antfly_metal_lighton_prefill_pack_streaming(r, 0) == 0 || !r->lighton_prefill_stream_pack_reuse)) return 17;''')
edit(t,'if (mode == 4 && termite_metal_decode_runtime_wait_frame(r))','if ((mode == 4 || mode == 5) && termite_metal_decode_runtime_wait_frame(r))')
edit(t,'''      if (((mode == 1 || mode == 2) && rows <= 4096) ? call_delta != steps
                                                     : call_delta != 0)
        return 10;
      if ((mode == 1 && rows <= 4096) ? hit_delta < steps - 1 : hit_delta != 0)
        return 11;''','''      const size_t expected_calls = rows <= 4096 && (mode == 1 || mode == 2 || mode == 5) ? steps + (mode == 5) : 0;
      if (call_delta != expected_calls) return 10;
      if (((mode == 1 || mode == 5) && rows <= 4096) ? hit_delta < steps - 1 : hit_delta != 0) return 11;
      if (mode == 5) {
        const uint32_t *ys = prefix_result.contents;
        for (size_t j = 0; j < 4; j++) if (ys[j] != 0xdeadbeef || ys[outputs + 4 + j] != 0xdeadbeef) return 18;
        if (memcmp((float *)prefix_result.contents + 4, (float *)results[0][0].contents + 4, outputs * 4)) return 19;
      }
      if (antfly_metal_lighton_prefill_pack_streaming(r, 0)) return 20;''')
# Prefix cancellation while the next active group borrows its own reused pack.
# Both the committed result and the unsubmitted output canaries are checked.
anchor='''  unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PACK_REUSE");
  unsetenv("TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS");
  fprintf(
      stderr,
      "prefill_pack_reuse rows='''
repl='''  if (!benchmark) {
    if (antfly_metal_lighton_prefill_pack_streaming(r, 1) || termite_metal_decode_runtime_begin_frame(r) ||
        termite_metal_decode_runtime_set_active_frame_regime(r, TERMITE_METAL_FRAME_REGIME_PREFILL)) return 21;
    if (termite_metal_decode_runtime_apply_add_device(r, (__bridge void *)source, 0, (__bridge void *)zero, 0, count, (__bridge void *)input, 0)) return 22;
    if (termite_metal_try_lightonocr3_mpp(r, 0, input, 0, rows, in, out, prefix_result, 16) != 1 ||
        termite_metal_decode_runtime_submit_frame(r) || termite_metal_decode_runtime_begin_frame(r) ||
        termite_metal_decode_runtime_set_active_frame_regime(r, TERMITE_METAL_FRAME_REGIME_PREFILL)) return 23;
    uint32_t *cancelled = results[5][0].contents;
    for (size_t j = 0; j < outputs + 8; j++) cancelled[j] = 0xdeadbeef;
    for (size_t step = 0; step < steps; step++) {
      if (termite_metal_try_lightonocr3_mpp(r, 0, input, 0, rows, in, out, results[5][0], 16) != 1) return 24;
    }
    if (termite_metal_decode_runtime_cancel_frame(r) || termite_metal_decode_runtime_wait_frame(r)) return 25;
    for (size_t j = 0; j < outputs + 8; j++) if (cancelled[j] != 0xdeadbeef) return 26;
    if (memcmp((float *)prefix_result.contents + 4, (float *)results[0][0].contents + 4, outputs * 4)) return 27;
    if (antfly_metal_lighton_prefill_pack_streaming(r, 0)) return 28;
  }
  unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PACK_REUSE");
  unsetenv("TERMITE_METAL_LIGHTONOCR3_BF16_PREFILL_INPUTS");
  fprintf(
      stderr,
      "prefill_pack_reuse rows='''
edit(t,anchor,repl)
for path,s in changes.items():
 (v/('engine67-before68-'+path.name)).write_bytes(path.read_bytes());path.write_text(s)
subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt',*[str(p)for p in changes if p.suffix=='.zig']],check=True)
(v/'engine68-freeze.json').write_text(json.dumps({p:sha(root/p)for p in old},indent=2)+'\n')
print('engine68 admitted prefill pack lifetime applied and frozen')
