from pathlib import Path
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text().replace('ANTFLY_BUFFER_UNINITIALIZED);','ANTFLY_BUFFER_OWNED);');p.write_text(s)
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text().replace('max_q_rows == 1 and !is_mixed and resident_output != null and !has_attention_sink and','max_q_rows == 1 and resident_output != null and !has_attention_sink and');s=s.replace('''            const collect_attention = self.lighton_batch_attention''','''            const all_decode = for (kv_batch) |view| {
                if ((view.per_item_query_len orelse max_q_rows) != 1 or
                    (view.per_item_mode orelse attention.mode) != .paged_decode) break false;
            } else true;
            const collect_attention = all_decode and self.lighton_batch_attention''',1);p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text();i=s.index('int main(')
code=r'''
// Compare one concurrent encoder against canonical per-page attention and a
// double-precision CPU softmax. Query production occurs on the GPU in the same
// planned frame. Pages have distinct logical lengths and permuted block tables.
static int ocr_attention_batch_check(termite_metal_decode_runtime *r, size_t rows, size_t heads, bool benchmark) {
    const size_t dim=256, kv_heads=heads/4, physical=768, page=128, width=heads*dim;
    id<MTLBuffer> source=[r->device newBufferWithLength:rows*width*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> zero=[r->device newBufferWithLength:rows*width*4 options:MTLResourceStorageModeShared];
    id<MTLBuffer> q=[r->device newBufferWithLength:rows*width*4 options:MTLResourceStorageModePrivate];
    id<MTLBuffer> k=[r->device newBufferWithLength:physical*kv_heads*dim*2 options:MTLResourceStorageModeShared];
    id<MTLBuffer> v=[r->device newBufferWithLength:k.length options:MTLResourceStorageModeShared];
    id<MTLBuffer> result[2];
    for(size_t m=0;m<2;m++)result[m]=[r->device newBufferWithLength:(rows*width+8)*4 options:MTLResourceStorageModeShared];
    if(!source||!zero||!q||!k||!v||!result[0]||!result[1])return 1;
    memset(zero.contents,0,zero.length);
    float *qs=source.contents; __fp16 *ks=k.contents,*vs=v.contents;
    for(size_t j=0;j<rows*width;j++)qs[j]=sinf((float)(j%1049)*.31f)*.6f;
    for(size_t j=0;j<physical*kv_heads*dim;j++){ks[j]=cosf((float)(j%997)*.17f)*.5f;vs[j]=sinf((float)(j%991)*.29f)*.8f;}
    r->attention_span_encoded_key_buffers[0]=k;r->attention_span_v_buffers[0]=v;
    r->attention_span_slot_key_row_bytes[0]=kv_heads*dim*2;
    r->attention_span_slot_v_row_stride[0]=kv_heads*dim;
    uint32_t blocks[6]={640,384,128,512,256,0};
    double elapsed[2]={0};
    const size_t trials=benchmark?16:1;
    for(size_t trial=0;trial<trials;trial++)for(size_t m=0;m<2;m++){
        const size_t mode=(trial&1)?1-m:m;
        uint32_t *out=result[mode].contents;
        for(size_t j=0;j<rows*width+8;j++)out[j]=0xdeadbeef;
        if(termite_metal_decode_runtime_begin_frame(r)||
            termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_ATTENTION,TERMITE_METAL_COMPUTE_REGION_ATTENTION)||
            termite_metal_decode_runtime_apply_add_device(r,(__bridge void*)source,0,(__bridge void*)zero,0,rows*width,(__bridge void*)q,0))return 2;
        if(mode&&termite_metal_decode_runtime_lighton_attention_batch_begin(r))return 3;
        for(size_t row=0;row<rows;row++){
            const size_t tokens=432+row*13;
            if(termite_metal_decode_runtime_encode_paged_attention_slot_ex(r,r,r->active_frame_cb,0,3,q,row*width*4,
                blocks,6,page,1,tokens,heads,kv_heads,dim,kv_heads*dim*2,kv_heads*dim*2,tokens-1,0,0,0,NULL,0,result[mode],16+row*width*4))return 4;
        }
        if(mode){
            if(r->lighton_attention_batch->count!=rows||termite_metal_decode_runtime_lighton_attention_batch_end(r))return 5;
        }
        id<MTLCommandBuffer> cb=r->active_frame_cb;
        if(termite_metal_decode_runtime_end_planned_compute_scope(r)||termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r))return 6;
        elapsed[mode]+=(cb.GPUEndTime-cb.GPUStartTime)*1e6;
        for(size_t j=0;j<4;j++)if(out[j]!=0xdeadbeef||out[rows*width+4+j]!=0xdeadbeef)return 7;
    }
    double worst=0,cpu_worst=0;
    for(size_t row=0;row<rows;row++){
        const size_t tokens=432+row*13;
        for(size_t j=0;j<width;j++){
            float a=((float*)result[0].contents)[4+row*width+j],b=((float*)result[1].contents)[4+row*width+j];
            if(!isfinite(a)||!isfinite(b))return 8;worst=fmax(worst,fabs(a-b));
        }
        for(size_t corner=0;corner<4;corner++){
            size_t h=(corner&1)?heads-1:0,d=(corner&2)?255:0,kh=h/4;
            double best=-INFINITY,denom=0,numer=0;
            for(size_t t=0;t<tokens;t++){
                size_t phys=blocks[t/page]+t%page;double dot=0;
                for(size_t d1=0;d1<dim;d1++)dot+=(double)qs[row*width+h*dim+d1]*ks[(phys*kv_heads+kh)*dim+d1];
                dot*=.0625;double next=fmax(best,dot),old=exp(best-next),weight=exp(dot-next);
                denom=denom*old+weight;numer=numer*old+weight*vs[(phys*kv_heads+kh)*dim+d];best=next;
            }
            cpu_worst=fmax(cpu_worst,fabs(numer/denom-((float*)result[1].contents)[4+row*width+h*dim+d]));
        }
    }
    fprintf(stderr,"attention_batch rows=%zu heads=%zu max_abs=%g cpu_max_abs=%g canonical_gpu_us=%.2f batch_gpu_us=%.2f\n",rows,heads,worst,cpu_worst,elapsed[0]/trials,elapsed[1]/trials);
    if(worst>2e-5||cpu_worst>2e-5)return 9;
    return 0;
}

'''
s=s[:i]+code+s[i:];needle='        if (argc == 2 && strcmp(argv[1], "--check-activation-pool") == 0) {'
idx=s.index(needle);s=s[:idx]+'''        if (argc == 2 && (strcmp(argv[1], "--check-batch-attention") == 0 || strcmp(argv[1], "--benchmark-batch-attention") == 0)) {
            for(size_t heads=8;heads<=16;heads+=8)for(size_t rows=2;rows<=16;rows*=2){
                int rc=ocr_attention_batch_check(r,rows,heads,strstr(argv[1],"benchmark")!=NULL);
                if(rc){fprintf(stderr,"ATTENTION_BATCH_FAIL rc=%d\\n",rc);return 125;}
            }
            termite_metal_decode_runtime_destroy(r);return 0;
        }
'''+s[idx:];p.write_text(s)
