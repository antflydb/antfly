from pathlib import Path
import json,hashlib,subprocess,gzip
v=Path('.venv-lighton-vllm-metal');o=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
frozen=json.loads((v/'engine56-freeze.json').read_text());assert all(sha(p)==h for p,h in frozen.items())
assert json.loads((o/'engine56_workspace_profiles_verified_audit.json').read_text())['status']=='pass'
assert json.loads((o/'engine56_c_qualification_audit.json').read_text())['status']=='pass'
assert 'DONE default_gpu_test 0'in Path('/private/tmp/ocr-engine56-functional-driver.txt').read_text()
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text();marker='} else struct {\n    pub const ReservedHiddenStatePair';assert s.count(marker)==1
start=s.index('    fn lightOnPreparedConfigEligible(');end=s.index('\n    }',start)+6;eligible=s[start:end]
stubs='''} else struct {
    pub const OcrEncoderStage = enum { vision, prefill, florence };

    pub fn beginOcrEncoderScope(_: *const ops.ComputeBackend, _: OcrEncoderStage) !bool {
        return false;
    }

    pub fn ocrEncoderScopeOpens(_: *const ops.ComputeBackend) [3]u64 {
        return @splat(0);
    }

    pub fn releaseProjectorSlotsForTensor(_: *const ops.ComputeBackend, _: CT) void {}

'''+eligible+'''

    pub const ReservedHiddenStatePair'''
old_prefix=s.split(marker)[0];s=s.replace(marker,stubs);p.write_text(s)
subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt',str(p)],check=True)
new=p.read_text();assert new.split('} else struct {\n    pub const OcrEncoderStage')[0]==old_prefix
(o/'engine57_metal_enabled_source_equivalence_audit.json').write_text(json.dumps(dict(status='pass',scope='Only Metal-disabled struct fallback declarations added; complete Metal-enabled implementation prefix remains byte-identical to engine56.',metal_enabled_prefix_sha256=hashlib.sha256(old_prefix.encode()).hexdigest(),unchanged_runtime_files={name:h for name,h in frozen.items()if name!=str(p)},prior_metal_compute_sha256=frozen[str(p)],new_metal_compute_sha256=sha(p)),indent=2)+'\n')
(v/'engine57-freeze.json').write_text(json.dumps({name:sha(name)for name in frozen},indent=2)+'\n')
(v/'engine57_benchmark_concurrency.py').write_bytes(Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes())
for old in ['run_engine56_verify_gpu_build.py','run_engine56_metal_disabled.py','run_engine56_budget_policies.py']:
 (v/old.replace('engine56','engine57')).write_text((v/old).read_text().replace('engine56','engine57'))
# Native paired29 uses identical preselected runtime settings. Preserve the
# qualification provenance by pointing it at the immutable engine56 screen.
s=(v/'run_engine56_paired29.py').read_text().replace('engine56','engine57').replace("out/'engine57_workspace_profiles_verified_audit.json'","out/'engine56_workspace_profiles_verified_audit.json'")
(v/'run_engine57_paired29.py').write_text(s)
ns={};a=(v/'archive_engine10_evidence.py').read_text();exec(a[:a.index("archive('qualification'")],ns)
ns['archive']('drivers',[Path(__file__),v/'engine57-freeze.json',v/'engine57_benchmark_concurrency.py',v/'run_engine57_verify_gpu_build.py',v/'run_engine57_metal_disabled.py',v/'run_engine57_budget_policies.py',v/'run_engine57_paired29.py'],'drivers_manifest.json')
ns['archive']('qualification',list(Path('/private/tmp').glob('ocr-engine56-*.txt')),'logs_manifest.json')
print('engine57 CPU-only stubs applied; Metal-enabled implementation byte-identical')
