from pathlib import Path
import hashlib,json,os,subprocess,sys,time
root=Path.cwd();v=root/'.venv-lighton-vllm-metal';out=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def freeze():
 d=json.loads((v/'engine45-freeze.json').read_text())
 assert all(sha(root/p)==s for p,s in d.items())
 m=json.loads((out/'engine45_build_manifest.json').read_text())
 assert sha(Path(m['binary_path']))==m['binary_sha256']
def archive(paths):
 ns={};s=(v/'archive_engine10_evidence.py').read_text();exec(s[:s.index("archive('qualification'")],ns)
 ns['archive']('qualification',paths,'logs_manifest.json')
def run(name,cmd):
 print('START',name,flush=True)
 log=Path('/private/tmp/ocr-'+name+'.txt');assert not log.exists()
 with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 archive([log]);print('DONE',name,r.returncode,flush=True)
 assert r.returncode==0,(name,r.returncode)
def compress(patterns):
 subprocess.run([sys.executable,str(v/'archive_completed_engine_reports.py'),*patterns],check=True)
freeze()
archive([Path('/private/tmp/ocr-engine45-probe-recovery-driver.txt')])
for mode in ['qualification','primary']:
 run('engine45-prefill4-c56-hybrid-'+mode,[sys.executable,str(v/'run_engine45_prefill4_case.py'),mode,'56','1'])
 freeze()
 compress(['engine45_4b_vision1_prefill4_*'+mode])
 archive(list(Path('/private/tmp').glob('ocr-engine45-4b-*vision1_prefill4*'+mode+'*.txt')))
run('engine45-paired27-4b-driver',[sys.executable,str(v/'run_engine45_paired27_verify2.py'),'4b'])
freeze()
compress(['engine45_4b_*paired27*','vllm_4b_*reference27*'])
archive(list(Path('/private/tmp').glob('ocr-engine45-*paired27*.txt')))
print('PREFILL4 AND PAIRED27 COMPLETE',flush=True)
