#include <metal_stdlib>
#include <metal_tensor>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;using namespace mpp::tensor_ops;
struct Params {uint rows,in_dim,out_dim,reserved;};
kernel void engine77_prefill_1(device bfloat *x [[buffer(0)]], device bfloat *w [[buffer(1)]], device float *bias [[buffer(2)]], device float *y [[buffer(3)]], constant Params &p [[buffer(4)]], uint2 group [[threadgroup_position_in_grid]]) {
 tensor<device bfloat,dextents<int,2>,tensor_inline> a(x,dextents<int,2>(p.in_dim,p.rows),array<int,2>{1,int(p.in_dim)});
 tensor<device bfloat,dextents<int,2>,tensor_inline> b(w,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{1,int(p.in_dim)});
 tensor<device float,dextents<int,2>,tensor_inline> c(y,dextents<int,2>(p.out_dim,p.rows),array<int,2>{1,int(p.out_dim)});
 auto left=a.slice(0,int(group.y)*128); auto right=b.slice(0,int(group.x)*32); auto dest=c.slice(int(group.x)*32,int(group.y)*128);
 constexpr auto desc=matmul2d_descriptor(128,32,dynamic_length_v<int>,false,true,false);
 matmul2d<desc,execution_simdgroups<8>> op;
 auto result=op.get_destination_cooperative_tensor<decltype(left),decltype(right),float>();
 op.run(left,right,result);
 #pragma unroll
 for(ushort i=0;i<result.get_capacity();i++){auto coord=result.get_multidimensional_index(i);int col=int(group.x)*32+coord[0],row=int(group.y)*128+coord[1];if(coord[0]>=0 && coord[0]<32 && coord[1]>=0 && coord[1]<128 && col<int(p.out_dim) && row<int(p.rows))result[i]+=bias[col];}
 result.store(dest);
}
