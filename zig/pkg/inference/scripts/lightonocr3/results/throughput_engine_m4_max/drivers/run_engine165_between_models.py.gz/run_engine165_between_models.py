from pathlib import Path
import datetime,hashlib,json,os,psutil,signal,statistics,subprocess,sys,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();a=o/'engine165_batched_prefix_audit.json';assert not a.exists();prep=json.loads((v/'engine165_batched_prefix_preparation.json').read_text());assert all(sha(p)==h for p,h in prep['source_sha256'].items());assert sha(r/'zig/pkg/inference/src/backends/metal_kernels.m')==prep['canonical_c_sha256'];f=json.loads((v/'engine158-freeze.json').read_text());assert all(sha(p)==h for p,h in f.items())
candidates=[]
for p in psutil.process_iter(['cmdline']):
 try:
  if any(arg.endswith('/run_engine158_short161_screen.py')for arg in p.info['cmdline']or[])and Path(p.cwd())==r:candidates.append(p)
 except psutil.Error:pass
assert len(candidates)==1,candidates
waiter=candidates[0];owned=dict(pid=waiter.pid,create_time=waiter.create_time(),cmdline=waiter.cmdline(),cwd=waiter.cwd());d=dict(status='stopping_own_waiter_for_isolated_probe',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),preparation=prep,own_waiter=owned,primary_throughput_eligible=False,runs=[])
def save():a.write_text(json.dumps(d,indent=2)+'\n')
save();stopped=False
try:
 waiter.send_signal(signal.SIGSTOP);stopped=True
 for i in range(50):
  if waiter.status()==psutil.STATUS_STOPPED:break
  time.sleep(.01)
 assert waiter.status()==psutil.STATUS_STOPPED
 children=waiter.children(recursive=True);d['children_after_stop']=[dict(pid=p.pid,cmdline=p.cmdline(),create_time=p.create_time())for p in children];save()
 if children:d['status']='probe_not_run_parent_race_child_exists';save();print('165 skipped: own model child already active',flush=True);sys.exit(0)
 d['status']='waiting8GiB_before_private_build';save()
 while psutil.virtual_memory().available<8*1024**3:print('WAIT165 available',psutil.virtual_memory().available,flush=True);time.sleep(10)
 binary=v/'engine165_batched_prefix_probe';build=Path('/private/tmp/ocr-engine165-batched-build.txt');assert not build.exists();command=['clang','-O3','-fobjc-arc','-I'+str(r/'zig/pkg/inference/src/backends'),str(v/'engine165_batched_prefix_probe.m'),'-o',str(binary),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate'];d['build_command']=command;d['status']='building';save()
 with build.open('w')as out:p=subprocess.run(command,env=dict(os.environ,CLANG_MODULE_CACHE_PATH=str(v/'clang-cache')),stdout=out,stderr=subprocess.STDOUT)
 d.update(build_exit_code=p.returncode,build_log_sha256=sha(build));save();assert p.returncode==0
 d['binary_sha256']=sha(binary);save()
 for phase,args in [('check',[]),('benchmark',['--benchmark'])]:
  while psutil.virtual_memory().available<8*1024**3:print('WAIT165 probe available',psutil.virtual_memory().available,flush=True);time.sleep(10)
  so=Path(f'/private/tmp/ocr-engine165-batched-{phase}-stdout.txt');se=Path(f'/private/tmp/ocr-engine165-batched-{phase}-stderr.txt');assert not so.exists()and not se.exists();d['status']=phase+'_running';save();print('START165',phase,flush=True)
  with so.open('w')as out,se.open('w')as err:p=subprocess.run([str(binary),*args],stdout=out,stderr=err,env=dict(os.environ,MTL_DEBUG_LAYER='0'),timeout=1200)
  record=dict(phase=phase,exit_code=p.returncode,stdout_sha256=sha(so),stderr_sha256=sha(se));d['runs'].append(record);save();assert p.returncode==0,record
  assert 'BATCH165 FULL OUTPUT INDEPENDENT STATE CANARY CHECKS PASS'in se.read_text()
  if phase=='check':record['shape_count']=se.read_text().count('batch165_check pages=');assert record['shape_count']==156
  else:
   rows=[json.loads(line)for line in so.read_text().splitlines()if line.startswith('{')];assert len(rows)==1920,len(rows);record['ratios']=[]
   for pages,q,h,mixed in sorted({(x['pages'],x['queries'],x['heads'],x['mixed'])for x in rows}):
    xs=[x for x in rows if (x['pages'],x['queries'],x['heads'],x['mixed'])==(pages,q,h,mixed)and x['trial']>=2];old=statistics.median(x['gpu_us']for x in xs if x['mode']==0);new=statistics.median(x['gpu_us']for x in xs if x['mode']==1);record['ratios'].append(dict(pages=pages,queries=q,heads=h,mixed=mixed,old_median_gpu_us=old,new_median_gpu_us=new,old_over_new=old/new))
  save();print('DONE165',phase,flush=True)
 d['status']='numeric_and_isolated_stage_pass_not_production_qualified';save()
except BaseException as e:
 d.update(status='failed_or_excluded',error=repr(e));save();raise
finally:
 if stopped:
  current=psutil.Process(owned['pid']);assert abs(current.create_time()-owned['create_time'])<.1 and current.cmdline()==owned['cmdline']and current.cwd()==owned['cwd']
  current.send_signal(signal.SIGCONT);d['own_waiter_resumed']=True;d['resumed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print('165 own waiter resumed',flush=True)
