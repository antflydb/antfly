from pathlib import Path
import hashlib,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';source=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=source.read_text();needle='#import <Metal/Metal.h>';s=s.replace(needle,needle+'\nstatic bool private_chunk115_enabled;\nstatic id<MTLComputePipelineState> private_chunk115_coeff,private_chunk115_state;\nstatic id<MTLBuffer> private_chunk115_workspace;')
needle='            [encoder setComputePipelineState:pipelines[stage]];';assert s.count(needle,s.index('int termite_metal_decode_runtime_qwen35_core_device('))>=1
code='''            if(stage==3 && private_chunk115_enabled && seq>=16) {
                if(!private_chunk115_coeff || !private_chunk115_state || !private_chunk115_workspace || private_chunk115_workspace.length<(seq/16)*value_heads*544*4) return -115;
                for(size_t i=0;i<15;i++)[encoder setBuffer:buffers[i] offset:offsets[i] atIndex:i];
                [encoder setBytes:&params length:sizeof(params) atIndex:15];
                [encoder setBuffer:private_chunk115_workspace offset:0 atIndex:16];
                if(!frame_owned && termite_metal_decode_runtime_retain_frame_resource(runtime,private_chunk115_workspace))return -116;
                [encoder setComputePipelineState:private_chunk115_coeff];
                [encoder dispatchThreadgroups:MTLSizeMake((seq/16)*value_heads,1,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];
                [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
                [encoder setComputePipelineState:private_chunk115_state];
                [encoder dispatchThreadgroups:MTLSizeMake(value_heads*8,1,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];
                [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
                const size_t full=(seq/16)*16,tail=seq-full;
                if(tail) {
                    __typeof__(params) tail_params=params;tail_params.seq=(uint32_t)tail;tail_params.initialized=1;
                    [encoder setBytes:&tail_params length:sizeof(tail_params) atIndex:15];
                    [encoder setBuffer:buffers[9] offset:offsets[9]+full*channels*4 atIndex:9];
                    [encoder setBuffer:buffers[10] offset:offsets[10]+full*value_heads*2*4 atIndex:10];
                    [encoder setBuffer:buffers[11] offset:offsets[11]+full*value_heads*128*4 atIndex:11];
                    [encoder setComputePipelineState:pipelines[3]];
                    size_t width=pipelines[3]==runtime->qwen35_recurrent_columns4_pipeline?32:128;
                    [encoder dispatchThreads:MTLSizeMake(grids[3],1,1) threadsPerThreadgroup:MTLSizeMake(width,1,1)];
                    [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
                    for(size_t i=9;i<=11;i++)[encoder setBuffer:buffers[i] offset:offsets[i] atIndex:i];
                    [encoder setBytes:&params length:sizeof(params) atIndex:15];
                }
                if(!shared_encoder)[encoder endEncoding];
                continue;
            }
'''
idx=s.index(needle,s.index('int termite_metal_decode_runtime_qwen35_core_device('));s=s[:idx]+code+s[idx:];(v/'engine115_chunk_kernels.m').write_text(s)
s=(r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text().replace('#include "../../src/backends/metal_kernels.m"','#include "engine115_chunk_kernels.m"');a=s.index('static int prefill_core_check(');b=s.index('\nstatic ',a+10);p=s[a:b]
p=p.replace('const size_t trials = benchmark ? 30 : 1, modes = benchmark ? 2 : 4;','const size_t trials = benchmark ? 12 : 1, modes = 2;')
p=p.replace('''            if (variant == 0 || variant == 3)
                setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_CORE_NORM", "1", 1);
            else
                unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_CORE_NORM");''','''            private_chunk115_enabled=variant!=0;
            unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_CORE_NORM");''')
p=p.replace('(variant == 1 && seq >= 128 ? 1 : 0)','(seq >= 128 ? 1 : 0)');s=s[:a]+p+s[b:];(v/'engine115_chunk_checks.m').write_text(s)
(v/'engine115_chunk_preparation.json').write_text(json.dumps(dict(scope='Private C16 chunked F32 recurrent prefill prototype only. Coefficient/triangular formulation, SIMD matrix products, F32 state, exact sequential legacy tail. No canonical runtime changes or model throughput claim.',production_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),shader_sha256=hashlib.sha256((v/'engine115_chunk.metal').read_bytes()).hexdigest()),indent=2)+'\n')
