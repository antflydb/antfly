from pathlib import Path
import datetime,hashlib,json,os,psutil,subprocess,sys,time
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=o/'engine94_mixed_screen75_audit.json';assert not a.exists();d=dict(status='preparing',primary_throughput_eligible=False,scope='First opt-in packed prefill+decode end-to-end qualification on0.8B C16/R32, then4B C64/R128 ifsmall passes. Everyfull output matches serialF32native and historicalvLLMfixturestrings. Historicalreference onlycontentoracle, neverthroughputcomparator. Originalcaps/reserve unchanged. Freshsource94 qualifiedbinary. No owncompilation/otherGPUjob overlaps.',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),runs=[])
def save():a.write_text(json.dumps(d,indent=2)+'\n')
save()
for p,h in json.loads((v/'engine94-freeze.json').read_text()).items():assert sha(r/p)==h,p
m=json.loads((o/'engine94_build_manifest.json').read_text());assert sha(m['binary_path'])==m['binary_sha256'];d['binary_sha256']=m['binary_sha256'];save()
try:
 for model,c,requests,estimate,reference in [('08',16,32,4*1024**3,'_primary_reference72_r0_auto_c64_r128'),('4b',64,128,11348275670,'_primary_reference73_r0_auto_c64_r128_ctx1024')]:
  while psutil.virtual_memory().available<estimate+6*1024**3+512*1024**2:
   d.update(status='waiting_original_reserve',available_bytes=psutil.virtual_memory().available);save();print('WAIT75',model,d['available_bytes'],flush=True);time.sleep(15)
  label=f'mixed_screen75_c{c}_r{requests}';dest=o/f'engine94_{model}_{label}';assert not dest.exists();env=dict(os.environ)
  env.update(OCR_PACKED_MIXED='1',OCR_REFERENCE_LABEL=reference,OCR_PHYSICAL32='0',OCR_PHYSICAL64=str(int(c==64)),OCR_CONCURRENCY=str(c),OCR_REQUESTS=str(requests),OCR_WIDE='1',OCR_KV_GIB='4',OCR_BACKEND_GIB='17'if model=='4b'else'16',OCR_SCRATCH_GIB='10'if model=='4b'else'8',OCR_CPU_PREPROCESS='1',OCR_PREFILL_DECODE_STREAK='0',OCR_POLICIES='engineepoch',OCR_SHARED_CORE='1',OCR_BF16_PREFILL='1',OCR_BF16='0',OCR_DISABLE_64_ROW_TILE='0',OCR_DISABLE_WIDE_GATE_UP='0',OCR_WIDE64_GATE_UP='1',OCR_FULL64_GATE_UP=str(int(model=='4b')),OCR_GPU_GREEDY_STREAM='0',OCR_STREAM_CHUNK_LAYERS='0',OCR_VISION_BATCH='0',OCR_VISION_BATCH_ITEMS='1',OCR_PREFILL_BATCH='0',OCR_PREFILL_BATCH_ITEMS='1',OCR_VISION_FRAME_BLOCKS='3'if model=='4b'else'4',OCR_SINGLE_FRAME='1',OCR_STREAM_FIRST='0',OCR_LOGICAL64='1',OCR_SHARED_DECODER_SCRATCH='1',OCR_DEVICE_RECURRENT_STATE='1',OCR_ENCODER_SCOPES='1',OCR_ADMISSION_UNITS='512',OCR_BATCH_ARGMAX='1',OCR_DEFER_VISION_SEAL='0',OCR_DEFER_PREFILL_SEAL='0',OCR_CACHE_VISION_WORKSPACE='1',OCR_LARGE_VISION_PACK_REUSE='0',ANTFLY_LIGHTONOCR3_QUEUED_PHASE_PRIORITY='0',OCR_TIMEOUT='1800',OCR_PREFILL_FUSED_FFN='0',OCR_RESIDENT_VISION_BUDGET='1',OCR_GPU_TOKEN_BURST='1',OCR_GPU_TOKEN_BURST_WIDTH='4',OCR_PIPELINE_VISION='0',OCR_PREFILL_STREAM_LAYERS='0',OCR_REQUIRE_MEMORY_ROUNDS='1')
  for key in ['OCR_BF16_ROUNDS','OCR_PREFILL_FFN_ROUNDS']:env.pop(key,None)
  record=dict(model=model,status='running');d['runs'].append(record);d['status']='running';save();print('START MIXED75',model,flush=True)
  log=Path(f'/private/tmp/ocr-engine94-mixed75-{model}-driver.txt');assert not log.exists()
  with log.open('w')as f:p=subprocess.run([sys.executable,str(v/'run_engine94_budget_policies.py'),model+':'+label],env=env,stdout=f,stderr=subprocess.STDOUT)
  record.update(exit_code=p.returncode,driver_log_sha256=sha(log));save();assert p.returncode==0
  report=dest/'report.json';nd=json.loads(report.read_text());result=nd['results'][0];sample=result['policy_rounds'][0];assert result['status']=='ok'and result['serial_reference_parity']and result['cross_runtime_content_parity'];assert sample['mixed_steps']>0 and sample['packed_steps']==requests and sample['completed']==requests and not sample['admission_pressures'];record.update(status='passed',report=str(report.relative_to(o)),report_sha256=sha(report),sample=sample);save();print('PASS MIXED75',model,sample['pages_per_second'],sample['mixed_steps'],flush=True)
 d['status']='mixed_screen_pass';save()
except BaseException as e:d.update(status='failed',error=repr(e));save();raise
