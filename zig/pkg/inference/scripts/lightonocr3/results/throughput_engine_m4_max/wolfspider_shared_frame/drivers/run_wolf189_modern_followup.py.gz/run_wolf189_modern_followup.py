from pathlib import Path
import datetime,json,os,psutil,shutil,subprocess,sys,time
r=Path('/Users/ajroetker/antfly/.worktrees/perf-lightonocr3-shared-frame-wolfspider');os.chdir(r);v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/wolfspider_shared_frame';a=o/'wolf189_modern_followup_audit.json';assert not a.exists();parents=[]
for p in psutil.process_iter(['cmdline']):
 try:
  if any(x.endswith('/run_wolf187_followups.py')for x in p.info['cmdline']or[])and Path(p.cwd())==r:parents.append(p)
 except psutil.Error:pass
assert len(parents)==1;parent=parents[0];identity=dict(pid=parent.pid,create_time=parent.create_time());d=dict(status='waiting_for185_and186_exit',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent=identity)
def save():a.write_text(json.dumps(d,indent=2)+'\n')
save()
while True:
 try:status=json.loads((o/'wolf187_followups_audit.json').read_text())['status']
 except json.JSONDecodeError:time.sleep(.1);continue
 if status=='followups_complete':break
 if status.startswith('failed')or status=='candidate_not_promoted_followups_held_for_selection':d['status']='held_prior_followup_failed';save();sys.exit(0)
 assert parent.is_running()and parent.create_time()==identity['create_time'];time.sleep(15)
while parent.is_running()and parent.status()!=psutil.STATUS_ZOMBIE and parent.create_time()==identity['create_time']:time.sleep(.2)
prior=json.loads((o/'paired185_08_warmed_comparison_audit.json').read_text());source=o/prior['vllm_r1']['report'];x=json.loads(source.read_text());assert x['status']=='ok';dest=o/'vllm_08_modern_oracle';dest.mkdir();(dest/'report.json').write_text(json.dumps(dict(reference_kind='text_only',performance_evidence=False,images=x['images'],references=x['references']),indent=2)+'\n');shutil.copyfile(v/'engine188_08_modern_preregistration.json',o/'engine188_08_modern_preregistration.json');d['status']='modern188_running';save();print('START189 fixed modern0.8B profile after prior model benchmarks exit',flush=True);log=Path('/private/tmp/ocr-wolf188-primary-parent.txt');assert not log.exists()
with log.open('w')as out:p=subprocess.run([sys.executable,str(v/'run_wolf188_08_modern_primary.py')],cwd=r,stdout=out,stderr=subprocess.STDOUT)
report=o/'paired188_08_warmed_comparison_audit.json';d.update(status='modern188_finished'if p.returncode==0 else'modern188_failed',exit_code=p.returncode,comparison=json.loads(report.read_text())if report.exists()else None);save();print('DONE189',d['status'],flush=True)
