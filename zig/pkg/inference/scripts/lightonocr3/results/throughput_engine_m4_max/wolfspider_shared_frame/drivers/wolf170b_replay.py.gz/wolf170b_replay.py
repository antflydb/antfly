from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
r=Path('/Users/ajroetker/antfly/.worktrees/perf-lightonocr3-wolfspider');os.chdir(r);v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/wolfspider';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=o/'wolf170_replay_audit.json';prior=json.loads(old.read_text());assert len(prior['c_checks'])==24 and all(x['exit_code']==0 for x in prior['c_checks'])
f=json.loads((v/'engine158-freeze.json').read_text());assert all(sha(r/p)==h for p,h in f.items())
a=o/'wolf170b_replay_audit.json';assert not a.exists();d=dict(status='replaying_native_with_original_filters_and_package_cwd',created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver_sha256=sha(Path(__file__)),scope='Same byte-identical qualified source158 binary.170C24replaypassed. First native replay used zig root instead of inference package and omitted runtime filters;371extra/defaulttests passed, one source-inspection test failedFileNotFound.170bcorrects invocation only. No canonical code changes, no performance claim.',prior_replay_sha256=sha(old),c_checks_reused=prior['c_checks'])
def save():a.write_text(json.dumps(d,indent=2)+'\n')
save();source=(v/'run_engine158_gpu_build.py').read_text();ns={'__name__':'__wolf170b_replay__'};exec(source[:source.index('command=[')],ns);binary=v/'qualified-binaries/engine158-test';args=[str(binary),*[arg for token in ns['filters']for arg in ['--test-filter',token]]];log=o/'qualification/wolf170b-native-gpu-replay.txt';d['command']=args;d['cwd']=str(r/'zig/pkg/inference');save();print('WOLF170b replaying original339testselection',flush=True)
with log.open('w')as out:result=subprocess.run(args,cwd=r/'zig/pkg/inference',env=ns['env'],stdout=out,stderr=subprocess.STDOUT,timeout=1200)
d.update(exit_code=result.returncode,log_sha256=sha(log));save();assert result.returncode==0;assert '339 selected; 333 passed; 6 skipped.'in log.read_text();ns['r']=result;validation=source[source.index('if r.returncode==0:'):].replace('/private/tmp/ocr-engine158-verify3-gpu-build.txt',str(log))
try:exec(validation,ns)
except SystemExit as e:assert e.code==0
assert all(sha(r/p)==h for p,h in f.items());d['status']='C24_and_333_native_tests_replayed_pass';save();print('WOLF170b REPLAY PASS',flush=True)
