from pathlib import Path
import datetime,json,os,psutil,subprocess,sys,time
r=Path('/Users/ajroetker/antfly/.worktrees/perf-lightonocr3-wolfspider');os.chdir(r);v=r/'.venv-lighton-vllm-metal';o=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/wolfspider';audit=o/'wolf173_chain_audit.json';assert not audit.exists()
parents=[p for p in psutil.process_iter(['pid','cmdline']) if any(x.endswith('/run_wolf171_screen.py') for x in p.info['cmdline']or[])];assert len(parents)==1
parent=parents[0];identity=dict(pid=parent.pid,create_time=parent.create_time(),cwd=parent.cwd(),cmdline=parent.cmdline());d=dict(status='waiting_for_screen',screen_parent=identity,created_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
def save():audit.write_text(json.dumps(d,indent=2)+'\n')
save()
while True:
 s=json.loads((o/'engine158_wolf171_screen_audit.json').read_text())
 if s['status']=='screen_complete':break
 assert s['status']!='failed_screen',s
 assert parent.is_running() and parent.create_time()==identity['create_time']
 time.sleep(15)
while parent.is_running() and parent.create_time()==identity['create_time']:time.sleep(.2)
assert all(x['status']=='passed' for x in s['runs'])
d['status']='primary_running';save();print('WOLF173 starting fresh actual vLLM paired comparison',flush=True)
with Path('/private/tmp/ocr-wolf172-primary-parent.txt').open('w') as out:p=subprocess.run([sys.executable,str(v/'run_wolf172_primary.py')],stdout=out,stderr=subprocess.STDOUT)
a=o/'paired172_4b_warmed_comparison_audit.json';d.update(exit_code=p.returncode,primary=json.loads(a.read_text())if a.exists()else None,status='primary_complete'if p.returncode==0 else'primary_failed');save();print('WOLF173 primary done',d['status'],flush=True)
