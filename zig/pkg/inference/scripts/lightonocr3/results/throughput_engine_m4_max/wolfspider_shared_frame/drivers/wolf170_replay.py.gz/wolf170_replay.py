from pathlib import Path
import datetime
import hashlib
import importlib.metadata
import json
import os
import platform
import re
import subprocess
import sys

r = Path('/Users/ajroetker/antfly/.worktrees/perf-lightonocr3-wolfspider')
os.chdir(r)
v = r / '.venv-lighton-vllm-metal'
o = r / 'zig/pkg/inference/scripts/lightonocr3/results/throughput_engine_m4_max/wolfspider'
o.mkdir(parents=True, exist_ok=True)
(origin := v / 'wolf170_origin').mkdir(exist_ok=True)
audit = o / 'wolf170_replay_audit.json'
assert not audit.exists()
def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for data in iter(lambda: stream.read(8 * 1024**2), b''):
            h.update(data)
    return h.hexdigest()
freeze = json.loads((v / 'engine158-freeze.json').read_text())
assert all(sha(r / name) == expected for name, expected in freeze.items())
models = json.loads((origin / 'model_inputs.json').read_text())
for name, expected in models['lighton08'].items():
    path = v / 'ocr-models/lighton08' / name
    assert path.stat().st_size == expected['bytes'] and sha(path) == expected['sha256'], path
manifest = json.loads((origin / 'engine158_build_manifest.json').read_text())
binary = v / 'qualified-binaries/engine158-test'
assert sha(binary) == manifest['binary_sha256']
record = {
    'status': 'checking_environment',
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'driver_sha256': sha(Path(__file__)),
    'scope': 'Wolfspider M4 Max32GPU/36GiB: replay of byte-identical source158 qualified native and C binaries. Same source48file hashes and pinned0.8B model bytes. Correctness only; the4B file transfer may overlap. No throughput claim. Fresh Python3.12.14 with copied exact dependency environment.',
    'platform': platform.platform(),
    'python': sys.version,
    'native_binary_sha256': sha(binary),
    'packages': {name: importlib.metadata.version(name) for name in ['vllm', 'vllm-metal', 'mlx', 'mlx-lm', 'mlx-vlm', 'torch', 'transformers', 'numpy', 'pillow', 'psutil']},
    'c_checks': [],
}
def save():
    audit.write_text(json.dumps(record, indent=2) + '\n')
save()
import mlx.core as mx
import torch
assert mx.metal.is_available() and torch.backends.mps.is_available()
record['mlx_device'] = mx.metal.device_info()
record['status'] = 'replaying_C24'
save()
print('WOLF170 environment/imports verified', flush=True)
cm = json.loads((origin / 'engine158_c_build_manifest.json').read_text())
for name, expected in cm['input_sha256'].items():
    assert sha(r / name) == expected, name
c_binaries = [v / 'engine158_conformance', v / 'engine158_attention']
assert [sha(path) for path in c_binaries] == [item['binary_sha256'] for item in cm['builds']]
flags = ['--check-prefill-activation-pool', '--check-activation-pool', '--check-wide-recurrent', '--check-frame-staging-lifetime', '--check-gpu-token-burst-long', '--check-gpu-token-burst', '--check-resident-vision-dispatch', '--check-vision-workspace-cache', '--check-large-vision-pack-reuse', '--check-batch-argmax', '--check-wide-gate-up-full64', '--check-wide-gate-up', '--check-wide-gate-up-large64', '--check-frame-metadata', '--check-wide64', '--check-planned-mpp', '', '--check-wide-mpp', '--check-batch-attention', '--check-prefill-pack-reuse', '--check-prefill-pack-reuse-large', '--check-decode-pack-reuse', '--check-vision-pack-reuse']
logs = o / 'qualification'
logs.mkdir(exist_ok=True)
env = dict(os.environ, TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE_RECURRENT='0', TERMITE_METAL_ENABLE_LIGHTONOCR3_WIDE64_GATE_UP='0', TERMITE_METAL_ENABLE_LIGHTONOCR3_FULL64_GATE_UP='0')
for executable, flag in [(c_binaries[0], flag) for flag in flags] + [(c_binaries[1], '')]:
    name = 'attention' if executable == c_binaries[1] else flag.removeprefix('--check-') or 'full'
    log = logs / ('wolf170-c-' + name + '.txt')
    print('WOLF170 C', name, flush=True)
    with log.open('w') as output:
        result = subprocess.run([str(executable), *([flag] if flag else [])], env=env, stdout=output, stderr=subprocess.STDOUT, timeout=1200)
    record['c_checks'].append({'name': name, 'exit_code': result.returncode, 'log_sha256': sha(log)})
    save()
    assert result.returncode == 0, name
record['status'] = 'replaying_native_Metal_tests'
save()
source = (v / 'run_engine158_gpu_build.py').read_text()
namespace = {'__name__': '__wolf170_replay__'}
exec(source[:source.index('command=[')], namespace)
log = logs / 'wolf170-native-gpu-replay.txt'
print('WOLF170 native Metal-enabled tests', flush=True)
with log.open('w') as output:
    result = subprocess.run([str(binary)], cwd=r / 'zig', env=namespace['env'], stdout=output, stderr=subprocess.STDOUT, timeout=1200)
record['native_replay'] = {'exit_code': result.returncode, 'log_sha256': sha(log)}
save()
assert result.returncode == 0
text = log.read_text()
assert '339 selected; 333 passed; 6 skipped.' in text
namespace['r'] = result
validation = source[source.index('if r.returncode==0:'):].replace('/private/tmp/ocr-engine158-verify3-gpu-build.txt', str(log))
try:
    exec(validation, namespace)
except SystemExit as exited:
    assert exited.code == 0
assert all(sha(r / name) == expected for name, expected in freeze.items())
record['status'] = 'C24_and_333_native_tests_replayed_pass'
save()
print('WOLF170 REPLAY PASS', flush=True)
