import subprocess,sys
from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_parity_m4_max';m=r/'.venv-lighton-vllm-metal/ocr-models';images=[str(r/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(p/'corpus/receipt.png'),str(p/'corpus/shipping.png')]
for name in sys.argv[1:]:
 if name in ['08','4b']:
  cmd=[sys.executable,str(p/'benchmark_vllm_metal.py'),'--python',sys.executable,'--model-dir',str(m/('lighton'+name)),'--images',*images,'--concurrency','8','--requests','16','--max-tokens','256','--output-dir',str(out/('vllm_'+name+'_shipping_reference'))]
 else:
  cmd=[sys.executable,str(p/'benchmark_mlx_florence.py'),'--model-dir',str(m/'florence-fp16'),'--images',*images,'--batch-sizes','1','--requests','16','--max-tokens','256','--output-dir',str(out/'mlx_florence_shipping_reference')]
 print('START',name,flush=True)
 with open('/private/tmp/ocr-parity-local-reference-'+name+'.txt','w') as f:res=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 print('DONE',name,res.returncode,flush=True)
 if res.returncode:sys.exit(res.returncode)
