from pathlib import Path
import gzip,subprocess,json
r=Path.cwd();h=r/'.venv-lighton-vllm-metal';out=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max';p=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=p.read_text()
patch=subprocess.check_output(['git','diff','58d7e441dd3c2f19584d99b5baa321659a387ef7','--','zig/pkg/inference/src'])
with gzip.GzipFile(filename=str(out/'decoder_runtime.patch.gz'),mode='wb',mtime=0) as f:f.write(patch)
shader=(h/'vision_packed_mpp.metal').read_text();pack=(h/'vision_packed_q64k64.metal').read_text();shader+=pack[pack.index('kernel void vision_pack_half'):];shader=shader.replace('termite_metal_sdpa_f32_params','VisionParams');shader='struct VisionParams {uint batch,seq_len,num_heads,head_dim,bias_mode,has_mask,layout,reserved1;};\n'+shader
idx=s.index('        "struct Params { uint rows; uint in_dim; uint out_dim; uint pad; };\\n"')
s=s[:idx]+''.join('        '+json.dumps(x+'\n')+'\n' for x in shader.splitlines())+s[idx:]
needle='    id<MTLComputePipelineState> lightonocr3_local_gate_tg16, lightonocr3_local_gate_tg32;';assert needle in s;s=s.replace(needle,needle+'\n    id<MTLComputePipelineState> lightonocr3_vision_pack_pipeline, lightonocr3_vision_mpp_pipeline;\n    id<MTLBuffer> lightonocr3_vision_pack_buffers[2];\n    __weak id<MTLCommandBuffer> lightonocr3_vision_pack_owners[2];\n    uint64_t lightonocr3_vision_mpp_dispatches;')
needle='            runtime->lightonocr3_local_gate_tg16 =';idx=s.index(needle);s=s[:idx]+'''            runtime->lightonocr3_vision_pack_pipeline = termite_metal_make_pipeline(device,tensor_library,@"vision_pack_half");
            runtime->lightonocr3_vision_mpp_pipeline = termite_metal_make_pipeline(device,tensor_library,@"termite_sdpa_f32_vision_hd64_flash_packed_mpp");
'''+s[idx:]
needle='    runtime->lightonocr3_local_gate_tg16=nil;';idx=s.index(needle);s=s[:idx]+'''    runtime->lightonocr3_vision_pack_pipeline=nil;runtime->lightonocr3_vision_mpp_pipeline=nil;
    for(size_t i=0;i<2;i++){runtime->lightonocr3_vision_pack_buffers[i]=nil;runtime->lightonocr3_vision_pack_owners[i]=nil;}
'''+s[idx:]
idx=s.index('int termite_metal_decode_runtime_sdpa_f32_device(');s=s[:idx]+(h/'vision_workspace.c').read_text()+'\n'+s[idx:]
needle='        const size_t bias_bytes = bias_mode != 0u';idx=s.index(needle,s.index('int termite_metal_decode_runtime_sdpa_f32_device('));s=s[:idx]+'''        // Optional packed TensorOps retains the same half Q/K/V/probability
        // tiles and F32 accumulation/output as the original Qwen vision flash.
        id<MTLBuffer> vision_packed = nil;
        const size_t vision_padded = (seq_len + 127u) / 128u * 128u;
        if (use_vision_hd64_flash_q32 && qwen3vl_vision_flash == 1u &&
            batch <= 4 && num_heads == 12 && termite_metal_lightonocr3_fast_projections(runtime) &&
            !termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_MPP")) &&
            !termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_MPP")) &&
            runtime->lightonocr3_vision_pack_pipeline != nil && runtime->lightonocr3_vision_mpp_pipeline != nil &&
            runtime->lightonocr3_vision_pack_pipeline.threadExecutionWidth == 32 &&
            runtime->lightonocr3_vision_mpp_pipeline.threadExecutionWidth == 32 &&
            runtime->lightonocr3_vision_pack_pipeline.maxTotalThreadsPerThreadgroup >= 256 &&
            runtime->lightonocr3_vision_mpp_pipeline.maxTotalThreadsPerThreadgroup >= 256 &&
            runtime->lightonocr3_vision_mpp_pipeline.staticThreadgroupMemoryLength <= runtime->device.maxThreadgroupMemoryLength &&
            q_offset % 4 == 0 && k_offset % 4 == 0 && v_offset % 4 == 0 && output_offset % 4 == 0 &&
            !(q_buffer == output_buffer && termite_metal_byte_ranges_overlap(q_offset,bytes,output_offset,bytes)) &&
            !(k_buffer == output_buffer && termite_metal_byte_ranges_overlap(k_offset,bytes,output_offset,bytes)) &&
            !(v_buffer == output_buffer && termite_metal_byte_ranges_overlap(v_offset,bytes,output_offset,bytes))) {
            vision_packed = termite_metal_lightonocr3_vision_workspace(runtime,command_buffer,
                3u * batch * num_heads * vision_padded * 64u * sizeof(uint16_t));
        }
        if (vision_packed != nil) { pipeline=runtime->lightonocr3_vision_mpp_pipeline;params.reserved1=(uint32_t)vision_padded; }
'''+s[idx:]
needle='        [encoder setComputePipelineState:pipeline];';start=s.index('int termite_metal_decode_runtime_sdpa_f32_device(');idx=s.index(needle,start);s=s[:idx]+'''        if (vision_packed != nil) {
            const size_t count=batch*num_heads*vision_padded*64u;
            [encoder setComputePipelineState:runtime->lightonocr3_vision_pack_pipeline];
            [encoder setBuffer:q_buffer offset:q_offset atIndex:0];[encoder setBuffer:k_buffer offset:k_offset atIndex:1];
            [encoder setBuffer:v_buffer offset:v_offset atIndex:2];[encoder setBuffer:vision_packed offset:0 atIndex:3];
            [encoder setBytes:&params length:sizeof(params) atIndex:4];
            [encoder dispatchThreads:MTLSizeMake(count,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];
            [encoder memoryBarrierWithScope:MTLBarrierScopeBuffers];
            q_buffer=vision_packed;k_buffer=vision_packed;v_buffer=vision_packed;
            q_offset=0;k_offset=count*sizeof(uint16_t);v_offset=2u*count*sizeof(uint16_t);
            runtime->lightonocr3_vision_mpp_dispatches+=1;
        }
'''+s[idx:]
needle='    termite_metal_decode_runtime_memory_add_buffer(snapshot, runtime->attention_decode_gqa_split_scratch_buffer, &snapshot->scratch_bytes);';assert needle in s;s=s.replace(needle,needle+'\n    for(size_t i=0;i<2;i++)termite_metal_decode_runtime_memory_add_buffer(snapshot,runtime->lightonocr3_vision_pack_buffers[i],&snapshot->scratch_bytes);')
# Existing overlap helper name is resolved below before writing.
s=s.replace('termite_metal_byte_ranges_overlap','termite_metal_ranges_overlap') if 'static bool termite_metal_ranges_overlap(' in s else s
p.write_text(s)
p=r/'zig/pkg/inference/src/backends/metal_runtime.zig';s=p.read_text();needle='pub extern fn termite_metal_decode_runtime_set_lightonocr3_projections';idx=s.index(needle);s=s[:idx]+'pub extern fn termite_metal_decode_runtime_clear_lightonocr3_vision_workspace(runtime: ?*RawMetalDecodeRuntime) c_int;\n'+s[idx:];p.write_text(s)
p=r/'zig/pkg/inference/src/ops/metal_compute.zig';s=p.read_text();idx=s.index('        if (self.require_f32_linears) {',s.index('    fn deinitPooled('));s=s[:idx]+'''        // The admitted request/epoch still owns the vision workspace lease.
        const vision_workspace_rc = metal_runtime.termite_metal_decode_runtime_clear_lightonocr3_vision_workspace(runtime);
        std.debug.assert(vision_workspace_rc == 0);
'''+s[idx:];p.write_text(s)
p=r/'zig/pkg/inference/src/architectures/qwen3vl_projector.zig';s=p.read_text();needle='    backend_scratch = try admissionAdd(backend_scratch, merge_intermediates);';s=s.replace(needle,needle+'''
    // Packed vision SDPA keeps two half Q/K/V workspaces for overlapping
    // command buffers. They remain live through FFN and epoch reuse, so charge
    // them in addition to the earlier score/FFN maximum, even on older devices.
    if (vision_hidden == 768 and head_count == 12 and max_patch_tokens > 256 and max_patch_tokens <= 4096) {
        const padded_rows = try admissionMul(try admissionAdd(max_patch_tokens, 127) / 128, 128);
        const packed_vision_pair = try admissionMul(try admissionF32Bytes(padded_rows, vision_hidden), 3);
        backend_scratch = try admissionAdd(backend_scratch, packed_vision_pair);
    }
''');p.write_text(s)
