from pathlib import Path
import subprocess,gzip,re,json,hashlib
r=Path.cwd();h=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max';stage=h/'runtime_stage';raw=gzip.decompress((p/'attention12_experiment_runtime.patch.gz').read_bytes());base='58d7e441dd3c2f19584d99b5baa321659a387ef7'
for path in re.findall(rb'diff --git a/(\S+) b/',raw):
 path=path.decode();f=stage/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','show',base+':'+path]))
patch=h/'runtime_stage.patch';patch.write_bytes(raw);subprocess.run(['git','apply','--directory='+str(stage.relative_to(r)),str(patch)],check=True)
f=stage/'zig/pkg/inference/src/backends/metal_kernels.m';s=f.read_text().replace('batch <= 4 && num_heads == 12 && termite_metal_lightonocr3_fast_projections(runtime)','batch <= 4 && (num_heads == 12 || num_heads == 16) && termite_metal_lightonocr3_fast_projections(runtime)');old='''(in_dim == 3072 && (out_dim == 768 || out_dim == 1024 || out_dim == 3072 ||
                           (out_dim == 2560 && rows <= 1024 &&
                            !termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_MERGER_MPP")))))''';assert old in s;s=s.replace(old,'(in_dim == 3072 && (out_dim == 768 || out_dim == 1024 || out_dim == 3072))');digest=hashlib.sha256(s.encode()).hexdigest();expected=json.loads((p/'prefilltg8_resident.json').read_text())['runtime_source_sha256'];assert digest==expected,(digest,expected);(p/'runtime_snapshots'/('metal_kernels_'+digest+'.m.gz')).write_bytes(gzip.compress(s.encode(),mtime=0));print('Captured exact prefill-candidate runtime',digest)
