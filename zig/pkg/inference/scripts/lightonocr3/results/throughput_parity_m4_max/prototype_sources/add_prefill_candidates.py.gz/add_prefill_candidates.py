from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3/benchmark_metal_pair.py';s=p.read_text().replace('"all-rows", "page-shapes"','"all-rows", "page-shapes", "prefill-gates"');s=s.replace('"previousmerger",','"previousmerger",\n            "prefill32x64",\n            "prefill64x32",\n            "prefill8x32",\n            "prefill8x16",');idx=s.index('    if args.only_candidates:\n\n        def applies(case):');s=s[:idx]+'''    if args.suite == "prefill-gates":
        cases = [(0, rows, k, n) for rows in [432,554,662] for k,n in [(1024,16),(2560,32),(2048,1024)]]
'''+s[idx:];p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/metal_pair_benchmark.m';s=p.read_text();idx=s.index('    switch (pair_variant) {',s.index('size_t ocr_pair_candidate_applies'));s=s[:idx]+'''    if(pair_variant>=52&&pair_variant<=55)return c->kind==0&&c->rows>=32&&c->rows<=2048&&
        ((c->in_dim==1024&&c->out_dim==16)||(c->in_dim==2560&&c->out_dim==32)||(c->in_dim==2048&&c->out_dim==1024));
'''+s[idx:];idx=s.index('\n',s.index('static int ocr_pair_encode_candidate(OCRPairCase *c) {'))+1;s=s[:idx]+'''    if(pair_variant>=52&&pair_variant<=55){
        termite_metal_decode_runtime*r=pair_runtime;
        id<MTLComputePipelineState>pipe=pair_variant==52?r->lightonocr3_mpp_f32_pipeline:pair_variant==53?r->lightonocr3_mpp_f32_n32_pipeline:pair_variant==54?r->lightonocr3_mpp_small_tile_pipeline:r->lightonocr3_mpp_four_row_pipeline;
        size_t tm=pair_variant==52?32:pair_variant==53?64:8,tn=pair_variant==52?64:pair_variant==55?16:32,threads=pair_variant>=54?32:128;
        if(!pipe||pipe.maxTotalThreadsPerThreadgroup<threads)return -1;
        termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
        id<MTLComputeCommandEncoder>e=termite_metal_tracked_compute_command_encoder_for(r->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);if(!e)return -1;
        termite_metal_linear_params p={(uint32_t)c->rows,(uint32_t)c->in_dim,(uint32_t)c->out_dim,0};
        [e setComputePipelineState:pipe];[e setBuffer:c->input offset:0 atIndex:0];[e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:2];[e setBuffer:c->output offset:0 atIndex:3];[e setBytes:&p length:sizeof(p) atIndex:4];
        [e dispatchThreadgroups:MTLSizeMake((c->out_dim+tn-1)/tn,(c->rows+tm-1)/tm,1) threadsPerThreadgroup:MTLSizeMake(threads,1,1)];[e endEncoding];return 0;
    }
'''+s[idx:];p.write_text(s)
