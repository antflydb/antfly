#include "../zig/pkg/inference/src/backends/metal_kernels.m"
static termite_metal_decode_runtime *vr;
static id<MTLComputePipelineState> vp,packp,vp128,vp256;
@interface VisionCase:NSObject { @public size_t seq,heads; id<MTLBuffer> q,k,v,out,packed; } @end
@implementation VisionCase @end
static NSString *vision_candidate_source(void) {return @""
 "kernel void termite_sdpa_f32_vision_hd64_flash_packed_q64k64(device const half *q [[buffer(0)]], device const half *k [[buffer(1)]], device const half *v [[buffer(2)]], device const float *bias [[buffer(3)]], device const float *mask [[buffer(4)]], device float *output [[buffer(5)]], constant termite_metal_sdpa_f32_params &p [[buffer(6)]], ushort tid [[thread_index_in_threadgroup]], ushort lane [[thread_index_in_simdgroup]], ushort sgitg [[simdgroup_index_in_threadgroup]], uint3 tg [[threadgroup_position_in_grid]]) {\n"
 "    (void)bias; (void)mask; if (p.seq_len == 0u || p.head_dim != 64u || p.bias_mode != 0u || p.has_mask != 0u || p.layout != 1u || sgitg >= 8u) return;\n"
 "    const uint query_tile_count = (p.seq_len + 63u) / 64u; const uint query_tile = tg.x % query_tile_count; const uint tmp = tg.x / query_tile_count; const uint h = tmp % p.num_heads; const uint b = tmp / p.num_heads; if (b >= p.batch) return;\n"
 "    const uint q0 = query_tile * 64u; const uint hidden = p.num_heads * 64u; const uint qgroup_base = uint(sgitg) >> 2u; const uint subgroup = uint(sgitg) & 3u; const uint dslice = subgroup * 16u; const float neg_inf = -3.402823466e+38f;\n"
 "    struct Scratch{float ss[4096];half sp[4096];float sM[64];float sS[64];float sdiag[512];};threadgroup Scratch scratch;threadgroup half*sp=scratch.sp;threadgroup float*ss=scratch.ss,*sM=scratch.sM,*sS=scratch.sS,*sdiag=scratch.sdiag,*so=(threadgroup float*)&scratch;\n"
 "    const uint head_base=(b*p.num_heads+h)*p.reserved1*64u;\n"
 "    if (tid < 64u) { sM[tid] = neg_inf; sS[tid] = 0.0f; } for(uint i=uint(tid);i<512u;i+=256u)sdiag[i]=0.0f; threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    simdgroup_float8x8 mo[4][2]; for (uint qp = 0u; qp < 4u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) mo[qp][dt] = make_filled_simdgroup_matrix<float, 8>(0.0f);\n"
 "    for (uint key_start = 0u; key_start < p.seq_len; key_start += 64u) {\n"
 "        for(uint qp=0;qp<4;qp++) {uint qgroup=qgroup_base+qp*2;\n"
 "          for(uint kp=0;kp<2;kp++) {simdgroup_float8x8 ms=make_filled_simdgroup_matrix<float,8>(0.0f);\n"
 "            #pragma unroll\n"
 "            for(uint d=0;d<8;d++){simdgroup_half8x8 mq,mk;simdgroup_load(mq,q+head_base+(q0+qgroup*8)*64+d*8,64u);simdgroup_load(mk,k+head_base+(key_start+(subgroup+kp*4)*8)*64+d*8,64u,0,true);simdgroup_multiply_accumulate(ms,mq,mk,ms);}\n"
 "            simdgroup_store(ms,ss+qgroup*512+subgroup*8+kp*32,64u);\n"
 "          }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for(uint pass=0;pass<8;pass++) {uint j=uint(sgitg)+pass*8,qi=q0+j,kk=uint(lane),ki=key_start+kk;\n"
 "          float sc0=qi<p.seq_len&&ki<p.seq_len?ss[j*64+kk]:neg_inf;\n"
 "          float sc1=qi<p.seq_len&&ki+32<p.seq_len?ss[j*64+kk+32]:neg_inf;\n"
 "          if(!isfinite(sc0))sc0=neg_inf;if(!isfinite(sc1))sc1=neg_inf;\n"
 "\n"
 "          float row_max=simd_max(max(sc0,sc1)),m_old=sM[j],m_new=max(m_old,row_max),corr=0,e0=0,e1=0;\n"
 "          if(m_new>-3.0e+38f){corr=m_old>-3.0e+38f?exp(m_old-m_new):0;e0=sc0>-3.0e+38f?exp(sc0-m_new):0;e1=sc1>-3.0e+38f?exp(sc1-m_new):0;}\n"
 "          sp[j*64+kk]=half(e0);sp[j*64+kk+32]=half(e1);\n"
 "          float row_sum=simd_sum(e0+e1);\n"
 "          if(lane==0){sS[j]=sS[j]*corr+row_sum;sM[j]=m_new;uint local_j=j&7u;sdiag[(j>>3u)*64+local_j*8+local_j]=corr;}\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 mcorr; simdgroup_load(mcorr, sdiag + qgroup * 64u, 8u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_float8x8 scaled; simdgroup_multiply(scaled, mcorr, mo[qp][dt]); mo[qp][dt] = scaled; } }\n"
 "        for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; for (uint kk8 = 0u; kk8 < 8u; ++kk8) { simdgroup_half8x8 mp; simdgroup_load(mp, sp + qgroup * 512u + kk8 * 8u, 64u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_half8x8 mv; simdgroup_load(mv, v + head_base + (key_start + kk8 * 8u) * 64u + dslice + dt * 8u, 64u); simdgroup_multiply_accumulate(mo[qp][dt], mp, mv, mo[qp][dt]); } } }\n"
 "    }\n"
 "    threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    if (tid < 64u) { const uint local_j = uint(tid) & 7u; const float denom = sS[tid]; sdiag[(uint(tid) >> 3u) * 64u + local_j * 8u + local_j] = denom > 0.0f ? 1.0f / denom : 0.0f; } threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 minv; simdgroup_load(minv, sdiag + qgroup * 64u, 8u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_float8x8 scaled; simdgroup_multiply(scaled, minv, mo[qp][dt]); mo[qp][dt] = scaled; } }\n"
 "    if (q0 + 64u <= p.seq_len) { for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; const uint output_base = (b * p.seq_len + q0 + qgroup * 8u) * hidden + h * 64u + dslice; for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], output + output_base + dt * 8u, hidden); } return; }\n"
 "    for (uint qp = 0u; qp < 4u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], so + (uint(sgitg) + qp * 8u) * 128u + dt * 8u, 16u); threadgroup_barrier(mem_flags::mem_threadgroup); const uint valid_rows = p.seq_len - q0; for (uint i = uint(tid); i < valid_rows * 64u; i += 256u) { const uint qr = i >> 6u; const uint d = i & 63u; const uint owner = (qr >> 3u) * 4u + (d >> 4u); const uint local_r = qr & 7u; const uint local_d = d & 15u; output[(b * p.seq_len + q0 + qr) * hidden + h * 64u + d] = so[owner * 128u + local_r * 16u + local_d]; }\n"
 "}\n"
 "\n"
 "kernel void termite_sdpa_f32_vision_hd64_flash_packed_q32k128(device const half *q [[buffer(0)]], device const half *k [[buffer(1)]], device const half *v [[buffer(2)]], device const float *bias [[buffer(3)]], device const float *mask [[buffer(4)]], device float *output [[buffer(5)]], constant termite_metal_sdpa_f32_params &p [[buffer(6)]], ushort tid [[thread_index_in_threadgroup]], ushort lane [[thread_index_in_simdgroup]], ushort sgitg [[simdgroup_index_in_threadgroup]], uint3 tg [[threadgroup_position_in_grid]]) {\n"
 "    (void)bias; (void)mask; if (p.seq_len == 0u || p.head_dim != 64u || p.bias_mode != 0u || p.has_mask != 0u || p.layout != 1u || sgitg >= 8u) return;\n"
 "    const uint query_tile_count = (p.seq_len + 31u) / 32u; const uint query_tile = tg.x % query_tile_count; const uint tmp = tg.x / query_tile_count; const uint h = tmp % p.num_heads; const uint b = tmp / p.num_heads; if (b >= p.batch) return;\n"
 "    const uint q0 = query_tile * 32u; const uint hidden = p.num_heads * 64u; const uint qgroup_base = uint(sgitg) >> 2u; const uint subgroup = uint(sgitg) & 3u; const uint dslice = subgroup * 16u; const float neg_inf = -3.402823466e+38f;\n"
 "    struct Scratch{float ss[4096];half sp[4096];float sM[32];float sS[32];float sdiag[256];};threadgroup Scratch scratch;threadgroup half*sp=scratch.sp;threadgroup float*ss=scratch.ss,*sM=scratch.sM,*sS=scratch.sS,*sdiag=scratch.sdiag,*so=(threadgroup float*)&scratch;\n"
 "    const uint head_base=(b*p.num_heads+h)*p.reserved1*64u;\n"
 "    if (tid < 32u) { sM[tid] = neg_inf; sS[tid] = 0.0f; } for(uint i=uint(tid);i<256u;i+=256u)sdiag[i]=0.0f; threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    simdgroup_float8x8 mo[2][2]; for (uint qp = 0u; qp < 2u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) mo[qp][dt] = make_filled_simdgroup_matrix<float, 8>(0.0f);\n"
 "    for (uint key_start = 0u; key_start < p.seq_len; key_start += 128u) {\n"
 "        for(uint qp=0;qp<2;qp++) {uint qgroup=qgroup_base+qp*2;\n"
 "          for(uint kp=0;kp<4;kp++) {simdgroup_float8x8 ms=make_filled_simdgroup_matrix<float,8>(0.0f);\n"
 "            #pragma unroll\n"
 "            for(uint d=0;d<8;d++){simdgroup_half8x8 mq,mk;simdgroup_load(mq,q+head_base+(q0+qgroup*8)*64+d*8,64u);simdgroup_load(mk,k+head_base+(key_start+(subgroup+kp*4)*8)*64+d*8,64u,0,true);simdgroup_multiply_accumulate(ms,mq,mk,ms);}\n"
 "            simdgroup_store(ms,ss+qgroup*1024+subgroup*8+kp*32,128u);\n"
 "          }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for(uint pass=0;pass<4;pass++){uint j=uint(sgitg)+pass*8,qi=q0+j,kk=uint(lane);float scores[4],exps[4];float local_max=neg_inf;\n"
 "          #pragma unroll\n"
 "          for(uint t=0;t<4;t++){uint ki=key_start+kk+t*32;float sc=qi<p.seq_len&&ki<p.seq_len?ss[j*128+kk+t*32]:neg_inf;if(!isfinite(sc))sc=neg_inf;scores[t]=sc;local_max=max(local_max,sc);}\n"
 "          float row_max=simd_max(local_max),m_old=sM[j],m_new=max(m_old,row_max),corr=0,local_sum=0;\n"
 "          if(m_new>-3.0e+38f){corr=m_old>-3.0e+38f?exp(m_old-m_new):0;\n"
 "            #pragma unroll\n"
 "            for(uint t=0;t<4;t++){exps[t]=scores[t]>-3.0e+38f?exp(scores[t]-m_new):0;local_sum+=exps[t];}\n"
 "          }else{\n"
 "            #pragma unroll\n"
 "            for(uint t=0;t<4;t++)exps[t]=0;\n"
 "          }\n"
 "          #pragma unroll\n"
 "          for(uint t=0;t<4;t++)sp[j*128+kk+t*32]=half(exps[t]);\n"
 "          float row_sum=simd_sum(local_sum);if(lane==0){sS[j]=sS[j]*corr+row_sum;sM[j]=m_new;uint local_j=j&7u;sdiag[(j>>3u)*64+local_j*8+local_j]=corr;}\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint qp = 0u; qp < 2u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 mcorr; simdgroup_load(mcorr, sdiag + qgroup * 64u, 8u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_float8x8 scaled; simdgroup_multiply(scaled, mcorr, mo[qp][dt]); mo[qp][dt] = scaled; } }\n"
 "        for (uint qp = 0u; qp < 2u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; for (uint kk8 = 0u; kk8 < 16u; ++kk8) { simdgroup_half8x8 mp; simdgroup_load(mp, sp + qgroup * 1024u + kk8 * 8u, 128u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_half8x8 mv; simdgroup_load(mv, v + head_base + (key_start + kk8 * 8u) * 64u + dslice + dt * 8u, 64u); simdgroup_multiply_accumulate(mo[qp][dt], mp, mv, mo[qp][dt]); } } }\n"
 "    }\n"
 "    threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    if (tid < 32u) { const uint local_j = uint(tid) & 7u; const float denom = sS[tid]; sdiag[(uint(tid) >> 3u) * 64u + local_j * 8u + local_j] = denom > 0.0f ? 1.0f / denom : 0.0f; } threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    for (uint qp = 0u; qp < 2u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 minv; simdgroup_load(minv, sdiag + qgroup * 64u, 8u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_float8x8 scaled; simdgroup_multiply(scaled, minv, mo[qp][dt]); mo[qp][dt] = scaled; } }\n"
 "    if (q0 + 32u <= p.seq_len) { for (uint qp = 0u; qp < 2u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; const uint output_base = (b * p.seq_len + q0 + qgroup * 8u) * hidden + h * 64u + dslice; for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], output + output_base + dt * 8u, hidden); } return; }\n"
 "    for (uint qp = 0u; qp < 2u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], so + (uint(sgitg) + qp * 8u) * 128u + dt * 8u, 16u); threadgroup_barrier(mem_flags::mem_threadgroup); const uint valid_rows = p.seq_len - q0; for (uint i = uint(tid); i < valid_rows * 64u; i += 256u) { const uint qr = i >> 6u; const uint d = i & 63u; const uint owner = (qr >> 3u) * 4u + (d >> 4u); const uint local_r = qr & 7u; const uint local_d = d & 15u; output[(b * p.seq_len + q0 + qr) * hidden + h * 64u + d] = so[owner * 128u + local_r * 16u + local_d]; }\n"
 "}\n"
 "\n"
 "kernel void termite_sdpa_f32_vision_hd64_flash_packed_q16k256(device const half *q [[buffer(0)]], device const half *k [[buffer(1)]], device const half *v [[buffer(2)]], device const float *bias [[buffer(3)]], device const float *mask [[buffer(4)]], device float *output [[buffer(5)]], constant termite_metal_sdpa_f32_params &p [[buffer(6)]], ushort tid [[thread_index_in_threadgroup]], ushort lane [[thread_index_in_simdgroup]], ushort sgitg [[simdgroup_index_in_threadgroup]], uint3 tg [[threadgroup_position_in_grid]]) {\n"
 "    (void)bias; (void)mask; if (p.seq_len == 0u || p.head_dim != 64u || p.bias_mode != 0u || p.has_mask != 0u || p.layout != 1u || sgitg >= 8u) return;\n"
 "    const uint query_tile_count = (p.seq_len + 15u) / 16u; const uint query_tile = tg.x % query_tile_count; const uint tmp = tg.x / query_tile_count; const uint h = tmp % p.num_heads; const uint b = tmp / p.num_heads; if (b >= p.batch) return;\n"
 "    const uint q0 = query_tile * 16u; const uint hidden = p.num_heads * 64u; const uint qgroup_base = uint(sgitg) >> 2u; const uint subgroup = uint(sgitg) & 3u; const uint dslice = subgroup * 16u; const float neg_inf = -3.402823466e+38f;\n"
 "    struct Scratch{float ss[4096];half sp[4096];float sM[16];float sS[16];float sdiag[128];};threadgroup Scratch scratch;threadgroup half*sp=scratch.sp;threadgroup float*ss=scratch.ss,*sM=scratch.sM,*sS=scratch.sS,*sdiag=scratch.sdiag,*so=(threadgroup float*)&scratch;\n"
 "    const uint head_base=(b*p.num_heads+h)*p.reserved1*64u;\n"
 "    if (tid < 16u) { sM[tid] = neg_inf; sS[tid] = 0.0f; } for(uint i=uint(tid);i<128u;i+=256u)sdiag[i]=0.0f; threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    simdgroup_float8x8 mo[1][2]; for (uint qp = 0u; qp < 1u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) mo[qp][dt] = make_filled_simdgroup_matrix<float, 8>(0.0f);\n"
 "    for (uint key_start = 0u; key_start < p.seq_len; key_start += 256u) {\n"
 "        for(uint qp=0;qp<1;qp++) {uint qgroup=qgroup_base+qp*2;\n"
 "          for(uint kp=0;kp<8;kp++) {simdgroup_float8x8 ms=make_filled_simdgroup_matrix<float,8>(0.0f);\n"
 "            #pragma unroll\n"
 "            for(uint d=0;d<8;d++){simdgroup_half8x8 mq,mk;simdgroup_load(mq,q+head_base+(q0+qgroup*8)*64+d*8,64u);simdgroup_load(mk,k+head_base+(key_start+(subgroup+kp*4)*8)*64+d*8,64u,0,true);simdgroup_multiply_accumulate(ms,mq,mk,ms);}\n"
 "            simdgroup_store(ms,ss+qgroup*2048+subgroup*8+kp*32,256u);\n"
 "          }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for(uint pass=0;pass<2;pass++){uint j=uint(sgitg)+pass*8,qi=q0+j,kk=uint(lane);float scores[8],exps[8];float local_max=neg_inf;\n"
 "          #pragma unroll\n"
 "          for(uint t=0;t<8;t++){uint ki=key_start+kk+t*32;float sc=qi<p.seq_len&&ki<p.seq_len?ss[j*256+kk+t*32]:neg_inf;if(!isfinite(sc))sc=neg_inf;scores[t]=sc;local_max=max(local_max,sc);}\n"
 "          float row_max=simd_max(local_max),m_old=sM[j],m_new=max(m_old,row_max),corr=0,local_sum=0;\n"
 "          if(m_new>-3.0e+38f){corr=m_old>-3.0e+38f?exp(m_old-m_new):0;\n"
 "            #pragma unroll\n"
 "            for(uint t=0;t<8;t++){exps[t]=scores[t]>-3.0e+38f?exp(scores[t]-m_new):0;local_sum+=exps[t];}\n"
 "          }else{\n"
 "            #pragma unroll\n"
 "            for(uint t=0;t<8;t++)exps[t]=0;\n"
 "          }\n"
 "          #pragma unroll\n"
 "          for(uint t=0;t<8;t++)sp[j*256+kk+t*32]=half(exps[t]);\n"
 "          float row_sum=simd_sum(local_sum);if(lane==0){sS[j]=sS[j]*corr+row_sum;sM[j]=m_new;uint local_j=j&7u;sdiag[(j>>3u)*64+local_j*8+local_j]=corr;}\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint qp = 0u; qp < 1u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 mcorr; simdgroup_load(mcorr, sdiag + qgroup * 64u, 8u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_float8x8 scaled; simdgroup_multiply(scaled, mcorr, mo[qp][dt]); mo[qp][dt] = scaled; } }\n"
 "        for (uint qp = 0u; qp < 1u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; for (uint kk8 = 0u; kk8 < 32u; ++kk8) { simdgroup_half8x8 mp; simdgroup_load(mp, sp + qgroup * 2048u + kk8 * 8u, 256u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_half8x8 mv; simdgroup_load(mv, v + head_base + (key_start + kk8 * 8u) * 64u + dslice + dt * 8u, 64u); simdgroup_multiply_accumulate(mo[qp][dt], mp, mv, mo[qp][dt]); } } }\n"
 "    }\n"
 "    threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    if (tid < 16u) { const uint local_j = uint(tid) & 7u; const float denom = sS[tid]; sdiag[(uint(tid) >> 3u) * 64u + local_j * 8u + local_j] = denom > 0.0f ? 1.0f / denom : 0.0f; } threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    for (uint qp = 0u; qp < 1u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 minv; simdgroup_load(minv, sdiag + qgroup * 64u, 8u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_float8x8 scaled; simdgroup_multiply(scaled, minv, mo[qp][dt]); mo[qp][dt] = scaled; } }\n"
 "    if (q0 + 16u <= p.seq_len) { for (uint qp = 0u; qp < 1u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; const uint output_base = (b * p.seq_len + q0 + qgroup * 8u) * hidden + h * 64u + dslice; for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], output + output_base + dt * 8u, hidden); } return; }\n"
 "    for (uint qp = 0u; qp < 1u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], so + (uint(sgitg) + qp * 8u) * 128u + dt * 8u, 16u); threadgroup_barrier(mem_flags::mem_threadgroup); const uint valid_rows = p.seq_len - q0; for (uint i = uint(tid); i < valid_rows * 64u; i += 256u) { const uint qr = i >> 6u; const uint d = i & 63u; const uint owner = (qr >> 3u) * 4u + (d >> 4u); const uint local_r = qr & 7u; const uint local_d = d & 15u; output[(b * p.seq_len + q0 + qr) * hidden + h * 64u + d] = so[owner * 128u + local_r * 16u + local_d]; }\n"
 "}\n"
 "\n"
 "kernel void vision_pack_half(device const float*q[[buffer(0)]],device const float*k[[buffer(1)]],device const float*v[[buffer(2)]],device half*out[[buffer(3)]],constant termite_metal_sdpa_f32_params&p[[buffer(4)]],uint i[[thread_position_in_grid]]){\n"
 " uint count=p.batch*p.num_heads*p.reserved1*64;if(i>=count)return;uint d=i%64,s=(i/64)%p.reserved1,h=(i/(64*p.reserved1))%p.num_heads,b=i/(64*p.reserved1*p.num_heads);uint offset=((b*p.seq_len+s)*p.num_heads+h)*64+d;\n"
 " out[i]=s<p.seq_len?half(q[offset]*0.125f):half(0);out[count+i]=s<p.seq_len?half(k[offset]):half(0);out[2*count+i]=s<p.seq_len?half(v[offset]):half(0);\n"
 "}\n"
;}
void *vision_create(size_t seq,size_t heads,const float*q,const float*k,const float*v) {
 @autoreleasepool {
 if(!vr){vr=termite_metal_decode_runtime_create();if(!vr)return NULL;
 MTLCompileOptions*o=[MTLCompileOptions new];o.languageVersion=MTLLanguageVersion4_0;o.mathMode=MTLMathModeSafe;
 NSError*err=nil;id<MTLLibrary> lib=[vr->device newLibraryWithSource:[termite_metal_shader_source() stringByAppendingString:vision_candidate_source()] options:o error:&err];
 if(!lib){fprintf(stderr,"vision candidate: %s\n",err.localizedDescription.UTF8String);return NULL;}
 packp=termite_metal_make_pipeline(vr->device,lib,@"vision_pack_half");if(!packp)return NULL;
 vp128=termite_metal_make_pipeline(vr->device,lib,@"termite_sdpa_f32_vision_hd64_flash_packed_q32k128");vp256=termite_metal_make_pipeline(vr->device,lib,@"termite_sdpa_f32_vision_hd64_flash_packed_q16k256");
 if(!vp128||!vp256)return NULL;
 fprintf(stderr,"packed_tiles bytes128=%zu bytes256=%zu\n",(size_t)vp128.staticThreadgroupMemoryLength,(size_t)vp256.staticThreadgroupMemoryLength);
 vp=termite_metal_make_pipeline(vr->device,lib,@"termite_sdpa_f32_vision_hd64_flash_packed_q64k64");
 if(!vp||vp.maxTotalThreadsPerThreadgroup<256||vp.staticThreadgroupMemoryLength>vr->device.maxThreadgroupMemoryLength)return NULL;
 fprintf(stderr,"vision_q64 threads=%zu static_bytes=%zu\n",(size_t)vp.maxTotalThreadsPerThreadgroup,(size_t)vp.staticThreadgroupMemoryLength);
 }
 VisionCase*c=[VisionCase new];c->seq=seq;c->heads=heads;size_t bytes=seq*heads*64*4;
 c->q=[vr->device newBufferWithBytes:q length:bytes options:MTLResourceStorageModeShared];
 c->k=[vr->device newBufferWithBytes:k length:bytes options:MTLResourceStorageModeShared];
 c->v=[vr->device newBufferWithBytes:v length:bytes options:MTLResourceStorageModeShared];
 c->out=[vr->device newBufferWithLength:bytes options:MTLResourceStorageModeShared];
 c->packed=[vr->device newBufferWithLength:3*((seq+255)/256*256)*heads*64*2 options:MTLResourceStorageModePrivate];
 if(!c->q||!c->k||!c->v||!c->out||!c->packed)return NULL;return (__bridge_retained void*)c;
 }}
uint64_t vision_run(void*handle,size_t candidate) {
 @autoreleasepool {VisionCase*c=(__bridge VisionCase*)handle;if(termite_metal_decode_runtime_begin_frame(vr))return 0;
 int rc=0;
 if(!candidate)rc=termite_metal_decode_runtime_sdpa_f32_device(vr,(__bridge void*)c->q,0,(__bridge void*)c->k,0,(__bridge void*)c->v,0,NULL,0,NULL,0,1,c->seq,c->heads,64,0,0,1,1,0,(__bridge void*)c->out,0);
 else{
 termite_metal_sdpa_f32_params p={1,(uint32_t)c->seq,(uint32_t)c->heads,64,0,0,1,(uint32_t)((c->seq+255)/256*256)};
 id<MTLComputeCommandEncoder>e=termite_metal_tracked_compute_command_encoder_for(vr->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_ATTENTION);if(!e)return 0;
 size_t count=p.batch*p.num_heads*p.reserved1*64;
 [e setComputePipelineState:packp];[e setBuffer:c->q offset:0 atIndex:0];[e setBuffer:c->k offset:0 atIndex:1];[e setBuffer:c->v offset:0 atIndex:2];[e setBuffer:c->packed offset:0 atIndex:3];[e setBytes:&p length:sizeof(p) atIndex:4];
 [e dispatchThreads:MTLSizeMake(count,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];[e memoryBarrierWithScope:MTLBarrierScopeBuffers];
 [e setComputePipelineState:candidate==1?vp:candidate==2?vp128:vp256];[e setBuffer:c->packed offset:0 atIndex:0];[e setBuffer:c->packed offset:count*2 atIndex:1];[e setBuffer:c->packed offset:count*4 atIndex:2];[e setBuffer:vr->optional_dummy_buffer offset:0 atIndex:3];[e setBuffer:vr->optional_dummy_buffer offset:0 atIndex:4];[e setBuffer:c->out offset:0 atIndex:5];[e setBytes:&p length:sizeof(p) atIndex:6];
 [e dispatchThreadgroups:MTLSizeMake(c->heads*((c->seq+(candidate==1?63:candidate==2?31:15))/(candidate==1?64:candidate==2?32:16)),1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];[e endEncoding];}
 if(rc||termite_metal_decode_runtime_submit_frame(vr)||termite_metal_decode_runtime_wait_frame(vr))return 0;return vr->last_frame_gpu_nanos;
 }}
const float*vision_output(void*h){return ((__bridge VisionCase*)h)->out.contents;}
void vision_release(void*h){id obj=CFBridgingRelease(h);(void)obj;}
void vision_shutdown(void){termite_metal_decode_runtime_destroy(vr);vr=NULL;vp=nil;}
