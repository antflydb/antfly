#include <metal_stdlib>
using namespace metal;
struct PairStreamParams{uint rows,in_dim,out_dim,pad;};
template<uint B,uint SN,uint U> inline void pair_stream_body(device const float*x,device const ushort*w,device const float*b,device float*y,constant PairStreamParams&p,uint group,uint sg,uint lane){
 const uint col=group*4+sg*(32/SN)+lane/SN,kLane=lane%SN;
 float acc[B];
 #pragma unroll
 for(uint r=0;r<B;r++)acc[r]=0.0f;
 const uint step=SN*4,block=step*U,full=p.in_dim/block*block;
 for(uint base=0;base<full;base+=block){
  float4 weights[U];
  #pragma unroll
  for(uint u=0;u<U;u++)weights[u]=as_type<float4>(uint4(*((device const ushort4*)(w+col*p.in_dim+base+u*step+kLane*4)))<<16);
  #pragma unroll
  for(uint r=0;r<B;r++){
   float partial=0.0f;
   #pragma unroll
   for(uint u=0;u<U;u++)partial+=dot(weights[u],*((device const float4*)(x+r*p.in_dim+base+u*step+kLane*4)));
   acc[r]+=partial;
  }
 }
 for(uint k=full+kLane*4;k<p.in_dim;k+=step){
  float4 weight=as_type<float4>(uint4(*((device const ushort4*)(w+col*p.in_dim+k)))<<16);
  #pragma unroll
  for(uint r=0;r<B;r++)acc[r]+=dot(weight,*((device const float4*)(x+r*p.in_dim+k)));
 }
 #pragma unroll
 for(uint r=0;r<B;r++){
  float v=acc[r];
  #pragma unroll
  for(uint d=SN/2;d>0;d/=2)v+=simd_shuffle_xor(v,d);
  if(kLane==0)y[r*p.out_dim+col]=v+b[col];
 }
}
#define ST(B,SN,U) kernel void pair_stream_##B##_##SN##_##U(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant PairStreamParams&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){pair_stream_body<B,SN,U>(x,w,b,y,p,group,sg,lane);}
#define SB(B) ST(B,8,4) ST(B,16,4) ST(B,32,4) ST(B,8,8) ST(B,16,8) ST(B,32,8)
SB(1) SB(2) SB(3) SB(4) SB(5) SB(6) SB(7) SB(8)
#undef SB
#undef ST
