import sys,subprocess,os,re,json
from pathlib import Path
r=Path.cwd();h=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_parity_m4_max';text=Path('/private/tmp/ocr-parity-actual-build.txt').read_text();binary=r/'zig/.zig-cache/o'/re.findall(r'\.zig-cache/o/([0-9a-f]{32})/test(?:\s|$)',text)[-1]/'test';env=os.environ.copy();env['OCR_BUILD_MANIFEST']=str(out/'actual_build_manifest.json')
for short in ['08','4b']:
 name=short+'_actual_combined';print('START',name,flush=True);subprocess.run([sys.executable,str(h/'run_actual_round.py'),str(binary),name],env=env,check=True);d=json.loads((out/('native_'+name)/'report.json').read_text());print('RESULT',name,d['results'][0]['status'],d['results'][0].get('pages_per_second'),flush=True)
for flush,label in [(0,'resident'),(64,'cold64')]:
 name='actual_decode_shapes_'+label;print('START',name,flush=True)
 cmd=[sys.executable,str(p/'benchmark_metal_pair.py'),'--native-library',str(h/'metal_pair_actual_final.dylib'),'--timing-library',str(h/'metal_timing_qualified.dylib'),'--suite','decode-shapes','--trials','30','--variant','production','--cache-flush-mib',str(flush),'--output',str(out/(name+'.json'))]
 with open('/private/tmp/ocr-parity-'+name+'.txt','w')as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
