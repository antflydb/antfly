import re,sys,subprocess,json,hashlib,os,time
from pathlib import Path
r=Path.cwd();h=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max';sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
log=Path('/private/tmp/ocr-parity-vision-build.txt')
while True:
 s=log.read_text();hits=re.findall(r'\.zig-cache/o/([0-9a-f]{32})/test(?:\s|$)',s)
 if hits:break
 if 'error:' in s:raise SystemExit(s[-4000:])
 time.sleep(5)
f=json.loads((h/'vision-kernels-freeze.json').read_text());assert all(sha(k)==v for k,v in f.items()),'Runtime edited during build';binary=r/'zig/.zig-cache/o'/hits[-1]/'test';base='58d7e441dd3c2f19584d99b5baa321659a387ef7'
m=dict(runtime_commit=base,runtime_source_diff_sha256=hashlib.sha256(subprocess.check_output(['git','diff',base,'--','zig/pkg/inference/src'])).hexdigest(),binary_sha256=sha(binary),runtime_files_sha256=f)
(p/'vision_build_manifest.json').write_text(json.dumps(m,indent=2)+'\n')
s=(h/'local_gpu_tests.py').read_text().replace('0dfe2362a7d763223b0619f4f49584f2',hits[-1]).replace('ocr-parity-local-gpu-tests','ocr-parity-vision-gpu-tests');s=s.replace('"decode GQA split"]','"decode GQA split", "LightOnOCR3 admission charges"]');driver=h/'vision_gpu_tests.py';driver.write_text(s);print('START',binary,flush=True);subprocess.run([sys.executable,str(driver)],check=True);print('DONE GPU tests',flush=True)
