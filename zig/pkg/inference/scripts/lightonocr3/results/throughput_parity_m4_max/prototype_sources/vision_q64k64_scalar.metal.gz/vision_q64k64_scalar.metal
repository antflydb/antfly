kernel void termite_sdpa_f32_vision_hd64_flash_q64k64_scalar(device const float *q [[buffer(0)]], device const float *k [[buffer(1)]], device const float *v [[buffer(2)]], device const float *bias [[buffer(3)]], device const float *mask [[buffer(4)]], device float *output [[buffer(5)]], constant termite_metal_sdpa_f32_params &p [[buffer(6)]], ushort tid [[thread_index_in_threadgroup]], ushort lane [[thread_index_in_simdgroup]], ushort sgitg [[simdgroup_index_in_threadgroup]], uint3 tg [[threadgroup_position_in_grid]]) {
    (void)bias; (void)mask; if (p.seq_len == 0u || p.head_dim != 64u || p.bias_mode != 0u || p.has_mask != 0u || p.layout != 1u || sgitg >= 8u) return;
    const uint query_tile_count = (p.seq_len + 63u) / 64u; const uint query_tile = tg.x % query_tile_count; const uint tmp = tg.x / query_tile_count; const uint h = tmp % p.num_heads; const uint b = tmp / p.num_heads; if (b >= p.batch) return;
    const uint q0 = query_tile * 64u; const uint hidden = p.num_heads * 64u; const uint qgroup_base = uint(sgitg) >> 2u; const uint subgroup = uint(sgitg) & 3u; const uint dslice = subgroup * 16u; const float neg_inf = -3.402823466e+38f;
    struct Scratch {half skv[4096];float ss[4096];float sM[64];float sS[64];float sdiag[512];};threadgroup Scratch scratch;threadgroup half *sq=(threadgroup half*)&scratch,*skv=scratch.skv,*sp=(threadgroup half*)scratch.ss;threadgroup float *ss=scratch.ss,*sM=scratch.sM,*sS=scratch.sS,*sdiag=scratch.sdiag;threadgroup float *so=(threadgroup float*)&scratch;
    for (uint i = uint(tid); i < 4096u; i += 256u) { const uint qr = i >> 6u; const uint d = i & 63u; const uint qi = q0 + qr; sq[i] = qi < p.seq_len ? half(q[(b * p.seq_len + qi) * hidden + h * 64u + d] * 0.125f) : half(0.0f); }
    if (tid < 64u) { sM[tid] = neg_inf; sS[tid] = 0.0f; } if(tid<64u)sdiag[tid]=float(tid/8u); threadgroup_barrier(mem_flags::mem_threadgroup);
    simdgroup_half8x8 cached_q[4][8];
    #pragma unroll
    for(uint qp=0;qp<4;qp++){
      uint qgroup=qgroup_base+qp*2;
      #pragma unroll
      for(uint d=0;d<8;d++)simdgroup_load(cached_q[qp][d],sq+qgroup*512+d*8,64u);
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    simdgroup_float8x8 row_ids;simdgroup_load(row_ids,sdiag,8u);
    const uint fragment_row0=uint(row_ids.thread_elements()[0]),fragment_row1=uint(row_ids.thread_elements()[1]);
    threadgroup_barrier(mem_flags::mem_threadgroup);
    simdgroup_float8x8 mo[4][2]; for (uint qp = 0u; qp < 4u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) mo[qp][dt] = make_filled_simdgroup_matrix<float, 8>(0.0f);
    for (uint key_start = 0u; key_start < p.seq_len; key_start += 64u) {
        for (uint i = uint(tid); i < 4096u; i += 256u) { const uint kr = i >> 6u; const uint d = i & 63u; const uint ki = key_start + kr; skv[i] = ki < p.seq_len ? half(k[(b * p.seq_len + ki) * hidden + h * 64u + d]) : half(0.0f); }
        threadgroup_barrier(mem_flags::mem_threadgroup);
        for(uint qp=0;qp<4;qp++) {uint qgroup=qgroup_base+qp*2;
          for(uint kp=0;kp<2;kp++) {simdgroup_float8x8 ms=make_filled_simdgroup_matrix<float,8>(0.0f);
            #pragma unroll
            for(uint d=0;d<8;d++){simdgroup_half8x8 mk;simdgroup_load(mk,skv+(subgroup+kp*4)*512+d*8,64u,0,true);simdgroup_multiply_accumulate(ms,cached_q[qp][d],mk,ms);}
            simdgroup_store(ms,ss+qgroup*512+subgroup*8+kp*32,64u);
          }
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
        for(uint pass=0;pass<8;pass++) {uint j=uint(sgitg)+pass*8,qi=q0+j,kk=uint(lane),ki=key_start+kk;
          float sc0=qi<p.seq_len&&ki<p.seq_len?ss[j*64+kk]:neg_inf;
          float sc1=qi<p.seq_len&&ki+32<p.seq_len?ss[j*64+kk+32]:neg_inf;
          if(!isfinite(sc0))sc0=neg_inf;if(!isfinite(sc1))sc1=neg_inf;
          simdgroup_barrier(mem_flags::mem_threadgroup);
          float row_max=simd_max(max(sc0,sc1)),m_old=sM[j],m_new=max(m_old,row_max),corr=0,e0=0,e1=0;
          if(m_new>-3.0e+38f){corr=m_old>-3.0e+38f?exp(m_old-m_new):0;e0=sc0>-3.0e+38f?exp(sc0-m_new):0;e1=sc1>-3.0e+38f?exp(sc1-m_new):0;}
          sp[j*128+kk]=half(e0);sp[j*128+kk+32]=half(e1);
          float row_sum=simd_sum(e0+e1);
          if(lane==0){sS[j]=sS[j]*corr+row_sum;sM[j]=m_new;uint local_j=j&7u;sdiag[(j>>3u)*64+local_j*8+local_j]=corr;}
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
        for(uint qp=0;qp<4;qp++){uint qgroup=qgroup_base+qp*2;float a=sdiag[qgroup*64+fragment_row0*9],b=sdiag[qgroup*64+fragment_row1*9];for(uint dt=0;dt<2;dt++){mo[qp][dt].thread_elements()[0]*=a;mo[qp][dt].thread_elements()[1]*=b;}}
        for (uint i = uint(tid); i < 4096u; i += 256u) { const uint kr = i >> 6u; const uint d = i & 63u; const uint ki = key_start + kr; skv[i] = ki < p.seq_len ? half(v[(b * p.seq_len + ki) * hidden + h * 64u + d]) : half(0.0f); }
        threadgroup_barrier(mem_flags::mem_threadgroup);
        for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; for (uint kk8 = 0u; kk8 < 8u; ++kk8) { simdgroup_half8x8 mp; simdgroup_load(mp, sp + qgroup * 1024u + kk8 * 8u, 128u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_half8x8 mv; simdgroup_load(mv, skv + kk8 * 512u + dslice + dt * 8u, 64u); simdgroup_multiply_accumulate(mo[qp][dt], mp, mv, mo[qp][dt]); } } }
        threadgroup_barrier(mem_flags::mem_threadgroup);
    }
    if (tid < 64u) { const uint local_j = uint(tid) & 7u; const float denom = sS[tid]; sdiag[(uint(tid) >> 3u) * 64u + local_j * 8u + local_j] = denom > 0.0f ? 1.0f / denom : 0.0f; } threadgroup_barrier(mem_flags::mem_threadgroup);
        for(uint qp=0;qp<4;qp++){uint qgroup=qgroup_base+qp*2;float a=sdiag[qgroup*64+fragment_row0*9],b=sdiag[qgroup*64+fragment_row1*9];for(uint dt=0;dt<2;dt++){mo[qp][dt].thread_elements()[0]*=a;mo[qp][dt].thread_elements()[1]*=b;}}
    if (q0 + 64u <= p.seq_len) { for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; const uint output_base = (b * p.seq_len + q0 + qgroup * 8u) * hidden + h * 64u + dslice; for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], output + output_base + dt * 8u, hidden); } return; }
    for (uint qp = 0u; qp < 4u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], so + (uint(sgitg) + qp * 8u) * 128u + dt * 8u, 16u); threadgroup_barrier(mem_flags::mem_threadgroup); const uint valid_rows = p.seq_len - q0; for (uint i = uint(tid); i < valid_rows * 64u; i += 256u) { const uint qr = i >> 6u; const uint d = i & 63u; const uint owner = (qr >> 3u) * 4u + (d >> 4u); const uint local_r = qr & 7u; const uint local_d = d & 15u; output[(b * p.seq_len + q0 + qr) * hidden + h * 64u + d] = so[owner * 128u + local_r * 16u + local_d]; }
}
