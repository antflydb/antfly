from pathlib import Path
import gzip,subprocess
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max';(p/'attention12_experiment_runtime.patch.gz').write_bytes(gzip.compress(subprocess.check_output(['git','diff','58d7e441dd3c2f19584d99b5baa321659a387ef7','--','zig/pkg/inference/src']),mtime=0))
c=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=c.read_text().replace('batch <= 4 && num_heads == 12 && termite_metal_lightonocr3_fast_projections(runtime)','batch <= 4 && (num_heads == 12 || num_heads == 16) && termite_metal_lightonocr3_fast_projections(runtime)');old='''(in_dim == 3072 && (out_dim == 768 || out_dim == 1024 || out_dim == 3072 ||
                           (out_dim == 2560 && rows <= 1024 &&
                            !termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_MERGER_MPP")))))''';assert old in s;s=s.replace(old,'(in_dim == 3072 && (out_dim == 768 || out_dim == 1024 || out_dim == 3072))');c.write_text(s)
p=r/'zig/pkg/inference/src/architectures/qwen3vl_projector.zig';s=p.read_text().replace('if (vision_hidden == 768 and head_count == 12 and max_patch_tokens > 256 and max_patch_tokens <= 4096)', 'if (((vision_hidden == 768 and head_count == 12) or (vision_hidden == 1024 and head_count == 16)) and\n        max_patch_tokens > 256 and max_patch_tokens <= 4096)');a=s.index('test "LightOnOCR3 admission charges packed');b=s.index('\ntest ',a+5);s=s[:a]+'''test "LightOnOCR3 admission charges packed vision storage beyond FFN and score peaks" {
    for ([_]usize{768,1024}) |vision_hidden| {
        const text_hidden: usize = if (vision_hidden == 768) 1024 else 2560;
        const config = gpt_config.Config{
            .family = .qwen3_5,
            .hidden_size = @intCast(text_hidden),
            .vision_hidden_size = @intCast(vision_hidden),
            .vision_intermediate_size = @intCast(vision_hidden*4),
            .vision_num_attention_heads = @intCast(vision_hidden/64),
            .vision_patch_size = 16,
            .vision_spatial_merge_size = 2,
        };
        // Non-aligned geometry covers padded packing rows as well as both
        // checkpoint encoder widths, independently of the score/FFN maximum.
        const geometry = try targetGeometryForLayout(16,2,1000,768,.{});
        const patches=geometry.patchCount();
        const estimate=try estimateAdmissionForImageDimensions(&.{.{.width=1000,.height=768}},config,.{});
        const hidden=patches*vision_hidden*@sizeOf(f32);
        const scores=patches*patches*(vision_hidden/64)*@sizeOf(f32);
        const ffn=patches*(vision_hidden*4)*@sizeOf(f32)*2;
        const merge=geometry.tokenCount()*(vision_hidden*4*3+text_hidden)*@sizeOf(f32);
        const packed_pair=std.mem.alignForward(usize,patches,128)*vision_hidden*3*2*@sizeOf(u16);
        try std.testing.expectEqual(7*hidden+@max(scores,ffn)+merge+packed_pair,estimate.backend_scratch_bytes);
    }
}
''' +s[b:];p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/check_metal_vision.m';s=p.read_text().replace('size_t batch, seq, count;', 'size_t batch, seq, heads, count;').replace('static VisionCheck *make_case(termite_metal_decode_runtime *r, size_t batch, size_t seq)', 'static VisionCheck *make_case_heads(termite_metal_decode_runtime *r, size_t batch, size_t seq, size_t heads)').replace('c->count = batch * seq * 12 * 64;', 'c->heads = heads;\n    c->count = batch * seq * heads * 64;').replace('* 12 +', '* c->heads +').replace('% 12,', '% c->heads,').replace('c->seq, 12, 64,', 'c->seq, c->heads, 64,');i=s.index('static int encode_case');s=s[:i]+'''static VisionCheck *make_case(termite_metal_decode_runtime*r,size_t batch,size_t seq){return make_case_heads(r,batch,seq,12);}
'''+s[i:];needle='        run_case(r, make_case(r, 1, 2592), YES);';s=s.replace(needle,needle+'''\n        for(size_t b=1;b<=4;b++)run_case(r,make_case_heads(r,b,b==1?257:b==2?578:b==3?1672:2160,16),YES);
        run_case(r,make_case_heads(r,1,2592,16),YES);run_case(r,make_case_heads(r,1,4095,16),YES);run_case(r,make_case_heads(r,1,4096,16),YES);
''');p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m';s=p.read_text();a=s.index('        // The 4B image merger');b=s.index('        if(cached_norm_views_check',a);s=s[:a]+s[b:];p.write_text(s)
