from pathlib import Path
import json
h=Path('.venv-lighton-vllm-metal');p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_metal_pair.py');s=p.read_text().replace('"decodetg",','"decodetg",\n            "decodetiled",\n            "decodef32mma32",\n            "decodef32mma64",');s=s.replace('if args.variant.startswith("decodevec"):', 'if args.variant.startswith("decodevec") or args.variant=="decodetiled":');p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/metal_pair_benchmark.m');s=p.read_text().replace('pair_variant>=64&&pair_variant<=69','pair_variant>=64&&pair_variant<=72').replace('(pair_variant==64||pair_variant==65)?2:1','(pair_variant==64||pair_variant==65||pair_variant==70)?2:1').replace('(pair_variant<68||(tiny&&(pair_variant!=68||c->rows==1)))','(pair_variant<68||pair_variant>=70||(tiny&&(pair_variant!=68||c->rows==1)))');a=s.index('static int ocr_pair_encode_candidate(');shader=(h/'decode_f32_mma.metal').read_text();s=s[:a]+'static NSString *pair_decode_mma_source(void){return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n'for x in shader.splitlines())+';}\n'+s[a:];a=s.index('\n',s.index('static int ocr_pair_encode_candidate(OCRPairCase *c) {'))+1;s=s[:a]+'''    if(pair_variant>=70&&pair_variant<=72){
        termite_metal_decode_runtime*r=pair_runtime;size_t columns=pair_variant==70?(c->rows<=4?2:4):c->out_dim==16?16:c->out_dim==32?32:pair_variant==71?32:64,threads=pair_variant==70?32:columns/8*32;
        id<MTLComputePipelineState>pipe=nil;
        if(pair_variant==70)pipe=r->lightonocr3_tiled_pipelines[c->rows];
        else{static id<MTLComputePipelineState>pipelines[3];if(!pipelines[0]){MTLCompileOptions*o=[MTLCompileOptions new];o.languageVersion=MTLLanguageVersion4_0;o.mathMode=MTLMathModeFast;NSError*err=nil;
            id<MTLLibrary>lib=[r->device newLibraryWithSource:pair_decode_mma_source() options:o error:&err];if(!lib){fprintf(stderr,"decode MMA: %s\\n",err.localizedDescription.UTF8String);return -1;}
            for(size_t i=0;i<3;i++)pipelines[i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"pair_decode_mma%zu",2ul<<i]);}
            pipe=pipelines[columns==16?0:columns==32?1:2];}
        if(!pipe||pipe.maxTotalThreadsPerThreadgroup<threads)return -1;
        termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
        id<MTLComputeCommandEncoder>e=termite_metal_tracked_compute_command_encoder_for(r->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);if(!e)return -1;
        termite_metal_linear_params p={(uint32_t)c->rows,(uint32_t)c->in_dim,(uint32_t)c->out_dim,0};[e setComputePipelineState:pipe];[e setBuffer:c->input offset:0 atIndex:0];[e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:2];[e setBuffer:c->output offset:0 atIndex:3];[e setBytes:&p length:sizeof(p) atIndex:4];[e dispatchThreadgroups:MTLSizeMake((c->out_dim+columns-1)/columns,1,1) threadsPerThreadgroup:MTLSizeMake(threads,1,1)];[e endEncoding];return 0;
    }
'''+s[a:];p.write_text(s)
s=(h/'run_observed_decode_candidates.py').read_text().replace("['decodevec16x2','decodevec32x4','decodempp16','decodempp32','decodegemv1','decodetg']","['decodetiled','decodef32mma32','decodef32mma64']").replace("variant=='decodevec16x2'","variant=='decodetiled'").replace('metal_pair_observed_decode','metal_pair_decode_mma');(h/'run_decode_mma_candidates.py').write_text(s)
