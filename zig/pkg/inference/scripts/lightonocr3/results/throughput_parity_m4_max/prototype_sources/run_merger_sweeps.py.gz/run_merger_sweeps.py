import sys,subprocess
from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_parity_m4_max'
for label,variant,flush,compile in [('merger_previous_vs_current_resident','previousmerger',0,True),('merger_previous_vs_current_cold64','previousmerger',64,False)]:
 print('START',label,flush=True)
 cmd=[sys.executable,str(p/'benchmark_metal_pair.py'),'--native-library',str(r/'.venv-lighton-vllm-metal/metal_pair_merger_final.dylib'),'--timing-library',str(r/'.venv-lighton-vllm-metal/metal_timing_qualified.dylib'),'--suite','page-shapes','--trials','30','--variant',variant,'--compare-production','--cache-flush-mib',str(flush),'--output',str(out/(label+'.json'))]
 if compile:cmd+=['--compile-native-library']
 with open('/private/tmp/ocr-parity-'+label+'.txt','w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)
