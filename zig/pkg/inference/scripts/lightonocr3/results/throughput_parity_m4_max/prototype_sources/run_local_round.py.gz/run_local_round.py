import subprocess,sys,os
from pathlib import Path
root=Path.cwd();script=root/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';results=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max';references=root/'zig/pkg/inference/scripts/lightonocr3/results/kernel_saturation_m4_max';models=root/'.venv-lighton-vllm-metal/ocr-models'
images=['zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png','zig/pkg/inference/scripts/lightonocr3/corpus/receipt.png','zig/pkg/inference/scripts/lightonocr3/corpus/shipping.png']
disable=['--disable-down-split','--disable-prefill-conv-vec4','--disable-four-row-tile']
cases={
 '08_control':('lighton08',models/'lighton08',4,[],'vllm_08'),
 '4b_control':('lighton4b',models/'lighton4b',4,[],'vllm_4b'),
 '08_resident':('lighton08',models/'lighton08',4,['--weight-residency'],'vllm_08'),
 '4b_resident':('lighton4b',models/'lighton4b',4,['--weight-residency'],'vllm_4b'),
 '08_ablation_retry':('lighton08',models/'lighton08',4,disable,'vllm_08'),
 '08_retry':('lighton08',models/'lighton08',4,[],'vllm_08'),
 '4b_ablation_retry':('lighton4b',models/'lighton4b',4,disable,'vllm_4b'),
 '4b_retry':('lighton4b',models/'lighton4b',4,[],'vllm_4b'),
 'florence_f16':('florence',Path('/Users/ajroetker/.antfly/inference/models/antflydb/florence-2-base'),8,[],'mlx_florence'),
 'florence_f16_ablation':('florence',Path('/Users/ajroetker/.antfly/inference/models/antflydb/florence-2-base'),8,['--disable-f16-encoder-mpp'],'mlx_florence'),
 '08':('lighton08',models/'lighton08',4,[],'vllm_08'),
 '08_ablation':('lighton08',models/'lighton08',4,disable,'vllm_08'),
 '4b':('lighton4b',models/'lighton4b',4,[],'vllm_4b'),
 '4b_ablation':('lighton4b',models/'lighton4b',4,disable,'vllm_4b'),
 'florence':('florence',Path('/Users/ajroetker/.antfly/inference/models/antflydb/florence-2-base'),8,[],'mlx_florence'),
 'florence_profile':('florence',Path('/Users/ajroetker/.antfly/inference/models/antflydb/florence-2-base'),8,['--profile-reader'],'mlx_florence'),
 '4b_resident_profile':('lighton4b',models/'lighton4b',4,['--profile-reader','--weight-residency'],'vllm_4b'),
 '08_profile':('lighton08',models/'lighton08',4,['--profile-reader'],'vllm_08'),
}
cases['08_rollback']=('lighton08',models/'lighton08',4,['--weight-residency','--disable-batch-gate-up','--disable-prefill-columns','--disable-prefill-norm','--disable-single-down-tile','--disable-four-row-split'],'vllm_08')
cases['4b_rollback']=('lighton4b',models/'lighton4b',4,['--weight-residency','--disable-batch-gate-up','--disable-prefill-columns','--disable-prefill-norm','--disable-single-down-tile','--disable-four-row-split'],'vllm_4b')
cases['08_bf16_prefill']=('lighton08',models/'lighton08',4,['--weight-residency','--bf16-prefill-inputs'],'vllm_08')
cases['4b_bf16_prefill']=('lighton4b',models/'lighton4b',4,['--weight-residency','--bf16-prefill-inputs'],'vllm_4b')
cases['4b_resident_retry']=cases['4b_resident']
cases['4b_rollback_retry']=cases['4b_rollback']
cases['08_profile_final']=('lighton08',models/'lighton08',4,['--weight-residency','--profile-reader'],'vllm_08')
cases['08_final']=cases['08_resident']
cases['08_final_rollback']=cases['08_rollback']
cases['4b_final']=cases['4b_resident']
cases['4b_final_rollback']=cases['4b_rollback']
cases['4b_profile_final']=('lighton4b',models/'lighton4b',4,['--weight-residency','--profile-reader'],'vllm_4b')
cases['florence_f16_repeat']=cases['florence_f16']
cases['florence_f16_ablation_repeat']=cases['florence_f16_ablation']
cases['08_wave_prototype']=cases['08_resident']
cases['4b_stream_prototype']=('lighton4b',models/'lighton4b',4,['--weight-residency','--continuous'],'vllm_4b')
cases['4b_wave_prototype']=cases['4b_resident']
cases['4b_stream_hardened']=cases['4b_stream_prototype']
cases['08_stream_hardened']=('lighton08',models/'lighton08',4,['--weight-residency','--continuous'],'vllm_08')
cases['08_vision_resident']=('lighton08',models/'lighton08',4,['--weight-residency','--continuous','--vision-batch'],'vllm_08')
cases['4b_vision_resident']=('lighton4b',models/'lighton4b',4,['--weight-residency','--continuous','--vision-batch'],'vllm_4b')
for key,label in [('08','lighton08'),('4b','lighton4b')]:
 for suffix,extra in [('prefill_only',['--prefill-batch']),('combined',['--vision-batch','--prefill-batch']),('refill_control',[]),('wave_control',None),('direct_kv',['--prefill-sg-attention','--prefill-direct-kv']),('refill_c16',[]),('refill_rows4',[]),('refill_no_split',['--disable-gate-up-split'])]:
  flags=['--weight-residency']+([] if extra is None else ['--continuous',*extra])
  cases[key+'_'+suffix]=(label,models/label,4,flags,'vllm_'+key)
cases['08_refill_profile']=('lighton08',models/'lighton08',4,['--weight-residency','--continuous','--profile-reader'],'vllm_08')

for short,label in [('08','lighton08'),('4b','lighton4b')]:
 for variant in ['off1','on','off2','profile']:
  flags=['--weight-residency','--continuous']
  if variant.startswith('off'):flags+=['--disable-local-kernels']
  if variant=='profile':flags+=['--profile-reader','--require-small-tail-fusion']
  for attempt in range(1,4):cases[short+'_local_'+variant+'_attempt'+str(attempt)]=(label,models/label,4,flags,'vllm_'+short)
cases['florence_local']=cases['florence_f16']

for name in sys.argv[2:]:
 label,model,scratch,flags,ref=cases[name]
 reference=results/(ref+'_local_reference')/'report.json'
 if not reference.exists():reference=references/(ref+'_refresh')/'report.json'
 command=[sys.executable,str(script),'--native-test',str(Path(sys.argv[1]).resolve()),'--model',f'{label}={model}','--images',*images,'--requests','8' if 'profile' in name else os.environ.get('OCR_REQUESTS','16'),'--concurrency',os.environ.get('OCR_CONCURRENCY','8'),'--max-tokens','256','--modes','batch','--batch-rows',os.environ.get('OCR_ROWS','8'),'--batch-window',os.environ.get('OCR_WINDOW','8'),'--batch-wait-us','20000','--memory-gib','24','--shared-memory-gib','28','--backend-memory-gib','16','--kv-memory-gib','4','--scratch-memory-gib',str(scratch),'--timeout','360','--reference-report',str(reference),'--output-dir',str(results/('native_'+name)),*flags]
 if os.environ.get('OCR_BUILD_MANIFEST'):command+=['--build-manifest',os.environ['OCR_BUILD_MANIFEST']]
 if 'profile' in name:command=['env','TERMITE_METAL_TRACE_ENCODER_TIMING=1','TERMITE_METAL_TRACE_DISPATCH_PROFILE=1',*command]
 print('START',name,flush=True)
 with open('/private/tmp/ocr-projection-native-'+name+'.txt','w') as f:result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 print('DONE',name,result.returncode,flush=True)
