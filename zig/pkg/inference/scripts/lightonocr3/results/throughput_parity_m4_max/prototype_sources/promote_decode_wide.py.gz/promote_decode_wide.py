from pathlib import Path
import json
p=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max');prefixes=['decodechunk4s16t2','decodechunk4s16t4','decodechunk4s32t4','decodechunk4s32t8','decodechunk2s16t4','decodechunk2s32t8','decodeexact4s16t2','decodeexact4s16t4','decodeexact4s32t4','decodeexact4s32t8','decodeexact2s16t4','decodeexact2s32t8'];data={}
for i,name in enumerate(prefixes):
 for cache in ['resident','cold64']:
  d=json.loads((p/(name+'_'+cache+'.json')).read_text())
  for x in d['results']:data.setdefault((x['in'],x['out'],x['rows']),{}).setdefault(i,{})[cache]=x
shapes=[(2048,1024),(1024,2048),(1024,512),(1024,4096),(4096,2560),(2560,4096),(2560,1024)];table=[];results=[]
for k,n in shapes:
 row=[]
 for r in range(2,9):
  options=[(max(x['median_native_over_production']for x in caches.values()),i,caches)for i,caches in data[(k,n,r)].items()if len(caches)==2];gain,i,caches=min(options,key=lambda t:t[:2]);assert gain<.98,(k,n,r,gain);row.append(i);results.append(dict(input=k,output=n,rows=r,variant=prefixes[i],new_over_old_by_cache={c:x['median_native_over_production']for c,x in caches.items()},new_over_mlx_by_cache={c:x['median_native_over_mlx']for c,x in caches.items()}))
 table.append(row)
(p/'promoted_decode_candidate_selection.json').write_text(json.dumps(dict(scope='Candidate selection for final production requalification; minimum worst median new/old ratio across both cache policies.',shapes=shapes,variant_table=table,variants=prefixes,results=results),indent=2)+'\n')
f=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=f.read_text();s=s.replace('    id<MTLComputePipelineState> lightonocr3_recurrent_gate_vectors[2][8];','    id<MTLComputePipelineState> lightonocr3_recurrent_gate_vectors[2][8];\n    id<MTLComputePipelineState> lightonocr3_decode_chunks[4][4],lightonocr3_decode_tails[6][3];')
shader=Path('.venv-lighton-vllm-metal/decode_exact.metal').read_text();shader=shader[shader.index('template<uint B'):];shader=shader.replace('pair_exact','termite_lightonocr3_decode').replace('PairChunkParams','termite_lightonocr3_local_params');chunk=Path('.venv-lighton-vllm-metal/decode_chunk.metal').read_text();chunk=chunk[chunk.index('#define CH'):].replace('pair_chunk_body','termite_lightonocr3_decode_body').replace('pair_chunk','termite_lightonocr3_chunk').replace('PairChunkParams','termite_lightonocr3_local_params');shader+=chunk
anchor='           "template<uint B,uint SN,uint TM,bool GATE>';a=s.index(anchor);s=s[:a]+''.join('           '+json.dumps(line+'\n')+'\n'for line in shader.splitlines())+s[a:]
a=s.index('            for(size_t model=0;model<2;model++)for(size_t row=0;row<8;row++)');b=s.index('\n',s.index('runtime->lightonocr3_recurrent_gate_vectors',a))+1;s=s[:b]+'''            const size_t caps[6]={4,4,4,4,2,2},lanes[6]={16,16,32,32,16,32},tiles[6]={2,4,4,8,4,8};
            for(size_t tile=0;tile<4;tile++)for(size_t row=0;row<4;row++)
                runtime->lightonocr3_decode_chunks[tile][row]=termite_metal_make_pipeline(device,library,[NSString stringWithFormat:@"termite_lightonocr3_chunk_%zu_%zu_%zu",row+1,lanes[tile],tiles[tile]]);
            for(size_t tile=0;tile<6;tile++)for(size_t row=0;row<3;row++)
                runtime->lightonocr3_decode_tails[tile][row]=termite_metal_make_pipeline(device,library,[NSString stringWithFormat:@"termite_lightonocr3_decode_%zu_%zu_%zu_%zu",row+5,caps[tile],lanes[tile],tiles[tile]]);
'''+s[b:]
a=s.index('    for(size_t model=0;model<2;model++)for(size_t row=0;row<8;row++)runtime->lightonocr3_recurrent_gate_vectors[model][row]=nil;');b=s.index('\n',a)+1;s=s[:b]+'''    for(size_t tile=0;tile<4;tile++)for(size_t row=0;row<4;row++)runtime->lightonocr3_decode_chunks[tile][row]=nil;
    for(size_t tile=0;tile<6;tile++)for(size_t row=0;row<3;row++)runtime->lightonocr3_decode_tails[tile][row]=nil;
'''+s[b:]
a=s.index('static int termite_metal_try_lightonocr3_local_projection(');b=s.index('static int termite_metal_try_lightonocr3_down_split',a);v=s[a:b];v=v.replace('    const bool qkv =','''    // Each row chooses a qualified register tile; partial groups either mask
    // stores or use an exact tail specialization, without rounding activations.
    static const size_t decode_shapes[7][2] = '''+json.dumps(shapes).replace('[','{').replace(']','}')+''';
    static const uint8_t decode_tiles[7][7] = '''+json.dumps(table).replace('[','{').replace(']','}')+''';
    size_t decode_shape=7;
    for(size_t shape=0;shape<7;shape++)if(in==decode_shapes[shape][0]&&out==decode_shapes[shape][1]){decode_shape=shape;break;}
    const bool decode_projection=rows>=2&&decode_shape<7;
    const bool qkv =''',1);v=v.replace('size_t columns = 16, threads = 128, memory = 0;', 'size_t columns = 16, threads = 128, memory = 0, row_groups = 1;');v=v.replace('    } else if (rows <= 4 && (qkv || ffn)) {','''    } else if (decode_projection) {
        const size_t variant=decode_tiles[decode_shape][rows-2],tile=variant%6;
        const size_t caps[6]={4,4,4,4,2,2},lanes[6]={16,16,32,32,16,32},tiles[6]={2,4,4,8,4,8};
        const size_t batch=MIN(rows,caps[tile]),family=tile<4?tile:tile==4?1:3;
        p=variant>=6?r->lightonocr3_decode_tails[tile][rows-5]:r->lightonocr3_decode_chunks[family][batch-1];
        columns=4*(32/lanes[tile])*tiles[tile];
        row_groups=(rows+batch-1)/batch;
    } else if (rows <= 4 && (qkv || ffn)) {''',1);v=v.replace('MTLSizeMake(out / columns, 1, 1)','MTLSizeMake(out / columns, row_groups, 1)');v=v.replace('recurrent_gate ? "lightonocr3_recurrent_gate_tg" : memory ?', 'decode_projection ? "lightonocr3_decode_projection_chunk" : recurrent_gate ? "lightonocr3_recurrent_gate_tg" : memory ?');s=s[:a]+v+s[b:];f.write_text(s)
f=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=f.read_text();a=s.index('        const size_t prefill_rows[]');s=s[:a]+'''        const size_t decode_shapes[][2] = '''+json.dumps(shapes).replace('[','{').replace(']','}')+''';
        for(size_t shape=0;shape<7;shape++)for(size_t row=2;row<=8;row++)
            if(projection(r,row,decode_shapes[shape][0],decode_shapes[shape][1],4))return 148;
        id<MTLComputePipelineState> saved_chunks[4][4],saved_tails[6][3];
        for(size_t tile=0;tile<4;tile++)for(size_t row=0;row<4;row++){
            saved_chunks[tile][row]=r->lightonocr3_decode_chunks[tile][row];r->lightonocr3_decode_chunks[tile][row]=nil;
        }
        for(size_t tile=0;tile<6;tile++)for(size_t row=0;row<3;row++){
            saved_tails[tile][row]=r->lightonocr3_decode_tails[tile][row];r->lightonocr3_decode_tails[tile][row]=nil;
        }
        if(projection(r,5,1024,512,4)||projection(r,8,4096,2560,4))return 149;
        for(size_t tile=0;tile<4;tile++)for(size_t row=0;row<4;row++)r->lightonocr3_decode_chunks[tile][row]=saved_chunks[tile][row];
        for(size_t tile=0;tile<6;tile++)for(size_t row=0;row<3;row++)r->lightonocr3_decode_tails[tile][row]=saved_tails[tile][row];
'''+s[a:];f.write_text(s)
print('Promoted decoder variants',table)
