from pathlib import Path
import hashlib,json,sys,gzip
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max';h=r/'.venv-lighton-vllm-metal';sys.path.insert(0,str(p.parent.parent));from benchmark_corpus import plain_text
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
checks=[]
for f in sorted(p.glob('native_*/report.json')):
 d=json.loads(f.read_text());v=d['results'][0];assert v['status']=='ok',f
 key={'lighton08':'08','lighton4b':'4b','florence':'florence'}[v['model']]
 baseline=p.parent/'concurrent_readers_m4_max'/({'08':'final_native_08_wait20','4b':'final_native_4b_retry','florence':'final_native_florence'}[key])/'report.json';b=json.loads(baseline.read_text())['results'][0]
 refs=[x for x in p.glob('*/report.json') if sha(x)==v['reference_report_sha256']];assert refs,f
 ref=refs[0];rd=json.loads(ref.read_text());values=rd.get('references') or rd['results'][0]['references']
 exact=v['references']==b['references'];content=len(values)==len(v['references']) and all(''.join(plain_text(a['text']).split())==''.join(plain_text(b['text']).split()) for a,b in zip(values,v['references']))
 assert exact and content and v['serial_reference_parity'] and v['cross_runtime_content_parity'],f
 checks.append(dict(report=str(f.relative_to(p)),report_sha256=sha(f),baseline=str(baseline.relative_to(p.parent)),baseline_sha256=sha(baseline),reference=str(ref.relative_to(p)),reference_sha256=sha(ref),matches_original_native_text_exactly=exact,matches_reference_content=content,timed_outputs_match_serial=True))
(p/'output_validation.json').write_text(json.dumps(dict(scope='Three synthetic fixtures; consistency only, not a real-document OCR quality evaluation.',checks=checks),indent=2)+'\n')
logs=['local-build','local-gpu-tests','local-conformance','local-check-final-build','vision-build','vision-gpu-tests','vision-conformance-final','vision-conformance-final-build']
for name in logs:
 f=Path('/private/tmp/ocr-parity-'+name+'.txt')
 if f.exists():(p/(name+'.txt')).write_bytes(f.read_bytes())
archive=p/'prototype_sources';archive.mkdir(exist_ok=True)
files=[]
for pattern in ['vision_*.metal','make_vision*.py','benchmark_vision*.py','vision_attention*_benchmark.m','*local*.py','local_helpers.c','vector_tiles.metal','add_tg_gate.py','add_tg_projection.py','summarize_local_pairs.py','prepare_parity_evidence.py','promote_vision.py','vision_workspace.c']:
 for f in h.glob(pattern):
  if f.name in {x['path'] for x in files}:continue
  raw=f.read_bytes();data=gzip.compress(raw,mtime=0);target=archive/(f.name+'.gz');target.write_bytes(data);files.append(dict(path=f.name,sha256=sha(f),gzip_sha256=sha(target)))
(archive/'manifest.json').write_text(json.dumps(dict(scope='Exact development sources, including rejected experiments. Restore original names in the ignored .venv-lighton-vllm-metal directory; reports bind original SHA256, including local includes. These files are not production runtime.',files=files),indent=2)+'\n')
print(len(checks),'validated native reports;',len(files),'prototype source snapshots')
