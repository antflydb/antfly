from pathlib import Path
import json,hashlib
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max';sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();manifest=json.loads((p/'actual_build_manifest.json').read_text());runtime_sha=manifest['runtime_files_sha256']['zig/pkg/inference/src/backends/metal_kernels.m'];s=dict(scope='Shipping runtime, GPU primitive timings and separate whole-reader wall-clock controls; M4 Max, shared machine. Precision differs from MLX as declared in raw reports.',build_manifest_sha256=sha(p/'actual_build_manifest.json'),primitive_sweeps=[],attention=[],prefill=[],readers=[])
for name in ['actual_page_shapes_resident','actual_page_shapes_cold64','actual_all_rows_resident','actual_all_rows_cold64']:
 f=p/(name+'.json');d=json.loads(f.read_text());assert d['status']=='ok' and d['runtime_source_sha256']==runtime_sha;rs=d['results'];s['primitive_sweeps'].append(dict(report=f.name,sha256=sha(f),cases=len(rs),median_native_at_or_below_mlx=sum(x['median_native_over_mlx']<=1 for x in rs),median_native_within_20_percent=sum(x['median_native_over_mlx']<=1.2 for x in rs),mean_native_within_20_percent=sum(x['native_over_mlx']<=1.2 for x in rs),exceptions=[dict(operation=x['operation'],rows=x['rows'],input_dim=x['in'],output_dim=x['out'],median_native_over_mlx=x['median_native_over_mlx'])for x in rs if x['median_native_over_mlx']>1.2]))
f=p/'actual_vision_attention.json';d=json.loads(f.read_text());assert d['runtime_source_sha256']==runtime_sha and len(d['results'])==14
s['attention']=[{k:v for k,v in x.items()if k!='samples_us'}for x in d['results']];s['attention_report_sha256']=sha(f)
for cache in ['resident','cold64']:
 f=p/('actual_prefill_previous_vs_current_'+cache+'.json');d=json.loads(f.read_text());assert d['status']=='ok'and d['runtime_source_sha256']==runtime_sha
 for x in d['results']:
  s['prefill'].append(dict(cache=cache,rows=x['rows'],input_dim=x['in'],output_dim=x['out'],new_over_old_median=1/x['median_native_over_production'],new_over_mlx_median=x['production']['median_us']/x['mlx']['median_us'],new_over_old_mean=x['production']['mean_us']/x['native']['mean_us']))
for key,ref in [('08','vllm_08_actual_reference'),('4b','vllm_4b_actual_reference'),('florence','mlx_florence_actual_reference')]:
 names=['native_'+key+'_actual_'+v+'_attempt1'for v in ['off1','on','off2']]if key!='florence'else['native_florence_actual'];items=[]
 for name in names:
  f=p/name/'report.json';d=json.loads(f.read_text());x=d['results'][0];assert x['status']=='ok'and d['binary_sha256']==manifest['binary_sha256']and d['runtime_source_diff_sha256']==manifest['runtime_source_diff_sha256'];items.append(dict(report=str(f.relative_to(p)),sha256=sha(f),pages_per_second=x['pages_per_second']))
 f=p/ref/'report.json';d=json.loads(f.read_text());s['readers'].append(dict(model=key,native=items,reference_report=str(f.relative_to(p)),reference_sha256=sha(f),reference_pages_per_second=d['results'][0]['pages_per_second']))
(p/'actual_summary.json').write_text(json.dumps(s,indent=2)+'\n');print('Validated final summary',len(s['primitive_sweeps']),len(s['attention']),len(s['prefill']),len(s['readers']))
