from pathlib import Path
import json
h=Path('.venv-lighton-vllm-metal')
shader=r'''#include <metal_stdlib>
using namespace metal;
struct PairDecodeSplitParams {uint rows,in_dim,out_dim,pad;};
template<uint B,uint S,uint SN,uint TM> inline void pair_decode_split_body(device const float*x,device const ushort*w,device const float*b,device float*y,constant PairDecodeSplitParams&p,uint group,uint sg,uint lane,uint tid,threadgroup float*scratch){
 const uint N=(32/SN)*TM,localcol=(lane/SN)*TM,col=group*N+localcol,chunk=p.in_dim/S;
 float acc[B][TM];for(uint r=0;r<B;r++)for(uint t=0;t<TM;t++)acc[r][t]=0.0f;
 for(uint k=sg*chunk+(lane%SN)*4;k<(sg+1)*chunk;k+=SN*4){
  float4 a[B];for(uint r=0;r<B;r++)a[r]=*((device const float4*)(x+r*p.in_dim+k));
  for(uint t=0;t<TM;t++) {float4 v=float4(0.0f);if(col+t<p.out_dim){ushort4 z=*((device const ushort4*)(w+(col+t)*p.in_dim+k));v=as_type<float4>(uint4(z)<<16);}for(uint r=0;r<B;r++)acc[r][t]+=dot(a[r],v);}
 }
 for(uint r=0;r<B;r++)for(uint t=0;t<TM;t++){
  float v=acc[r][t];for(uint d=SN/2;d>0;d/=2)v+=simd_shuffle_xor(v,d);
  if(lane%SN==0)scratch[sg*8*N+r*N+localcol+t]=v;
 }
 threadgroup_barrier(mem_flags::mem_threadgroup);
 for(uint i=tid;i<B*N;i+=S*32){uint c=group*N+i%N;if(c<p.out_dim){float v=0.0f;for(uint s=0;s<S;s++)v+=scratch[s*8*N+i];y[(i/N)*p.out_dim+c]=v+b[c];}}
}
#define DS(B,S,SN,TM) kernel void pair_decode_split_##B##_##S##_##SN##_##TM(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant PairDecodeSplitParams&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint tid[[thread_index_in_threadgroup]],threadgroup float*scratch[[threadgroup(0)]]){pair_decode_split_body<B,S,SN,TM>(x,w,b,y,p,group,sg,lane,tid,scratch);}
#define DB(B) DS(B,4,4,4) DS(B,8,4,4) DS(B,4,8,4) DS(B,8,8,4)
DB(1) DB(2) DB(3) DB(4) DB(5) DB(6) DB(7) DB(8)
#undef DB
#undef DS
'''
(h/'decode_split.metal').write_text(shader)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_metal_pair.py');s=p.read_text().replace('"decodenax64sg4",','"decodenax64sg4",\n            "decodesplit4n32",\n            "decodesplit8n32",\n            "decodesplit4n16",\n            "decodesplit8n16",');p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/metal_pair_benchmark.m');s=p.read_text().replace('pair_variant>=64&&pair_variant<=78','pair_variant>=64&&pair_variant<=82');a=s.index('static int ocr_pair_encode_candidate(');s=s[:a]+'static NSString *pair_decode_split_source(void){return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n'for x in shader.splitlines())+';}\n'+s[a:];a=s.index('\n',s.index('static int ocr_pair_encode_candidate(OCRPairCase *c) {'))+1;s=s[:a]+'''    if(pair_variant>=79&&pair_variant<=82){
        static id<MTLComputePipelineState>pipelines[4][8];termite_metal_decode_runtime*r=pair_runtime;
        if(!pipelines[0][0]){MTLCompileOptions*o=[MTLCompileOptions new];o.languageVersion=MTLLanguageVersion4_0;o.mathMode=MTLMathModeFast;NSError*err=nil;
          id<MTLLibrary>lib=[r->device newLibraryWithSource:pair_decode_split_source() options:o error:&err];if(!lib){fprintf(stderr,"decode split: %s\\n",err.localizedDescription.UTF8String);return -1;}
          for(size_t j=0;j<4;j++)for(size_t i=0;i<8;i++)pipelines[j][i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"pair_decode_split_%zu_%zu_%zu_4",i+1,j%2?8:4,j<2?4:8]);
        }
        size_t index=pair_variant-79,S=index%2?8:4,N=index<2?32:16;id<MTLComputePipelineState>pipe=pipelines[index][c->rows-1];
        if(!pipe||pipe.maxTotalThreadsPerThreadgroup<S*32)return -1;
        termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
        id<MTLComputeCommandEncoder>e=termite_metal_tracked_compute_command_encoder_for(r->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);if(!e)return -1;
        termite_metal_linear_params p={(uint32_t)c->rows,(uint32_t)c->in_dim,(uint32_t)c->out_dim,0};[e setComputePipelineState:pipe];[e setBuffer:c->input offset:0 atIndex:0];[e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:2];[e setBuffer:c->output offset:0 atIndex:3];[e setBytes:&p length:sizeof(p) atIndex:4];[e setThreadgroupMemoryLength:S*8*N*sizeof(float) atIndex:0];[e dispatchThreadgroups:MTLSizeMake((c->out_dim+N-1)/N,1,1) threadsPerThreadgroup:MTLSizeMake(S*32,1,1)];[e endEncoding];return 0;
    }
'''+s[a:];p.write_text(s)
s=(h/'run_observed_decode_candidates.py').read_text().replace("['decodevec16x2','decodevec32x4','decodempp16','decodempp32','decodegemv1','decodetg']","['decodesplit4n32','decodesplit8n32','decodesplit4n16','decodesplit8n16']").replace("variant=='decodevec16x2'","variant=='decodesplit4n32'").replace('metal_pair_observed_decode','metal_pair_decode_split');(h/'run_decode_split_candidates.py').write_text(s)
