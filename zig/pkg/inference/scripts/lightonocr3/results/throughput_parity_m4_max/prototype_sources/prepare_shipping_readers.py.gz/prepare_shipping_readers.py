from pathlib import Path
h=Path('.venv-lighton-vllm-metal')
s=(h/'refresh_actual_references.py').read_text().replace('actual','shipping');(h/'refresh_shipping_references.py').write_text(s)
s=(h/'run_actual_round.py').read_text().replace('actual','shipping');s=s.replace("'--require-prefill-gates']", "'--require-prefill-gates','--require-decode-projections']")
a=s.index('for name in sys.argv[2:]:');s=s[:a]+'''
for short,label in [('08','lighton08'),('4b','lighton4b')]:
 for variant in ['combined_off1','combined_on','combined_off2','default1','combined_repeat','default2','final_profile']:
  flags=['--weight-residency','--continuous']
  if not variant.startswith('default'):
   flags+=['--vision-batch','--prefill-batch','--vision-wait-us','100000','--prefill-wait-us','100000']
  if '_off' in variant:flags+=['--disable-vision-mpp','--disable-local-kernels','--disable-prefill-projections']
  if variant=='final_profile':flags+=['--profile-reader','--require-small-tail-fusion','--require-vision-mpp','--require-prefill-gates','--require-decode-projections']
  for attempt in range(1,4):cases[short+'_shipping_'+variant+'_attempt'+str(attempt)]=(label,models/label,4,flags,'vllm_'+short)
''' +s[a:];(h/'run_shipping_round.py').write_text(s)
s=(h/'validate_actual_readers.py').read_text().replace('actual','shipping');a=s.index(' for variant in ');b=s.index('  for attempt in ',a);s=s[:a]+" for variant in (['combined_off1','combined_on','combined_off2','default1','combined_repeat','default2','final_profile'] if model!='florence' else ['default']):\n"+s[b:];s=s.replace("if variant=='profile':", "if 'profile' in variant:");s=s.replace("if model!='florence' else 'florence_shipping'", "if model!='florence' else 'florence_shipping'");(h/'validate_shipping_readers.py').write_text(s)
