import os,sys,subprocess,json,time,re
from pathlib import Path
r=Path.cwd();h=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max'
s=Path('/private/tmp/ocr-parity-merger-build.txt').read_text();hits=re.findall(r'\.zig-cache/o/([0-9a-f]{32})/test(?:\s|$)',s);assert hits;binary=r/'zig/.zig-cache/o'/hits[-1]/'test'
env=os.environ.copy();env['OCR_BUILD_MANIFEST']=str(p/'final_build_manifest.json')
for model in ['08','4b','florence']:
 subprocess.run([sys.executable,str(h/'refresh_vision_references.py'),model],check=True)
 for variant in (['off1','on','off2','profile'] if model!='florence' else ['default']):
  for attempt in range(1,4):
   name=model+'_vision_'+variant+'_attempt'+str(attempt) if model!='florence' else 'florence_vision'
   if variant=='profile':env['TERMITE_METAL_TRACE_DENSE_LINEAR_SHAPES']='1'
   else:env.pop('TERMITE_METAL_TRACE_DENSE_LINEAR_SHAPES',None)
   subprocess.run([sys.executable,str(h/'run_vision_round.py'),str(binary),name],env=env,check=True)
   f=p/('native_'+name)/'report.json';v=json.loads(f.read_text())['results'][0];print('RESULT',name,v.get('status'),v.get('pages_per_second'),flush=True)
   if v['status']=='ok':break
   raw=(f.parent/v['log']).read_text()
   if 'ResourceTemporarilyUnavailable' not in raw or 'OCR_REFERENCE' in raw or attempt==3:raise SystemExit('Reader validation failed: '+name)
   time.sleep(5)
