import sys,subprocess
from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_parity_m4_max'
for label,suite,flush,compile in [('vision_integrated_page_shapes','page-shapes',0,True),('vision_integrated_all_rows_resident','all-rows',0,False),('vision_integrated_all_rows_cold64','all-rows',64,False)]:
 print('START',label,flush=True)
 cmd=[sys.executable,str(p/'benchmark_metal_pair.py'),'--native-library',str(r/'.venv-lighton-vllm-metal/metal_pair_vision_final.dylib'),'--timing-library',str(r/'.venv-lighton-vllm-metal/metal_timing_qualified.dylib'),'--suite',suite,'--trials','30','--variant','production','--cache-flush-mib',str(flush),'--output',str(out/(label+'.json'))]
 if compile:cmd+=['--compile-native-library']
 with open('/private/tmp/ocr-parity-'+label+'.txt','w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)
