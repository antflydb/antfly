from pathlib import Path
import json
h=Path('.venv-lighton-vllm-metal');s=(h/'vision_q64.metal').read_text();s=s.replace('flash_q64(', 'flash_q64k64(')
a=s.index('struct Scratch');b=s.index('\n',a);s=s[:a]+'''struct Scratch {half skv[4096];float ss[4096];float sM[64];float sS[64];float sdiag[512];};threadgroup Scratch scratch;threadgroup half *sq=(threadgroup half*)&scratch,*skv=scratch.skv,*sp=(threadgroup half*)scratch.ss;threadgroup float *ss=scratch.ss,*sM=scratch.sM,*sS=scratch.sS,*sdiag=scratch.sdiag;threadgroup float *so=(threadgroup float*)&scratch;'''+s[b:]
a=s.index('    simdgroup_float8x8 mo');s=s[:a]+'''    simdgroup_half8x8 cached_q[4][8];
    #pragma unroll
    for(uint qp=0;qp<4;qp++){
      uint qgroup=qgroup_base+qp*2;
      #pragma unroll
      for(uint d=0;d<8;d++)simdgroup_load(cached_q[qp][d],sq+qgroup*512+d*8,64u);
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
'''+s[a:]
s=s.replace('key_start += 32u','key_start += 64u')
# K and V loads grow to 64 keys; query loading was already 4096 elements.
s=s.replace('i < 2048u','i < 4096u')
a=s.index('        for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 ms');b=s.index('\n',a)
s=s[:a]+'''        for(uint qp=0;qp<4;qp++) {uint qgroup=qgroup_base+qp*2;
          for(uint kp=0;kp<2;kp++) {simdgroup_float8x8 ms=make_filled_simdgroup_matrix<float,8>(0.0f);
            #pragma unroll
            for(uint d=0;d<8;d++){simdgroup_half8x8 mk;simdgroup_load(mk,skv+(subgroup+kp*4)*512+d*8,64u,0,true);simdgroup_multiply_accumulate(ms,cached_q[qp][d],mk,ms);}
            simdgroup_store(ms,ss+qgroup*512+subgroup*8+kp*32,64u);
          }
        }'''+s[b:]
a=s.index('        for (uint pass = 0u; pass < 8u;');b=s.index('\n',a)
s=s[:a]+'''        for(uint pass=0;pass<8;pass++) {uint j=uint(sgitg)+pass*8,qi=q0+j,kk=uint(lane),ki=key_start+kk;
          float sc0=qi<p.seq_len&&ki<p.seq_len?ss[j*64+kk]:neg_inf;
          float sc1=qi<p.seq_len&&ki+32<p.seq_len?ss[j*64+kk+32]:neg_inf;
          if(!isfinite(sc0))sc0=neg_inf;if(!isfinite(sc1))sc1=neg_inf;
          simdgroup_barrier(mem_flags::mem_threadgroup);
          float row_max=simd_max(max(sc0,sc1)),m_old=sM[j],m_new=max(m_old,row_max),corr=0,e0=0,e1=0;
          if(m_new>-3.0e+38f){corr=m_old>-3.0e+38f?exp(m_old-m_new):0;e0=sc0>-3.0e+38f?exp(sc0-m_new):0;e1=sc1>-3.0e+38f?exp(sc1-m_new):0;}
          sp[j*128+kk]=half(e0);sp[j*128+kk+32]=half(e1);
          float row_sum=simd_sum(e0+e1);
          if(lane==0){sS[j]=sS[j]*corr+row_sum;sM[j]=m_new;uint local_j=j&7u;sdiag[(j>>3u)*64+local_j*8+local_j]=corr;}
        }'''+s[b:]
s=s.replace('kk8 < 4u','kk8 < 8u').replace('sp + qgroup * 256u + kk8 * 8u, 32u','sp + qgroup * 1024u + kk8 * 8u, 128u')
(h/'vision_q64k64.metal').write_text(s)
p=h/'vision_attention_benchmark.m';c=p.read_text();a=c.index('static NSString *vision_candidate_source');b=c.index('void *vision_create',a);k=(h/'vision_q64.metal').read_text()+s;literal='static NSString *vision_candidate_source(void) {return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n' for x in k.splitlines())+';}\n';c=c[:a]+literal+c[b:];c=c.replace('static id<MTLComputePipelineState> vp;','static id<MTLComputePipelineState> vp,vp64;')
needle=' vp=termite_metal_make_pipeline';i=c.index(needle);c=c[:i]+''' vp64=termite_metal_make_pipeline(vr->device,lib,@"termite_sdpa_f32_vision_hd64_flash_q64k64");
 if(!vp64||vp64.maxTotalThreadsPerThreadgroup<256||vp64.staticThreadgroupMemoryLength>vr->device.maxThreadgroupMemoryLength)return NULL;
 fprintf(stderr,"vision_q64k64 threads=%zu static_bytes=%zu\\n",(size_t)vp64.maxTotalThreadsPerThreadgroup,(size_t)vp64.staticThreadgroupMemoryLength);
'''+c[i:];c=c.replace('[e setComputePipelineState:vp];','[e setComputePipelineState:candidate==2?vp64:vp];');c+='''
static id<MTLBuffer> flush_buffer;static id<MTLComputePipelineState> flush_pipeline;
int vision_flush(size_t mib){
 if(!vr||!mib||mib>512)return -1;
 if(!flush_pipeline){MTLCompileOptions*o=[MTLCompileOptions new];NSError*err=nil;
 id<MTLLibrary>l=[vr->device newLibraryWithSource:@"#include <metal_stdlib>\\nusing namespace metal;kernel void flush(device uint*x[[buffer(0)]],uint i[[thread_position_in_grid]]){x[i]^=0x9e3779b9u;}" options:o error:&err];flush_pipeline=termite_metal_make_pipeline(vr->device,l,@"flush");if(!flush_pipeline)return -1;}
 size_t bytes=mib*1024*1024;if(!flush_buffer||flush_buffer.length!=bytes)flush_buffer=[vr->device newBufferWithLength:bytes options:MTLResourceStorageModePrivate];
 id<MTLCommandBuffer>cb=[vr->queue commandBuffer];id<MTLComputeCommandEncoder>e=[cb computeCommandEncoder];if(!e||!flush_buffer)return -1;
 [e setComputePipelineState:flush_pipeline];[e setBuffer:flush_buffer offset:0 atIndex:0];[e dispatchThreads:MTLSizeMake(bytes/4,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];[e endEncoding];[cb commit];[cb waitUntilCompleted];return cb.status==MTLCommandBufferStatusCompleted?0:-1;
}
''';(h/'vision_attention_q64k64_benchmark.m').write_text(c)
