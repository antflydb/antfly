import re,sys,json,subprocess,hashlib,time
from pathlib import Path
r=Path.cwd();h=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max';sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
s=Path('/private/tmp/ocr-parity-shipping-build.txt').read_text();hits=re.findall(r'\.zig-cache/o/([0-9a-f]{32})/test(?:\s|$)',s);assert hits;binary=r/'zig/.zig-cache/o'/hits[-1]/'test';f=json.loads((h/'shipping-kernels-freeze.json').read_text());assert all(sha(k)==v for k,v in f.items()),'Runtime changed during build'
base='58d7e441dd3c2f19584d99b5baa321659a387ef7';m=dict(runtime_commit=base,runtime_source_diff_sha256=hashlib.sha256(subprocess.check_output(['git','diff',base,'--','zig/pkg/inference/src'])).hexdigest(),binary_sha256=sha(binary),runtime_files_sha256=f);(p/'shipping_build_manifest.json').write_text(json.dumps(m,indent=2)+'\n')
s=(h/'local_gpu_tests.py').read_text().replace('0dfe2362a7d763223b0619f4f49584f2',hits[-1]).replace('ocr-parity-local-gpu-tests','ocr-parity-shipping-gpu-tests');driver=h/'shipping_parity_gpu_tests.py';driver.write_text(s)
subprocess.run([sys.executable,str(driver)],check=True)
print('All final GPU and real-checkpoint/HTTP checks passed',flush=True)
