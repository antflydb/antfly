from pathlib import Path
import json
h=Path('.venv-lighton-vllm-metal');shader=(h/'decode_chunk.metal').read_text();shader=shader[:shader.index('#define CH')];shader=shader.replace('pair_chunk_body','pair_exact_body')
shader+=r'''
template<uint R,uint CAP,uint SN,uint TM> inline void pair_exact_dispatch(device const float*x,device const ushort*w,device const float*b,device float*y,constant PairChunkParams&p,uint2 group,uint sg,uint lane){
 if constexpr(R>CAP && R%CAP!=0){
  if(group.y==R/CAP){const uint start=R/CAP*CAP;pair_exact_body<R%CAP,SN,TM>(x+start*p.in_dim,w,b,y+start*p.out_dim,p,uint2(group.x,0),sg,lane);return;}
 }
 pair_exact_body<(R<CAP?R:CAP),SN,TM>(x,w,b,y,p,group,sg,lane);
}
#define EX(R,CAP,SN,TM) kernel void pair_exact_##R##_##CAP##_##SN##_##TM(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant PairChunkParams&p[[buffer(4)]],uint2 group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){pair_exact_dispatch<R,CAP,SN,TM>(x,w,b,y,p,group,sg,lane);}
#define EB(R) EX(R,4,16,2) EX(R,4,16,4) EX(R,4,32,4) EX(R,4,32,8) EX(R,2,16,4) EX(R,2,32,8)
EB(5) EB(6) EB(7)
#undef EB
#undef EX
''';(h/'decode_exact.metal').write_text(shader)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_metal_pair.py');s=p.read_text().replace('"decodechunk2s32t8",','"decodechunk2s32t8",\n            "decodeexact4s16t2",\n            "decodeexact4s16t4",\n            "decodeexact4s32t4",\n            "decodeexact4s32t8",\n            "decodeexact2s16t4",\n            "decodeexact2s32t8",');a=s.index('                if args.variant.startswith("decodechunk")');s=s[:a]+'                if args.variant.startswith("decodeexact"):return kind==0 and 5<=rows<=7 and n>32 and missing\n'+s[a:];p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/metal_pair_benchmark.m');s=p.read_text().replace('pair_variant>=64&&pair_variant<=100','pair_variant>=64&&pair_variant<=106');a=s.index('        if(pair_variant>=95)return');s=s[:a]+'        if(pair_variant>=101)return c->kind==0&&missing&&c->rows>=5&&c->rows<=7&&!tiny;\n'+s[a:];a=s.index('static int ocr_pair_encode_candidate(');s=s[:a]+'static NSString *pair_decode_exact_source(void){return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n'for x in shader.splitlines())+';}\n'+s[a:];a=s.index('\n',s.index('static int ocr_pair_encode_candidate(OCRPairCase *c) {'))+1;s=s[:a]+'''    if(pair_variant>=101&&pair_variant<=106){
        static id<MTLComputePipelineState>pipelines[6][3];termite_metal_decode_runtime*r=pair_runtime;
        const size_t caps[6]={4,4,4,4,2,2},lanes[6]={16,16,32,32,16,32},tiles[6]={2,4,4,8,4,8};
        if(!pipelines[0][0]){MTLCompileOptions*o=[MTLCompileOptions new];o.languageVersion=MTLLanguageVersion4_0;o.mathMode=MTLMathModeFast;NSError*err=nil;
          id<MTLLibrary>lib=[r->device newLibraryWithSource:pair_decode_exact_source() options:o error:&err];if(!lib){fprintf(stderr,"decode exact: %s\\n",err.localizedDescription.UTF8String);return -1;}
          for(size_t j=0;j<6;j++)for(size_t i=0;i<3;i++)pipelines[j][i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"pair_exact_%zu_%zu_%zu_%zu",i+5,caps[j],lanes[j],tiles[j]]);
        }
        size_t index=pair_variant-101,B=caps[index],N=4*(32/lanes[index])*tiles[index];id<MTLComputePipelineState>pipe=pipelines[index][c->rows-5];
        if(!pipe||pipe.maxTotalThreadsPerThreadgroup<128)return -1;
        termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
        id<MTLComputeCommandEncoder>e=termite_metal_tracked_compute_command_encoder_for(r->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);if(!e)return -1;
        termite_metal_linear_params p={(uint32_t)c->rows,(uint32_t)c->in_dim,(uint32_t)c->out_dim,0};[e setComputePipelineState:pipe];[e setBuffer:c->input offset:0 atIndex:0];[e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:2];[e setBuffer:c->output offset:0 atIndex:3];[e setBytes:&p length:sizeof(p) atIndex:4];[e dispatchThreadgroups:MTLSizeMake(c->out_dim/N,(c->rows+B-1)/B,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];[e endEncoding];return 0;
    }
'''+s[a:];p.write_text(s)
s=(h/'run_decode_chunk_candidates.py').read_text().replace('decodechunk','decodeexact').replace('metal_pair_decode_chunk','metal_pair_decode_exact');(h/'run_decode_exact_candidates.py').write_text(s)
