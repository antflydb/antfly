from pathlib import Path
import json
kernel=r'''
template<uint S,uint N> inline void tg_proj_body(device float*x,device bfloat*w,device float*bias,device float*y,constant P&p,threadgroup float*tmp,uint group,uint sg,uint tid){
 uint chunk=p.in_dim/S;
 tensor<device float,dextents<int,2>,tensor_inline>a(x+sg*chunk,dextents<int,2>(chunk,p.rows),array<int,2>{1,int(p.in_dim)});
 tensor<device bfloat,dextents<int,2>,tensor_inline>wm(w+sg*chunk,dextents<int,2>(chunk,p.out_dim),array<int,2>{1,int(p.in_dim)});
 tensor<threadgroup float,dextents<int,2>,tensor_inline>dest(tmp+sg*8*N,dextents<int,2>(N,p.rows),array<int,2>{1,int(N)});
 auto left=a.slice(0,0);auto right=wm.slice(0,int(group)*N);
 constexpr auto desc=matmul2d_descriptor(8,N,dynamic_length_v<int>,false,true,false);matmul2d<desc,execution_simdgroups<1>>op;
 auto result=op.template get_destination_cooperative_tensor<decltype(left),decltype(right),float>();op.run(left,right,result);result.store(dest);
 threadgroup_barrier(mem_flags::mem_threadgroup);
 for(uint i=tid;i<p.rows*N;i+=S*32){float sum=0;
  #pragma unroll
  for(uint j=0;j<S;j++)sum+=tmp[j*8*N+i];
  uint col=group*N+i%N;y[(i/N)*p.out_dim+col]=sum+bias[col];
 }
}
#define TP(S,N) kernel void tg_proj##S##_##N(device float*x[[buffer(0)]],device bfloat*w[[buffer(1)]],device float*bias[[buffer(2)]],device float*y[[buffer(3)]],constant P&p[[buffer(4)]],threadgroup float*tmp[[threadgroup(0)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint tid[[thread_index_in_threadgroup]]){tg_proj_body<S,N>(x,w,bias,y,p,tmp,group,sg,tid);}
TP(8,16) TP(8,32) TP(16,16)
'''
p=Path('zig/pkg/inference/scripts/lightonocr3/metal_pair_benchmark.m');s=p.read_text();start=s.index('static NSString *ocr_pair_tg_gate_source');end=s.index('static NSString *ocr_pair_vector_tile_source',start);part=s[start:end];idx=part.rindex('];');part=part[:idx]+''.join(' '+json.dumps(line+'\n')+'\n' for line in kernel.splitlines())+part[idx:];s=s[:start]+part+s[end:];s=s.replace('static size_t pair_variant;','static id<MTLComputePipelineState> pair_tg_projections[3];\nstatic size_t pair_variant;');s=s.replace('    case 41:\n','    case 45:\n    case 46:\n    case 47:\n        return c->kind == 0 && c->rows >= 2 && c->rows <= 8 && (c->in_dim == 3584 || c->in_dim == 9216);\n    case 41:\n');i=s.index('    if (pair_variant >= 36',s.index('static int ocr_pair_encode_candidate'));s=s[:i]+'''    if (pair_variant >= 45 && pair_variant <= 47) {
        if (!pair_tg_library) {
            MTLCompileOptions *opt=[MTLCompileOptions new];opt.languageVersion=MTLLanguageVersion4_0;opt.mathMode=MTLMathModeSafe;
            NSError *err=nil;pair_tg_library=[r->device newLibraryWithSource:ocr_pair_tg_gate_source() options:opt error:&err];
            if(!pair_tg_library){fprintf(stderr,"TG projection: %s\\n",err.localizedDescription.UTF8String);return -1;}
        }
        const size_t index=pair_variant-45,splits=index==2?16:8,columns=index==1?32:16;
        id<MTLComputePipelineState> pipe=pair_tg_projections[index];
        if(!pipe){pipe=termite_metal_make_pipeline(r->device,pair_tg_library,[NSString stringWithFormat:@"tg_proj%zu_%zu",splits,columns]);pair_tg_projections[index]=pipe;}
        if(!pipe||pipe.maxTotalThreadsPerThreadgroup<splits*32)return -1;
        id<MTLComputeCommandEncoder> e=termite_metal_tracked_compute_command_encoder_for(r->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_OTHER);if(!e)return -1;
        termite_metal_linear_params p={(uint32_t)c->rows,(uint32_t)c->in_dim,(uint32_t)c->out_dim,0};
        [e setComputePipelineState:pipe];[e setBuffer:c->input offset:0 atIndex:0];[e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:2];[e setBuffer:c->output offset:0 atIndex:3];[e setBytes:&p length:sizeof(p) atIndex:4];
        [e setThreadgroupMemoryLength:splits*8*columns*4 atIndex:0];[e dispatchThreadgroups:MTLSizeMake(c->out_dim/columns,1,1) threadsPerThreadgroup:MTLSizeMake(splits*32,1,1)];[e endEncoding];return 0;
    }
'''+s[i:];p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_metal_pair.py');s=p.read_text().replace('"vecproj32x4",','"vecproj32x4",\n"tgproj8x16",\n"tgproj8x32",\n"tgproj16x16",');s=s.replace('                "vecproj16x2":','                "tgproj8x16": kind == 0 and 2 <= rows <= 8 and k in (3584,9216),\n                "tgproj8x32": kind == 0 and 2 <= rows <= 8 and k in (3584,9216),\n                "tgproj16x16": kind == 0 and 2 <= rows <= 8 and k in (3584,9216),\n                "vecproj16x2":');p.write_text(s)
