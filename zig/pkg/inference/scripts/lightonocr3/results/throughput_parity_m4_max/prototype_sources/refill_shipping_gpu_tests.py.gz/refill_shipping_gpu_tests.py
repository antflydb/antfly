import os, pathlib, subprocess, sys
root=pathlib.Path.cwd()
env=os.environ.copy()
env.pop("ANTFLY_INFERENCE_REQUIRED_BACKEND",None)
env.pop("ANTFLY_LIGHTONOCR3_CONTINUOUS",None)
env["ANTFLY_LIGHTONOCR3_PREFILL_BATCH"]="1"
env["ANTFLY_LIGHTONOCR3_VISION_BATCH"]="1"
env["ANTFLY_TEST_LIGHTONOCR3_VISION_BATCH_CHECK"]="1"
env.update(ANTFLY_INFERENCE_PREFERRED_BACKEND="metal",TERMITE_METAL_ENABLE_LIGHTONOCR3_WEIGHT_RESIDENCY="1",ANTFLY_TEST_LIGHTONOCR3_MODEL_DIR=str(root/".venv-lighton-vllm-metal/ocr-models/lighton08"),ANTFLY_BENCH_LIGHTONOCR3="1",ANTFLY_TEST_LIGHTONOCR3_WARM_RUNS="0",ANTFLY_TEST_LIGHTONOCR3_HTTP_BATCH="1",ANTFLY_TEST_LIGHTONOCR3_MEMORY_LIMIT_GIB="24",ANTFLY_TEST_LIGHTONOCR3_SHARED_LIMIT_GIB="28",ANTFLY_TEST_LIGHTONOCR3_BACKEND_LIMIT_GIB="16",ANTFLY_TEST_LIGHTONOCR3_KV_LIMIT_GIB="4",ANTFLY_TEST_LIGHTONOCR3_SCRATCH_LIMIT_GIB="4")
cmd=[str((root/"zig/.zig-cache/o/d8617769a5d04f08f727898d3bb56d7a/test").resolve())]
for f in ["LightOnOCR3","batch decode context","execution lane","projector residency","executor batch","coalesc","Florence","shared native provider","dynamic linear slot","decode GQA split"]:cmd += ["--test-filter",f]
with open("/private/tmp/ocr-refill-shipping-gpu-tests.txt","w") as out:r=subprocess.run(cmd,cwd=root/"zig/pkg/inference",env=env,stdout=out,stderr=subprocess.STDOUT)
sys.exit(r.returncode)
