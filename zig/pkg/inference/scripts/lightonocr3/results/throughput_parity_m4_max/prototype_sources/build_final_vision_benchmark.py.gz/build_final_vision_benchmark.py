from pathlib import Path
import hashlib,subprocess
h=Path('.venv-lighton-vllm-metal');source=h/'vision_attention_final_benchmark.m';source.write_bytes((h/'vision_attention_production_benchmark.m').read_bytes());p=h/'benchmark_final_vision.py';s=(h/'benchmark_vision_production.py').read_text().replace('vision_attention_production_benchmark','vision_attention_final_benchmark').replace('vision_production.json','final_vision_attention.json');p.write_text(s)
sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
cmd=['clang','-O2','-dynamiclib','-fobjc-arc','-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate','-DOCR_VISION_RUNTIME_SHA="'+sha('zig/pkg/inference/src/backends/metal_kernels.m')+'"','-DOCR_VISION_BRIDGE_SHA="'+sha(source)+'"',str(source),'-o',str(h/'vision_attention_final_benchmark.dylib')]
with open('/private/tmp/ocr-parity-final-vision-benchmark-build.txt','w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
