from pathlib import Path
import ast,json,re,hashlib
root=Path.cwd();p=root/'zig/pkg/inference/src/backends/metal_kernels.m';s=p.read_text()
# Preserve the exact final benchmark sources used against the preceding C runtime.
a=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max/baseline_benchmark_sources';a.mkdir(exist_ok=True)
for name in ['benchmark_metal_pair.py','metal_pair_benchmark.m']:(a/name).write_bytes((a.parent.parent.parent/name).read_bytes())
fields='''    id<MTLComputePipelineState> lightonocr3_local_gate_vectors[2];
    id<MTLComputePipelineState> lightonocr3_local_projection_vectors[3];
    id<MTLComputePipelineState> lightonocr3_local_down_vectors[2];
    id<MTLComputePipelineState> lightonocr3_local_down_vector4;
    id<MTLComputePipelineState> lightonocr3_local_gate_tg16, lightonocr3_local_gate_tg32;
    id<MTLComputePipelineState> lightonocr3_local_down_tg8, lightonocr3_local_down_tg16;
''';s=s.replace('    id<MTLComputePipelineState> lightonocr3_gate_up_small16_pipeline;',fields+'    id<MTLComputePipelineState> lightonocr3_gate_up_small16_pipeline;')
def kernel_literal(name):
 t=ast.parse((root/'.venv-lighton-vllm-metal'/name).read_text())
 return next(ast.literal_eval(n.value) for n in t.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='kernel' for x in n.targets))
def strings(src,indent=8):return ''.join(' '*indent+json.dumps(line+'\n')+'\n' for line in src.splitlines())
tg=kernel_literal('add_tg_gate.py').replace('TG(4,16) TG(2,16) TG(4,32)','TG(4,16) TG(4,32)\n#undef TG')
tg+=kernel_literal('add_tg_projection.py').replace('TP(8,16) TP(8,32) TP(16,16)','TP(8,16) TP(16,16)\n#undef TP')
tg=re.sub(r'\bP\b','Params',tg).replace('tg_gate','termite_lightonocr3_local_gate').replace('tg_proj','termite_lightonocr3_local_down')
needle='        "struct GateSplitParams';i=s.index(needle);s=s[:i]+strings(tg)+s[i:]
v=(root/'.venv-lighton-vllm-metal/vector_tiles.metal').read_text();v=v[v.index('struct P'):v.index('T(2,8,2)')];v+='T(2,16,2) T(3,16,2)\nV(2,16,2) V(3,16,2) V(4,16,4) V(4,16,2) V(2,32,4) V(3,32,4)\n#undef T\n#undef V\n';v=re.sub(r'\bP\b','termite_lightonocr3_local_params',v).replace('tile_body','termite_lightonocr3_local_tile_body').replace('void tile##','void termite_lightonocr3_local_gate_vec##').replace('void proj##','void termite_lightonocr3_local_proj_vec##');i=s.index('           "kernel void termite_lightonocr3_gemv_vec4_rows2');s=s[:i]+strings(v,11)+s[i:]
needle='            runtime->lightonocr3_gate_up_split16_pipeline =';i=s.index(needle);init='''            runtime->lightonocr3_local_gate_tg16 = termite_metal_make_pipeline(device,tensor_library,@"termite_lightonocr3_local_gate4_16");
            runtime->lightonocr3_local_gate_tg32 = termite_metal_make_pipeline(device,tensor_library,@"termite_lightonocr3_local_gate4_32");
            runtime->lightonocr3_local_down_tg8 = termite_metal_make_pipeline(device,tensor_library,@"termite_lightonocr3_local_down8_16");
            runtime->lightonocr3_local_down_tg16 = termite_metal_make_pipeline(device,tensor_library,@"termite_lightonocr3_local_down16_16");
''';s=s[:i]+init+s[i:]
needle='        runtime->lightonocr3_gate_up_gemv_pipeline =';i=s.index(needle);init='''        if ([device.name isEqualToString:@"Apple M4 Max"]) {
            for(size_t b=0;b<2;b++) {
                runtime->lightonocr3_local_gate_vectors[b]=termite_metal_make_pipeline(device,library,[NSString stringWithFormat:@"termite_lightonocr3_local_gate_vec%zu_16_2",b+2]);
                runtime->lightonocr3_local_down_vectors[b]=termite_metal_make_pipeline(device,library,[NSString stringWithFormat:@"termite_lightonocr3_local_proj_vec%zu_32_4",b+2]);
            }
            for(size_t b=0;b<3;b++)runtime->lightonocr3_local_projection_vectors[b]=termite_metal_make_pipeline(device,library,[NSString stringWithFormat:@"termite_lightonocr3_local_proj_vec%zu_16_%zu",b+2,b==2?(size_t)4:(size_t)2]);
            runtime->lightonocr3_local_down_vector4=termite_metal_make_pipeline(device,library,@"termite_lightonocr3_local_proj_vec4_16_2");
        }
''';s=s[:i]+init+s[i:]
needle='    runtime->lightonocr3_gate_up_small16_pipeline = nil;';i=s.index(needle);release='''    for(size_t i=0;i<2;i++) {runtime->lightonocr3_local_gate_vectors[i]=nil;runtime->lightonocr3_local_down_vectors[i]=nil;}
    for(size_t i=0;i<3;i++)runtime->lightonocr3_local_projection_vectors[i]=nil;
    runtime->lightonocr3_local_down_vector4=nil;
    runtime->lightonocr3_local_gate_tg16=nil;runtime->lightonocr3_local_gate_tg32=nil;
    runtime->lightonocr3_local_down_tg8=nil;runtime->lightonocr3_local_down_tg16=nil;
''';s=s[:i]+release+s[i:]
i=s.index('static int termite_metal_try_lightonocr3_down_split(');s=s[:i]+(root/'.venv-lighton-vllm-metal/local_helpers.c').read_text()+'\n'+s[i:]
needle='        const int down_split_rc = termite_metal_try_lightonocr3_down_split';i=s.index(needle);s=s[:i]+'''        const int local_rc=termite_metal_try_lightonocr3_local_projection(runtime,slot,input_buffer,input_offset,rows,in_dim,out_dim,output_buffer,output_offset);
        if(local_rc!=0)return local_rc==1?0:local_rc;
'''+s[i:]
needle='    if (in_dim == 1024 && out_dim == 3584 && rows >= 2) {';i=s.index(needle,s.index('termite_metal_lightonocr3_batch_gate_up_pipeline'));s=s[:i]+'''    id<MTLComputePipelineState> local=termite_metal_lightonocr3_local_gate_pipeline(runtime,rows,in_dim,out_dim);
    if(local!=nil)return local;
'''+s[i:]
needle='    id<MTLComputePipelineState> stage = runtime->lightonocr3_gate_up_split16_pipeline;';i=s.index(needle,s.index('static int termite_metal_try_lightonocr3_gate_split'));s=s[:i]+'''    if(termite_metal_lightonocr3_local_gate_pipeline(runtime,rows,in_dim,out_dim)!=nil)return 0;
'''+s[i:]
needle='        if (small != nil) [encoder dispatchThreadgroups:';i=s.index(needle,s.index('int termite_metal_decode_runtime_apply_bf16_gate_up_device'));end=s.index('\n        else if(rows==1)',i);s=s[:i]+'''        const bool local_tg=small!=nil&&(small==runtime->lightonocr3_local_gate_tg16||small==runtime->lightonocr3_local_gate_tg32);
        const bool local_vec=small!=nil&&(small==runtime->lightonocr3_local_gate_vectors[0]||small==runtime->lightonocr3_local_gate_vectors[1]);
        if(local_tg){
            const size_t columns=small==runtime->lightonocr3_local_gate_tg16?16:32;
            [encoder setThreadgroupMemoryLength:2*4*8*columns*sizeof(float) atIndex:0];
            [encoder dispatchThreadgroups:MTLSizeMake(out_dim/columns,1,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];
        } else if(local_vec)[encoder dispatchThreadgroups:MTLSizeMake(out_dim/16,1,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];
        else if (small != nil) [encoder dispatchThreadgroups:MTLSizeMake(out_dim / (small == runtime->lightonocr3_gate_up_small16_pipeline ? 16 : 32), 1, 1) threadsPerThreadgroup:MTLSizeMake(32, 1, 1)];'''+s[end:]
needle='            small != nil ? "lightonocr3_batch_gate_up" :';s=s.replace(needle,'            local_tg ? "lightonocr3_gate_up_local_tg" : local_vec ? "lightonocr3_gate_up_local_vector" : small != nil ? "lightonocr3_batch_gate_up" :');p.write_text(s)
# Actual reader reachability accepts both old global and new local fusion.
p=root/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';s=p.read_text().replace('variant=lightonocr3_gate_up_split(?:','variant=lightonocr3_gate_up_(?:split|local_vector|local_tg)(?:');p.write_text(s)
