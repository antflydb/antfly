from pathlib import Path
import json
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_metal_pair.py');s=p.read_text().replace('"prefill8x16",','"prefill8x16",\n            "prefilltg4",\n            "prefilltg8",\n            "prefilltg16",');p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/metal_pair_benchmark.m');s=p.read_text();idx=s.index('    if(pair_variant>=52',s.index('size_t ocr_pair_candidate_applies'));s=s[:idx]+'''    if(pair_variant>=56&&pair_variant<=58)return c->kind==0&&c->rows>=32&&c->rows<=2048&&
        ((c->in_dim==1024&&c->out_dim==16)||(c->in_dim==2560&&c->out_dim==32));
'''+s[idx:];idx=s.index('static int ocr_pair_encode_candidate(');shader=Path('.venv-lighton-vllm-metal/prefill_gate_tg.metal').read_text();lit='static NSString *pair_prefill_source(void){return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n'for x in shader.splitlines())+';}\n';s=s[:idx]+lit+s[idx:];idx=s.index('\n',s.index('static int ocr_pair_encode_candidate(OCRPairCase *c) {'))+1;s=s[:idx]+'''    if(pair_variant>=56&&pair_variant<=58){
        static id<MTLComputePipelineState>pipelines[3];termite_metal_decode_runtime*r=pair_runtime;
        if(!pipelines[0]){MTLCompileOptions*o=[MTLCompileOptions new];o.languageVersion=MTLLanguageVersion4_0;o.mathMode=MTLMathModeSafe;NSError*err=nil;
            id<MTLLibrary>lib=[r->device newLibraryWithSource:[termite_metal_lightonocr3_tensor_source() stringByAppendingString:pair_prefill_source()] options:o error:&err];
            if(!lib){fprintf(stderr,"prefill TG: %s\\n",err.localizedDescription.UTF8String);return -1;}
            for(size_t i=0;i<3;i++)pipelines[i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"pair_prefill_gate%zu",4ul<<i]);
        }
        size_t index=pair_variant-56,S=4ul<<index;id<MTLComputePipelineState>pipe=pipelines[index];
        if(!pipe||pipe.maxTotalThreadsPerThreadgroup<S*32||S*8*16*4>r->device.maxThreadgroupMemoryLength)return -1;
        termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
        id<MTLComputeCommandEncoder>e=termite_metal_tracked_compute_command_encoder_for(r->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);if(!e)return -1;
        termite_metal_linear_params p={(uint32_t)c->rows,(uint32_t)c->in_dim,(uint32_t)c->out_dim,0};
        [e setComputePipelineState:pipe];[e setBuffer:c->input offset:0 atIndex:0];[e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:2];[e setBuffer:c->output offset:0 atIndex:3];[e setBytes:&p length:sizeof(p) atIndex:4];[e setThreadgroupMemoryLength:S*8*16*4 atIndex:0];
        [e dispatchThreadgroups:MTLSizeMake((c->out_dim+15)/16,(c->rows+7)/8,1) threadsPerThreadgroup:MTLSizeMake(S*32,1,1)];[e endEncoding];return 0;
    }
'''+s[idx:];p.write_text(s)
