from pathlib import Path
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text();needle='static int gate_split_frame_check(termite_metal_decode_runtime *r, size_t in, size_t out, size_t rows) {';s=s.replace(needle,needle+'\n    setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_LOCAL_KERNELS","1",1);');i=s.index('static int gate_split_frame_check');end=s.index('static int prefill_conv_check',i);part=s[i:end].replace('    free(gold);\n    return worst', '    free(gold);\n    unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_LOCAL_KERNELS");\n    return worst');s=s[:i]+part+s[end:]
s=s.replace('bool qualified = (in == 1024 && rows >= 5 && rows <= 8) || (in == 2560 && rows >= 4 && rows <= 8);','bool qualified = rows >= 2 && rows <= 8 && (in == 1024 || in == 2560);')
needle='        r->lightonocr3_gate_up_small16_pipeline = nil;';i=s.index(needle,s.index('static int batch_gate_up_check'));s=s[:i]+'''        id<MTLComputePipelineState> local[4]={r->lightonocr3_local_gate_vectors[0],r->lightonocr3_local_gate_vectors[1],r->lightonocr3_local_gate_tg16,r->lightonocr3_local_gate_tg32};
        r->lightonocr3_local_gate_vectors[0]=nil;r->lightonocr3_local_gate_vectors[1]=nil;
        r->lightonocr3_local_gate_tg16=nil;r->lightonocr3_local_gate_tg32=nil;
'''+s[i:];needle='        r->lightonocr3_gate_up_small32_pipeline = p32;';i=s.index(needle,s.index('static int batch_gate_up_check'))+len(needle);s=s[:i]+'''
        r->lightonocr3_local_gate_vectors[0]=local[0];r->lightonocr3_local_gate_vectors[1]=local[1];
        r->lightonocr3_local_gate_tg16=local[2];r->lightonocr3_local_gate_tg32=local[3];
        if(termite_metal_lightonocr3_local_pipeline_valid(r,local[0],SIZE_MAX,0)||
            termite_metal_lightonocr3_local_pipeline_valid(r,local[2],128,SIZE_MAX))return 70;
        id<MTLBuffer> source=[r->device newBufferWithBytes:x.contents length:x.length options:MTLResourceStorageModeShared];
        id<MTLBuffer> zero=[r->device newBufferWithLength:x.length options:MTLResourceStorageModeShared];
        if(!source||!zero)return 71;memset(zero.contents,0,zero.length);
'''+s[i:]
s=s.replace('for (size_t mode = 0; mode < 2; mode++) {\n                uint32_t *raw = y.contents;', 'for (size_t mode = 0; mode < 3; mode++) {\n                uint32_t *raw = y.contents;')
needle='                } else if (termite_metal_decode_runtime_apply_bf16_gate_up_device(';i=s.index(needle,s.index('static int batch_gate_up_check'));end=s.index('                if (termite_metal_decode_runtime_submit_frame',i);s=s[:i]+'''                } else {
                    if(mode==1){
                        memset(x.contents,0,x.length);
                        if(termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_FFN,TERMITE_METAL_COMPUTE_REGION_FFN)||
                            termite_metal_decode_runtime_apply_add_device(r,(__bridge void*)source,16,(__bridge void*)zero,16,rows*in,(__bridge void*)x,16))return 72;
                    } else setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_LOCAL_KERNELS","1",1);
                    if(termite_metal_decode_runtime_apply_bf16_gate_up_device(r,0,1,(__bridge void*)x,16,rows,in,out,(__bridge void*)y,16))return 10;
                    if(mode==1&&termite_metal_decode_runtime_end_planned_compute_scope(r))return 73;
                    if(mode==2)unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_LOCAL_KERNELS");
                }
'''+s[end:]
needle='        // The master rollback must retain the existing numerical result.';i=s.index(needle);s=s[:i]+'''        if(!bf16 && rows>=2 && rows<=8 && offset_floats%4==0) {
            id<MTLBuffer> source=[r->device newBufferWithBytes:input.contents length:input.length options:MTLResourceStorageModeShared];
            id<MTLBuffer> zero=[r->device newBufferWithLength:input.length options:MTLResourceStorageModeShared];
            if(!source||!zero)return 30;memset(zero.contents,0,zero.length);memset(input.contents,0,input.length);
            if(termite_metal_decode_runtime_begin_frame(r)||termite_metal_decode_runtime_begin_planned_compute_scope(r,TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR,TERMITE_METAL_COMPUTE_REGION_FFN)||
                termite_metal_decode_runtime_apply_add_device(r,(__bridge void*)source,offset_floats*4,(__bridge void*)zero,offset_floats*4,rows*in,(__bridge void*)input,offset_floats*4))return 31;
            int local=termite_metal_try_lightonocr3_local_projection(r,0,input,offset_floats*4,rows,in,out,result,16);
            if(local<0||termite_metal_decode_runtime_end_planned_compute_scope(r)||termite_metal_decode_runtime_submit_frame(r)||termite_metal_decode_runtime_wait_frame(r))return 32;
            if(local==1){
                for(size_t i=0;i<rows*out;i++)if(!isfinite(got[i])||fabsf(got[i]-gold[i])>2e-4f)return 33;
                uint32_t *raw=result.contents;
                for(size_t i=0;i<4;i++)if(raw[i]!=0xdeadbeefu)return 34;
                for(size_t i=4+rows*out;i<12+rows*out;i++)if(raw[i]!=0xcafebabeu)return 35;
                fprintf(stderr,"local_projection_planned_producer rows=%zu in=%zu out=%zu full_output=pass canaries=pass\\n",rows,in,out);
            }
        }
'''+s[i:];p.write_text(s)
