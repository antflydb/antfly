import subprocess,sys
from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_parity_m4_max'
for variant in ['prefill32x64','prefill64x32','prefill8x32','prefill8x16']:
 for flush in [0,64]:
  label=variant+('_resident' if flush==0 else '_cold64');print('START',label,flush=True)
  cmd=[sys.executable,str(p/'benchmark_metal_pair.py'),'--native-library',str(r/'.venv-lighton-vllm-metal/metal_pair_prefill_gates.dylib'),'--timing-library',str(r/'.venv-lighton-vllm-metal/metal_timing_qualified.dylib'),'--suite','prefill-gates','--trials','30','--variant',variant,'--compare-production','--cache-flush-mib',str(flush),'--output',str(out/(label+'.json'))]
  if variant=='prefill32x64' and flush==0:cmd+=['--compile-native-library']
  with open('/private/tmp/ocr-parity-'+label+'.txt','w')as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
  print('DONE',label,flush=True)
