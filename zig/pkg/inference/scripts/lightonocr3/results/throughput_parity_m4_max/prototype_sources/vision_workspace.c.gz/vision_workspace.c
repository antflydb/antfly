// At most two command buffers may own packed vision storage. Reusing within
// one buffer is ordered by the compute encoder; a submitted peer gets a
// separate slot. Growth in an encoded buffer declines to the original SDPA.
static id<MTLBuffer> termite_metal_lightonocr3_vision_workspace(termite_metal_decode_runtime *r,
                                                                id<MTLCommandBuffer> cb, size_t bytes) {
    for (size_t i = 0; i < 2; ++i) {
        if (r->lightonocr3_vision_pack_owners[i] == cb) {
            return r->lightonocr3_vision_pack_buffers[i].length >= bytes
                       ? r->lightonocr3_vision_pack_buffers[i]
                       : nil;
        }
    }
    for (size_t i = 0; i < 2; ++i) {
        id<MTLCommandBuffer> owner = r->lightonocr3_vision_pack_owners[i];
        if (owner != nil && owner.status < MTLCommandBufferStatusCompleted)
            continue;
        if (r->lightonocr3_vision_pack_buffers[i].length < bytes) {
            // Drop the old free allocation before growing: no transient third
            // workspace can escape the two-buffer admission envelope.
            r->lightonocr3_vision_pack_buffers[i] = nil;
            r->lightonocr3_vision_pack_buffers[i] = antfly_observe_metal_buffer(
                [r->device newBufferWithLength:bytes options:MTLResourceStorageModePrivate],
                ANTFLY_BUFFER_OWNED);
        }
        id<MTLBuffer> packed = r->lightonocr3_vision_pack_buffers[i];
        if (packed == nil)
            return nil;
        if (r->active_frame_cb != nil && termite_metal_decode_runtime_retain_frame_resource(r, packed) != 0)
            return nil;
        r->lightonocr3_vision_pack_owners[i] = cb;
        return packed;
    }
    return nil;
}

int termite_metal_decode_runtime_clear_lightonocr3_vision_workspace(termite_metal_decode_runtime *r) {
    if (r == NULL || r->active_frame_cb != nil || r->submitted_frame_cb != nil)
        return -1;
    for (size_t i = 0; i < 2; ++i) {
        id<MTLCommandBuffer> owner = r->lightonocr3_vision_pack_owners[i];
        if (owner != nil && owner.status >= MTLCommandBufferStatusEnqueued &&
            owner.status < MTLCommandBufferStatusCompleted)
            return -2;
    }
    for (size_t i = 0; i < 2; ++i) {
        r->lightonocr3_vision_pack_buffers[i] = nil;
        r->lightonocr3_vision_pack_owners[i] = nil;
    }
    return 0;
}
