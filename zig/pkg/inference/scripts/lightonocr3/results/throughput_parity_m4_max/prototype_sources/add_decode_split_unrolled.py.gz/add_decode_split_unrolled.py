from pathlib import Path
import json
h=Path('.venv-lighton-vllm-metal');shader=(h/'decode_split.metal').read_text();shader=shader.replace('pair_decode_split','pair_decode_unroll')
shader=shader.replace('float acc[B][TM];for(uint r=0;r<B;r++)for(uint t=0;t<TM;t++)acc[r][t]=0.0f;', '''float acc[B][TM];
 #pragma unroll
 for(uint r=0;r<B;r++){
  #pragma unroll
  for(uint t=0;t<TM;t++)acc[r][t]=0.0f;
 }''')
shader=shader.replace('float4 a[B];for(uint r=0;r<B;r++)a[r]=', 'float4 a[B];\n  #pragma unroll\n  for(uint r=0;r<B;r++)a[r]=')
shader=shader.replace('for(uint t=0;t<TM;t++) {','\n  #pragma unroll\n  for(uint t=0;t<TM;t++) {').replace('for(uint r=0;r<B;r++)acc[r][t]+=dot(a[r],v);','\n   #pragma unroll\n   for(uint r=0;r<B;r++)acc[r][t]+=dot(a[r],v);')
shader=shader.replace('for(uint r=0;r<B;r++)for(uint t=0;t<TM;t++){','''#pragma unroll
 for(uint r=0;r<B;r++){
  #pragma unroll
  for(uint t=0;t<TM;t++){''').replace('float v=acc[r][t];for(uint d=SN/2;d>0;d/=2)', 'float v=acc[r][t];\n  #pragma unroll\n  for(uint d=SN/2;d>0;d/=2)').replace(' threadgroup_barrier(mem_flags::mem_threadgroup);',' }\n threadgroup_barrier(mem_flags::mem_threadgroup);').replace('for(uint s=0;s<S;s++)v+=scratch[s*8*N+i];','\n #pragma unroll\n for(uint s=0;s<S;s++)v+=scratch[s*8*N+i];')
shader=shader.replace('#define DB(B) DS(B,4,4,4) DS(B,8,4,4) DS(B,4,8,4) DS(B,8,8,4)', '#define DB(B) DS(B,4,4,4) DS(B,8,4,4) DS(B,8,32,1) DS(B,16,32,1) DS(B,32,32,1) DS(B,16,16,2)')
(h/'decode_unroll.metal').write_text(shader)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_metal_pair.py');s=p.read_text().replace('"decodesplit8n16",','"decodesplit8n16",\n            "decodeunroll4n32",\n            "decodeunroll8n32",\n            "decodeunroll8n1",\n            "decodeunroll16n1",\n            "decodeunroll32n1",\n            "decodeunroll16n4",');p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/metal_pair_benchmark.m');s=p.read_text().replace('pair_variant>=64&&pair_variant<=82','pair_variant>=64&&pair_variant<=88');a=s.index('static int ocr_pair_encode_candidate(');s=s[:a]+'static NSString *pair_decode_unroll_source(void){return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n'for x in shader.splitlines())+';}\n'+s[a:];a=s.index('\n',s.index('static int ocr_pair_encode_candidate(OCRPairCase *c) {'))+1;s=s[:a]+'''    if(pair_variant>=83&&pair_variant<=88){
        static id<MTLComputePipelineState>pipelines[6][8];termite_metal_decode_runtime*r=pair_runtime;
        const size_t splits[6]={4,8,8,16,32,16},lanes[6]={4,4,32,32,32,16},tiles[6]={4,4,1,1,1,2};
        if(!pipelines[0][0]){MTLCompileOptions*o=[MTLCompileOptions new];o.languageVersion=MTLLanguageVersion4_0;o.mathMode=MTLMathModeFast;NSError*err=nil;
          id<MTLLibrary>lib=[r->device newLibraryWithSource:pair_decode_unroll_source() options:o error:&err];if(!lib){fprintf(stderr,"decode unroll: %s\\n",err.localizedDescription.UTF8String);return -1;}
          for(size_t j=0;j<6;j++)for(size_t i=0;i<8;i++)pipelines[j][i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"pair_decode_unroll_%zu_%zu_%zu_%zu",i+1,splits[j],lanes[j],tiles[j]]);
        }
        size_t index=pair_variant-83,S=splits[index],N=(32/lanes[index])*tiles[index];id<MTLComputePipelineState>pipe=pipelines[index][c->rows-1];
        if(!pipe||pipe.maxTotalThreadsPerThreadgroup<S*32)return -1;
        termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
        id<MTLComputeCommandEncoder>e=termite_metal_tracked_compute_command_encoder_for(r->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);if(!e)return -1;
        termite_metal_linear_params p={(uint32_t)c->rows,(uint32_t)c->in_dim,(uint32_t)c->out_dim,0};[e setComputePipelineState:pipe];[e setBuffer:c->input offset:0 atIndex:0];[e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:2];[e setBuffer:c->output offset:0 atIndex:3];[e setBytes:&p length:sizeof(p) atIndex:4];[e setThreadgroupMemoryLength:S*8*N*sizeof(float) atIndex:0];[e dispatchThreadgroups:MTLSizeMake((c->out_dim+N-1)/N,1,1) threadsPerThreadgroup:MTLSizeMake(S*32,1,1)];[e endEncoding];return 0;
    }
'''+s[a:];p.write_text(s)
s=(h/'run_observed_decode_candidates.py').read_text().replace("['decodevec16x2','decodevec32x4','decodempp16','decodempp32','decodegemv1','decodetg']","['decodeunroll4n32','decodeunroll8n32','decodeunroll8n1','decodeunroll16n1','decodeunroll32n1','decodeunroll16n4']").replace("variant=='decodevec16x2'","variant=='decodeunroll4n32'").replace('metal_pair_observed_decode','metal_pair_decode_unroll');(h/'run_decode_unroll_candidates.py').write_text(s)
