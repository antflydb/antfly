from pathlib import Path
import json
h=Path('.venv-lighton-vllm-metal')
shader=r'''#include <metal_stdlib>
using namespace metal;
struct PairChunkParams{uint rows,in_dim,out_dim,pad;};
template<uint B,uint SN,uint TM> inline void pair_chunk_body(device const float*x,device const ushort*w,device const float*b,device float*y,constant PairChunkParams&p,uint2 group,uint sg,uint lane){
 const uint start=group.y*B,col=((group.x*4+sg)*(32/SN)+lane/SN)*TM;
 float acc[B][TM];
 #pragma unroll
 for(uint r=0;r<B;r++){
  #pragma unroll
  for(uint t=0;t<TM;t++)acc[r][t]=0.0f;
 }
 for(uint k=(lane%SN)*4;k<p.in_dim;k+=SN*4){
  float4 a[B];
  #pragma unroll
  for(uint r=0;r<B;r++)a[r]=*((device const float4*)(x+min(start+r,p.rows-1)*p.in_dim+k));
  #pragma unroll
  for(uint t=0;t<TM;t++){
   float4 v=as_type<float4>(uint4(*((device const ushort4*)(w+(col+t)*p.in_dim+k)))<<16);
   #pragma unroll
   for(uint r=0;r<B;r++)acc[r][t]+=dot(a[r],v);
  }
 }
 #pragma unroll
 for(uint r=0;r<B;r++){
  #pragma unroll
  for(uint t=0;t<TM;t++){
   float v=acc[r][t];
   #pragma unroll
   for(uint d=SN/2;d>0;d/=2)v+=simd_shuffle_xor(v,d);
   if(lane%SN==0&&start+r<p.rows)y[(start+r)*p.out_dim+col+t]=v+b[col+t];
  }
 }
}
#define CH(B,SN,TM) kernel void pair_chunk_##B##_##SN##_##TM(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant PairChunkParams&p[[buffer(4)]],uint2 group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){pair_chunk_body<B,SN,TM>(x,w,b,y,p,group,sg,lane);}
#define CB(B) CH(B,16,2) CH(B,16,4) CH(B,32,4) CH(B,32,8)
CB(1) CB(2) CB(3) CB(4)
#undef CB
#undef CH
''';(h/'decode_chunk.metal').write_text(shader)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_metal_pair.py');s=p.read_text().replace('"decodestream32u8",','"decodestream32u8",\n            "decodechunk4s16t2",\n            "decodechunk4s16t4",\n            "decodechunk4s32t4",\n            "decodechunk4s32t8",\n            "decodechunk2s16t4",\n            "decodechunk2s32t8",');a=s.index('                if args.variant == "decodegemv1"');s=s[:a]+'                if args.variant.startswith("decodechunk"):return kind==0 and 2<=rows<=8 and n>32 and missing\n'+s[a:];p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/metal_pair_benchmark.m');s=p.read_text().replace('pair_variant>=64&&pair_variant<=94','pair_variant>=64&&pair_variant<=100');a=s.index('        return c->kind==0&&missing',s.index('size_t ocr_pair_candidate_applies'));s=s[:a]+'''        if(pair_variant>=95)return c->kind==0&&missing&&c->rows>=2&&c->rows<=8&&!tiny;
'''+s[a:];a=s.index('static int ocr_pair_encode_candidate(');s=s[:a]+'static NSString *pair_decode_chunk_source(void){return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n'for x in shader.splitlines())+';}\n'+s[a:];a=s.index('\n',s.index('static int ocr_pair_encode_candidate(OCRPairCase *c) {'))+1;s=s[:a]+'''    if(pair_variant>=95&&pair_variant<=100){
        static id<MTLComputePipelineState>pipelines[4][4];termite_metal_decode_runtime*r=pair_runtime;
        const size_t lanes[4]={16,16,32,32},tiles[4]={2,4,4,8};
        if(!pipelines[0][0]){MTLCompileOptions*o=[MTLCompileOptions new];o.languageVersion=MTLLanguageVersion4_0;o.mathMode=MTLMathModeFast;NSError*err=nil;
          id<MTLLibrary>lib=[r->device newLibraryWithSource:pair_decode_chunk_source() options:o error:&err];if(!lib){fprintf(stderr,"decode chunk: %s\\n",err.localizedDescription.UTF8String);return -1;}
          for(size_t j=0;j<4;j++)for(size_t i=0;i<4;i++)pipelines[j][i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"pair_chunk_%zu_%zu_%zu",i+1,lanes[j],tiles[j]]);
        }
        size_t variant=pair_variant-95,index=variant<4?variant:variant==4?1:3,B=MIN(c->rows,variant<4?(size_t)4:(size_t)2),N=4*(32/lanes[index])*tiles[index];id<MTLComputePipelineState>pipe=pipelines[index][B-1];
        if(!pipe||pipe.maxTotalThreadsPerThreadgroup<128)return -1;
        termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
        id<MTLComputeCommandEncoder>e=termite_metal_tracked_compute_command_encoder_for(r->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);if(!e)return -1;
        termite_metal_linear_params p={(uint32_t)c->rows,(uint32_t)c->in_dim,(uint32_t)c->out_dim,0};[e setComputePipelineState:pipe];[e setBuffer:c->input offset:0 atIndex:0];[e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:2];[e setBuffer:c->output offset:0 atIndex:3];[e setBytes:&p length:sizeof(p) atIndex:4];[e dispatchThreadgroups:MTLSizeMake(c->out_dim/N,(c->rows+B-1)/B,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];[e endEncoding];return 0;
    }
'''+s[a:];p.write_text(s)
s=(h/'run_observed_decode_candidates.py').read_text().replace("['decodevec16x2','decodevec32x4','decodempp16','decodempp32','decodegemv1','decodetg']","['decodechunk4s16t2','decodechunk4s16t4','decodechunk4s32t4','decodechunk4s32t8','decodechunk2s16t4','decodechunk2s32t8']").replace("variant=='decodevec16x2'","variant=='decodechunk4s16t2'").replace('metal_pair_observed_decode','metal_pair_decode_chunk');(h/'run_decode_chunk_candidates.py').write_text(s)
