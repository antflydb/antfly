from pathlib import Path
import sys,subprocess,time,re,json,hashlib,gzip
r=Path.cwd();h=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_parity_m4_max'
def run(name,cmd):
 print('START',name,flush=True)
 with open('/private/tmp/ocr-parity-'+name+'.txt','w')as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',name,flush=True)
for key,source in [('conformance','check_metal_projections.m'),('vision-conformance','check_metal_vision.m')]:
 binary=h/'bin'/('shipping-'+key)
 run('shipping-'+key+'-build',['clang','-O2','-fobjc-arc','-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate',str(p/source),'-o',str(binary)])
 run('shipping-'+key,[str(binary)])
for _ in range(600):
 s=Path('/private/tmp/ocr-parity-shipping-build.txt').read_text()
 if re.search(r'\.zig-cache/o/([0-9a-f]{32})/test(?:\s|$)',s) and '79 selected; 73 passed; 6 skipped.'in s:break
 if 'error:'in s:raise SystemExit('Release build failed')
 time.sleep(1)
else:raise SystemExit('Release build did not complete in ten minutes')
for name,script in [('shipping-gpu-checks-driver','run_shipping_gpu_checks.py'),('shipping-sweeps','run_shipping_sweeps.py'),('shipping-vision-benchmark-build','build_shipping_vision_benchmark.py'),('shipping-vision-benchmark','benchmark_shipping_vision.py'),('shipping-readers','validate_shipping_readers.py')]:run(name,[sys.executable,str(h/script)])
print('All shipping qualification completed',flush=True)
