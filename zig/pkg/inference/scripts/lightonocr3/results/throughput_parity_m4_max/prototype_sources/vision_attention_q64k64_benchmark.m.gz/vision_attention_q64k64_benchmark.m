#include "../zig/pkg/inference/src/backends/metal_kernels.m"
static termite_metal_decode_runtime *vr;
static id<MTLComputePipelineState> vp,vp64;
@interface VisionCase:NSObject { @public size_t seq,heads; id<MTLBuffer> q,k,v,out; } @end
@implementation VisionCase @end
static NSString *vision_candidate_source(void) {return @""
 "kernel void termite_sdpa_f32_vision_hd64_flash_q64(device const float *q [[buffer(0)]], device const float *k [[buffer(1)]], device const float *v [[buffer(2)]], device const float *bias [[buffer(3)]], device const float *mask [[buffer(4)]], device float *output [[buffer(5)]], constant termite_metal_sdpa_f32_params &p [[buffer(6)]], ushort tid [[thread_index_in_threadgroup]], ushort lane [[thread_index_in_simdgroup]], ushort sgitg [[simdgroup_index_in_threadgroup]], uint3 tg [[threadgroup_position_in_grid]]) {\n"
 "    (void)bias; (void)mask; if (p.seq_len == 0u || p.head_dim != 64u || p.bias_mode != 0u || p.has_mask != 0u || p.layout != 1u || sgitg >= 8u) return;\n"
 "    const uint query_tile_count = (p.seq_len + 63u) / 64u; const uint query_tile = tg.x % query_tile_count; const uint tmp = tg.x / query_tile_count; const uint h = tmp % p.num_heads; const uint b = tmp / p.num_heads; if (b >= p.batch) return;\n"
 "    const uint q0 = query_tile * 64u; const uint hidden = p.num_heads * 64u; const uint qgroup_base = uint(sgitg) >> 2u; const uint subgroup = uint(sgitg) & 3u; const uint dslice = subgroup * 16u; const float neg_inf = -3.402823466e+38f;\n"
 "    struct Scratch { half sq[4096]; half skv[2048]; float ss[2048]; half sp[2048]; float sM[64]; float sS[64]; float sdiag[512]; }; threadgroup Scratch scratch; threadgroup half *sq=scratch.sq,*skv=scratch.skv,*sp=scratch.sp; threadgroup float *ss=scratch.ss,*sM=scratch.sM,*sS=scratch.sS,*sdiag=scratch.sdiag; threadgroup float *so=(threadgroup float*)&scratch;\n"
 "    for (uint i = uint(tid); i < 4096u; i += 256u) { const uint qr = i >> 6u; const uint d = i & 63u; const uint qi = q0 + qr; sq[i] = qi < p.seq_len ? half(q[(b * p.seq_len + qi) * hidden + h * 64u + d] * 0.125f) : half(0.0f); }\n"
 "    if (tid < 64u) { sM[tid] = neg_inf; sS[tid] = 0.0f; } for(uint i=uint(tid);i<512u;i+=256u)sdiag[i]=0.0f; threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    simdgroup_float8x8 mo[4][2]; for (uint qp = 0u; qp < 4u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) mo[qp][dt] = make_filled_simdgroup_matrix<float, 8>(0.0f);\n"
 "    for (uint key_start = 0u; key_start < p.seq_len; key_start += 32u) {\n"
 "        for (uint i = uint(tid); i < 2048u; i += 256u) { const uint kr = i >> 6u; const uint d = i & 63u; const uint ki = key_start + kr; skv[i] = ki < p.seq_len ? half(k[(b * p.seq_len + ki) * hidden + h * 64u + d]) : half(0.0f); }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 ms = make_filled_simdgroup_matrix<float, 8>(0.0f); for (uint d = 0u; d < 64u; d += 8u) { simdgroup_half8x8 mq; simdgroup_half8x8 mk; simdgroup_load(mq, sq + qgroup * 512u + d, 64u); simdgroup_load(mk, skv + subgroup * 512u + d, 64u, 0, true); simdgroup_multiply_accumulate(ms, mq, mk, ms); } simdgroup_store(ms, ss + qgroup * 256u + subgroup * 8u, 32u); }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint pass = 0u; pass < 8u; ++pass) { const uint j = uint(sgitg) + pass * 8u; const uint qi = q0 + j; const uint kk = uint(lane); const uint ki = key_start + kk; float sc = qi < p.seq_len && ki < p.seq_len ? ss[j * 32u + kk] : neg_inf; if (!isfinite(sc)) sc = neg_inf; const float row_max = simd_max(sc); const float m_old = sM[j]; const float m_new = max(m_old, row_max); float corr = 0.0f; float e = 0.0f; if (m_new > -3.0e+38f) { corr = m_old > -3.0e+38f ? exp(m_old - m_new) : 0.0f; e = sc > -3.0e+38f ? exp(sc - m_new) : 0.0f; } sp[j * 32u + kk] = half(e); const float row_sum = simd_sum(e); if (lane == 0u) { sS[j] = sS[j] * corr + row_sum; sM[j] = m_new; const uint local_j = j & 7u; sdiag[(j >> 3u) * 64u + local_j * 8u + local_j] = corr; } }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 mcorr; simdgroup_load(mcorr, sdiag + qgroup * 64u, 8u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_float8x8 scaled; simdgroup_multiply(scaled, mcorr, mo[qp][dt]); mo[qp][dt] = scaled; } }\n"
 "        for (uint i = uint(tid); i < 2048u; i += 256u) { const uint kr = i >> 6u; const uint d = i & 63u; const uint ki = key_start + kr; skv[i] = ki < p.seq_len ? half(v[(b * p.seq_len + ki) * hidden + h * 64u + d]) : half(0.0f); }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; for (uint kk8 = 0u; kk8 < 4u; ++kk8) { simdgroup_half8x8 mp; simdgroup_load(mp, sp + qgroup * 256u + kk8 * 8u, 32u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_half8x8 mv; simdgroup_load(mv, skv + kk8 * 512u + dslice + dt * 8u, 64u); simdgroup_multiply_accumulate(mo[qp][dt], mp, mv, mo[qp][dt]); } } }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    }\n"
 "    if (tid < 64u) { const uint local_j = uint(tid) & 7u; const float denom = sS[tid]; sdiag[(uint(tid) >> 3u) * 64u + local_j * 8u + local_j] = denom > 0.0f ? 1.0f / denom : 0.0f; } threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 minv; simdgroup_load(minv, sdiag + qgroup * 64u, 8u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_float8x8 scaled; simdgroup_multiply(scaled, minv, mo[qp][dt]); mo[qp][dt] = scaled; } }\n"
 "    if (q0 + 64u <= p.seq_len) { for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; const uint output_base = (b * p.seq_len + q0 + qgroup * 8u) * hidden + h * 64u + dslice; for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], output + output_base + dt * 8u, hidden); } return; }\n"
 "    for (uint qp = 0u; qp < 4u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], so + (uint(sgitg) + qp * 8u) * 128u + dt * 8u, 16u); threadgroup_barrier(mem_flags::mem_threadgroup); const uint valid_rows = p.seq_len - q0; for (uint i = uint(tid); i < valid_rows * 64u; i += 256u) { const uint qr = i >> 6u; const uint d = i & 63u; const uint owner = (qr >> 3u) * 4u + (d >> 4u); const uint local_r = qr & 7u; const uint local_d = d & 15u; output[(b * p.seq_len + q0 + qr) * hidden + h * 64u + d] = so[owner * 128u + local_r * 16u + local_d]; }\n"
 "}\n"
 "kernel void termite_sdpa_f32_vision_hd64_flash_q64k64(device const float *q [[buffer(0)]], device const float *k [[buffer(1)]], device const float *v [[buffer(2)]], device const float *bias [[buffer(3)]], device const float *mask [[buffer(4)]], device float *output [[buffer(5)]], constant termite_metal_sdpa_f32_params &p [[buffer(6)]], ushort tid [[thread_index_in_threadgroup]], ushort lane [[thread_index_in_simdgroup]], ushort sgitg [[simdgroup_index_in_threadgroup]], uint3 tg [[threadgroup_position_in_grid]]) {\n"
 "    (void)bias; (void)mask; if (p.seq_len == 0u || p.head_dim != 64u || p.bias_mode != 0u || p.has_mask != 0u || p.layout != 1u || sgitg >= 8u) return;\n"
 "    const uint query_tile_count = (p.seq_len + 63u) / 64u; const uint query_tile = tg.x % query_tile_count; const uint tmp = tg.x / query_tile_count; const uint h = tmp % p.num_heads; const uint b = tmp / p.num_heads; if (b >= p.batch) return;\n"
 "    const uint q0 = query_tile * 64u; const uint hidden = p.num_heads * 64u; const uint qgroup_base = uint(sgitg) >> 2u; const uint subgroup = uint(sgitg) & 3u; const uint dslice = subgroup * 16u; const float neg_inf = -3.402823466e+38f;\n"
 "    struct Scratch {half skv[4096];float ss[4096];float sM[64];float sS[64];float sdiag[512];};threadgroup Scratch scratch;threadgroup half *sq=(threadgroup half*)&scratch,*skv=scratch.skv,*sp=(threadgroup half*)scratch.ss;threadgroup float *ss=scratch.ss,*sM=scratch.sM,*sS=scratch.sS,*sdiag=scratch.sdiag;threadgroup float *so=(threadgroup float*)&scratch;\n"
 "    for (uint i = uint(tid); i < 4096u; i += 256u) { const uint qr = i >> 6u; const uint d = i & 63u; const uint qi = q0 + qr; sq[i] = qi < p.seq_len ? half(q[(b * p.seq_len + qi) * hidden + h * 64u + d] * 0.125f) : half(0.0f); }\n"
 "    if (tid < 64u) { sM[tid] = neg_inf; sS[tid] = 0.0f; } for(uint i=uint(tid);i<512u;i+=256u)sdiag[i]=0.0f; threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    simdgroup_half8x8 cached_q[4][8];\n"
 "    #pragma unroll\n"
 "    for(uint qp=0;qp<4;qp++){\n"
 "      uint qgroup=qgroup_base+qp*2;\n"
 "      #pragma unroll\n"
 "      for(uint d=0;d<8;d++)simdgroup_load(cached_q[qp][d],sq+qgroup*512+d*8,64u);\n"
 "    }\n"
 "    threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    simdgroup_float8x8 mo[4][2]; for (uint qp = 0u; qp < 4u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) mo[qp][dt] = make_filled_simdgroup_matrix<float, 8>(0.0f);\n"
 "    for (uint key_start = 0u; key_start < p.seq_len; key_start += 64u) {\n"
 "        for (uint i = uint(tid); i < 4096u; i += 256u) { const uint kr = i >> 6u; const uint d = i & 63u; const uint ki = key_start + kr; skv[i] = ki < p.seq_len ? half(k[(b * p.seq_len + ki) * hidden + h * 64u + d]) : half(0.0f); }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for(uint qp=0;qp<4;qp++) {uint qgroup=qgroup_base+qp*2;\n"
 "          for(uint kp=0;kp<2;kp++) {simdgroup_float8x8 ms=make_filled_simdgroup_matrix<float,8>(0.0f);\n"
 "            #pragma unroll\n"
 "            for(uint d=0;d<8;d++){simdgroup_half8x8 mk;simdgroup_load(mk,skv+(subgroup+kp*4)*512+d*8,64u,0,true);simdgroup_multiply_accumulate(ms,cached_q[qp][d],mk,ms);}\n"
 "            simdgroup_store(ms,ss+qgroup*512+subgroup*8+kp*32,64u);\n"
 "          }\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for(uint pass=0;pass<8;pass++) {uint j=uint(sgitg)+pass*8,qi=q0+j,kk=uint(lane),ki=key_start+kk;\n"
 "          float sc0=qi<p.seq_len&&ki<p.seq_len?ss[j*64+kk]:neg_inf;\n"
 "          float sc1=qi<p.seq_len&&ki+32<p.seq_len?ss[j*64+kk+32]:neg_inf;\n"
 "          if(!isfinite(sc0))sc0=neg_inf;if(!isfinite(sc1))sc1=neg_inf;\n"
 "          simdgroup_barrier(mem_flags::mem_threadgroup);\n"
 "          float row_max=simd_max(max(sc0,sc1)),m_old=sM[j],m_new=max(m_old,row_max),corr=0,e0=0,e1=0;\n"
 "          if(m_new>-3.0e+38f){corr=m_old>-3.0e+38f?exp(m_old-m_new):0;e0=sc0>-3.0e+38f?exp(sc0-m_new):0;e1=sc1>-3.0e+38f?exp(sc1-m_new):0;}\n"
 "          sp[j*128+kk]=half(e0);sp[j*128+kk+32]=half(e1);\n"
 "          float row_sum=simd_sum(e0+e1);\n"
 "          if(lane==0){sS[j]=sS[j]*corr+row_sum;sM[j]=m_new;uint local_j=j&7u;sdiag[(j>>3u)*64+local_j*8+local_j]=corr;}\n"
 "        }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 mcorr; simdgroup_load(mcorr, sdiag + qgroup * 64u, 8u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_float8x8 scaled; simdgroup_multiply(scaled, mcorr, mo[qp][dt]); mo[qp][dt] = scaled; } }\n"
 "        for (uint i = uint(tid); i < 4096u; i += 256u) { const uint kr = i >> 6u; const uint d = i & 63u; const uint ki = key_start + kr; skv[i] = ki < p.seq_len ? half(v[(b * p.seq_len + ki) * hidden + h * 64u + d]) : half(0.0f); }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "        for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; for (uint kk8 = 0u; kk8 < 8u; ++kk8) { simdgroup_half8x8 mp; simdgroup_load(mp, sp + qgroup * 1024u + kk8 * 8u, 128u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_half8x8 mv; simdgroup_load(mv, skv + kk8 * 512u + dslice + dt * 8u, 64u); simdgroup_multiply_accumulate(mo[qp][dt], mp, mv, mo[qp][dt]); } } }\n"
 "        threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    }\n"
 "    if (tid < 64u) { const uint local_j = uint(tid) & 7u; const float denom = sS[tid]; sdiag[(uint(tid) >> 3u) * 64u + local_j * 8u + local_j] = denom > 0.0f ? 1.0f / denom : 0.0f; } threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "    for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 minv; simdgroup_load(minv, sdiag + qgroup * 64u, 8u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_float8x8 scaled; simdgroup_multiply(scaled, minv, mo[qp][dt]); mo[qp][dt] = scaled; } }\n"
 "    if (q0 + 64u <= p.seq_len) { for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; const uint output_base = (b * p.seq_len + q0 + qgroup * 8u) * hidden + h * 64u + dslice; for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], output + output_base + dt * 8u, hidden); } return; }\n"
 "    for (uint qp = 0u; qp < 4u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], so + (uint(sgitg) + qp * 8u) * 128u + dt * 8u, 16u); threadgroup_barrier(mem_flags::mem_threadgroup); const uint valid_rows = p.seq_len - q0; for (uint i = uint(tid); i < valid_rows * 64u; i += 256u) { const uint qr = i >> 6u; const uint d = i & 63u; const uint owner = (qr >> 3u) * 4u + (d >> 4u); const uint local_r = qr & 7u; const uint local_d = d & 15u; output[(b * p.seq_len + q0 + qr) * hidden + h * 64u + d] = so[owner * 128u + local_r * 16u + local_d]; }\n"
 "}\n"
;}
void *vision_create(size_t seq,size_t heads,const float*q,const float*k,const float*v) {
 @autoreleasepool {
 if(!vr){vr=termite_metal_decode_runtime_create();if(!vr)return NULL;
 MTLCompileOptions*o=[MTLCompileOptions new];o.languageVersion=MTLLanguageVersion4_0;o.mathMode=MTLMathModeSafe;
 NSError*err=nil;id<MTLLibrary> lib=[vr->device newLibraryWithSource:[termite_metal_shader_source() stringByAppendingString:vision_candidate_source()] options:o error:&err];
 if(!lib){fprintf(stderr,"vision candidate: %s\n",err.localizedDescription.UTF8String);return NULL;}
 vp64=termite_metal_make_pipeline(vr->device,lib,@"termite_sdpa_f32_vision_hd64_flash_q64k64");
 if(!vp64||vp64.maxTotalThreadsPerThreadgroup<256||vp64.staticThreadgroupMemoryLength>vr->device.maxThreadgroupMemoryLength)return NULL;
 fprintf(stderr,"vision_q64k64 threads=%zu static_bytes=%zu\n",(size_t)vp64.maxTotalThreadsPerThreadgroup,(size_t)vp64.staticThreadgroupMemoryLength);
 vp=termite_metal_make_pipeline(vr->device,lib,@"termite_sdpa_f32_vision_hd64_flash_q64");
 if(!vp||vp.maxTotalThreadsPerThreadgroup<256||vp.staticThreadgroupMemoryLength>vr->device.maxThreadgroupMemoryLength)return NULL;
 fprintf(stderr,"vision_q64 threads=%zu static_bytes=%zu\n",(size_t)vp.maxTotalThreadsPerThreadgroup,(size_t)vp.staticThreadgroupMemoryLength);
 }
 VisionCase*c=[VisionCase new];c->seq=seq;c->heads=heads;size_t bytes=seq*heads*64*4;
 c->q=[vr->device newBufferWithBytes:q length:bytes options:MTLResourceStorageModeShared];
 c->k=[vr->device newBufferWithBytes:k length:bytes options:MTLResourceStorageModeShared];
 c->v=[vr->device newBufferWithBytes:v length:bytes options:MTLResourceStorageModeShared];
 c->out=[vr->device newBufferWithLength:bytes options:MTLResourceStorageModeShared];
 if(!c->q||!c->k||!c->v||!c->out)return NULL;return (__bridge_retained void*)c;
 }}
uint64_t vision_run(void*handle,size_t candidate) {
 @autoreleasepool {VisionCase*c=(__bridge VisionCase*)handle;if(termite_metal_decode_runtime_begin_frame(vr))return 0;
 int rc=0;
 if(!candidate)rc=termite_metal_decode_runtime_sdpa_f32_device(vr,(__bridge void*)c->q,0,(__bridge void*)c->k,0,(__bridge void*)c->v,0,NULL,0,NULL,0,1,c->seq,c->heads,64,0,0,1,1,0,(__bridge void*)c->out,0);
 else{
 termite_metal_sdpa_f32_params p={1,(uint32_t)c->seq,(uint32_t)c->heads,64,0,0,1,0};
 id<MTLComputeCommandEncoder>e=termite_metal_tracked_compute_command_encoder_for(vr->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_ATTENTION);if(!e)return 0;
 [e setComputePipelineState:candidate==2?vp64:vp];[e setBuffer:c->q offset:0 atIndex:0];[e setBuffer:c->k offset:0 atIndex:1];[e setBuffer:c->v offset:0 atIndex:2];[e setBuffer:vr->optional_dummy_buffer offset:0 atIndex:3];[e setBuffer:vr->optional_dummy_buffer offset:0 atIndex:4];[e setBuffer:c->out offset:0 atIndex:5];[e setBytes:&p length:sizeof(p) atIndex:6];
 [e dispatchThreadgroups:MTLSizeMake(c->heads*((c->seq+63)/64),1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];[e endEncoding];}
 if(rc||termite_metal_decode_runtime_submit_frame(vr)||termite_metal_decode_runtime_wait_frame(vr))return 0;return vr->last_frame_gpu_nanos;
 }}
const float*vision_output(void*h){return ((__bridge VisionCase*)h)->out.contents;}
void vision_release(void*h){id obj=CFBridgingRelease(h);(void)obj;}
void vision_shutdown(void){termite_metal_decode_runtime_destroy(vr);vr=NULL;vp=nil;}

static id<MTLBuffer> flush_buffer;static id<MTLComputePipelineState> flush_pipeline;
int vision_flush(size_t mib){
 if(!vr||!mib||mib>512)return -1;
 if(!flush_pipeline){MTLCompileOptions*o=[MTLCompileOptions new];NSError*err=nil;
 id<MTLLibrary>l=[vr->device newLibraryWithSource:@"#include <metal_stdlib>\nusing namespace metal;kernel void flush(device uint*x[[buffer(0)]],uint i[[thread_position_in_grid]]){x[i]^=0x9e3779b9u;}" options:o error:&err];flush_pipeline=termite_metal_make_pipeline(vr->device,l,@"flush");if(!flush_pipeline)return -1;}
 size_t bytes=mib*1024*1024;if(!flush_buffer||flush_buffer.length!=bytes)flush_buffer=[vr->device newBufferWithLength:bytes options:MTLResourceStorageModePrivate];
 id<MTLCommandBuffer>cb=[vr->queue commandBuffer];id<MTLComputeCommandEncoder>e=[cb computeCommandEncoder];if(!e||!flush_buffer)return -1;
 [e setComputePipelineState:flush_pipeline];[e setBuffer:flush_buffer offset:0 atIndex:0];[e dispatchThreads:MTLSizeMake(bytes/4,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];[e endEncoding];[cb commit];[cb waitUntilCompleted];return cb.status==MTLCommandBufferStatusCompleted?0:-1;
}
