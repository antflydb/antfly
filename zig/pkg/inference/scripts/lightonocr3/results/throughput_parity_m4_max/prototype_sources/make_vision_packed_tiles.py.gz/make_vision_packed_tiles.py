from pathlib import Path
import json
h=Path('.venv-lighton-vllm-metal');orig=(h/'vision_packed_q64k64.metal').read_text();pack=orig[orig.index('kernel void vision_pack_half'):];orig=orig[:orig.index('kernel void vision_pack_half')];kernels=[]
for qtile,ktile in [(32,128),(16,256)]:
 qp=qtile//16;kp=ktile//32;scale=qtile//8*64
 s=orig.replace('flash_packed_q64k64(',f'flash_packed_q{qtile}k{ktile}(')
 s=s.replace('(p.seq_len + 63u) / 64u',f'(p.seq_len + {qtile-1}u) / {qtile}u').replace('q0 = query_tile * 64u',f'q0 = query_tile * {qtile}u')
 s=s.replace('float ss[4096];half sp[4096];float sM[64];float sS[64];float sdiag[512];',f'float ss[{qtile*ktile}];half sp[{qtile*ktile}];float sM[{qtile}];float sS[{qtile}];float sdiag[{scale}];')
 s=s.replace('tid < 64u',f'tid < {qtile}u').replace('i<512u',f'i<{scale}u').replace('mo[4][2]',f'mo[{qp}][2]').replace('qp < 4u',f'qp < {qp}u').replace('qp<4;',f'qp<{qp};').replace('kp<2;',f'kp<{kp};').replace('key_start += 64u',f'key_start += {ktile}u')
 s=s.replace('ss+qgroup*512+subgroup*8+kp*32,64u',f'ss+qgroup*{8*ktile}+subgroup*8+kp*32,{ktile}u')
 a=s.index('        for(uint pass=0;pass<8;');b=s.index('        threadgroup_barrier',a)
 line=f'''        for(uint pass=0;pass<{qtile//8};pass++){{uint j=uint(sgitg)+pass*8,qi=q0+j,kk=uint(lane);float scores[{kp}],exps[{kp}];float local_max=neg_inf;
          #pragma unroll
          for(uint t=0;t<{kp};t++){{uint ki=key_start+kk+t*32;float sc=qi<p.seq_len&&ki<p.seq_len?ss[j*{ktile}+kk+t*32]:neg_inf;if(!isfinite(sc))sc=neg_inf;scores[t]=sc;local_max=max(local_max,sc);}}
          float row_max=simd_max(local_max),m_old=sM[j],m_new=max(m_old,row_max),corr=0,local_sum=0;
          if(m_new>-3.0e+38f){{corr=m_old>-3.0e+38f?exp(m_old-m_new):0;
            #pragma unroll
            for(uint t=0;t<{kp};t++){{exps[t]=scores[t]>-3.0e+38f?exp(scores[t]-m_new):0;local_sum+=exps[t];}}
          }}else{{
            #pragma unroll
            for(uint t=0;t<{kp};t++)exps[t]=0;
          }}
          #pragma unroll
          for(uint t=0;t<{kp};t++)sp[j*{ktile}+kk+t*32]=half(exps[t]);
          float row_sum=simd_sum(local_sum);if(lane==0){{sS[j]=sS[j]*corr+row_sum;sM[j]=m_new;uint local_j=j&7u;sdiag[(j>>3u)*64+local_j*8+local_j]=corr;}}
        }}
''';s=s[:a]+line+s[b:]
 s=s.replace('kk8 < 8u',f'kk8 < {ktile//8}u').replace('sp + qgroup * 512u + kk8 * 8u, 64u',f'sp + qgroup * {8*ktile}u + kk8 * 8u, {ktile}u')
 s=s.replace('q0 + 64u <= p.seq_len',f'q0 + {qtile}u <= p.seq_len');(h/f'vision_packed_q{qtile}k{ktile}.metal').write_text(s);kernels.append(s)
c=(h/'vision_attention_packed_benchmark.m').read_text();a=c.index('static NSString *vision_candidate_source');b=c.index('void *vision_create',a);lit='static NSString *vision_candidate_source(void) {return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n' for x in (orig+''.join(kernels)+pack).splitlines())+';}\n';c=c[:a]+lit+c[b:];c=c.replace('vp,packp;', 'vp,packp,vp128,vp256;');i=c.index(' vp=termite_metal_make_pipeline');c=c[:i]+''' vp128=termite_metal_make_pipeline(vr->device,lib,@"termite_sdpa_f32_vision_hd64_flash_packed_q32k128");vp256=termite_metal_make_pipeline(vr->device,lib,@"termite_sdpa_f32_vision_hd64_flash_packed_q16k256");
 if(!vp128||!vp256)return NULL;
 fprintf(stderr,"packed_tiles bytes128=%zu bytes256=%zu\\n",(size_t)vp128.staticThreadgroupMemoryLength,(size_t)vp256.staticThreadgroupMemoryLength);
'''+c[i:];c=c.replace('3*((seq+63)/64*64)*heads*64*2','3*((seq+255)/256*256)*heads*64*2');c=c.replace('(uint32_t)((c->seq+63)/64*64)','(uint32_t)((c->seq+255)/256*256)');c=c.replace('[e setComputePipelineState:vp];','[e setComputePipelineState:candidate==1?vp:candidate==2?vp128:vp256];');c=c.replace('c->heads*((c->seq+63)/64)','c->heads*((c->seq+(candidate==1?63:candidate==2?31:15))/(candidate==1?64:candidate==2?32:16))');(h/'vision_attention_packed_tiles_benchmark.m').write_text(c)
