from pathlib import Path
import json
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text()
s=s.replace('    id<MTLComputePipelineState> lightonocr3_local_down_vector4;', '    id<MTLComputePipelineState> lightonocr3_local_down_vector4;\n    id<MTLComputePipelineState> lightonocr3_recurrent_gate_vectors[2][8];')
shader=Path('.venv-lighton-vllm-metal/decode_unroll.metal').read_text();shader=shader[shader.index('template<uint B'):];shader=shader.replace('pair_decode_unroll','termite_lightonocr3_recurrent_gate').replace('PairDecodeSplitParams','termite_lightonocr3_local_params');shader=shader.replace('#define DB(B) DS(B,4,4,4) DS(B,8,4,4) DS(B,8,32,1) DS(B,16,32,1) DS(B,32,32,1) DS(B,16,16,2)','#define DB(B) DS(B,8,32,1) DS(B,16,32,1)')
a=s.index('           "template<uint B,uint SN,uint TM,bool GATE>');s=s[:a]+''.join('           '+json.dumps(line+'\n')+'\n'for line in shader.splitlines())+s[a:]
a=s.index('            runtime->lightonocr3_local_down_vector4=');b=s.index('\n',a)+1;s=s[:b]+'''            for(size_t model=0;model<2;model++)for(size_t row=0;row<8;row++)
                runtime->lightonocr3_recurrent_gate_vectors[model][row]=termite_metal_make_pipeline(device,library,[NSString stringWithFormat:@"termite_lightonocr3_recurrent_gate_%zu_%zu_32_1",row+1,model?(size_t)16:(size_t)8]);
'''+s[b:]
s=s.replace('    runtime->lightonocr3_local_down_vector4=nil;', '    runtime->lightonocr3_local_down_vector4=nil;\n    for(size_t model=0;model<2;model++)for(size_t row=0;row<8;row++)runtime->lightonocr3_recurrent_gate_vectors[model][row]=nil;')
a=s.index('static int termite_metal_try_lightonocr3_local_projection(');b=s.index('static int termite_metal_try_lightonocr3_down_split',a);v=s[a:b];v=v.replace('if (rows < 2 || rows > 8','if (rows < 1 || rows > 8',1);v=v.replace('    const bool qkv =','    const bool recurrent_gate = (in == 1024 && out == 16) || (in == 2560 && out == 32);\n    if (rows == 1 && !recurrent_gate) return 0;\n    const bool qkv =',1);v=v.replace('    if (rows <= 4 && (qkv || ffn)) {','''    if (recurrent_gate) {
        const size_t model = in == 2560, splits = model ? 16 : 8;
        p = r->lightonocr3_recurrent_gate_vectors[model][rows - 1];
        columns = 1;
        threads = splits * 32;
        memory = splits * 8 * sizeof(float);
    } else if (rows <= 4 && (qkv || ffn)) {''',1);v=v.replace('memory ? "lightonocr3_down_local_tg"','recurrent_gate ? "lightonocr3_recurrent_gate_tg" : memory ? "lightonocr3_down_local_tg"');s=s[:a]+v+s[b:]
a=s.index('int termite_metal_decode_runtime_apply_linear_device(');a=s.index('        bool frame_owned = true;',a);s=s[:a]+'''        const int local_rc = termite_metal_try_lightonocr3_local_projection(runtime, slot, input_buffer, input_offset, 1, in_dim, out_dim, output_buffer, output_offset);
        if(local_rc != 0) return local_rc == 1 ? 0 : local_rc;
'''+s[a:];p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m');s=p.read_text();a=s.index('        const bool narrow_prefill =');s=s[:a]+'''        const bool recurrent_gate = rows>=1 && rows<=8 &&
            ((in==1024&&out==16)||(in==2560&&out==32)) &&
            r->lightonocr3_recurrent_gate_vectors[in==2560][rows-1]!=nil &&
            !termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_LOCAL_KERNELS"));
'''+s[a:];s=s.replace('((rows >= 2 && rows <= 8) || narrow_prefill || post_prefill)', '((rows >= 2 && rows <= 8) || recurrent_gate || narrow_prefill || post_prefill)').replace('if ((narrow_prefill || post_prefill) && local != 1)','if ((recurrent_gate || narrow_prefill || post_prefill) && local != 1)');a=s.index('        const size_t prefill_rows[]');s=s[:a]+'''        for(size_t row=1;row<=8;row++)
            if(projection(r,row,1024,16,4)||projection(r,row,2560,32,4))return 144;
        for(size_t model=0;model<2;model++){
            id<MTLComputePipelineState> saved=r->lightonocr3_recurrent_gate_vectors[model][7];
            r->lightonocr3_recurrent_gate_vectors[model][7]=nil;
            if(projection(r,8,model?2560:1024,model?32:16,4))return 145;
            r->lightonocr3_recurrent_gate_vectors[model][7]=saved;
        }
        setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_LOCAL_KERNELS","1",1);
        if(projection(r,1,1024,16,4)||projection(r,8,2560,32,4))return 146;
        unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_LOCAL_KERNELS");
        if(projection(r,8,1024,16,1)||projection(r,9,2560,32,4))return 147;
'''+s[a:];p.write_text(s)
