from pathlib import Path
import json
h=Path('.venv-lighton-vllm-metal')
shader=r'''#include <metal_stdlib>
using namespace metal;
struct PairStreamParams{uint rows,in_dim,out_dim,pad;};
template<uint B,uint SN,uint U> inline void pair_stream_body(device const float*x,device const ushort*w,device const float*b,device float*y,constant PairStreamParams&p,uint group,uint sg,uint lane){
 const uint col=group*4+sg*(32/SN)+lane/SN,kLane=lane%SN;
 float acc[B];
 #pragma unroll
 for(uint r=0;r<B;r++)acc[r]=0.0f;
 const uint step=SN*4,block=step*U,full=p.in_dim/block*block;
 for(uint base=0;base<full;base+=block){
  float4 weights[U];
  #pragma unroll
  for(uint u=0;u<U;u++)weights[u]=as_type<float4>(uint4(*((device const ushort4*)(w+col*p.in_dim+base+u*step+kLane*4)))<<16);
  #pragma unroll
  for(uint r=0;r<B;r++){
   float partial=0.0f;
   #pragma unroll
   for(uint u=0;u<U;u++)partial+=dot(weights[u],*((device const float4*)(x+r*p.in_dim+base+u*step+kLane*4)));
   acc[r]+=partial;
  }
 }
 for(uint k=full+kLane*4;k<p.in_dim;k+=step){
  float4 weight=as_type<float4>(uint4(*((device const ushort4*)(w+col*p.in_dim+k)))<<16);
  #pragma unroll
  for(uint r=0;r<B;r++)acc[r]+=dot(weight,*((device const float4*)(x+r*p.in_dim+k)));
 }
 #pragma unroll
 for(uint r=0;r<B;r++){
  float v=acc[r];
  #pragma unroll
  for(uint d=SN/2;d>0;d/=2)v+=simd_shuffle_xor(v,d);
  if(kLane==0)y[r*p.out_dim+col]=v+b[col];
 }
}
#define ST(B,SN,U) kernel void pair_stream_##B##_##SN##_##U(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant PairStreamParams&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){pair_stream_body<B,SN,U>(x,w,b,y,p,group,sg,lane);}
#define SB(B) ST(B,8,4) ST(B,16,4) ST(B,32,4) ST(B,8,8) ST(B,16,8) ST(B,32,8)
SB(1) SB(2) SB(3) SB(4) SB(5) SB(6) SB(7) SB(8)
#undef SB
#undef ST
'''
(h/'decode_stream.metal').write_text(shader)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_metal_pair.py');s=p.read_text().replace('"decodeunroll16n4",','"decodeunroll16n4",\n            "decodestream8u4",\n            "decodestream16u4",\n            "decodestream32u4",\n            "decodestream8u8",\n            "decodestream16u8",\n            "decodestream32u8",');p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/metal_pair_benchmark.m');s=p.read_text().replace('pair_variant>=64&&pair_variant<=88','pair_variant>=64&&pair_variant<=94');a=s.index('static int ocr_pair_encode_candidate(');s=s[:a]+'static NSString *pair_decode_stream_source(void){return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n'for x in shader.splitlines())+';}\n'+s[a:];a=s.index('\n',s.index('static int ocr_pair_encode_candidate(OCRPairCase *c) {'))+1;s=s[:a]+'''    if(pair_variant>=89&&pair_variant<=94){
        static id<MTLComputePipelineState>pipelines[6][8];termite_metal_decode_runtime*r=pair_runtime;
        if(!pipelines[0][0]){MTLCompileOptions*o=[MTLCompileOptions new];o.languageVersion=MTLLanguageVersion4_0;o.mathMode=MTLMathModeFast;NSError*err=nil;
          id<MTLLibrary>lib=[r->device newLibraryWithSource:pair_decode_stream_source() options:o error:&err];if(!lib){fprintf(stderr,"decode stream: %s\\n",err.localizedDescription.UTF8String);return -1;}
          for(size_t j=0;j<6;j++)for(size_t i=0;i<8;i++)pipelines[j][i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"pair_stream_%zu_%zu_%zu",i+1,(size_t)8<<(j%3),j<3?(size_t)4:(size_t)8]);
        }
        size_t index=pair_variant-89,SN=8<<(index%3),threads=SN*4;id<MTLComputePipelineState>pipe=pipelines[index][c->rows-1];
        if(!pipe||pipe.maxTotalThreadsPerThreadgroup<threads)return -1;
        termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
        id<MTLComputeCommandEncoder>e=termite_metal_tracked_compute_command_encoder_for(r->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);if(!e)return -1;
        termite_metal_linear_params p={(uint32_t)c->rows,(uint32_t)c->in_dim,(uint32_t)c->out_dim,0};[e setComputePipelineState:pipe];[e setBuffer:c->input offset:0 atIndex:0];[e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:2];[e setBuffer:c->output offset:0 atIndex:3];[e setBytes:&p length:sizeof(p) atIndex:4];[e dispatchThreadgroups:MTLSizeMake(c->out_dim/4,1,1) threadsPerThreadgroup:MTLSizeMake(threads,1,1)];[e endEncoding];return 0;
    }
'''+s[a:];p.write_text(s)
s=(h/'run_observed_decode_candidates.py').read_text().replace("['decodevec16x2','decodevec32x4','decodempp16','decodempp32','decodegemv1','decodetg']","['decodestream8u4','decodestream16u4','decodestream32u4','decodestream8u8','decodestream16u8','decodestream32u8']").replace("variant=='decodevec16x2'","variant=='decodestream8u4'").replace('metal_pair_observed_decode','metal_pair_decode_stream');(h/'run_decode_stream_candidates.py').write_text(s)
