#include <metal_tensor>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace mpp::tensor_ops;
kernel void termite_sdpa_f32_vision_hd64_flash_packed_mpp(device half*q[[buffer(0)]],device half*k[[buffer(1)]],device half*v[[buffer(2)]],device const float*bias[[buffer(3)]],device const float*mask[[buffer(4)]],device float*output[[buffer(5)]],constant termite_metal_sdpa_f32_params&p[[buffer(6)]],uint tid[[thread_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]],uint group[[threadgroup_position_in_grid]]){
 const uint tiles=(p.seq_len+31)/32,qtile=group%tiles,h=(group/tiles)%p.num_heads,b=group/(tiles*p.num_heads),q0=qtile*32,qrow=(sg/4)*16,kcol=(sg%4)*32,dcol=(sg%4)*16,base=(b*p.num_heads+h)*p.reserved1*64;
 threadgroup float scores[32*128],rowmax[32],rowsum[32],correction[32];threadgroup half probs[32*128];
 if(tid<32){rowmax[tid]=-INFINITY;rowsum[tid]=0;}threadgroup_barrier(mem_flags::mem_threadgroup);
 tensor<device half,dextents<int,2>,tensor_inline> Q(q+base+(q0+qrow)*64,dextents<int,2>(64,16),array<int,2>{1,64});
 tensor<threadgroup half,dextents<int,2>,tensor_inline> P(probs+qrow*128,dextents<int,2>(128,16),array<int,2>{1,128});
 tensor<threadgroup float,dextents<int,2>,tensor_inline> S(scores+qrow*128+kcol,dextents<int,2>(32,16),array<int,2>{1,128});
 constexpr auto qkd=matmul2d_descriptor(16,32,64,false,true,false);matmul2d<qkd,execution_simdgroups<1>> qkop;
 constexpr auto pvd=matmul2d_descriptor(16,16,128,false,false,false,matmul2d_descriptor::mode::multiply_accumulate);matmul2d<pvd,execution_simdgroups<1>> pvop;
 tensor<device half,dextents<int,2>,tensor_inline> V(v+base+dcol,dextents<int,2>(16,128),array<int,2>{1,64});
 auto out=pvop.get_destination_cooperative_tensor<decltype(P),decltype(V),float>();
 for(ushort i=0;i<out.get_capacity();i++)out[i]=0;
 for(uint start=0;start<p.seq_len;start+=128){
  tensor<device half,dextents<int,2>,tensor_inline> K(k+base+(start+kcol)*64,dextents<int,2>(64,32),array<int,2>{1,64});
  auto dot=qkop.get_destination_cooperative_tensor<decltype(Q),decltype(K),float>();qkop.run(Q,K,dot);dot.store(S);
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint pass=0;pass<4;pass++){
   uint row=sg+pass*8;float x[4],e[4],m=-INFINITY;
   for(uint j=0;j<4;j++){x[j]=(q0+row<p.seq_len&&start+lane+j*32<p.seq_len)?scores[row*128+lane+j*32]:-INFINITY;m=max(m,x[j]);}
   m=simd_max(m);float nm=max(rowmax[row],m),c=isfinite(nm)&&isfinite(rowmax[row])?exp(rowmax[row]-nm):0,sum=0;
   for(uint j=0;j<4;j++){e[j]=isfinite(x[j])?exp(x[j]-nm):0;probs[row*128+lane+j*32]=half(e[j]);sum+=e[j];}
   sum=simd_sum(sum);if(lane==0){rowmax[row]=nm;rowsum[row]=rowsum[row]*c+sum;correction[row]=c;}
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);out[i]*=correction[qrow+c[1]];}
  tensor<device half,dextents<int,2>,tensor_inline> vb(v+base+start*64+dcol,dextents<int,2>(16,128),array<int,2>{1,64});
  pvop.run(P,vb,out);
 }
 for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);uint row=qrow+c[1],d=dcol+c[0];if(q0+row<p.seq_len)output[((b*p.seq_len+q0+row)*p.num_heads+h)*64+d]=rowsum[row]>0?out[i]/rowsum[row]:0;}
}
