#include <metal_stdlib>
using namespace metal;
struct PairDecodeSplitParams {uint rows,in_dim,out_dim,pad;};
template<uint B,uint S,uint SN,uint TM> inline void pair_decode_unroll_body(device const float*x,device const ushort*w,device const float*b,device float*y,constant PairDecodeSplitParams&p,uint group,uint sg,uint lane,uint tid,threadgroup float*scratch){
 const uint N=(32/SN)*TM,localcol=(lane/SN)*TM,col=group*N+localcol,chunk=p.in_dim/S;
 float acc[B][TM];
 #pragma unroll
 for(uint r=0;r<B;r++){
  #pragma unroll
  for(uint t=0;t<TM;t++)acc[r][t]=0.0f;
 }
 for(uint k=sg*chunk+(lane%SN)*4;k<(sg+1)*chunk;k+=SN*4){
  float4 a[B];
  #pragma unroll
  for(uint r=0;r<B;r++)a[r]=*((device const float4*)(x+r*p.in_dim+k));
  
  #pragma unroll
  for(uint t=0;t<TM;t++) {float4 v=float4(0.0f);if(col+t<p.out_dim){ushort4 z=*((device const ushort4*)(w+(col+t)*p.in_dim+k));v=as_type<float4>(uint4(z)<<16);}
   #pragma unroll
   for(uint r=0;r<B;r++)acc[r][t]+=dot(a[r],v);}
 }
 #pragma unroll
 for(uint r=0;r<B;r++){
  #pragma unroll
  for(uint t=0;t<TM;t++){
  float v=acc[r][t];
  #pragma unroll
  for(uint d=SN/2;d>0;d/=2)v+=simd_shuffle_xor(v,d);
  if(lane%SN==0)scratch[sg*8*N+r*N+localcol+t]=v;
 }
 }
 threadgroup_barrier(mem_flags::mem_threadgroup);
 for(uint i=tid;i<B*N;i+=S*32){uint c=group*N+i%N;if(c<p.out_dim){float v=0.0f;
 #pragma unroll
 for(uint s=0;s<S;s++)v+=scratch[s*8*N+i];y[(i/N)*p.out_dim+c]=v+b[c];}}
}
#define DS(B,S,SN,TM) kernel void pair_decode_unroll_##B##_##S##_##SN##_##TM(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant PairDecodeSplitParams&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint tid[[thread_index_in_threadgroup]],threadgroup float*scratch[[threadgroup(0)]]){pair_decode_unroll_body<B,S,SN,TM>(x,w,b,y,p,group,sg,lane,tid,scratch);}
#define DB(B) DS(B,4,4,4) DS(B,8,4,4) DS(B,8,32,1) DS(B,16,32,1) DS(B,32,32,1) DS(B,16,16,2)
DB(1) DB(2) DB(3) DB(4) DB(5) DB(6) DB(7) DB(8)
#undef DB
#undef DS
