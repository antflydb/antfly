import sys,subprocess
from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_parity_m4_max'
cases=[('actual_page_shapes_resident','page-shapes',0,'production',False,True),('actual_page_shapes_cold64','page-shapes',64,'production',False,False),('actual_all_rows_resident','all-rows',0,'production',False,False),('actual_all_rows_cold64','all-rows',64,'production',False,False),('actual_prefill_previous_vs_current_resident','prefill-gates',0,'previousprefill',True,False),('actual_prefill_previous_vs_current_cold64','prefill-gates',64,'previousprefill',True,False)]
for label,suite,flush,variant,compare,compile in cases:
 print('START',label,flush=True)
 cmd=[sys.executable,str(p/'benchmark_metal_pair.py'),'--native-library',str(r/'.venv-lighton-vllm-metal/metal_pair_actual_final.dylib'),'--timing-library',str(r/'.venv-lighton-vllm-metal/metal_timing_qualified.dylib'),'--suite',suite,'--trials','30','--variant',variant,'--cache-flush-mib',str(flush),'--output',str(out/(label+'.json'))]
 if compile:cmd+=['--compile-native-library']
 if compare:cmd+=['--compare-production']
 with open('/private/tmp/ocr-parity-'+label+'.txt','w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)
