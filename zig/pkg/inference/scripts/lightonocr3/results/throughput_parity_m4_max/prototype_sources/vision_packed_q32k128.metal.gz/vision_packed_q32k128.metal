kernel void termite_sdpa_f32_vision_hd64_flash_packed_q32k128(device const half *q [[buffer(0)]], device const half *k [[buffer(1)]], device const half *v [[buffer(2)]], device const float *bias [[buffer(3)]], device const float *mask [[buffer(4)]], device float *output [[buffer(5)]], constant termite_metal_sdpa_f32_params &p [[buffer(6)]], ushort tid [[thread_index_in_threadgroup]], ushort lane [[thread_index_in_simdgroup]], ushort sgitg [[simdgroup_index_in_threadgroup]], uint3 tg [[threadgroup_position_in_grid]]) {
    (void)bias; (void)mask; if (p.seq_len == 0u || p.head_dim != 64u || p.bias_mode != 0u || p.has_mask != 0u || p.layout != 1u || sgitg >= 8u) return;
    const uint query_tile_count = (p.seq_len + 31u) / 32u; const uint query_tile = tg.x % query_tile_count; const uint tmp = tg.x / query_tile_count; const uint h = tmp % p.num_heads; const uint b = tmp / p.num_heads; if (b >= p.batch) return;
    const uint q0 = query_tile * 32u; const uint hidden = p.num_heads * 64u; const uint qgroup_base = uint(sgitg) >> 2u; const uint subgroup = uint(sgitg) & 3u; const uint dslice = subgroup * 16u; const float neg_inf = -3.402823466e+38f;
    struct Scratch{float ss[4096];half sp[4096];float sM[32];float sS[32];float sdiag[256];};threadgroup Scratch scratch;threadgroup half*sp=scratch.sp;threadgroup float*ss=scratch.ss,*sM=scratch.sM,*sS=scratch.sS,*sdiag=scratch.sdiag,*so=(threadgroup float*)&scratch;
    const uint head_base=(b*p.num_heads+h)*p.reserved1*64u;
    if (tid < 32u) { sM[tid] = neg_inf; sS[tid] = 0.0f; } for(uint i=uint(tid);i<256u;i+=256u)sdiag[i]=0.0f; threadgroup_barrier(mem_flags::mem_threadgroup);
    simdgroup_float8x8 mo[2][2]; for (uint qp = 0u; qp < 2u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) mo[qp][dt] = make_filled_simdgroup_matrix<float, 8>(0.0f);
    for (uint key_start = 0u; key_start < p.seq_len; key_start += 128u) {
        for(uint qp=0;qp<2;qp++) {uint qgroup=qgroup_base+qp*2;
          for(uint kp=0;kp<4;kp++) {simdgroup_float8x8 ms=make_filled_simdgroup_matrix<float,8>(0.0f);
            #pragma unroll
            for(uint d=0;d<8;d++){simdgroup_half8x8 mq,mk;simdgroup_load(mq,q+head_base+(q0+qgroup*8)*64+d*8,64u);simdgroup_load(mk,k+head_base+(key_start+(subgroup+kp*4)*8)*64+d*8,64u,0,true);simdgroup_multiply_accumulate(ms,mq,mk,ms);}
            simdgroup_store(ms,ss+qgroup*1024+subgroup*8+kp*32,128u);
          }
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
        for(uint pass=0;pass<4;pass++){uint j=uint(sgitg)+pass*8,qi=q0+j,kk=uint(lane);float scores[4],exps[4];float local_max=neg_inf;
          #pragma unroll
          for(uint t=0;t<4;t++){uint ki=key_start+kk+t*32;float sc=qi<p.seq_len&&ki<p.seq_len?ss[j*128+kk+t*32]:neg_inf;if(!isfinite(sc))sc=neg_inf;scores[t]=sc;local_max=max(local_max,sc);}
          float row_max=simd_max(local_max),m_old=sM[j],m_new=max(m_old,row_max),corr=0,local_sum=0;
          if(m_new>-3.0e+38f){corr=m_old>-3.0e+38f?exp(m_old-m_new):0;
            #pragma unroll
            for(uint t=0;t<4;t++){exps[t]=scores[t]>-3.0e+38f?exp(scores[t]-m_new):0;local_sum+=exps[t];}
          }else{
            #pragma unroll
            for(uint t=0;t<4;t++)exps[t]=0;
          }
          #pragma unroll
          for(uint t=0;t<4;t++)sp[j*128+kk+t*32]=half(exps[t]);
          float row_sum=simd_sum(local_sum);if(lane==0){sS[j]=sS[j]*corr+row_sum;sM[j]=m_new;uint local_j=j&7u;sdiag[(j>>3u)*64+local_j*8+local_j]=corr;}
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
        for (uint qp = 0u; qp < 2u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 mcorr; simdgroup_load(mcorr, sdiag + qgroup * 64u, 8u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_float8x8 scaled; simdgroup_multiply(scaled, mcorr, mo[qp][dt]); mo[qp][dt] = scaled; } }
        for (uint qp = 0u; qp < 2u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; for (uint kk8 = 0u; kk8 < 16u; ++kk8) { simdgroup_half8x8 mp; simdgroup_load(mp, sp + qgroup * 1024u + kk8 * 8u, 128u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_half8x8 mv; simdgroup_load(mv, v + head_base + (key_start + kk8 * 8u) * 64u + dslice + dt * 8u, 64u); simdgroup_multiply_accumulate(mo[qp][dt], mp, mv, mo[qp][dt]); } } }
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (tid < 32u) { const uint local_j = uint(tid) & 7u; const float denom = sS[tid]; sdiag[(uint(tid) >> 3u) * 64u + local_j * 8u + local_j] = denom > 0.0f ? 1.0f / denom : 0.0f; } threadgroup_barrier(mem_flags::mem_threadgroup);
    for (uint qp = 0u; qp < 2u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 minv; simdgroup_load(minv, sdiag + qgroup * 64u, 8u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_float8x8 scaled; simdgroup_multiply(scaled, minv, mo[qp][dt]); mo[qp][dt] = scaled; } }
    if (q0 + 32u <= p.seq_len) { for (uint qp = 0u; qp < 2u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; const uint output_base = (b * p.seq_len + q0 + qgroup * 8u) * hidden + h * 64u + dslice; for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], output + output_base + dt * 8u, hidden); } return; }
    for (uint qp = 0u; qp < 2u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], so + (uint(sgitg) + qp * 8u) * 128u + dt * 8u, 16u); threadgroup_barrier(mem_flags::mem_threadgroup); const uint valid_rows = p.seq_len - q0; for (uint i = uint(tid); i < valid_rows * 64u; i += 256u) { const uint qr = i >> 6u; const uint d = i & 63u; const uint owner = (qr >> 3u) * 4u + (d >> 4u); const uint local_r = qr & 7u; const uint local_d = d & 15u; output[(b * p.seq_len + q0 + qr) * hidden + h * 64u + d] = so[owner * 128u + local_r * 16u + local_d]; }
}

