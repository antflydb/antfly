from pathlib import Path
import sys
if "4f30719e950ef8da6cea15266c7be42b" in sys.argv[1] and sys.argv[2:]==["08_refill_control"]:sys.argv[2]="08_middle_snapshot"
p=Path('.venv-lighton-vllm-metal/run_stream_round.py')
s=p.read_text().replace("for name in sys.argv[2:]:","cases['08_middle_snapshot']=cases['08_refill_control']\nfor name in sys.argv[2:]:").replace("cases['08_refill_profile']=", "cases['08_shipping']=cases['08_refill_control']\ncases['4b_shipping']=cases['4b_refill_control']\ncases['08_shipping_wave']=cases['08_wave_control']\ncases['4b_shipping_wave']=cases['4b_wave_control']\ncases['08_shipping_rows4']=cases['08_refill_control']\ncases['florence_shipping']=cases['florence_f16']\ncases['08_refill_profile']=")
exec(compile(s,str(p),'exec'))
