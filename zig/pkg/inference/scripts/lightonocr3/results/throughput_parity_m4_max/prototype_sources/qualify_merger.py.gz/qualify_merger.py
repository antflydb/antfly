from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path.cwd();h=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max';sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
f=json.loads((h/'vision-kernels-freeze.json').read_text());assert all(sha(k)==v for k,v in f.items())
s=Path('/private/tmp/ocr-parity-vision-build.txt').read_text();import re
binary=r/'zig/.zig-cache/o'/re.findall(r'\.zig-cache/o/([0-9a-f]{32})/test(?:\s|$)',s)[-1]/'test';base='58d7e441dd3c2f19584d99b5baa321659a387ef7';diff=subprocess.check_output(['git','diff',base,'--','zig/pkg/inference/src'])
(p/'vision_build_manifest.json').write_text(json.dumps(dict(runtime_commit=base,runtime_source_diff_sha256=hashlib.sha256(diff).hexdigest(),binary_sha256=sha(binary),runtime_files_sha256=f),indent=2)+'\n')
(p/'vision_runtime_before_merger.patch.gz').write_bytes(gzip.compress(diff,mtime=0))
archive=p/'vision_benchmark_sources';archive.mkdir(exist_ok=True)
for n in ['benchmark_metal_pair.py','metal_pair_benchmark.m']:(archive/n).write_bytes((p.parent.parent/n).read_bytes())
c=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=c.read_text();start=s.index('static int termite_metal_try_lightonocr3_mpp(');i=s.index('(in_dim == 3072 && (out_dim == 768 || out_dim == 1024 || out_dim == 3072))',start);old='(in_dim == 3072 && (out_dim == 768 || out_dim == 1024 || out_dim == 3072))';new='''(in_dim == 3072 && (out_dim == 768 || out_dim == 1024 || out_dim == 3072 ||
                           (out_dim == 2560 && rows <= 1024 &&
                            !termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_MERGER_MPP")))))''';s=s[:i]+s[i:].replace(old,new,1);c.write_text(s)
f={k:sha(k) for k in f};(h/'merger-kernels-freeze.json').write_text(json.dumps(f,indent=2)+'\n')
