kernel void termite_sdpa_f32_vision_hd64_flash_packed_q64k64(device const half *q [[buffer(0)]], device const half *k [[buffer(1)]], device const half *v [[buffer(2)]], device const float *bias [[buffer(3)]], device const float *mask [[buffer(4)]], device float *output [[buffer(5)]], constant termite_metal_sdpa_f32_params &p [[buffer(6)]], ushort tid [[thread_index_in_threadgroup]], ushort lane [[thread_index_in_simdgroup]], ushort sgitg [[simdgroup_index_in_threadgroup]], uint3 tg [[threadgroup_position_in_grid]]) {
    (void)bias; (void)mask; if (p.seq_len == 0u || p.head_dim != 64u || p.bias_mode != 0u || p.has_mask != 0u || p.layout != 1u || sgitg >= 8u) return;
    const uint query_tile_count = (p.seq_len + 63u) / 64u; const uint query_tile = tg.x % query_tile_count; const uint tmp = tg.x / query_tile_count; const uint h = tmp % p.num_heads; const uint b = tmp / p.num_heads; if (b >= p.batch) return;
    const uint q0 = query_tile * 64u; const uint hidden = p.num_heads * 64u; const uint qgroup_base = uint(sgitg) >> 2u; const uint subgroup = uint(sgitg) & 3u; const uint dslice = subgroup * 16u; const float neg_inf = -3.402823466e+38f;
    struct Scratch{float ss[4096];half sp[4096];float sM[64];float sS[64];float sdiag[512];};threadgroup Scratch scratch;threadgroup half*sp=scratch.sp;threadgroup float*ss=scratch.ss,*sM=scratch.sM,*sS=scratch.sS,*sdiag=scratch.sdiag,*so=(threadgroup float*)&scratch;
    const uint head_base=(b*p.num_heads+h)*p.reserved1*64u;
    if (tid < 64u) { sM[tid] = neg_inf; sS[tid] = 0.0f; } for(uint i=uint(tid);i<512u;i+=256u)sdiag[i]=0.0f; threadgroup_barrier(mem_flags::mem_threadgroup);
    simdgroup_float8x8 mo[4][2]; for (uint qp = 0u; qp < 4u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) mo[qp][dt] = make_filled_simdgroup_matrix<float, 8>(0.0f);
    for (uint key_start = 0u; key_start < p.seq_len; key_start += 64u) {
        for(uint qp=0;qp<4;qp++) {uint qgroup=qgroup_base+qp*2;
          for(uint kp=0;kp<2;kp++) {simdgroup_float8x8 ms=make_filled_simdgroup_matrix<float,8>(0.0f);
            #pragma unroll
            for(uint d=0;d<8;d++){simdgroup_half8x8 mq,mk;simdgroup_load(mq,q+head_base+(q0+qgroup*8)*64+d*8,64u);simdgroup_load(mk,k+head_base+(key_start+(subgroup+kp*4)*8)*64+d*8,64u,0,true);simdgroup_multiply_accumulate(ms,mq,mk,ms);}
            simdgroup_store(ms,ss+qgroup*512+subgroup*8+kp*32,64u);
          }
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
        for(uint pass=0;pass<8;pass++) {uint j=uint(sgitg)+pass*8,qi=q0+j,kk=uint(lane),ki=key_start+kk;
          float sc0=qi<p.seq_len&&ki<p.seq_len?ss[j*64+kk]:neg_inf;
          float sc1=qi<p.seq_len&&ki+32<p.seq_len?ss[j*64+kk+32]:neg_inf;
          if(!isfinite(sc0))sc0=neg_inf;if(!isfinite(sc1))sc1=neg_inf;

          float row_max=simd_max(max(sc0,sc1)),m_old=sM[j],m_new=max(m_old,row_max),corr=0,e0=0,e1=0;
          if(m_new>-3.0e+38f){corr=m_old>-3.0e+38f?exp(m_old-m_new):0;e0=sc0>-3.0e+38f?exp(sc0-m_new):0;e1=sc1>-3.0e+38f?exp(sc1-m_new):0;}
          sp[j*64+kk]=half(e0);sp[j*64+kk+32]=half(e1);
          float row_sum=simd_sum(e0+e1);
          if(lane==0){sS[j]=sS[j]*corr+row_sum;sM[j]=m_new;uint local_j=j&7u;sdiag[(j>>3u)*64+local_j*8+local_j]=corr;}
        }
        threadgroup_barrier(mem_flags::mem_threadgroup);
        for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 mcorr; simdgroup_load(mcorr, sdiag + qgroup * 64u, 8u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_float8x8 scaled; simdgroup_multiply(scaled, mcorr, mo[qp][dt]); mo[qp][dt] = scaled; } }
        for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; for (uint kk8 = 0u; kk8 < 8u; ++kk8) { simdgroup_half8x8 mp; simdgroup_load(mp, sp + qgroup * 512u + kk8 * 8u, 64u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_half8x8 mv; simdgroup_load(mv, v + head_base + (key_start + kk8 * 8u) * 64u + dslice + dt * 8u, 64u); simdgroup_multiply_accumulate(mo[qp][dt], mp, mv, mo[qp][dt]); } } }
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (tid < 64u) { const uint local_j = uint(tid) & 7u; const float denom = sS[tid]; sdiag[(uint(tid) >> 3u) * 64u + local_j * 8u + local_j] = denom > 0.0f ? 1.0f / denom : 0.0f; } threadgroup_barrier(mem_flags::mem_threadgroup);
    for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; simdgroup_float8x8 minv; simdgroup_load(minv, sdiag + qgroup * 64u, 8u); for (uint dt = 0u; dt < 2u; ++dt) { simdgroup_float8x8 scaled; simdgroup_multiply(scaled, minv, mo[qp][dt]); mo[qp][dt] = scaled; } }
    if (q0 + 64u <= p.seq_len) { for (uint qp = 0u; qp < 4u; ++qp) { const uint qgroup = qgroup_base + qp * 2u; const uint output_base = (b * p.seq_len + q0 + qgroup * 8u) * hidden + h * 64u + dslice; for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], output + output_base + dt * 8u, hidden); } return; }
    for (uint qp = 0u; qp < 4u; ++qp) for (uint dt = 0u; dt < 2u; ++dt) simdgroup_store(mo[qp][dt], so + (uint(sgitg) + qp * 8u) * 128u + dt * 8u, 16u); threadgroup_barrier(mem_flags::mem_threadgroup); const uint valid_rows = p.seq_len - q0; for (uint i = uint(tid); i < valid_rows * 64u; i += 256u) { const uint qr = i >> 6u; const uint d = i & 63u; const uint owner = (qr >> 3u) * 4u + (d >> 4u); const uint local_r = qr & 7u; const uint local_d = d & 15u; output[(b * p.seq_len + q0 + qr) * hidden + h * 64u + d] = so[owner * 128u + local_r * 16u + local_d]; }
}

kernel void vision_pack_half(device const float*q[[buffer(0)]],device const float*k[[buffer(1)]],device const float*v[[buffer(2)]],device half*out[[buffer(3)]],constant termite_metal_sdpa_f32_params&p[[buffer(4)]],uint i[[thread_position_in_grid]]){
 uint count=p.batch*p.num_heads*p.reserved1*64;if(i>=count)return;uint d=i%64,s=(i/64)%p.reserved1,h=(i/(64*p.reserved1))%p.num_heads,b=i/(64*p.reserved1*p.num_heads);uint offset=((b*p.seq_len+s)*p.num_heads+h)*64+d;
 out[i]=s<p.seq_len?half(q[offset]*0.125f):half(0);out[count+i]=s<p.seq_len?half(k[offset]):half(0);out[2*count+i]=s<p.seq_len?half(v[offset]):half(0);
}
