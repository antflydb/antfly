from pathlib import Path
import gzip,hashlib,json
p=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max');d=dict(scope='Byte-exact raw logs and historical/candidate timing reports. Restore original names with gzip -dk. Current shipping measurements, summaries and identity manifests remain directly readable.',files=[]);sha=lambda raw:hashlib.sha256(raw).hexdigest()
for x in json.loads((p/'compressed_profile_logs.json').read_text())['files']:d['files'].append(x)
files=list(p.rglob('*.txt'))
for f in p.glob('*.json'):
 if f.name.startswith('shipping_') or 'manifest'in f.name or 'summary'in f.name or 'selection'in f.name or f.name in ['output_validation.json','compressed_profile_logs.json','compressed_evidence.json']:continue
 files.append(f)
for f in files:
 raw=f.read_bytes();target=f.with_name(f.name+'.gz');data=gzip.compress(raw,mtime=0);target.write_bytes(data);d['files'].append(dict(original_path=str(f.relative_to(p)),archive_path=str(target.relative_to(p)),sha256=sha(raw),gzip_sha256=sha(data)));f.unlink()
(p/'compressed_evidence.json').write_text(json.dumps(d,indent=2)+'\n');print('Archived',len(d['files']),'raw evidence files')
