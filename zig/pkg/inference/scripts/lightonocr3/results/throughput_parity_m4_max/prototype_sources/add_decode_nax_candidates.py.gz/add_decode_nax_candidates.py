from pathlib import Path
import json
h=Path('.venv-lighton-vllm-metal');p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_metal_pair.py');s=p.read_text().replace('"decodef32mma64",','"decodef32mma64",\n            "decodenax16",\n            "decodenax32",\n            "decodenax64",\n            "decodebigmpp",\n            "decodenax32sg2",\n            "decodenax64sg4",');p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/metal_pair_benchmark.m');s=p.read_text().replace('pair_variant>=64&&pair_variant<=72','pair_variant>=64&&pair_variant<=78');a=s.index('static int ocr_pair_encode_candidate(');shader=(h/'decode_nax.metal').read_text();s=s[:a]+'static NSString *pair_decode_nax_source(void){return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n'for x in shader.splitlines())+';}\n'+s[a:];a=s.index('\n',s.index('static int ocr_pair_encode_candidate(OCRPairCase *c) {'))+1;s=s[:a]+'''    if(pair_variant==76){size_t saved=pair_variant;pair_variant=52;int rc=ocr_pair_encode_candidate(c);pair_variant=saved;return rc;}
    if(pair_variant>=73&&pair_variant<=78){
        static id<MTLComputePipelineState>pipelines[5];termite_metal_decode_runtime*r=pair_runtime;
        if(!pipelines[0]){MTLCompileOptions*o=[MTLCompileOptions new];o.languageVersion=MTLLanguageVersion4_0;o.mathMode=MTLMathModeSafe;NSError*err=nil;
          id<MTLLibrary>lib=[r->device newLibraryWithSource:pair_decode_nax_source() options:o error:&err];if(!lib){fprintf(stderr,"decode NAX: %s\\n",err.localizedDescription.UTF8String);return -1;}
          const size_t ns[5]={16,32,64,32,64},sgs[5]={1,1,1,2,4};for(size_t i=0;i<5;i++)pipelines[i]=termite_metal_make_pipeline(r->device,lib,[NSString stringWithFormat:@"pair_decode_nax16_%zu_%zu",ns[i],sgs[i]]);
        }
        size_t index=pair_variant<=75?pair_variant-73:pair_variant-74,N=index==0?16:index==1||index==3?32:64,SG=index<3?1:index==3?2:4;id<MTLComputePipelineState>pipe=pipelines[index];
        if(!pipe||pipe.maxTotalThreadsPerThreadgroup<SG*32)return -1;
        termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
        id<MTLComputeCommandEncoder>e=termite_metal_tracked_compute_command_encoder_for(r->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);if(!e)return -1;
        termite_metal_linear_params p={(uint32_t)c->rows,(uint32_t)c->in_dim,(uint32_t)c->out_dim,0};[e setComputePipelineState:pipe];[e setBuffer:c->input offset:0 atIndex:0];[e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:2];[e setBuffer:c->output offset:0 atIndex:3];[e setBytes:&p length:sizeof(p) atIndex:4];[e dispatchThreadgroups:MTLSizeMake((c->out_dim+N-1)/N,1,1) threadsPerThreadgroup:MTLSizeMake(SG*32,1,1)];[e endEncoding];return 0;
    }
'''+s[a:];p.write_text(s)
s=(h/'run_observed_decode_candidates.py').read_text().replace("['decodevec16x2','decodevec32x4','decodempp16','decodempp32','decodegemv1','decodetg']","['decodenax16','decodenax32','decodenax64','decodebigmpp','decodenax32sg2','decodenax64sg4']").replace("variant=='decodevec16x2'","variant=='decodenax16'").replace('metal_pair_observed_decode','metal_pair_decode_nax');(h/'run_decode_nax_candidates.py').write_text(s)
