import subprocess,sys
from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3';h=r/'.venv-lighton-vllm-metal';out=p/'results/throughput_parity_m4_max'
for variant in ['decodechunk4s16t2','decodechunk4s16t4','decodechunk4s32t4','decodechunk4s32t8','decodechunk2s16t4','decodechunk2s32t8']:
 for flush,label in [(0,'resident'),(64,'cold64')]:
  name=variant+'_'+label;print('START',name,flush=True)
  cmd=[sys.executable,str(p/'benchmark_metal_pair.py'),'--native-library',str(h/'metal_pair_decode_chunk.dylib'),'--timing-library',str(h/'metal_timing_qualified.dylib'),'--suite','decode-missing','--variant',variant,'--only-candidates','--compare-production','--trials','30','--cache-flush-mib',str(flush),'--output',str(out/(name+'.json'))]
  if variant=='decodechunk4s16t2' and flush==0:cmd+=['--compile-native-library']
  with open('/private/tmp/ocr-parity-'+name+'.txt','w')as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
  print('DONE',name,flush=True)
