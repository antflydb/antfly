from pathlib import Path
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_metal_pair.py');s=p.read_text().replace('"previousprefill",','"previousprefill",\n            "decodevec16x2",\n            "decodevec32x4",\n            "decodempp16",\n            "decodempp32",\n            "decodegemv1",\n            "decodetg",');s=s.replace('            "decode-shapes",','            "decode-shapes",\n            "decode-missing",',1);a=s.index('    if args.suite == "prefill-gates":');s=s[:a]+'''    if args.suite == "decode-missing":
        missing=[(1024,16),(2048,1024),(1024,2048),(1024,512),(1024,4096),
                 (2560,32),(4096,2560),(2560,4096),(2560,1024)]
        cases=[(0,rows,k,n) for rows in range(1,9) for k,n in missing]
'''+s[a:];a=s.index('            return {',s.index('        def applies(case):'));s=s[:a]+'''            if args.variant.startswith("decode"):
                missing=(k,n) in [(1024,16),(2048,1024),(1024,2048),(1024,512),(1024,4096),(2560,32),(4096,2560),(2560,4096),(2560,1024)]
                if args.variant=="decodegemv1":return kind==0 and rows==1 and n in (16,32)
                if args.variant=="decodetg":return kind==0 and 1<=rows<=8 and n in (16,32)
                if args.variant.startswith("decodevec"):return kind==0 and 2<=rows<=8 and missing
                return kind==0 and 1<=rows<=8 and missing
'''+s[a:];p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/metal_pair_benchmark.m');s=p.read_text();a=s.index('    if(pair_variant>=56',s.index('size_t ocr_pair_candidate_applies'));s=s[:a]+'''    if(pair_variant>=64&&pair_variant<=69){
        const bool tiny=(c->in_dim==1024&&c->out_dim==16)||(c->in_dim==2560&&c->out_dim==32);
        const bool missing=tiny||(c->in_dim==2048&&c->out_dim==1024)||(c->in_dim==1024&&(c->out_dim==2048||c->out_dim==512||c->out_dim==4096))||(c->in_dim==4096&&c->out_dim==2560)||(c->in_dim==2560&&(c->out_dim==4096||c->out_dim==1024));
        return c->kind==0&&missing&&c->rows>=((pair_variant==64||pair_variant==65)?2:1)&&c->rows<=8&&
            (pair_variant<68||(tiny&&(pair_variant!=68||c->rows==1)));
    }
'''+s[a:];a=s.index('\n',s.index('static int ocr_pair_encode_candidate(OCRPairCase *c) {'))+1;s=s[:a]+'''    if(pair_variant>=64&&pair_variant<=68){
        const size_t saved=pair_variant;pair_variant=saved==64?41:saved==65?44:saved==66?55:saved==67?54:6;
        int rc=ocr_pair_encode_candidate(c);pair_variant=saved;return rc;
    }
    if(pair_variant==69){
        termite_metal_decode_runtime*r=pair_runtime;size_t S=c->out_dim==16?8:16,N=c->out_dim==16?16:32;
        id<MTLComputePipelineState>pipe=N==16?r->lightonocr3_prefill_gate8_16:r->lightonocr3_prefill_gate16_32;
        if(!pipe||pipe.maxTotalThreadsPerThreadgroup<S*32)return -1;
        termite_metal_decode_runtime_close_planned_compute_encoder_for_transition(r);
        id<MTLComputeCommandEncoder>e=termite_metal_tracked_compute_command_encoder_for(r->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);if(!e)return -1;
        termite_metal_linear_params p={(uint32_t)c->rows,(uint32_t)c->in_dim,(uint32_t)c->out_dim,0};
        [e setComputePipelineState:pipe];[e setBuffer:c->input offset:0 atIndex:0];[e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];[e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:2];[e setBuffer:c->output offset:0 atIndex:3];[e setBytes:&p length:sizeof(p) atIndex:4];[e setThreadgroupMemoryLength:S*8*N*4 atIndex:0];[e dispatchThreadgroups:MTLSizeMake(1,1,1) threadsPerThreadgroup:MTLSizeMake(S*32,1,1)];[e endEncoding];return 0;
    }
'''+s[a:];p.write_text(s)
