from pathlib import Path
import re,json
h=Path('.venv-lighton-vllm-metal');src=(h/'vision_q64k64.metal').read_text();src=src.replace('flash_q64k64(','flash_packed_q64k64(');src=src.replace('device const float *q','device const half *q').replace('device const float *k','device const half *k').replace('device const float *v','device const half *v')
a=src.index('struct Scratch');b=src.index('\n',a);src=src[:a]+'''struct Scratch{float ss[4096];half sp[4096];float sM[64];float sS[64];float sdiag[512];};threadgroup Scratch scratch;threadgroup half*sp=scratch.sp;threadgroup float*ss=scratch.ss,*sM=scratch.sM,*sS=scratch.sS,*sdiag=scratch.sdiag,*so=(threadgroup float*)&scratch;
    const uint head_base=(b*p.num_heads+h)*p.reserved1*64u;'''+src[b:]
a=src.index('    for (uint i = uint(tid); i < 4096u;');b=src.index('\n',a);src=src[:a]+src[b+1:]
a=src.index('    simdgroup_half8x8 cached_q');b=src.index('    simdgroup_float8x8 mo',a);src=src[:a]+src[b:]
lines=src.splitlines();out=[];skip=False
for line in lines:
 if skip:
  assert 'threadgroup_barrier' in line;skip=False;continue
 if 'skv[i] = ki < p.seq_len ? half(' in line:skip=True;continue
 if 'for(uint d=0;d<8;d++){simdgroup_half8x8 mk;' in line:
  line='''            for(uint d=0;d<8;d++){simdgroup_half8x8 mq,mk;simdgroup_load(mq,q+head_base+(q0+qgroup*8)*64+d*8,64u);simdgroup_load(mk,k+head_base+(key_start+(subgroup+kp*4)*8)*64+d*8,64u,0,true);simdgroup_multiply_accumulate(ms,mq,mk,ms);}'''
 line=line.replace('          simdgroup_barrier(mem_flags::mem_threadgroup);','')
 line=line.replace('sp[j*128+kk]','sp[j*64+kk]').replace('sp[j*128+kk+32]','sp[j*64+kk+32]')
 line=line.replace('sp + qgroup * 1024u + kk8 * 8u, 128u','sp + qgroup * 512u + kk8 * 8u, 64u')
 line=line.replace('simdgroup_load(mv, skv + kk8 * 512u + dslice + dt * 8u, 64u)','simdgroup_load(mv, v + head_base + (key_start + kk8 * 8u) * 64u + dslice + dt * 8u, 64u)')
 out.append(line)
src='\n'.join(out)+'\n';needle='        threadgroup_barrier(mem_flags::mem_threadgroup);\n    }\n    if (tid < 64u)';assert needle in src;src=src.replace(needle,'    }\n    threadgroup_barrier(mem_flags::mem_threadgroup);\n    if (tid < 64u)');assert 'skv' not in src
src+='''
kernel void vision_pack_half(device const float*q[[buffer(0)]],device const float*k[[buffer(1)]],device const float*v[[buffer(2)]],device half*out[[buffer(3)]],constant termite_metal_sdpa_f32_params&p[[buffer(4)]],uint i[[thread_position_in_grid]]){
 uint count=p.batch*p.num_heads*p.reserved1*64;if(i>=count)return;uint d=i%64,s=(i/64)%p.reserved1,h=(i/(64*p.reserved1))%p.num_heads,b=i/(64*p.reserved1*p.num_heads);uint offset=((b*p.seq_len+s)*p.num_heads+h)*64+d;
 out[i]=s<p.seq_len?half(q[offset]*0.125f):half(0);out[count+i]=s<p.seq_len?half(k[offset]):half(0);out[2*count+i]=s<p.seq_len?half(v[offset]):half(0);
}
'''
(h/'vision_packed_q64k64.metal').write_text(src)
c=(h/'vision_attention_benchmark.m').read_text();a=c.index('static NSString *vision_candidate_source');b=c.index('void *vision_create',a);lit='static NSString *vision_candidate_source(void) {return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n' for x in src.splitlines())+';}\n';c=c[:a]+lit+c[b:];c=c.replace('static id<MTLComputePipelineState> vp;', 'static id<MTLComputePipelineState> vp,packp;');c=c.replace('id<MTLBuffer> q,k,v,out;','id<MTLBuffer> q,k,v,out,packed;');c=c.replace(' vp=termite_metal_make_pipeline', ' packp=termite_metal_make_pipeline(vr->device,lib,@"vision_pack_half");if(!packp)return NULL;\n vp=termite_metal_make_pipeline');c=c.replace('flash_q64"','flash_packed_q64k64"');needle=' if(!c->q||!c->k||!c->v||!c->out)return NULL;';c=c.replace(needle,' c->packed=[vr->device newBufferWithLength:3*((seq+63)/64*64)*heads*64*2 options:MTLResourceStorageModePrivate];\n if(!c->q||!c->k||!c->v||!c->out||!c->packed)return NULL;');c=c.replace('(uint32_t)c->heads,64,0,0,1,0};','(uint32_t)c->heads,64,0,0,1,(uint32_t)((c->seq+63)/64*64)};');needle=' [e setComputePipelineState:vp];';i=c.index(needle);c=c[:i]+''' size_t count=p.batch*p.num_heads*p.reserved1*64;
 [e setComputePipelineState:packp];[e setBuffer:c->q offset:0 atIndex:0];[e setBuffer:c->k offset:0 atIndex:1];[e setBuffer:c->v offset:0 atIndex:2];[e setBuffer:c->packed offset:0 atIndex:3];[e setBytes:&p length:sizeof(p) atIndex:4];
 [e dispatchThreads:MTLSizeMake(count,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];[e memoryBarrierWithScope:MTLBarrierScopeBuffers];
'''+c[i:];c=c.replace('[e setBuffer:c->q offset:0 atIndex:0];[e setBuffer:c->k offset:0 atIndex:1];[e setBuffer:c->v offset:0 atIndex:2];[e setBuffer:vr->optional_dummy_buffer','[e setBuffer:c->packed offset:0 atIndex:0];[e setBuffer:c->packed offset:count*2 atIndex:1];[e setBuffer:c->packed offset:count*4 atIndex:2];[e setBuffer:vr->optional_dummy_buffer');(h/'vision_attention_packed_benchmark.m').write_text(c)
