#include <metal_tensor>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace mpp::tensor_ops;
kernel void termite_sdpa_f32_vision_hd64_flash_packed_register(device half*q[[buffer(0)]],device half*k[[buffer(1)]],device half*v[[buffer(2)]],device const float*bias[[buffer(3)]],device const float*mask[[buffer(4)]],device float*output[[buffer(5)]],constant termite_metal_sdpa_f32_params&p[[buffer(6)]],uint tid[[thread_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]],uint group[[threadgroup_position_in_grid]]){
 const uint tiles=(p.seq_len+63)/64,qtile=group%tiles,h=(group/tiles)%p.num_heads,b=group/(tiles*p.num_heads),q0=qtile*64+sg*16,base=(b*p.num_heads+h)*p.reserved1*64;
 threadgroup float rowmax[64],rowsum[64],correction[64];
 if(tid<64){rowmax[tid]=-INFINITY;rowsum[tid]=0;}threadgroup_barrier(mem_flags::mem_threadgroup);
 tensor<device half,dextents<int,2>,tensor_inline> Q(q+base+q0*64,dextents<int,2>(64,16),array<int,2>{1,64});
 tensor<device half,dextents<int,2>,tensor_inline> K(k+base,dextents<int,2>(64,64),array<int,2>{1,64});
 tensor<device half,dextents<int,2>,tensor_inline> V(v+base,dextents<int,2>(64,64),array<int,2>{1,64});
 tensor<threadgroup float,dextents<int,1>,tensor_inline> R(rowmax+sg*16,dextents<int,1>(16),array<int,1>{1});
 tensor<threadgroup float,dextents<int,1>,tensor_inline> RS(rowsum+sg*16,dextents<int,1>(16),array<int,1>{1});
 constexpr auto qkd=matmul2d_descriptor(16,64,64,false,true,false);matmul2d<qkd,execution_simdgroups<1>> qkop;
 constexpr auto pvd=matmul2d_descriptor(16,64,64,false,false,false,matmul2d_descriptor::mode::multiply_accumulate);matmul2d<pvd,execution_simdgroups<1>> pvop;
 auto dot=qkop.get_destination_cooperative_tensor<decltype(Q),decltype(K),float>();
 auto halfdot=qkop.get_destination_cooperative_tensor<decltype(Q),decltype(K),half>();
 auto rows=qkop.get_row_reduction_destination_cooperative_tensor<decltype(Q),decltype(K),float>();
 auto probs=pvop.get_left_input_cooperative_tensor<half,half,float>();
 auto out=pvop.get_destination_cooperative_tensor<decltype(probs),decltype(V),float>();for(ushort i=0;i<out.get_capacity();i++)out[i]=0;
 for(uint start=0;start<p.seq_len;start+=64){
  tensor<device half,dextents<int,2>,tensor_inline> kb(k+base+start*64,dextents<int,2>(64,64),array<int,2>{1,64});qkop.run(Q,kb,dot);
  for(ushort i=0;i<dot.get_capacity();i++){auto c=dot.get_multidimensional_index(i);if(start+c[0]>=p.seq_len||q0+c[1]>=p.seq_len)dot[i]=-INFINITY;}
  reduce_rows(dot,rows,reduction_operation::max,-INFINITY);
  for(ushort i=0;i<rows.get_capacity();i++){auto c=rows.get_multidimensional_index(i);uint row=sg*16+c[0];if(c[0]<16){float prev=rowmax[row],nm=max(prev,rows[i]);correction[row]=isfinite(prev)&&isfinite(nm)?exp(prev-nm):0;rows[i]=nm;}}
  rows.store(R);simdgroup_barrier(mem_flags::mem_threadgroup);
  for(ushort i=0;i<dot.get_capacity();i++){auto c=dot.get_multidimensional_index(i);dot[i]=isfinite(dot[i])?exp(dot[i]-rowmax[sg*16+c[1]]):0;}
  reduce_rows(dot,rows);
  for(ushort i=0;i<rows.get_capacity();i++){auto c=rows.get_multidimensional_index(i);uint row=sg*16+c[0];if(c[0]<16)rows[i]+=rowsum[row]*correction[row];}
  rows.store(RS);simdgroup_barrier(mem_flags::mem_threadgroup);
  for(ushort i=0;i<halfdot.get_capacity();i++)halfdot[i]=half(dot[i]);
  probs=pvop.get_left_input_cooperative_tensor<half,half,float>(halfdot);
  for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);out[i]*=correction[sg*16+c[1]];}
  tensor<device half,dextents<int,2>,tensor_inline> vb(v+base+start*64,dextents<int,2>(64,64),array<int,2>{1,64});pvop.run(probs,vb,out);
 }
 for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);uint row=c[1];if(q0+row<p.seq_len)output[((b*p.seq_len+q0+row)*p.num_heads+h)*64+c[0]]=rowsum[sg*16+row]>0?out[i]/rowsum[sg*16+row]:0;}
}
