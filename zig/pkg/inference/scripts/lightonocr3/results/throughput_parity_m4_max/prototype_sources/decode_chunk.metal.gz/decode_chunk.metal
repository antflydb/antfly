#include <metal_stdlib>
using namespace metal;
struct PairChunkParams{uint rows,in_dim,out_dim,pad;};
template<uint B,uint SN,uint TM> inline void pair_chunk_body(device const float*x,device const ushort*w,device const float*b,device float*y,constant PairChunkParams&p,uint2 group,uint sg,uint lane){
 const uint start=group.y*B,col=((group.x*4+sg)*(32/SN)+lane/SN)*TM;
 float acc[B][TM];
 #pragma unroll
 for(uint r=0;r<B;r++){
  #pragma unroll
  for(uint t=0;t<TM;t++)acc[r][t]=0.0f;
 }
 for(uint k=(lane%SN)*4;k<p.in_dim;k+=SN*4){
  float4 a[B];
  #pragma unroll
  for(uint r=0;r<B;r++)a[r]=*((device const float4*)(x+min(start+r,p.rows-1)*p.in_dim+k));
  #pragma unroll
  for(uint t=0;t<TM;t++){
   float4 v=as_type<float4>(uint4(*((device const ushort4*)(w+(col+t)*p.in_dim+k)))<<16);
   #pragma unroll
   for(uint r=0;r<B;r++)acc[r][t]+=dot(a[r],v);
  }
 }
 #pragma unroll
 for(uint r=0;r<B;r++){
  #pragma unroll
  for(uint t=0;t<TM;t++){
   float v=acc[r][t];
   #pragma unroll
   for(uint d=SN/2;d>0;d/=2)v+=simd_shuffle_xor(v,d);
   if(lane%SN==0&&start+r<p.rows)y[(start+r)*p.out_dim+col+t]=v+b[col+t];
  }
 }
}
#define CH(B,SN,TM) kernel void pair_chunk_##B##_##SN##_##TM(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant PairChunkParams&p[[buffer(4)]],uint2 group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]]){pair_chunk_body<B,SN,TM>(x,w,b,y,p,group,sg,lane);}
#define CB(B) CH(B,16,2) CH(B,16,4) CH(B,32,4) CH(B,32,8)
CB(1) CB(2) CB(3) CB(4)
#undef CB
#undef CH
