#include "../zig/pkg/inference/src/backends/metal_kernels.m"
static termite_metal_decode_runtime *vr;
static id<MTLComputePipelineState> vp,packp;
@interface VisionCase:NSObject { @public size_t seq,heads; id<MTLBuffer> q,k,v,out,packed; } @end
@implementation VisionCase @end
void *vision_create(size_t seq,size_t heads,const float*q,const float*k,const float*v) {
 @autoreleasepool {
 if(!vr){vr=termite_metal_decode_runtime_create();if(!vr)return NULL;
 termite_metal_decode_runtime_set_lightonocr3_projections(vr,1);
 if(!vr->lightonocr3_vision_mpp_pipeline||!vr->lightonocr3_vision_pack_pipeline)return NULL;
 }
 VisionCase*c=[VisionCase new];c->seq=seq;c->heads=heads;size_t bytes=seq*heads*64*4;
 c->q=[vr->device newBufferWithBytes:q length:bytes options:MTLResourceStorageModeShared];
 c->k=[vr->device newBufferWithBytes:k length:bytes options:MTLResourceStorageModeShared];
 c->v=[vr->device newBufferWithBytes:v length:bytes options:MTLResourceStorageModeShared];
 c->out=[vr->device newBufferWithLength:bytes options:MTLResourceStorageModeShared];

 if(!c->q||!c->k||!c->v||!c->out)return NULL;return (__bridge_retained void*)c;
 }}
uint64_t vision_run(void*handle,size_t candidate) {
 @autoreleasepool {VisionCase*c=(__bridge VisionCase*)handle;if(termite_metal_decode_runtime_begin_frame(vr))return 0;
 if(candidate)unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_MPP");else setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_MPP","1",1);
 uint64_t before=vr->lightonocr3_vision_mpp_dispatches;
 int rc=termite_metal_decode_runtime_sdpa_f32_device(vr,(__bridge void*)c->q,0,(__bridge void*)c->k,0,(__bridge void*)c->v,0,NULL,0,NULL,0,1,c->seq,c->heads,64,0,0,1,1,0,(__bridge void*)c->out,0);
 if(candidate&&vr->lightonocr3_vision_mpp_dispatches!=before+1)return 0;
 if(!candidate&&vr->lightonocr3_vision_mpp_dispatches!=before)return 0;
 unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_MPP");
 if(rc||termite_metal_decode_runtime_submit_frame(vr)||termite_metal_decode_runtime_wait_frame(vr))return 0;return vr->last_frame_gpu_nanos;
 }}
const float*vision_output(void*h){return ((__bridge VisionCase*)h)->out.contents;}
void vision_release(void*h){id obj=CFBridgingRelease(h);(void)obj;}
void vision_shutdown(void){termite_metal_decode_runtime_destroy(vr);vr=NULL;vp=nil;}
