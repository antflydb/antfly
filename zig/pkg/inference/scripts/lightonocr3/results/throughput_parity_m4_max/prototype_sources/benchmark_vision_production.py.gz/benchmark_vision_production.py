import ctypes,json,hashlib,statistics,sys,subprocess
from pathlib import Path
r=Path.cwd();h=r/'.venv-lighton-vllm-metal';out=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max';lib=h/'vision_attention_production_benchmark.dylib';n=ctypes.CDLL(str(lib));n.vision_create.argtypes=[ctypes.c_size_t,ctypes.c_size_t]+[ctypes.c_void_p]*3;n.vision_create.restype=ctypes.c_void_p;n.vision_run.argtypes=[ctypes.c_void_p,ctypes.c_size_t];n.vision_run.restype=ctypes.c_uint64;n.vision_output.argtypes=[ctypes.c_void_p];n.vision_output.restype=ctypes.POINTER(ctypes.c_float);n.vision_release.argtypes=[ctypes.c_void_p]
t=ctypes.CDLL(str(h/'metal_timing_qualified.dylib'));t.ocr_timing_end.argtypes=[ctypes.POINTER(ctypes.c_uint64)];t.ocr_timing_end.restype=ctypes.c_uint64;assert not t.ocr_timing_init() and not t.ocr_timing_self_test()
import mlx.core as mx
import numpy as np
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
report=dict(scope='Production-dispatch vision HD64 attention including Q/K/V packing, batch one, 12 heads; native old/new half Q/K/V/probability tiles and F32 accumulation/output, MLX BF16 input/output. Native inputs hold exactly the same BF16 values. Six rotated/reversed participant orders; numerical checks include full outputs and CPU samples.',device=mx.device_info(),runtime_source_sha256=sha(r/'zig/pkg/inference/src/backends/metal_kernels.m'),bridge_sha256=sha(h/'vision_attention_production_benchmark.m'),library_sha256=sha(lib),runner_sha256=sha(Path(__file__)),runtime_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),results=[])
for seq in [257,578,1672,2160,2592,4095,4096]:
 shape=(1,seq,12,64);rng=np.random.default_rng(2468+seq);xs=[]
 for _ in range(3):
  a=(rng.standard_normal(shape)*.2).astype(np.float32);u=a.view(np.uint32);a=(((u+np.uint32(0x7fff)+((u>>16)&1))>>16)<<16).view(np.float32);xs.append(a)
 q,k,v=xs;handle=n.vision_create(seq,12,*[x.ctypes.data for x in xs]);assert handle,'Cannot create vision case'
 mq,mk,mv=[mx.array(x).astype(mx.bfloat16).transpose(0,2,1,3) for x in xs];mx.eval(mq,mk,mv)
 def mlxrun():
  y=mx.fast.scaled_dot_product_attention(mq,mk,mv,scale=.125);mx.eval(y);mx.synchronize();return y
 for _ in range(5):assert n.vision_run(handle,0) and n.vision_run(handle,1);mlxrun()
 samples={x:[] for x in ['old','new','mlx']}
 for trial in range(30):
  who=['old','new','mlx'];i=trial%3;who=who[i:]+who[:i]
  if (trial//3)%2:who.reverse()
  for name in who:
   if name=='mlx':t.ocr_timing_begin();my=mlxrun();count=ctypes.c_uint64();ns=t.ocr_timing_end(ctypes.byref(count));assert count.value
   else:ns=n.vision_run(handle,int(name=='new'))
   assert ns;samples[name].append(ns/1000)
 assert n.vision_run(handle,0);old=np.ctypeslib.as_array(n.vision_output(handle),shape=(q.size,)).copy().reshape(shape)
 assert n.vision_run(handle,1);new=np.ctypeslib.as_array(n.vision_output(handle),shape=(q.size,)).copy().reshape(shape)
 ref=np.array(my.transpose(0,2,1,3).astype(mx.float32));assert np.all(np.isfinite(new));diff=float(np.max(np.abs(new-old)));np.testing.assert_allclose(new,old,atol=2e-5,rtol=1e-4);np.testing.assert_allclose(new,ref,atol=2e-4,rtol=.005)
 cpu=0
 for qi,head,col in [(0,0,0),(seq-1,11,63),(seq//2,5,31),(seq//3,7,17)]:
  scores=k[0,:,head].astype(np.float64)@q[0,qi,head].astype(np.float64)*.125;p=np.exp(scores-scores.max());p/=p.sum();expected=p@v[0,:,head,col].astype(np.float64);cpu=max(cpu,abs(expected-float(new[0,qi,head,col])))
 assert cpu<2e-4,cpu
 med={key:statistics.median(val) for key,val in samples.items()};item=dict(seq=seq,heads=12,batch=1,samples_us=samples,median_us=med,mean_us={k:statistics.mean(v) for k,v in samples.items()},median_new_over_old=med['new']/med['old'],median_new_over_mlx=med['new']/med['mlx'],full_output_max_abs_old_new=diff,cpu_sample_max_abs=cpu,mlx_max_abs=float(np.max(np.abs(new-ref))))
 report['results'].append(item);print({k:v for k,v in item.items() if k!='samples_us'},flush=True);(out/'vision_production.json').write_text(json.dumps(report,indent=2)+'\n');n.vision_release(handle)
n.vision_shutdown()
