from pathlib import Path
import subprocess,json,hashlib
p=Path('zig/pkg/inference/src/server/reader_execution_pool.zig');s=p.read_text();s+='''
/// One serialized workspace peak held until the shared runtime is destroyed.
/// The caller serializes growth; each successful increment retains its exact
/// admission lease, so cancellation and later page retirement cannot uncharge
/// a workspace still owned by peers. An epoch accepts at most 64 page joins.
pub fn SharedPeak(comptime Lease: type) type {
    return struct {
        bytes: usize = 0,
        count: usize = 0,
        leases: [64]Lease = undefined,

        pub fn grow(self: *@This(), target: usize, context: anytype, comptime acquire: anytype) !void {
            if (target <= self.bytes) return;
            if (self.count == self.leases.len) return error.ResourceLimitExceeded;
            const lease = try acquire(context, target - self.bytes);
            self.leases[self.count] = lease;
            self.count += 1;
            self.bytes = target;
        }

        pub fn deinit(self: *@This()) void {
            for (self.leases[0..self.count]) |*lease| lease.release();
            self.bytes = 0;
            self.count = 0;
        }
    };
}

test "LightOnOCR3 shared vision peak preserves caps and reservations across page retirement" {
    const memory = @import("../runtime/tier/memory.zig");
    const Factory = struct {
        fn acquire(controller: *memory.AdmissionController, bytes: usize) !memory.AdmissionLease {
            return controller.tryAcquire(.gpu, .{ .backend_limit_bytes = 100, .scratch_limit_bytes = 100 }, .{ .backend_scratch_bytes = bytes }, false);
        }
    };
    var controller = memory.AdmissionController{};
    defer controller.deinit();
    var peak = SharedPeak(memory.AdmissionLease){};
    defer peak.deinit();
    try peak.grow(80, &controller, Factory.acquire);
    var first = try Factory.acquire(&controller, 10);
    defer first.release();
    try peak.grow(80, &controller, Factory.acquire);
    var second = try Factory.acquire(&controller, 10);
    defer second.release();
    try std.testing.expectEqual(@as(usize, 100), controller.admitted.backend_scratch_bytes);
    try std.testing.expectError(error.ResourceTemporarilyUnavailable, peak.grow(90, &controller, Factory.acquire));
    try std.testing.expectEqual(@as(usize, 80), peak.bytes);
    try std.testing.expectEqual(@as(usize, 1), peak.count);
    first.release();
    try peak.grow(90, &controller, Factory.acquire);
    second.release();
    try std.testing.expectEqual(@as(usize, 90), controller.admitted.backend_scratch_bytes);
    peak.deinit();
    try std.testing.expectEqual(@as(usize, 0), controller.admitted.backend_scratch_bytes);
    try std.testing.expectError(error.ResourceLimitExceeded, peak.grow(101, &controller, Factory.acquire));
    try std.testing.expectEqual(@as(usize, 0), peak.count);
    for (1..65) |target| try peak.grow(target, &controller, Factory.acquire);
    try std.testing.expectError(error.ResourceLimitExceeded, peak.grow(65, &controller, Factory.acquire));
}
''';p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text();s=s.replace('        prefill_broker: executor_microbatch.Broker,','        prefill_broker: executor_microbatch.Broker,\n        vision_peak: reader_execution_pool.SharedPeak(model_manager_mod.GenerationAdmissionLease) = .{},',1)
# The server already imports the pool under a name checked below.
if 'const reader_execution_pool =' not in s:
 s=s.replace('const model_manager_mod = model_manager;', 'const reader_execution_pool = @import("reader_execution_pool.zig");\nconst model_manager_mod = model_manager;',1)
needle='''        fn register(ctx: *LightOnStreamContext, control: InferenceExecutionControl) usize {''';assert needle in s
s=s.replace(needle,'''        fn acquireVisionPeak(factory: *Factory, bytes: usize) !model_manager_mod.GenerationAdmissionLease {
            return factory.node.model_manager.acquireGenerationResources(&.{.{ .session = factory.model.session, .resources = .{ .backend_class = .gpu, .limits = factory.limits, .amounts = .{ .backend_scratch_bytes = bytes } } }});
        }
        fn admitPage(ctx: *LightOnStreamContext, factory: *Factory, peak: ?usize, amounts: runtime.tier.memory.AdmissionAmounts) !model_manager_mod.GenerationAdmissionLease {
            if (peak) |bytes| {
                try factory.control.lock(&ctx.step_mutex);
                defer ctx.step_mutex.unlock();
                try ctx.vision_peak.grow(bytes, factory, acquireVisionPeak);
            }
            return factory.node.model_manager.acquireGenerationResources(&.{.{ .session = factory.model.session, .resources = .{ .backend_class = .gpu, .limits = factory.limits, .amounts = amounts } } });
        }
'''+needle,1)
s=s.replace('            ctx.coordinator.deinit();\n            ctx.model.unlockNativeGeneration();','''            ctx.coordinator.deinit();
            if (platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3")) std.debug.print("LIGHTONOCR3 shared_vision_peak_bytes={d} peak_segments={d}\\n", .{ ctx.vision_peak.bytes, ctx.vision_peak.count });
            ctx.vision_peak.deinit();
            ctx.model.unlockNativeGeneration();''',1)
a=s.index('    fn runLightOnContinuousPage(');b=s.index('    fn readLightOnContinuousImages(',a);t=s[a:b]
needle='        const amounts = try memory.finish();';assert needle in t;t=t.replace(needle,'''        // Default vision execution is serialized by step_mutex. Reserve its
        // maximum once for the epoch, while page-local retained state remains
        // additive. Batched vision keeps the conservative per-page peaks.
        const vision_batch_enabled = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_VISION_BATCH");
        const share_vision_peak = !vision_batch_enabled and
            !platform.env.getenvBool("ANTFLY_LIGHTONOCR3_DISABLE_SHARED_VISION_PEAK");
        const amounts = if (share_vision_peak) memory.amounts else try memory.finish();''',1)
needle='self.model_manager.acquireGenerationResources(&.{.{ .session = model.session, .resources = .{ .backend_class = .gpu, .limits = limits, .amounts = amounts } }})';assert needle in t;t=t.replace(needle,'ctx.admitPage(&factory, if (share_vision_peak) memory.vision_backend_peak else null, amounts)',1)
t=t.replace('.qwen_vision_batch = if (platform.env.getenvBool("ANTFLY_LIGHTONOCR3_VISION_BATCH"))', '.qwen_vision_batch = if (vision_batch_enabled)',1)
s=s[:a]+t+s[b:];p.write_text(s)
subprocess.run(['/Users/ajroetker/bin/zig-0.17.0/zig','fmt','zig/pkg/inference/src/server/server.zig','zig/pkg/inference/src/server/reader_execution_pool.zig'],check=True)
paths=json.loads(Path('.venv-lighton-vllm-metal/refill-tail-qualified-source.json').read_text());Path('.venv-lighton-vllm-metal/refill-shared-peak-source.json').write_text(json.dumps({p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
