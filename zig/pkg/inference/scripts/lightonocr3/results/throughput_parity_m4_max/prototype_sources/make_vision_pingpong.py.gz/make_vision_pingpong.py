from pathlib import Path
import re,json
h=Path('.venv-lighton-vllm-metal');s=Path('zig/pkg/inference/src/backends/metal_kernels.m').read_text();a=s.index('           "kernel void termite_sdpa_f32_vision_hd64_flash_q32(');b=s.index('           // Full F32 variant',a);src=''.join(json.loads('"'+x+'"') for x in re.findall(r'"((?:[^"\\]|\\.)*)"',s[a:b]));src=src.replace('flash_q32(','flash_q32_pingpong(')
old='threadgroup half sq[2048]; threadgroup half skv[2048]; threadgroup float ss[1024]; threadgroup half sp[1024]; threadgroup float sM[32]; threadgroup float sS[32]; threadgroup float sdiag[256]; threadgroup float so[2048];'
new='struct Scratch{half sq[2048];half sk[2][2048];half sv[2][2048];float ss[1024];half sp[1024];float sM[32];float sS[32];float sdiag[256];};threadgroup Scratch scratch;threadgroup half*sq=scratch.sq,*sp=scratch.sp;threadgroup float*ss=scratch.ss,*sM=scratch.sM,*sS=scratch.sS,*sdiag=scratch.sdiag,*so=(threadgroup float*)&scratch;';assert old in src;src=src.replace(old,new)
lines=src.splitlines();out=[];skip=False
for line in lines:
 if skip:
  assert 'threadgroup_barrier' in line;skip=False;continue
 if 'for (uint key_start' in line:
  out.append(line);out.append('        const uint ping=(key_start/32u)&1u;threadgroup half*sk=scratch.sk[ping],*sv=scratch.sv[ping];');continue
 if 'skv[i] = ki < p.seq_len ? half(k[' in line:
  line=line.replace('skv[i]','sk[i]');needle=' : half(0.0f); }';assert needle in line;line=line.replace(needle,' : half(0.0f); sv[i]=ki<p.seq_len?half(v[(b*p.seq_len+ki)*hidden+h*64u+d]):half(0.0f); }')
 if 'skv[i] = ki < p.seq_len ? half(v[' in line:skip=True;continue
 line=line.replace('simdgroup_load(mk, skv +','simdgroup_load(mk, sk +').replace('simdgroup_load(mv, skv +','simdgroup_load(mv, sv +')
 out.append(line)
src='\n'.join(out)+'\n';needle='        threadgroup_barrier(mem_flags::mem_threadgroup);\n    }\n    if (tid < 32u)';assert needle in src;src=src.replace(needle,'    }\n    threadgroup_barrier(mem_flags::mem_threadgroup);\n    if (tid < 32u)')
(h/'vision_q32_pingpong.metal').write_text(src)
c=(h/'vision_attention_benchmark.m').read_text();a=c.index('static NSString *vision_candidate_source');b=c.index('void *vision_create',a);literal='static NSString *vision_candidate_source(void) {return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n' for x in src.splitlines())+';}\n';c=c[:a]+literal+c[b:];c=c.replace('flash_q64"','flash_q32_pingpong"').replace('c->heads*((c->seq+63)/64)','c->heads*((c->seq+31)/32)');(h/'vision_attention_pingpong_benchmark.m').write_text(c)
