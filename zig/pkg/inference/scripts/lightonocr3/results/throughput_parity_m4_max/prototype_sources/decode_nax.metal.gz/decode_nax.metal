#include <metal_stdlib>
#include <metal_tensor>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;using namespace mpp::tensor_ops;
struct DecodeNaxParams{uint rows,in_dim,out_dim,pad;};
template<uint M,uint N,uint SG> inline void decode_nax_body(device float*x,device bfloat*w,device float*b,device float*y,constant DecodeNaxParams&p,uint2 group){
 tensor<device float,dextents<int,2>,tensor_inline>a(x,dextents<int,2>(p.in_dim,p.rows),array<int,2>{1,int(p.in_dim)});
 tensor<device bfloat,dextents<int,2>,tensor_inline>wm(w,dextents<int,2>(p.in_dim,p.out_dim),array<int,2>{1,int(p.in_dim)});
 tensor<device float,dextents<int,2>,tensor_inline>dest(y,dextents<int,2>(p.out_dim,p.rows),array<int,2>{1,int(p.out_dim)});
 auto left=a.slice(0,int(group.y)*M);auto right=wm.slice(0,int(group.x)*N);auto output=dest.slice(int(group.x)*N,int(group.y)*M);
 constexpr auto desc=matmul2d_descriptor(M,N,dynamic_length_v<int>,false,true,false);matmul2d<desc,execution_simdgroups<SG>>op;
 auto result=op.template get_destination_cooperative_tensor<decltype(left),decltype(right),float>();op.run(left,right,result);
 for(ushort i=0;i<result.get_capacity();i++){auto c=result.get_multidimensional_index(i);int col=int(group.x)*N+c[0],row=int(group.y)*M+c[1];if(c[0]>=0&&c[0]<int(N)&&c[1]>=0&&c[1]<int(M)&&col<int(p.out_dim)&&row<int(p.rows))result[i]+=b[col];}
 result.store(output);
}
#define DN(N,SG) kernel void pair_decode_nax16_##N##_##SG(device float*x[[buffer(0)]],device bfloat*w[[buffer(1)]],device float*b[[buffer(2)]],device float*y[[buffer(3)]],constant DecodeNaxParams&p[[buffer(4)]],uint2 group[[threadgroup_position_in_grid]]){decode_nax_body<16,N,SG>(x,w,b,y,p,group);}
DN(16,1) DN(32,1) DN(64,1) DN(32,2) DN(64,4)
#undef DN
