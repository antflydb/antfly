from pathlib import Path
import json,hashlib,gzip,subprocess
r=Path.cwd();h=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max';c=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=c.read_text();old=(h/'vision_packed_mpp.metal').read_text().replace('termite_metal_sdpa_f32_params','VisionParams');new=(h/'vision_packed_mpp16.metal').read_text().replace('termite_metal_sdpa_f32_params','VisionParams').replace('packed_mpp16(','packed_mpp(')
literal=lambda text:''.join('        '+json.dumps(x+'\n')+'\n' for x in text.splitlines());assert literal(old) in s;s=s.replace(literal(old),literal(new),1)
s=s.replace('runtime->lightonocr3_vision_mpp_pipeline.maxTotalThreadsPerThreadgroup >= 256','runtime->lightonocr3_vision_mpp_pipeline.maxTotalThreadsPerThreadgroup >= 128')
a=s.index('int termite_metal_decode_runtime_sdpa_f32_device(');i=s.index('        } else if (use_vision_hd64_flash_q32) {',a);end=s.index('        } else if (use_vision_hd64_flash_q16)',i);s=s[:i]+'''        } else if (use_vision_hd64_flash_q32) {
            const size_t query_tile = vision_packed != nil ? 16u : 32u;
            [encoder dispatchThreadgroups:MTLSizeMake(batch * num_heads * ((seq_len + query_tile - 1u) / query_tile), 1, 1)
                       threadsPerThreadgroup:MTLSizeMake(vision_packed != nil ? 128u : 256u, 1, 1)];
'''+s[end:];c.write_text(s)
f=json.loads((h/'merger-kernels-freeze.json').read_text());f={k:hashlib.sha256(Path(k).read_bytes()).hexdigest() for k in f};(h/'merger-kernels-freeze.json').write_text(json.dumps(f,indent=2)+'\n')
