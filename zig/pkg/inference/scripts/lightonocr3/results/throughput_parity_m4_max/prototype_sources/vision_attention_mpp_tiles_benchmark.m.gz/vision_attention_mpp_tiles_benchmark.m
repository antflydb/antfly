#include "../zig/pkg/inference/src/backends/metal_kernels.m"
static termite_metal_decode_runtime *vr;
static id<MTLComputePipelineState> vp,packp,vp32,vp256;
@interface VisionCase:NSObject { @public size_t seq,heads; id<MTLBuffer> q,k,v,out,packed; } @end
@implementation VisionCase @end
static NSString *vision_candidate_source(void){return @""
 "#include <metal_tensor>\n"
 "#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n"
 "using namespace mpp::tensor_ops;\n"
 "kernel void termite_sdpa_f32_vision_hd64_flash_packed_mpp(device half*q[[buffer(0)]],device half*k[[buffer(1)]],device half*v[[buffer(2)]],device const float*bias[[buffer(3)]],device const float*mask[[buffer(4)]],device float*output[[buffer(5)]],constant termite_metal_sdpa_f32_params&p[[buffer(6)]],uint tid[[thread_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]],uint group[[threadgroup_position_in_grid]]){\n"
 " const uint tiles=(p.seq_len+31)/32,qtile=group%tiles,h=(group/tiles)%p.num_heads,b=group/(tiles*p.num_heads),q0=qtile*32,qrow=(sg/4)*16,kcol=(sg%4)*32,dcol=(sg%4)*16,base=(b*p.num_heads+h)*p.reserved1*64;\n"
 " threadgroup float scores[32*128],rowmax[32],rowsum[32],correction[32];threadgroup half probs[32*128];\n"
 " if(tid<32){rowmax[tid]=-INFINITY;rowsum[tid]=0;}threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 " tensor<device half,dextents<int,2>,tensor_inline> Q(q+base+(q0+qrow)*64,dextents<int,2>(64,16),array<int,2>{1,64});\n"
 " tensor<threadgroup half,dextents<int,2>,tensor_inline> P(probs+qrow*128,dextents<int,2>(128,16),array<int,2>{1,128});\n"
 " tensor<threadgroup float,dextents<int,2>,tensor_inline> S(scores+qrow*128+kcol,dextents<int,2>(32,16),array<int,2>{1,128});\n"
 " constexpr auto qkd=matmul2d_descriptor(16,32,64,false,true,false);matmul2d<qkd,execution_simdgroups<1>> qkop;\n"
 " constexpr auto pvd=matmul2d_descriptor(16,16,128,false,false,false,matmul2d_descriptor::mode::multiply_accumulate);matmul2d<pvd,execution_simdgroups<1>> pvop;\n"
 " tensor<device half,dextents<int,2>,tensor_inline> V(v+base+dcol,dextents<int,2>(16,128),array<int,2>{1,64});\n"
 " auto out=pvop.get_destination_cooperative_tensor<decltype(P),decltype(V),float>();\n"
 " for(ushort i=0;i<out.get_capacity();i++)out[i]=0;\n"
 " for(uint start=0;start<p.seq_len;start+=128){\n"
 "  tensor<device half,dextents<int,2>,tensor_inline> K(k+base+(start+kcol)*64,dextents<int,2>(64,32),array<int,2>{1,64});\n"
 "  auto dot=qkop.get_destination_cooperative_tensor<decltype(Q),decltype(K),float>();qkop.run(Q,K,dot);dot.store(S);\n"
 "  threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "  for(uint pass=0;pass<4;pass++){\n"
 "   uint row=sg+pass*8;float x[4],e[4],m=-INFINITY;\n"
 "   for(uint j=0;j<4;j++){x[j]=(q0+row<p.seq_len&&start+lane+j*32<p.seq_len)?scores[row*128+lane+j*32]:-INFINITY;m=max(m,x[j]);}\n"
 "   m=simd_max(m);float nm=max(rowmax[row],m),c=isfinite(nm)&&isfinite(rowmax[row])?exp(rowmax[row]-nm):0,sum=0;\n"
 "   for(uint j=0;j<4;j++){e[j]=isfinite(x[j])?exp(x[j]-nm):0;probs[row*128+lane+j*32]=half(e[j]);sum+=e[j];}\n"
 "   sum=simd_sum(sum);if(lane==0){rowmax[row]=nm;rowsum[row]=rowsum[row]*c+sum;correction[row]=c;}\n"
 "  }\n"
 "  threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "  for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);out[i]*=correction[qrow+c[1]];}\n"
 "  tensor<device half,dextents<int,2>,tensor_inline> vb(v+base+start*64+dcol,dextents<int,2>(16,128),array<int,2>{1,64});\n"
 "  pvop.run(P,vb,out);\n"
 " }\n"
 " for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);uint row=qrow+c[1],d=dcol+c[0];if(q0+row<p.seq_len)output[((b*p.seq_len+q0+row)*p.num_heads+h)*64+d]=rowsum[row]>0?out[i]/rowsum[row]:0;}\n"
 "}\n"
 "#include <metal_tensor>\n"
 "#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n"
 "using namespace mpp::tensor_ops;\n"
 "kernel void termite_sdpa_f32_vision_hd64_flash_packed_mpp16(device half*q[[buffer(0)]],device half*k[[buffer(1)]],device half*v[[buffer(2)]],device const float*bias[[buffer(3)]],device const float*mask[[buffer(4)]],device float*output[[buffer(5)]],constant termite_metal_sdpa_f32_params&p[[buffer(6)]],uint tid[[thread_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]],uint group[[threadgroup_position_in_grid]]){\n"
 " const uint tiles=(p.seq_len+15)/16,qtile=group%tiles,h=(group/tiles)%p.num_heads,b=group/(tiles*p.num_heads),q0=qtile*16,qrow=(sg/4)*16,kcol=(sg%4)*32,dcol=(sg%4)*16,base=(b*p.num_heads+h)*p.reserved1*64;\n"
 " threadgroup float scores[16*128],rowmax[16],rowsum[16],correction[16];threadgroup half probs[16*128];\n"
 " if(tid<16){rowmax[tid]=-INFINITY;rowsum[tid]=0;}threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 " tensor<device half,dextents<int,2>,tensor_inline> Q(q+base+(q0+qrow)*64,dextents<int,2>(64,16),array<int,2>{1,64});\n"
 " tensor<threadgroup half,dextents<int,2>,tensor_inline> P(probs+qrow*128,dextents<int,2>(128,16),array<int,2>{1,128});\n"
 " tensor<threadgroup float,dextents<int,2>,tensor_inline> S(scores+qrow*128+kcol,dextents<int,2>(32,16),array<int,2>{1,128});\n"
 " constexpr auto qkd=matmul2d_descriptor(16,32,64,false,true,false);matmul2d<qkd,execution_simdgroups<1>> qkop;\n"
 " constexpr auto pvd=matmul2d_descriptor(16,16,128,false,false,false,matmul2d_descriptor::mode::multiply_accumulate);matmul2d<pvd,execution_simdgroups<1>> pvop;\n"
 " tensor<device half,dextents<int,2>,tensor_inline> V(v+base+dcol,dextents<int,2>(16,128),array<int,2>{1,64});\n"
 " auto out=pvop.get_destination_cooperative_tensor<decltype(P),decltype(V),float>();\n"
 " for(ushort i=0;i<out.get_capacity();i++)out[i]=0;\n"
 " for(uint start=0;start<p.seq_len;start+=128){\n"
 "  tensor<device half,dextents<int,2>,tensor_inline> K(k+base+(start+kcol)*64,dextents<int,2>(64,32),array<int,2>{1,64});\n"
 "  auto dot=qkop.get_destination_cooperative_tensor<decltype(Q),decltype(K),float>();qkop.run(Q,K,dot);dot.store(S);\n"
 "  threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "  for(uint pass=0;pass<4;pass++){\n"
 "   uint row=sg+pass*4;float x[4],e[4],m=-INFINITY;\n"
 "   for(uint j=0;j<4;j++){x[j]=(q0+row<p.seq_len&&start+lane+j*32<p.seq_len)?scores[row*128+lane+j*32]:-INFINITY;m=max(m,x[j]);}\n"
 "   m=simd_max(m);float nm=max(rowmax[row],m),c=isfinite(nm)&&isfinite(rowmax[row])?exp(rowmax[row]-nm):0,sum=0;\n"
 "   for(uint j=0;j<4;j++){e[j]=isfinite(x[j])?exp(x[j]-nm):0;probs[row*128+lane+j*32]=half(e[j]);sum+=e[j];}\n"
 "   sum=simd_sum(sum);if(lane==0){rowmax[row]=nm;rowsum[row]=rowsum[row]*c+sum;correction[row]=c;}\n"
 "  }\n"
 "  threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "  for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);out[i]*=correction[qrow+c[1]];}\n"
 "  tensor<device half,dextents<int,2>,tensor_inline> vb(v+base+start*64+dcol,dextents<int,2>(16,128),array<int,2>{1,64});\n"
 "  pvop.run(P,vb,out);\n"
 " }\n"
 " for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);uint row=qrow+c[1],d=dcol+c[0];if(q0+row<p.seq_len)output[((b*p.seq_len+q0+row)*p.num_heads+h)*64+d]=rowsum[row]>0?out[i]/rowsum[row]:0;}\n"
 "}\n"
 "#include <metal_tensor>\n"
 "#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n"
 "using namespace mpp::tensor_ops;\n"
 "kernel void termite_sdpa_f32_vision_hd64_flash_packed_mpp16k256(device half*q[[buffer(0)]],device half*k[[buffer(1)]],device half*v[[buffer(2)]],device const float*bias[[buffer(3)]],device const float*mask[[buffer(4)]],device float*output[[buffer(5)]],constant termite_metal_sdpa_f32_params&p[[buffer(6)]],uint tid[[thread_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]],uint group[[threadgroup_position_in_grid]]){\n"
 " const uint tiles=(p.seq_len+15)/16,qtile=group%tiles,h=(group/tiles)%p.num_heads,b=group/(tiles*p.num_heads),q0=qtile*16,qrow=(sg/4)*16,kcol=(sg%4)*64,dcol=(sg%4)*16,base=(b*p.num_heads+h)*p.reserved1*64;\n"
 " threadgroup float scores[16*256],rowmax[16],rowsum[16],correction[16];threadgroup half probs[16*256];\n"
 " if(tid<16){rowmax[tid]=-INFINITY;rowsum[tid]=0;}threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 " tensor<device half,dextents<int,2>,tensor_inline> Q(q+base+(q0+qrow)*64,dextents<int,2>(64,16),array<int,2>{1,64});\n"
 " tensor<threadgroup half,dextents<int,2>,tensor_inline> P(probs+qrow*256,dextents<int,2>(256,16),array<int,2>{1,256});\n"
 " tensor<threadgroup float,dextents<int,2>,tensor_inline> S(scores+qrow*256+kcol,dextents<int,2>(64,16),array<int,2>{1,256});\n"
 " constexpr auto qkd=matmul2d_descriptor(16,64,64,false,true,false);matmul2d<qkd,execution_simdgroups<1>> qkop;\n"
 " constexpr auto pvd=matmul2d_descriptor(16,16,256,false,false,false,matmul2d_descriptor::mode::multiply_accumulate);matmul2d<pvd,execution_simdgroups<1>> pvop;\n"
 " tensor<device half,dextents<int,2>,tensor_inline> V(v+base+dcol,dextents<int,2>(16,256),array<int,2>{1,64});\n"
 " auto out=pvop.get_destination_cooperative_tensor<decltype(P),decltype(V),float>();\n"
 " for(ushort i=0;i<out.get_capacity();i++)out[i]=0;\n"
 " for(uint start=0;start<p.seq_len;start+=256){\n"
 "  tensor<device half,dextents<int,2>,tensor_inline> K(k+base+(start+kcol)*64,dextents<int,2>(64,64),array<int,2>{1,64});\n"
 "  auto dot=qkop.get_destination_cooperative_tensor<decltype(Q),decltype(K),float>();qkop.run(Q,K,dot);dot.store(S);\n"
 "  threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "  for(uint pass=0;pass<4;pass++){\n"
 "   uint row=sg+pass*4;float x[8],e[8],m=-INFINITY;\n"
 "   for(uint j=0;j<8;j++){x[j]=(q0+row<p.seq_len&&start+lane+j*32<p.seq_len)?scores[row*256+lane+j*32]:-INFINITY;m=max(m,x[j]);}\n"
 "   m=simd_max(m);float nm=max(rowmax[row],m),c=isfinite(nm)&&isfinite(rowmax[row])?exp(rowmax[row]-nm):0,sum=0;\n"
 "   for(uint j=0;j<8;j++){e[j]=isfinite(x[j])?exp(x[j]-nm):0;probs[row*256+lane+j*32]=half(e[j]);sum+=e[j];}\n"
 "   sum=simd_sum(sum);if(lane==0){rowmax[row]=nm;rowsum[row]=rowsum[row]*c+sum;correction[row]=c;}\n"
 "  }\n"
 "  threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "  for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);out[i]*=correction[qrow+c[1]];}\n"
 "  tensor<device half,dextents<int,2>,tensor_inline> vb(v+base+start*64+dcol,dextents<int,2>(16,256),array<int,2>{1,64});\n"
 "  pvop.run(P,vb,out);\n"
 " }\n"
 " for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);uint row=qrow+c[1],d=dcol+c[0];if(q0+row<p.seq_len)output[((b*p.seq_len+q0+row)*p.num_heads+h)*64+d]=rowsum[row]>0?out[i]/rowsum[row]:0;}\n"
 "}\n"
 "kernel void vision_pack_half(device const float*q[[buffer(0)]],device const float*k[[buffer(1)]],device const float*v[[buffer(2)]],device half*out[[buffer(3)]],constant termite_metal_sdpa_f32_params&p[[buffer(4)]],uint i[[thread_position_in_grid]]){\n"
 " uint count=p.batch*p.num_heads*p.reserved1*64;if(i>=count)return;uint d=i%64,s=(i/64)%p.reserved1,h=(i/(64*p.reserved1))%p.num_heads,b=i/(64*p.reserved1*p.num_heads);uint offset=((b*p.seq_len+s)*p.num_heads+h)*64+d;\n"
 " out[i]=s<p.seq_len?half(q[offset]*0.125f):half(0);out[count+i]=s<p.seq_len?half(k[offset]):half(0);out[2*count+i]=s<p.seq_len?half(v[offset]):half(0);\n"
 "}\n"
;}
void *vision_create(size_t seq,size_t heads,const float*q,const float*k,const float*v) {
 @autoreleasepool {
 if(!vr){vr=termite_metal_decode_runtime_create();if(!vr)return NULL;
 MTLCompileOptions*o=[MTLCompileOptions new];o.languageVersion=MTLLanguageVersion4_0;o.mathMode=MTLMathModeSafe;
 NSError*err=nil;id<MTLLibrary> lib=[vr->device newLibraryWithSource:[termite_metal_shader_source() stringByAppendingString:vision_candidate_source()] options:o error:&err];
 if(!lib){fprintf(stderr,"vision candidate: %s\n",err.localizedDescription.UTF8String);return NULL;}
 packp=termite_metal_make_pipeline(vr->device,lib,@"vision_pack_half");if(!packp)return NULL;
 vp32=termite_metal_make_pipeline(vr->device,lib,@"termite_sdpa_f32_vision_hd64_flash_packed_mpp");vp256=termite_metal_make_pipeline(vr->device,lib,@"termite_sdpa_f32_vision_hd64_flash_packed_mpp16k256");if(!vp32||!vp256)return NULL;
 vp=termite_metal_make_pipeline(vr->device,lib,@"termite_sdpa_f32_vision_hd64_flash_packed_mpp16");
 if(!vp||vp.maxTotalThreadsPerThreadgroup<256||vp.staticThreadgroupMemoryLength>vr->device.maxThreadgroupMemoryLength)return NULL;
 fprintf(stderr,"vision_q64 threads=%zu static_bytes=%zu\n",(size_t)vp.maxTotalThreadsPerThreadgroup,(size_t)vp.staticThreadgroupMemoryLength);
 }
 VisionCase*c=[VisionCase new];c->seq=seq;c->heads=heads;size_t bytes=seq*heads*64*4;
 c->q=[vr->device newBufferWithBytes:q length:bytes options:MTLResourceStorageModeShared];
 c->k=[vr->device newBufferWithBytes:k length:bytes options:MTLResourceStorageModeShared];
 c->v=[vr->device newBufferWithBytes:v length:bytes options:MTLResourceStorageModeShared];
 c->out=[vr->device newBufferWithLength:bytes options:MTLResourceStorageModeShared];
 c->packed=[vr->device newBufferWithLength:3*((seq+255)/256*256)*heads*64*2 options:MTLResourceStorageModePrivate];
 if(!c->q||!c->k||!c->v||!c->out||!c->packed)return NULL;return (__bridge_retained void*)c;
 }}
uint64_t vision_run(void*handle,size_t candidate) {
 @autoreleasepool {VisionCase*c=(__bridge VisionCase*)handle;if(termite_metal_decode_runtime_begin_frame(vr))return 0;
 int rc=0;
 {
 termite_metal_sdpa_f32_params p={1,(uint32_t)c->seq,(uint32_t)c->heads,64,0,0,1,(uint32_t)((c->seq+255)/256*256)};
 id<MTLComputeCommandEncoder>e=termite_metal_tracked_compute_command_encoder_for(vr->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_ATTENTION);if(!e)return 0;
 size_t count=p.batch*p.num_heads*p.reserved1*64;
 [e setComputePipelineState:packp];[e setBuffer:c->q offset:0 atIndex:0];[e setBuffer:c->k offset:0 atIndex:1];[e setBuffer:c->v offset:0 atIndex:2];[e setBuffer:c->packed offset:0 atIndex:3];[e setBytes:&p length:sizeof(p) atIndex:4];
 [e dispatchThreads:MTLSizeMake(count,1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];[e memoryBarrierWithScope:MTLBarrierScopeBuffers];
 [e setComputePipelineState:candidate==0?vp32:candidate==1?vp:vp256];[e setBuffer:c->packed offset:0 atIndex:0];[e setBuffer:c->packed offset:count*2 atIndex:1];[e setBuffer:c->packed offset:count*4 atIndex:2];[e setBuffer:vr->optional_dummy_buffer offset:0 atIndex:3];[e setBuffer:vr->optional_dummy_buffer offset:0 atIndex:4];[e setBuffer:c->out offset:0 atIndex:5];[e setBytes:&p length:sizeof(p) atIndex:6];
 [e dispatchThreadgroups:MTLSizeMake(c->heads*((c->seq+(candidate==0?31:15))/(candidate==0?32:16)),1,1) threadsPerThreadgroup:MTLSizeMake(candidate==0?256:128,1,1)];[e endEncoding];}
 if(rc||termite_metal_decode_runtime_submit_frame(vr)||termite_metal_decode_runtime_wait_frame(vr))return 0;return vr->last_frame_gpu_nanos;
 }}
const float*vision_output(void*h){return ((__bridge VisionCase*)h)->out.contents;}
void vision_release(void*h){id obj=CFBridgingRelease(h);(void)obj;}
void vision_shutdown(void){termite_metal_decode_runtime_destroy(vr);vr=NULL;vp=nil;}
