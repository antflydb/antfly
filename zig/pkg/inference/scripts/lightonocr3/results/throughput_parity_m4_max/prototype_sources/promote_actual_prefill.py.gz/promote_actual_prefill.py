from pathlib import Path
import json,subprocess,hashlib
r=Path.cwd();h=r/'.venv-lighton-vllm-metal';c=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=c.read_text();shader=(h/'prefill_gate_tg_tiles.metal').read_text().replace('pair_prefill_gate','termite_lightonocr3_prefill_gate').replace('PN(4,16) PN(8,16) PN(16,16) PN(8,32) PN(16,32)','PN(8,16) PN(16,32)');needle='        "struct Params { uint rows; uint in_dim; uint out_dim; uint pad; };\\n"\n';assert needle in s;s=s.replace(needle,needle+''.join('        '+json.dumps(x+'\n')+'\n'for x in shader.splitlines()),1)
needle='    id<MTLComputePipelineState> lightonocr3_local_gate_tg16, lightonocr3_local_gate_tg32;';s=s.replace(needle,needle+'\n    id<MTLComputePipelineState> lightonocr3_prefill_gate8_16,lightonocr3_prefill_gate16_32;')
idx=s.index('            runtime->lightonocr3_local_gate_tg16 =');s=s[:idx]+'''            runtime->lightonocr3_prefill_gate8_16=termite_metal_make_pipeline(device,tensor_library,@"termite_lightonocr3_prefill_gate8_16");
            runtime->lightonocr3_prefill_gate16_32=termite_metal_make_pipeline(device,tensor_library,@"termite_lightonocr3_prefill_gate16_32");
'''+s[idx:];idx=s.index('    runtime->lightonocr3_local_gate_tg16=nil;');s=s[:idx]+'    runtime->lightonocr3_prefill_gate8_16=nil;runtime->lightonocr3_prefill_gate16_32=nil;\n'+s[idx:]
helper=(h/'prefill_gate_helper.c').read_text().replace('PREFILL_GATE_SPLITS','16').replace('PREFILL_GATE_COLUMNS','32').replace('PREFILL_GATE_PIPELINE','lightonocr3_prefill_gate16_32');helper=helper.replace('r->linear_weight_dtypes[slot] != TERMITE_METAL_DENSE_LINEAR_DTYPE_BF16 ||','r->linear_weight_dtypes[slot] != TERMITE_METAL_DENSE_LINEAR_DTYPE_BF16 ||\n        !r->linear_slot_prepared[slot] || r->linear_in_dims[slot]!=in || r->linear_out_dims[slot]!=out ||');helper=helper.replace('if (pipeline == nil ||','if (output==weight || output==bias || pipeline == nil ||');helper=subprocess.check_output(['/opt/homebrew/opt/llvm/bin/clang-format','-style={BasedOnStyle: LLVM, IndentWidth: 4, ColumnLimit: 110}'],input=helper.encode()).decode();idx=s.index('// Return zero to decline, one on success, negative on an encoding failure.\nstatic int termite_metal_try_lightonocr3_mpp');s=s[:idx]+helper+'\n'+s[idx:]
idx=s.index('    const bool bf16 =',s.index('static int termite_metal_try_lightonocr3_mpp('));s=s[:idx]+'''    const int prefill_gate_rc=termite_metal_try_lightonocr3_prefill_gate(runtime,slot,input,input_offset,rows,in_dim,out_dim,output,output_offset);
    if(prefill_gate_rc!=0)return prefill_gate_rc;
    const bool prefill_post=rows>=32&&rows<=2048&&in_dim==2048&&out_dim==1024&&
        !termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PROJECTIONS"));
'''+s[idx:];s=s.replace('const bool small_tile = !bf16 && rows >= 4 && rows <= 8 && (small_ffn_shape || small_qkv_shape) &&','const bool small_tile = !bf16 && ((rows >= 4 && rows <= 8 && (small_ffn_shape || small_qkv_shape)) || prefill_post) &&',1);needle='    const bool shape = (in_dim == 768 &&';s=s.replace(needle,'    const bool shape = prefill_post || (in_dim == 768 &&',1);c.write_text(s)
p=r/'zig/pkg/inference/src/architectures/qwen3vl_projector.zig';s=p.read_text().replace('max_patch_tokens > 256 and max_patch_tokens <= 4096)','max_patch_tokens > 256)').replace('admissionAdd(max_patch_tokens, 127)','admissionAdd(@min(max_patch_tokens, 4096), 127)');s=s.replace('    // them in addition to the earlier score/FFN maximum, even on older devices.','    // them in addition to the earlier score/FFN maximum, even on older devices.\n    // Larger fallback geometries may follow a supported image in the same\n    // epoch, so retain the bounded 4096-row packing charge for those too.');p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/check_metal_vision.m';s=p.read_text().replace('"vision batch=%zu seq=%zu full_output=pass cpu=pass canaries=pass max_abs=%g\\n", c->batch,\n            c->seq, worst','"vision heads=%zu batch=%zu seq=%zu full_output=pass cpu=pass canaries=pass max_abs=%g\\n", c->heads,c->batch,\n            c->seq, worst');p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m';s=p.read_text();s=s.replace('if (!bf16 && rows >= 2 && rows <= 8 && offset_floats % 4 == 0) {','''const bool narrow_prefill = rows>=32&&rows<=2048&&((in==1024&&out==16&&r->lightonocr3_prefill_gate8_16!=nil)||(in==2560&&out==32&&r->lightonocr3_prefill_gate16_32!=nil))&&
            !termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PROJECTIONS"));
        const bool post_prefill=rows>=32&&rows<=2048&&in==2048&&out==1024&&r->lightonocr3_mpp_small_tile_pipeline!=nil&&
            !termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PROJECTIONS"));
        if (!bf16 && ((rows >= 2 && rows <= 8)||narrow_prefill||post_prefill) && offset_floats % 4 == 0) {''',1)
needle='''            int local = termite_metal_try_lightonocr3_local_projection(r, 0, input, offset_floats * 4, rows,
                                                                       in, out, result, 16);''';assert needle in s;s=s.replace(needle,'''            int local = narrow_prefill ? termite_metal_try_lightonocr3_prefill_gate(r,0,input,offset_floats*4,rows,in,out,result,16)
                : post_prefill ? termite_metal_try_lightonocr3_mpp(r,0,input,offset_floats*4,rows,in,out,result,16)
                : termite_metal_try_lightonocr3_local_projection(r,0,input,offset_floats*4,rows,in,out,result,16);
            if((narrow_prefill||post_prefill)&&local!=1)return 36;''',1)
idx=s.index('        if(cached_norm_views_check(r,1024)');s=s[:idx]+'''        const size_t prefill_rows[]={33,129,432,554,662,2048};
        for(size_t i=0;i<sizeof(prefill_rows)/sizeof(prefill_rows[0]);i++){
            if(projection(r,prefill_rows[i],1024,16,4)||projection(r,prefill_rows[i],2560,32,4)||projection(r,prefill_rows[i],2048,1024,4))return 140;
        }
        setenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PROJECTIONS","1",1);
        if(projection(r,129,1024,16,4)||projection(r,129,2560,32,4)||projection(r,129,2048,1024,4))return 141;
        unsetenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_PROJECTIONS");
        id<MTLComputePipelineState> gate08=r->lightonocr3_prefill_gate8_16,gate4b=r->lightonocr3_prefill_gate16_32;
        r->lightonocr3_prefill_gate8_16=nil;r->lightonocr3_prefill_gate16_32=nil;
        if(projection(r,129,1024,16,4)||projection(r,129,2560,32,4))return 142;
        r->lightonocr3_prefill_gate8_16=gate08;r->lightonocr3_prefill_gate16_32=gate4b;
'''+s[idx:];p.write_text(s)
