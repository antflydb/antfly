import subprocess,sys
from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3';h=r/'.venv-lighton-vllm-metal';out=p/'results/throughput_parity_m4_max'
for variant in ['decodevec16x2','decodevec32x4','decodempp16','decodempp32','decodegemv1','decodetg']:
 for flush,label in [(0,'resident'),(64,'cold64')]:
  name=variant+'_'+label;print('START',name,flush=True)
  cmd=[sys.executable,str(p/'benchmark_metal_pair.py'),'--native-library',str(h/'metal_pair_observed_decode.dylib'),'--timing-library',str(h/'metal_timing_qualified.dylib'),'--suite','decode-missing','--variant',variant,'--only-candidates','--compare-production','--trials','30','--cache-flush-mib',str(flush),'--output',str(out/(name+'.json'))]
  if variant=='decodevec16x2' and flush==0:cmd+=['--compile-native-library']
  with open('/private/tmp/ocr-parity-'+name+'.txt','w')as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
  print('DONE',name,flush=True)
