#include <metal_stdlib>
#include <metal_simdgroup_matrix>
using namespace metal;
struct DecodeParams{uint rows,in_dim,out_dim,pad;};
template<uint SG> inline void decode_f32_mma_body(device const float*x,device const ushort*w,device const float*b,device float*y,constant DecodeParams&p,uint group,uint sg,uint tid,threadgroup float*scratch){
 const uint N=SG*8,columns=group*N,basecol=columns+sg*8;
 for(uint i=tid;i<64;i+=SG*32)scratch[i]=float(i);
 threadgroup_barrier(mem_flags::mem_threadgroup);
 // Discover the opaque SIMD matrix element coordinates once. All operand
 // loads below keep the original F32 activation and BF16 weight values.
 simdgroup_float8x8 coord;simdgroup_load(coord,scratch,8u);
 uint z0=uint(coord.thread_elements()[0]),z1=uint(coord.thread_elements()[1]);
 const uint r0=z0>>3,c0=z0&7,r1=z1>>3,c1=z1&7;
 simdgroup_float8x8 acc=make_filled_simdgroup_matrix<float,8>(0.0f);
 for(uint k=0;k<p.in_dim;k+=8){
  simdgroup_float8x8 a,v;
  a.thread_elements()[0]=r0<p.rows?x[r0*p.in_dim+k+c0]:0.0f;
  a.thread_elements()[1]=r1<p.rows?x[r1*p.in_dim+k+c1]:0.0f;
  v.thread_elements()[0]=basecol+c0<p.out_dim?as_type<float>(uint(w[(basecol+c0)*p.in_dim+k+r0])<<16):0.0f;
  v.thread_elements()[1]=basecol+c1<p.out_dim?as_type<float>(uint(w[(basecol+c1)*p.in_dim+k+r1])<<16):0.0f;
  simdgroup_multiply_accumulate(acc,a,v,acc);
 }
 threadgroup_barrier(mem_flags::mem_threadgroup);
 simdgroup_store(acc,scratch+sg*8,N);
 threadgroup_barrier(mem_flags::mem_threadgroup);
 for(uint i=tid;i<p.rows*N;i+=SG*32){uint col=columns+i%N;if(col<p.out_dim)y[(i/N)*p.out_dim+col]=scratch[i]+b[col];}
}
#define DM(SG) kernel void pair_decode_mma##SG(device const float*x[[buffer(0)]],device const ushort*w[[buffer(1)]],device const float*b[[buffer(2)]],device float*y[[buffer(3)]],constant DecodeParams&p[[buffer(4)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint tid[[thread_index_in_threadgroup]]){threadgroup float scratch[64*SG];decode_f32_mma_body<SG>(x,w,b,y,p,group,sg,tid,scratch);}
DM(2) DM(4) DM(8)
#undef DM
