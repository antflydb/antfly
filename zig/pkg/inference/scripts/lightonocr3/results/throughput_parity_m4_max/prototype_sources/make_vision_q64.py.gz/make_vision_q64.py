from pathlib import Path
import re,json
r=Path.cwd();s=(r/'zig/pkg/inference/src/backends/metal_kernels.m').read_text();a=s.index('           "kernel void termite_sdpa_f32_vision_hd64_flash_q32(');b=s.index('           // Full F32 variant',a);part=s[a:b];kernel=''.join(json.loads('"'+x+'"') for x in re.findall(r'"((?:[^"\\]|\\.)*)"',part));kernel=kernel.replace('flash_q32(','flash_q64(').replace('(p.seq_len + 31u) / 32u','(p.seq_len + 63u) / 64u').replace('q0 = query_tile * 32u','q0 = query_tile * 64u')
old='threadgroup half sq[2048]; threadgroup half skv[2048]; threadgroup float ss[1024]; threadgroup half sp[1024]; threadgroup float sM[32]; threadgroup float sS[32]; threadgroup float sdiag[256]; threadgroup float so[2048];'
new='struct Scratch { half sq[4096]; half skv[2048]; float ss[2048]; half sp[2048]; float sM[64]; float sS[64]; float sdiag[512]; }; threadgroup Scratch scratch; threadgroup half *sq=scratch.sq,*skv=scratch.skv,*sp=scratch.sp; threadgroup float *ss=scratch.ss,*sM=scratch.sM,*sS=scratch.sS,*sdiag=scratch.sdiag; threadgroup float *so=(threadgroup float*)&scratch;'
assert old in kernel;kernel=kernel.replace(old,new)
# Only query loading grows; the K/V tile remains 32 keys.
old='for (uint i = uint(tid); i < 2048u; i += 256u)';assert kernel.count(old)==3;kernel=kernel.replace(old,'for (uint i = uint(tid); i < 4096u; i += 256u)',1)
kernel=kernel.replace('tid < 32u','tid < 64u').replace('if (tid < 256u) sdiag[tid] = 0.0f;','for(uint i=uint(tid);i<512u;i+=256u)sdiag[i]=0.0f;').replace('mo[2][2]','mo[4][2]').replace('qp < 2u','qp < 4u').replace('pass < 4u','pass < 8u').replace('q0 + 32u <= p.seq_len','q0 + 64u <= p.seq_len')
(r/'.venv-lighton-vllm-metal/vision_q64.metal').write_text(kernel)
literal='static NSString *vision_candidate_source(void) {return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n' for x in kernel.splitlines())+';}\n'
base='''#include "../zig/pkg/inference/src/backends/metal_kernels.m"
static termite_metal_decode_runtime *vr;
static id<MTLComputePipelineState> vp;
@interface VisionCase:NSObject { @public size_t seq,heads; id<MTLBuffer> q,k,v,out; } @end
@implementation VisionCase @end
'''+literal+'''
void *vision_create(size_t seq,size_t heads,const float*q,const float*k,const float*v) {
 @autoreleasepool {
 if(!vr){vr=termite_metal_decode_runtime_create();if(!vr)return NULL;
 MTLCompileOptions*o=[MTLCompileOptions new];o.languageVersion=MTLLanguageVersion4_0;o.mathMode=MTLMathModeSafe;
 NSError*err=nil;id<MTLLibrary> lib=[vr->device newLibraryWithSource:[termite_metal_shader_source() stringByAppendingString:vision_candidate_source()] options:o error:&err];
 if(!lib){fprintf(stderr,"vision candidate: %s\\n",err.localizedDescription.UTF8String);return NULL;}
 vp=termite_metal_make_pipeline(vr->device,lib,@"termite_sdpa_f32_vision_hd64_flash_q64");
 if(!vp||vp.maxTotalThreadsPerThreadgroup<256||vp.staticThreadgroupMemoryLength>vr->device.maxThreadgroupMemoryLength)return NULL;
 fprintf(stderr,"vision_q64 threads=%zu static_bytes=%zu\\n",(size_t)vp.maxTotalThreadsPerThreadgroup,(size_t)vp.staticThreadgroupMemoryLength);
 }
 VisionCase*c=[VisionCase new];c->seq=seq;c->heads=heads;size_t bytes=seq*heads*64*4;
 c->q=[vr->device newBufferWithBytes:q length:bytes options:MTLResourceStorageModeShared];
 c->k=[vr->device newBufferWithBytes:k length:bytes options:MTLResourceStorageModeShared];
 c->v=[vr->device newBufferWithBytes:v length:bytes options:MTLResourceStorageModeShared];
 c->out=[vr->device newBufferWithLength:bytes options:MTLResourceStorageModeShared];
 if(!c->q||!c->k||!c->v||!c->out)return NULL;return (__bridge_retained void*)c;
 }}
uint64_t vision_run(void*handle,size_t candidate) {
 @autoreleasepool {VisionCase*c=(__bridge VisionCase*)handle;if(termite_metal_decode_runtime_begin_frame(vr))return 0;
 int rc=0;
 if(!candidate)rc=termite_metal_decode_runtime_sdpa_f32_device(vr,(__bridge void*)c->q,0,(__bridge void*)c->k,0,(__bridge void*)c->v,0,NULL,0,NULL,0,1,c->seq,c->heads,64,0,0,1,1,0,(__bridge void*)c->out,0);
 else{
 termite_metal_sdpa_f32_params p={1,(uint32_t)c->seq,(uint32_t)c->heads,64,0,0,1,0};
 id<MTLComputeCommandEncoder>e=termite_metal_tracked_compute_command_encoder_for(vr->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_ATTENTION);if(!e)return 0;
 [e setComputePipelineState:vp];[e setBuffer:c->q offset:0 atIndex:0];[e setBuffer:c->k offset:0 atIndex:1];[e setBuffer:c->v offset:0 atIndex:2];[e setBuffer:vr->optional_dummy_buffer offset:0 atIndex:3];[e setBuffer:vr->optional_dummy_buffer offset:0 atIndex:4];[e setBuffer:c->out offset:0 atIndex:5];[e setBytes:&p length:sizeof(p) atIndex:6];
 [e dispatchThreadgroups:MTLSizeMake(c->heads*((c->seq+63)/64),1,1) threadsPerThreadgroup:MTLSizeMake(256,1,1)];[e endEncoding];}
 if(rc||termite_metal_decode_runtime_submit_frame(vr)||termite_metal_decode_runtime_wait_frame(vr))return 0;return vr->last_frame_gpu_nanos;
 }}
const float*vision_output(void*h){return ((__bridge VisionCase*)h)->out.contents;}
void vision_release(void*h){id obj=CFBridgingRelease(h);(void)obj;}
void vision_shutdown(void){termite_metal_decode_runtime_destroy(vr);vr=NULL;vp=nil;}
'''
(r/'.venv-lighton-vllm-metal/vision_attention_benchmark.m').write_text(base)
