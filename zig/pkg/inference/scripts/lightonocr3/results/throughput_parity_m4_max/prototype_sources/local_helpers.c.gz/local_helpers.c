// Local reductions keep partials in registers or bounded threadgroup memory.
// Unsupported resource envelopes retain the preceding production routes.
static bool termite_metal_lightonocr3_local_pipeline_valid(termite_metal_decode_runtime *r,
                                                           id<MTLComputePipelineState> p, size_t threads,
                                                           size_t memory) {
    return p != nil && p.threadExecutionWidth == 32 && p.maxTotalThreadsPerThreadgroup >= threads &&
           p.staticThreadgroupMemoryLength <= r->device.maxThreadgroupMemoryLength &&
           memory <= r->device.maxThreadgroupMemoryLength - p.staticThreadgroupMemoryLength;
}
static id<MTLComputePipelineState>
termite_metal_lightonocr3_local_gate_pipeline(termite_metal_decode_runtime *r, size_t rows, size_t in,
                                              size_t out) {
    if (rows < 2 || rows > 8 || !((in == 1024 && out == 3584) || (in == 2560 && out == 9216)) ||
        termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_LOCAL_KERNELS")))
        return nil;
    id<MTLComputePipelineState> p = rows <= 3    ? r->lightonocr3_local_gate_vectors[rows - 2]
                                    : in == 1024 ? r->lightonocr3_local_gate_tg16
                                                 : r->lightonocr3_local_gate_tg32;
    const size_t memory = rows <= 3 ? 0 : 2 * 4 * 8 * (in == 1024 ? 16 : 32) * sizeof(float);
    return termite_metal_lightonocr3_local_pipeline_valid(r, p, 128, memory) ? p : nil;
}
static int termite_metal_try_lightonocr3_local_projection(termite_metal_decode_runtime *r, size_t slot,
                                                          id<MTLBuffer> input, size_t input_offset,
                                                          size_t rows, size_t in, size_t out,
                                                          id<MTLBuffer> output, size_t output_offset) {
    if (rows < 2 || rows > 8 || !termite_metal_lightonocr3_fast_projections(r) || input_offset % 16 ||
        output_offset % 4 || r->linear_weight_dtypes[slot] != TERMITE_METAL_DENSE_LINEAR_DTYPE_BF16 ||
        termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_LOCAL_KERNELS")) ||
        termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_BATCH_PROJECTIONS")) ||
        termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_TILED_PROJECTIONS")) ||
        termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_MPP")) ||
        termite_metal_env_flag_enabled(getenv("TERMITE_METAL_LIGHTONOCR3_BF16_ACTIVATIONS")))
        return 0;
    const bool qkv = (in == 1024 && out == 6144) || (in == 2560 && out == 8192);
    const bool ffn = (in == 1024 && out == 3584) || (in == 2560 && out == 9216);
    const bool small_down = in == 3584 && out == 1024, large_down = in == 9216 && out == 2560;
    if ((qkv && termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_QKV_SMALL_TILE"))) ||
        (ffn && termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_FFN_SMALL_TILE"))) ||
        ((small_down || large_down) &&
         termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_DOWN_SPLIT"))))
        return 0;
    id<MTLComputePipelineState> p = nil;
    size_t columns = 16, threads = 128, memory = 0;
    if (rows <= 4 && (qkv || ffn)) {
        p = r->lightonocr3_local_projection_vectors[rows - 2];
        if (rows == 4)
            columns = 32;
    } else if (large_down && rows <= 3) {
        p = r->lightonocr3_local_down_vectors[rows - 2];
        columns = 16;
    } else if (large_down && rows == 4)
        p = r->lightonocr3_local_down_vector4;
    else if (small_down && rows >= 4) {
        p = r->lightonocr3_local_down_tg16;
        threads = 512;
        memory = 16 * 8 * 16 * 4;
    } else if (large_down && rows == 8) {
        p = r->lightonocr3_local_down_tg8;
        threads = 256;
        memory = 8 * 8 * 16 * 4;
    }
    if (!termite_metal_lightonocr3_local_pipeline_valid(r, p, threads, memory))
        return 0;
    if (input == output || output == r->linear_weight_buffers[slot] || output == r->linear_bias_buffers[slot])
        return -3;
    const size_t ib = rows * in * 4, ob = rows * out * 4;
    if (input_offset > input.length || ib > input.length - input_offset || output_offset > output.length ||
        ob > output.length - output_offset || r->linear_weight_buffers[slot].length < in * out * 2 ||
        r->linear_bias_buffers[slot].length < out * 4)
        return -7;
    bool owned = true;
    id<MTLCommandBuffer> cb = termite_metal_decode_runtime_command_buffer(r, __func__, &owned);
    if (!cb)
        return -10;
    if (!owned && (termite_metal_decode_runtime_retain_frame_resource(r, input) ||
                   termite_metal_decode_runtime_retain_frame_resource(r, output)))
        return -10;
    termite_metal_planned_encoder_range ranges[4];
    if (termite_metal_planned_range_make(input, input_offset, ib, TERMITE_METAL_PLANNED_RANGE_READ,
                                         &ranges[0], -11) ||
        termite_metal_planned_range_make(r->linear_weight_buffers[slot], 0, in * out * 2,
                                         TERMITE_METAL_PLANNED_RANGE_READ, &ranges[1], -11) ||
        termite_metal_planned_range_make(r->linear_bias_buffers[slot], 0, out * 4,
                                         TERMITE_METAL_PLANNED_RANGE_READ, &ranges[2], -11) ||
        termite_metal_planned_range_make(output, output_offset, ob, TERMITE_METAL_PLANNED_RANGE_WRITE,
                                         &ranges[3], -11) ||
        termite_metal_decode_runtime_prepare_planned_compute_accesses(r, ranges, 4, -11))
        return -11;
    id<MTLComputeCommandEncoder> e = r->active_planned_compute_encoder;
    const bool planned = e != nil;
    if (!planned)
        e = termite_metal_tracked_compute_command_encoder_for(cb, TERMITE_METAL_COMPUTE_SOURCE_DENSE_LINEAR);
    if (!e)
        return -12;
    const termite_metal_linear_params params = {(uint32_t)rows, (uint32_t)in, (uint32_t)out, 0};
    [e setComputePipelineState:p];
    [e setBuffer:input offset:input_offset atIndex:0];
    [e setBuffer:r->linear_weight_buffers[slot] offset:0 atIndex:1];
    [e setBuffer:r->linear_bias_buffers[slot] offset:0 atIndex:2];
    [e setBuffer:output offset:output_offset atIndex:3];
    [e setBytes:&params length:sizeof(params) atIndex:4];
    if (memory)
        [e setThreadgroupMemoryLength:memory atIndex:0];
    [e dispatchThreadgroups:MTLSizeMake(out / columns, 1, 1)
        threadsPerThreadgroup:MTLSizeMake(threads, 1, 1)];
    if (!planned)
        [e endEncoding];
    termite_metal_maybe_trace_dense_linear_dispatch("linear_multi_row_device", slot, rows, in, out,
                                                    memory ? "lightonocr3_down_local_tg"
                                                           : "lightonocr3_projection_local_vector",
                                                    !owned, planned, false, false, false);
    int rc = termite_metal_decode_runtime_finish_command_buffer(cb, owned, -13);
    return rc == 0 ? 1 : rc;
}
