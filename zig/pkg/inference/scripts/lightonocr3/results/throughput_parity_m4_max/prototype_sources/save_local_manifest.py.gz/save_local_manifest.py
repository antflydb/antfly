import json,hashlib,subprocess,re
from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max';f=json.loads((r/'.venv-lighton-vllm-metal/local-kernels-freeze.json').read_text());sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert all(sha(k)==v for k,v in f.items()),'Runtime changed during build'
log=Path('/private/tmp/ocr-parity-local-build.txt').read_text();hits=re.findall(r'\.zig-cache/o/([0-9a-f]{32})/test(?:\s|$)',log);assert hits;binary=r/'zig/.zig-cache/o'/hits[-1]/'test';base='58d7e441dd3c2f19584d99b5baa321659a387ef7'
d=dict(runtime_commit=base,runtime_source_diff_sha256=hashlib.sha256(subprocess.check_output(['git','diff',base,'--','zig/pkg/inference/src'])).hexdigest(),binary_sha256=sha(binary),runtime_files_sha256=f)
(p/'local_build_manifest.json').write_text(json.dumps(d,indent=2)+'\n');print(binary)
