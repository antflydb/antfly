from pathlib import Path
import json,hashlib,statistics
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max';sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest();m=json.loads((p/'shipping_build_manifest.json').read_text());runtime_sha=m['runtime_files_sha256']['zig/pkg/inference/src/backends/metal_kernels.m']
s=dict(scope='Final integrated runtime on shared 36 GiB M4 Max. GPU primitive timings and separate reader wall clock. F32 native activations/output versus BF16 MLX except F32 normalization; original BF16 LightOn weights. Not a universal parity or real-document OCR accuracy claim.',build_manifest_sha256=sha(p/'shipping_build_manifest.json'),primitive_sweeps=[],attention=[],prefill=[],decode_improvements=[],readers=[])
for suite in ['page_shapes','decode_shapes']:
 for cache in ['resident','cold64']:
  f=p/('shipping_'+suite+'_'+cache+'.json');d=json.loads(f.read_text());assert d['status']=='ok'and d['runtime_source_sha256']==runtime_sha;xs=d['results'];s['primitive_sweeps'].append(dict(report=f.name,sha256=sha(f),cases=len(xs),median_at_or_below_mlx=sum(x['median_native_over_mlx']<=1 for x in xs),median_within_20_percent=sum(x['median_native_over_mlx']<=1.2 for x in xs),mean_within_20_percent=sum(x['native_over_mlx']<=1.2 for x in xs),exceptions=[{k:x[k]for k in ['operation','rows','in','out','median_native_over_mlx','native_over_mlx']}for x in xs if x['median_native_over_mlx']>1.2]))
f=p/'shipping_vision_attention.json';d=json.loads(f.read_text());assert d['runtime_source_sha256']==runtime_sha and len(d['results'])==14;s['attention']=[{k:v for k,v in x.items()if k!='samples_us'}for x in d['results']];s['attention_report_sha256']=sha(f)
for suite,target in [('prefill','prefill'),('decode','decode_improvements')]:
 for cache in ['resident','cold64']:
  f=p/('shipping_'+suite+'_previous_vs_current_'+cache+'.json');d=json.loads(f.read_text());assert d['status']=='ok'and d['runtime_source_sha256']==runtime_sha
  for x in d['results']:s[target].append(dict(cache=cache,rows=x['rows'],input_dim=x['in'],output_dim=x['out'],new_over_old_median=1/x['median_native_over_production'],new_over_mlx_median=x['production']['median_us']/x['mlx']['median_us']))
for model,ref in [('08','vllm_08_shipping_reference'),('4b','vllm_4b_shipping_reference'),('florence','mlx_florence_shipping_reference')]:
 names=['native_'+model+'_shipping_'+v+'_attempt1'for v in ['combined_off1','combined_on','combined_off2','default1','combined_repeat','default2']]if model!='florence'else['native_florence_shipping'];xs=[]
 for name in names:
  fs=list(p.glob(name.replace('attempt1','attempt*')+'/report.json'));valid=[(f,json.loads(f.read_text()))for f in fs if json.loads(f.read_text())['results'][0]['status']=='ok'];assert len(valid)==1,name;f,d=valid[0];x=d['results'][0];assert d['binary_sha256']==m['binary_sha256']and d['runtime_source_diff_sha256']==m['runtime_source_diff_sha256'];xs.append(dict(report=str(f.relative_to(p)),sha256=sha(f),pages_per_second=x['pages_per_second'],p50_ms=x['p50_ms'],p95_ms=x['p95_ms']))
 f=p/ref/'report.json';d=json.loads(f.read_text());s['readers'].append(dict(model=model,native=xs,reference_report=str(f.relative_to(p)),reference_sha256=sha(f),reference_pages_per_second=d['results'][0]['pages_per_second']))
(p/'shipping_summary.json').write_text(json.dumps(s,indent=2)+'\n');print('Final summary validated',len(s['primitive_sweeps']),len(s['attention']),len(s['prefill']),len(s['decode_improvements']),len(s['readers']))
