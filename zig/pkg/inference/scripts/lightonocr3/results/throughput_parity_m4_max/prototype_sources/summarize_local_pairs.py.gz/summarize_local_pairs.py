import json,statistics,hashlib
from pathlib import Path
p=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max');rows=[]
for cache in ['resident','cold64']:
 f=p/('previous_vs_local_'+cache+'.json');data=json.loads(f.read_text());cases=[]
 for x in data['results']:
  buckets={who:{'native_predecessor':[],'mlx_predecessor':[]} for who in ['native','production']};prev='production'
  for trial in range(len(x['samples_us']['native'])):
   order=['native','production','mlx'];k=trial%3;order=order[k:]+order[:k]
   if (trial//3)%2:order.reverse()
   for who in order:
    if who!='mlx':buckets[who]['mlx_predecessor' if prev=='mlx' else 'native_predecessor'].append(x['samples_us'][who][trial])
    prev=who
  per=[]
  for key in ['native_predecessor','mlx_predecessor']:
   old=buckets['native'][key];new=buckets['production'][key]
   per.append(dict(previous_participant_class=key,old_n=len(old),new_n=len(new),old_mean_us=statistics.mean(old),new_mean_us=statistics.mean(new),old_median_us=statistics.median(old),new_median_us=statistics.median(new),new_over_old_median=statistics.median(new)/statistics.median(old)))
  cases.append(dict(operation=x['operation'],rows=x['rows'],input_dim=x['in'],output_dim=x['out'],new_over_old_median=1/x['median_native_over_production'],new_over_old_mean=x['production']['mean_us']/x['native']['mean_us'],precedence_groups=per))
 rows.append(dict(report=f.name,report_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),cases=cases))
(p/'paired_precedence_summary.json').write_text(json.dumps(dict(scope='Old participant is native (variant previousproduction); current participant is production. Reconstructs the six rotated/reversed trial orders from samples. Preceding participant is a cache-context proxy, not a hardware cache-hit counter. Initial predecessor follows production warmup. Cold64 flushes before each participant.',policies=rows),indent=2)+'\n')
for d in rows:
 print(d['report'])
 for x in d['cases']:
  if x['operation']=='gate_up' and x['rows'] in [2,3,4] and x['input_dim']==1024:print(x['rows'],[round(y['new_over_old_median'],3) for y in x['precedence_groups']],round(x['new_over_old_mean'],3))
