from pathlib import Path
import json
p=Path('zig/pkg/inference/src/backends/metal_kernels.m');s=p.read_text()
s=s.replace('    id<MTLComputePipelineState> qwen35_recurrent_pipeline;','    id<MTLComputePipelineState> qwen35_recurrent_pipeline;\n    id<MTLComputePipelineState> qwen35_recurrent_columns4_pipeline;',1)
raw=Path('.venv-lighton-vllm-metal/recurrent_columns.metal').read_text();raw=raw[raw.index('template<uint C>'):raw.index('#define KERN(C)')].replace('body(', 'termite_qwen35_recurrent_columns_body(').replace('constant P&p','constant termite_qwen35_params&p')
raw+='kernel void termite_qwen35_recurrent_columns4(device float*s[[buffer(8)]],device const float*x[[buffer(9)]],device const float*g[[buffer(10)]],device float*y[[buffer(11)]],constant termite_qwen35_params&p[[buffer(15)]],uint gid[[thread_position_in_grid]],uint lane[[thread_index_in_simdgroup]]){termite_qwen35_recurrent_columns_body<4>(s,x,g,y,p,gid,lane);}\n'
needle='           "kernel void termite_qwen35_recurrent(device float'
pos=s.index(needle);s=s[:pos]+''.join('           '+json.dumps(line+'\n')+'\n' for line in raw.splitlines())+s[pos:]
needle='        runtime->qwen35_recurrent_pipeline = termite_metal_make_pipeline(device, precise_library, @"termite_qwen35_recurrent");'
s=s.replace(needle,needle+'\n        runtime->qwen35_recurrent_columns4_pipeline = termite_metal_make_pipeline(device, precise_library, @"termite_qwen35_recurrent_columns4");',1)
s=s.replace('    runtime->qwen35_recurrent_pipeline = nil;', '    runtime->qwen35_recurrent_pipeline = nil;\n    runtime->qwen35_recurrent_columns4_pipeline = nil;',1)
needle='        const bool parallel_norm = seq == 1 && termite_metal_qwen35_parallel_norm_available(runtime);'
assert s.count(needle)==1
s=s.replace(needle,'''        if (runtime->qwen35_ocr_vector_loads_enabled && seq >= 128 && seq <= 2048 &&
            dim == 128 && key_heads == 16 && (value_heads == 16 || value_heads == 32) && kernel == 4 &&
            !termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_QWEN35_PREFILL_COLUMNS")) &&
            runtime->qwen35_recurrent_columns4_pipeline != nil &&
            runtime->qwen35_recurrent_columns4_pipeline.threadExecutionWidth == 32 &&
            runtime->qwen35_recurrent_columns4_pipeline.maxTotalThreadsPerThreadgroup >= 128) {
            pipelines[3] = runtime->qwen35_recurrent_columns4_pipeline;
            grids[3] /= 4;
        }
'''+needle,1)
needle='static void termite_metal_dispatch_rms_norm_rows('
pos=s.index(needle)
helper='''// Wide prefill rows must not scan each hidden vector on one scalar lane.
// Reuse the existing F32 SIMD reduction with one group per row; no new scratch.
static uint32_t termite_metal_lightonocr3_prefill_norm_threads(
    termite_metal_decode_runtime *runtime, size_t rows, size_t hidden_size
) {
    if (runtime == NULL || rows > 32768 || runtime->rms_norm_rows_simd4_reduce_pipeline == nil ||
        runtime->rms_norm_rows_simd4_reduce_pipeline.threadExecutionWidth != 32 ||
        runtime->rms_norm_rows_simd4_reduce_pipeline.maxTotalThreadsPerThreadgroup < 32 ||
        termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PROJECTIONS")) ||
        termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PARALLEL_NORM")) ||
        termite_metal_env_flag_enabled(getenv("TERMITE_METAL_DISABLE_LIGHTONOCR3_PREFILL_NORM"))) return 0;
    if (runtime->lightonocr3_projections_enabled && rows >= 33 &&
        (hidden_size == 2560 || hidden_size == 256)) return 32;
    if (runtime->qwen35_ocr_vector_loads_enabled && rows >= 9 &&
        (hidden_size == 1024 || hidden_size == 128)) return 32;
    return 0;
}

'''
s=s[:pos]+helper+s[pos:]
needle='    const uint32_t embedding_threads = termite_metal_decode_runtime_embeddinggemma2_rms_norm_threads(runtime, rows, hidden_size);'
s=s.replace(needle,'''    const uint32_t prefill_threads = termite_metal_lightonocr3_prefill_norm_threads(runtime, rows, hidden_size);
    if (prefill_threads != 0) {
        [encoder setComputePipelineState:runtime->rms_norm_rows_simd4_reduce_pipeline];
        [encoder setThreadgroupMemoryLength:32u * sizeof(float) atIndex:0];
        [encoder dispatchThreadgroups:MTLSizeMake(rows, 1, 1) threadsPerThreadgroup:MTLSizeMake(prefill_threads, 1, 1)];
        return;
    }
'''+needle,1)
p.write_text(s)
