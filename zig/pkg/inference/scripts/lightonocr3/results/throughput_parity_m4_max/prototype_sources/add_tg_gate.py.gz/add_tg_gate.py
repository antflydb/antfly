from pathlib import Path
import json
kernel=r'''
template<uint S,uint N> inline void tg_gate_body(device float*x,device bfloat*gw,device bfloat*uw,device float*gb,device float*ub,device float*y,constant P&p,threadgroup float*tmp,uint group,uint sg,uint tid){
 uint chunk=p.in_dim/S;
 tensor<device float,dextents<int,2>,tensor_inline>a(x+sg*chunk,dextents<int,2>(chunk,p.rows),array<int,2>{1,int(p.in_dim)});
 tensor<device bfloat,dextents<int,2>,tensor_inline>gmat(gw+sg*chunk,dextents<int,2>(chunk,p.out_dim),array<int,2>{1,int(p.in_dim)}),umat(uw+sg*chunk,dextents<int,2>(chunk,p.out_dim),array<int,2>{1,int(p.in_dim)});
 tensor<threadgroup float,dextents<int,2>,tensor_inline>dest(tmp+sg*8*N,dextents<int,2>(N,p.rows),array<int,2>{1,int(N)}),destU(tmp+(S+sg)*8*N,dextents<int,2>(N,p.rows),array<int,2>{1,int(N)});
 auto left=a.slice(0,0);auto rightG=gmat.slice(0,int(group)*N);auto rightU=umat.slice(0,int(group)*N);
 constexpr auto desc=matmul2d_descriptor(8,N,dynamic_length_v<int>,false,true,false);matmul2d<desc,execution_simdgroups<1>>op;
 auto g=op.template get_destination_cooperative_tensor<decltype(left),decltype(rightG),float>();auto u=op.template get_destination_cooperative_tensor<decltype(left),decltype(rightU),float>();
 op.run(left,rightG,g);op.run(left,rightU,u);g.store(dest);u.store(destU);
 threadgroup_barrier(mem_flags::mem_threadgroup);
 for(uint i=tid;i<p.rows*N;i+=S*32){float gs=0,us=0;
  #pragma unroll
  for(uint j=0;j<S;j++){gs+=tmp[j*8*N+i];us+=tmp[(S+j)*8*N+i];}
  uint col=group*N+i%N;gs+=gb[col];us+=ub[col];y[(i/N)*p.out_dim+col]=(gs/(1.0f+exp(-gs)))*us;
 }
}
#define TG(S,N) kernel void tg_gate##S##_##N(device float*x[[buffer(0)]],device bfloat*g[[buffer(1)]],device bfloat*u[[buffer(2)]],device float*gb[[buffer(3)]],device float*ub[[buffer(4)]],device float*y[[buffer(5)]],constant P&p[[buffer(6)]],threadgroup float*tmp[[threadgroup(0)]],uint group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint tid[[thread_index_in_threadgroup]]){tg_gate_body<S,N>(x,g,u,gb,ub,y,p,tmp,group,sg,tid);}
TG(4,16) TG(2,16) TG(4,32)
'''
p=Path('zig/pkg/inference/scripts/lightonocr3/metal_pair_benchmark.m');s=p.read_text();i=s.index('static NSString *ocr_pair_stream_gate_source');source='static NSString *ocr_pair_tg_gate_source(void) {\n return [ocr_pair_split_source() stringByAppendingString:@""\n'+''.join(' '+json.dumps(line+'\n')+'\n' for line in kernel.splitlines())+'];\n}\n';s=s[:i]+source+s[i:];s=s.replace('static size_t pair_variant;','static id<MTLLibrary> pair_tg_library;\nstatic id<MTLComputePipelineState> pair_tg4, pair_tg2, pair_tg32;\nstatic size_t pair_variant;');s=s.replace('    case 30:\n', '    case 33:\n    case 34:\n    case 35:\n    case 30:\n');i=s.index('    if ((pair_variant == 22',s.index('static int ocr_pair_encode_candidate'));s=s[:i]+'''    if (pair_variant >= 33 && pair_variant <= 35) {
        if (!pair_tg_library) {
            MTLCompileOptions *opt = [MTLCompileOptions new];
            opt.languageVersion = MTLLanguageVersion4_0; opt.mathMode = MTLMathModeSafe;
            NSError *err=nil;
            pair_tg_library = [r->device newLibraryWithSource:ocr_pair_tg_gate_source() options:opt error:&err];
            if (!pair_tg_library) {fprintf(stderr,"TG gate: %s\\n",err.localizedDescription.UTF8String);return -1;}
            pair_tg4=termite_metal_make_pipeline(r->device,pair_tg_library,@"tg_gate4_16");
            pair_tg2=termite_metal_make_pipeline(r->device,pair_tg_library,@"tg_gate2_16");
            pair_tg32=termite_metal_make_pipeline(r->device,pair_tg_library,@"tg_gate4_32");
        }
        id<MTLComputePipelineState> pipe=pair_variant==33?pair_tg4:pair_variant==34?pair_tg2:pair_tg32;
        const size_t splits=pair_variant==34?2:4, columns=pair_variant==35?32:16;
        if (!pipe || pipe.maxTotalThreadsPerThreadgroup<splits*32) return -1;
        id<MTLComputeCommandEncoder> e=termite_metal_tracked_compute_command_encoder_for(r->active_frame_cb,TERMITE_METAL_COMPUTE_SOURCE_OTHER);
        if(!e)return -1;
        termite_metal_linear_params p={(uint32_t)c->rows,(uint32_t)c->in_dim,(uint32_t)c->out_dim,0};
        [e setComputePipelineState:pipe];
        [e setBuffer:c->input offset:0 atIndex:0];
        [e setBuffer:r->linear_weight_buffers[0] offset:0 atIndex:1];
        [e setBuffer:r->linear_weight_buffers[1] offset:0 atIndex:2];
        [e setBuffer:r->linear_bias_buffers[0] offset:0 atIndex:3];
        [e setBuffer:r->linear_bias_buffers[1] offset:0 atIndex:4];
        [e setBuffer:c->output offset:0 atIndex:5];
        [e setBytes:&p length:sizeof(p) atIndex:6];
        [e setThreadgroupMemoryLength:2*splits*8*columns*4 atIndex:0];
        [e dispatchThreadgroups:MTLSizeMake(c->out_dim/columns,1,1) threadsPerThreadgroup:MTLSizeMake(splits*32,1,1)];
        [e endEncoding];return 0;
    }
'''+s[i:];p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_metal_pair.py');s=p.read_text().replace('"splitprojections2",','"splitprojections2",\n"tggate4",\n"tggate2",\n"tggate32",');s=s.replace('                "splitgate2":','                "tggate4": kind == 3 and 2 <= rows <= 8,\n                "tggate2": kind == 3 and 2 <= rows <= 8,\n                "tggate32": kind == 3 and 2 <= rows <= 8,\n                "splitgate2":');p.write_text(s)
