from pathlib import Path
import json,statistics
p=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max')
names=['decodevec16x2','decodevec32x4','decodetiled','decodetg','decodesplit4n32','decodesplit8n32','decodesplit4n16','decodesplit8n16','decodeunroll4n32','decodeunroll8n32','decodeunroll8n1','decodeunroll16n1','decodeunroll32n1','decodeunroll16n4','decodestream8u4','decodestream16u4','decodestream32u4','decodestream8u8','decodestream16u8','decodestream32u8','decodechunk4s16t2','decodechunk4s16t4','decodechunk4s32t4','decodechunk4s32t8','decodechunk2s16t4','decodechunk2s32t8']
data={}
for name in names:
 for cache in ['resident','cold64']:
  f=p/(name+'_'+cache+'.json')
  if f.exists():
   for x in json.loads(f.read_text())['results']:
    k=(x['in'],x['out'],x['rows']);data.setdefault(k,{}).setdefault(name,{})[cache]=x
summary=[]
for k,variants in sorted(data.items()):
 ranked=[]
 for v,c in variants.items():
  if len(c)!=2:continue
  gain=max(x['median_native_over_production']for x in c.values());mlx=max(x['median_native_over_mlx']for x in c.values());ranked.append((gain,v,mlx))
 if ranked:
  ranked.sort();g,v,m=ranked[0];summary.append(dict(input=k[0],output=k[1],rows=k[2],variant=v,worst_new_over_old=g,worst_new_over_mlx=m));print(k,v,round(g,3),round(m,3))
print('qualified pairs',len(summary),'within20%',sum(x['worst_new_over_mlx']<=1.2 for x in summary),'median gain',statistics.median(x['worst_new_over_old']for x in summary))
(p/'missing_decode_candidate_selection.json').write_text(json.dumps(dict(scope='Exploratory cross-run selection; maximum median ratio across both cache policies, sorted by improvement over each run own production control. Requires final integrated requalification.',results=summary),indent=2)+'\n')
