import sys,subprocess
from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3';out=p/'results/throughput_parity_m4_max'
for label,variant,flush,comp,compare in [('final_all_rows_resident','production',0,True,False),('final_all_rows_cold64','production',64,False,False),('previous_vs_local_resident','previousproduction',0,False,True),('previous_vs_local_cold64','previousproduction',64,False,True)]:
 print('START',label,flush=True)
 cmd=[sys.executable,str(p/'benchmark_metal_pair.py'),'--native-library',str(r/'.venv-lighton-vllm-metal/metal_pair_local_final.dylib'),'--timing-library',str(r/'.venv-lighton-vllm-metal/metal_timing_qualified.dylib'),'--suite','all-rows','--trials','30','--variant',variant,'--cache-flush-mib',str(flush),'--output',str(out/(label+'.json'))]
 if comp:cmd+=['--compile-native-library']
 if compare:cmd+=['--compare-production']
 with open('/private/tmp/ocr-parity-'+label+'.txt','w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DONE',label,flush=True)
