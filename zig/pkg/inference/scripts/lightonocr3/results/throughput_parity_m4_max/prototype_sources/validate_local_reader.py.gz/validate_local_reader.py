import os,sys,re,json,subprocess,time
from pathlib import Path
r=Path.cwd();h=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max';log=Path('/private/tmp/ocr-parity-local-build.txt')
while True:
 text=log.read_text()
 hits=re.findall(r'\.zig-cache/o/([0-9a-f]{32})/test(?:\s|$)',text)
 if hits:break
 if 'error:' in text:raise SystemExit(text[-5000:])
 time.sleep(5)
subprocess.run([sys.executable,str(h/'save_local_manifest.py')],check=True)
binary=r/'zig/.zig-cache/o'/hits[-1]/'test'
s=(h/'refill_shared_peak_gpu_tests.py').read_text().replace('866f7e0d65c8428f2c3b9e7e56ba01ba',hits[-1]).replace('ocr-shared-peak-gpu-tests','ocr-parity-local-gpu-tests');gpu=h/'local_gpu_tests.py';gpu.write_text(s)
print('START GPU tests',binary,flush=True);subprocess.run([sys.executable,str(gpu)],check=True);print('DONE GPU tests',flush=True)
env=os.environ.copy();env['OCR_BUILD_MANIFEST']=str(p/'local_build_manifest.json')
for model in ['08','4b','florence']:
 subprocess.run([sys.executable,str(h/'refresh_local_references.py'),model],check=True)
 for variant in (['off1','on','off2','profile'] if model!='florence' else ['default']):
  for attempt in range(1,4):
   name=model+'_local_'+variant+'_attempt'+str(attempt) if model!='florence' else 'florence_local'
   if variant=='profile':env['TERMITE_METAL_TRACE_DENSE_LINEAR_SHAPES']='1'
   else:env.pop('TERMITE_METAL_TRACE_DENSE_LINEAR_SHAPES',None)
   subprocess.run([sys.executable,str(h/'run_local_round.py'),str(binary),name],env=env,check=True)
   f=p/('native_'+name)/'report.json';v=json.loads(f.read_text())['results'][0];print('RESULT',name,v.get('status'),v.get('pages_per_second'),flush=True)
   if v['status']=='ok':break
   raw=(f.parent/v['log']).read_text()
   if 'ResourceTemporarilyUnavailable' not in raw or 'OCR_REFERENCE' in raw or attempt==3:raise SystemExit('Reader validation failed: '+name)
   time.sleep(5)
