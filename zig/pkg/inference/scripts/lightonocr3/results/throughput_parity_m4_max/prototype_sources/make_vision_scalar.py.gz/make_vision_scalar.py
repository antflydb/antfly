from pathlib import Path
import re,json
h=Path('.venv-lighton-vllm-metal');s=Path('zig/pkg/inference/src/backends/metal_kernels.m').read_text();a=s.index('           "kernel void termite_sdpa_f32_vision_hd64_flash_q32(');b=s.index('           // Full F32 variant',a);old=''.join(json.loads('"'+x+'"') for x in re.findall(r'"((?:[^"\\]|\\.)*)"',s[a:b]));kernels=[]
for name,src,qp in [('q32',old,2),('q64',(h/'vision_q64.metal').read_text(),4),('q64k64',(h/'vision_q64k64.metal').read_text(),4)]:
 src=src.replace('flash_'+name+'(', 'flash_'+name+'_scalar(')
 src=re.sub(r'if \(tid < 256u\) sdiag\[tid\] = 0.0f;|for\(uint i=uint\(tid\);i<512u;i\+=256u\)sdiag\[i\]=0.0f;', 'if(tid<64u)sdiag[tid]=float(tid/8u);',src)
 i=src.index('    simdgroup_float8x8 mo');src=src[:i]+'''    simdgroup_float8x8 row_ids;simdgroup_load(row_ids,sdiag,8u);
    const uint fragment_row0=uint(row_ids.thread_elements()[0]),fragment_row1=uint(row_ids.thread_elements()[1]);
    threadgroup_barrier(mem_flags::mem_threadgroup);
'''+src[i:]
 lines=src.splitlines();count=0
 for i,line in enumerate(lines):
  if 'simdgroup_float8x8 mcorr;' in line or 'simdgroup_float8x8 minv;' in line:
   lines[i]=f'''        for(uint qp=0;qp<{qp};qp++){{uint qgroup=qgroup_base+qp*2;float a=sdiag[qgroup*64+fragment_row0*9],b=sdiag[qgroup*64+fragment_row1*9];for(uint dt=0;dt<2;dt++){{mo[qp][dt].thread_elements()[0]*=a;mo[qp][dt].thread_elements()[1]*=b;}}}}''';count+=1
 assert count==2,(name,count)
 src='\n'.join(lines)+'\n';(h/('vision_'+name+'_scalar.metal')).write_text(src);kernels.append(src)
p=h/'vision_attention_q64k64_benchmark.m';c=p.read_text();a=c.index('static NSString *vision_candidate_source');b=c.index('void *vision_create',a);base=(h/'vision_q64.metal').read_text()+(h/'vision_q64k64.metal').read_text()+''.join(kernels);lit='static NSString *vision_candidate_source(void) {return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n' for x in base.splitlines())+';}\n';c=c[:a]+lit+c[b:];c=c.replace('static id<MTLComputePipelineState> vp,vp64;','static id<MTLComputePipelineState> vp,vp64,vs[3];');i=c.index(' vp64=termite_metal_make_pipeline');c=c[:i]+''' const char*names[]={"q32","q64","q64k64"};
 for(size_t j=0;j<3;j++){
 vs[j]=termite_metal_make_pipeline(vr->device,lib,[NSString stringWithFormat:@"termite_sdpa_f32_vision_hd64_flash_%s_scalar",names[j]]);
 if(!vs[j]||vs[j].maxTotalThreadsPerThreadgroup<256||vs[j].staticThreadgroupMemoryLength>vr->device.maxThreadgroupMemoryLength)return NULL;
 fprintf(stderr,"vision_scalar %s threads=%zu static_bytes=%zu\\n",names[j],(size_t)vs[j].maxTotalThreadsPerThreadgroup,(size_t)vs[j].staticThreadgroupMemoryLength);
 }
'''+c[i:];c=c.replace('[e setComputePipelineState:candidate==2?vp64:vp];','[e setComputePipelineState:vs[candidate-1]];');c=c.replace('c->heads*((c->seq+63)/64)','c->heads*((c->seq+(candidate==1?31:63))/(candidate==1?32:64))');(h/'vision_attention_scalar_benchmark.m').write_text(c)
