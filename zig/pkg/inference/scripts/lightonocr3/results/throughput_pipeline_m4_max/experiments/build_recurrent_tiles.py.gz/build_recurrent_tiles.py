from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();p=root/'.venv-lighton-vllm-metal/recurrent-tiles';p.mkdir(exist_ok=True)
runtime=(root/'zig/pkg/inference/src/backends/metal_kernels.m').read_text();harness=(root/'zig/pkg/inference/scripts/lightonocr3/check_metal_projections.m').read_text()
for tile in [16,32]:
 s=runtime;assert s.count('const uint TM = 8, SG = 128 / TM;')==1;s=s.replace('const uint TM = 8, SG = 128 / TM;',f'const uint TM = {tile}, SG = 128 / TM;')
 a=s.index('static int termite_metal_lightonocr3_encode_recurrent_parallel(');b=s.index('int termite_metal_decode_runtime_qwen35_core_batch_end(',a);part=s[a:b].replace('< 512','< '+str(4096//tile)).replace('MTLSizeMake(512, 1, 1)','MTLSizeMake('+str(4096//tile)+', 1, 1)').replace('threads=512','threads='+str(4096//tile));s=s[:a]+part+s[b:]
 src=p/f'metal_kernels_tile{tile}.m';src.write_text(s);check=p/f'check_tile{tile}.m';check.write_text(harness.replace('../../src/backends/metal_kernels.m',str(src)));binary=p/f'check_tile{tile}'
 with (p/f'compile_tile{tile}.txt').open('w')as out:r=subprocess.run(['clang','-O2','-fobjc-arc','-I',str(root/'zig/pkg/inference/src/backends'),'-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders','-framework','Accelerate',str(check),'-o',str(binary)],stdout=out,stderr=subprocess.STDOUT)
 print(tile,r.returncode,flush=True);assert r.returncode==0
