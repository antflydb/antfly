from pathlib import Path
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text();s=s.replace('    vision_slot_reuse: bool = true,','    vision_slot_reuse: bool = true,\n    native_patch: bool = false,',1).replace('            .vision_slot_reuse = !platform.env.getenvBool("TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_SLOT_REUSE"),','            .vision_slot_reuse = !platform.env.getenvBool("TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_SLOT_REUSE"),\n            .native_patch = platform.env.getenvBool("TERMITE_METAL_ENABLE_LIGHTONOCR3_NATIVE_PATCH"),',1)
s=s.replace('    lightonocr3_packed_core_reported_rows: u16 = 0,','    lightonocr3_packed_core_reported_rows: u16 = 0,\n    lightonocr3_native_patch_reported: bool = false,',1)
needle='    pub fn lightOnDirectCoreOutputEnabled('
a=s.index(needle);s=s[:a]+'''    pub fn lightOnNativePatchEnabled(cb: *const ops.ComputeBackend) bool {
        if (cb.kind() != .metal) return false;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        if (!self.lightonocr3_projections or !self.lightonocr3_policy.native_patch or
            !metal_runtime_mod.qualifiedM4DeviceDefault()) return false;
        if (!self.lightonocr3_native_patch_reported and platform.env.getenvBool("TERMITE_METAL_TRACE_LIGHTONOCR3_NATIVE_PATCH")) {
            self.lightonocr3_native_patch_reported = true;
            std.debug.print("lightonocr3_native_patch: original_bf16=1 activations=f32 temporal=2\\n", .{});
        }
        return true;
    }

'''+s[a:]
s=s.replace('''        _ = self;
        const position_table =''','''        const native_patch = self.lightonocr3_projections and self.lightonocr3_policy.native_patch and
            std.mem.endsWith(u8, name, "model.visual.patch_embed.proj.weight") and tensor.shape.len == 5 and
            (tensor.shape[0] == 768 or tensor.shape[0] == 1024) and tensor.shape[1] == 3 and
            tensor.shape[2] == 2 and tensor.shape[3] == 16 and tensor.shape[4] == 16;
        const position_table =''',1).replace('(tensor.shape.len == 2 or position_table);','(tensor.shape.len == 2 or position_table or native_patch);',1);p.write_text(s)
p=Path('zig/pkg/inference/src/architectures/qwen3vl_projector.zig');s=p.read_text().replace('    const normalized_and_patches = try admissionMul(try admissionF32Bytes(max_resized_pixels, 3), 2);','''    // Native Conv3D may keep the normalized image, spatial patches and a
    // doubled C,T,H,W patch matrix live together. Reserve that host peak even
    // when this request uses the split temporal fallback.
    const normalized_and_patches = try admissionMul(try admissionF32Bytes(max_resized_pixels, 3), if (config.family == .qwen3_5) 4 else 2);''')
a=s.index('    const full_resident_patch = if (comptime build_options.enable_cuda)');b=s.index('    const embedded =',a)
s=s[:a]+'''    const cuda_native_patch = if (comptime build_options.enable_cuda) cb.kind() == .cuda else false;
    const metal_native_patch = if (comptime build_options.enable_metal) metal_compute_mod.MetalCompute.lightOnNativePatchEnabled(cb) else false;
    const full_resident_patch = if (cuda_native_patch or metal_native_patch)
        (weights.fullResidentPatch() catch |zig017_err| {
            zig017_return_error = zig017_err;
            return zig017_err;
        })
    else
        null;
'''+s[b:];p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text().replace('            "ANTFLY_LIGHTONOCR3_READY_COHORTS",','            "ANTFLY_LIGHTONOCR3_READY_COHORTS",\n            "TERMITE_METAL_ENABLE_LIGHTONOCR3_NATIVE_PATCH",',1).replace('or std.mem.eql(u8, policy, "ready");','or std.mem.eql(u8, policy, "ready") or std.mem.eql(u8, policy, "nativepatch");',1)
needle='                if (Env.setenv(policy_flags[20],';a=s.index(needle);b=s.index('\n',a);s=s[:b]+'''\n                if (Env.setenv(policy_flags[21], if (std.mem.eql(u8, policy, "nativepatch")) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;'''+s[b:];p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text().replace('            "ready",','            "ready",\n            "nativepatch",',1).replace('            "TERMITE_METAL_TRACE_LIGHTONOCR3_PACKED_CORE",','            "TERMITE_METAL_TRACE_LIGHTONOCR3_PACKED_CORE",\n            "TERMITE_METAL_ENABLE_LIGHTONOCR3_NATIVE_PATCH",\n            "TERMITE_METAL_TRACE_LIGHTONOCR3_NATIVE_PATCH",',1)
s=s.replace('    if args.disable_packed_core:','    if args.native_patch:\n        env["TERMITE_METAL_ENABLE_LIGHTONOCR3_NATIVE_PATCH"] = "1"\n    if args.require_native_patch:\n        env["TERMITE_METAL_TRACE_LIGHTONOCR3_NATIVE_PATCH"] = "1"\n    if args.disable_packed_core:',1).replace('    parser.add_argument("--require-packed-core", action="store_true")','    parser.add_argument("--require-packed-core", action="store_true")\n    parser.add_argument("--native-patch", action="store_true")\n    parser.add_argument("--require-native-patch", action="store_true")',1)
needle='        if args.require_packed_core:';a=s.index(needle);s=s[:a]+'''        if args.require_native_patch:
            result["native_patch_observed_including_warmup"] = "lightonocr3_native_patch: original_bf16=1 activations=f32 temporal=2" in text
            if not result["native_patch_observed_including_warmup"]:
                result["status"] = "missing_native_patch"
'''+s[a:];p.write_text(s)
