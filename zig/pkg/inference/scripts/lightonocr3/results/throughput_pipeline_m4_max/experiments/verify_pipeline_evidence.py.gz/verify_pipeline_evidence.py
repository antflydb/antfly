from pathlib import Path
import hashlib,gzip,json,subprocess,tempfile
root=Path.cwd();p=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_pipeline_m4_max';sha=lambda b:hashlib.sha256(b).hexdigest();checked=[]
for f in sorted(p.glob('*_build_manifest.json')):
 d=json.loads(f.read_text());stage=f.name.removesuffix('_build_manifest.json');patch=p/(stage+'_runtime.patch.gz')
 if not patch.exists():continue
 raw=gzip.decompress(patch.read_bytes());assert sha(raw)==d['runtime_source_diff_sha256'],str(f)
 with tempfile.TemporaryDirectory(prefix='ocr-source-proof-',dir='/private/tmp')as t:
  t=Path(t)
  for name in d['runtime_files_sha256']:
   out=t/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(subprocess.check_output(['git','show',d['runtime_commit']+':'+name],cwd=root))
  r=subprocess.run(['git','apply','--unsafe-paths','-'],input=raw,cwd=t,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert r.returncode==0,r.stderr.decode()
  for name,h in d['runtime_files_sha256'].items():assert sha((t/name).read_bytes())==h,(stage,name)
 binary=Path(d['binary_path'])
 if binary.exists():assert sha(binary.read_bytes())==d['binary_sha256'],str(binary)
 checked.append(stage)
print('source patches and binary identities verified:',', '.join(checked))
for f in p.rglob('*.gz'):gzip.decompress(f.read_bytes())
for f in p.rglob('*.json'):json.loads(f.read_text())
for f in p.glob('native*/report.json'):
 d=json.loads(f.read_text())
 for r in d.get('results',[]):
  assert (f.parent/r['log']).exists(),(f,r.get('log'))
  if r['status']=='ok':assert r.get('serial_reference_parity') and r.get('cross_runtime_content_parity'),f
print('JSON, compressed payloads, report logs and successful output parity verified')
for model in ['08','4b']:
 canonical=json.loads((p/f'vllm_{model}_reference/report.json').read_text());expected={x['image_index']:x['text']for x in canonical['references']}
 for f in p.glob('native*_'+model+'*/report.json'):
  for r in json.loads(f.read_text())['results']:
   if r['status']=='ok':assert {x['image_index']:x['text']for x in r['references']}==expected,f
 after=p/f'vllm_{model}_after_reference/report.json'
 if after.exists():assert {x['image_index']:x['text']for x in json.loads(after.read_text())['references']}==expected,after
print('exact LightOn output identity across recorded native and vLLM stages verified')
