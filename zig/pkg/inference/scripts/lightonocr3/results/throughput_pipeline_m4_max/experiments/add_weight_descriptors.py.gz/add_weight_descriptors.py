from pathlib import Path
p=Path('zig/pkg/inference/src/ops/metal_compute.zig');s=p.read_text();s=s.replace('    vision_slot_reuse: bool = true,','    vision_slot_reuse: bool = true,\n    retain_weight_handles: bool = true,',1).replace('            .vision_slot_reuse = !platform.env.getenvBool("TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_SLOT_REUSE"),','            .vision_slot_reuse = !platform.env.getenvBool("TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_SLOT_REUSE"),\n            .retain_weight_handles = !platform.env.getenvBool("TERMITE_METAL_DISABLE_LIGHTONOCR3_WEIGHT_HANDLES"),',1)
s=s.replace('        weight_handle_refs: usize = 0,','        weight_handle_refs: usize = 0,\n        weight_handle_compute_owned: bool = false,',1)
a='''            buf.weight_handle_refs -= 1;
            if (buf.weight_handle_refs != 0) return;''';b='''            buf.weight_handle_refs -= 1;
            if (buf.weight_handle_refs != 0) {
                // Retain only the descriptor and its already cached source.
                // A host mirror must not survive its last actual consumer.
                if (buf.weight_handle_compute_owned and buf.weight_handle_refs == 1) {
                    if (buf.native_dense_host_cache) |cache| {
                        buf.native_dense_host_cache = null;
                        freeOp(ctx, cache);
                    }
                }
                return;
            }''';assert a in s;s=s.replace(a,b,1)
a='''        toBuf(tensor).weight_handle_name = owned_name;
        toBuf(tensor).weight_handle_refs = 1;''';b='''        const buf = toBuf(tensor);
        // Layer projections reuse their immutable provider-cache backing. One
        // additional owner keeps the small wrapper stable until this compute
        // epoch drains. Borrowed/pinned, mutable and unshared handles retain
        // their existing lifetimes; no additional weight bytes are retained.
        const decoder_layer = std.mem.indexOf(u8, full_name, "model.layers.") != null or
            std.mem.indexOf(u8, full_name, "model.language_model.layers.") != null;
        const retain = self.lightonocr3_projections and self.lightonocr3_policy.retain_weight_handles and
            decoder_layer and !buf.owned and !buf.owns_lazy_pin and !buf.mutable_state and
            buf.metal_tensor == null and self.dense_weight_cache.contains(full_name);
        buf.weight_handle_name = owned_name;
        buf.weight_handle_compute_owned = retain;
        buf.weight_handle_refs = if (retain) 2 else 1;''';assert a in s;s=s.replace(a,b,1)
# Extend the per-epoch flag regression test.
a=s.index('test "LightOnOCR3 runtime policy snapshots');part=s[a:];part=part.replace('        "TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_SLOT_REUSE",','        "TERMITE_METAL_DISABLE_LIGHTONOCR3_VISION_SLOT_REUSE",\n        "TERMITE_METAL_DISABLE_LIGHTONOCR3_WEIGHT_HANDLES",',1).replace('var saved: [3]?[:0]u8','var saved: [names.len]?[:0]u8',1).replace('!disabled.vision_slot_reuse);','!disabled.vision_slot_reuse and !disabled.retain_weight_handles);',1).replace('enabled.vision_slot_reuse);','enabled.vision_slot_reuse and enabled.retain_weight_handles);',1);s=s[:a]+part;p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text().replace('            "ANTFLY_LIGHTONOCR3_READY_COHORTS",','            "ANTFLY_LIGHTONOCR3_READY_COHORTS",\n            "TERMITE_METAL_DISABLE_LIGHTONOCR3_WEIGHT_HANDLES",',1).replace('or std.mem.eql(u8, policy, "ready");','or std.mem.eql(u8, policy, "ready") or std.mem.eql(u8, policy, "handlesoff");',1)
needle='                if (Env.setenv(policy_flags[20],';a=s.index(needle);b=s.index('\n',a);s=s[:b]+'''\n                if (Env.setenv(policy_flags[21], if (std.mem.eql(u8, policy, "pipelineoff") or std.mem.eql(u8, policy, "handlesoff")) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;'''+s[b:];p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text().replace('            "ready",','            "ready",\n            "handlesoff",',1);p.write_text(s)
