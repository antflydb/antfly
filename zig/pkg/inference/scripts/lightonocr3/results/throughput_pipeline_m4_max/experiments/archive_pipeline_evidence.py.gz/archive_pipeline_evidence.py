from pathlib import Path
import gzip,json,hashlib
root=Path.cwd();p=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_pipeline_m4_max';logs=p/'logs';logs.mkdir(exist_ok=True);helpers=p/'experiments';helpers.mkdir(exist_ok=True)
external={
 'pipeline_build':'/private/tmp/ocr-pipeline-build.txt',
 'packed_build':'/private/tmp/ocr-packed-build.txt',
 'vision_build':'/private/tmp/ocr-vision-build.txt',
 'optimized_build':'/private/tmp/ocr-optimized-build.txt',
 'nativepatch_build':'/private/tmp/ocr-nativepatch-build.txt',
 'descriptor_allocation_failure_build':'/private/tmp/ocr-descriptors-build.txt',
 'pipeline_gpu_tests':'/private/tmp/ocr-pipeline-local-gpu-tests.txt',
 'packed_gpu_tests':'/private/tmp/ocr-packed-local-gpu-tests.txt',
 'vision_gpu_tests':'/private/tmp/ocr-vision-local-gpu-tests.txt',
 'optimized_gpu_tests':'/private/tmp/ocr-optimized-local-gpu-tests.txt',
 'nativepatch_gpu_tests_rejected':'/private/tmp/ocr-nativepatch-local-gpu-tests.txt',
 'license_check':'/private/tmp/ocr-pipeline-license.txt',
 'final_license_check':'/private/tmp/ocr-pipeline-final-license.txt',
 'descriptors_fixed_build':'/private/tmp/ocr-descriptors-fixed-build.txt',
 'shipping_build':'/private/tmp/ocr-shipping-build.txt',
 'descriptors_gpu_tests':'/private/tmp/ocr-descriptors-local-gpu-tests.txt',
 'shipping_gpu_tests':'/private/tmp/ocr-shipping-local-gpu-tests.txt',
}
for label,source in external.items():
 f=Path(source)
 if f.exists():(logs/(label+'.txt.gz')).write_bytes(gzip.compress(f.read_bytes(),mtime=0))
for name in ['run_pipeline_matrix.py','run_pipeline_florence.py','run_pipeline_conformance.py','run_recurrent_tiles.py','build_recurrent_tiles.py','finalize_ocr_build.py','refresh_pipeline_references.py','pipeline_gpu_tests.py','packed_gpu_tests.py','vision_gpu_tests.py','optimized_gpu_tests.py','nativepatch_gpu_tests.py','add_native_patch.py','add_weight_descriptors.py','shipping_gpu_tests.py','descriptors_gpu_tests.py','verify_pipeline_evidence.py','refresh_pipeline_after_references.py']:
 f=root/'.venv-lighton-vllm-metal'/name
 if f.exists():(helpers/(name+'.gz')).write_bytes(gzip.compress(f.read_bytes(),mtime=0))
# Every payload is byte-for-byte recoverable; report paths follow compression.
for f in list(p.rglob('*.txt'))+list(p.rglob('*.log'))+list(p.rglob('*.jsonl')):
 raw=f.read_bytes();dest=f.with_name(f.name+'.gz');dest.write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress(dest.read_bytes())==raw;f.unlink()
for report in p.glob('native*/report.json'):
 d=json.loads(report.read_text())
 for r in d.get('results',[]):
  if isinstance(r.get('log'),str) and (report.parent/(r['log']+'.gz')).exists():r['log']+='.gz'
 report.write_text(json.dumps(d,indent=2)+'\n')
f=p/'recurrent_tiles/summary.json'
if f.exists():
 d=json.loads(f.read_text())
 for r in d['raw_files']:
  if (f.parent/(r['file']+'.gz')).exists():r['file']+='.gz'
 f.write_text(json.dumps(d,indent=2)+'\n')
