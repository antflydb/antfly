from pathlib import Path
import json,hashlib,re,subprocess,gzip,sys
root=Path.cwd();name=sys.argv[1];log=Path(sys.argv[2] if len(sys.argv)>2 else '/private/tmp/ocr-'+name+'-build.txt').read_text();assert 'error:'not in log,log[-4000:]
freeze=json.loads((root/'.venv-lighton-vllm-metal'/f'{name}-freeze.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
for f,h in freeze.items():assert sha((root/f).read_bytes())==h,f
ids=re.findall(r'\.zig-cache/o/([0-9a-f]{32})/test(?:\s|$)',log);assert ids
binary=(root/'zig/.zig-cache/o'/ids[-1]/'test');assert binary.exists()
p=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_pipeline_m4_max';patch=subprocess.check_output(['git','diff','--',*freeze]);(p/f'{name}_runtime.patch.gz').write_bytes(gzip.compress(patch,mtime=0))
d=dict(runtime_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),runtime_source_diff_sha256=sha(patch),runtime_files_sha256=freeze,binary_sha256=sha(binary.read_bytes()),binary_path=str(binary));(p/f'{name}_build_manifest.json').write_text(json.dumps(d,indent=2)+'\n');print(binary)
