import subprocess,pathlib,json,hashlib,sys
root=pathlib.Path.cwd();p=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_pipeline_m4_max'
rows=[]
for label,binary,source in [('projection','check-pipeline','check_metal_projections.m'),('attention','check-pipeline-prefill_attention','check_metal_prefill_attention.m'),('vision','check-pipeline-vision','check_metal_vision.m')]:
 binary=root/'.venv-lighton-vllm-metal/bin'/binary
 with (p/(label+'_conformance.jsonl')).open('w')as out,(p/(label+'_conformance.txt')).open('w')as err:
  r=subprocess.run([str(binary)],cwd=root,stdout=out,stderr=err)
 rows.append(dict(test=label,exit_code=r.returncode,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),harness_source_sha256=hashlib.sha256((root/'zig/pkg/inference/scripts/lightonocr3'/source).read_bytes()).hexdigest(),runtime_source_sha256=hashlib.sha256((root/'zig/pkg/inference/src/backends/metal_kernels.m').read_bytes()).hexdigest()))
 print(label,r.returncode,flush=True)
 if r.returncode:break
(p/'conformance_manifest.json').write_text(json.dumps(rows,indent=2)+'\n');sys.exit(r.returncode)
