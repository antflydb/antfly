from pathlib import Path
import subprocess,json,hashlib,sys,gzip
root=Path.cwd();p=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_pipeline_m4_max/recurrent_tiles';p.mkdir(exist_ok=True)
meta=[]
for tile in [16,32]:
 folder=root/'.venv-lighton-vllm-metal/recurrent-tiles';binary=folder/f'check_tile{tile}';source=folder/f'metal_kernels_tile{tile}.m';harness=folder/f'check_tile{tile}.m'
 with (p/f'conformance_tile{tile}.jsonl').open('w')as out,(p/f'conformance_tile{tile}.txt').open('w')as err:r=subprocess.run([str(binary)],cwd=root,stdout=out,stderr=err)
 print('conformance',tile,r.returncode,flush=True);meta.append(dict(tile=tile,exit_code=r.returncode,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),runtime_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),harness_source_sha256=hashlib.sha256(harness.read_bytes()).hexdigest()))
 (p/f'runtime_tile{tile}.m.gz').write_bytes(gzip.compress(source.read_bytes(),mtime=0));(p/f'harness_tile{tile}.m.gz').write_bytes(gzip.compress(harness.read_bytes(),mtime=0))
 if r.returncode:break
(p/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
if r.returncode:sys.exit(r.returncode)
for i,tile in enumerate([8,16,32,32,16,8]):
 binary=root/'.venv-lighton-vllm-metal/bin/check-pipeline' if tile==8 else root/'.venv-lighton-vllm-metal/recurrent-tiles'/f'check_tile{tile}'
 with (p/f'round{i}_tile{tile}.jsonl').open('w')as out,(p/f'round{i}_tile{tile}.txt').open('w')as err:r=subprocess.run([str(binary),'--benchmark-recurrent'],cwd=root,stdout=out,stderr=err)
 print('benchmark',i,tile,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
