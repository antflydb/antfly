#include "../zig/pkg/inference/src/backends/metal_kernels.m"
static NSString*float_source(void){return @""
 "#define QT 16\n"
 "#define KT 64\n"
 "#include <metal_stdlib>\n"
 "#include <metal_tensor>\n"
 "#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>\n"
 "using namespace metal;using namespace mpp::tensor_ops;\n"
 "struct Params {uint q_len,kv_tokens,num_heads,num_kv_heads,head_dim,key_row_bytes,base_key_row_bytes,query_position_offset,kv_position_offset,sliding_window,v_row_stride,page_size,block_count,contiguous_base_token,contiguous_blocks,format,v_element_bytes,has_sinks;float softcap;uint swa_scan_clamp;};\n"
 "kernel void prefill_direct64_16(device float*q[[buffer(0)]],device half*k[[buffer(1)]],device half*v[[buffer(2)]],device const uint*blocks[[buffer(3)]],device const float*sinks[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]],uint tid[[thread_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]]){\n"
 " const uint q0=group.x*QT,h=group.y,kh=h/(p.num_heads/p.num_kv_heads),kw=p.key_row_bytes/2;\n"
 " threadgroup float scores[QT*KT],prob[QT*KT],maxima[QT],denom[QT],correction[QT];threadgroup atomic_uint nonfinite_v;\n"
 " if(tid<QT){maxima[tid]=-INFINITY;denom[tid]=0;}\n"
 " tensor<device float,dextents<int,2>,tensor_inline>qa(q+h*256,dextents<int,2>(256,p.q_len),array<int,2>{1,int(p.num_heads*256)});auto Q=qa.slice(0,int(q0));\n"
 " tensor<threadgroup float,dextents<int,2>,tensor_inline>S(scores+sg*16,dextents<int,2>(16,QT),array<int,2>{1,KT});\n"
 " tensor<threadgroup float,dextents<int,2>,tensor_inline>Pbase(prob,dextents<int,2>(16,QT),array<int,2>{1,KT});\n"
 " tensor<device half,dextents<int,2>,tensor_inline>Vbase(v+kh*256+sg*64,dextents<int,2>(64,16),array<int,2>{1,int(p.v_row_stride)});\n"
 " constexpr auto qkd=matmul2d_descriptor(QT,16,256,false,true,false);\n"
 " constexpr auto pvd=matmul2d_descriptor(QT,64,16,false,false,false,matmul2d_descriptor::mode::multiply_accumulate);\n"
 " matmul2d<qkd,execution_simdgroups<1>>qkop;matmul2d<pvd,execution_simdgroups<1>>pvop;\n"
 " auto out=pvop.get_destination_cooperative_tensor<decltype(Pbase),decltype(Vbase),float>();for(ushort i=0;i<out.get_capacity();i++)out[i]=0;\n"
 " uint end=min(p.kv_tokens,p.query_position_offset+min(q0+QT,p.q_len)-p.kv_position_offset);\n"
 " for(uint start=0;start<end;start+=KT){\n"
 "  threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "  uint key=start+sg*16,count=key<p.kv_tokens?min(16u,p.kv_tokens-key):0;\n"
 "  if(count){\n"
 "   uint physical=blocks[key/p.page_size]+key%p.page_size;\n"
 "   tensor<device half,dextents<int,2>,tensor_inline>K(k+physical*kw+kh*256,dextents<int,2>(256,count),array<int,2>{1,int(kw)});\n"
 "   auto dots=qkop.get_destination_cooperative_tensor<decltype(Q),decltype(K),float>();qkop.run(Q,K,dots);dots.store(S);\n"
 "  }else for(uint i=lane;i<QT*16;i+=32)scores[(i/16)*KT+sg*16+i%16]=0;\n"
 "  threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "  for(uint pass=0;pass<QT/4;pass++){\n"
 "   uint row=sg+pass*4;float x[2],m=-INFINITY;\n"
 "   for(uint j=0;j<2;j++){uint t=start+lane+j*32;bool valid=q0+row<p.q_len&&t<p.kv_tokens&&t+p.kv_position_offset<=p.query_position_offset+q0+row;x[j]=valid?scores[row*KT+lane+j*32]*.0625f:-INFINITY;if(!isfinite(x[j]))x[j]=-INFINITY;m=max(m,x[j]);}\n"
 "   m=simd_max(m);float nm=max(maxima[row],m),c=isfinite(maxima[row])&&isfinite(nm)?exp(maxima[row]-nm):0,sum=0;\n"
 "   for(uint j=0;j<2;j++){float e=isfinite(x[j])?exp(x[j]-nm):0;prob[row*KT+lane+j*32]=e;sum+=e;}\n"
 "   sum=simd_sum(sum);if(lane==0){maxima[row]=nm;denom[row]=denom[row]*c+sum;correction[row]=c;}\n"
 "  }\n"
 "  threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "  for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);float scale=correction[c[1]];out[i]=scale==0?0:out[i]*scale;}\n"
 "  if(tid==0)atomic_store_explicit(&nonfinite_v,0,memory_order_relaxed);threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "  for(uint i=tid;i<KT*256;i+=128){uint t=start+i/256,d=i%256;if(t<p.kv_tokens){uint physical=blocks[t/p.page_size]+t%p.page_size;if(!isfinite(v[physical*p.v_row_stride+kh*256+d]))atomic_store_explicit(&nonfinite_v,1,memory_order_relaxed);}}\n"
 "  threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "  if(atomic_load_explicit(&nonfinite_v,memory_order_relaxed)==0){\n"
 "   for(uint part=0;part<KT/16;part++){uint key=start+part*16;if(key>=p.kv_tokens)break;uint count=min(16u,p.kv_tokens-key),physical=blocks[key/p.page_size]+key%p.page_size;\n"
 "    tensor<threadgroup float,dextents<int,2>,tensor_inline>P(prob+part*16,dextents<int,2>(count,QT),array<int,2>{1,KT});\n"
 "    tensor<device half,dextents<int,2>,tensor_inline>V(v+physical*p.v_row_stride+kh*256+sg*64,dextents<int,2>(64,count),array<int,2>{1,int(p.v_row_stride)});\n"
 "    pvop.run(P,V,out);\n"
 "   }\n"
 "  }else for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);uint row=c[1],d=sg*64+c[0];float sum=0;for(uint t=0;t<KT&&start+t<p.kv_tokens;t++){float w=prob[row*KT+t];if(w!=0){uint key=start+t,physical=blocks[key/p.page_size]+key%p.page_size;sum+=w*float(v[physical*p.v_row_stride+kh*256+d]);}}out[i]+=sum;}\n"
 " }\n"
 " for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);uint row=c[1],d=sg*64+c[0];if(q0+row>=p.q_len)continue;float value=denom[row]>0?out[i]/denom[row]:0;\n"
 "  if(denom[row]==0){float sum=0;for(uint t=0;t<p.kv_tokens;t++){bool allowed=t+p.kv_position_offset<=p.query_position_offset+q0+row;uint physical=allowed?blocks[t/p.page_size]+t%p.page_size:0;sum+=float(v[physical*p.v_row_stride+kh*256+d]);}value=sum/float(p.kv_tokens);}\n"
 "  y[((q0+row)*p.num_heads+h)*256+d]=value;\n"
 " }\n"
 "}\n"
;}
typedef struct {
    termite_metal_decode_runtime *r;
    id<MTLBuffer> q, k, v, y;
    uint32_t *blocks;
    size_t n, heads, kh, block_count;
} PrefillPair;
void *prefill_pair_create(size_t n,size_t heads,const float*q,const uint16_t*k,const uint16_t*v) {
    @autoreleasepool {
        PrefillPair *b=calloc(1,sizeof(*b));if(!b)return NULL;
        b->r=termite_metal_decode_runtime_create();if(!b->r){free(b);return NULL;}
        termite_metal_decode_runtime_set_lightonocr3_projections(b->r,1);
        termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(b->r,1);
        MTLCompileOptions*options=[MTLCompileOptions new];options.languageVersion=MTLLanguageVersion4_0;options.mathMode=MTLMathModeSafe;NSError*error=nil;id<MTLLibrary>library=[b->r->device newLibraryWithSource:float_source() options:options error:&error];if(!library){fprintf(stderr,"%s\n",error.localizedDescription.UTF8String);return NULL;}
        b->r->lightonocr3_prefill_attention_mpp32_pipeline=nil;
        b->r->lightonocr3_prefill_attention_mpp_pipeline=termite_metal_make_pipeline(b->r->device,library,@"prefill_direct64_16");
        if(!b->r->lightonocr3_prefill_attention_mpp_pipeline)return NULL;
        b->n=n;b->heads=heads;b->kh=heads/4;b->block_count=(n+127)/128;
        b->q=[b->r->device newBufferWithBytes:q length:n*heads*256*4 options:MTLResourceStorageModeShared];
        b->k=[b->r->device newBufferWithLength:b->block_count*128*b->kh*256*2 options:MTLResourceStorageModeShared];
        b->v=[b->r->device newBufferWithLength:b->k.length options:MTLResourceStorageModeShared];
        b->y=[b->r->device newBufferWithLength:n*heads*256*4 options:MTLResourceStorageModeShared];
        b->blocks=calloc(b->block_count,4);if(!b->q||!b->k||!b->v||!b->y||!b->blocks)return NULL;
        for(size_t page=0;page<b->block_count;page++)b->blocks[page]=(uint32_t)((b->block_count-1-page)*128);
        for(size_t t=0;t<n;t++){
            size_t p=b->blocks[t/128]+t%128;
            memcpy((char*)b->k.contents+p*b->kh*256*2,k+t*b->kh*256,b->kh*256*2);
            memcpy((char*)b->v.contents+p*b->kh*256*2,v+t*b->kh*256,b->kh*256*2);
        }
        b->r->attention_span_encoded_key_buffers[7]=b->k;b->r->attention_span_v_buffers[7]=b->v;
        b->r->attention_span_slot_key_row_bytes[7]=b->kh*256*2;b->r->attention_span_slot_v_row_stride[7]=b->kh*256;
        return b;
    }
}
int prefill_pair_run(void *raw,double *gpu_us){
    @autoreleasepool {
        PrefillPair*b=raw;uint64_t count=b->r->lightonocr3_prefill_attention_mpp_dispatches;
        if(termite_metal_decode_runtime_begin_frame(b->r)||
           termite_metal_decode_runtime_attention_paged_slot_device(b->r,7,3,(__bridge void*)b->q,0,b->blocks,b->block_count,128,b->n,b->n,b->heads,b->kh,256,b->kh*256*2,b->kh*256*2,0,0,0,0,NULL,0,(__bridge void*)b->y,0)||
           termite_metal_decode_runtime_submit_frame(b->r)||termite_metal_decode_runtime_wait_frame(b->r))return -1;
        if(b->r->lightonocr3_prefill_attention_mpp_dispatches!=count+1)return -2;
        *gpu_us=b->r->last_frame_gpu_nanos/1000.0;return 0;
    }
}
const float *prefill_pair_output(void *raw){PrefillPair*b=raw;return b->y.contents;}
void prefill_pair_destroy(void *raw){
    if(!raw)return;PrefillPair*b=raw;termite_metal_decode_runtime_destroy(b->r);
    b->q=nil;b->k=nil;b->v=nil;b->y=nil;free(b->blocks);free(b);
}
