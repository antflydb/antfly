#include "../zig/pkg/inference/src/backends/metal_kernels.m"
static NSString*float_source(void){return @""
 "#include <metal_stdlib>\n"
 "#include <metal_simdgroup_matrix>\n"
 "using namespace metal;\n"
 "struct Params {uint q_len,kv_tokens,num_heads,num_kv_heads,head_dim,key_row_bytes,base_key_row_bytes,query_position_offset,kv_position_offset,sliding_window,v_row_stride,page_size,block_count,contiguous_base_token,contiguous_blocks,format,v_element_bytes,has_sinks;float softcap;uint swa_scan_clamp;};\n"
 "kernel void prefill_simd_float(device const float*q[[buffer(0)]],device const half*k[[buffer(1)]],device const half*v[[buffer(2)]],device const uint*blocks[[buffer(3)]],device const float*sinks[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]],uint tid[[thread_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]]){\n"
 " const uint q0=group.x*16,h=group.y,kh=h/(p.num_heads/p.num_kv_heads),kw=p.key_row_bytes/2;\n"
 " const uint fragment_row=((lane&16)>>2)+((lane>>1)&3),fragment_col=((lane&8)>>1)+((lane&1)<<1);\n"
 " threadgroup float qs[16*128],kv[32*128],scores[16*32],prob[16*32],maxima[16],denom[16],correction[16];threadgroup atomic_uint nonfinite_v;\n"
 " if(tid<16){maxima[tid]=-INFINITY;denom[tid]=0;}\n"
 " simdgroup_float8x8 out[2][2][4];\n"
 " for(uint part=0;part<2;part++)for(uint j=0;j<2;j++)for(uint d=0;d<4;d++)out[part][j][d]=make_filled_simdgroup_matrix<float,8>(0.0f);\n"
 " uint end=min(p.kv_tokens,p.query_position_offset+min(q0+16,p.q_len)-p.kv_position_offset);\n"
 " for(uint start=0;start<end;start+=32){\n"
 "  simdgroup_float8x8 dots[2];dots[0]=make_filled_simdgroup_matrix<float,8>(0.0f);dots[1]=make_filled_simdgroup_matrix<float,8>(0.0f);\n"
 "  for(uint part=0;part<2;part++){\n"
 "   threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "   for(uint i=tid;i<16*128;i+=128){uint row=i/128,d=part*128+i%128;qs[i]=q0+row<p.q_len?q[((q0+row)*p.num_heads+h)*256+d]:0;}\n"
 "   for(uint i=tid;i<32*128;i+=128){uint t=start+i/128,d=part*128+i%128,physical=t<p.kv_tokens?blocks[t/p.page_size]+t%p.page_size:0;kv[i]=t<p.kv_tokens?float(k[physical*kw+kh*256+d]):0;}\n"
 "   threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "   for(uint d=0;d<128;d+=8){simdgroup_float8x8 mk;simdgroup_load(mk,kv+sg*8*128+d,128,0,true);\n"
 "    for(uint j=0;j<2;j++){simdgroup_float8x8 mq;simdgroup_load(mq,qs+j*8*128+d,128);simdgroup_multiply_accumulate(dots[j],mq,mk,dots[j]);}\n"
 "   }\n"
 "  }\n"
 "  for(uint j=0;j<2;j++)simdgroup_store(dots[j],scores+j*8*32+sg*8,32);\n"
 "  threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "  for(uint pass=0;pass<4;pass++){\n"
 "   uint row=sg+pass*4,t=start+lane;bool valid=q0+row<p.q_len&&t<p.kv_tokens&&t+p.kv_position_offset<=p.query_position_offset+q0+row;\n"
 "   float x=valid?scores[row*32+lane]*.0625f:-INFINITY;if(!isfinite(x))x=-INFINITY;\n"
 "   float m=simd_max(x),nm=max(maxima[row],m),c=isfinite(maxima[row])&&isfinite(nm)?exp(maxima[row]-nm):0;\n"
 "   float e=isfinite(x)?exp(x-nm):0;prob[row*32+lane]=e;float sum=simd_sum(e);if(lane==0){maxima[row]=nm;denom[row]=denom[row]*c+sum;correction[row]=c;}\n"
 "  }\n"
 "  threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "  for(uint part=0;part<2;part++)for(uint j=0;j<2;j++)for(uint d=0;d<4;d++)for(uint e=0;e<2;e++){\n"
 "   float c=correction[j*8+fragment_row];out[part][j][d].thread_elements()[e]=c==0?0:out[part][j][d].thread_elements()[e]*c;\n"
 "  }\n"
 "  for(uint part=0;part<2;part++){\n"
 "   threadgroup_barrier(mem_flags::mem_threadgroup);if(tid==0)atomic_store_explicit(&nonfinite_v,0,memory_order_relaxed);threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "   for(uint i=tid;i<32*128;i+=128){uint t=start+i/128,d=part*128+i%128,physical=t<p.kv_tokens?blocks[t/p.page_size]+t%p.page_size:0;float value=t<p.kv_tokens?float(v[physical*p.v_row_stride+kh*256+d]):0;kv[i]=value;if(!isfinite(value))atomic_store_explicit(&nonfinite_v,1,memory_order_relaxed);}\n"
 "   threadgroup_barrier(mem_flags::mem_threadgroup);\n"
 "   if(atomic_load_explicit(&nonfinite_v,memory_order_relaxed)==0){\n"
 "    for(uint t=0;t<32;t+=8)for(uint j=0;j<2;j++){simdgroup_float8x8 mp;simdgroup_load(mp,prob+j*8*32+t,32);\n"
 "     for(uint d=0;d<4;d++){simdgroup_float8x8 mv;simdgroup_load(mv,kv+t*128+sg*32+d*8,128);simdgroup_multiply_accumulate(out[part][j][d],mp,mv,out[part][j][d]);}\n"
 "    }\n"
 "   }else for(uint j=0;j<2;j++)for(uint d=0;d<4;d++)for(uint e=0;e<2;e++){\n"
 "    uint row=j*8+fragment_row,col=sg*32+d*8+fragment_col+e;float sum=0;for(uint t=0;t<32;t++){float w=prob[row*32+t];if(w!=0)sum+=w*kv[t*128+col];}out[part][j][d].thread_elements()[e]+=sum;\n"
 "   }\n"
 "  }\n"
 " }\n"
 " for(uint part=0;part<2;part++)for(uint j=0;j<2;j++)for(uint dc=0;dc<4;dc++)for(uint e=0;e<2;e++){\n"
 "  uint row=j*8+fragment_row,d=part*128+sg*32+dc*8+fragment_col+e;if(q0+row>=p.q_len)continue;\n"
 "  float value=denom[row]>0?out[part][j][dc].thread_elements()[e]/denom[row]:0;\n"
 "  if(denom[row]==0){float sum=0;for(uint t=0;t<p.kv_tokens;t++){bool allowed=t+p.kv_position_offset<=p.query_position_offset+q0+row;uint physical=allowed?blocks[t/p.page_size]+t%p.page_size:0;sum+=float(v[physical*p.v_row_stride+kh*256+d]);}value=sum/float(p.kv_tokens);}\n"
 "  y[((q0+row)*p.num_heads+h)*256+d]=value;\n"
 " }\n"
 "}\n"
;}
typedef struct {
    termite_metal_decode_runtime *r;
    id<MTLBuffer> q, k, v, y;
    uint32_t *blocks;
    size_t n, heads, kh, block_count;
} PrefillPair;
void *prefill_pair_create(size_t n,size_t heads,const float*q,const uint16_t*k,const uint16_t*v) {
    @autoreleasepool {
        PrefillPair *b=calloc(1,sizeof(*b));if(!b)return NULL;
        b->r=termite_metal_decode_runtime_create();if(!b->r){free(b);return NULL;}
        termite_metal_decode_runtime_set_lightonocr3_projections(b->r,1);
        termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(b->r,1);
        MTLCompileOptions*options=[MTLCompileOptions new];options.languageVersion=MTLLanguageVersion4_0;options.mathMode=MTLMathModeSafe;NSError*error=nil;id<MTLLibrary>library=[b->r->device newLibraryWithSource:float_source() options:options error:&error];if(!library){fprintf(stderr,"%s\n",error.localizedDescription.UTF8String);return NULL;}
        b->r->lightonocr3_prefill_attention_mpp32_pipeline=nil;
        b->r->lightonocr3_prefill_attention_mpp_pipeline=termite_metal_make_pipeline(b->r->device,library,@"prefill_simd_float");
        if(!b->r->lightonocr3_prefill_attention_mpp_pipeline)return NULL;
        b->n=n;b->heads=heads;b->kh=heads/4;b->block_count=(n+127)/128;
        b->q=[b->r->device newBufferWithBytes:q length:n*heads*256*4 options:MTLResourceStorageModeShared];
        b->k=[b->r->device newBufferWithLength:b->block_count*128*b->kh*256*2 options:MTLResourceStorageModeShared];
        b->v=[b->r->device newBufferWithLength:b->k.length options:MTLResourceStorageModeShared];
        b->y=[b->r->device newBufferWithLength:n*heads*256*4 options:MTLResourceStorageModeShared];
        b->blocks=calloc(b->block_count,4);if(!b->q||!b->k||!b->v||!b->y||!b->blocks)return NULL;
        for(size_t page=0;page<b->block_count;page++)b->blocks[page]=(uint32_t)((b->block_count-1-page)*128);
        for(size_t t=0;t<n;t++){
            size_t p=b->blocks[t/128]+t%128;
            memcpy((char*)b->k.contents+p*b->kh*256*2,k+t*b->kh*256,b->kh*256*2);
            memcpy((char*)b->v.contents+p*b->kh*256*2,v+t*b->kh*256,b->kh*256*2);
        }
        b->r->attention_span_encoded_key_buffers[7]=b->k;b->r->attention_span_v_buffers[7]=b->v;
        b->r->attention_span_slot_key_row_bytes[7]=b->kh*256*2;b->r->attention_span_slot_v_row_stride[7]=b->kh*256;
        return b;
    }
}
int prefill_pair_run(void *raw,double *gpu_us){
    @autoreleasepool {
        PrefillPair*b=raw;uint64_t count=b->r->lightonocr3_prefill_attention_mpp_dispatches;
        if(termite_metal_decode_runtime_begin_frame(b->r)||
           termite_metal_decode_runtime_attention_paged_slot_device(b->r,7,3,(__bridge void*)b->q,0,b->blocks,b->block_count,128,b->n,b->n,b->heads,b->kh,256,b->kh*256*2,b->kh*256*2,0,0,0,0,NULL,0,(__bridge void*)b->y,0)||
           termite_metal_decode_runtime_submit_frame(b->r)||termite_metal_decode_runtime_wait_frame(b->r))return -1;
        if(b->r->lightonocr3_prefill_attention_mpp_dispatches!=count+1)return -2;
        *gpu_us=b->r->last_frame_gpu_nanos/1000.0;return 0;
    }
}
const float *prefill_pair_output(void *raw){PrefillPair*b=raw;return b->y.contents;}
void prefill_pair_destroy(void *raw){
    if(!raw)return;PrefillPair*b=raw;termite_metal_decode_runtime_destroy(b->r);
    b->q=nil;b->k=nil;b->v=nil;b->y=nil;free(b->blocks);free(b);
}
