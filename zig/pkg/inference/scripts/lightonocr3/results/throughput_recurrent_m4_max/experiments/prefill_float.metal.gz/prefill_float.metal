#include <metal_stdlib>
#include <metal_tensor>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;using namespace mpp::tensor_ops;
struct Params {uint q_len,kv_tokens,num_heads,num_kv_heads,head_dim,key_row_bytes,base_key_row_bytes,query_position_offset,kv_position_offset,sliding_window,v_row_stride,page_size,block_count,contiguous_base_token,contiguous_blocks,format,v_element_bytes,has_sinks;float softcap;uint swa_scan_clamp;};
kernel void prefill_float(device float*q[[buffer(0)]],device const half*k[[buffer(1)]],device const half*v[[buffer(2)]],device const uint*blocks[[buffer(3)]],device const float*sinks[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]],uint tid[[thread_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]]){
 const uint q0=group.x*32,h=group.y,kh=h/(p.num_heads/p.num_kv_heads),kw=p.key_row_bytes/2;
 threadgroup float tile[32*128],scores[32*32],prob[32*32],maxima[32],denom[32],correction[32];threadgroup atomic_uint nonfinite_v;
 if(tid<32){maxima[tid]=-INFINITY;denom[tid]=0;}
 tensor<device float,dextents<int,2>,tensor_inline>Qbase(q+h*256+q0*p.num_heads*256,dextents<int,2>(128,min(32u,p.q_len-q0)),array<int,2>{1,int(p.num_heads*256)});
 tensor<threadgroup float,dextents<int,2>,tensor_inline>ka(tile,dextents<int,2>(128,32),array<int,2>{1,128});auto K=ka.slice(0,int(sg*8));
 tensor<threadgroup float,dextents<int,2>,tensor_inline>S(scores+sg*8,dextents<int,2>(8,32),array<int,2>{1,32});
 tensor<threadgroup float,dextents<int,2>,tensor_inline>P(prob,dextents<int,2>(32,32),array<int,2>{1,32});
 tensor<threadgroup float,dextents<int,2>,tensor_inline>V(tile+sg*32,dextents<int,2>(32,32),array<int,2>{1,128});
 constexpr auto qkd=matmul2d_descriptor(32,8,128,false,true,false,matmul2d_descriptor::mode::multiply_accumulate);
 constexpr auto pvd=matmul2d_descriptor(32,32,32,false,false,false,matmul2d_descriptor::mode::multiply_accumulate);
 matmul2d<qkd,execution_simdgroups<1>>qkop;matmul2d<pvd,execution_simdgroups<1>>pvop;
 auto out0=pvop.get_destination_cooperative_tensor<decltype(P),decltype(V),float>();auto out1=pvop.get_destination_cooperative_tensor<decltype(P),decltype(V),float>();
 for(ushort i=0;i<out0.get_capacity();i++){out0[i]=0;out1[i]=0;}
 uint end=min(p.kv_tokens,p.query_position_offset+min(q0+32,p.q_len)-p.kv_position_offset);
 for(uint start=0;start<end;start+=32){
  auto dots=qkop.get_destination_cooperative_tensor<decltype(Qbase),decltype(K),float>();for(ushort i=0;i<dots.get_capacity();i++)dots[i]=0;
  for(uint part=0;part<2;part++){
   threadgroup_barrier(mem_flags::mem_threadgroup);
   for(uint i=tid;i<32*128;i+=128){uint t=start+i/128,d=part*128+i%128,physical=t<p.kv_tokens?blocks[t/p.page_size]+t%p.page_size:0;tile[i]=t<p.kv_tokens?float(k[physical*kw+kh*256+d]):0;}
   threadgroup_barrier(mem_flags::mem_threadgroup);
   tensor<device float,dextents<int,2>,tensor_inline>Q(q+h*256+q0*p.num_heads*256+part*128,dextents<int,2>(128,min(32u,p.q_len-q0)),array<int,2>{1,int(p.num_heads*256)});
   qkop.run(Q,K,dots);
  }
  dots.store(S);threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint pass=0;pass<8;pass++){
   uint row=sg+pass*4,t=start+lane;bool valid=q0+row<p.q_len&&t<p.kv_tokens&&t+p.kv_position_offset<=p.query_position_offset+q0+row;
   float x=valid?scores[row*32+lane]*.0625f:-INFINITY;if(!isfinite(x))x=-INFINITY;
   float m=simd_max(x),nm=max(maxima[row],m),c=isfinite(maxima[row])&&isfinite(nm)?exp(maxima[row]-nm):0;
   float e=isfinite(x)?exp(x-nm):0;prob[row*32+lane]=e;float sum=simd_sum(e);if(lane==0){maxima[row]=nm;denom[row]=denom[row]*c+sum;correction[row]=c;}
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(ushort i=0;i<out0.get_capacity();i++){auto c=out0.get_multidimensional_index(i);float scale=correction[c[1]];out0[i]=scale==0?0:out0[i]*scale;out1[i]=scale==0?0:out1[i]*scale;}
  for(uint part=0;part<2;part++){
   threadgroup_barrier(mem_flags::mem_threadgroup);if(tid==0)atomic_store_explicit(&nonfinite_v,0,memory_order_relaxed);threadgroup_barrier(mem_flags::mem_threadgroup);
   for(uint i=tid;i<32*128;i+=128){uint t=start+i/128,d=part*128+i%128,physical=t<p.kv_tokens?blocks[t/p.page_size]+t%p.page_size:0;float value=t<p.kv_tokens?float(v[physical*p.v_row_stride+kh*256+d]):0;tile[i]=value;if(!isfinite(value))atomic_store_explicit(&nonfinite_v,1,memory_order_relaxed);}
   threadgroup_barrier(mem_flags::mem_threadgroup);
   if(atomic_load_explicit(&nonfinite_v,memory_order_relaxed)==0){if(part==0)pvop.run(P,V,out0);else pvop.run(P,V,out1);}
   else for(ushort i=0;i<out0.get_capacity();i++){auto c=out0.get_multidimensional_index(i);float sum=0;for(uint t=0;t<32;t++){float w=prob[c[1]*32+t];if(w!=0)sum+=w*tile[t*128+sg*32+c[0]];}if(part==0)out0[i]+=sum;else out1[i]+=sum;}
  }
 }
 for(ushort i=0;i<out0.get_capacity();i++){auto c=out0.get_multidimensional_index(i);uint row=c[1];if(q0+row>=p.q_len)continue;
  for(uint part=0;part<2;part++){uint d=part*128+sg*32+c[0];float value=denom[row]>0?(part==0?out0[i]:out1[i])/denom[row]:0;
   if(denom[row]==0){float sum=0;for(uint t=0;t<p.kv_tokens;t++){bool allowed=t+p.kv_position_offset<=p.query_position_offset+q0+row;uint physical=allowed?blocks[t/p.page_size]+t%p.page_size:0;sum+=float(v[physical*p.v_row_stride+kh*256+d]);}value=sum/float(p.kv_tokens);}
   y[((q0+row)*p.num_heads+h)*256+d]=value;
  }
 }
}
