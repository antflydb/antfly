from pathlib import Path
import hashlib,json,re,os,subprocess,sys
root=Path.cwd();p=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_recurrent_m4_max';p.mkdir(exist_ok=True);sha=lambda f:hashlib.sha256(Path(f).read_bytes()).hexdigest()
build=sys.argv[1];manifest_path=p/(build+'_build_manifest.json')
if not manifest_path.exists():
 import gzip
 frozen=json.loads((root/'.venv-lighton-vllm-metal/throughput-freeze.json').read_text());assert all(sha(f)==h for f,h in frozen.items()),'runtime mutated during build'
 log=Path('/private/tmp/ocr-throughput-build.txt').read_text();matches=re.findall(r'\.zig-cache/o/([0-9a-f]{32})/test(?:\s|$)',log);assert matches,'build not finished';binary=root/'zig/.zig-cache/o'/matches[-1]/'test'
 base=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();patch=subprocess.check_output(['git','diff','HEAD','--','zig/pkg/inference/src']);manifest=dict(runtime_commit=base,runtime_source_diff_sha256=hashlib.sha256(patch).hexdigest(),runtime_files_sha256=frozen,binary_sha256=sha(binary),binary_path=str(binary));manifest_path.write_text(json.dumps(manifest,indent=2)+'\n');(p/(build+'_runtime.patch.gz')).write_bytes(gzip.compress(patch,mtime=0))
manifest=json.loads(manifest_path.read_text());binary=Path(manifest['binary_path']);assert sha(binary)==manifest['binary_sha256']
for key in sys.argv[2:]:
 short,variant=key.split('_',1);label='lighton08'if short=='08'else'lighton4b';flags=['--weight-residency','--continuous']
 if variant.startswith('off'):flags+=['--disable-recurrent-parallel','--disable-prefill-attention-mpp','--disable-prefill-core-norm']
 if not variant.startswith('off'):
  if not variant.startswith('attn'):flags+=['--recurrent-parallel']
  if not variant.startswith('rnn'):flags+=['--prefill-attention-mpp']
 if 'coalesce'in variant:flags+=['--recurrent-coalescing']
 if 'profile'in variant:flags+=['--profile-reader','--require-recurrent-parallel','--require-prefill-attention-mpp','--require-prefill-core-norm']
 if variant.startswith('rounds'):
  if 'profile'in variant:flags+=['--profile-reader']

  policies=os.environ.get('OCR_POLICY_ROUNDS','off,on,off,on,off,on,recurrent,attention,norm,static,on,coalesced,on').split(',')
  flags+=['--prefill-core-norm','--require-recurrent-parallel','--require-prefill-attention-mpp','--require-prefill-core-norm','--policy-rounds',*policies]

 ref=root/'zig/pkg/inference/scripts/lightonocr3/results/throughput_parity_m4_max'/('vllm_'+short+'_shipping_reference')/'report.json'
 if (p/('vllm_'+short+'_reference')/'report.json').exists():ref=p/('vllm_'+short+'_reference')/'report.json'
 command=[sys.executable,str(root/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py'),'--native-test',str(binary),'--model',f'{label}={root/".venv-lighton-vllm-metal/ocr-models"/label}','--images',str(root/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(root/'zig/pkg/inference/scripts/lightonocr3/corpus/receipt.png'),str(root/'zig/pkg/inference/scripts/lightonocr3/corpus/shipping.png'),'--pages-per-request',os.environ.get('OCR_PAGES_PER_REQUEST','1'),'--requests',os.environ.get('OCR_REQUESTS','16'),'--concurrency',os.environ.get('OCR_CONCURRENCY','8'),'--max-tokens','256','--modes','batch','--batch-rows',os.environ.get('OCR_ROWS','8'),'--batch-window',os.environ.get('OCR_WINDOW','8'),'--batch-wait-us','20000','--memory-gib','24','--shared-memory-gib','28','--backend-memory-gib','16','--kv-memory-gib','4','--scratch-memory-gib','4','--timeout','900','--reference-report',str(ref),'--output-dir',str(p/('native_'+build+'_'+key)),'--build-manifest',str(manifest_path),*flags]
 print('START',build,key,flush=True)
 with open('/private/tmp/ocr-'+build+'-reader-'+key+'.txt','w')as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 print('DONE',build,key,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
 data=json.loads((p/('native_'+build+'_'+key)/'report.json').read_text());print(json.dumps({k:v for k,v in data['results'][0].items() if k in ['status','pages_per_second','p50_ms','p95_ms','elapsed_ms','serial_reference_parity','cross_runtime_content_parity','policy_rounds']}),flush=True)
