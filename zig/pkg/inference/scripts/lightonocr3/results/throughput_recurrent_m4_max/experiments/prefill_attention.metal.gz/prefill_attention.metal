#include <metal_stdlib>
#include <metal_tensor>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;
using namespace mpp::tensor_ops;
struct Params {uint q_len,kv_tokens,num_heads,num_kv_heads,head_dim,key_row_bytes,base_key_row_bytes,query_position_offset,kv_position_offset,sliding_window,v_row_stride,page_size,block_count,contiguous_base_token,contiguous_blocks,format,v_element_bytes,has_sinks;float softcap;uint swa_scan_clamp;};
kernel void prefill_mpp(device float*q[[buffer(0)]],device const half*k[[buffer(1)]],device const half*v[[buffer(2)]],device const uint*blocks[[buffer(3)]],device const float*sinks[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]],uint tid[[thread_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]]){
 const uint q0=group.x*16,h=group.y,kh=h/(p.num_heads/p.num_kv_heads),hd=256,kw=p.key_row_bytes/2;
 threadgroup atomic_uint nonfinite_v;threadgroup half kv[32*256];threadgroup float scores[16*32],prob[16*32],maxima[16],denom[16],correction[16];
 if(tid<16){maxima[tid]=-INFINITY;denom[tid]=0;}
 tensor<device float,dextents<int,2>,tensor_inline>qa(q+h*hd,dextents<int,2>(hd,p.q_len),array<int,2>{1,int(p.num_heads*hd)});
 auto Q=qa.slice(0,int(q0));
 tensor<threadgroup half,dextents<int,2>,tensor_inline>ka(kv,dextents<int,2>(hd,32),array<int,2>{1,hd});
 auto K=ka.slice(0,int(sg*8));
 tensor<threadgroup float,dextents<int,2>,tensor_inline>S(scores+sg*8,dextents<int,2>(8,16),array<int,2>{1,32});
 tensor<threadgroup float,dextents<int,2>,tensor_inline>P(prob,dextents<int,2>(32,16),array<int,2>{1,32});
 tensor<threadgroup half,dextents<int,2>,tensor_inline>V(kv+sg*64,dextents<int,2>(64,32),array<int,2>{1,hd});
 constexpr auto qkd=matmul2d_descriptor(16,8,256,false,true,false);
 constexpr auto pvd=matmul2d_descriptor(16,64,32,false,false,false,matmul2d_descriptor::mode::multiply_accumulate);
 matmul2d<qkd,execution_simdgroups<1>>qkop;matmul2d<pvd,execution_simdgroups<1>>pvop;
 auto out=pvop.get_destination_cooperative_tensor<decltype(P),decltype(V),float>();
 for(ushort i=0;i<out.get_capacity();i++)out[i]=0;
 uint end=min(p.kv_tokens,p.query_position_offset+min(q0+16,p.q_len)-p.kv_position_offset);
 for(uint start=0;start<end;start+=32){
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint i=tid;i<32*256;i+=128){uint t=start+i/256,d=i%256;uint physical=t<p.kv_tokens?blocks[t/p.page_size]+t%p.page_size:0;
   kv[i]=t<p.kv_tokens?k[physical*kw+kh*hd+d]:half(0);
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);
  auto dots=qkop.get_destination_cooperative_tensor<decltype(Q),decltype(K),float>();qkop.run(Q,K,dots);dots.store(S);
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint pass=0;pass<4;pass++){
   uint row=sg+pass*4,t=start+lane;bool valid=q0+row<p.q_len&&t<p.kv_tokens&&t+p.kv_position_offset<=p.query_position_offset+q0+row;
   float x=valid?scores[row*32+lane]*0.0625f:-INFINITY;if(!isfinite(x))x=-INFINITY;
   float m=simd_max(x),nm=max(maxima[row],m),c=isfinite(maxima[row])&&isfinite(nm)?exp(maxima[row]-nm):0;
   float e=isfinite(x)?exp(x-nm):0;prob[row*32+lane]=e;float sum=simd_sum(e);
   if(lane==0){maxima[row]=nm;denom[row]=denom[row]*c+sum;correction[row]=c;}
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(ushort i=0;i<out.get_capacity();i++){auto coord=out.get_multidimensional_index(i);out[i]*=correction[coord[1]];}
  if(tid==0)atomic_store_explicit(&nonfinite_v,0,memory_order_relaxed);
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint i=tid;i<32*256;i+=128){uint t=start+i/256,d=i%256;uint physical=t<p.kv_tokens?blocks[t/p.page_size]+t%p.page_size:0;
   half value=t<p.kv_tokens?v[physical*p.v_row_stride+kh*hd+d]:half(0);kv[i]=value;
   if(!isfinite(value))atomic_store_explicit(&nonfinite_v,1,memory_order_relaxed);
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);
  if(atomic_load_explicit(&nonfinite_v,memory_order_relaxed)==0)pvop.run(P,V,out);
  else for(ushort i=0;i<out.get_capacity();i++){
   auto coord=out.get_multidimensional_index(i);uint row=coord[1],d=sg*64+coord[0];float sum=0;
   for(uint t=0;t<32;t++){float weight=prob[row*32+t];if(weight!=0)sum+=weight*float(kv[t*256+d]);}out[i]+=sum;
  }
 }
 for(ushort i=0;i<out.get_capacity();i++){auto coord=out.get_multidimensional_index(i);uint row=coord[1],d=sg*64+coord[0];if(q0+row<p.q_len){
  float value=denom[row]>0?out[i]/denom[row]:0;
  // Match the existing sentinel-softmax route when every score is invalid:
  // exp(sentinel-sentinel) gives uniform mass, including masked physical zero.
  if(denom[row]==0){float sum=0;for(uint t=0;t<p.kv_tokens;t++){
   bool allowed=t+p.kv_position_offset<=p.query_position_offset+q0+row;
   uint physical=allowed?blocks[t/p.page_size]+t%p.page_size:0;sum+=float(v[physical*p.v_row_stride+kh*hd+d]);
  }value=sum/float(p.kv_tokens);}
  y[((q0+row)*p.num_heads+h)*hd+d]=value;
 }}
}
