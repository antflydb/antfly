from pathlib import Path
import ctypes as c,json,time,hashlib,itertools,statistics
import numpy as np
import mlx.core as mx
r=Path.cwd();h=r/'.venv-lighton-vllm-metal';lib=c.CDLL(str(h/'bin/prefill-shipping-pair.dylib'))
lib.prefill_pair_create.argtypes=[c.c_size_t,c.c_size_t,c.c_void_p,c.c_void_p,c.c_void_p];lib.prefill_pair_create.restype=c.c_void_p
lib.prefill_pair_run.argtypes=[c.c_void_p,c.POINTER(c.c_double)];lib.prefill_pair_run.restype=c.c_int
lib.prefill_pair_output.argtypes=[c.c_void_p];lib.prefill_pair_output.restype=c.POINTER(c.c_float)
lib.prefill_pair_destroy.argtypes=[c.c_void_p]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
report=dict(scope='One process; native F32 queries/probabilities/accumulation/output and existing F16 paged KV versus MLX BF16 production-style attention and a F32 numeric reference. MLX KV is contiguous; native page table is permuted. All participant wall timings include synchronized completion; native GPU timestamps are also retained. No precision-matched BF16 claim.',runtime_sha256=sha(r/'zig/pkg/inference/src/backends/metal_kernels.m'),bridge_sha256=sha(h/'prefill_pair_bridge.m'),python_sha256=sha(__file__),library_sha256=sha(h/'bin/prefill-shipping-pair.dylib'),cases=[])
orders=list(itertools.permutations(range(3)))
for heads in [8,16]:
 for n in [432,662,1024]:
  rng=np.random.default_rng(123);q=rng.uniform(-.7,.7,(n,heads,256)).astype('f4');k=rng.uniform(-.6,.6,(n,heads//4,256)).astype('f2');v=rng.uniform(-.6,.6,k.shape).astype('f2')
  probe=lib.prefill_pair_create(n,heads,q.ctypes.data,k.ctypes.data,v.ctypes.data);assert probe
  try:
   g=c.c_double();assert lib.prefill_pair_run(probe,c.byref(g))==0
   native=np.ctypeslib.as_array(lib.prefill_pair_output(probe),shape=(n*heads*256,)).copy().reshape(n,heads,256)
   source=[mx.array(np.transpose(a.astype('f4'),(1,0,2))[None])for a in [q,k,v]];mx.eval(*source)
   inputs=[[x.astype(dtype)for x in source]for dtype in [mx.bfloat16,mx.float32]]
   for row in inputs:mx.eval(*row)
   errors=[]
   for row in inputs:
    out=mx.fast.scaled_dot_product_attention(*row,scale=.0625,mask='causal');mx.eval(out);got=np.transpose(np.array(out.astype(mx.float32))[0],(1,0,2));errors.append(float(np.max(np.abs(got-native))))
   assert errors[1]<2e-4,errors
   samples=[[],[],[]];gpu=[]
   for warm in range(8):
    assert lib.prefill_pair_run(probe,c.byref(g))==0
    for row in inputs:mx.eval(mx.fast.scaled_dot_product_attention(*row,scale=.0625,mask='causal'))
   for trial in range(36):
    for mode in orders[trial%6]:
     start=time.perf_counter_ns()
     if mode==0:
      assert lib.prefill_pair_run(probe,c.byref(g))==0;gpu.append(g.value)
     else:
      out=mx.fast.scaled_dot_product_attention(*inputs[mode-1],scale=.0625,mask='causal');mx.eval(out)
     samples[mode].append((time.perf_counter_ns()-start)/1000)
   case=dict(heads=heads,kv_heads=heads//4,seq=n,wall_us={'native':samples[0],'mlx_bf16':samples[1],'mlx_f32':samples[2]},native_gpu_us=gpu,max_abs_vs_mlx_bf16=errors[0],max_abs_vs_mlx_f32=errors[1]);case['median_us']={key:statistics.median(value)for key,value in case['wall_us'].items()};report['cases'].append(case)
   print(heads,n,case['median_us'],errors,flush=True)
  finally:lib.prefill_pair_destroy(probe)
  mx.clear_cache()
 out=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_recurrent_m4_max/shipping_prefill_attention_mlx_pair.json';out.write_text(json.dumps(report,indent=2)+'\n')
