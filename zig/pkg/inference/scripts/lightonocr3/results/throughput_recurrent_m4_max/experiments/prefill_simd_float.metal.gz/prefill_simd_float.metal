#include <metal_stdlib>
#include <metal_simdgroup_matrix>
using namespace metal;
struct Params {uint q_len,kv_tokens,num_heads,num_kv_heads,head_dim,key_row_bytes,base_key_row_bytes,query_position_offset,kv_position_offset,sliding_window,v_row_stride,page_size,block_count,contiguous_base_token,contiguous_blocks,format,v_element_bytes,has_sinks;float softcap;uint swa_scan_clamp;};
kernel void prefill_simd_float(device const float*q[[buffer(0)]],device const half*k[[buffer(1)]],device const half*v[[buffer(2)]],device const uint*blocks[[buffer(3)]],device const float*sinks[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]],uint tid[[thread_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]]){
 const uint q0=group.x*16,h=group.y,kh=h/(p.num_heads/p.num_kv_heads),kw=p.key_row_bytes/2;
 const uint fragment_row=((lane&16)>>2)+((lane>>1)&3),fragment_col=((lane&8)>>1)+((lane&1)<<1);
 threadgroup float qs[16*128],kv[32*128],scores[16*32],prob[16*32],maxima[16],denom[16],correction[16];threadgroup atomic_uint nonfinite_v;
 if(tid<16){maxima[tid]=-INFINITY;denom[tid]=0;}
 simdgroup_float8x8 out[2][2][4];
 for(uint part=0;part<2;part++)for(uint j=0;j<2;j++)for(uint d=0;d<4;d++)out[part][j][d]=make_filled_simdgroup_matrix<float,8>(0.0f);
 uint end=min(p.kv_tokens,p.query_position_offset+min(q0+16,p.q_len)-p.kv_position_offset);
 for(uint start=0;start<end;start+=32){
  simdgroup_float8x8 dots[2];dots[0]=make_filled_simdgroup_matrix<float,8>(0.0f);dots[1]=make_filled_simdgroup_matrix<float,8>(0.0f);
  for(uint part=0;part<2;part++){
   threadgroup_barrier(mem_flags::mem_threadgroup);
   for(uint i=tid;i<16*128;i+=128){uint row=i/128,d=part*128+i%128;qs[i]=q0+row<p.q_len?q[((q0+row)*p.num_heads+h)*256+d]:0;}
   for(uint i=tid;i<32*128;i+=128){uint t=start+i/128,d=part*128+i%128,physical=t<p.kv_tokens?blocks[t/p.page_size]+t%p.page_size:0;kv[i]=t<p.kv_tokens?float(k[physical*kw+kh*256+d]):0;}
   threadgroup_barrier(mem_flags::mem_threadgroup);
   for(uint d=0;d<128;d+=8){simdgroup_float8x8 mk;simdgroup_load(mk,kv+sg*8*128+d,128,0,true);
    for(uint j=0;j<2;j++){simdgroup_float8x8 mq;simdgroup_load(mq,qs+j*8*128+d,128);simdgroup_multiply_accumulate(dots[j],mq,mk,dots[j]);}
   }
  }
  for(uint j=0;j<2;j++)simdgroup_store(dots[j],scores+j*8*32+sg*8,32);
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint pass=0;pass<4;pass++){
   uint row=sg+pass*4,t=start+lane;bool valid=q0+row<p.q_len&&t<p.kv_tokens&&t+p.kv_position_offset<=p.query_position_offset+q0+row;
   float x=valid?scores[row*32+lane]*.0625f:-INFINITY;if(!isfinite(x))x=-INFINITY;
   float m=simd_max(x),nm=max(maxima[row],m),c=isfinite(maxima[row])&&isfinite(nm)?exp(maxima[row]-nm):0;
   float e=isfinite(x)?exp(x-nm):0;prob[row*32+lane]=e;float sum=simd_sum(e);if(lane==0){maxima[row]=nm;denom[row]=denom[row]*c+sum;correction[row]=c;}
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint part=0;part<2;part++)for(uint j=0;j<2;j++)for(uint d=0;d<4;d++)for(uint e=0;e<2;e++){
   float c=correction[j*8+fragment_row];out[part][j][d].thread_elements()[e]=c==0?0:out[part][j][d].thread_elements()[e]*c;
  }
  for(uint part=0;part<2;part++){
   threadgroup_barrier(mem_flags::mem_threadgroup);if(tid==0)atomic_store_explicit(&nonfinite_v,0,memory_order_relaxed);threadgroup_barrier(mem_flags::mem_threadgroup);
   for(uint i=tid;i<32*128;i+=128){uint t=start+i/128,d=part*128+i%128,physical=t<p.kv_tokens?blocks[t/p.page_size]+t%p.page_size:0;float value=t<p.kv_tokens?float(v[physical*p.v_row_stride+kh*256+d]):0;kv[i]=value;if(!isfinite(value))atomic_store_explicit(&nonfinite_v,1,memory_order_relaxed);}
   threadgroup_barrier(mem_flags::mem_threadgroup);
   if(atomic_load_explicit(&nonfinite_v,memory_order_relaxed)==0){
    for(uint t=0;t<32;t+=8)for(uint j=0;j<2;j++){simdgroup_float8x8 mp;simdgroup_load(mp,prob+j*8*32+t,32);
     for(uint d=0;d<4;d++){simdgroup_float8x8 mv;simdgroup_load(mv,kv+t*128+sg*32+d*8,128);simdgroup_multiply_accumulate(out[part][j][d],mp,mv,out[part][j][d]);}
    }
   }else for(uint j=0;j<2;j++)for(uint d=0;d<4;d++)for(uint e=0;e<2;e++){
    uint row=j*8+fragment_row,col=sg*32+d*8+fragment_col+e;float sum=0;for(uint t=0;t<32;t++){float w=prob[row*32+t];if(w!=0)sum+=w*kv[t*128+col];}out[part][j][d].thread_elements()[e]+=sum;
   }
  }
 }
 for(uint part=0;part<2;part++)for(uint j=0;j<2;j++)for(uint dc=0;dc<4;dc++)for(uint e=0;e<2;e++){
  uint row=j*8+fragment_row,d=part*128+sg*32+dc*8+fragment_col+e;if(q0+row>=p.q_len)continue;
  float value=denom[row]>0?out[part][j][dc].thread_elements()[e]/denom[row]:0;
  if(denom[row]==0){float sum=0;for(uint t=0;t<p.kv_tokens;t++){bool allowed=t+p.kv_position_offset<=p.query_position_offset+q0+row;uint physical=allowed?blocks[t/p.page_size]+t%p.page_size:0;sum+=float(v[physical*p.v_row_stride+kh*256+d]);}value=sum/float(p.kv_tokens);}
  y[((q0+row)*p.num_heads+h)*256+d]=value;
 }
}
