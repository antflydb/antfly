#include <metal_stdlib>
#include <metal_tensor>
#include <MetalPerformancePrimitives/MetalPerformancePrimitives.h>
using namespace metal;using namespace mpp::tensor_ops;
struct Params {uint q_len,kv_tokens,num_heads,num_kv_heads,head_dim,key_row_bytes,base_key_row_bytes,query_position_offset,kv_position_offset,sliding_window,v_row_stride,page_size,block_count,contiguous_base_token,contiguous_blocks,format,v_element_bytes,has_sinks;float softcap;uint swa_scan_clamp;};
kernel void prefill_direct(device float*q[[buffer(0)]],device half*k[[buffer(1)]],device half*v[[buffer(2)]],device const uint*blocks[[buffer(3)]],device const float*sinks[[buffer(4)]],device float*y[[buffer(5)]],constant Params&p[[buffer(6)]],uint2 group[[threadgroup_position_in_grid]],uint tid[[thread_index_in_threadgroup]],uint lane[[thread_index_in_simdgroup]],uint sg[[simdgroup_index_in_threadgroup]]){
 const uint q0=group.x*32,h=group.y,kh=h/(p.num_heads/p.num_kv_heads),kw=p.key_row_bytes/2;
 threadgroup float scores[32*32],prob[32*32],maxima[32],denom[32],correction[32];threadgroup atomic_uint nonfinite_v;
 if(tid<32){maxima[tid]=-INFINITY;denom[tid]=0;}
 tensor<device float,dextents<int,2>,tensor_inline>qa(q+h*256,dextents<int,2>(256,p.q_len),array<int,2>{1,int(p.num_heads*256)});auto Q=qa.slice(0,int(q0));
 tensor<threadgroup float,dextents<int,2>,tensor_inline>S(scores+sg*8,dextents<int,2>(8,32),array<int,2>{1,32});
 tensor<threadgroup float,dextents<int,2>,tensor_inline>Pbase(prob,dextents<int,2>(16,32),array<int,2>{1,32});
 tensor<device half,dextents<int,2>,tensor_inline>Vbase(v+kh*256+sg*64,dextents<int,2>(64,16),array<int,2>{1,int(p.v_row_stride)});
 constexpr auto qkd=matmul2d_descriptor(32,8,256,false,true,false);
 constexpr auto pvd=matmul2d_descriptor(32,64,16,false,false,false,matmul2d_descriptor::mode::multiply_accumulate);
 matmul2d<qkd,execution_simdgroups<1>>qkop;matmul2d<pvd,execution_simdgroups<1>>pvop;
 auto out=pvop.get_destination_cooperative_tensor<decltype(Pbase),decltype(Vbase),float>();for(ushort i=0;i<out.get_capacity();i++)out[i]=0;
 uint end=min(p.kv_tokens,p.query_position_offset+min(q0+32,p.q_len)-p.kv_position_offset);
 for(uint start=0;start<end;start+=32){
  threadgroup_barrier(mem_flags::mem_threadgroup);
  uint key=start+sg*8,count=key<p.kv_tokens?min(8u,p.kv_tokens-key):0;
  if(count){
   uint physical=blocks[key/p.page_size]+key%p.page_size;
   tensor<device half,dextents<int,2>,tensor_inline>K(k+physical*kw+kh*256,dextents<int,2>(256,count),array<int,2>{1,int(kw)});
   auto dots=qkop.get_destination_cooperative_tensor<decltype(Q),decltype(K),float>();qkop.run(Q,K,dots);dots.store(S);
  }else for(uint i=lane;i<32*8;i+=32)scores[(i/8)*32+sg*8+i%8]=0;
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint pass=0;pass<8;pass++){
   uint row=sg+pass*4,t=start+lane;bool valid=q0+row<p.q_len&&t<p.kv_tokens&&t+p.kv_position_offset<=p.query_position_offset+q0+row;
   float x=valid?scores[row*32+lane]*.0625f:-INFINITY;if(!isfinite(x))x=-INFINITY;
   float m=simd_max(x),nm=max(maxima[row],m),c=isfinite(maxima[row])&&isfinite(nm)?exp(maxima[row]-nm):0;
   float e=isfinite(x)?exp(x-nm):0;prob[row*32+lane]=e;float sum=simd_sum(e);if(lane==0){maxima[row]=nm;denom[row]=denom[row]*c+sum;correction[row]=c;}
  }
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);float scale=correction[c[1]];out[i]=scale==0?0:out[i]*scale;}
  if(tid==0)atomic_store_explicit(&nonfinite_v,0,memory_order_relaxed);threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint i=tid;i<32*256;i+=128){uint t=start+i/256,d=i%256;if(t<p.kv_tokens){uint physical=blocks[t/p.page_size]+t%p.page_size;if(!isfinite(v[physical*p.v_row_stride+kh*256+d]))atomic_store_explicit(&nonfinite_v,1,memory_order_relaxed);}}
  threadgroup_barrier(mem_flags::mem_threadgroup);
  if(atomic_load_explicit(&nonfinite_v,memory_order_relaxed)==0){
   for(uint part=0;part<2;part++){uint key=start+part*16;if(key>=p.kv_tokens)break;uint count=min(16u,p.kv_tokens-key),physical=blocks[key/p.page_size]+key%p.page_size;
    tensor<threadgroup float,dextents<int,2>,tensor_inline>P(prob+part*16,dextents<int,2>(count,32),array<int,2>{1,32});
    tensor<device half,dextents<int,2>,tensor_inline>V(v+physical*p.v_row_stride+kh*256+sg*64,dextents<int,2>(64,count),array<int,2>{1,int(p.v_row_stride)});
    pvop.run(P,V,out);
   }
  }else for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);uint row=c[1],d=sg*64+c[0];float sum=0;for(uint t=0;t<32&&start+t<p.kv_tokens;t++){float w=prob[row*32+t];if(w!=0){uint key=start+t,physical=blocks[key/p.page_size]+key%p.page_size;sum+=w*float(v[physical*p.v_row_stride+kh*256+d]);}}out[i]+=sum;}
 }
 for(ushort i=0;i<out.get_capacity();i++){auto c=out.get_multidimensional_index(i);uint row=c[1],d=sg*64+c[0];if(q0+row>=p.q_len)continue;float value=denom[row]>0?out[i]/denom[row]:0;
  if(denom[row]==0){float sum=0;for(uint t=0;t<p.kv_tokens;t++){bool allowed=t+p.kv_position_offset<=p.query_position_offset+q0+row;uint physical=allowed?blocks[t/p.page_size]+t%p.page_size:0;sum+=float(v[physical*p.v_row_stride+kh*256+d]);}value=sum/float(p.kv_tokens);}
  y[((q0+row)*p.num_heads+h)*256+d]=value;
 }
}
