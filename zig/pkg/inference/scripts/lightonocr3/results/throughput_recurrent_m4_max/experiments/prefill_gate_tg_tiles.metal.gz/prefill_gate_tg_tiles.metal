template<uint S,uint N> inline void pair_prefill_gate_body(device float*x,device bfloat*w,device float*bias,device float*y,constant Params&p,threadgroup float*tmp,uint2 group,uint sg,uint tid){
 const uint chunk=p.in_dim/S,row=group.y*8,col=group.x*N;
 tensor<device float,dextents<int,2>,tensor_inline>a(x+sg*chunk,dextents<int,2>(chunk,p.rows),array<int,2>{1,int(p.in_dim)});
 tensor<device bfloat,dextents<int,2>,tensor_inline>b(w+sg*chunk,dextents<int,2>(chunk,p.out_dim),array<int,2>{1,int(p.in_dim)});
 tensor<threadgroup float,dextents<int,2>,tensor_inline>dest(tmp+sg*8*N,dextents<int,2>(N,8),array<int,2>{1,int(N)});
 auto left=a.slice(0,int(row));auto right=b.slice(0,int(col));
 constexpr auto desc=matmul2d_descriptor(8,N,dynamic_length_v<int>,false,true,false);matmul2d<desc,execution_simdgroups<1>>op;
 auto result=op.template get_destination_cooperative_tensor<decltype(left),decltype(right),float>();op.run(left,right,result);result.store(dest);
 threadgroup_barrier(mem_flags::mem_threadgroup);
 for(uint i=tid;i<min(8u,p.rows-row)*N;i+=S*32){float sum=0;
  #pragma unroll
  for(uint j=0;j<S;j++)sum+=tmp[j*8*N+i];
  uint c=col+i%N;if(c<p.out_dim)y[(row+i/N)*p.out_dim+c]=sum+bias[c];
 }
}
#define PN(S,N) kernel void pair_prefill_gate##S##_##N(device float*x[[buffer(0)]],device bfloat*w[[buffer(1)]],device float*b[[buffer(2)]],device float*y[[buffer(3)]],constant Params&p[[buffer(4)]],threadgroup float*tmp[[threadgroup(0)]],uint2 group[[threadgroup_position_in_grid]],uint sg[[simdgroup_index_in_threadgroup]],uint tid[[thread_index_in_threadgroup]]){pair_prefill_gate_body<S,N>(x,w,b,y,p,tmp,group,sg,tid);}
PN(4,16) PN(8,16) PN(16,16) PN(8,32) PN(16,32)
#undef PN
