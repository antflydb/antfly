from pathlib import Path
import json,sys
h=Path('.venv-lighton-vllm-metal');qt=int(sys.argv[1]);src=(h/'prefill_direct.metal').read_text();src='#define QT '+str(qt)+'\n#define KT 64\n'+src
src=src.replace('prefill_direct(',f'prefill_direct64_{qt}(').replace('q0=group.x*32','q0=group.x*QT').replace('scores[32*32],prob[32*32],maxima[32],denom[32],correction[32]','scores[QT*KT],prob[QT*KT],maxima[QT],denom[QT],correction[QT]').replace('tid<32','tid<QT').replace('S(scores+sg*8,dextents<int,2>(8,32),array<int,2>{1,32})','S(scores+sg*16,dextents<int,2>(16,QT),array<int,2>{1,KT})').replace('Pbase(prob,dextents<int,2>(16,32),array<int,2>{1,32})','Pbase(prob,dextents<int,2>(16,QT),array<int,2>{1,KT})').replace('descriptor(32,8,256','descriptor(QT,16,256').replace('descriptor(32,64,16','descriptor(QT,64,16').replace('q0+32','q0+QT').replace('start+=32','start+=KT').replace('key=start+sg*8,count=key<p.kv_tokens?min(8u','key=start+sg*16,count=key<p.kv_tokens?min(16u').replace('i<32*8;i+=32)scores[(i/8)*32+sg*8+i%8]','i<QT*16;i+=32)scores[(i/16)*KT+sg*16+i%16]')
a=src.index('  for(uint pass=0;pass<8;pass++){');b=src.index('  threadgroup_barrier(mem_flags::mem_threadgroup);',a)
src=src[:a]+'''  for(uint pass=0;pass<QT/4;pass++){
   uint row=sg+pass*4;float x[2],m=-INFINITY;
   for(uint j=0;j<2;j++){uint t=start+lane+j*32;bool valid=q0+row<p.q_len&&t<p.kv_tokens&&t+p.kv_position_offset<=p.query_position_offset+q0+row;x[j]=valid?scores[row*KT+lane+j*32]*.0625f:-INFINITY;if(!isfinite(x[j]))x[j]=-INFINITY;m=max(m,x[j]);}
   m=simd_max(m);float nm=max(maxima[row],m),c=isfinite(maxima[row])&&isfinite(nm)?exp(maxima[row]-nm):0,sum=0;
   for(uint j=0;j<2;j++){float e=isfinite(x[j])?exp(x[j]-nm):0;prob[row*KT+lane+j*32]=e;sum+=e;}
   sum=simd_sum(sum);if(lane==0){maxima[row]=nm;denom[row]=denom[row]*c+sum;correction[row]=c;}
  }
'''+src[b:]
src=src.replace('i<32*256','i<KT*256').replace('part<2;part++){uint key=start+part*16','part<KT/16;part++){uint key=start+part*16').replace('P(prob+part*16,dextents<int,2>(count,32),array<int,2>{1,32})','P(prob+part*16,dextents<int,2>(count,QT),array<int,2>{1,KT})').replace('t<32&&start+t','t<KT&&start+t').replace('prob[row*32+t]','prob[row*KT+t]');(h/f'prefill_direct64_{qt}.metal').write_text(src)
s=(h/'prefill_direct_bridge.m').read_text();a=s.index('static NSString*float_source(void)');b=s.index('typedef struct',a);s=s[:a]+'static NSString*float_source(void){return @""\n'+''.join(' '+json.dumps(x+'\n')+'\n'for x in src.splitlines())+';}\n'+s[b:];s=s.replace('@"prefill_direct"',f'@"prefill_direct64_{qt}"')
if qt in [8,16]:s=s.replace('b->r->lightonocr3_prefill_attention_mpp32_pipeline=termite_metal_make_pipeline','b->r->lightonocr3_prefill_attention_mpp32_pipeline=nil;\n        b->r->lightonocr3_prefill_attention_mpp_pipeline=termite_metal_make_pipeline').replace('if(!b->r->lightonocr3_prefill_attention_mpp32_pipeline)return NULL;','if(!b->r->lightonocr3_prefill_attention_mpp_pipeline)return NULL;')
(h/f'prefill_direct64_{qt}_bridge.m').write_text(s)
s=(h/'benchmark_prefill_direct_pair.py').read_text().replace('prefill-direct-pair.dylib',f'prefill-direct64-{qt}-pair.dylib').replace("h/'prefill_direct_bridge.m'",f"h/'prefill_direct64_{qt}_bridge.m'").replace("h/'prefill_direct.metal'",f"h/'prefill_direct64_{qt}.metal'").replace('prefill_attention_mlx_direct_candidate.json',f'prefill_attention_mlx_direct64_{qt}_candidate.json').replace('Experimental direct paged-KV TensorOps tile',f'Experimental direct paged-KV TensorOps query{qt}/key64 tile');(h/f'benchmark_prefill_direct64_{qt}_pair.py').write_text(s)
