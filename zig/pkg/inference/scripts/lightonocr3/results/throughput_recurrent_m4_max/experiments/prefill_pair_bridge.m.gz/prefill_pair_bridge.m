#include "../zig/pkg/inference/src/backends/metal_kernels.m"
typedef struct {
    termite_metal_decode_runtime *r;
    id<MTLBuffer> q, k, v, y;
    uint32_t *blocks;
    size_t n, heads, kh, block_count;
} PrefillPair;
void *prefill_pair_create(size_t n,size_t heads,const float*q,const uint16_t*k,const uint16_t*v) {
    @autoreleasepool {
        PrefillPair *b=calloc(1,sizeof(*b));if(!b)return NULL;
        b->r=termite_metal_decode_runtime_create();if(!b->r){free(b);return NULL;}
        termite_metal_decode_runtime_set_lightonocr3_projections(b->r,1);
        termite_metal_decode_runtime_set_qwen35_ocr_vector_loads(b->r,1);
        b->n=n;b->heads=heads;b->kh=heads/4;b->block_count=(n+127)/128;
        b->q=[b->r->device newBufferWithBytes:q length:n*heads*256*4 options:MTLResourceStorageModeShared];
        b->k=[b->r->device newBufferWithLength:b->block_count*128*b->kh*256*2 options:MTLResourceStorageModeShared];
        b->v=[b->r->device newBufferWithLength:b->k.length options:MTLResourceStorageModeShared];
        b->y=[b->r->device newBufferWithLength:n*heads*256*4 options:MTLResourceStorageModeShared];
        b->blocks=calloc(b->block_count,4);if(!b->q||!b->k||!b->v||!b->y||!b->blocks)return NULL;
        for(size_t page=0;page<b->block_count;page++)b->blocks[page]=(uint32_t)((b->block_count-1-page)*128);
        for(size_t t=0;t<n;t++){
            size_t p=b->blocks[t/128]+t%128;
            memcpy((char*)b->k.contents+p*b->kh*256*2,k+t*b->kh*256,b->kh*256*2);
            memcpy((char*)b->v.contents+p*b->kh*256*2,v+t*b->kh*256,b->kh*256*2);
        }
        b->r->attention_span_encoded_key_buffers[7]=b->k;b->r->attention_span_v_buffers[7]=b->v;
        b->r->attention_span_slot_key_row_bytes[7]=b->kh*256*2;b->r->attention_span_slot_v_row_stride[7]=b->kh*256;
        return b;
    }
}
int prefill_pair_run(void *raw,double *gpu_us){
    @autoreleasepool {
        PrefillPair*b=raw;uint64_t count=b->r->lightonocr3_prefill_attention_mpp_dispatches;
        if(termite_metal_decode_runtime_begin_frame(b->r)||
           termite_metal_decode_runtime_attention_paged_slot_device(b->r,7,3,(__bridge void*)b->q,0,b->blocks,b->block_count,128,b->n,b->n,b->heads,b->kh,256,b->kh*256*2,b->kh*256*2,0,0,0,0,NULL,0,(__bridge void*)b->y,0)||
           termite_metal_decode_runtime_submit_frame(b->r)||termite_metal_decode_runtime_wait_frame(b->r))return -1;
        if(b->r->lightonocr3_prefill_attention_mpp_dispatches!=count+1)return -2;
        *gpu_us=b->r->last_frame_gpu_nanos/1000.0;return 0;
    }
}
const float *prefill_pair_output(void *raw){PrefillPair*b=raw;return b->y.contents;}
void prefill_pair_destroy(void *raw){
    if(!raw)return;PrefillPair*b=raw;termite_metal_decode_runtime_destroy(b->r);
    b->q=nil;b->k=nil;b->v=nil;b->y=nil;free(b->blocks);free(b);
}
