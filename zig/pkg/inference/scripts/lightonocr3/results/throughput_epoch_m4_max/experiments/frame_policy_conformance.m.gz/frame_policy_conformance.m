#include "../zig/pkg/inference/src/backends/metal_kernels.m"
#include <assert.h>
int main(void) {
 @autoreleasepool {
  termite_metal_decode_runtime *r=calloc(1,sizeof(*r));assert(r);
  const termite_metal_frame_env_key key=TERMITE_METAL_FRAME_DISABLE_LIGHTONOCR3_GEMV;
  const char *flag=termite_metal_frame_env_names[key];
  setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY","1",1);
  setenv(flag,"0",1);r->lightonocr3_projections_enabled=YES;
  // Real Objective-C ownership, no GPU work: these tests exercise policy
  // lifetime independently of Metal command submission.
  r->active_frame_cb=(id<MTLCommandBuffer>)[NSObject new];
  termite_metal_snapshot_lighton_frame_policy(r);
  assert(!termite_metal_frame_env_enabled(r,key));
  setenv(flag,"1",1);assert(!termite_metal_frame_env_enabled(r,key));
  r->active_frame_cb=nil;assert(termite_metal_frame_env_enabled(r,key));
  r->active_frame_cb=(id<MTLCommandBuffer>)[NSObject new];
  termite_metal_snapshot_lighton_frame_policy(r);assert(termite_metal_frame_env_enabled(r,key));
  assert(termite_metal_decode_runtime_lighton_frame_policy_snapshots(r)==2);
  const char *falsy[]={"","0","false","no","off"};
  for(unsigned i=0;i<sizeof(falsy)/sizeof(*falsy);i++){
   setenv(flag,falsy[i],1);termite_metal_snapshot_lighton_frame_policy(r);
   assert(!termite_metal_frame_env_enabled(r,key));
  }
  // Legacy profiling/barrier switches intentionally treat "false" as on.
  setenv("TERMITE_METAL_PLANNED_ACCESS_PROFILE","false",1);
  setenv("TERMITE_METAL_DISABLE_PLANNED_COMPUTE_BARRIERS","false",1);
  termite_metal_snapshot_lighton_frame_policy(r);
  assert(termite_metal_planned_access_profile_enabled(r));
  assert(!termite_metal_planned_compute_barriers_enabled(r));
  r->concurrent_planned_dispatch_enabled=YES;
  assert(termite_metal_planned_compute_barriers_enabled(r));
  r->concurrent_planned_dispatch_enabled=NO;
  setenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY","0",1);
  termite_metal_snapshot_lighton_frame_policy(r);setenv(flag,"1",1);
  assert(termite_metal_frame_env_enabled(r,key));assert(!r->lighton_frame_policy_valid);
  r->active_frame_cb=nil;free(r);
  puts("frame policy: frame refresh, in-frame stability, inactive fallback, falsy flags, legacy switches and concurrent barrier safety passed");
 }
}
