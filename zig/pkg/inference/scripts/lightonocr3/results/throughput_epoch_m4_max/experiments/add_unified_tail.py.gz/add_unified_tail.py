from pathlib import Path
r=Path.cwd()
p=r/'zig/pkg/inference/src/ops/metal_compute.zig';s=p.read_text();s=s.replace('    retain_weight_handles: bool = false,','    retain_weight_handles: bool = false,\n    unified_decode: bool = false,',1).replace('            .retain_weight_handles = retain_handles,','            .retain_weight_handles = retain_handles,\n            .unified_decode = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_UNIFIED_DECODE"),',1).replace('    lightonocr3_policy: LightOnRuntimePolicy = .{},','    lightonocr3_policy: LightOnRuntimePolicy = .{},\n    lightonocr3_unified_decode_steps: usize = 0,',1)
a='    pub fn lightOnDirectCoreOutputEnabled(cb: *const ops.ComputeBackend) bool {'
s=s.replace(a,'''    pub fn lightOnUnifiedDecodeEnabled(cb: *const ops.ComputeBackend) bool {
        if (cb.kind() != .metal) return false;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return self.lightonocr3_projections and self.lightonocr3_policy.unified_decode and
            metal_runtime.qualifiedM4DeviceDefault();
    }

    pub fn noteLightOnUnifiedDecodeStep(cb: *const ops.ComputeBackend) void {
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        self.lightonocr3_unified_decode_steps += 1;
    }

    pub fn lightOnUnifiedDecodeSteps(cb: *const ops.ComputeBackend) usize {
        if (cb.kind() != .metal) return 0;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return self.lightonocr3_unified_decode_steps;
    }

'''+a,1)
a=s.index('test "LightOnOCR3 runtime policy snapshots');b=s.index('\nfn checkLightOnWeightDescriptors',a);part=s[a:b].replace('        "TERMITE_METAL_ENABLE_LIGHTONOCR3_WEIGHT_HANDLES",','        "TERMITE_METAL_ENABLE_LIGHTONOCR3_WEIGHT_HANDLES",\n        "ANTFLY_LIGHTONOCR3_UNIFIED_DECODE",',1);part=part.replace('    try std.testing.expect(!LightOnRuntimePolicy.fromEnvironment().retain_weight_handles);\n}', '''    try std.testing.expect(!LightOnRuntimePolicy.fromEnvironment().retain_weight_handles);
    try std.testing.expect(disabled.unified_decode and enabled.unified_decode);
    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[5], "0", 1));
    try std.testing.expect(!LightOnRuntimePolicy.fromEnvironment().unified_decode);
    try std.testing.expect(enabled.unified_decode);
}''',1);s=s[:a]+part+s[b:];p.write_text(s)
p=r/'zig/pkg/inference/src/pipelines/generation.zig';s=p.read_text();anchor='            const hidden = try gpt_arch.forwardHiddenTensorWithCudaReplay(&self.cb, self.allocator, self.gpt_config, input_ids, claimed.len, max_query_seq_len, &owned_ctx.context, "gpt.metal_batch_decode");';assert s.count(anchor)==1
s=s.replace(anchor,'''            // A caller-owned frame can carry the same decoder and vocabulary
            // projection through token selection. On failure cancel the frame;
            // never replay a forward that has already updated KV/recurrent state.
            if (comptime build_options.enable_metal) {
                if (self.gpt_config.hasQwen35VisionArchitectureContract() and claimed.len <= 8 and
                    @import("../ops/metal_compute.zig").MetalCompute.lightOnUnifiedDecodeEnabled(&self.cb) and
                    !self.cb.decoderRuntimeHasActiveFrame())
                {
                    const head = try self.graphWeight("lm_head.weight");
                    defer self.cb.free(head);
                    if (try self.cb.decoderRuntimeBeginFrame()) {
                        defer self.cb.decoderRuntimeCancelFrame() catch {};
                        try self.cb.decoderRuntimeSetActiveFrameRegime(.decode);
                        try self.cb.checkExecutionControl();
                        const hidden = try gpt_arch.forwardHiddenTensorWithCudaReplay(&self.cb, self.allocator, self.gpt_config, input_ids, claimed.len, 1, &owned_ctx.context, "gpt.metal_batch_decode");
                        defer self.cb.free(hidden);
                        const logits = try self.cb.linearNoBias(hidden, head, claimed.len, self.gpt_config.hidden_size, self.gpt_config.vocab_size);
                        defer self.cb.free(logits);
                        var choices = try self.cb.decoderRuntimeArgmaxRowsSuppress(logits, 0, claimed.len, self.gpt_config.vocab_size, self.gpt_config.suppressTokenIds(), self.allocator);
                        if (choices == null) {
                            try self.cb.decoderRuntimeSubmitAndWaitFrame();
                            choices = try self.cb.argmaxRowsSuppress(logits, 0, claimed.len, self.gpt_config.vocab_size, self.gpt_config.suppressTokenIds(), self.allocator);
                        }
                        const tokens = choices orelse return error.ResidentImageOperationUnavailable;
                        errdefer self.allocator.free(tokens);
                        if (tokens.len != claimed.len) return error.InvalidBatchDecodeState;
                        try self.cb.checkExecutionControl();
                        @import("../ops/metal_compute.zig").MetalCompute.noteLightOnUnifiedDecodeStep(&self.cb);
                        return .{ .logits = null, .greedy_tokens = tokens, .max_query_seq_len = 1 };
                    }
                }
            }

'''+anchor,1);p.write_text(s)
p=r/'zig/pkg/inference/src/server/server.zig';s=p.read_text().replace('            "ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK",','            "ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK",\n            "ANTFLY_LIGHTONOCR3_UNIFIED_DECODE",',1).replace('or std.mem.eql(u8, policy, "gateoff");','or std.mem.eql(u8, policy, "gateoff") or std.mem.eql(u8, policy, "tail");',1).replace('or std.mem.eql(u8, policy, "gateoff")) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;','or std.mem.eql(u8, policy, "gateoff") or std.mem.eql(u8, policy, "tail")) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;',1)
a='                if (Env.setenv(policy_flags[22],';i=s.index(a);j=s.index('\n',i);s=s[:j]+'\n                if (Env.setenv(policy_flags[23], if (std.mem.eql(u8, policy, "tail")) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;'+s[j:]
a='                    const t = cb.debugTimingSnapshot().provider;';assert a in s;s=s.replace(a,a+'\n                    const unified = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnUnifiedDecodeSteps(&cb) else 0;\n                    std.debug.print("LIGHTONOCR3 unified_decode_steps={d}\\n", .{unified});',1);p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';s=p.read_text().replace('            "ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK",','            "ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK",\n            "ANTFLY_LIGHTONOCR3_UNIFIED_DECODE",',1).replace('            "gateoff",\n            "direct",','            "gateoff",\n            "tail",\n            "direct",',1).replace('                    "gateoff",\n                )','                    "gateoff",\n                    "tail",\n                )',1)
a='        if args.require_execution_gate_wait:\n';assert a in s;s=s.replace(a,'''        if args.require_unified_decode:
            rounds = result.get("policy_rounds", [])
            if not rounds:
                result["status"] = "unified_decode_requires_policy_rounds"
            for sample in rounds:
                enabled = sample["policy"] == "tail" or (sample["policy"] == "current" and args.unified_decode)
                if enabled != (sample["unified_decode_steps"] > 0):
                    result["status"] = "unified_decode_control_mismatch"
'''+a,1)
a='                    frames = re.findall(\n';assert a in s;s=s.replace(a,'''                    sample["unified_decode_steps"] = sum(
                        int(value) for value in re.findall(r"LIGHTONOCR3 unified_decode_steps=(\\d+)", section)
                    )
'''+a,1)
a='    if args.contention_wait_us is not None:';assert a in s;s=s.replace(a,'''    if args.unified_decode:
        env["ANTFLY_LIGHTONOCR3_UNIFIED_DECODE"] = "1"
'''+a,1)
a='    parser.add_argument("--require-execution-gate-wait", action="store_true")';assert a in s;s=s.replace(a,a+'\n    parser.add_argument("--unified-decode", action="store_true")\n    parser.add_argument("--require-unified-decode", action="store_true")',1);p.write_text(s)
