#include "../zig/pkg/inference/src/backends/metal_kernels.m"
int main(void) {
 @autoreleasepool {
  termite_metal_decode_runtime *r=termite_metal_decode_runtime_create();
  if(!r)return 2;
  for(int scenario=0;scenario<5;scenario++){
   float x[32]; for(int j=0;j<32;j++)x[j]=-2;
   x[3]=4;x[22]=4;
   if(scenario==1){x[6]=5;x[19]=5;}
   if(scenario==2){x[6]=4;x[19]=4;}
   if(scenario==3){x[0]=NAN;x[16]=NAN;x[3]=INFINITY;x[22]=INFINITY;}
   if(scenario==4){for(int j=0;j<32;j++)x[j]=-INFINITY;x[0]=NAN;x[16]=NAN;}
   id<MTLBuffer>b=[r->device newBufferWithBytes:x length:sizeof(x) options:MTLResourceStorageModeShared];
   uint32_t out[2]={999,999};
   int rc=termite_metal_decode_runtime_argmax_from_logits_rows_suppress_device(r,(__bridge void*)b,0,2,16,NULL,0,out,0);
   printf("scenario=%d rc=%d tokens=%u,%u\n",scenario,rc,out[0],out[1]);
  }
  termite_metal_decode_runtime_destroy(r);
 }
}
