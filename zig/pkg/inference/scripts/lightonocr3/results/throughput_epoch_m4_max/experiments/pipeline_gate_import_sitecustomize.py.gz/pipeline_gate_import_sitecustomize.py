import os,json,sys,importlib.abc,importlib.machinery
from pathlib import Path
from collections import Counter
class GateLoader(importlib.abc.Loader):
 def __init__(self,inner):self.inner=inner
 def create_module(self,spec):return self.inner.create_module(spec)
 def exec_module(self,module):
  self.inner.exec_module(module)
  original=module.DecodePipeline.begin_step
  counts=Counter()
  def begin(self,decision):
   value=original(self,decision)
   if Path(os.environ['OCR_PIPELINE_GATE_MARKER']).exists():
    counts[decision.reason]+=1
    Path(os.environ['OCR_PIPELINE_GATE_DIR'],f'gate-{os.getpid()}.json').write_text(json.dumps(dict(counts)))
   return value
  module.DecodePipeline.begin_step=begin
class GateFinder(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname!='vllm_metal.v1.decode_pipeline':return None
  spec=importlib.machinery.PathFinder.find_spec(fullname,path)
  if spec:spec.loader=GateLoader(spec.loader)
  return spec
sys.meta_path.insert(0,GateFinder())
