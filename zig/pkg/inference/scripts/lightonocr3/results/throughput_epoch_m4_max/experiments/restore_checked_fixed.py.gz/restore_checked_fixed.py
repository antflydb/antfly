from pathlib import Path
import json,gzip,subprocess,tempfile,hashlib,sys
r=Path.cwd();p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_epoch_m4_max';e=p/'experiments'
(e/(sys.argv[1]+'_benchmark_concurrency.py.gz')).write_bytes(gzip.compress((r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').read_bytes(),mtime=0))
d=json.loads((p/'checked_fixed_build_manifest.json').read_text())
with tempfile.TemporaryDirectory(dir='/private/tmp',prefix='ocr-qualified-source-')as td:
 t=Path(td)
 for name in d['runtime_files_sha256']:
  f=t/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(subprocess.check_output(['git','show',d['runtime_commit']+':'+name]))
 subprocess.run(['git','apply','--unsafe-paths','-'],input=gzip.decompress((p/'checked_fixed_runtime.patch.gz').read_bytes()),cwd=t,check=True)
 for name,h in d['runtime_files_sha256'].items():
  raw=(t/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==h;(r/name).write_bytes(raw)
(r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py').write_bytes(gzip.decompress((e/'checked_fixed_benchmark_concurrency.py.gz').read_bytes()))
