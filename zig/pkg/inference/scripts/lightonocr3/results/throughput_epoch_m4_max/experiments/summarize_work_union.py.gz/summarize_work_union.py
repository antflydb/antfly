from pathlib import Path
import json,gzip
p=Path('zig/pkg/inference/scripts/lightonocr3/results/throughput_epoch_m4_max/work_profiles')
for out in p.glob('*/summary.json'):
 s=json.loads(out.read_text())
 if 'observer_window'not in s:continue
 d=out.parent;a,b=s['observer_window'];rows=[]
 for f in d.glob('frames-*.jsonl*'):
  raw=gzip.decompress(f.read_bytes())if f.suffix=='.gz'else f.read_bytes()
  rows += [x for line in raw.splitlines() if a <= (x:=json.loads(line))['gpu_start'] <= x['gpu_end'] <= b]
 intervals=sorted((x['gpu_start'],x['gpu_end'])for x in rows);merged=[]
 for lo,hi in intervals:
  if merged and lo<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],hi)
  else:merged.append([lo,hi])
 busy=sum(hi-lo for lo,hi in merged)*1000
 s.update(observer_elapsed_ms=(b-a)*1000,gpu_busy_union_ms=busy,observed_non_gpu_ms=(b-a)*1000-busy,duplicate_gpu_intervals=len(intervals)-len(set(intervals)),interval_scope='Union of completed command-buffer GPU timestamp intervals wholly within observer window. Non-GPU remainder includes CPU submission, synchronization, scheduling and client/HTTP overhead; it is not solely CPU encoding.')
 out.write_text(json.dumps(s,indent=2)+'\n');print(d.name,s['observer_elapsed_ms'],busy,s['observed_non_gpu_ms'])
