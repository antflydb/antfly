from pathlib import Path
import os,sys,subprocess,threading,time,json,hashlib
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_epoch_m4_max';scripts=r/'zig/pkg/inference/scripts/lightonocr3'
s=(scripts/'benchmark_vllm_metal.py').read_text().replace('from benchmark_antfly_readers import', 'import sys\nsys.path.insert(0, '+repr(str(scripts))+')\nfrom benchmark_antfly_readers import',1)
s=s.replace('            for concurrency in args.concurrency:\n                start = time.perf_counter()', '            for concurrency in args.concurrency:\n                Path(os.environ["OCR_METAL_PROFILE_MARKER"]).write_text(os.environ["OCR_METAL_PROFILE_TAG"])\n                start = time.perf_counter()',1)
s=s.replace('                start = time.perf_counter()', '                observer_start = time.monotonic()\n                start = time.perf_counter()',1)
s=s.replace('                elapsed = time.perf_counter() - start','                elapsed = time.perf_counter() - start\n                observer_end = time.monotonic()\n                Path(os.environ["OCR_METAL_PROFILE_MARKER"]).unlink(missing_ok=True)',1)
s=s.replace('                    \"concurrency\": concurrency,', '                    \"observer_window\": [observer_start, observer_end],\n                    \"concurrency\": concurrency,',1)
s=s.replace('        finally:\n            save()', '        finally:\n            Path(os.environ["OCR_METAL_PROFILE_MARKER"]).unlink(missing_ok=True)\n            save()',1)
anchor='    with (args.output_dir / "server.txt").open("w") as log:'
s=s.replace(anchor,'''    report["instrumented"] = True
    report["execution_flags"] = {key: env.get(key) for key in ("VLLM_METAL_GDN_LAZY_KERNELS", "VLLM_METAL_DECODE_PIPELINE", "VLLM_METAL_COMPILED_MLP")}
    report["observer_library_sha256"] = digest(Path(env["DYLD_INSERT_LIBRARIES"]))
'''+anchor,1)
(v/'benchmark_vllm_work_profile.py').write_text(s)
imports=v/'metal_profile_import';imports.mkdir(exist_ok=True)
(imports/'sitecustomize.py').write_text("""import os,ctypes,json
from pathlib import Path
library=os.environ.get('OCR_METAL_OBSERVER_LIBRARY')
if library:
 ctypes.CDLL(library)
 with (Path(os.environ['OCR_METAL_PROFILE_DIR'])/'profile_imports.txt').open('a') as out:out.write(json.dumps({'pid':os.getpid(),'library':library})+chr(10))
""")
for runtime,model,variant in [x.split(':')for x in sys.argv[1:]]:
 tag=f'{runtime}_{model}_{variant}';trace=p/'work_profiles'/tag;trace.mkdir(parents=True,exist_ok=True);marker=v/(tag+'.active');marker.unlink(missing_ok=True)
 env=os.environ.copy();env.update(OCR_METAL_PROFILE_ALWAYS='1',OCR_METAL_OBSERVER_LIBRARY=str(v/'libmetal_work_profile_v2.dylib'),PYTHONPATH=str(imports)+os.pathsep+env.get('PYTHONPATH',''),DYLD_INSERT_LIBRARIES=str(v/'libmetal_work_profile_v2.dylib'),OCR_METAL_PROFILE_DIR=str(trace),OCR_METAL_PROFILE_MARKER=str(marker),OCR_METAL_PROFILE_TAG=tag)
 if runtime=='native':
  key=model+'_rounds_work_profile_'+variant;out=p/('native_checked_fixed_'+key);log=out/(('lighton'+model)+'-batch-c8.txt');env.update(OCR_REQUESTS='8',OCR_POLICY_ROUNDS='default')
  command=[sys.executable,str(v/'run_checked_fixed_matrix.py'),'checked_fixed',key];stop=threading.Event();window={}
  def monitor():
   while not stop.is_set():
    text=log.read_text()if log.exists()else''
    if 'OCR_CONCURRENCY concurrency='in text:window['end']=time.monotonic();marker.unlink(missing_ok=True);return
    if 'OCR_POLICY round=0'in text and not marker.exists():window['begin']=time.monotonic();marker.write_text(tag)
    stop.wait(.001)
  watcher=threading.Thread(target=monitor);watcher.start()
 else:
  env.update(VLLM_METAL_GDN_LAZY_KERNELS='0'if variant.startswith('gdn_off')else'1',VLLM_METAL_DECODE_PIPELINE='0'if variant.startswith('pipeline_off')else'1',VLLM_METAL_COMPILED_MLP='0')
  command=[sys.executable,str(v/'benchmark_vllm_work_profile.py'),'--python',sys.executable,'--model-dir',str(v/'ocr-models'/('lighton'+model)),'--images',str(r/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(scripts/'corpus/receipt.png'),str(scripts/'corpus/shipping.png'),'--concurrency','8','--requests','8','--max-tokens','256','--kv-cache-blocks','128','--output-dir',str(p/tag)]
 print('START',tag,flush=True)
 try:
  with open('/private/tmp/ocr-work-profile-'+tag+'.txt','w')as f:res=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT)
 finally:
  marker.unlink(missing_ok=True)
  if runtime=='native':stop.set();watcher.join()
 print('DONE',tag,res.returncode,flush=True)
 if res.returncode:sys.exit(res.returncode)
 files=list(trace.glob('frames-*.jsonl'));assert files,tag
 raw_rows=[json.loads(line)for f in files for line in f.read_text().splitlines()]
 if runtime=='native':bounds=[window['begin'],window['end']]
 else:bounds=json.loads((p/tag/'report.json').read_text())['results'][0]['observer_window']
 rows=[x for x in raw_rows if x['gpu_start']>=bounds[0] and x['gpu_end']<=bounds[1]]
 assert rows,(tag,bounds,len(raw_rows))
 assert all(x['status']==4 for x in rows),tag
 counts={}
 for row in rows:
  for name,entry in row['kernels'].items():counts[name]=counts.get(name,0)+entry['dispatches']
 summary=dict(observer_window=bounds,raw_frames=len(raw_rows),scope='Instrumented GPU work, not primary throughput. Command-buffer duration includes all operations in each buffer; counts are not per-kernel GPU attribution.',frames=len(rows),gpu_ms=sum((x['gpu_end']-x['gpu_start'])*1000 for x in rows),dispatches=sum(counts.values()),kernel_dispatches=dict(sorted(counts.items(),key=lambda x:-x[1])),blit_copies=sum(x['blit_copies']for x in rows),blit_bytes=sum(x['blit_bytes']for x in rows),observer_source_sha256=hashlib.sha256((v/'metal_work_profile.m').read_bytes()).hexdigest(),observer_library_sha256=hashlib.sha256((v/'libmetal_work_profile_v2.dylib').read_bytes()).hexdigest())
 (trace/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:val for k,val in summary.items()if k!='kernel_dispatches'}),flush=True)
