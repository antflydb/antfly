from pathlib import Path
import gzip
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';e=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_epoch_m4_max/experiments'
p=r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';(e/'checked_fixed_benchmark_concurrency.py.gz').write_bytes(gzip.compress(p.read_bytes(),mtime=0))
p=r/'zig/pkg/inference/src/ops/metal_compute.zig';s=p.read_text().replace('    retain_weight_handles: bool = false,','    retain_weight_handles: bool = false,\n    stream_forward: bool = false,',1).replace('            .retain_weight_handles = retain_handles,','            .retain_weight_handles = retain_handles,\n            .stream_forward = platform.env.getenvBool("ANTFLY_LIGHTONOCR3_STREAM_FORWARD"),',1).replace('    lightonocr3_policy: LightOnRuntimePolicy = .{},','    lightonocr3_policy: LightOnRuntimePolicy = .{},\n    lightonocr3_streamed_forward_chunks: usize = 0,',1)
anchor='    pub fn lightOnDirectCoreOutputEnabled(cb: *const ops.ComputeBackend) bool {';insert='''    pub fn lightOnStreamForwardEnabled(cb: *const ops.ComputeBackend) bool {
        if (cb.kind() != .metal) return false;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return self.lightonocr3_projections and self.lightonocr3_policy.stream_forward and
            metal_runtime.qualifiedM4DeviceDefault() and metal_runtime.pipelinedDecodeFrameEnabled();
    }

    pub fn noteLightOnStreamForwardChunk(cb: *const ops.ComputeBackend) void {
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        self.lightonocr3_streamed_forward_chunks += 1;
    }

    pub fn lightOnStreamForwardChunks(cb: *const ops.ComputeBackend) usize {
        if (cb.kind() != .metal) return 0;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return self.lightonocr3_streamed_forward_chunks;
    }

''';assert anchor in s;s=s.replace(anchor,insert+anchor,1)
a=s.index('test "LightOnOCR3 runtime policy snapshots');b=s.index('\nfn checkLightOnWeightDescriptors',a);part=s[a:b].replace('        "TERMITE_METAL_ENABLE_LIGHTONOCR3_WEIGHT_HANDLES",','        "TERMITE_METAL_ENABLE_LIGHTONOCR3_WEIGHT_HANDLES",\n        "ANTFLY_LIGHTONOCR3_STREAM_FORWARD",',1);needle='    try std.testing.expect(!LightOnRuntimePolicy.fromEnvironment().retain_weight_handles);\n}';assert needle in part;part=part.replace(needle,'''    try std.testing.expect(!LightOnRuntimePolicy.fromEnvironment().retain_weight_handles);
    try std.testing.expect(disabled.stream_forward and enabled.stream_forward);
    try std.testing.expectEqual(@as(c_int, 0), Env.setenv(names[5], "0", 1));
    try std.testing.expect(!LightOnRuntimePolicy.fromEnvironment().stream_forward);
    try std.testing.expect(enabled.stream_forward);
}''',1);s=s[:a]+part+s[b:];p.write_text(s)
p=r/'zig/pkg/inference/src/architectures/gpt.zig';s=p.read_text();anchor='    // A long-lived Metal frame may recycle a released buffer immediately for';insert='''    const stream_lighton_forward = if (comptime build_options.enable_metal)
        lightOnForwardStreamEligible(config, batch, isDecodeStep(decode_context), owns_qwen3vl_forward_frame) and
            metal_compute_mod.MetalCompute.lightOnStreamForwardEnabled(cb)
    else
        false;
    // A failed begin/encode can leave the preceding chunk in flight. Drain
    // it before the enclosing owner's active-frame cancellation or teardown.
    defer if (stream_lighton_forward) cb.decoderRuntimeWaitSubmittedFrame() catch {};

''';assert anchor in s;s=s.replace(anchor,insert+anchor,1)
a=s.index('    for (0..config.num_hidden_layers) |layer| {',s.index(insert));anchor='        prefetchGemmaCudaLayerWindow(cb, config, layer + 1);';i=s.index(anchor,a);s=s[:i]+'''        // Full-attention bindings and scratch retain their established
        // non-overlap boundary. Encode intervening recurrent layers while
        // the preceding four-layer chunk executes on the same queue.
        if (stream_lighton_forward and !config.layerUsesQwen35LinearAttention(layer)) {
            try cb.decoderRuntimeWaitSubmittedFrame();
            try cb.checkExecutionControl();
        }
'''+s[i:]
anchor='        // Materialize layer groups on lazy backends when the policy asks for a';i=s.index(anchor,a);s=s[:i]+'''        if (stream_lighton_forward and (layer + 1) % 4 == 0 and layer + 1 < config.num_hidden_layers) {
            try rotateLightOnForwardFrame(cb);
            if (comptime build_options.enable_metal) metal_compute_mod.MetalCompute.noteLightOnStreamForwardChunk(cb);
        }
'''+s[i:]
anchor='pub const DenseQwen3PrefillOptions = struct {';insert='''fn lightOnForwardStreamEligible(config: Config, batch: usize, decode: bool, owns_frame: bool) bool {
    if (!decode or !owns_frame or batch == 0 or batch > 8 or !config.hasQwen35VisionArchitectureContract() or
        (config.hidden_size != 1024 and config.hidden_size != 2560) or
        (config.num_hidden_layers != 24 and config.num_hidden_layers != 32)) return false;
    for (0..config.num_hidden_layers) |layer| {
        if (config.layerUsesQwen35LinearAttention(layer) != ((layer + 1) % 4 != 0)) return false;
    }
    return true;
}

/// Keep at most one submitted chunk and one chunk being encoded. Backend
/// frame retention, alternating staging buffers and existing budgets remain
/// authoritative; no token, KV reservation or recurrent step is speculated.
fn rotateLightOnForwardFrame(cb: *const ComputeBackend) !void {
    try cb.checkExecutionControl();
    try cb.decoderRuntimeWaitSubmittedFrame();
    try cb.checkExecutionControl();
    try cb.decoderRuntimeSubmitFrame();
    errdefer cb.decoderRuntimeWaitSubmittedFrame() catch {};
    if (!try cb.decoderRuntimeBeginFrame()) return error.StreamedForwardFrameUnavailable;
    try cb.decoderRuntimeSetActiveFrameRegime(.decode);
    try cb.checkExecutionControl();
}

''';assert anchor in s;s=s.replace(anchor,insert+anchor,1);p.write_text(s)
p=r/'zig/pkg/inference/src/server/server.zig';s=p.read_text();s=s.replace('            "ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK",','            "ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK",\n            "ANTFLY_LIGHTONOCR3_STREAM_FORWARD",',1);s=s.replace(' or std.mem.eql(u8, policy, "gateoff");',' or std.mem.eql(u8, policy, "gateoff") or std.mem.eql(u8, policy, "stream");',1);s=s.replace('or std.mem.eql(u8, policy, "gateoff")) "1" else "0", 1)', 'or std.mem.eql(u8, policy, "gateoff") or std.mem.eql(u8, policy, "stream")) "1" else "0", 1)',1)
anchor='''            }
            std.debug.print("OCR_POLICY round={d} name={s}\\n", .{ round, policy });''';assert anchor in s;s=s.replace(anchor,'''                if (Env.setenv(policy_flags[23], if (std.mem.eql(u8, policy, "stream")) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;
'''+anchor,1)
anchor='''                    std.debug.print("LIGHTONOCR3 runtime_frames={d} frame_gpu_ns={d} frame_wait_ns={d}\\n",''';i=s.index(anchor);s=s[:i]+'''                    const chunks = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnStreamForwardChunks(&cb) else 0;
                    std.debug.print("LIGHTONOCR3 streamed_forward_chunks={d}\\n", .{chunks});
'''+s[i:];p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';s=p.read_text().replace('            "ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK",','            "ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK",\n            "ANTFLY_LIGHTONOCR3_STREAM_FORWARD",',1).replace('            "gateoff",\n            "direct",','            "gateoff",\n            "stream",\n            "direct",',1).replace('                    "gateoff",\n                )','                    "gateoff",\n                    "stream",\n                )',1)
anchor='    if args.require_execution_gate_wait:';# args are evaluated in result parsing; use the known indentation there.
anchor='        if args.require_execution_gate_wait:\n';insert='''        if args.require_streamed_forward:
            rounds = result.get("policy_rounds", [])
            if not rounds:
                result["status"] = "streamed_forward_requires_policy_rounds"
            for sample in rounds:
                enabled = sample["policy"] == "stream" or (sample["policy"] == "current" and args.stream_forward)
                if enabled != (sample["streamed_forward_chunks"] > 0):
                    result["status"] = "streamed_forward_control_mismatch"
''';assert anchor in s;s=s.replace(anchor,insert+anchor,1)
anchor='                    frames = re.findall(\n';assert anchor in s;s=s.replace(anchor,'''                    sample["streamed_forward_chunks"] = sum(
                        int(value) for value in re.findall(r"LIGHTONOCR3 streamed_forward_chunks=(\\d+)", section)
                    )
'''+anchor,1)
anchor='    if args.contention_wait_us is not None:';assert anchor in s;s=s.replace(anchor,'''    if args.stream_forward:
        env["ANTFLY_LIGHTONOCR3_STREAM_FORWARD"] = "1"
'''+anchor,1)
anchor='    parser.add_argument("--require-execution-gate-wait", action="store_true")';assert anchor in s;s=s.replace(anchor,anchor+'\n    parser.add_argument("--stream-forward", action="store_true")\n    parser.add_argument("--require-streamed-forward", action="store_true")',1);p.write_text(s)
