from pathlib import Path
import os,subprocess,time,json,sys
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_epoch_m4_max';out=p/'native_cpu_profile';out.mkdir(exist_ok=True)
env=os.environ.copy();env.update(OCR_REQUESTS='64',OCR_POLICY_ROUNDS='default')
command=[sys.executable,str(v/'run_unified_matrix.py'),'unified','08_rounds_cpu_profile']
with (out/'driver.txt').open('w')as log:
 process=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 deadline=time.monotonic()+180;sampled=False
 while process.poll()is None and time.monotonic()<deadline:
  timed=p/'native_unified_08_rounds_cpu_profile/lighton08-batch-c8.txt'
  if timed.exists()and 'OCR_POLICY round=0 name=default' in timed.read_text():
   rows=subprocess.check_output(['ps','-axo','pid,ppid,args'],text=True).splitlines()[1:];items={}
   for row in rows:
    bits=row.strip().split(None,2)
    if len(bits)==3:items[int(bits[0])]=(int(bits[1]),bits[2])
   binary=json.loads((p/'unified_build_manifest.json').read_text())['binary_path']
   for pid,(parent,args)in items.items():
    if not args.startswith(binary+' '):continue
    ancestor=parent
    while ancestor in items and ancestor!=process.pid:ancestor=items[ancestor][0]
    if ancestor!=process.pid:continue
    cmd=['/usr/bin/sample',str(pid),'4','1','-file',str(out/'sample.txt')]
    result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (out/'sample_command.json').write_text(json.dumps(dict(command=cmd,exit_code=result.returncode,stdout=result.stdout,driver_pid=process.pid,profiled_pid=pid,scope='Diagnostic CPU stack sampling during native default timed work; sampling adds overhead. Not a primary throughput result.'),indent=2)+'\n');sampled=True;break
   if sampled:break
  time.sleep(.05)
 status=process.wait(timeout=900)
 print('driver',status,'sampled',sampled,flush=True)
 sys.exit(status if sampled else 2)
