from pathlib import Path
import re
r=Path.cwd();p=r/'zig/pkg/inference/src/backends/metal_kernels.m';s=p.read_text();a=s.index('static bool termite_metal_lightonocr3_fast_projections(');b=s.index('\nint termite_metal_decode_runtime_apply_linear_device(',a);part=s[a:b]
pattern=r'termite_metal_env_flag_enabled\(\s*getenv\("([^"]+)"\)\)'
names=sorted(set(re.findall(pattern,part)))
assert len(names)==22
prefix='TERMITE_METAL_'
keys={name:'TERMITE_METAL_FRAME_'+name.removeprefix(prefix)for name in names}
headers=list(re.finditer(r'(?m)^(?:static )?[^\s\n;{}][^\n;{}]*\([^;{}]*?\)\s*\{',part))
def replace(match):
 header=next(h for h in reversed(headers)if h.start()<match.start());params=header.group();m=re.search(r'termite_metal_decode_runtime \*(\w+)',params);assert m,params
 return f'termite_metal_frame_env_enabled({m[1]}, {keys[match[1]]})'
part=re.sub(pattern,replace,part);s=s[:a]+part+s[b:]
enum='typedef enum termite_metal_frame_env_key {\n'+''.join('    '+keys[n]+',\n'for n in names)+'    TERMITE_METAL_FRAME_ENV_COUNT\n} termite_metal_frame_env_key;\n\nstatic const char *const termite_metal_frame_env_names[TERMITE_METAL_FRAME_ENV_COUNT] = {\n'+''.join('    "'+n+'",\n'for n in names)+'};\n\n'
s=s.replace('typedef struct termite_metal_decode_runtime {',enum+'typedef struct termite_metal_decode_runtime {',1)
s=s.replace('    BOOL lightonocr3_projections_enabled;','''    BOOL lightonocr3_projections_enabled;
    // Immutable only while this frame is active; refresh on every begin so
    // subsequent frame controls never inherit a process-global cached flag.
    bool lighton_frame_policy_valid;
    uint64_t lighton_frame_env_bits;
    bool lighton_frame_access_profile;
    bool lighton_frame_barriers_disabled;
    uint64_t lighton_frame_policy_snapshots;''',1)
anchor='} termite_metal_decode_runtime;';helpers='''

static bool termite_metal_frame_env_enabled(
    const termite_metal_decode_runtime *runtime, termite_metal_frame_env_key key
) {
    if (runtime != NULL && runtime->active_frame_cb != nil && runtime->lighton_frame_policy_valid)
        return (runtime->lighton_frame_env_bits & (UINT64_C(1) << key)) != 0;
    return termite_metal_env_flag_enabled(getenv(termite_metal_frame_env_names[key]));
}

static void termite_metal_snapshot_lighton_frame_policy(termite_metal_decode_runtime *runtime) {
    runtime->lighton_frame_policy_valid = runtime->lightonocr3_projections_enabled &&
        termite_metal_env_flag_enabled(getenv("TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY"));
    if (!runtime->lighton_frame_policy_valid) return;
    uint64_t bits = 0;
    for (unsigned key = 0; key < TERMITE_METAL_FRAME_ENV_COUNT; ++key)
        if (termite_metal_env_flag_enabled(getenv(termite_metal_frame_env_names[key])))
            bits |= UINT64_C(1) << key;
    runtime->lighton_frame_env_bits = bits;
    // Preserve these legacy switches' exact nonempty/nonzero semantics.
    const char *profile = getenv("TERMITE_METAL_PLANNED_ACCESS_PROFILE");
    runtime->lighton_frame_access_profile = profile != NULL && profile[0] != '\\0' && strcmp(profile, "0") != 0;
    const char *disabled = getenv("TERMITE_METAL_DISABLE_PLANNED_COMPUTE_BARRIERS");
    runtime->lighton_frame_barriers_disabled = disabled != NULL && disabled[0] != '\\0' && strcmp(disabled, "0") != 0;
    runtime->lighton_frame_policy_snapshots += 1;
}

uint64_t termite_metal_decode_runtime_lighton_frame_policy_snapshots(const termite_metal_decode_runtime *runtime) {
    return runtime == NULL ? 0 : runtime->lighton_frame_policy_snapshots;
}
''';s=s.replace(anchor,anchor+helpers,1)
s=s.replace('    const char *disabled = getenv("TERMITE_METAL_DISABLE_PLANNED_COMPUTE_BARRIERS");\n    if (disabled != NULL', '''    const char *disabled = runtime != NULL && runtime->active_frame_cb != nil && runtime->lighton_frame_policy_valid
        ? (runtime->lighton_frame_barriers_disabled ? "1" : "0")
        : getenv("TERMITE_METAL_DISABLE_PLANNED_COMPUTE_BARRIERS");
    if (disabled != NULL''',1)
s=s.replace('static bool termite_metal_planned_access_profile_enabled(void) {','''static bool termite_metal_planned_access_profile_enabled(const termite_metal_decode_runtime *runtime) {
    if (runtime != NULL && runtime->active_frame_cb != nil && runtime->lighton_frame_policy_valid)
        return runtime->lighton_frame_access_profile;''',1).replace('termite_metal_planned_access_profile_enabled()', 'termite_metal_planned_access_profile_enabled(runtime)')
anchor='        runtime->active_frame_cb = cb;\n        runtime->active_frame_encode_started_nanos';assert s.count(anchor)==1;s=s.replace(anchor,'        termite_metal_snapshot_lighton_frame_policy(runtime);\n'+anchor,1);p.write_text(s)
p=r/'zig/pkg/inference/src/backends/metal_runtime.zig';s=p.read_text();a='pub extern fn termite_metal_decode_runtime_set_lightonocr3_projections(';i=s.index(a);j=s.index('\n',i);s=s[:j]+ '\npub extern fn termite_metal_decode_runtime_lighton_frame_policy_snapshots(runtime: ?*RawMetalDecodeRuntime) u64;'+s[j:];p.write_text(s)
p=r/'zig/pkg/inference/src/ops/metal_compute.zig';s=p.read_text();a='    pub fn lightOnDirectCoreOutputEnabled(cb: *const ops.ComputeBackend) bool {';assert a in s;s=s.replace(a,'''    pub fn lightOnFramePolicySnapshots(cb: *const ops.ComputeBackend) u64 {
        if (cb.kind() != .metal) return 0;
        const self: *MetalCompute = @ptrCast(@alignCast(cb.ptr));
        return metal_runtime_mod.termite_metal_decode_runtime_lighton_frame_policy_snapshots(self.provider_impl.raw_decode_runtime);
    }

'''+a,1);p.write_text(s)
p=r/'zig/pkg/inference/src/server/server.zig';s=p.read_text().replace('            "ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK",','            "ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK",\n            "TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY",',1).replace('or std.mem.eql(u8, policy, "gateoff");','or std.mem.eql(u8, policy, "gateoff") or std.mem.eql(u8, policy, "flags");',1).replace('or std.mem.eql(u8, policy, "gateoff")) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;','or std.mem.eql(u8, policy, "gateoff") or std.mem.eql(u8, policy, "flags")) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;',1)
a='                if (Env.setenv(policy_flags[22],';i=s.index(a);j=s.index('\n',i);s=s[:j]+'\n                if (Env.setenv(policy_flags[23], if (std.mem.eql(u8, policy, "flags")) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;'+s[j:]
a='                    const t = cb.debugTimingSnapshot().provider;';assert a in s;s=s.replace(a,a+'\n                    const snapshots = if (comptime build_options.enable_metal) @import("../ops/metal_compute.zig").MetalCompute.lightOnFramePolicySnapshots(&cb) else 0;\n                    std.debug.print("LIGHTONOCR3 frame_policy_snapshots={d}\\n", .{snapshots});',1);p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';s=p.read_text().replace('            "ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK",','            "ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK",\n            "TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY",',1).replace('            "gateoff",\n            "direct",','            "gateoff",\n            "flags",\n            "direct",',1).replace('                    "gateoff",\n                )','                    "gateoff",\n                    "flags",\n                )',1)
a='        if args.require_execution_gate_wait:\n';assert a in s;s=s.replace(a,'''        if args.require_frame_policy:
            rounds = result.get("policy_rounds", [])
            if not rounds:
                result["status"] = "frame_policy_requires_rounds"
            for sample in rounds:
                enabled = sample["policy"] == "flags" or (sample["policy"] == "current" and args.frame_policy)
                if enabled != (sample["frame_policy_snapshots"] > 0):
                    result["status"] = "frame_policy_control_mismatch"
'''+a,1)
a='                    frames = re.findall(\n';assert a in s;s=s.replace(a,'''                    sample["frame_policy_snapshots"] = sum(
                        int(value) for value in re.findall(r"LIGHTONOCR3 frame_policy_snapshots=(\\d+)", section)
                    )
'''+a,1)
a='    if args.contention_wait_us is not None:';assert a in s;s=s.replace(a,'''    if args.frame_policy:
        env["TERMITE_METAL_ENABLE_LIGHTONOCR3_FRAME_POLICY"] = "1"
'''+a,1)
a='    parser.add_argument("--require-execution-gate-wait", action="store_true")';assert a in s;s=s.replace(a,a+'\n    parser.add_argument("--frame-policy", action="store_true")\n    parser.add_argument("--require-frame-policy", action="store_true")',1);p.write_text(s)
