from pathlib import Path
r=Path.cwd();p=r/'zig/pkg/inference/src/pipelines/reading.zig';s=p.read_text()
needle='''        const fused_lm_head_allowed = if (self.config.no_repeat_ngram_size == 0)''';insert='''        // An unmasked device winner is also the masked winner when the
        // page's no-repeat policy allows that token. Only rejected winners
        // need the existing full-logits host selection path.
        const checked_no_repeat_argmax = cb.kind() == .metal and
            !platform.env.getenvBool("ANTFLY_FLORENCE2_DISABLE_NO_REPEAT_ARGMAX");
        var no_repeat_device_accepts: usize = 0;
        var no_repeat_cpu_fallbacks: usize = 0;
        defer if (self.config.no_repeat_ngram_size > 0 and platform.env.getenvBool("ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX")) {
            std.debug.print("FLORENCE2 no_repeat_argmax_enabled={d} device_accepts={d} cpu_fallbacks={d}\\n", .{ @intFromBool(checked_no_repeat_argmax), no_repeat_device_accepts, no_repeat_cpu_fallbacks });
        };
''';assert needle in s;s=s.replace(needle,insert+needle,1)
needle='''            else
                "batch_full_logits_no_repeat";''';replace='''            else if (checked_no_repeat_argmax)
                "batch_logits_checked_no_repeat"
            else
                "batch_full_logits_no_repeat";''';assert needle in s;s=s.replace(needle,replace,1)
a=s.index('                if (!selected_on_device) {',s.index(insert));b=s.index('                    if (!selected_on_device) {',a);region=s[a:b];region=region.replace('if (self.config.no_repeat_ngram_size == 0) {','if (self.config.no_repeat_ngram_size == 0 or checked_no_repeat_argmax) {',1)
needle='''                            finished_count += try applyFlorenceBatchSelectedTokensActive(''';assert needle in region;region=region.replace(needle,'''                            if (florenceBatchArgmaxAllowedByNoRepeat(dec_ids, max_len, dec_len, active_rows[0..active_count], selected_tokens, self.config.no_repeat_ngram_size)) {
                                if (self.config.no_repeat_ngram_size > 0) no_repeat_device_accepts += 1;
'''+needle,1)
needle='''                                last_read_telemetry.lm_head_path = "batch_logits_argmax";
''';assert needle in region;region=region.replace(needle,needle+'                            }\n',1);s=s[:a]+region+s[b:]
a=s.index('                    if (!selected_on_device) {',a);needle='''                        const logits = try cb.toFloat32(logits_tensor, allocator);''';assert s[a:].startswith('                    if (!selected_on_device) {');b=s.index(needle,a);s=s[:b]+'''                        if (self.config.no_repeat_ngram_size > 0) no_repeat_cpu_fallbacks += 1;
'''+s[b:]
anchor='fn selectGreedyToken(logits: []const f32, prefix: []const i64, no_repeat_ngram_size: usize) usize {';insert='''/// Validate each device winner against its original page history. Active
/// decoder/cache rows may have been compacted or reordered after earlier EOS.
/// A rejected winner leaves the existing full-logits policy in control.
fn florenceBatchArgmaxAllowedByNoRepeat(
    decoder_ids: []const i64,
    max_len: usize,
    decoder_len: usize,
    active_rows: []const usize,
    selected_tokens: []const u32,
    no_repeat_ngram_size: usize,
) bool {
    if (max_len == 0 or decoder_len > max_len or decoder_ids.len % max_len != 0 or
        selected_tokens.len != active_rows.len) return false;
    const total_rows = decoder_ids.len / max_len;
    for (selected_tokens, active_rows) |token, original_row| {
        if (original_row >= total_rows) return false;
        const prefix = decoder_ids[original_row * max_len ..][0..decoder_len];
        if (wouldRepeatNgram(prefix, @intCast(token), no_repeat_ngram_size)) return false;
    }
    return true;
}

test "Florence device winners preserve per-page no-repeat after active row compaction" {
    const ids = [_]i64{
        1, 2, 3, 1, 2, 0,
        7, 8, 9, 7, 8, 0,
        4, 5, 6, 4, 5, 0,
    };
    const active = [_]usize{ 2, 0 };
    try std.testing.expect(florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &active, &.{ 3, 6 }, 3));
    try std.testing.expect(!florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &active, &.{ 6, 3 }, 3));
    try std.testing.expect(!florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &active, &.{ 3, 3 }, 3));
    try std.testing.expect(florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &active, &.{ 6, 3 }, 0));
    try std.testing.expect(florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &active, &.{ 6, 3 }, 1));
    try std.testing.expect(!florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &.{3}, &.{3}, 3));
    try std.testing.expect(!florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &active, &.{3}, 3));
    try std.testing.expect(!florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 7, &active, &.{ 3, 6 }, 3));
    try std.testing.expect(!florenceBatchArgmaxAllowedByNoRepeat(&ids, 0, 0, &active, &.{ 3, 6 }, 3));

    // If a global maximum is allowed, it remains the masked maximum. A
    // rejected maximum must use the established host policy instead. Cover
    // tied maxima and every candidate for both independent page histories.
    for ([_]usize{ 0, 2 }) |row| {
        for (0..10) |candidate| {
            var logits: [10]f32 = @splat(-1);
            logits[candidate] = 4;
            logits[(candidate + 1) % logits.len] = 4;
            const unmasked = selectGreedyToken(&logits, ids[row * 6 ..][0..5], 0);
            const masked = selectGreedyToken(&logits, ids[row * 6 ..][0..5], 3);
            const allowed = florenceBatchArgmaxAllowedByNoRepeat(&ids, 6, 5, &.{row}, &.{@intCast(unmasked)}, 3);
            if (allowed) try std.testing.expectEqual(masked, unmasked) else try std.testing.expect(masked != unmasked);
        }
    }
}

''';assert anchor in s;s=s.replace(anchor,insert+anchor,1);p.write_text(s)
p=r/'zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py';s=p.read_text();anchor='            "ANTFLY_FLORENCE2_BATCH_WAIT_US",';assert anchor in s;s=s.replace(anchor,anchor+'\n            "ANTFLY_FLORENCE2_DISABLE_NO_REPEAT_ARGMAX",\n            "ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX",',1);anchor='    env["ANTFLY_FLORENCE2_BATCH_WAIT_US"] = str(args.florence_batch_wait_us)';assert anchor in s;s=s.replace(anchor,anchor+'''\n    if args.disable_florence_no_repeat_argmax:
        env["ANTFLY_FLORENCE2_DISABLE_NO_REPEAT_ARGMAX"] = "1"
    if args.require_florence_no_repeat_argmax:
        env["ANTFLY_FLORENCE2_TRACE_NO_REPEAT_ARGMAX"] = "1"''',1)
anchor='        if args.require_weight_handles:\n';insert='''        if args.require_florence_no_repeat_argmax:
            timed = "".join(re.split(r"OCR_POLICY round=\\d+ name=[a-z0-9]+\\n", text)[1:])
            traces = re.findall(r"FLORENCE2 no_repeat_argmax_enabled=(\\d+) device_accepts=(\\d+) cpu_fallbacks=(\\d+)", timed)
            stats = {
                "enabled": sorted({int(row[0]) for row in traces}),
                "device_accepts": sum(int(row[1]) for row in traces),
                "cpu_fallbacks": sum(int(row[2]) for row in traces),
            }
            result["florence_no_repeat_argmax"] = stats
            enabled = not args.disable_florence_no_repeat_argmax
            if stats["enabled"] != [int(enabled)] or (enabled and not stats["device_accepts"]) or (not enabled and (stats["device_accepts"] or not stats["cpu_fallbacks"])):
                result["status"] = "florence_no_repeat_argmax_control_mismatch"
''';assert anchor in s;s=s.replace(anchor,insert+anchor,1);anchor='    parser.add_argument("--disable-florence-window-softmax", action="store_true")';assert anchor in s;s=s.replace(anchor,anchor+'\n    parser.add_argument("--disable-florence-no-repeat-argmax", action="store_true")\n    parser.add_argument("--require-florence-no-repeat-argmax", action="store_true")',1);p.write_text(s)
