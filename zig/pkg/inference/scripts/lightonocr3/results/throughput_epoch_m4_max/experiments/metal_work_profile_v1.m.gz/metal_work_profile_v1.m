// Copyright 2026 Antfly, Inc.
// SPDX-License-Identifier: Apache-2.0
// Benchmark-only observer. No kernel, buffer, or dispatch arguments are changed.
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#import <objc/runtime.h>
#include <fcntl.h>
#include <unistd.h>

@interface OCRWorkFrame : NSObject
@property NSMutableDictionary *kernels;
@property unsigned long long copies;
@property unsigned long long copyBytes;
@end
@implementation OCRWorkFrame
- (instancetype)init { if ((self = [super init])) _kernels = [NSMutableDictionary new]; return self; }
@end
static NSObject *registryLock;
static NSMutableDictionary *originals;
static NSMutableDictionary *pipelineNames;
static NSString *traceDir;
static const char *markerPath;
static char frameKey, pipelineKey;
static void hookBuffer(id obj);
static void hookCompute(id obj, OCRWorkFrame *frame);
static void hookBlit(id obj, OCRWorkFrame *frame);
static NSString *methodKey(Class cls, SEL sel) { return [NSString stringWithFormat:@"%p:%s", cls, sel_getName(sel)]; }
static IMP lookupOriginal(Class cls, SEL sel) {
    @synchronized (registryLock) {
        for (; cls != Nil; cls = class_getSuperclass(cls)) {
            NSValue *p = originals[methodKey(cls, sel)];
            if (p) return (IMP)p.pointerValue;
        }
    }
    abort();
}
static void hook(Class cls, SEL sel, IMP replacement) {
    @synchronized (registryLock) {
        NSString *key = methodKey(cls, sel);
        if (originals[key]) return;
        Method method = class_getInstanceMethod(cls, sel);
        if (!method) return;
        IMP old = method_getImplementation(method);
        if (old == replacement) old = lookupOriginal(class_getSuperclass(cls), sel);
        originals[key] = [NSValue valueWithPointer:(const void *)old];
        class_replaceMethod(cls, sel, replacement, method_getTypeEncoding(method));
    }
}
static OCRWorkFrame *frameFor(id buffer) {
    OCRWorkFrame *frame = objc_getAssociatedObject(buffer, &frameKey);
    if (!frame) {
        frame = [OCRWorkFrame new];
        objc_setAssociatedObject(buffer, &frameKey, frame, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    return frame;
}
static NSString *pipelineName(id<MTLComputePipelineState> pso) {
    @synchronized (registryLock) {
        NSValue *key = [NSValue valueWithPointer:(__bridge const void *)pso];
        NSString *name = pipelineNames[key];
        if (!name) {
            name = pso.label.length ? pso.label : pso.description;
            if (name.length > 700) name = [name substringToIndex:700];
            pipelineNames[key] = name ?: @"unknown";
        }
        return pipelineNames[key];
    }
}
// These selectors return +1 objects. Preserve that ARC contract in both
// the original function-pointer types and the replacement entry points.
typedef id (*NewFunctionPso)(id, SEL, id, NSError *__autoreleasing *) __attribute__((ns_returns_retained));
typedef id (*NewOptionsPso)(id, SEL, id, NSUInteger, id __autoreleasing *, NSError *__autoreleasing *) __attribute__((ns_returns_retained));
static void registerPipeline(id pso, id function) {
    if (!pso || !function) return;
    NSString *name = [(id<MTLFunction>)function name];
    if (name.length) @synchronized (registryLock) {
        pipelineNames[[NSValue valueWithPointer:(__bridge const void *)pso]] = name;
    }
}
static id newFunctionPso(id obj, SEL sel, id function, NSError *__autoreleasing *error) __attribute__((ns_returns_retained));
static id newFunctionPso(id obj, SEL sel, id function, NSError *__autoreleasing *error) {
    id result = ((NewFunctionPso)lookupOriginal(object_getClass(obj), sel))(obj, sel, function, error);
    registerPipeline(result, function);
    return result;
}
static id newFunctionOptionsPso(id obj, SEL sel, id function, NSUInteger options, id __autoreleasing *reflection, NSError *__autoreleasing *error) __attribute__((ns_returns_retained));
static id newFunctionOptionsPso(id obj, SEL sel, id function, NSUInteger options, id __autoreleasing *reflection, NSError *__autoreleasing *error) {
    id result = ((NewOptionsPso)lookupOriginal(object_getClass(obj), sel))(obj, sel, function, options, reflection, error);
    registerPipeline(result, function);
    return result;
}
static id newDescriptorPso(id obj, SEL sel, MTLComputePipelineDescriptor *desc, NSUInteger options, id __autoreleasing *reflection, NSError *__autoreleasing *error) __attribute__((ns_returns_retained));
static id newDescriptorPso(id obj, SEL sel, MTLComputePipelineDescriptor *desc, NSUInteger options, id __autoreleasing *reflection, NSError *__autoreleasing *error) {
    id result = ((NewOptionsPso)lookupOriginal(object_getClass(obj), sel))(obj, sel, desc, options, reflection, error);
    registerPipeline(result, desc.computeFunction);
    return result;
}
static void setPipeline(id obj, SEL sel, id<MTLComputePipelineState> pso) {
    objc_setAssociatedObject(obj, &pipelineKey, pipelineName(pso), OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    ((void (*)(id, SEL, id))lookupOriginal(object_getClass(obj), sel))(obj, sel, pso);
}
static void recordDispatch(id obj, MTLSize grid) {
    OCRWorkFrame *frame = objc_getAssociatedObject(obj, &frameKey);
    if (!frame) return;
    NSString *name = objc_getAssociatedObject(obj, &pipelineKey) ?: @"unset";
    @synchronized (frame) {
        NSMutableDictionary *entry = frame.kernels[name];
        if (!entry) { entry = [@{@"dispatches": @0, @"grid_items": @0} mutableCopy]; frame.kernels[name] = entry; }
        entry[@"dispatches"] = @([entry[@"dispatches"] unsignedLongLongValue] + 1);
        entry[@"grid_items"] = @([entry[@"grid_items"] unsignedLongLongValue] + (unsigned long long)grid.width * grid.height * grid.depth);
    }
}
static void dispatch(id obj, SEL sel, MTLSize grid, MTLSize threads) {
    recordDispatch(obj, grid);
    ((void (*)(id, SEL, MTLSize, MTLSize))lookupOriginal(object_getClass(obj), sel))(obj, sel, grid, threads);
}
static void copyBuffer(id obj, SEL sel, id src, NSUInteger srcOffset, id dst, NSUInteger dstOffset, NSUInteger bytes) {
    OCRWorkFrame *frame = objc_getAssociatedObject(obj, &frameKey);
    if (frame) @synchronized (frame) { frame.copies += 1; frame.copyBytes += bytes; }
    ((void (*)(id, SEL, id, NSUInteger, id, NSUInteger, NSUInteger))lookupOriginal(object_getClass(obj), sel))(obj, sel, src, srcOffset, dst, dstOffset, bytes);
}
static id computePlain(id obj, SEL sel) {
    id encoder = ((id (*)(id, SEL))lookupOriginal(object_getClass(obj), sel))(obj, sel);
    if (encoder) hookCompute(encoder, frameFor(obj));
    return encoder;
}
static id computeDescriptor(id obj, SEL sel, id desc) {
    id encoder = ((id (*)(id, SEL, id))lookupOriginal(object_getClass(obj), sel))(obj, sel, desc);
    if (encoder) hookCompute(encoder, frameFor(obj));
    return encoder;
}
static id computeType(id obj, SEL sel, NSUInteger type) {
    id encoder = ((id (*)(id, SEL, NSUInteger))lookupOriginal(object_getClass(obj), sel))(obj, sel, type);
    if (encoder) hookCompute(encoder, frameFor(obj));
    return encoder;
}
static id blitPlain(id obj, SEL sel) {
    id encoder = ((id (*)(id, SEL))lookupOriginal(object_getClass(obj), sel))(obj, sel);
    if (encoder) hookBlit(encoder, frameFor(obj));
    return encoder;
}
static id blitDescriptor(id obj, SEL sel, id desc) {
    id encoder = ((id (*)(id, SEL, id))lookupOriginal(object_getClass(obj), sel))(obj, sel, desc);
    if (encoder) hookBlit(encoder, frameFor(obj));
    return encoder;
}
static void commit(id<MTLCommandBuffer> obj, SEL sel) {
    char tag[192] = {0};
    int marker = open(markerPath, O_RDONLY);
    ssize_t count = marker >= 0 ? read(marker, tag, sizeof(tag) - 1) : 0;
    if (marker >= 0) close(marker);
    if (count > 0) {
        OCRWorkFrame *frame = frameFor(obj);
        NSString *label = obj.label ?: @"";
        NSString *scope = [[NSString alloc] initWithBytes:tag length:(NSUInteger)count encoding:NSUTF8StringEncoding] ?: @"unknown";
        [obj addCompletedHandler:^(id<MTLCommandBuffer> done) {
            @autoreleasepool {
                NSDictionary *row;
                @synchronized (frame) {
                    row = @{@"tag":scope, @"pid":@(getpid()), @"label":label,
                            @"gpu_start":@(done.GPUStartTime), @"gpu_end":@(done.GPUEndTime),
                            @"status":@(done.status), @"kernels":[frame.kernels copy],
                            @"blit_copies":@(frame.copies), @"blit_bytes":@(frame.copyBytes)};
                }
                NSData *json = [NSJSONSerialization dataWithJSONObject:row options:0 error:NULL];
                NSString *path = [traceDir stringByAppendingPathComponent:[NSString stringWithFormat:@"frames-%d.jsonl", getpid()]];
                @synchronized (registryLock) {
                    int fd = open(path.fileSystemRepresentation, O_WRONLY | O_CREAT | O_APPEND, 0600);
                    if (fd >= 0) { write(fd, json.bytes, json.length); write(fd, "\n", 1); close(fd); }
                }
            }
        }];
    }
    ((void (*)(id, SEL))lookupOriginal(object_getClass(obj), sel))(obj, sel);
}
static void hookCompute(id obj, OCRWorkFrame *frame) {
    objc_setAssociatedObject(obj, &frameKey, frame, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    Class cls = object_getClass(obj);
    hook(cls, @selector(setComputePipelineState:), (IMP)setPipeline);
    hook(cls, @selector(dispatchThreadgroups:threadsPerThreadgroup:), (IMP)dispatch);
    hook(cls, @selector(dispatchThreads:threadsPerThreadgroup:), (IMP)dispatch);
}
static void hookBlit(id obj, OCRWorkFrame *frame) {
    objc_setAssociatedObject(obj, &frameKey, frame, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    hook(object_getClass(obj), @selector(copyFromBuffer:sourceOffset:toBuffer:destinationOffset:size:), (IMP)copyBuffer);
}
static void hookBuffer(id obj) {
    Class cls = object_getClass(obj);
    frameFor(obj);
    hook(cls, @selector(computeCommandEncoder), (IMP)computePlain);
    hook(cls, @selector(computeCommandEncoderWithDescriptor:), (IMP)computeDescriptor);
    hook(cls, @selector(computeCommandEncoderWithDispatchType:), (IMP)computeType);
    hook(cls, @selector(blitCommandEncoder), (IMP)blitPlain);
    hook(cls, @selector(blitCommandEncoderWithDescriptor:), (IMP)blitDescriptor);
    hook(cls, @selector(commit), (IMP)commit);
}
static id queuePlain(id obj, SEL sel) {
    id buffer = ((id (*)(id, SEL))lookupOriginal(object_getClass(obj), sel))(obj, sel);
    if (buffer) hookBuffer(buffer);
    return buffer;
}
static id queueDescriptor(id obj, SEL sel, id desc) {
    id buffer = ((id (*)(id, SEL, id))lookupOriginal(object_getClass(obj), sel))(obj, sel, desc);
    if (buffer) hookBuffer(buffer);
    return buffer;
}
__attribute__((constructor)) static void initializeObserver(void) {
    const char *directory = getenv("OCR_METAL_PROFILE_DIR");
    markerPath = getenv("OCR_METAL_PROFILE_MARKER");
    if (!directory || !markerPath) return;
    @autoreleasepool {
        registryLock = [NSObject new]; originals = [NSMutableDictionary new]; pipelineNames = [NSMutableDictionary new];
        traceDir = [NSString stringWithUTF8String:directory];
        [[NSFileManager defaultManager] createDirectoryAtPath:traceDir withIntermediateDirectories:YES attributes:nil error:NULL];
        id<MTLDevice> device = MTLCreateSystemDefaultDevice();
        hook(object_getClass(device), @selector(newComputePipelineStateWithFunction:error:), (IMP)newFunctionPso);
        hook(object_getClass(device), @selector(newComputePipelineStateWithFunction:options:reflection:error:), (IMP)newFunctionOptionsPso);
        hook(object_getClass(device), @selector(newComputePipelineStateWithDescriptor:options:reflection:error:), (IMP)newDescriptorPso);
        id<MTLCommandQueue> queue = [device newCommandQueue];
        if (!queue) return;
        Class cls = object_getClass(queue);
        hook(cls, @selector(commandBuffer), (IMP)queuePlain);
        hook(cls, @selector(commandBufferWithUnretainedReferences), (IMP)queuePlain);
        hook(cls, @selector(commandBufferWithDescriptor:), (IMP)queueDescriptor);
        id<MTLCommandBuffer> buffer = [queue commandBuffer];
        id<MTLComputeCommandEncoder> encoder = [buffer computeCommandEncoder];
        [encoder endEncoding]; [buffer commit]; [buffer waitUntilCompleted];
    }
}
