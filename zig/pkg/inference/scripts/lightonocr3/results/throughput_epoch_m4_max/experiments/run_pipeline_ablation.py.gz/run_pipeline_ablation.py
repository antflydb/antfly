from pathlib import Path
import os,sys,subprocess,json
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_epoch_m4_max';scripts=r/'zig/pkg/inference/scripts/lightonocr3';loader=v/'pipeline_gate_import';loader.mkdir(exist_ok=True)
(loader/'sitecustomize.py').write_text('''import os,json,sys,importlib.abc,importlib.machinery
from pathlib import Path
from collections import Counter
class GateLoader(importlib.abc.Loader):
 def __init__(self,inner):self.inner=inner
 def create_module(self,spec):return self.inner.create_module(spec)
 def exec_module(self,module):
  self.inner.exec_module(module)
  original=module.DecodePipeline.begin_step
  counts=Counter()
  def begin(self,decision):
   value=original(self,decision)
   if Path(os.environ['OCR_PIPELINE_GATE_MARKER']).exists():
    counts[decision.reason]+=1
    Path(os.environ['OCR_PIPELINE_GATE_DIR'],f'gate-{os.getpid()}.json').write_text(json.dumps(dict(counts)))
   return value
  module.DecodePipeline.begin_step=begin
class GateFinder(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname!='vllm_metal.v1.decode_pipeline':return None
  spec=importlib.machinery.PathFinder.find_spec(fullname,path)
  if spec:spec.loader=GateLoader(spec.loader)
  return spec
sys.meta_path.insert(0,GateFinder())
''')
s=(scripts/'benchmark_vllm_metal.py').read_text().replace('from benchmark_antfly_readers import', 'import sys\nsys.path.insert(0, '+repr(str(scripts))+')\nfrom benchmark_antfly_readers import',1)
anchor='    with (args.output_dir / "server.txt").open("w") as log:';s=s.replace(anchor,'''    report["execution_flags"] = {key: env.get(key) for key in ("VLLM_METAL_GDN_LAZY_KERNELS", "VLLM_METAL_DECODE_PIPELINE", "VLLM_METAL_COMPILED_MLP")}
    report["conditioning_requests"] = max(args.concurrency) * 2
'''+anchor,1)
s=s.replace('            for concurrency in args.concurrency:\n                start = time.perf_counter()', '''            for concurrency in args.concurrency:
                with ThreadPoolExecutor(max_workers=concurrency) as executor:
                    conditioning = list(executor.map(request, range(concurrency * 2)))
                if not all(x["text"] == references[x["image_index"]]["text"] for x in conditioning):
                    raise RuntimeError("Conditioning output differs from reference")
                Path(os.environ["OCR_PIPELINE_GATE_MARKER"]).write_text("timed")
                start = time.perf_counter()''',1)
s=s.replace('                elapsed = time.perf_counter() - start','                elapsed = time.perf_counter() - start\n                Path(os.environ["OCR_PIPELINE_GATE_MARKER"]).unlink(missing_ok=True)',1).replace('        finally:\n            save()', '        finally:\n            Path(os.environ["OCR_PIPELINE_GATE_MARKER"]).unlink(missing_ok=True)\n            save()',1);(v/'benchmark_vllm_pipeline_ablation.py').write_text(s)
for label in sys.argv[1:]:
 model,variant=label.split(':');out=p/('vllm_'+model+'_pipeline_'+variant);out.mkdir(exist_ok=True);marker=v/('pipeline_'+model+'_'+variant+'.active');marker.unlink(missing_ok=True)
 env=os.environ.copy();env.update(PYTHONPATH=str(loader)+os.pathsep+env.get('PYTHONPATH',''),OCR_PIPELINE_GATE_MARKER=str(marker),OCR_PIPELINE_GATE_DIR=str(out),VLLM_METAL_GDN_LAZY_KERNELS='1',VLLM_METAL_DECODE_PIPELINE='0'if variant.startswith('off')else'1',VLLM_METAL_COMPILED_MLP='0')
 cmd=[sys.executable,str(v/'benchmark_vllm_pipeline_ablation.py'),'--python',sys.executable,'--model-dir',str(v/'ocr-models'/('lighton'+model)),'--images',str(r/'zig/pkg/inference/src/models/testdata/lightonocr3/invoice.png'),str(scripts/'corpus/receipt.png'),str(scripts/'corpus/shipping.png'),'--concurrency','8','--requests','16','--max-tokens','256','--kv-cache-blocks','128','--output-dir',str(out)]
 print('START',label,flush=True)
 with open('/private/tmp/ocr-vllm-pipeline-'+model+'-'+variant+'.txt','w')as f:res=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 print('DONE',label,res.returncode,flush=True)
 if res.returncode:sys.exit(res.returncode)
 gates=[json.loads(f.read_text())for f in out.glob('gate-*.json')];assert gates,label
 print(json.dumps({'variant':variant,'gates':gates,'pps':json.loads((out/'report.json').read_text())['results'][0]['pages_per_second']}),flush=True)
