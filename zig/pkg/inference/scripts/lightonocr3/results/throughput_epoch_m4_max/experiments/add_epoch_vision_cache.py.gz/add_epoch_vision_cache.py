from pathlib import Path
p=Path('zig/pkg/inference/src/architectures/qwen3vl_projector.zig');s=p.read_text();at=s.index('fn encodeProjectedImagesResidentQualified(')
new='''/// Immutable vision transforms owned by one serialized compute epoch. The
/// caller reserves retainedBytes() before initialization, holds the backend
/// alive, and deinitializes this cache before releasing either owner or lease.
/// Image intermediates and projected outputs remain owned by each invocation.
pub const ResidentVisionCache = struct {
    weights: WeightCache,
    cfg: Config,
    encoded_images: usize = 0,

    pub const RetainedBytes = struct { host: usize, backend: usize };

    pub fn supported(config: gpt_config.Config) bool {
        return config.hasQwen35VisionArchitectureContract() and
            (config.vision_hidden_size == 768 or config.vision_hidden_size == 1024) and
            config.vision_patch_size == 16 and config.vision_spatial_merge_size == 2 and
            config.vision_num_position_embeddings == 2304;
    }

    pub fn retainedBytes(config: gpt_config.Config) !RetainedBytes {
        if (!supported(config)) return error.UnsupportedResidentVisionCache;
        const cfg = try configFromResidentModel(config);
        const patch = try admissionF32Bytes(try admissionMul(try admissionMul(cfg.patch_size, cfg.patch_size), 6), cfg.vision_hidden);
        const positions = try admissionF32Bytes(config.vision_num_position_embeddings, cfg.vision_hidden);
        const metadata = try admissionMul(try admissionAdd(try admissionMul(cfg.block_count, 16), 32), 1024);
        // Full patch mirror, split tensors and conservative staging/source
        // peers; two position mirrors; bounded tensor/name bookkeeping. GPU
        // reservation allows both uploaded and prepared split-weight peers.
        return .{
            .host = try admissionAdd(try admissionAdd(try admissionMul(patch, 4), try admissionMul(positions, 2)), metadata),
            .backend = try admissionMul(patch, 2),
        };
    }

    pub fn init(allocator: std.mem.Allocator, cb: *const ComputeBackend, config: gpt_config.Config) !ResidentVisionCache {
        if (!supported(config)) return error.UnsupportedResidentVisionCache;
        const cfg = try configFromResidentModel(config);
        return .{ .weights = WeightCache.initResident(allocator, cb, cfg), .cfg = cfg };
    }

    pub fn deinit(self: *ResidentVisionCache) void {
        self.weights.deinit();
        self.* = undefined;
    }

    pub fn encode(self: *ResidentVisionCache, allocator: std.mem.Allocator, images: []const []const u8, limits: Limits) !ProjectedImages {
        try self.weights.cb.checkExecutionControl();
        const result = try encodeProjectedImagesFromWeightsQualified(self.weights.cb, allocator, &self.weights, self.cfg, images, limits, false);
        self.encoded_images += images.len;
        return result;
    }
};

'''
s=s[:at]+new+s[at:]
s+='''

test "LightOnOCR3 epoch vision reservation covers split patch and position owners" {
    inline for (.{ "../models/testdata/lightonocr3/config.json", "../models/testdata/lightonocr3/config-4b.json" }) |file| {
        const config = try gpt_config.parseConfig(std.testing.allocator, @embedFile(file));
        const bytes = try ResidentVisionCache.retainedBytes(config);
        const patch = @as(usize, config.vision_hidden_size) * 3 * 2 * 16 * 16 * 4;
        const positions = @as(usize, config.vision_hidden_size) * 2304 * 4;
        try std.testing.expect(bytes.host >= patch * 4 + positions * 2);
        try std.testing.expect(bytes.backend >= patch * 2);
        var unsupported = config;
        unsupported.vision_num_position_embeddings = 1024;
        try std.testing.expect(!ResidentVisionCache.supported(unsupported));
        try std.testing.expectError(error.UnsupportedResidentVisionCache, ResidentVisionCache.retainedBytes(unsupported));
    }
}
''';p.write_text(s)
p=Path('zig/pkg/inference/src/server/server.zig');s=p.read_text();s=s.replace('        cb: ?ops.ComputeBackend = null,\n        step_mutex:', '''        cb: ?ops.ComputeBackend = null,
        vision_weights: ?qwen3vl_projector.ResidentVisionCache = null,
        vision_cache_enabled: bool = false,
        vision_cache_admission: model_manager_mod.GenerationAdmissionLease = .{},
        vision_cache_bytes: qwen3vl_projector.ResidentVisionCache.RetainedBytes = .{ .host = 0, .backend = 0 },
        step_mutex:''',1)
a='''            const a = std.heap.smp_allocator;
            const ctx = try a.create(LightOnStreamContext);''';b='''            const a = std.heap.smp_allocator;
            const cache_enabled = metal_runtime.qualifiedM4DeviceDefault() and
                qwen3vl_projector.ResidentVisionCache.supported(factory.cfg) and
                !platform.env.getenvBool("ANTFLY_LIGHTONOCR3_DISABLE_VISION_WEIGHT_CACHE") and
                !platform.env.getenvBool("ANTFLY_LIGHTONOCR3_VISION_BATCH");
            var cache_admission = model_manager_mod.GenerationAdmissionLease{};
            errdefer cache_admission.release();
            var cache_bytes = qwen3vl_projector.ResidentVisionCache.RetainedBytes{ .host = 0, .backend = 0 };
            var budget = runtime.tier.memory.RunBudget.init(factory.limits);
            if (cache_enabled) {
                cache_bytes = try qwen3vl_projector.ResidentVisionCache.retainedBytes(factory.cfg);
                _ = try budget.tryReserveWeight(.host, cache_bytes.host);
                _ = try budget.tryReserveWeight(.backend, cache_bytes.backend);
                cache_admission = try factory.node.model_manager.acquireGenerationResources(&.{.{ .session = factory.model.session, .resources = .{ .backend_class = .gpu, .limits = factory.limits, .amounts = .{ .host_weight_bytes = cache_bytes.host, .backend_weight_bytes = cache_bytes.backend } } }});
            }
            const ctx = try a.create(LightOnStreamContext);''';assert a in s;s=s.replace(a,b,1)
a='.cfg = factory.cfg, .budget = runtime.tier.memory.RunBudget.init(factory.limits), .lane = lane,';b='.cfg = factory.cfg, .budget = budget, .vision_cache_enabled = cache_enabled, .vision_cache_admission = cache_admission, .vision_cache_bytes = cache_bytes, .lane = lane,';assert a in s;s=s.replace(a,b,1)
a='''            ctx.vision_broker.deinit();
            ctx.prefill_broker.deinit();''';b='''            if (platform.env.getenvBool("ANTFLY_BENCH_LIGHTONOCR3")) if (ctx.vision_weights) |cache| {
                std.debug.print("LIGHTONOCR3 vision_weight_cache_pages={d} host_reserved={d} backend_reserved={d}\\n", .{ cache.encoded_images, ctx.vision_cache_bytes.host, ctx.vision_cache_bytes.backend });
            };
            ctx.vision_broker.deinit();
            ctx.prefill_broker.deinit();
            if (ctx.vision_weights) |*cache| cache.deinit();''';assert a in s;s=s.replace(a,b,1)
a='            if (ctx.cb) |*cb| cb.deinit();\n            ctx.coordinator.deinit();';b='            if (ctx.cb) |*cb| cb.deinit();\n            ctx.vision_cache_admission.release();\n            ctx.coordinator.deinit();';assert a in s;s=s.replace(a,b,1)
a='''            ctx.cb = cb;
        }
    };

    fn checkLightOnVisionBatch''';b='''            ctx.cb = cb;
            if (ctx.vision_cache_enabled) {
                ctx.vision_weights = qwen3vl_projector.ResidentVisionCache.init(ctx.allocator, &ctx.cb.?, ctx.cfg) catch |err| {
                    ctx.cb = null;
                    return err;
                };
            }
        }
    };

    fn checkLightOnVisionBatch''';assert a in s;s=s.replace(a,b,1)
a='''            const geometry = if (images.len == 1)''';b='''            if (ctx.vision_cache_enabled) {
                try request.control.lock(&ctx.step_mutex);
                defer ctx.step_mutex.unlock();
                var result = try ctx.vision_weights.?.encode(allocator, images, limits);
                errdefer result.deinit();
                try request.control.check();
                return result;
            }
            const geometry = if (images.len == 1)''';assert a in s;s=s.replace(a,b,1)
s=s.replace('.qwen_vision_batch = if (vision_batch_enabled) .{ .ptr = &vision_request, .encode_fn = LightOnVisionRequest.encode } else null,','.qwen_vision_batch = if (vision_batch_enabled or ctx.vision_cache_enabled) .{ .ptr = &vision_request, .encode_fn = LightOnVisionRequest.encode } else null,',1)
# Independent cache-vs-fresh outputs, cancellation and recovery in the actual checkpoint check.
a='''        var admission = try self.model_manager.acquireGenerationResources(&.{.{ .session = model.session, .resources = .{ .backend_class = .gpu, .limits = limits, .amounts = try one.merge(try one.merge(one)) } }});''';b='''        const cached_bytes = try qwen3vl_projector.ResidentVisionCache.retainedBytes(cfg);
        const cache_amounts = runtime.tier.memory.AdmissionAmounts{ .host_weight_bytes = cached_bytes.host, .backend_weight_bytes = cached_bytes.backend };
        var admission = try self.model_manager.acquireGenerationResources(&.{.{ .session = model.session, .resources = .{ .backend_class = .gpu, .limits = limits, .amounts = try (try one.merge(try one.merge(one))).merge(cache_amounts) } }});''';assert a in s;s=s.replace(a,b,1)
a='''        for ([_]usize{ 2, 3 }) |count| {''';b='''        var cached_vision = try qwen3vl_projector.ResidentVisionCache.init(a, &cb, cfg);
        defer cached_vision.deinit();
        for ([_]usize{ 1, 0, 1 }) |index| {
            var value = try cached_vision.encode(a, &.{images[index]}, .{});
            defer value.deinit();
            try std.testing.expectEqualSlices(f32, serial[index].embeddings, value.embeddings);
        }
        const Cancel = struct { fn check(_: ?*anyopaque) !void { return error.Cancelled; } };
        const saved_control = cb.execution_control;
        cb.execution_control = .{ .check_fn = Cancel.check };
        const cancelled = cached_vision.encode(a, &.{fixture}, .{});
        cb.execution_control = saved_control;
        try std.testing.expectError(error.Cancelled, cancelled);
        try std.testing.expectEqual(@as(usize, 3), cached_vision.encoded_images);
        var resumed = try cached_vision.encode(a, &.{fixture}, .{});
        defer resumed.deinit();
        try std.testing.expectEqualSlices(f32, serial[0].embeddings, resumed.embeddings);
        std.debug.print("LIGHTONOCR3 vision_weight_cache_parity images=4 exact=true cancellation=true\\n", .{});
        for ([_]usize{ 2, 3 }) |count| {''';# specific first after serial section
start=s.index('    fn checkLightOnVisionBatch');idx=s.index(a,start);s=s[:idx]+s[idx:].replace(a,b,1)
# Compare to the previous production default within the same process.
s=s.replace('            "TERMITE_METAL_DISABLE_LIGHTONOCR3_WEIGHT_HANDLES",','            "TERMITE_METAL_DISABLE_LIGHTONOCR3_WEIGHT_HANDLES",\n            "ANTFLY_LIGHTONOCR3_DISABLE_VISION_WEIGHT_CACHE",',1)
s=s.replace('or std.mem.eql(u8, policy, "default");','or std.mem.eql(u8, policy, "default") or std.mem.eql(u8, policy, "cacheoff");',1)
s=s.replace('std.mem.eql(u8, policy, "handlesoff") or std.mem.eql(u8, policy, "default")) "1"','std.mem.eql(u8, policy, "handlesoff") or std.mem.eql(u8, policy, "default") or std.mem.eql(u8, policy, "cacheoff")) "1"',1)
a='''                if (Env.setenv(policy_flags[21],''';idx=s.index(a);end=s.index('\n',idx);s=s[:end]+'''\n                if (Env.setenv(policy_flags[22], if (std.mem.eql(u8, policy, "cacheoff") or std.mem.eql(u8, policy, "pipelineoff")) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;'''+s[end:]
p.write_text(s)
p=Path('zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py');s=p.read_text().replace('            "default",','            "default",\n            "cacheoff",',1).replace('            "ANTFLY_LIGHTONOCR3_READY_COHORTS",','            "ANTFLY_LIGHTONOCR3_READY_COHORTS",\n            "ANTFLY_LIGHTONOCR3_DISABLE_VISION_WEIGHT_CACHE",',1).replace('("pipelineoff", "handlesoff", "default")','("pipelineoff", "handlesoff", "default", "cacheoff")',1);p.write_text(s)
