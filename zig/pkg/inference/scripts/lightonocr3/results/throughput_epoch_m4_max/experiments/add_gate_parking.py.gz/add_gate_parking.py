from pathlib import Path
import subprocess, json, hashlib, gzip
r=Path.cwd();v=r/'.venv-lighton-vllm-metal';p=r/'zig/pkg/inference/scripts/lightonocr3/results/throughput_epoch_m4_max';(p/'experiments').mkdir(exist_ok=True)
freeze=json.loads((v/'epoch_locked-freeze.json').read_text())
for f,h in freeze.items():assert hashlib.sha256((r/f).read_bytes()).hexdigest()==h,f
# The cache candidates are fully archived before restoring this pass's own
# changes; this worktree was clean at the base commit.
bench='zig/pkg/inference/scripts/lightonocr3/benchmark_concurrency.py'
(p/'experiments/cache_benchmark_concurrency.py.gz').write_bytes(gzip.compress((r/bench).read_bytes(),mtime=0))
for f in ['zig/pkg/inference/src/server/server.zig','zig/pkg/inference/src/pipelines/generation.zig','zig/pkg/inference/src/architectures/qwen3vl_projector.zig',bench]:
 (r/f).write_bytes(subprocess.check_output(['git','show','HEAD:'+f]))
f='zig/pkg/inference/src/execution_control.zig';s=(r/f).read_text();needle='''    pub fn lock(self: InferenceExecutionControl, mutex: *std.atomic.Mutex) !void {
        var spins: usize = 0;''';repl='''    pub fn lock(self: InferenceExecutionControl, mutex: *std.atomic.Mutex) !void {
        return self.lockWithPoll(mutex, 0);
    }

    /// Shared inference epochs can park between gate attempts instead of
    /// repeatedly yielding during a long GPU step. Cancellation is checked on
    /// every attempt and after acquiring the gate. Cap each requested sleep
    /// at 100us so a caller cannot create an unbounded cancellation interval.
    pub fn lockWithPoll(self: InferenceExecutionControl, mutex: *std.atomic.Mutex, poll_ns: u64) !void {
        var spins: usize = 0;''';assert needle in s;s=s.replace(needle,repl,1);needle='''            } else {
                @import("antfly_platform").time.yieldNow();
            }
        }
        self.check() catch |err| {''';repl='''            } else if (poll_ns != 0) {
                platform_time.sleepNs(@min(poll_ns, 100 * std.time.ns_per_us));
            } else {
                @import("antfly_platform").time.yieldNow();
            }
        }
        self.check() catch |err| {''';assert needle in s;s=s.replace(needle,repl,1)
s+='''

test "LightOnOCR3 parked execution gate preserves cancellation and lock ownership" {
    const Cancel = struct {
        calls: usize = 0,
        limit: usize,
        fn check(raw: ?*anyopaque) !void {
            const self: *@This() = @ptrCast(@alignCast(raw.?));
            self.calls += 1;
            if (self.calls >= self.limit) return error.Cancelled;
        }
    };
    var mutex = std.atomic.Mutex.unlocked;
    try std.testing.expect(mutex.tryLock());
    var blocked = Cancel{ .limit = 67 };
    const waiting = InferenceExecutionControl{ .ptr = &blocked, .check_fn = Cancel.check };
    try std.testing.expectError(error.Cancelled, waiting.lockWithPoll(&mutex, std.time.ns_per_s));
    try std.testing.expectEqual(@as(usize, 67), blocked.calls);
    try std.testing.expect(!mutex.tryLock());
    mutex.unlock();
    var cancelled = Cancel{ .limit = 1 };
    const acquired = InferenceExecutionControl{ .ptr = &cancelled, .check_fn = Cancel.check };
    try std.testing.expectError(error.Cancelled, acquired.lockWithPoll(&mutex, 100 * std.time.ns_per_us));
    try std.testing.expect(mutex.tryLock());
    mutex.unlock();
    try (InferenceExecutionControl{}).lockWithPoll(&mutex, 100 * std.time.ns_per_us);
    try std.testing.expect(!mutex.tryLock());
    mutex.unlock();
}
''';(r/f).write_text(s)
f='zig/pkg/inference/src/pipelines/generation.zig';s=(r/f).read_text();s=s.replace('    execution_lock: ?*std.atomic.Mutex = null,','    execution_lock: ?*std.atomic.Mutex = null,\n    /// Optional bounded polling for a shared epoch gate; zero retains yielding.\n    execution_contention_wait_ns: u64 = 0,',1);s=s.replace('            try control.lock(mutex)\n        else','            try control.lockWithPoll(mutex, self.execution_contention_wait_ns)\n        else',1);(r/f).write_text(s)
f='zig/pkg/inference/src/server/server.zig';s=(r/f).read_text();s=s.replace('            "TERMITE_METAL_DISABLE_LIGHTONOCR3_WEIGHT_HANDLES",','            "TERMITE_METAL_DISABLE_LIGHTONOCR3_WEIGHT_HANDLES",\n            "ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK",',1);s=s.replace(' or std.mem.eql(u8, policy, "default");',' or std.mem.eql(u8, policy, "default") or std.mem.eql(u8, policy, "gateoff");',1);s=s.replace('or std.mem.eql(u8, policy, "default")) "1" else "0", 1)', 'or std.mem.eql(u8, policy, "default") or std.mem.eql(u8, policy, "gateoff")) "1" else "0", 1)',1);anchor='''            }
            std.debug.print("OCR_POLICY round={d} name={s}\\n", .{ round, policy });''';insert='''                if (Env.setenv(policy_flags[22], if (std.mem.eql(u8, policy, "gateoff") or std.mem.eql(u8, policy, "pipelineoff")) "1" else "0", 1) != 0) return error.EnvironmentMutationFailed;
''';assert anchor in s;s=s.replace(anchor,insert+anchor,1)
s=s.replace('        step_mutex: std.atomic.Mutex = .unlocked,','        execution_gate_wait_ns: u64 = 0,\n        step_mutex: std.atomic.Mutex = .unlocked,',1);anchor='            ctx.coordinator.setPolicy(factory.node.lightOnOcrPolicy(factory.physical_rows_limit));';assert anchor in s;s=s.replace(anchor,anchor+'''\n            ctx.execution_gate_wait_ns = if (platform.env.getenvBool("ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK")) 0 else\n                @min(@as(u64, ctx.coordinator.policy.contention_wait_us), 100) * std.time.ns_per_us;''',1);anchor='''                std.debug.print("LIGHTONOCR3 registered_window_peak={d} physical_rows_limit={d}\\n",''';assert anchor in s;s=s.replace(anchor,'''                std.debug.print("LIGHTONOCR3 execution_gate_wait_ns={d}\\n", .{ctx.execution_gate_wait_ns});
'''+anchor,1);anchor='            .execution_lock = &ctx.step_mutex,';assert anchor in s;s=s.replace(anchor,anchor+'\n            .execution_contention_wait_ns = ctx.execution_gate_wait_ns,',1);(r/f).write_text(s)
s=(r/bench).read_text();s=s.replace('            "ANTFLY_LIGHTONOCR3_READY_COHORTS",','            "ANTFLY_LIGHTONOCR3_READY_COHORTS",\n            "ANTFLY_LIGHTONOCR3_DISABLE_GATE_PARK",',1);s=s.replace('            "default",\n            "direct",','            "default",\n            "gateoff",\n            "direct",',1);s=s.replace('                    "default",\n                )','                    "default",\n                    "gateoff",\n                )',1)
anchor='                    frames = re.findall(\n';insert='''                    sample["execution_gate_wait_ns"] = sorted({
                        int(value) for value in re.findall(
                            r"LIGHTONOCR3 execution_gate_wait_ns=(\\d+)", section
                        )
                    })
''';assert anchor in s;s=s.replace(anchor,insert+anchor,1);anchor='        if args.require_weight_handles:\n';insert='''        if args.require_execution_gate_wait:
            rounds = result.get("policy_rounds", [])
            if not rounds:
                result["status"] = "gate_wait_requires_policy_rounds"
            for sample in rounds:
                expected = 0 if sample["policy"] in ("gateoff", "pipelineoff", "spin") else min(args.contention_wait_us if args.contention_wait_us is not None else 100, 100) * 1000
                if sample["execution_gate_wait_ns"] != [expected]:
                    result["status"] = "gate_wait_control_mismatch"
''';assert anchor in s;s=s.replace(anchor,insert+anchor,1);s=s.replace('    parser.add_argument("--weight-handles", action="store_true")','    parser.add_argument("--weight-handles", action="store_true")\n    parser.add_argument("--require-execution-gate-wait", action="store_true")',1);(r/bench).write_text(s)
