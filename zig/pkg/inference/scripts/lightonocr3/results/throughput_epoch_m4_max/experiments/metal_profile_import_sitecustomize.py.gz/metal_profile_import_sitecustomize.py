import os,ctypes,json
from pathlib import Path
library=os.environ.get('OCR_METAL_OBSERVER_LIBRARY')
if library:
 ctypes.CDLL(library)
 with (Path(os.environ['OCR_METAL_PROFILE_DIR'])/'profile_imports.txt').open('a') as out:out.write(json.dumps({'pid':os.getpid(),'library':library})+chr(10))
