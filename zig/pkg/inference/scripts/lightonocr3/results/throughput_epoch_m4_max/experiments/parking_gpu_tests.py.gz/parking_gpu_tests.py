import os, pathlib, subprocess, sys
root=pathlib.Path.cwd()
env=os.environ.copy()
env.pop("ANTFLY_INFERENCE_REQUIRED_BACKEND",None)
env.pop("ANTFLY_LIGHTONOCR3_DISABLE_SHARED_VISION_PEAK",None)
env.pop("ANTFLY_LIGHTONOCR3_CONTINUOUS",None)
env.pop("ANTFLY_LIGHTONOCR3_BATCH_ROWS",None)
env.pop("ANTFLY_LIGHTONOCR3_BATCH_WINDOW",None)
env["ANTFLY_LIGHTONOCR3_VISION_WAIT_US"]="100000"
env["ANTFLY_LIGHTONOCR3_PREFILL_WAIT_US"]="100000"
env["ANTFLY_LIGHTONOCR3_PREFILL_BATCH"]="1"
env["ANTFLY_LIGHTONOCR3_VISION_BATCH"]="1"
env["ANTFLY_TEST_LIGHTONOCR3_VISION_BATCH_CHECK"]="1"
env.update(ANTFLY_INFERENCE_PREFERRED_BACKEND="metal",TERMITE_METAL_ENABLE_LIGHTONOCR3_WEIGHT_RESIDENCY="1",ANTFLY_TEST_LIGHTONOCR3_MODEL_DIR=str(root/".venv-lighton-vllm-metal/ocr-models/lighton08"),ANTFLY_BENCH_LIGHTONOCR3="1",ANTFLY_TEST_LIGHTONOCR3_WARM_RUNS="0",ANTFLY_TEST_LIGHTONOCR3_HTTP_BATCH="1",ANTFLY_TEST_LIGHTONOCR3_MEMORY_LIMIT_GIB="24",ANTFLY_TEST_LIGHTONOCR3_SHARED_LIMIT_GIB="28",ANTFLY_TEST_LIGHTONOCR3_BACKEND_LIMIT_GIB="16",ANTFLY_TEST_LIGHTONOCR3_KV_LIMIT_GIB="4",ANTFLY_TEST_LIGHTONOCR3_SCRATCH_LIMIT_GIB="4")
env["TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_COALESCING"]="1"
env["TERMITE_METAL_ENABLE_LIGHTONOCR3_WEIGHT_HANDLES"]="1"
env["TERMITE_METAL_TRACE_LIGHTONOCR3_WEIGHT_HANDLES"]="1"
cmd=[str((root/"zig/.zig-cache/o/09b03ce8271789faab59b01e7c707376/test").resolve())]
for f in ["LightOnOCR3","Qwen3-VL","batch decode context","execution lane","projector residency","executor batch","coalesc","Florence","shared native provider","dynamic linear slot","decode GQA split"]:cmd += ["--test-filter",f]
with open("/private/tmp/ocr-parking-local-gpu-tests.txt","w") as out:r=subprocess.run(cmd,cwd=root/"zig/pkg/inference",env=env,stdout=out,stderr=subprocess.STDOUT)
if r.returncode:sys.exit(r.returncode)
env.pop('TERMITE_METAL_ENABLE_LIGHTONOCR3_WEIGHT_HANDLES',None)
env['TERMITE_METAL_ENABLE_LIGHTONOCR3_RECURRENT_COALESCING']='0'
env['ANTFLY_LIGHTONOCR3_VISION_BATCH']='0'
env['ANTFLY_LIGHTONOCR3_PREFILL_BATCH']='0'
with open('/private/tmp/ocr-parking-local-gpu-tests.txt','a') as out:
 out.write('\nDEFAULT_SHARED_VISION_PEAK_TEST\n');out.flush()
 r=subprocess.run([cmd[0],'--test-filter','LightOnOCR3 real checkpoint transcribes'],cwd=root/'zig/pkg/inference',env=env,stdout=out,stderr=subprocess.STDOUT)
sys.exit(r.returncode)
