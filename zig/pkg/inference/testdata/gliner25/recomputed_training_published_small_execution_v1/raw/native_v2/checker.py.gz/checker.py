"""Bounded, read-only checks for the prepared native all131 training profile.

Tensor payloads stay in their opened files. Each read is at most one MiB;
only bounded headers, counters and small digest metadata are retained.
"""
from __future__ import annotations

import contextlib
import hashlib
import json
import math
import os
from pathlib import Path
import secrets
import signal
import stat
import struct

ROOT = Path(__file__).resolve().parent
MIB = 1024**2
CHUNK = MIB
PREPARATION_SHA256 = 'd96cb14c5c1636a7f04949d8ac9e6fd6e735cfeae582e9e7249920b3258c5b07'
MODEL_FILES = {'adapter_config.json', 'adapter_model.safetensors', 'antfly_gliner25_adapter.json', 'antfly_gliner25_training.json'}
SEMANTIC_REPORT = ('epoch', 'batch', 'examples', 'terms', 'coverage', 'optimizer', 'decision_fingerprint', 'zero_loss_fallback')
TERM_NAMES = {'start', 'end', 'pair', 'inside', 'soft_iou', 'rerank_listwise', 'proposal', 'consistency', 'abstention', 'count', 'classification', 'record_object', 'record_field', 'relation', 'total'}
F32_FIELDS = ({'config.run.' + x for x in ('encoder_lr', 'task_lr', 'weight_decay', 'beta1', 'beta2', 'epsilon', 'max_grad_norm', 'num_cycles')}
              | {'config.peft.alpha', 'config.peft.dropout'}
              | {'config.weights.' + x for x in ('start', 'end', 'pair', 'inside')}
              | {'config.gold_start', 'config.gold_end', 'config.gold_hold_fraction'})


def require(condition, message):
    if not condition:
        raise ValueError(message)


def integer(value, name, lower=0, upper=2**64-1):
    require(type(value) is int and lower <= value <= upper, 'invalid integer: ' + name)
    return value


def finite(value):
    require(type(value) in (int, float) and math.isfinite(value), 'expected finite number')
    return value


def byte_array(value):
    require(type(value) is list and len(value) == 32, 'expected32 digest bytes')
    return bytes(integer(x, 'digest byte', 0, 255) for x in value)


def pin(raw):
    return {'size_bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def stamp(info):
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns


def regular(path, maximum, allow_empty=False):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        info = os.fstat(fd)
        require(stat.S_ISREG(info.st_mode), 'not regular: ' + str(path))
        require((0 if allow_empty else 1) <= info.st_size <= maximum, 'file size bound: ' + str(path))
        return fd, info
    except BaseException:
        os.close(fd)
        raise


def read(path, maximum=4*MIB):
    fd, info = regular(path, maximum)
    try:
        raw = bytearray()
        while len(raw) < info.st_size:
            chunk = os.read(fd, min(CHUNK, info.st_size-len(raw)))
            require(bool(chunk), 'truncated file: ' + str(path))
            raw.extend(chunk)
        require(stamp(info) == stamp(os.fstat(fd)), 'file changed: ' + str(path))
        return bytes(raw)
    finally:
        os.close(fd)


def digest(path, maximum=1024*MIB, allow_empty=False):
    fd, info = regular(path, maximum, allow_empty)
    try:
        hashed = hashlib.sha256()
        size = 0
        while size < info.st_size:
            chunk = os.read(fd, min(CHUNK, info.st_size-size))
            require(bool(chunk), 'truncated digest: ' + str(path))
            size += len(chunk)
            hashed.update(chunk)
        require(stamp(info) == stamp(os.fstat(fd)), 'file changed: ' + str(path))
        return {'size_bytes': size, 'sha256': hashed.hexdigest()}
    finally:
        os.close(fd)


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key: ' + key)
        result[key] = value
    return result


class RawNumber(str):
    """An original finite float lexeme, for exact Zig JSON hash reproduction."""


def loads(raw, preserve_numbers=False):
    require(0 < len(raw) <= 4*MIB, 'JSON byte limit')
    depth = work = 0
    quoted = escaped = False
    for ch in raw:
        if quoted:
            if escaped:
                escaped = False
            elif ch == 92:
                escaped = True
            elif ch == 34:
                quoted = False
        elif ch == 34:
            quoted = True
        elif ch in (123, 91):
            depth += 1
            work += 1
            require(depth <= 32 and work <= 131072, 'JSON depth/structural limit')
        elif ch in (125, 93):
            depth -= 1
            require(depth >= 0, 'unbalanced JSON')
    require(depth == 0 and not quoted, 'truncated JSON')
    def number(token):
        require(math.isfinite(float(token)), 'nonfinite JSON float')
        return RawNumber(token) if preserve_numbers else float(token)
    def int_token(token):
        require(len(token.lstrip('-')) <= 20, 'JSON integer overflow')
        value = int(token)
        require(-(2**63) <= value <= 2**64-1, 'JSON integer overflow')
        return value
    def bad(token):
        raise ValueError('nonfinite JSON: ' + token)
    return json.loads(raw, object_pairs_hook=unique, parse_float=number, parse_int=int_token, parse_constant=bad)


def load(path, maximum=4*MIB):
    return loads(read(path, maximum))


@contextlib.contextmanager
def protected_receipt():
    old = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT, signal.SIGTERM})
    try:
        yield
    finally:
        signal.pthread_sigmask(signal.SIG_SETMASK, old)


def write_new(path, value):
    """Publish one bounded immutable JSON file without replacing any output."""
    path = Path(path)
    raw = (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()
    require(len(raw) <= 4*MIB, 'receipt byte limit')
    temporary = path.parent / ('.receipt-' + secrets.token_hex(16) + '.tmp')
    fd = None
    try:
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
        offset = 0
        while offset < len(raw):
            count = os.write(fd, raw[offset:offset+256*1024])
            require(count > 0, 'short receipt write')
            offset += count
        os.fsync(fd)
        os.close(fd)
        fd = None
        # Hard-link publication is atomic and refuses an existing destination.
        os.link(temporary, path, follow_symlinks=False)
        os.unlink(temporary)
        directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if fd is not None:
            os.close(fd)
        with protected_receipt():
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass
    return pin(raw)


def config_subset(expected, actual, prefix='config'):
    if prefix in F32_FIELDS:
        canonical, = struct.unpack('<f', struct.pack('<f', finite(expected)))
        require(math.isfinite(canonical) and finite(actual) == canonical and (canonical != 0 or math.copysign(1, actual) == math.copysign(1, canonical)), 'changed consumed ' + prefix)
    elif prefix == 'config.run.warmup_ratio':
        require(finite(expected) == finite(actual), 'changed consumed ' + prefix)
    elif type(expected) is dict:
        require(type(actual) is dict, 'wrong object: ' + prefix)
        for key, value in expected.items():
            require(key in actual, 'missing ' + prefix + '.' + key)
            config_subset(value, actual[key], prefix + '.' + key)
    elif type(expected) is list:
        require(type(actual) is list and len(expected) == len(actual), 'wrong array: ' + prefix)
        for i, (left, right) in enumerate(zip(expected, actual)):
            config_subset(left, right, prefix + '[' + str(i) + ']')
    else:
        require(type(expected) is type(actual) and expected == actual, 'changed consumed ' + prefix)


def preparation():
    raw = read(ROOT / 'preparation.json', 64*1024)
    require(pin(raw)['sha256'] == PREPARATION_SHA256, 'preparation changed')
    prep = loads(raw)
    require(prep['format'] == 'antfly.gliner25-regional-all-small-native-preparation/v1' and prep['model_execution'] is False, 'wrong preparation')
    for key, filename in (('inventory', 'inventory.json'), ('resource_plan', 'resource_plan.json'), ('qualification_plan', 'qualification_plan.json')):
        require(digest(ROOT / filename, MIB) == prep[key], 'prepared ' + filename + ' changed')
    for filename, wanted in prep['configs'].items():
        require(digest(ROOT / filename, 64*1024) == wanted, 'prepared config changed: ' + filename)
    require(digest(Path(prep['data']['path']), MIB) == {key: prep['data'][key] for key in ('size_bytes', 'sha256')}, 'dataset changed')
    inventory = load(ROOT / 'inventory.json', MIB)
    validate_inventory(inventory)
    return prep, inventory, load(ROOT / 'resource_plan.json', 64*1024)


def validate_formula_inventory(recorded, resources):
    """Bind static resource formulas to archived build bytes, never checkout."""
    require(type(recorded) is dict, 'missing frozen build source inventory')
    for name, expected in resources['code_formula_pins'].items():
        actual = recorded.get(expected['path'])
        require(type(actual) is dict, 'build omits formula source: '+name)
        require(integer(actual.get('size_bytes'), 'formula source bytes', 1, 2*MIB) == expected['size_bytes'] and actual.get('sha256') == expected['sha256'], 'build formula source changed: '+name)


def validate_inventory(inventory):
    modules = inventory['modules']
    require(inventory['module_count'] == len(modules) == 131 and inventory['source_parameter_count'] == 334, 'wrong published inventory count')
    require([m['module'] for m in modules] == sorted({m['module'] for m in modules}), 'unordered/duplicate target modules')
    counts = {family: sum(m['family'] == family for m in modules) for family in ('encoder', 'boundary_head', 'classifier', 'record_decoder', 'relation_scorer')}
    require(counts == {'encoder': 72, 'boundary_head': 43, 'classifier': 2, 'record_decoder': 8, 'relation_scorer': 6}, 'wrong target families')
    for mode in ('lora', 'dora'):
        expected = []
        for m in modules:
            integer(m['in_dim'], 'input width', 1, 16384)
            integer(m['out_dim'], 'output width', 1, 16384)
            require(m['base_weight'] == m['module'] + '.weight' and m['family'] == m['module'].split('.')[0], 'canonical module mismatch')
            prefix = 'base_model.model.' + m['module']
            for leaf, saved, shape in (('lora_A.default.weight', 'lora_A.weight', [2, m['in_dim']]), ('lora_B.default.weight', 'lora_B.weight', [m['out_dim'], 2]), *((('lora_magnitude_vector.default.weight', 'lora_magnitude_vector', [m['out_dim']]),) if mode == 'dora' else ())):
                expected.append({'name': prefix + '.' + leaf, 'saved_key': prefix + '.' + saved, 'shape': shape, 'family': m['family'], 'group': 0})
        actual = inventory['modes'][mode]
        require(actual['slots'] == expected and actual['slot_count'] == len(expected), 'ordered adapter inventory mismatch')
        require(actual['parameter_payload_bytes'] == sum(math.prod(x['shape'])*4 for x in expected), 'adapter payload census mismatch')


def verify_source(prep):
    for filename, wanted in zip(prep['source_file_names'], [prep['source']['weight'], *prep['source']['sidecars']]):
        require(digest(Path(prep['source_dir']) / filename, 512*MIB) == wanted, 'source changed: ' + filename)
    require(digest(Path(prep['data']['path']), MIB) == {key: prep['data'][key] for key in ('size_bytes', 'sha256')}, 'dataset changed')


def dormant(slot):
    name = slot['name'].removeprefix('base_model.model.')
    return name.startswith(('boundary_head.boundary_proposer.', 'boundary_head.pair_scorer.', 'boundary_head.candidate_encoder.'))


def route(slot, paused):
    # Fixed shared-pool entity/classification schema: explicit-span proposer
    # and pair-scorer are unused; candidate_encoder has no record consumer.
    if dormant(slot):
        return 0, False
    return (0, True) if paused else (2 if slot['family'] == 'classifier' else 3, False)


class TensorFile:
    def __init__(self, path, maximum=16*MIB, max_header=2*MIB):
        self.path = Path(path)
        self.fd, self.initial = regular(path, maximum)
        self.max_read_bytes = 0
        try:
            require(self.initial.st_size >= 10, 'truncated SafeTensors')
            length, = struct.unpack('<Q', self._read(0, 8))
            require(1 < length <= max_header and 8+length <= self.initial.st_size, 'SafeTensors header bound')
            self.offset = 8+length
            self.header = loads(self._read(8, length))
            require(type(self.header) is dict and 0 < len(self.header) <= 4096, 'tensor metadata count')
            self.tensors = {}
            ranges = []
            for name, item in self.header.items():
                if name == '__metadata__':
                    require(type(item) is dict and len(item) <= 64 and all(type(k) is str and type(v) is str and len(k)+len(v) <= 4096 for k, v in item.items()), 'invalid SafeTensors metadata')
                    continue
                require(type(name) is str and 0 < len(name.encode()) <= 1024 and all(ord(x) >= 32 for x in name), 'invalid tensor name')
                require(type(item) is dict and set(item) == {'dtype', 'shape', 'data_offsets'} and item['dtype'] == 'F32', 'unsupported tensor descriptor')
                shape = item['shape']
                require(type(shape) is list and 1 <= len(shape) <= 8, 'tensor rank')
                elements = 1
                for dim in shape:
                    elements *= integer(dim, 'dimension', 1, 2**31-1)
                    require(elements*4 <= maximum, 'tensor element bound')
                offsets = item['data_offsets']
                require(type(offsets) is list and len(offsets) == 2, 'tensor offsets')
                start, end = (integer(x, 'offset', 0, maximum) for x in offsets)
                require(start < end <= self.initial.st_size-self.offset and end-start == 4*elements, 'tensor payload range/shape')
                self.tensors[name] = {'shape': shape, 'start': start, 'end': end, 'elements': elements}
                ranges.append((start, end))
            position = 0
            for start, end in sorted(ranges):
                require(start == position, 'overlapping/missing tensor payload')
                position = end
            require(position == self.initial.st_size-self.offset, 'trailing/truncated tensor payload')
            self.verify()
        except BaseException:
            os.close(self.fd)
            self.fd = None
            raise

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        try:
            if exc_type is None:
                self.verify()
        finally:
            os.close(self.fd)
            self.fd = None

    def verify(self):
        require(stamp(os.fstat(self.fd)) == stamp(self.initial), 'tensor file changed while open')

    def _read(self, offset, count):
        chunks = []
        while count:
            request = min(CHUNK, count)
            self.max_read_bytes = max(self.max_read_bytes, request)
            value = os.pread(self.fd, request, offset)
            require(len(value) == request, 'truncated tensor read')
            chunks.append(value)
            offset += request
            count -= request
        return b''.join(chunks)

    def require_shape(self, name, shape):
        require(name in self.tensors and self.tensors[name]['shape'] == shape, 'tensor shape mismatch: ' + name)

    def chunks(self, name):
        require(name in self.tensors, 'missing tensor: ' + name)
        item = self.tensors[name]
        offset = item['start']
        while offset < item['end']:
            count = min(CHUNK, item['end']-offset)
            yield self._read(self.offset+offset, count)
            offset += count
        self.verify()

    def values(self, name, maximum=4096):
        require(self.tensors[name]['elements'] <= maximum, 'scalar/counter read bound')
        result = [value[0] for chunk in self.chunks(name) for value in struct.iter_unpack('<f', chunk)]
        require(all(math.isfinite(x) for x in result), 'nonfinite counter')
        return result

    def scan(self, name, hasher=None, nonnegative=False, zero=False):
        own = hashlib.sha256()
        for chunk in self.chunks(name):
            for (value,) in struct.iter_unpack('<f', chunk):
                require(math.isfinite(value), 'nonfinite tensor: ' + name)
                require(not nonnegative or value >= 0, 'negative second moment: ' + name)
                require(not zero or value == 0, 'unexpected nonzero tensor: ' + name)
            own.update(chunk)
            if hasher is not None:
                hasher.update(chunk)
        return own.hexdigest()

    def digest(self):
        hashed = hashlib.sha256()
        for offset in range(0, self.initial.st_size, CHUNK):
            hashed.update(self._read(offset, min(CHUNK, self.initial.st_size-offset)))
        self.verify()
        return {'size_bytes': self.initial.st_size, 'sha256': hashed.hexdigest()}


def decode_limbs(values, bits):
    require(len(values) == 4 and bits in (8, 16), 'invalid counter limb count')
    result = 0
    for i, value in enumerate(values):
        require(type(value) is float and math.isfinite(value) and value.is_integer() and 0 <= value < 2**bits, 'invalid counter limb')
        result |= int(value) << (i*bits)
    return result


def compact_numbers(value):
    if type(value) is RawNumber:
        return str(value)
    if type(value) is dict:
        return '{' + ','.join(json.dumps(k, ensure_ascii=False) + ':' + compact_numbers(v) for k, v in value.items()) + '}'
    if type(value) is list:
        return '[' + ','.join(compact_numbers(v) for v in value) + ']'
    require(type(value) in (str, int, bool, type(None)), 'unexpected fingerprint value')
    return json.dumps(value, separators=(',', ':'), ensure_ascii=False)


def controller_fingerprint(manifest_bytes, slots):
    manifest = loads(manifest_bytes, preserve_numbers=True)
    cfg = manifest['config']
    run = cfg['run']
    require(manifest['backend'] == cfg['execution'] == 'native', 'wrong controller execution')
    require(run['mode'] in ('lora', 'dora') and run['scheduler'] == 'constant' and run['epochs'] == 1 and run['batch_size'] == 1 and run['accumulation'] == 2 and run['warmup_steps'] == 0 and run.get('max_optimizer_steps') is None, 'wrong controller schedule')
    opt = {'beta1': run['beta1'], 'beta2': run['beta2'], 'eps': run['epsilon'], 'weight_decay': run['weight_decay']}
    settings = {'groups': [{'optimizer': opt, 'schedule': {'warmup_constant': {'initial_lr': run['task_lr'], 'warmup_steps': 0, 'total_steps': 3}}}], 'grad_accum_steps': 2, 'max_grad_norm': run['max_grad_norm'], 'partial_window': 'actual_microbatches'}
    hashed = hashlib.sha256(b'antfly.seeded-gradient-trainer.v1' + byte_array(manifest['run_fingerprint']) + compact_numbers(settings).encode())
    for slot in slots:
        hashed.update(compact_numbers({'name': slot['name'], 'dimensions': slot['shape'], 'group': 0}).encode())
    return hashed.digest()


def validate_checkpoint(path, slots, paused, controller_hash, expected_state=None):
    expected_keys = {'__trainer_counters', '__run_fingerprint', '__extension.seeded.counters', '__extension.seeded.presence'}
    for i, slot in enumerate(slots):
        expected_keys.update(prefix+'::'+slot['name'] for prefix in ('weight', 'adam_m', 'adam_v', 'adam_step', 'adam_step_u32'))
        expected_keys.add('__extension.seeded.gradient.'+str(i))
    require(len({s['name'] for s in slots}) == len(slots), 'duplicate expected slot')
    with TensorFile(path) as tensors:
        require(set(tensors.tensors) == expected_keys, 'checkpoint added or omitted tensors')
        for name, shape in (('__trainer_counters', [8]), ('__run_fingerprint', [32]), ('__extension.seeded.counters', [3]), ('__extension.seeded.presence', [len(slots)])):
            tensors.require_shape(name, shape)
        counters = tensors.values('__trainer_counters')
        micro, update = decode_limbs(counters[:4], 16), decode_limbs(counters[4:], 16)
        require((micro, update) == ((1, 0) if paused else (5, 3)), 'wrong global checkpoint counters')
        require(tensors.values('__run_fingerprint') == list(controller_hash), 'controller checkpoint fingerprint mismatch')
        require(tensors.values('__extension.seeded.counters') == [1, int(paused), 2], 'wrong accumulated count/divisor')
        presence = tensors.values('__extension.seeded.presence')
        require(all(x in (0, 1) for x in presence), 'nonbinary gradient presence')
        hashed = hashlib.sha256(b'antfly.seeded-gradient-state.v1\0' + controller_hash)
        def u64(value):
            hashed.update(struct.pack('<Q', value))
        for value in (update, micro, int(paused), len(slots)):
            u64(value)
        evidence = []
        for i, slot in enumerate(slots):
            name = slot['name']
            step, present = route(slot, paused)
            require(presence[i] == int(present), 'wrong routed gradient presence: ' + name)
            for prefix in ('weight', 'adam_m', 'adam_v'):
                tensors.require_shape(prefix+'::'+name, [math.prod(slot['shape'])])
            gradient = '__extension.seeded.gradient.' + str(i)
            tensors.require_shape(gradient, [math.prod(slot['shape'])])
            tensors.require_shape('adam_step_u32::'+name, [4])
            tensors.require_shape('adam_step::'+name, [1])
            require(decode_limbs(tensors.values('adam_step_u32::'+name), 8) == step, 'wrong routed Adam counter: '+name)
            require(tensors.values('adam_step::'+name) == [step], 'compatibility Adam counter mismatch: '+name)
            encoded = name.encode()
            u64(len(encoded)); hashed.update(encoded); u64(len(slot['shape']))
            for dim in slot['shape']:
                u64(dim)
            for value in (step, step, int(present)):
                u64(value)
            digests = {}
            for prefix, key in (('weight', 'weight::'+name), ('m', 'adam_m::'+name), ('v', 'adam_v::'+name), ('gradient', gradient)):
                u64(math.prod(slot['shape']))
                digests[prefix] = tensors.scan(key, hashed, nonnegative=prefix == 'v', zero=(prefix in ('m', 'v') and step == 0) or (prefix == 'gradient' and not present))
            evidence.append({'name': name, 'shape': slot['shape'], 'adam_step': step, 'present': present, 'payload_sha256': digests})
        actual_state = hashed.digest()
        if expected_state is not None:
            require(actual_state == byte_array(expected_state), 'independently reconstructed state digest mismatch')
        return {'file': tensors.digest(), 'controller_fingerprint': list(controller_hash), 'state_sha256': list(actual_state), 'slots': evidence, 'stream_read_maximum_bytes': tensors.max_read_bytes}


def layout_fingerprint(mode, inventory):
    hashed = hashlib.sha256(b'antfly-gliner25-model-peft-layout/v1\0')
    def u32(value):
        hashed.update(struct.pack('<I', value))
    def string(value):
        raw = value.encode(); u32(len(raw)); hashed.update(raw)
    string('small'); string(mode); u32(2)
    hashed.update(struct.pack('<ff', 3.0, 0.0)); u32(131)
    by_name = {s['name']: s for s in inventory['modes'][mode]['slots']}
    for module in inventory['modules']:
        name = module['module']; prefix = 'base_model.model.' + name
        a = by_name[prefix+'.lora_A.default.weight']; b = by_name[prefix+'.lora_B.default.weight']
        base = module['base_weight']
        if base.startswith('encoder.encoder.layer.'):
            base = base[len('encoder.'):]
        for value in (name, base, a['name'], b['name'], a['saved_key'], b['saved_key']):
            string(value)
        if mode == 'dora':
            m = by_name[prefix+'.lora_magnitude_vector.default.weight']; string(m['name']); string(m['saved_key'])
        u32(module['in_dim']); u32(module['out_dim'])
    return hashed.digest()


def validate_export(output, config, result, manifest, inventory, checkpoint):
    mode = config['run']['mode']
    directory = Path(output) / 'model'
    require(stat.S_ISDIR(directory.lstat().st_mode) and {p.name for p in directory.iterdir()} == MODEL_FILES, 'unexpected export directory/files')
    files = {name: digest(directory/name, 4*MIB) for name in sorted(MODEL_FILES)}
    cfg = load(directory/'adapter_config.json', 128*1024)
    expected = {'peft_type': 'LORA', 'task_type': None, 'base_model_name_or_path': config['source_dir'], 'revision': None, 'r': 2, 'lora_alpha': 3, 'lora_dropout': 0, 'target_modules': [m['module'] for m in inventory['modules']], 'bias': 'none', 'use_dora': mode == 'dora', 'fan_in_fan_out': False, 'inference_mode': True}
    require(cfg == expected and type(cfg['r']) is int and type(cfg['use_dora']) is bool and type(cfg['fan_in_fan_out']) is bool and type(cfg['inference_mode']) is bool, 'export PEFT configuration changed')
    require(finite(cfg['lora_alpha']) == 3 and finite(cfg['lora_dropout']) == 0, 'invalid PEFT numeric configuration')
    target_hash = hashlib.sha256(b'antfly-gliner25-peft-targets/v1\0'+mode.encode()+struct.pack('<Iff', 2, 3.0, 0.0))
    parameter_hash = hashlib.sha256(b'antfly-gliner25-peft-parameters/v1\0')
    slots = inventory['modes'][mode]['slots']
    checkpoint_slots = {x['name']: x for x in checkpoint['slots']}
    with TensorFile(directory/'adapter_model.safetensors', 4*MIB, MIB) as tensors:
        require(set(tensors.tensors) == {x['saved_key'] for x in slots}, 'saved adapter key inventory mismatch')
        by_module = {}
        for slot in slots:
            tensors.require_shape(slot['saved_key'], slot['shape'])
            module = slot['name'].removeprefix('base_model.model.').split('.lora_', 1)[0]
            by_module.setdefault(module, []).append(slot)
        for m in inventory['modules']:
            name = m['module'].encode()
            target_hash.update(struct.pack('<I', len(name))+name+struct.pack('<II', m['in_dim'], m['out_dim']))
            parameter_hash.update(name+b'\0')
            for slot in by_module[m['module']]:
                parameter_hash.update(struct.pack('<Q', math.prod(slot['shape'])))
                raw_digest = tensors.scan(slot['saved_key'], parameter_hash)
                require(raw_digest == checkpoint_slots[slot['name']]['payload_sha256']['weight'], 'export weight differs from final checkpoint: '+slot['name'])
            if mode == 'lora':
                parameter_hash.update(struct.pack('<Q', 0))
        require(tensors.digest() == files['adapter_model.safetensors'], 'adapter file changed')
    adapter = load(directory/'antfly_gliner25_adapter.json', 64*1024)
    require(adapter['family'] == 'gliner_boundary_adapter/v1' and integer(adapter['version'], 'adapter version') == 1 and integer(adapter['architecture_version'], 'adapter architecture') == 1 and integer(adapter['config_version'], 'adapter config version') == 3, 'adapter receipt version mismatch')
    require(adapter['source'] == manifest['source'] and adapter['schema_sha256'] == manifest['schema_sha256'], 'adapter source/schema mismatch')
    require(byte_array(adapter['frozen_weight_sha256']).hex() == manifest['source']['weight']['sha256'], 'frozen weight receipt mismatch')
    require(byte_array(adapter['target_sha256']) == target_hash.digest() and byte_array(adapter['parameter_sha256']) == parameter_hash.digest(), 'adapter target/parameter digest mismatch')
    require(adapter['config'] == files['adapter_config.json'] and adapter['weights'] == files['adapter_model.safetensors'], 'adapter receipt file pins mismatch')
    receipt = load(directory/'antfly_gliner25_training.json', 64*1024)
    require(receipt['family'] == 'gliner_boundary_training_snapshot/v1' and integer(receipt['version'], 'export version') == integer(receipt['architecture_version'], 'export architecture') == integer(receipt['tensor_policy_version'], 'export tensor policy') == 1 and integer(receipt['config_version'], 'export config version') == 3 and receipt['mode'] == mode, 'training export receipt version mismatch')
    provenance = {'run_fingerprint': result['run_fingerprint'], 'dataset_sha256': manifest['train_sha256'], 'schemas_sha256': manifest['schema_sha256'], 'optimizer_identity': result['identity'], 'accumulated_microbatches': 0}
    require(receipt['source'] == manifest['source'] and receipt['provenance'] == provenance and receipt['sidecars'] is None, 'training export provenance mismatch')
    require(integer(receipt['provenance']['accumulated_microbatches'], 'export accumulation') == 0, 'invalid export accumulation')
    validate_identity(receipt['provenance']['optimizer_identity'], result['identity'])
    require(byte_array(receipt['adapter_layout_sha256']) == layout_fingerprint(mode, inventory), 'global adapter layout digest mismatch')
    require(receipt['weights'] == files['adapter_model.safetensors'] and receipt['adapter_config'] == files['adapter_config.json'] and receipt['adapter_receipt'] == files['antfly_gliner25_adapter.json'], 'training receipt artifact mismatch')
    portable = result['portable_model']
    require(portable['mode'] == mode and portable['weights'] == files['adapter_model.safetensors'] and portable['provenance'] == files['antfly_gliner25_training.json'], 'terminal export pins mismatch')
    total = sum(x['size_bytes'] for x in files.values())
    require(integer(portable['output_bytes'], 'export bytes') == total <= config['export_limits']['max_output_bytes'], 'export size mismatch')
    require(integer(portable['peak_scratch_bytes'], 'export scratch') <= config['export_limits']['max_scratch_bytes'], 'export scratch exceeded')
    return files


def validate_reports(reports, phase):
    rows = [0] if phase == 'paused' else list(range(1, 5)) if phase == 'resumed' else list(range(5))
    require(len(reports) == len(rows) + int(phase != 'paused'), 'missing/extra progress rows')
    for report, row in zip(reports, rows):
        require(all(key in report for key in SEMANTIC_REPORT), 'missing semantic report field')
        require(integer(report['epoch'], 'epoch') == 0 and integer(report['batch'], 'row') == row and integer(report['examples'], 'examples') == 1, 'wrong dataset order/cardinality')
        require(report['zero_loss_fallback'] is False, 'all-target encoder path unexpectedly used zero-loss fallback')
        terms = report['terms']
        require(type(terms) is dict and set(terms) == TERM_NAMES and all(math.isfinite(finite(x)) for x in terms.values()), 'invalid loss terms')
        require(terms['total'] > 0 and (terms['classification'] > 0 if row in (0, 2) else terms['classification'] == 0), 'wrong active/inactive classification terms')
        coverage = {'gold_mentions': 1, 'proposed_gold_mentions': 1, 'gold_relations': 0, 'proposed_gold_relations': 0, 'matched_records': 0}
        require(type(report['coverage']) is dict and set(report['coverage']) == set(coverage), 'gold coverage fields changed')
        require(all(integer(report['coverage'][key], 'coverage '+key) == value for key, value in coverage.items()), 'gold coverage changed')
        opt = report['optimizer']
        expected = {'optimizer_step': (row+1)//2, 'microbatch_step': row+1}
        validate_identity(opt['identity'], expected)
        require(opt['optimizer_stepped'] is (row in (1, 3)) and integer(opt['accumulated_microbatches'], 'accumulation') == (row+1)%2, 'wrong optimizer accumulation')
        require(finite(opt['loss']) == terms['total'] and finite(opt['grad_norm']) >= 0, 'optimizer objective/norm mismatch')
        byte_array(report['decision_fingerprint'])
    if phase != 'paused':
        final = reports[-1]
        require(integer(final['examples'], 'flush examples') == 0 and final['terms'] is None, 'missing partial flush event')
        opt = final['optimizer']
        validate_identity(opt['identity'], {'optimizer_step': 3, 'microbatch_step': 5})
        require(opt['optimizer_stepped'] is True and integer(opt['accumulated_microbatches'], 'flush accumulation') == 0 and opt['loss'] is None and finite(opt['grad_norm']) >= 0, 'wrong final partial flush')


def validate_identity(value, expected):
    require(type(value) is dict and set(value) == set(expected), 'invalid optimizer identity')
    for name, want in expected.items():
        require(integer(value[name], name) == want, 'optimizer identity changed: '+name)


def compare_continuity(whole, paused, resumed):
    require(whole['result'] == resumed['result'] and whole['result']['run_fingerprint'] == paused['result']['run_fingerprint'], 'final state/run changed on fresh resume')
    stitched = paused['reports'] + resumed['reports']
    require(len(stitched) == len(whole['reports']), 'stitched report cardinality')
    for left, right in zip(whole['reports'], stitched):
        require({key: left[key] for key in SEMANTIC_REPORT} == {key: right[key] for key in SEMANTIC_REPORT}, 'resume semantic/decision bytes differ')
    for name in ('result.json', 'latest.safetensors', *('model/'+x for x in sorted(MODEL_FILES))):
        require(whole['files'][name] == resumed['files'][name], 'resume artifact bytes differ: '+name)
    initial = {x['name']: x for x in paused['checkpoint']['slots']}
    for slot in whole['checkpoint']['slots']:
        if dormant(slot):
            require(slot['payload_sha256']['weight'] == initial[slot['name']]['payload_sha256']['weight'], 'dormant adapter weight changed')
